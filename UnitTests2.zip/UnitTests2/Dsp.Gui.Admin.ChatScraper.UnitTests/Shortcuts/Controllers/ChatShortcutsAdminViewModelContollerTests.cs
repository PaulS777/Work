﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Controllers
{
    internal interface IChatShortcutsAdminViewModelControllerTestObjects
    {
        ISubject<List<ChatIceMap>> ChatIceMaps { get; }
        ISubject<List<ChatMarket>> ChatMarkets { get; }
        ISubject<List<ChatVariableShortcut>> ChatVariableShortcuts { get; }
        IChatShortcutsItemViewModelBuilder ChatShortcutsViewModelBuilder { get; }
        IChatShortcutsItemCollectionProvider ChatShortcutsCollectionProvider { get; }
        IChatShortcutsItemCollectionService ChatShortcutsItemCollectionService { get; }
        IChatIceMapDuplicateShortcutsService DuplicateShortcutsService { get; }
        IChatVariableShortcutBuilder ChatVariableShortcutBuilder { get; }
        IChatVariableShortcutAdminUpdateService ChatVariableShortcutAdminUpdateService { get; }
        IChatScraperShortcutsAdminToolBarService ToolBarService { get; }
        ISubject<bool> CanExecuteUpdateCommand { get; }
        ISubject<bool> CanExecuteUndoCommand { get; }
        ISubject<IList<string>> ValidationErrors { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        ISubject<Unit> ToolBarUndo { get; }
        ISubject<Unit> ChatShortcutsUpdateResponse { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        ChatShortcutsAdminViewModel ViewModel { get; }
        ChatShortcutsAdminViewModelController Controller { get; }
    }

    [TestFixture]
    public class ChatShortcutsAdminViewModelControllerTests
    {
        private class ChatShortcutsAdminViewModelControllerTestObjectBuilder
        {
            private List<ChatIceMap> _chatIceMaps;
            private List<ChatMarket> _chatMarkets;
            private List<ChatVariableShortcut> _chatVariableShortcuts;
            private ChatShortcutsItemViewModel _createNewChatShortcutsItemResult;
            private IList<ChatShortcutsItemViewModel> _chatShortcutsProviderResult;

            public ChatShortcutsAdminViewModelControllerTestObjectBuilder WithChatIceMaps(List<ChatIceMap> values)
            {
                _chatIceMaps = values;
                return this;
            }

            public ChatShortcutsAdminViewModelControllerTestObjectBuilder WithChatMarkets(List<ChatMarket> values)
            {
                _chatMarkets = values;
                return this;
            }

            public ChatShortcutsAdminViewModelControllerTestObjectBuilder WithChatVariableShortcuts(List<ChatVariableShortcut> values)
            {
                _chatVariableShortcuts = values;
                return this;
            }

            public ChatShortcutsAdminViewModelControllerTestObjectBuilder WithChatShortcutsProviderResult(IList<ChatShortcutsItemViewModel> values)
            {
                _chatShortcutsProviderResult = values;
                return this;
            }

            public ChatShortcutsAdminViewModelControllerTestObjectBuilder CreateNewChatShortcutsItemResult(ChatShortcutsItemViewModel value)
            {
                _createNewChatShortcutsItemResult = value;
                return this;
            }

            public IChatShortcutsAdminViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatShortcutsAdminViewModelControllerTestObjects>();

                var chatIceMaps = new BehaviorSubject<List<ChatIceMap>>(_chatIceMaps);

                testObjects.SetupGet(o => o.ChatIceMaps)
                           .Returns(chatIceMaps);

                var chatMarkets = new BehaviorSubject<List<ChatMarket>>(_chatMarkets);

                testObjects.SetupGet(o => o.ChatMarkets)
                           .Returns(chatMarkets);

                var chatVariableShortcuts = new BehaviorSubject<List<ChatVariableShortcut>>(_chatVariableShortcuts);

                testObjects.SetupGet(o => o.ChatVariableShortcuts)
                           .Returns(chatVariableShortcuts);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ChatIceMaps)
                                   .Returns(chatIceMaps);

                curveControlService.SetupGet(c => c.ChatMarkets)
                                   .Returns(chatMarkets);

                curveControlService.SetupGet(c => c.ChatVariableShortcuts)
                                   .Returns(chatVariableShortcuts);

                curveControlService.Setup(c => c.GetChatVariableShortcutSnapshot())
                                   .Returns(_chatVariableShortcuts);

                var chatShortcutsUpdateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.ChatShortcutsUpdateResponse)
                           .Returns(chatShortcutsUpdateResponse);

                var chatVariableShortcutsAdminUpdateService = new Mock<IChatVariableShortcutAdminUpdateService>();

                chatVariableShortcutsAdminUpdateService.Setup(c => c.Update(It.IsAny<IList<ChatShortcutsItemViewModel>>(),
                                                                            It.IsAny<IScheduler>(),
                                                                            It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut>>(),
                                                                            It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut>>(),
                                                                            It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut>>()))
                                                       .Returns(chatShortcutsUpdateResponse);

                testObjects.SetupGet(o => o.ChatVariableShortcutAdminUpdateService)
                           .Returns(chatVariableShortcutsAdminUpdateService.Object);

                var toolBarUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUpdate)
                           .Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUndo)
                           .Returns(toolBarUndo);

                var toolBarService = new Mock<IChatScraperShortcutsAdminToolBarService>();

                toolBarService.SetupGet(tb => tb.Update)
                              .Returns(toolBarUpdate);

                toolBarService.SetupGet(tb => tb.Undo)
                              .Returns(toolBarUndo);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBarService.Object);

                var collectionProvider = new Mock<IChatShortcutsItemCollectionProvider>();

                testObjects.SetupGet(o => o.ChatShortcutsCollectionProvider)
                           .Returns(collectionProvider.Object);

                collectionProvider.Setup(p => p.GetCollection(It.IsAny<IList<ChatShortcutsItemViewModel>>(),
                                                              It.IsAny<IList<ChatVariableShortcut>>(),
                                                              It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut, bool>>(),
                                                              It.IsAny<Action<ChatShortcutsItemViewModel, ChatVariableShortcut>>(),
                                                              It.IsAny<Func<ChatVariableShortcut, ChatShortcutsItemViewModel>>()))
                                  .Returns(_chatShortcutsProviderResult);

                collectionProvider.Setup(p => p.GetCollectionReset(It.IsAny<IList<ChatVariableShortcut>>(), 
                                                                   It.IsAny<Func<ChatVariableShortcut, ChatShortcutsItemViewModel>>()))
                                  .Returns(_chatShortcutsProviderResult);

                var shortcutsBuilder = new Mock<IChatShortcutsItemViewModelBuilder>();

                shortcutsBuilder.Setup(b => b.CreateNewItem(It.IsAny<ObservableCollection<ChatIceMap>>(),
                                                                     It.IsAny<ObservableCollection<ChatMarket>>()))
                                .Returns(_createNewChatShortcutsItemResult);

                testObjects.SetupGet(o => o.ChatShortcutsViewModelBuilder)
                           .Returns(shortcutsBuilder.Object);

                var canExecuteUpdateCommand = new Subject<bool>();

                testObjects.SetupGet(o => o.CanExecuteUpdateCommand)
                           .Returns(canExecuteUpdateCommand);

                var canExecuteUndoCommand = new Subject<bool>();

                testObjects.SetupGet(o => o.CanExecuteUndoCommand)
                           .Returns(canExecuteUndoCommand);

                var validationErrors = new Subject<IList<string>>();

                testObjects.SetupGet(o => o.ValidationErrors)
                           .Returns(validationErrors);

                var chatShortcutsService = new Mock<IChatShortcutsItemCollectionService>();

                chatShortcutsService.SetupGet(cs => cs.CanExecuteUndoCommand)
                                    .Returns(canExecuteUndoCommand);

                chatShortcutsService.SetupGet(cs => cs.CanExecuteUpdateCommand)
                                    .Returns(canExecuteUpdateCommand);

                chatShortcutsService.SetupGet(cs => cs.ValidationErrors)
                                    .Returns(validationErrors);

                testObjects.SetupGet(o => o.ChatShortcutsItemCollectionService)
                           .Returns(chatShortcutsService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var chatVariableShortcutBuilder = new Mock<IChatVariableShortcutBuilder>();

                testObjects.SetupGet(o => o.ChatVariableShortcutBuilder)
                           .Returns(chatVariableShortcutBuilder.Object);

                var duplicateShortcutsService = new Mock<IChatIceMapDuplicateShortcutsService>();

                testObjects.SetupGet(o => o.DuplicateShortcutsService)
                           .Returns(duplicateShortcutsService.Object);

                var controller = new ChatShortcutsAdminViewModelController(curveControlService.Object,
                                                                           toolBarService.Object,
                                                                           collectionProvider.Object,
                                                                           chatShortcutsService.Object,
                                                                           duplicateShortcutsService.Object,
                                                                           chatVariableShortcutsAdminUpdateService.Object,
                                                                           TestMocks.GetSchedulerProvider().Object,
                                                                           TestMocks.GetLoggerFactory().Object)
                {
                    ChatShortcutsItemViewModelBuilder = shortcutsBuilder.Object,
                    ChatVariableShortcutBuilder = chatVariableShortcutBuilder.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    PopupNotificationService = popupNotificationService.Object
                };

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPopulateChatShortcuts_On_ChatVariableShortcuts_With_MarketsAndIceMaps()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatVariableShortcut = new ChatVariableShortcut(51, EntityStatus.Active, "name", "s1;s2", new List<ChatVariableShortcutVariation>());

            var chatVariableShortcuts = new List<ChatVariableShortcut>
            {
                chatVariableShortcut
            };

            var chatShortcutsViewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>()) { Id = 51 };

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                chatShortcutsViewModel
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .Build();
            var comparerResult = false;

            Mock.Get(testObjects.ChatShortcutsCollectionProvider)
                .Setup(p => p.GetCollection(It.IsAny<IList<ChatShortcutsItemViewModel>>(), //null
                                            It.IsAny<IList<ChatVariableShortcut>>(),
                                            It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut, bool>>(),
                                            It.IsAny<Action<ChatShortcutsItemViewModel, ChatVariableShortcut>>(),
                                            It.IsAny<Func<ChatVariableShortcut, ChatShortcutsItemViewModel>>()))
                .Returns(chatShortcutsViewModels)
                .Callback<IList<ChatShortcutsItemViewModel>,
                    IList<ChatVariableShortcut>,
                    Func<ChatShortcutsItemViewModel, ChatVariableShortcut, bool>,
                    Action<ChatShortcutsItemViewModel, ChatVariableShortcut>,
                    Func<ChatVariableShortcut, ChatShortcutsItemViewModel>>
                ((_, _, comparer, updater, builder) =>
                {
                    comparerResult = comparer(chatShortcutsViewModel, chatVariableShortcut);
                    updater(chatShortcutsViewModel, chatVariableShortcut);
                    builder(chatVariableShortcut);
                });

            // ACT
            testObjects.ChatVariableShortcuts.OnNext(chatVariableShortcuts);

            // ASSERT
            Assert.That(comparerResult, Is.True);

            Mock.Get(testObjects.ChatShortcutsViewModelBuilder)
                .Verify(b => b.UpdateItemFromChatVariableShortcut(chatShortcutsViewModel, chatVariableShortcut));

            Mock.Get(testObjects.ChatShortcutsViewModelBuilder)
                .Verify(b => b.CreateItemFromChatVariableShortcut(chatVariableShortcut, 
                                                   It.Is<ObservableCollection<ChatIceMap>>(m => m.Count == 1),
                                                   It.Is<ObservableCollection<ChatMarket>>(m => m.Count == 1)));

            Assert.That(testObjects.ViewModel.ChatIceMaps.Count, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.ChatMarkets.Count, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.ChatShortcuts.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldRefreshItems_On_ChatVariableShortcuts_With_MarketsAndIceMaps()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatVariableShortcuts = new List<ChatVariableShortcut>
            {
                new(51, EntityStatus.Active, "name", "s1;s2", new List<ChatVariableShortcutVariation>())
            };

            var result = false;

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RefreshItemsCommand = new DelegateCommand(() => result = true)
                }
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .WithChatShortcutsProviderResult(chatShortcutsViewModels)
                                                                                          .Build();
            // ACT
            testObjects.ChatVariableShortcuts.OnNext(chatVariableShortcuts);

            // ASSERT
            Mock.Get(testObjects.ChatShortcutsItemCollectionService)
                .Verify(cs => cs.RefreshItems(It.Is<IList<ChatShortcutsItemViewModel>>(i => i.Count == 1)));

            Mock.Get(testObjects.DuplicateShortcutsService)
                .Verify(cs => cs.RefreshItems(It.Is<IList<ChatShortcutsItemViewModel>>(i => i.Count == 1)));

            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldInvokeCollectionProvider_On_ChatVariableShortcutsUpdate()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatVariableShortcuts = new List<ChatVariableShortcut>
            {
                new(51,
                    EntityStatus.Active,
                    "name",
                    "s1;s2",
                    new List<ChatVariableShortcutVariation>())
            };

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .WithChatVariableShortcuts(chatVariableShortcuts)
                                                                                          .WithChatShortcutsProviderResult(chatShortcutsViewModels)
                                                                                          .Build();

            var chatVariableShortcutsUpdate = new List<ChatVariableShortcut>
            {
                new(51,
                    EntityStatus.Active,
                    "name",
                    "s1;s2;s3",
                    new List<ChatVariableShortcutVariation>())
            };

            Mock.Get(testObjects.ChatShortcutsCollectionProvider).Invocations.Clear();

            // ACT
            testObjects.ChatVariableShortcuts.OnNext(chatVariableShortcutsUpdate);

            // ASSERT
            Mock.Get(testObjects.ChatShortcutsCollectionProvider)
                .Verify(p => p.GetCollection(testObjects.ViewModel.ChatShortcuts,
                                             chatVariableShortcutsUpdate,
                                             It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut, bool>>(),
                                             It.IsAny<Action<ChatShortcutsItemViewModel, ChatVariableShortcut>>(),
                                             It.IsAny<Func<ChatVariableShortcut, ChatShortcutsItemViewModel>>()));
        }

        [Test]
        public void ShouldUpdateChatIceMaps_On_ChatIceMapsUpdate()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatVariableShortcuts = new List<ChatVariableShortcut>
            {
                new(51,
                    EntityStatus.Active,
                    "name",
                    "s1;s2",
                    new List<ChatVariableShortcutVariation>())
            };

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .WithChatVariableShortcuts(chatVariableShortcuts)
                                                                                          .WithChatShortcutsProviderResult(chatShortcutsViewModels)
                                                                                          .Build();

            var chatIceMapsUpdate = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty),
                new(92, EntityStatus.Active, "curve-2", 24, null, string.Empty)
            };

            // ACT
            testObjects.ChatIceMaps.OnNext(chatIceMapsUpdate);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatIceMaps.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldUpdateChatMarkets_On_ChatMarketsUpdate()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatVariableShortcuts = new List<ChatVariableShortcut>
            {
                new(51,
                    EntityStatus.Active,
                    "name",
                    "s1;s2",
                    new List<ChatVariableShortcutVariation>())
            };

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .WithChatVariableShortcuts(chatVariableShortcuts)
                                                                                          .WithChatShortcutsProviderResult(chatShortcutsViewModels)
                                                                                          .Build();

            var chatMarketsUpdate = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1"),
                new(22, EntityStatus.Active, "market-2")
            };

            // ACT
            testObjects.ChatMarkets.OnNext(chatMarketsUpdate);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatMarkets.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldNotInvokeCollectionProvider_On_ChatIceMaps_Or_ChatMarketsUpdate()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatVariableShortcuts = new List<ChatVariableShortcut>
            {
                new(51,
                    EntityStatus.Active,
                    "name",
                    "s1;s2",
                    new List<ChatVariableShortcutVariation>())
            };

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .WithChatVariableShortcuts(chatVariableShortcuts)
                                                                                          .WithChatShortcutsProviderResult(chatShortcutsViewModels)
                                                                                          .Build();

            var chatIceMapsUpdate = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty),
                new(92, EntityStatus.Active, "curve-2", 24, null, string.Empty)
            };

            var chatMarketsUpdate = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1"),
                new(22, EntityStatus.Active, "market-2")
            };

            Mock.Get(testObjects.ChatShortcutsCollectionProvider).Invocations.Clear();

            // ACT
            testObjects.ChatIceMaps.OnNext(chatIceMapsUpdate);
            testObjects.ChatMarkets.OnNext(chatMarketsUpdate);

            // ASSERT
            Mock.Get(testObjects.ChatShortcutsCollectionProvider)
                .Verify(p => p.GetCollection(testObjects.ViewModel.ChatShortcuts,
                                             It.IsAny<IList<ChatVariableShortcut>>(),
                                             It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut, bool>>(),
                                             It.IsAny<Action<ChatShortcutsItemViewModel, ChatVariableShortcut>>(),
                                             It.IsAny<Func<ChatVariableShortcut, ChatShortcutsItemViewModel>>()), Times.Never);
        }

        [Test]
        public void ShouldAddNewChatShortcutsItem_On_AddShortcutsCommand()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var result = false;

            var chatShortcutsViewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                RefreshItemsCommand = new DelegateCommand(() => result = true)
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .CreateNewChatShortcutsItemResult(chatShortcutsViewModel)
                                                                                          .Build();
            // ACT
            testObjects.ViewModel.AddShortcutsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ChatShortcutsViewModelBuilder)
                .Verify(b => b.CreateNewItem(It.Is<ObservableCollection<ChatIceMap>>(m => m.Count == 1),
                                             It.Is<ObservableCollection<ChatMarket>>(m => m.Count == 1)));

            Mock.Get(testObjects.ChatShortcutsItemCollectionService)
                .Verify(cs => cs.AddNewItem(chatShortcutsViewModel, 
                                            testObjects.ViewModel.ChatShortcuts, 
                                            testObjects.ViewModel));

            Mock.Get(testObjects.DuplicateShortcutsService)
                .Verify(cs => cs.AddItem(chatShortcutsViewModel));

            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldSetValidationErrors_When_Errors()
        {
            var errors = new List<string> { "error" };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetValidationErrors(errors));
        }

        [Test]
        public void ShouldClearValidationErrors_When_NoErrors()
        {
            var errors = new List<string>();

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.ClearValidation());
        }

        [Test]
        public void ShouldEnableUndoCommand_OnCanExecuteUndoCommandTrue()
        {
            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CanExecuteUndoCommand.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(true));
        }

        [Test]
        public void ShouldEnableUpdateCommand_OnCanExecuteUpdateCommandTrue()
        {
            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CanExecuteUpdateCommand.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldUndoChanges_On_ToolBarUndo()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatVariableShortcuts = new List<ChatVariableShortcut>
            {
                new(51, EntityStatus.Active, "name", "s1;s2", new List<ChatVariableShortcutVariation>())
            };

            var result = false;

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RefreshItemsCommand = new DelegateCommand(() => result = true)
                }
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .WithChatVariableShortcuts(chatVariableShortcuts)
                                                                                          .WithChatShortcutsProviderResult(chatShortcutsViewModels)
                                                                                          .Build();

            testObjects.ViewModel.ChatShortcuts.Clear();
            result = false;

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ChatShortcutsCollectionProvider)
                .Verify(p => p.GetCollectionReset(chatVariableShortcuts, 
                                                  It.IsAny<Func<ChatVariableShortcut, ChatShortcutsItemViewModel>>()));

            Assert.That(testObjects.ViewModel.ChatShortcuts.Count, Is.EqualTo(1));

            Mock.Get(testObjects.ChatShortcutsItemCollectionService)
                .Verify(cs => cs.RefreshItems(It.Is<IList<ChatShortcutsItemViewModel>>(i => i.Count == 1)));

            Mock.Get(testObjects.DuplicateShortcutsService)
                .Verify(cs => cs.RefreshItems(It.Is<IList<ChatShortcutsItemViewModel>>(i => i.Count == 1)));

            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldSetIsBusy_On_ToolBarUpdate()
        {
            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldInvokeAdminUpdateService_OnToolBarUpdate()
        {
            var chatIceMaps = new List<ChatIceMap>();
            var chatMarkets = new List<ChatMarket>();
            var chatVariableShortcuts = new List<ChatVariableShortcut>();
            var chatShortcutsViewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>());

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                chatShortcutsViewModel
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .WithChatVariableShortcuts(chatVariableShortcuts)
                                                                                          .WithChatShortcutsProviderResult(chatShortcutsViewModels)
                                                                                          .Build();

            Mock.Get(testObjects.ChatVariableShortcutAdminUpdateService)
                .Setup(u => u.Update(It.IsAny<IList<ChatShortcutsItemViewModel>>(),
                                     It.IsAny<IScheduler>(),
                                     It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut>>(),
                                     It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut>>(),
                                     It.IsAny<Func<ChatShortcutsItemViewModel, ChatVariableShortcut>>()))
                .Returns(Observable.Return(Unit.Default))
                .Callback<IList<ChatShortcutsItemViewModel>, 
                     IScheduler, 
                     Func<ChatShortcutsItemViewModel, ChatVariableShortcut>, 
                     Func<ChatShortcutsItemViewModel, ChatVariableShortcut>, 
                     Func<ChatShortcutsItemViewModel, ChatVariableShortcut>>
                ((_, _, func1, func2, func3) =>
                {
                    func1(chatShortcutsViewModel);
                    func2(chatShortcutsViewModel);
                    func3(chatShortcutsViewModel);
                });

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            Mock.Get(testObjects.ChatVariableShortcutBuilder)
                .Verify(b => b.GetNewChatVariableShortcut(chatShortcutsViewModel), Times.Once);

            Mock.Get(testObjects.ChatVariableShortcutBuilder)
                .Verify(b => b.GetUpdatedChatVariableShortcut(chatShortcutsViewModel), Times.Once);

            Mock.Get(testObjects.ChatVariableShortcutBuilder)
                .Verify(b => b.GetDeletedChatVariableShortcut(chatShortcutsViewModel), Times.Once);
        }

        [Test]
        public void ShouldShowPopupAndSetIsBusyFalse_OnChatShortcutsUpdateCompleted()
        {
            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ChatShortcutsUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), null));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldShowPopupAndSetIsBusyFalse_OnChatShortcutsUpdateError()
        {
            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ChatShortcutsUpdateResponse.OnError(new Exception("error"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "error"
                                                                                && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldNotUpdateChatIceMaps_When_Disposed()
        {
            var chatIceMaps = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatVariableShortcuts = new List<ChatVariableShortcut>
            {
                new(51, EntityStatus.Active, "name", "s1;s2", new List<ChatVariableShortcutVariation>())
            };

            var chatShortcutsViewModels = new List<ChatShortcutsItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                          .WithChatMarkets(chatMarkets)
                                                                                          .WithChatVariableShortcuts(chatVariableShortcuts)
                                                                                          .WithChatShortcutsProviderResult(chatShortcutsViewModels)
                                                                                          .Build();

            var chatIceMapsUpdate = new List<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty),
                new(92, EntityStatus.Active, "curve-2", 24, null, string.Empty)
            };

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ChatIceMaps.OnNext(chatIceMapsUpdate);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatIceMaps.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldDisposeServices_When_Disposed()
        {
            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ACT
            Mock.Get(testObjects.ChatShortcutsItemCollectionService)
                .Verify(cs => cs.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ChatShortcutsAdminViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();
            Mock.Get(testObjects.ChatShortcutsItemCollectionService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ACT
            Mock.Get(testObjects.ChatShortcutsItemCollectionService)
                .Verify(cs => cs.Dispose(), Times.Never);
        }
    }
}
