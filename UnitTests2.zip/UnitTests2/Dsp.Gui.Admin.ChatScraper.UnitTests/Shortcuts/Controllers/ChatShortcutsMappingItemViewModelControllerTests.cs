﻿using Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Controllers
{
    internal interface IChatShortcutsMappingItemViewModelControllerTestObjects
    {
        IChatShortcutsMappingItemSubscribeUpdatesService SubscribeUpdatesService { get; }
        ChatShortcutsMappingItemViewModel ViewModel { get; }
        ChatShortcutsMappingItemViewModelController Controller { get; }
    }

    [TestFixture]
    public class ChatShortcutsMappingItemViewModelControllerTests
    {
        private class ChatShortcutsMappingItemViewModelControllerTestObjectBuilder
        {
            public IChatShortcutsMappingItemViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatShortcutsMappingItemViewModelControllerTestObjects>();

                var subscribeUpdates = new Mock<IChatShortcutsMappingItemSubscribeUpdatesService>();

                testObjects.SetupGet(o => o.SubscribeUpdatesService)
                           .Returns(subscribeUpdates.Object);

                var controller = new ChatShortcutsMappingItemViewModelController(subscribeUpdates.Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachSubscribeUpdates()
        {
            var testObjects = new ChatShortcutsMappingItemViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.SubscribeUpdatesService)
                .Verify(su => su.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSetIsDeletedTrue_On_DeleteCommand()
        {
            var testObjects = new ChatShortcutsMappingItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.True);
        }

        [Test]
        public void ShouldSetIsDeletedFalse_On_UndoDeleteCommand()
        {
            var testObjects = new ChatShortcutsMappingItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.DeleteCommand.Execute();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.False);
        }

        [Test]
        public void ShouldDisposeSubscribeUpdates_When_Dispose()
        {
            var testObjects = new ChatShortcutsMappingItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // VERIFY
            Mock.Get(testObjects.SubscribeUpdatesService)
                .Verify(v => v.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ChatShortcutsMappingItemViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            Mock.Get(testObjects.SubscribeUpdatesService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // VERIFY
            Mock.Get(testObjects.SubscribeUpdatesService)
                .Verify(v => v.Dispose(), Times.Never);
        }
    }
}
