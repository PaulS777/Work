﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Controllers
{
    internal interface IChatShortcutsItemViewModelControllerTestObjects
    {
        IChatShortcutsSubscribeUpdatesService SubscribeUpdatesService { get; }
        IChatShortcutsItemViewModelBuilder ChatShortcutsViewModelBuilder { get; }
        ISubject<bool> CanExecuteUndoCommand { get; }
        ISubject<IList<string>> ValidationErrors { get; }
        IChatShortcutsMappingItemCollectionService MappingItemCollectionService { get; }
        ChatShortcutsItemViewModel ViewModel { get; }
        ChatShortcutsItemViewModelController Controller { get; }
    }

    [TestFixture]
    public class ChatShortcutsItemViewModelControllerTests
    {
        private class ChatShortcutsItemViewModelControllerTestObjectBuilder
        {
            private ObservableCollection<ChatMarket> _chatMarkets;
            private ObservableCollection<ChatIceMap> _chatIceMaps;
            private ChatShortcutsMappingItemViewModel _chatShortcutsItemBuilderResult;
            private ObservableCollection<ChatShortcutsMappingItemViewModel> _chatShortcutsMappings;

            public ChatShortcutsItemViewModelControllerTestObjectBuilder WithChatMarkets(ObservableCollection<ChatMarket> values)
            {
                _chatMarkets = values;
                return this;
            }

            public ChatShortcutsItemViewModelControllerTestObjectBuilder WithChatIceMaps(ObservableCollection<ChatIceMap> values)
            {
                _chatIceMaps = values;
                return this;
            }

            public ChatShortcutsItemViewModelControllerTestObjectBuilder WithChatShortcutsItemBuilderResult(ChatShortcutsMappingItemViewModel value)
            {
                _chatShortcutsItemBuilderResult = value;
                return this;
            }

            public ChatShortcutsItemViewModelControllerTestObjectBuilder WithChatShortcutsMappingItems(ObservableCollection<ChatShortcutsMappingItemViewModel> values)
            {
                _chatShortcutsMappings = values;
                return this;
            }

            public IChatShortcutsItemViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatShortcutsItemViewModelControllerTestObjects>();

                var subscribeUpdates = new Mock<IChatShortcutsSubscribeUpdatesService>();

                testObjects.SetupGet(o => o.SubscribeUpdatesService)
                           .Returns(subscribeUpdates.Object);

                var canExecuteUndoCommand = new Subject<bool>();

                testObjects.SetupGet(o => o.CanExecuteUndoCommand)
                           .Returns(canExecuteUndoCommand);

                var validationErrors = new Subject<IList<string>>();

                testObjects.SetupGet(o => o.ValidationErrors)
                           .Returns(validationErrors);

                var mappingItemCollectionService = new Mock<IChatShortcutsMappingItemCollectionService>();

                mappingItemCollectionService.SetupGet(c => c.CanExecuteUndoCommand)
                                            .Returns(canExecuteUndoCommand);

                mappingItemCollectionService.SetupGet(c => c.ValidationErrors)
                                            .Returns(validationErrors);

                testObjects.SetupGet(o => o.MappingItemCollectionService)
                           .Returns(mappingItemCollectionService.Object);

                var builder = new Mock<IChatShortcutsItemViewModelBuilder>();

                builder.Setup(b => b.CreateNewMappingItem(It.IsAny<ObservableCollection<ChatIceMap>>(),
                                                          It.IsAny<ObservableCollection<ChatMarket>>()))
                       .Returns(_chatShortcutsItemBuilderResult);

                testObjects.SetupGet(o => o.ChatShortcutsViewModelBuilder)
                           .Returns(builder.Object);

                var controller = new ChatShortcutsItemViewModelController(subscribeUpdates.Object,
                                                                          mappingItemCollectionService.Object)
                {
                    ChatShortcutsItemViewModelBuilder = builder.Object
                };

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                controller.ViewModel.SetChatIceMaps(_chatIceMaps);
                controller.ViewModel.SetChatMarkets(_chatMarkets);
                controller.ViewModel.ChatShortcutsMappings = _chatShortcutsMappings;

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachSubscribeUpdatesService()
        {
            // ACT
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            Mock.Get(testObjects.SubscribeUpdatesService)
                .Verify(s => s.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSetIsDeletedTrue_On_DeleteCommand()
        {
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.True);
        }

        [Test]
        public void ShouldSetIsDeletedFalse_On_UndoDeleteCommand()
        {
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.DeleteCommand.Execute();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.False);
        }

        [Test]
        public void ShouldSetChatShortcutsMappingsChangedTrue_On_CanExecuteUndoCommand()
        {
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CanExecuteUndoCommand.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatShortcutsMappingsChanged, Is.True);
        }

        [Test]
        public void ShouldSetChatShortcutsMappingsValidFalse_When_ValidationErrors()
        {
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            var errors = new[] { "error" };

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatShortcutsMappingsValid, Is.False);
        }

        [Test]
        public void ShouldChatShortcutsMappingsValidTrue_When_NoValidationsErrors()
        {
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            var errors = new string[] { };

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatShortcutsMappingsValid, Is.True);
        }

        [Test]
        public void ShouldAddNewItem_On_AddItemCommand()
        {
            var chatIceMaps = new ObservableCollection<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new ObservableCollection<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var row = new ChatShortcutsMappingItemViewModel(Mock.Of<IDisposable>());

            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                         .WithChatMarkets(chatMarkets)
                                                                                         .WithChatShortcutsItemBuilderResult(row)
                                                                                         .Build();
            // ACT
            testObjects.ViewModel.AddItemCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ChatShortcutsViewModelBuilder)
                .Verify(b => b.CreateNewMappingItem(It.Is<ObservableCollection<ChatIceMap>>(m => m.Count == 1),
                                                    It.Is<ObservableCollection<ChatMarket>>(m => m.Count == 1)));

            Mock.Get(testObjects.MappingItemCollectionService)
                .Verify(rs => rs.AddNewItem(row, testObjects.ViewModel.ChatShortcutsMappings));
        }

        [Test]
        public void ShouldRefreshItems_On_AddRefreshItemsCommand()
        {
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.RefreshItemsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.MappingItemCollectionService)
                .Verify(rs => rs.RefreshItems(testObjects.ViewModel.ChatShortcutsMappings));
        }

        [Test]
        public void ShouldNotSetChatShortcutsMappingsChanged_When_Disposed()
        {
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.CanExecuteUndoCommand.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatShortcutsMappingsChanged, Is.False);
        }

        [Test]
        public void ShouldDisposeItemsAndServices_On_Dispose()
        {
            var mappingController = new Mock<IDisposable>();
            var mapping = new ChatShortcutsMappingItemViewModel(mappingController.Object);

            var mappings = new ObservableCollection<ChatShortcutsMappingItemViewModel> { mapping };

            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().WithChatShortcutsMappingItems(mappings)
                                                                                         .Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            mappingController.Verify(r => r.Dispose());
            Mock.Get(testObjects.MappingItemCollectionService).Verify(rs => rs.Dispose());
            Mock.Get(testObjects.SubscribeUpdatesService).Verify(rs => rs.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ChatShortcutsItemViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            Mock.Get(testObjects.MappingItemCollectionService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.MappingItemCollectionService).Verify(rs => rs.Dispose(), Times.Never);
        }
    }
}
