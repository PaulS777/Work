﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Services
{
    [TestFixture]
    public class ChatShortcutsMappingItemValidationServiceTests
    {
        [Test]
        public void ShouldReturnIsDuplicateText()
        {
            var service = new ChatShortcutsMappingItemValidationService(new ChatShortcutsMappingMarketRule(), 
                                                                        new ChatShortcutsMappingIceMapRule());

            // ACT
            var result = service.IsDuplicateText();

            // ASSERT
            Assert.That(result, Is.EqualTo("Duplicate Market"));
        }

        [Test]
        public void ShouldSetIsValidTrue_When_Attach_With_ValidChatShortcuts()
        {
            var market = new ChatMarket(21, EntityStatus.Active, "market");
            var iceMap = new ChatIceMap(91, EntityStatus.Active, "curve-1", 23, null, string.Empty);

            var viewModel = new ChatShortcutsMappingItemViewModel(Mock.Of<IDisposable>())
            {
                Market = market,
                IceMap = iceMap
            };

            var validationService = new ChatShortcutsMappingItemValidationService(new ChatShortcutsMappingMarketRule(),
                                                                                  new ChatShortcutsMappingIceMapRule());

            // ACT
            validationService.Attach(viewModel);

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_MarketRuleFails()
        {
            var market = new ChatMarket(21, EntityStatus.Active, "market");
            var iceMap = new ChatIceMap(91, EntityStatus.Active, "curve-1", 23, null, string.Empty);

            var viewModel = new ChatShortcutsMappingItemViewModel(Mock.Of<IDisposable>())
            {
                Market = market,
                IceMap = iceMap
            };

            var validationService = new ChatShortcutsMappingItemValidationService(new ChatShortcutsMappingMarketRule(),
                                                                                  new ChatShortcutsMappingIceMapRule());

            validationService.Attach(viewModel);

            // ACT
            viewModel.Market = null;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText != null && viewModel.ErrorText == "Missing Market");
        }

        [Test]
        public void ShouldSetIsValidFalse_When_IceMapRuleFails()
        {
            var market = new ChatMarket(21, EntityStatus.Active, "market");
            var iceMap = new ChatIceMap(91, EntityStatus.Active, "curve-1", 23, null, string.Empty);

            var viewModel = new ChatShortcutsMappingItemViewModel(Mock.Of<IDisposable>())
            {
                Market = market,
                IceMap = iceMap
            };

            var validationService = new ChatShortcutsMappingItemValidationService(new ChatShortcutsMappingMarketRule(),
                                                                                  new ChatShortcutsMappingIceMapRule());


            validationService.Attach(viewModel);

            // ACT
            viewModel.IceMap = null;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText != null && viewModel.ErrorText == "Missing Price Curve");
        }

        [Test]
        public void ShouldReturnIsDuplicateText_When_IsDuplicate()
        {
            var market = new ChatMarket(21, EntityStatus.Active, "market");
            var iceMap = new ChatIceMap(91, EntityStatus.Active, "curve-1", 23, null, string.Empty);

            var viewModel = new ChatShortcutsMappingItemViewModel(Mock.Of<IDisposable>())
            {
                Market = market,
                IceMap = iceMap
            };

            var validationService = new ChatShortcutsMappingItemValidationService(new ChatShortcutsMappingMarketRule(),
                                                                                  new ChatShortcutsMappingIceMapRule());

            validationService.Attach(viewModel);

            // ACT
            viewModel.IsDuplicate = true;
            var result = validationService.IsDuplicateText();

            // ASSERT
            Assert.That(result, Is.EqualTo("Duplicate Market"));
        }
    }
}
