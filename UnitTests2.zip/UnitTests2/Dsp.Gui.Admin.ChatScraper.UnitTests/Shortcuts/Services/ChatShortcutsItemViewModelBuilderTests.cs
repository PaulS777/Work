﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Services
{
    internal interface IChatShortcutsItemViewModelBuilderTestObjects
    {
        ChatShortcutsItemViewModelBuilder ChatShortcutsViewModelBuilder { get; }
    }

    [TestFixture]
    public class ChatShortcutsItemViewModelBuilderTests
    {
        private class ChatShortcutsItemViewModelBuilderTestObjectBuilder
        {
            private IChatShortcutsItemViewModelController _chatShortcutsViewModelController;
            private IChatShortcutsMappingItemViewModelController _mappingViewModelController1;
            private IChatShortcutsMappingItemViewModelController _mappingViewModelController2;

            public ChatShortcutsItemViewModelBuilderTestObjectBuilder WithChatShortcutsViewModelController(IChatShortcutsItemViewModelController value)
            {
                _chatShortcutsViewModelController = value;
                return this;
            }

            public ChatShortcutsItemViewModelBuilderTestObjectBuilder WithMappingViewModelControllers(IChatShortcutsMappingItemViewModelController value1,
                                                                                                      IChatShortcutsMappingItemViewModelController value2 =null)
            {
                _mappingViewModelController1 = value1;
                _mappingViewModelController2 = value2;

                return this;
            }

            public IChatShortcutsItemViewModelBuilderTestObjects Build()
            {
                var testObjects = new Mock<IChatShortcutsItemViewModelBuilderTestObjects>();

                var itemFactory = new Mock<IServiceFactory<IChatShortcutsItemViewModelController>>();

                itemFactory.Setup(f => f.Create())
                           .Returns(_chatShortcutsViewModelController);

                var mappingItemFactory = new Mock<IServiceFactory<IChatShortcutsMappingItemViewModelController>>();

                mappingItemFactory.SetupSequence(f => f.Create())
                                  .Returns(_mappingViewModelController1)
                                  .Returns(_mappingViewModelController2);

                var builder = new ChatShortcutsItemViewModelBuilder
                              {
                                  ItemFactory = itemFactory.Object,
                                  MappingItemFactory = mappingItemFactory.Object
                              };

                testObjects.SetupGet(o => o.ChatShortcutsViewModelBuilder)
                           .Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCreateChatShortcutsViewModel_From_ChatVariableShortcut_With_Markets_And_IceMaps()
        {
            var chatIceMaps = new ObservableCollection<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty),
                new(92, EntityStatus.Active, "curve-2", 24, null, string.Empty)
            };

            var chatMarkets = new ObservableCollection<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1"),
                new(22, EntityStatus.Active, "market-1")
            };

            var mappingController1 = new Mock<IChatShortcutsMappingItemViewModelController>();

            var mapping1 = new ChatShortcutsMappingItemViewModel(mappingController1.Object);

            mappingController1.SetupGet(c => c.ViewModel)
                              .Returns(mapping1);

            var mappingController2 = new Mock<IChatShortcutsMappingItemViewModelController>();

            var mapping2 = new ChatShortcutsMappingItemViewModel(mappingController2.Object);

            mappingController2.SetupGet(c => c.ViewModel)
                              .Returns(mapping2);

            var chatShortcutsController = new Mock<IChatShortcutsItemViewModelController>();

            var chatShortcuts = new ChatShortcutsItemViewModel(chatShortcutsController.Object);

            chatShortcutsController.SetupGet(c => c.ViewModel)
                                   .Returns(chatShortcuts);

            var testObjects = 
                new ChatShortcutsItemViewModelBuilderTestObjectBuilder().WithChatShortcutsViewModelController(chatShortcutsController.Object)
                                                                        .WithMappingViewModelControllers(mappingController1.Object,
                                                                                                         mappingController2.Object)
                                                                        .Build();

            var shortCutVariation1 = new ChatVariableShortcutVariation(91, 51, 21, "curve-1");
            var shortCutVariation2 = new ChatVariableShortcutVariation(92, 51, 22, "curve-2");

            var chatVariableShortcut = new ChatVariableShortcut(51, 
                                                                EntityStatus.Active, 
                                                                "name", 
                                                                "s1;s2", 
                                                                new List<ChatVariableShortcutVariation>
            {
                shortCutVariation1, shortCutVariation2
            });

            // ACT
            var result = testObjects.ChatShortcutsViewModelBuilder.CreateItemFromChatVariableShortcut(chatVariableShortcut, 
                                                                                                      chatIceMaps, 
                                                                                                      chatMarkets);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(51));
            Assert.That(result.Name, Is.EqualTo("name"));
            Assert.AreSame(chatVariableShortcut, result.ChatVariableShortcut());
            Assert.AreSame(chatIceMaps, result.ChatIceMaps());
            Assert.AreSame(chatMarkets, result.ChatMarkets());
            Assert.That(result.SubscribeUpdates, Is.True);

            Assert.That(result.Shortcuts.Count == 2 
                        && result.Shortcuts[0].ToString() == "s1" 
                        && result.Shortcuts[1].ToString() == "s2");

            Assert.That(result.ChatShortcutsMappings.Count, Is.EqualTo(2));

            Assert.AreSame(shortCutVariation1, result.ChatShortcutsMappings[0].Variation());

            Assert.AreSame(chatIceMaps, result.ChatShortcutsMappings[0].ChatIceMaps);
            Assert.AreSame(chatMarkets, result.ChatShortcutsMappings[0].ChatMarkets);

            Assert.That(result.ChatShortcutsMappings[0].IceMap.PriceCurveName, Is.EqualTo("curve-1"));
            Assert.That(result.ChatShortcutsMappings[0].Market.Market, Is.EqualTo("market-1"));

            Assert.That(result.ChatShortcutsMappings[0].SubscribeUpdates, Is.True);
        }

        [Test]
        public void ShouldUpdateChatShortcutsViewModel_From_ChatVariableShortcut()
        {
            var mappingController1 = new Mock<IChatShortcutsMappingItemViewModelController>();

            var mapping1 = new ChatShortcutsMappingItemViewModel(mappingController1.Object);

            mappingController1.SetupGet(c => c.ViewModel)
                              .Returns(mapping1);

            var mappingController2 = new Mock<IChatShortcutsMappingItemViewModelController>();

            var mapping2 = new ChatShortcutsMappingItemViewModel(mappingController2.Object);

            mappingController2.SetupGet(c => c.ViewModel)
                              .Returns(mapping2);

            var chatIceMaps = new ObservableCollection<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty),
                new(92, EntityStatus.Active, "curve-2", 24, null, string.Empty)
            };

            var chatMarkets = new ObservableCollection<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1"),
                new(22, EntityStatus.Active, "market-1")
            };

            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>());

            viewModel.SetChatIceMaps(chatIceMaps);
            viewModel.SetChatMarkets(chatMarkets);

            var testObjects =
                new ChatShortcutsItemViewModelBuilderTestObjectBuilder().WithMappingViewModelControllers(mappingController1.Object,
                                                                                                         mappingController2.Object).Build();

            var shortCutVariation1 = new ChatVariableShortcutVariation(91, 51, 21, "curve-1");
            var shortCutVariation2 = new ChatVariableShortcutVariation(92, 51, 22, "curve-2");

            var chatVariableShortcut = new ChatVariableShortcut(51,
                                                                EntityStatus.Active,
                                                                "name",
                                                                "s1;s2",
                                                                new List<ChatVariableShortcutVariation>
            {
                shortCutVariation1, shortCutVariation2
            });

            // ACT
            testObjects.ChatShortcutsViewModelBuilder.UpdateItemFromChatVariableShortcut(viewModel, chatVariableShortcut);

            // ASSERT
            Assert.That(viewModel.Name, Is.EqualTo("name"));
            Assert.AreSame(chatVariableShortcut, viewModel.ChatVariableShortcut());
      
            Assert.That(viewModel.SubscribeUpdates, Is.True);

            Assert.That(viewModel.Shortcuts.Count == 2
                        && viewModel.Shortcuts[0].ToString() == "s1"
                        && viewModel.Shortcuts[1].ToString() == "s2");

            Assert.That(viewModel.ChatShortcutsMappings.Count, Is.EqualTo(2));

            Assert.AreSame(shortCutVariation1, viewModel.ChatShortcutsMappings[0].Variation());

            Assert.AreSame(chatIceMaps, viewModel.ChatShortcutsMappings[0].ChatIceMaps);
            Assert.AreSame(chatMarkets, viewModel.ChatShortcutsMappings[0].ChatMarkets);

            Assert.That(viewModel.ChatShortcutsMappings[0].IceMap.PriceCurveName, Is.EqualTo("curve-1"));
            Assert.That(viewModel.ChatShortcutsMappings[0].Market.Market, Is.EqualTo("market-1"));

            Assert.That(viewModel.ChatShortcutsMappings[0].SubscribeUpdates, Is.True);
        }

        [Test]
        public void ShouldCreateNewChatShortcutsItem()
        {
            var chatIceMaps = new ObservableCollection<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new ObservableCollection<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var chatShortcutsController = new Mock<IChatShortcutsItemViewModelController>();

            var chatShortcuts = new ChatShortcutsItemViewModel(chatShortcutsController.Object);

            chatShortcutsController.SetupGet(c => c.ViewModel)
                                   .Returns(chatShortcuts);

            var testObjects =
                new ChatShortcutsItemViewModelBuilderTestObjectBuilder().WithChatShortcutsViewModelController(chatShortcutsController.Object)
                                                                        .Build();

            // ACT
            var result = testObjects.ChatShortcutsViewModelBuilder.CreateNewItem(chatIceMaps, 
                                                                                 chatMarkets);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(0));
            Assert.That(result.NewRecord, Is.True);
            Assert.IsNull(result.Name);
            Assert.IsNull(result.Shortcuts);
            Assert.IsNull(result.ChatVariableShortcut());
            Assert.AreSame(chatIceMaps, result.ChatIceMaps());
            Assert.AreSame(chatMarkets, result.ChatMarkets());
            Assert.That(result.SubscribeUpdates, Is.True);
            Assert.That(result.ChatShortcutsMappings != null && result.ChatShortcutsMappings.Count == 0);
        }


        [Test]
        public void ShouldCreateNewChatShortcutsMappingItem()
        {
            var chatIceMaps = new ObservableCollection<ChatIceMap>
            {
                new(91, EntityStatus.Active, "curve-1", 23, null, string.Empty)
            };

            var chatMarkets = new ObservableCollection<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-1")
            };

            var mappingController = new Mock<IChatShortcutsMappingItemViewModelController>();

            var mapping = new ChatShortcutsMappingItemViewModel(mappingController.Object);

            mappingController.SetupGet(c => c.ViewModel)
                             .Returns(mapping);

            var testObjects =
                new ChatShortcutsItemViewModelBuilderTestObjectBuilder().WithMappingViewModelControllers(mappingController.Object)
                                                                        .Build();

            // ACT
            var result = testObjects.ChatShortcutsViewModelBuilder.CreateNewMappingItem(chatIceMaps, chatMarkets);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(0));
            Assert.That(result.NewRecord, Is.True);
            Assert.IsNull(result.Market);
            Assert.IsNull(result.IceMap);
            Assert.That(result.SubscribeUpdates, Is.True);
        }
    }
}
