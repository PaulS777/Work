﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Services
{
    [TestFixture]
    public class ChatVariableShortcutBuilderTests
    {
        [Test]
        public void ShouldGetNewChatVariableShortcut()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                Id = 0,
                Name = "name",
                Shortcuts = new List<object> { "ref-1", "ref-2" },
                NewRecord = true
            };

            viewModel.ChatShortcutsMappings = new ObservableCollection<ChatShortcutsMappingItemViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    IceMap = new ChatIceMap(21, EntityStatus.Active, "curve-1", 51, 101, ""),
                    Market = new ChatMarket(52,EntityStatus.Active, "market")
                }
            };

            var builder = new ChatVariableShortcutBuilder();

            // ACT
            var result = builder.GetNewChatVariableShortcut(viewModel);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(0));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Active));
            Assert.That(result.Name, Is.EqualTo("name"));
            Assert.That(result.Shortcuts, Is.EqualTo("ref-1;ref-2"));

            Assert.That(result.ChatVariableShortcutVariations.Count, Is.EqualTo(1));

            Assert.That(result.ChatVariableShortcutVariations[0].ChatVariableShortcutId == 0
                        && result.ChatVariableShortcutVariations[0].PriceCurveName == "curve-1"
                        && result.ChatVariableShortcutVariations[0].ChatMarketId == 52);
        }

        [Test]
        public void ShouldGetUpdatedChatVariableShortcut()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                Id = 5,
                Name = "name",
                Shortcuts = new List<object> { "ref-1", "ref-2" }
            };

            viewModel.ChatShortcutsMappings = new ObservableCollection<ChatShortcutsMappingItemViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    IceMap = new ChatIceMap(21, EntityStatus.Active, "curve-1", 51, 101, ""),
                    Market = new ChatMarket(52,EntityStatus.Active, "market")
                },
                new(Mock.Of<IDisposable>())
                {
                    IceMap = new ChatIceMap(22, EntityStatus.Active, "curve-2", 61, 102, ""),
                    Market = new ChatMarket(62,EntityStatus.Active, "market-2"),
                    IsDeleted = true
                },
                new(Mock.Of<IDisposable>())
                {
                    IceMap = new ChatIceMap(23, EntityStatus.Active, "curve-3", 71, 103, ""),
                    Market = new ChatMarket(72,EntityStatus.Active, "market-3"),
                    NewRecord = true
                }
            };

            var builder = new ChatVariableShortcutBuilder();

            // ACT
            var result = builder.GetUpdatedChatVariableShortcut(viewModel);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(5));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Active));
            Assert.That(result.Name, Is.EqualTo("name"));
            Assert.That(result.Shortcuts, Is.EqualTo("ref-1;ref-2"));

            Assert.That(result.ChatVariableShortcutVariations.Count, Is.EqualTo(2));

            Assert.That(result.ChatVariableShortcutVariations[0].ChatVariableShortcutId == 5
                        && result.ChatVariableShortcutVariations[0].PriceCurveName == "curve-1"
                        && result.ChatVariableShortcutVariations[0].ChatMarketId == 52);

            Assert.That(result.ChatVariableShortcutVariations[1].ChatVariableShortcutId == 5
                        && result.ChatVariableShortcutVariations[1].PriceCurveName == "curve-3"
                        && result.ChatVariableShortcutVariations[1].ChatMarketId == 72);
        }

        [Test]
        public void ShouldGetDeletedChatVariableShortcut()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                Id = 5,
                Name = "name-2",
                Shortcuts = new List<object> { "ref-1" },
                IsDeleted = true
            };

            viewModel.ChatShortcutsMappings = new ObservableCollection<ChatShortcutsMappingItemViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    IceMap = new ChatIceMap(21, EntityStatus.Active, "curve-1", 51, 101, ""),
                    Market = new ChatMarket(52, EntityStatus.Active, "market")
                },
                new(Mock.Of<IDisposable>())
                {
                    IceMap = new ChatIceMap(23, EntityStatus.Active, "curve-3", 71, 103, ""),
                    Market = new ChatMarket(72, EntityStatus.Active, "market-3"),
                    NewRecord = true
                }
            };

            var chatVariableShortcut = new ChatVariableShortcut(5, EntityStatus.Active, "name", "ref-1;ref-2",
                                                                new List<ChatVariableShortcutVariation>
                                                                {
                                                                    new(0, 5, 52, "curve-1")
                                                                });
            
            viewModel.SetChatVariableShortcut(chatVariableShortcut);

            var builder = new ChatVariableShortcutBuilder();

            // ACT
            var result = builder.GetDeletedChatVariableShortcut(viewModel);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(5));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Deleted));
            Assert.That(result.Name, Is.EqualTo("name"));
            Assert.That(result.Shortcuts, Is.EqualTo("ref-1;ref-2"));

            Assert.That(result.ChatVariableShortcutVariations.Count, Is.EqualTo(1));
        }
    }
}
