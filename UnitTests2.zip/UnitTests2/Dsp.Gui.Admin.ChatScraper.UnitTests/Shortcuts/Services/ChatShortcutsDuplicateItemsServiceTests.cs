﻿using System;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Services
{
    [TestFixture]
    public class ChatShortcutsDuplicateItemsServiceTests
    {
        [Test]
        public void ShouldSetIsDuplicateTrue_When_DuplicateName()
        {
            var chatShortcuts1 = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                Name = "name"
            };

            var chatShortcuts2 = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                Name = "name-2"
            };

            var chatShortcuts = new[] { chatShortcuts1, chatShortcuts2 };

            var service = new ChatShortcutsDuplicateItemsService();

            service.RefreshItems(chatShortcuts);

            // ACT
            chatShortcuts2.Name = "name";

            // ASSERT
            Assert.That(chatShortcuts1.IsDuplicate, Is.True);
            Assert.That(chatShortcuts2.IsDuplicate, Is.True);
        }
    }
}
