﻿using System;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Services.Mappings   
{
    internal interface IChatShortcutsMappingItemChangedObserverTestObjects
    {
        ChatShortcutsMappingItemViewModel ChatShortcutsItem { get; }
        ChatShortcutsMappingItemChangedObserver ChatShortcutsItemChangedObserver { get; }
    }

    [TestFixture]
    public class ChatShortcutsMappingItemChangedObserverTests
    {
        private class ChatShortcutsMappingItemChangedObserverTestObjectBuilder
        {
            private ChatVariableShortcutVariation _variation;
            private ChatMarket _chatMarket;
            private ChatIceMap _chatIceMap;
            private ObservableCollection<ChatMarket> _chatMarkets;

            public ChatShortcutsMappingItemChangedObserverTestObjectBuilder WithVariation(ChatVariableShortcutVariation value)
            {
                _variation = value;
                return this;
            }

            public ChatShortcutsMappingItemChangedObserverTestObjectBuilder WithChatMarket(ChatMarket value)
            {
                _chatMarket = value;
                return this;
            }

            public ChatShortcutsMappingItemChangedObserverTestObjectBuilder WithChatIceMap(ChatIceMap value)
            {
                _chatIceMap = value;
                return this;
            }

            public ChatShortcutsMappingItemChangedObserverTestObjectBuilder WithChatMarkets(ObservableCollection<ChatMarket> values)
            {
                _chatMarkets = values;
                return this;
            }

            public IChatShortcutsMappingItemChangedObserverTestObjects Build()
            {
                var testObjects = new Mock<IChatShortcutsMappingItemChangedObserverTestObjects>();

                var viewModel = new ChatShortcutsMappingItemViewModel(Mock.Of<IDisposable>())
                {
                    Market = _chatMarket,
                    IceMap = _chatIceMap,
                    ChatMarkets = _chatMarkets
                };

                viewModel.SetVariation(_variation);

                testObjects.SetupGet(o => o.ChatShortcutsItem)
                           .Returns(viewModel);

                var rowChangedObserver = new ChatShortcutsMappingItemChangedObserver();

                testObjects.SetupGet(o => o.ChatShortcutsItemChangedObserver)
                           .Returns(rowChangedObserver);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetDefaultMarket_When_IceMapChanged()
        {
            var iceMap = new ChatIceMap(92, EntityStatus.Active, "curve-1", 22, null, string.Empty);

            var market1 = new ChatMarket(21, EntityStatus.Active, "market-1");
            var market2 = new ChatMarket(22, EntityStatus.Active, "market-1");
            
            var markets = new ObservableCollection<ChatMarket>
            {
                market1, market2
            };

            var testObjects = new ChatShortcutsMappingItemChangedObserverTestObjectBuilder().WithChatMarkets(markets)
                                                                                            .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ChatShortcutsItem);

            // ACT
            testObjects.ChatShortcutsItem.IceMap = iceMap;

            // ASSERT
            Assert.AreSame(market2, testObjects.ChatShortcutsItem.Market);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_IceMapChanged()
        {
            var iceMap1 = new ChatIceMap(92, EntityStatus.Active, "curve-1", 21, null, string.Empty);
            var iceMap2 = new ChatIceMap(93, EntityStatus.Active, "curve-2", 21, null, string.Empty);

            var market1 = new ChatMarket(21, EntityStatus.Active, "market-1");

            var markets = new ObservableCollection<ChatMarket>
            {
                market1
            };

            var variation = new ChatVariableShortcutVariation(21, 99, market1.Id, iceMap1.PriceCurveName);

            var testObjects = new ChatShortcutsMappingItemChangedObserverTestObjectBuilder().WithVariation(variation)
                                                                                            .WithChatIceMap(iceMap1)
                                                                                            .WithChatMarket(market1)
                                                                                            .WithChatMarkets(markets)
                                                                                            .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ChatShortcutsItem);

            // ACT
            testObjects.ChatShortcutsItem.IceMap = iceMap2;

            // ASSERT
            Assert.That(testObjects.ChatShortcutsItem.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_IceMapChangeReverted()
        {
            var iceMap1 = new ChatIceMap(92, EntityStatus.Active, "curve-1", 21, null, string.Empty);
            var iceMap2 = new ChatIceMap(93, EntityStatus.Active, "curve-2", 21, null, string.Empty);

            var market1 = new ChatMarket(21, EntityStatus.Active, "market-1");

            var markets = new ObservableCollection<ChatMarket>
            {
                market1
            };

            var variation = new ChatVariableShortcutVariation(21, 99, market1.Id, iceMap1.PriceCurveName);

            var testObjects = new ChatShortcutsMappingItemChangedObserverTestObjectBuilder().WithVariation(variation)
                                                                                            .WithChatIceMap(iceMap1)
                                                                                            .WithChatMarket(market1)
                                                                                            .WithChatMarkets(markets)
                                                                                            .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ChatShortcutsItem);

            testObjects.ChatShortcutsItem.IceMap = iceMap2;

            // ACT
            testObjects.ChatShortcutsItem.IceMap = iceMap1;

            // ASSERT
            Assert.That(testObjects.ChatShortcutsItem.IsDirty, Is.False);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_MarketChanged()
        {
            var iceMap = new ChatIceMap(92, EntityStatus.Active, "curve-1", 21, null, string.Empty);

            var market1 = new ChatMarket(21, EntityStatus.Active, "market-1");
            var market2 = new ChatMarket(22, EntityStatus.Active, "market-1");

            var markets = new ObservableCollection<ChatMarket>
            {
                market1, market2
            };

            var variation = new ChatVariableShortcutVariation(21, 99, market1.Id, iceMap.PriceCurveName);

            var testObjects = new ChatShortcutsMappingItemChangedObserverTestObjectBuilder().WithVariation(variation)
                                                                                            .WithChatMarket(market1)
                                                                                            .WithChatIceMap(iceMap)
                                                                                            .WithChatMarkets(markets)
                                                                                            .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ChatShortcutsItem);

            // ACT
            testObjects.ChatShortcutsItem.Market = market2;

            // ASSERT
            Assert.That(testObjects.ChatShortcutsItem.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_MarketChangeReverted()
        {
            var iceMap = new ChatIceMap(92, EntityStatus.Active, "curve-1", 21, null, string.Empty);

            var market1 = new ChatMarket(21, EntityStatus.Active, "market-1");
            var market2 = new ChatMarket(22, EntityStatus.Active, "market-1");

            var markets = new ObservableCollection<ChatMarket>
            {
                market1, market2
            };

            var variation = new ChatVariableShortcutVariation(21, 99, market1.Id, iceMap.PriceCurveName);

            var testObjects = new ChatShortcutsMappingItemChangedObserverTestObjectBuilder().WithVariation(variation)
                                                                                            .WithChatMarket(market1)
                                                                                            .WithChatIceMap(iceMap)
                                                                                            .WithChatMarkets(markets)
                                                                                            .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ChatShortcutsItem);

            testObjects.ChatShortcutsItem.Market = market2;

            // ACT
            testObjects.ChatShortcutsItem.Market = market1;

            // ASSERT
            Assert.That(testObjects.ChatShortcutsItem.IsDirty, Is.False);
        }


        [Test]
        public void ShouldNotSetIsDirtyTrue_When_UnSubscribe()
        {
            var iceMap = new ChatIceMap(92, EntityStatus.Active, "curve-1", 21, null, string.Empty);

            var market1 = new ChatMarket(21, EntityStatus.Active, "market-1");
            var market2 = new ChatMarket(22, EntityStatus.Active, "market-1");

            var markets = new ObservableCollection<ChatMarket>
            {
                market1, market2
            };


            var variation = new ChatVariableShortcutVariation(21, 99, market1.Id, iceMap.PriceCurveName);

            var testObjects = new ChatShortcutsMappingItemChangedObserverTestObjectBuilder().WithVariation(variation)
                                                                                            .WithChatMarket(market1)
                                                                                            .WithChatIceMap(iceMap)
                                                                                            .WithChatMarkets(markets)
                                                                                            .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ChatShortcutsItem);

            testObjects.ChatShortcutsItemChangedObserver.UnSubscribe();

            // ACT
            testObjects.ChatShortcutsItem.Market = market2;

            // ASSERT
            Assert.That(testObjects.ChatShortcutsItem.IsDirty, Is.False);
        }

        [Test]
        public void ShouldNotSetIsDirtyTrue_When_Disposed()
        {
            var iceMap = new ChatIceMap(92, EntityStatus.Active, "curve-1", 21, null, string.Empty);

            var market1 = new ChatMarket(21, EntityStatus.Active, "market-1");
            var market2 = new ChatMarket(22, EntityStatus.Active, "market-1");

            var markets = new ObservableCollection<ChatMarket>
            {
                market1, market2
            };

            var variation = new ChatVariableShortcutVariation(21, 99, market1.Id, iceMap.PriceCurveName);

            var testObjects = new ChatShortcutsMappingItemChangedObserverTestObjectBuilder().WithVariation(variation)
                                                                                            .WithChatMarket(market1)
                                                                                            .WithChatIceMap(iceMap)
                                                                                            .WithChatMarkets(markets)
                                                                                            .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ChatShortcutsItem);

            testObjects.ChatShortcutsItemChangedObserver.Dispose();

            // ACT
            testObjects.ChatShortcutsItem.Market = market2;

            // ASSERT
            Assert.That(testObjects.ChatShortcutsItem.IsDirty, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var iceMap = new ChatIceMap(92, EntityStatus.Active, "curve-1", 21, null, string.Empty);

            var market1 = new ChatMarket(21, EntityStatus.Active, "market-1");
            var market2 = new ChatMarket(22, EntityStatus.Active, "market-1");

            var markets = new ObservableCollection<ChatMarket>
            {
                market1, market2
            };

            var variation = new ChatVariableShortcutVariation(21, 99, market1.Id, iceMap.PriceCurveName);

            var testObjects = new ChatShortcutsMappingItemChangedObserverTestObjectBuilder().WithVariation(variation)
                                                                                            .WithChatMarket(market1)
                                                                                            .WithChatIceMap(iceMap)
                                                                                            .WithChatMarkets(markets)
                                                                                            .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ChatShortcutsItem);

            testObjects.ChatShortcutsItemChangedObserver.Dispose();

            // ACT
            testObjects.ChatShortcutsItem.Market = market2;

            // ASSERT
            testObjects.ChatShortcutsItemChangedObserver.Dispose();
            Assert.That(testObjects.ChatShortcutsItem.IsDirty, Is.False);
        }
    }
}
