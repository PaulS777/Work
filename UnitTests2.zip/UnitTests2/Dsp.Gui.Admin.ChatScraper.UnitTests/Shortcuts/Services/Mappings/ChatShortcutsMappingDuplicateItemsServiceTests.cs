﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Services.Mappings
{
    [TestFixture]
    public class ChatShortcutsMappingDuplicateItemsServiceTests
    {
        [Test]
        public void ShouldSetIsDuplicateTrue_When_DuplicateMarket()
        {
            var market1 = new ChatMarket(51, EntityStatus.Active, "market-1");
            var market2 = new ChatMarket(52, EntityStatus.Active, "market-2");

            var chatShortcutsItem1 = new ChatShortcutsMappingItemViewModel(Mock.Of<IDisposable>())
            {
                Market = market1
            };


            var chatShortcutsItem2 = new ChatShortcutsMappingItemViewModel(Mock.Of<IDisposable>())
            {
                Market = market2
            };

            var chatShortcutItems = new[] { chatShortcutsItem1, chatShortcutsItem2 };

            var service = new ChatShortcutsMappingDuplicateItemsService();

            service.RefreshItems(chatShortcutItems);

            // ACT
            chatShortcutsItem2.Market = market1;

            // ASSERT
            Assert.That(chatShortcutsItem1.IsDuplicate, Is.True);
            Assert.That(chatShortcutsItem2.IsDuplicate, Is.True);
        }
    }
}
