﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Services
{
    internal interface IChatShortcutsItemChangedObserverTestObjects
    {
        ChatShortcutsItemViewModel ViewModel { get; }
        ChatShortcutsItemChangedObserver ChatShortcutsItemChangedObserver { get; }
    }

    [TestFixture]
    public class ChatShortcutsItemChangedObserverTests
    {
        private class ChatShortcutsItemChangedObserverTestObjectBuilder
        {
            private ChatVariableShortcut _chatVariableShortcut;
            private string _name;
            private List<object> _shortcuts;
            private bool _chatShortcutsMappingsChanged;
            private bool _compareShortcuts;
            private bool _isDuplicate;

            public ChatShortcutsItemChangedObserverTestObjectBuilder WithChatVariableShortcut(ChatVariableShortcut value)
            {
                _chatVariableShortcut = value;
                return this;
            }

            public ChatShortcutsItemChangedObserverTestObjectBuilder WithName(string value)
            {
                _name = value;
                return this;
            }

            public ChatShortcutsItemChangedObserverTestObjectBuilder WithShortcuts(List<object> value)
            {
                _shortcuts = value;
                return this;
            }

            public ChatShortcutsItemChangedObserverTestObjectBuilder WithIsDuplicate(bool value)
            {
                _isDuplicate = value;
                return this;
            }

            public ChatShortcutsItemChangedObserverTestObjectBuilder WithChatShortcutsMappingsChanged(bool value)
            {
                _chatShortcutsMappingsChanged = value;
                return this;
            }

            public ChatShortcutsItemChangedObserverTestObjectBuilder WithCompareShortcuts(bool value)
            {
                _compareShortcuts = value;
                return this;
            }

            public IChatShortcutsItemChangedObserverTestObjects Build()
            {
                var testObjects = new Mock<IChatShortcutsItemChangedObserverTestObjects>();

                var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
                {
                    Name = _name,
                    Shortcuts = _shortcuts,
                    IsDuplicate = _isDuplicate,
                    ChatShortcutsMappingsChanged = _chatShortcutsMappingsChanged
                };

                viewModel.SetChatVariableShortcut(_chatVariableShortcut);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(viewModel);

                var comparer = new Mock<IChatShortcutsComparer>();

                comparer.Setup(c => c.CompareShortcuts(It.IsAny<IEnumerable<object>>(), It.IsAny<string>()))
                        .Returns(_compareShortcuts);

                var chatShortcutsItemChangedObserver = new ChatShortcutsItemChangedObserver(comparer.Object);

                testObjects.SetupGet(o => o.ChatShortcutsItemChangedObserver)
                           .Returns(chatShortcutsItemChangedObserver);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetNameIsValidFalse_When_NameEmpty()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.Name = "";

            // ASSERT
            Assert.That(testObjects.ViewModel.NameIsValid, Is.False);
        }

        [Test]
        public void ShouldSetNameIsValidTrue_When_NameNotEmpty()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.Name = "name";

            // ASSERT
            Assert.That(testObjects.ViewModel.NameIsValid, Is.True);
        }

        [Test]
        public void ShouldSetShortcutsValidFalse_When_ShortcutsEmpty()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", "ref", new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>{"ref"})
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.Shortcuts = new List<object>();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShortcutsValid, Is.False);
            Assert.That(testObjects.ViewModel.ShortcutsValidText, Is.EqualTo("Missing Shortcuts"));
        }

        [Test]
        public void ShouldSetShortcutsValidTrue_When_ShortcutsNotEmpty()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", "", new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.Shortcuts = new List<object>{"ref"};

            // ASSERT
            Assert.That(testObjects.ViewModel.ShortcutsValid, Is.True);
        }

        [Test]
        public void ShouldSetShortcutsValidFalse_When_IsDuplicateShortcut()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", "ref", new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object> { "ref" })
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.IsDuplicateShortcut = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShortcutsValid, Is.False);
            Assert.That(testObjects.ViewModel.ShortcutsValidText, Is.EqualTo("Duplicate Shortcut"));
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_NameChanged()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.Name = "changed";

            // ASSERT
            Assert.That(testObjects.ViewModel.NameChanged, Is.True);
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_NameChangeReverted()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            testObjects.ViewModel.Name = "changed";

            // ACT
            testObjects.ViewModel.Name = "name";

            // ASSERT
            Assert.That(testObjects.ViewModel.NameChanged, Is.False);
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_ShortcutsChanged()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", "s1", new List<ChatVariableShortcutVariation>());

            var shortcuts = new List<object> { "s1" };

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(shortcuts)
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(false)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.Shortcuts = new List<object> { "s2" };

            // ASSERT
            Assert.That(testObjects.ViewModel.ShortcutsChanged, Is.True);
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_ShortcutsChangeReverted()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", "s1", new List<ChatVariableShortcutVariation>());

            var shortcuts = new List<object> { "s2" };

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(shortcuts)
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.Shortcuts = new List<object> { "s1" };

            // ASSERT
            Assert.That(testObjects.ViewModel.ShortcutsChanged, Is.False);
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_ChatShortcutMappingsChanged()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.ChatShortcutsMappingsChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_ChatShortcutMappingsChangedFalse()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(true)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.ChatShortcutsMappingsChanged = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldSetIsNameIsValidAndNotDuplicateTrue_When_NameIsValid_And_IsDuplicateFalse()
        {
            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            // ACT
            testObjects.ViewModel.Name = "name";
            testObjects.ViewModel.IsDuplicate = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.NameIsValidAndNotDuplicate, Is.True);
            Assert.IsNull(testObjects.ViewModel.NameValidationText);
        }

        [Test]
        public void ShouldSetIsNameIsValidAndNotDuplicateTextFalse_When_NameIsNotValid()
        {
            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithName("name")
                                                                                     .WithIsDuplicate(false)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);


            // ACT
            testObjects.ViewModel.Name = "";
            
            // ASSERT
            Assert.That(testObjects.ViewModel.NameIsValidAndNotDuplicate, Is.False);
            Assert.That(testObjects.ViewModel.NameValidationText, Is.EqualTo("Missing Name"));
        }

        [Test]
        public void ShouldSetIsNameIsValidAndNotDuplicateTextFalse_When_IsDuplicate()
        {
            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithName("name")
                                                                                     .WithIsDuplicate(false)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);


            // ACT
            testObjects.ViewModel.IsDuplicate = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.NameIsValidAndNotDuplicate, Is.False);
            Assert.That(testObjects.ViewModel.NameValidationText, Is.EqualTo("Duplicate Name"));
        }

        [Test]
        public void ShouldNotSetIsDirty_When_UnSubscribe()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            testObjects.ChatShortcutsItemChangedObserver.UnSubscribe();

            // ACT
            testObjects.ViewModel.Name = "changed";

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldNotSetIsDirty_When_Dispose()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            testObjects.ChatShortcutsItemChangedObserver.Dispose();

            // ACT
            testObjects.ViewModel.Name = "changed";

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Dispose()
        {
            var chatVariableShortcut = new ChatVariableShortcut(21, EntityStatus.Active, "name", string.Empty, new List<ChatVariableShortcutVariation>());

            var testObjects = new ChatShortcutsItemChangedObserverTestObjectBuilder().WithChatVariableShortcut(chatVariableShortcut)
                                                                                     .WithName("name")
                                                                                     .WithShortcuts(new List<object>())
                                                                                     .WithChatShortcutsMappingsChanged(false)
                                                                                     .WithCompareShortcuts(true)
                                                                                     .Build();

            testObjects.ChatShortcutsItemChangedObserver.SubscribeUpdates(testObjects.ViewModel);

            testObjects.ChatShortcutsItemChangedObserver.Dispose();

            // ACT
            testObjects.ChatShortcutsItemChangedObserver.Dispose();
            testObjects.ViewModel.Name = "changed";

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

    }
}
