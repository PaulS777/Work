﻿using System;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Shortcuts.Services
{
    internal interface IChatShortcutsValidationServiceTestObjects
    {
        ChatShortcutsItemValidationService ChatShortcutsValidationService { get; }
    } 

    [TestFixture]
    public class ChatShortcutsItemValidationServiceTests
    {
        private class ChatShortcutsValidationServiceTestObjectBuilder
        {
            public IChatShortcutsValidationServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatShortcutsValidationServiceTestObjects>();

                var validationService = new ChatShortcutsItemValidationService(new ChatShortcutsNameRule(),
                                                                               new ChatShortcutsShortcutsRule(),
                                                                               new ChatShortcutsMappingsValidRule());

                testObjects.SetupGet(o => o.ChatShortcutsValidationService)
                           .Returns(validationService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetIsValidTrue_When_Attach_With_ValidChatShortcutsViewModel()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                NameIsValid = true,
                ShortcutsValid = true,
                ChatShortcutsMappingsValid = true
            };

            var testObjects = new ChatShortcutsValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatShortcutsValidationService.Attach(viewModel);

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_NameInvalid()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                NameIsValid = true,
                ShortcutsValid = true,
                ChatShortcutsMappingsValid = true
            };

            var testObjects = new ChatShortcutsValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatShortcutsValidationService.Attach(viewModel);

            // ACT
            viewModel.NameIsValid = false;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText != null && viewModel.ErrorText == "Missing Name");
        }

        [Test]
        public void ShouldSetIsValidTrue_When_NameValid()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                NameIsValid = false,
                ShortcutsValid = true,
                ChatShortcutsMappingsValid = true
            };

            var testObjects = new ChatShortcutsValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatShortcutsValidationService.Attach(viewModel);

            // ACT
            viewModel.NameIsValid = true;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
            Assert.IsNull(viewModel.ErrorText);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_ShortcutsInvalid()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                NameIsValid = true,
                ShortcutsValid = true,
                ChatShortcutsMappingsValid = true
            };

            var testObjects = new ChatShortcutsValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatShortcutsValidationService.Attach(viewModel);

            // ACT
            viewModel.ShortcutsValid = false;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText != null && viewModel.ErrorText == "Missing Shortcuts");
        }

        [Test]
        public void ShouldSetIsValidTrue_When_ShortcutsValid()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                NameIsValid = true,
                ShortcutsValid = false,
                ChatShortcutsMappingsValid = true
            };

            var testObjects = new ChatShortcutsValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatShortcutsValidationService.Attach(viewModel);

            // ACT
            viewModel.ShortcutsValid = true;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
            Assert.IsNull(viewModel.ErrorText);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_ChatShortcutsItemsValid_False()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                NameIsValid = true,
                ShortcutsValid = true,
                ChatShortcutsMappingsValid = true
            };

            var testObjects = new ChatShortcutsValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatShortcutsValidationService.Attach(viewModel);

            // ACT
            viewModel.ChatShortcutsMappingsValid = false;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText != null && viewModel.ErrorText == "Invalid Variations");
        }

        [Test]
        public void ShouldSetIsValidTrue_When_ChatShortcutsRowsValid()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                NameIsValid = true,
                ShortcutsValid = true,
                ChatShortcutsMappingsValid = false
            };

            var testObjects = new ChatShortcutsValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatShortcutsValidationService.Attach(viewModel);

            // ACT
            viewModel.ChatShortcutsMappingsValid = true;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
            Assert.IsNull(viewModel.ErrorText);
        }

        [Test]
        public void ShouldReturnIsDuplicateText_When_IsDuplicate()
        {
            var viewModel = new ChatShortcutsItemViewModel(Mock.Of<IDisposable>())
            {
                NameIsValid = true,
                ShortcutsValid = true,
                ChatShortcutsMappingsValid = true
            };

            var testObjects = new ChatShortcutsValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatShortcutsValidationService.Attach(viewModel);

            // ACT
            viewModel.IsDuplicate = true;
            var result = testObjects.ChatShortcutsValidationService.IsDuplicateText();

            // ASSERT
            Assert.That(result, Is.EqualTo("Duplicate Chat Shortcuts Name"));
        }
    }
}
