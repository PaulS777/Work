﻿using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Market.Services
{
    [TestFixture]
    public class ChatMarketItemConflictServiceTests
    {
        [Test]
        public void ShouldConstructChatMarketItemConflictService()
        {
            var dialogService = new Mock<IChatBrokerAdminMessageDialogService>();

            // ACT
            var chatMarketConflictService = new ChatMarketItemsConflictService(dialogService.Object);

            // ASSERT
            Assert.IsNotNull(chatMarketConflictService);
        }
    }
}
