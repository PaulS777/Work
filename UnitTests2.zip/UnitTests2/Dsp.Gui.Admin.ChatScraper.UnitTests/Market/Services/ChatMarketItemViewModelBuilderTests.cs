﻿using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Market.Controllers;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Market.Services
{
    internal interface IChatMarketItemViewModelBuilderTestObjects
    {
        IChatMarketItemViewModelController ChatMarketRowViewModelController { get; }
        ChatMarketItemViewModelBuilder ChatMarketItemViewModelBuilder { get; }
    }

    [TestFixture]
    public class ChatMarketItemViewModelBuilderTests
    {
        private class ChatMarketItemViewModelBuilderTestObjectBuilder
        {
            public IChatMarketItemViewModelBuilderTestObjects Build()
            {
                var testObjects = new Mock<IChatMarketItemViewModelBuilderTestObjects>();

                var controller = new Mock<IChatMarketItemViewModelController>();

                var viewModel = new ChatMarketItemViewModel(controller.Object);

                controller.SetupGet(c => c.ViewModel)
                          .Returns(viewModel);

                testObjects.SetupGet(o => o.ChatMarketRowViewModelController)
                           .Returns(controller.Object);

                var factory = new Mock<IServiceFactory<IChatMarketItemViewModelController>>();

                factory.Setup(f => f.Create())
                       .Returns(controller.Object);

                var builder = new ChatMarketItemViewModelBuilder
                              {
                                  Factory = factory.Object
                              };

                testObjects.SetupGet(o => o.ChatMarketItemViewModelBuilder)
                           .Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCreateNewItem_WithNewRecordTrue()
        {
            var testObjects = new ChatMarketItemViewModelBuilderTestObjectBuilder().Build();

            // ACT
            var viewModel = testObjects.ChatMarketItemViewModelBuilder.CreateNewItem();

            // ASSERT
            Assert.That(viewModel.NewRecord, Is.True);
        }

        [Test]
        public void ShouldCreateChatMarketItemViewModel_From_ChatMarket()
        {
            var chatMarket = new ChatMarket(10, EntityStatus.Active, "market");

            var testObjects = new ChatMarketItemViewModelBuilderTestObjectBuilder().Build();

            // ACT
            var viewModel = testObjects.ChatMarketItemViewModelBuilder.CreateItemFromChatMarket(chatMarket);

            // ASSERT
            Assert.That(viewModel.Id, Is.EqualTo(10));
            Assert.That(viewModel.Name, Is.EqualTo("market"));
            Assert.AreSame(chatMarket, viewModel.GetChatMarket());
            Assert.That(viewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldUpdateChatMarketItemViewModel_From_ChatMarket()
        {
            var chatMarket = new ChatMarket(10, EntityStatus.Active, "market");
            var update = new ChatMarket(10, EntityStatus.Active, "update");

            var testObjects = new ChatMarketItemViewModelBuilderTestObjectBuilder().Build();

            var item = testObjects.ChatMarketItemViewModelBuilder.CreateItemFromChatMarket(chatMarket);

            // ACT
            testObjects.ChatMarketItemViewModelBuilder.UpdateItemFromChatMarket(item, update);

            // ASSERT
            Assert.That(item.Name, Is.EqualTo("update"));
            Assert.That(item.IsDirty, Is.False);
        }

        [Test]
        public void ShouldUpdateNewChatMarketItemViewModel_From_ChatMarket()
        {
            var update = new ChatMarket(10, EntityStatus.Active, "update");

            var testObjects = new ChatMarketItemViewModelBuilderTestObjectBuilder().Build();

            var item = testObjects.ChatMarketItemViewModelBuilder.CreateNewItem();

            // ACT
            testObjects.ChatMarketItemViewModelBuilder.UpdateItemFromChatMarket(item, update);

            // ASSERT
            Assert.That(item.Name, Is.EqualTo("update"));
            Assert.That(item.NewRecord, Is.False);
            Assert.That(item.IsDirty, Is.False);
        }
    }
}
