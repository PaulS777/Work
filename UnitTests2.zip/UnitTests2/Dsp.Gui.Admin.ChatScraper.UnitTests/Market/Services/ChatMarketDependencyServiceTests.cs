﻿using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Market.Services
{
    internal interface IChatMarketDependencyServiceTestObjects
    {
        ISubject<List<ChatUser>> ChatUsers { get; }
        ChatMarketDependencyService ChatMarketDependencyService { get; }
    }

    [TestFixture]
    public class ChatMarketDependencyServiceTests
    {
        private class ChatMarketDependencyServiceTestObjectBuilder
        {
            private IList<ChatUser> _chatUsers;
            private List<ChatIceMap> _chatIceMaps;
            private List<ChatVariableShortcut> _chatVariableShortcuts;

            public ChatMarketDependencyServiceTestObjectBuilder WithChatUsers(IList<ChatUser> values)
            {
                _chatUsers = values;
                return this;
            }

            public ChatMarketDependencyServiceTestObjectBuilder WithChatShortcuts(List<ChatVariableShortcut> values)
            {
                _chatVariableShortcuts = values;
                return this;
            }

            public ChatMarketDependencyServiceTestObjectBuilder WithChatIceMaps(List<ChatIceMap> values)
            {
                _chatIceMaps = values;
                return this;
            }

            public IChatMarketDependencyServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatMarketDependencyServiceTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ChatUsers).Returns(Observable.Return(_chatUsers));
                curveControlService.SetupGet(c => c.ChatVariableShortcuts).Returns(Observable.Return(_chatVariableShortcuts));
                curveControlService.SetupGet(c => c.ChatIceMaps).Returns(Observable.Return(_chatIceMaps));

                var chatMarketDependencyService = new ChatMarketDependencyService(curveControlService.Object);

                testObjects.SetupGet(o => o.ChatMarketDependencyService).Returns(chatMarketDependencyService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishFalse_When_MarketHasNoDependents()
        {
            var userId = 10;
            var marketId = 1;
            var otherMarketId = 2;

            var chatMarkets = new List<ChatUserMarket>
            {
                new(101, userId, otherMarketId)
            };

            var chatUsers = new List<ChatUser>
            {
                new(userId, EntityStatus.Active, "user", chatMarkets, new List<ChatUserReference>())
            };

            var variations = new List<ChatVariableShortcutVariation>
            {
                new(201, 202, otherMarketId, "ice")
            };

            var chatShortcuts = new List<ChatVariableShortcut>
            {
                new(201, EntityStatus.Active, "name", "shortcuts", variations)
            };

            var chatIceMaps = new List<ChatIceMap>
            {
                new(301, EntityStatus.Active,"code", otherMarketId, 101, "")
            };

            var testObjects = new ChatMarketDependencyServiceTestObjectBuilder().WithChatUsers(chatUsers)
                                                                                .WithChatShortcuts(chatShortcuts)
                                                                                .WithChatIceMaps(chatIceMaps)
                                                                                .Build();

            var dependents = testObjects.ChatMarketDependencyService.HasDependents(marketId);

            bool? result = null;

            // ACT
            using (dependents.Subscribe(r => result = r))
            {
                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_User_HasDependency()
        {
            var userId = 10;
            var marketId = 1;
            var otherMarketId = 2;

            var chatMarkets = new List<ChatUserMarket>
            {
                new(101, userId, marketId)
            };

            var chatUsers = new List<ChatUser>
            {
                new(userId, EntityStatus.Active, "user", chatMarkets, new List<ChatUserReference>())
            };

            var variations = new List<ChatVariableShortcutVariation>
            {
                new(201, 202, otherMarketId, "ice")
            };

            var chatShortcuts = new List<ChatVariableShortcut>
            {
                new(201, EntityStatus.Active, "name", "shortcuts", variations)
            };

            var chatIceMaps = new List<ChatIceMap>
            {
                new(301, EntityStatus.Active,"code", otherMarketId, 101, "")
            };

            var testObjects = new ChatMarketDependencyServiceTestObjectBuilder().WithChatUsers(chatUsers)
                                                                                .WithChatShortcuts(chatShortcuts)
                                                                                .WithChatIceMaps(chatIceMaps)
                                                                                .Build();

            var dependents = testObjects.ChatMarketDependencyService.HasDependents(marketId);

            bool? result = null;

            // ACT
            using (dependents.Subscribe(r => result = r))
            {
                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_Shortcuts_HasDependency()
        {
            var userId = 10;
            var marketId = 1;
            var otherMarketId = 2;

            var chatMarkets = new List<ChatUserMarket>
            {
                new(101, userId, otherMarketId)
            };

            var chatUsers = new List<ChatUser>
            {
                new(userId, EntityStatus.Active, "user", chatMarkets, new List<ChatUserReference>())
            };

            var variations = new List<ChatVariableShortcutVariation>
            {
                new(201, 202, marketId, "ice")
            };

            var chatShortcuts = new List<ChatVariableShortcut>
            {
                new(201, EntityStatus.Active, "name", "shortcuts", variations)
            };

            var chatIceMaps = new List<ChatIceMap>
            {
                new(301, EntityStatus.Active,"code", otherMarketId, 101, "")
            };

            var testObjects = new ChatMarketDependencyServiceTestObjectBuilder().WithChatUsers(chatUsers)
                                                                                .WithChatShortcuts(chatShortcuts)
                                                                                .WithChatIceMaps(chatIceMaps)
                                                                                .Build();

            var dependents = testObjects.ChatMarketDependencyService.HasDependents(marketId);

            bool? result = null;

            // ACT
            using (dependents.Subscribe(r => result = r))
            {
                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_IceMaps_HasDependency()
        {
            var userId = 10;
            var marketId = 1;
            var otherMarketId = 2;

            var chatMarkets = new List<ChatUserMarket>
            {
                new(101, userId, otherMarketId)
            };

            var chatUsers = new List<ChatUser>
            {
                new(userId, EntityStatus.Active, "user", chatMarkets, new List<ChatUserReference>())
            };

            var variations = new List<ChatVariableShortcutVariation>
            {
                new(201, 202, otherMarketId, "ice")
            };

            var chatShortcuts = new List<ChatVariableShortcut>
            {
                new(201, EntityStatus.Active, "name", "shortcuts", variations)
            };

            var chatIceMaps = new List<ChatIceMap>
            {
                new(301, EntityStatus.Active,"code", marketId, 101, "")
            };

            var testObjects = new ChatMarketDependencyServiceTestObjectBuilder().WithChatUsers(chatUsers)
                                                                                .WithChatShortcuts(chatShortcuts)
                                                                                .WithChatIceMaps(chatIceMaps)
                                                                                .Build();

            var dependents = testObjects.ChatMarketDependencyService.HasDependents(marketId);

            bool? result = null;

            // ACT
            using (dependents.Subscribe(r => result = r))
            {
                // ASSERT
                Assert.That(result, Is.True);
            }
        }
    }
}
