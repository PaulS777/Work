﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Market.Services
{
    [TestFixture]
    public class ChatMarketDuplicateItemsServiceTests
    {
        [Test]
        public void ShouldSetIsDuplicateTrue_When_MatchingNames()
        {
            var row1 = new ChatMarketItemViewModel(Mock.Of<IDisposable>()) { Name = "name" };
            var row2 = new ChatMarketItemViewModel(Mock.Of<IDisposable>());

            var rows = new List<ChatMarketItemViewModel> { row1, row2 };

            var service = new ChatMarketDuplicateItemsService();

            service.RefreshItems(rows);

            // ACT
            row2.Name = "name";

            // ASSERT
            Assert.That(row1.IsDuplicate, Is.True);
            Assert.That(row2.IsDuplicate, Is.True);
        }
    }
}
