﻿using System;
using Dsp.Gui.Admin.ChatScraper.Market.Rules;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Market.Services
{
    [TestFixture]
    public class ChatMarketItemValidationServiceTests
    {
        [Test]
        public void ShouldSetIsValidTrue_When_Attach_With_ValidName()
        {
            var viewModel = new ChatMarketItemViewModel(Mock.Of<IDisposable>())
            {
                Name = "market"
            };

            var service = new ChatMarketItemValidationService(new ChatMarketNameRule());

            // ACT
            service.Attach(viewModel);

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_Name_Empty()
        {
            var viewModel = new ChatMarketItemViewModel(Mock.Of<IDisposable>())
            {
                Name = "market"
            };

            var service = new ChatMarketItemValidationService(new ChatMarketNameRule());

            service.Attach(viewModel);

            // ACT
            viewModel.Name = "";

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText, Is.EqualTo("Missing Market"));
        }

        [Test]
        public void ShouldSetIsValidTrue_When_Name_Valid()
        {
            var viewModel = new ChatMarketItemViewModel(Mock.Of<IDisposable>())
            {
                Name = ""
            };

            var service = new ChatMarketItemValidationService(new ChatMarketNameRule());

            service.Attach(viewModel);

            // ACT
            viewModel.Name = "market";

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnIsDuplicateText()
        {
            var rule = new Mock<IChatMarketNameRule>();
            
            var service = new ChatMarketItemValidationService(rule.Object);

            // ACT
            var result = service.IsDuplicateText();

            // ASSERT
            Assert.That(result, Is.EqualTo("Duplicate Market"));
        }
    }
}
