﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Market.Controllers;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Market.Controllers
{
    internal interface IChatBrokerMarketsAdminViewModelControllerTestObjects
    {
        IChatMarketAdminUpdateService ChatMarketAdminUpdateService { get; }
        IChatMarketItemViewModelBuilder ChatMarketItemViewModelBuilder { get; }
        IChatMarketItemCollectionProvider ChatMarketItemCollectionProvider { get; }
        IChatMarketItemCollectionService ChatMarketItemCollectionService { get; }
        IChatMarketItemsConflictService ChatMarketConflictService { get; }
        IChatBrokerAdminMessageDialogService MessageDialogService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IChatScraperMarketAdminToolBarService ToolBarService { get; }
        ISubject<List<ChatMarket>> ChatMarkets { get; }
        ISubject<Unit> ChatMarketsUpdated { get; }
        ISubject<bool> CanExecuteUpdateCommand { get; }
        ISubject<bool> CanExecuteUndoCommand { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        ISubject<Unit> ToolBarUndo { get; }
        ISubject<Unit> ChatMarketsUpdateResponse { get; }
        ISubject<IList<string>> ValidationErrors { get; }
        ChatBrokerMarketsAdminViewModel ViewModel { get; }
        ChatBrokerMarketsAdminViewModelController Controller { get; }
    }

    [TestFixture]
    public class ChatBrokerMarketsAdminViewModelControllerTests
    {
        private class ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder
        {
            private List<ChatMarket> _chatMarkets;
            private IList<ChatMarketItemViewModel> _itemsProviderResult = new List<ChatMarketItemViewModel>();
            private ChatMarketItemViewModel _newChatMarketViewModel;
            private IList<ChatMarketItemViewModel> _conflicts = new List<ChatMarketItemViewModel>();

            public ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder WithChatMarkets(List<ChatMarket> values)
            {
                _chatMarkets = values;
                return this;
            }

            public ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder WithItemsProviderResult(List<ChatMarketItemViewModel> values)
            {
                _itemsProviderResult = values;
                return this;
            }

            public ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder WithNewChatMarketViewModel(ChatMarketItemViewModel value)
            {
                _newChatMarketViewModel = value;
                return this;
            }

            public ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder WithConflicts(IList<ChatMarketItemViewModel> values)
            {
                _conflicts = values;
                return this;
            }

            public IChatBrokerMarketsAdminViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatBrokerMarketsAdminViewModelControllerTestObjects>();

                var chatMarkets = new BehaviorSubject<List<ChatMarket>>(_chatMarkets);
                testObjects.SetupGet(o => o.ChatMarkets).Returns(chatMarkets);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.ChatMarkets).Returns(chatMarkets);
                curveControlService.Setup(o => o.GetChatMarketSnapshot()).Returns(_chatMarkets);

                var chatMarketsUpdated = new Subject<Unit>();
                testObjects.SetupGet(o => o.ChatMarketsUpdated).Returns(chatMarketsUpdated);

                var chatMarketsUpdateResponse = new Subject<Unit>();
                testObjects.SetupGet(o => o.ChatMarketsUpdateResponse).Returns(chatMarketsUpdateResponse);

                var chatMarketAdminUpdateService = new Mock<IChatMarketAdminUpdateService>();

                chatMarketAdminUpdateService.Setup(
                                               c => c.Update(It.IsAny<IList<ChatMarketItemViewModel>>(),
                                                             It.IsAny<IScheduler>(),
                                                             It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>(),
                                                             It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>(),
                                                             It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>()))
                                          .Returns(chatMarketsUpdateResponse);

                testObjects.SetupGet(o => o.ChatMarketAdminUpdateService)
                           .Returns(chatMarketAdminUpdateService.Object);

                var chatMarketViewModelBuilder = new Mock<IChatMarketItemViewModelBuilder>();

                chatMarketViewModelBuilder.Setup(b => b.CreateNewItem()).Returns(_newChatMarketViewModel);

                testObjects.SetupGet(o => o.ChatMarketItemViewModelBuilder)
                           .Returns(chatMarketViewModelBuilder.Object);

                var itemCollectionProvider = new Mock<IChatMarketItemCollectionProvider>();

                itemCollectionProvider.Setup(p => p.GetCollection(
                                                        It.IsAny<IList<ChatMarketItemViewModel>>(),
                                                        It.IsAny<IList<ChatMarket>>(),
                                                        It.IsAny<Func<ChatMarketItemViewModel, ChatMarket, bool>>(),
                                                        It.IsAny<Action<ChatMarketItemViewModel, ChatMarket>>(),
                                                        It.IsAny<Func<ChatMarket, ChatMarketItemViewModel>>()))
                                                .Returns(_itemsProviderResult);

                testObjects.SetupGet(o => o.ChatMarketItemCollectionProvider)
                           .Returns(itemCollectionProvider.Object);

                var canExecuteUpdateCommand = new Subject<bool>();
                testObjects.SetupGet(o => o.CanExecuteUpdateCommand).Returns(canExecuteUpdateCommand);

                var canExecuteUndoCommand = new Subject<bool>();
                testObjects.SetupGet(o => o.CanExecuteUndoCommand).Returns(canExecuteUndoCommand);

                var validationErrors = new Subject<IList<string>>();
                testObjects.SetupGet(o => o.ValidationErrors).Returns(validationErrors);

                var itemCollectionService = new Mock<IChatMarketItemCollectionService>();

                itemCollectionService.SetupGet(c => c.CanExecuteUpdateCommand).Returns(canExecuteUpdateCommand);
                itemCollectionService.SetupGet(c => c.CanExecuteUndoCommand).Returns(canExecuteUndoCommand);
                itemCollectionService.SetupGet(c => c.ValidationErrors).Returns(validationErrors);

                testObjects.SetupGet(o => o.ChatMarketItemCollectionService).Returns(itemCollectionService.Object);

                var messageDialogService = new Mock<IChatBrokerAdminMessageDialogService>();
                testObjects.SetupGet(o => o.MessageDialogService).Returns(messageDialogService.Object);

                var chatMarketConflictService = new Mock<IChatMarketItemsConflictService>();

                chatMarketConflictService.Setup(c => c.GetConflicts(It.IsAny<IList<ChatMarketItemViewModel>>(), It.IsAny<IEnumerable<ChatMarket>>()))
                                         .Returns(_conflicts);

                testObjects.SetupGet(o => o.ChatMarketConflictService).Returns(chatMarketConflictService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();
                testObjects.SetupGet(o => o.PopupNotificationService).Returns(popupNotificationService.Object);

                var toolBarUpdate = new Subject<Unit>();
                testObjects.SetupGet(o => o.ToolBarUpdate).Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();
                testObjects.SetupGet(o => o.ToolBarUndo).Returns(toolBarUndo);

                var toolBarService = new Mock<IChatScraperMarketAdminToolBarService>();

                toolBarService.SetupGet(tb => tb.Update).Returns(toolBarUpdate);
                toolBarService.SetupGet(tb => tb.Undo).Returns(toolBarUndo);

                testObjects.SetupGet(o => o.ToolBarService).Returns(toolBarService.Object);

                var controller = new ChatBrokerMarketsAdminViewModelController(curveControlService.Object,
                                                                               chatMarketViewModelBuilder.Object,
                                                                               itemCollectionProvider.Object,
                                                                               itemCollectionService.Object,
                                                                               toolBarService.Object,
                                                                               Mocks.GetSchedulerProvider().Object,
                                                                               Mocks.GetLoggerFactory().Object)
                {
                    ErrorMessageDialogService = messageDialogService.Object,
                    PopupNotificationService = popupNotificationService.Object,
                    ChatMarketConflictService = chatMarketConflictService.Object,
                    ChatMarketAdminUpdateService = chatMarketAdminUpdateService.Object
                };

                controller.ViewModel.ChatMarketItems = new ObservableCollection<ChatMarketItemViewModel>(_itemsProviderResult);

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPopulateItems_From_ChatMarkets()
        {
            var item = new ChatMarketItemViewModel(Mock.Of<IChatMarketItemViewModelController>()) {Name = "market"};
            var chatMarketRows = new List<ChatMarketItemViewModel> { item };

            var chatMarket = new ChatMarket(101, EntityStatus.Active, "market");
            var chatMarkets = new List<ChatMarket> { chatMarket };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().Build();

            var comparerResult = false;

            Mock.Get(testObjects.ChatMarketItemCollectionProvider)
                .Setup(p => p.GetCollection(
                           It.IsAny<IList<ChatMarketItemViewModel>>(),
                           It.IsAny<IList<ChatMarket>>(),
                           It.IsAny<Func<ChatMarketItemViewModel, ChatMarket, bool>>(),
                           It.IsAny<Action<ChatMarketItemViewModel, ChatMarket>>(),
                           It.IsAny<Func<ChatMarket, ChatMarketItemViewModel>>()))
                .Returns(chatMarketRows)
                .Callback<IList<ChatMarketItemViewModel>,
                     IList<ChatMarket>,
                     Func<ChatMarketItemViewModel, ChatMarket, bool>,
                     Action<ChatMarketItemViewModel, ChatMarket>,
                     Func<ChatMarket, ChatMarketItemViewModel>>
                 ((_, _, comparer, updater, builder) =>
                 {
                     comparerResult = comparer(item, chatMarket);
                     updater(item, chatMarket);
                     builder(chatMarket);
                 });

            // ACT
            testObjects.ChatMarkets.OnNext(chatMarkets);

            // ASSERT
            Assert.That(comparerResult, Is.True);

            Mock.Get(testObjects.ChatMarketItemViewModelBuilder)
                .Verify(b => b.UpdateItemFromChatMarket(item, chatMarket));

            Mock.Get(testObjects.ChatMarketItemViewModelBuilder)
                .Verify(b => b.CreateItemFromChatMarket(chatMarket));

            Assert.That(testObjects.ViewModel.ChatMarketItems.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldCheckConflicts_OnUsersUpdate()
        {
            var items = new List<ChatMarketItemViewModel>
            {
                new(Mock.Of<IChatMarketItemViewModelController>()) { Name = "market" }
            };

            var chatMarket = new ChatMarket(101, EntityStatus.Active, "market");
            var chatMarkets = new List<ChatMarket> { chatMarket };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                              .Build();

            // ACT
            testObjects.ChatMarkets.OnNext(chatMarkets);

            // ASSERT
            Mock.Get(testObjects.ChatMarketConflictService)
                .Verify(c => c.GetConflicts(It.IsAny<IList<ChatMarketItemViewModel>>(), chatMarkets));
        }

        [Test]
        public void ShouldShowMessageDialog_WhenConflicts()
        {
            var items = new List<ChatMarketItemViewModel>
            {
                new(Mock.Of<IChatMarketItemViewModelController>()) { Name = "market" }
            };

            var chatMarket = new ChatMarket(101, EntityStatus.Active, "market");
            var chatMarkets = new List<ChatMarket> { chatMarket };

            var conflicts = new List<ChatMarketItemViewModel> { new(Mock.Of<IDisposable>()) };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                              .WithConflicts(conflicts)
                                                                                              .Build();
            // ACT
            testObjects.ChatMarkets.OnNext(chatMarkets);

            // ASSERT
            Mock.Get(testObjects.ChatMarketConflictService)
                .Verify(c => c.ShowConflictsDialog(It.Is<IEnumerable<string>>(s => s.ToArray().Length == 1)));
        }

        [Test]
        public void ShouldInvokeChatMarketItemCollectionService_On_AddChatMarketCommand()
        {
            var chatMarket1 = new ChatMarketItemViewModel(Mock.Of<IChatMarketItemViewModelController>());
            var chatMarkets = new List<ChatMarketItemViewModel> {chatMarket1};

            var chatMarket2 = new ChatMarketItemViewModel(Mock.Of<IChatMarketItemViewModelController>()){NewRecord = true};

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(chatMarkets)
                                                                                              .WithNewChatMarketViewModel(chatMarket2)
                                                                                              .Build();
            // ACT
            testObjects.ViewModel.AddChatMarketCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ChatMarketItemCollectionService)
                .Verify(c => c.AddNewItem(chatMarket2, It.IsAny<IList<ChatMarketItemViewModel>>(), testObjects.ViewModel));
        }

        [Test]
        public void ShouldRefreshRows_OnToolBarUndo()
        {
            var chatMarket = new ChatMarket(101, EntityStatus.Active, "market-A");

            var chatMarkets = new List<ChatMarket>
            {
                chatMarket
            };

            var rowItems = new List<ChatMarketItemViewModel>
            {
                new(Mock.Of<IChatMarketItemViewModelController>())
            };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().WithChatMarkets(chatMarkets)
                                                                                              .Build();

            Mock.Get(testObjects.ChatMarketItemCollectionProvider)
                .Setup(p => p.GetCollectionReset(It.IsAny<IList<ChatMarket>>(), 
                                                    It.IsAny<Func<ChatMarket, ChatMarketItemViewModel>>()))
                .Returns(rowItems)
                .Callback<IList<ChatMarket>, Func<ChatMarket, ChatMarketItemViewModel>>
                 ((_, builder) =>
                 {
                     builder(chatMarket);
                 });

            testObjects.ViewModel.ChatMarketItems = new ObservableCollection<ChatMarketItemViewModel>
            {
                new(Mock.Of<IChatMarketItemViewModelController>()),
                new(Mock.Of<IChatMarketItemViewModelController>())
            };

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatMarketItems.Count, Is.EqualTo(1));

            Mock.Get(testObjects.ChatMarketItemViewModelBuilder)
                .Verify(b => b.CreateItemFromChatMarket(chatMarket));

            Mock.Get(testObjects.ChatMarketItemCollectionService)
                .Verify(c => c.RefreshItems(It.IsAny<IList<ChatMarketItemViewModel>>()));
        }

        [Test]
        public void ShouldSetIsBusyAndInvokeAdminService_OnToolBarUpdate()
        {
            var items = new List<ChatMarketItemViewModel>
            {
                new(Mock.Of<IChatMarketItemViewModelController>()) {IsValid = true},
            };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                              .Build();
            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.ChatMarketAdminUpdateService).
                 Verify(cs => cs.Update(items,
                                        It.IsAny<IScheduler>(),
                                        It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>(),
                                        It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>(),
                                        It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>()));
        }

        [Test]
        public void Should_InvokeAdminUpdateService_With_BuilderFunctions_On_ToolBarUpdate()
        {
            var newItem = new ChatMarketItemViewModel(Mock.Of<IChatMarketItemViewModelController>()) { Name = "name-1" };

            var changedItem = new ChatMarketItemViewModel(Mock.Of<IChatMarketItemViewModelController>()) { Name = "name-2"};
            changedItem.SetChatMarket(new ChatMarket(2, EntityStatus.Active, "name-2"));

            var deletedItem = new ChatMarketItemViewModel(Mock.Of<IChatMarketItemViewModelController>());
            deletedItem.SetChatMarket(new ChatMarket(3, EntityStatus.Active, "name-3"));

            var items = new List<ChatMarketItemViewModel>
            {
                newItem
            };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                              .Build();
            ChatMarket newBuildResult = null;
            ChatMarket changedBuildResult = null;
            ChatMarket deletedBuildResult = null;

            Mock.Get(testObjects.ChatMarketAdminUpdateService)
                .Setup(
                     c => c.Update(It.IsAny<IList<ChatMarketItemViewModel>>(),
                                   It.IsAny<IScheduler>(),
                                   It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>(),
                                   It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>(),
                                   It.IsAny<Func<ChatMarketItemViewModel, ChatMarket>>()))
                .Returns(Observable.Return(Unit.Default))
                .Callback<IList<ChatMarketItemViewModel>,
                          IScheduler,
                          Func<ChatMarketItemViewModel, ChatMarket>,
                          Func<ChatMarketItemViewModel, ChatMarket>,
                          Func<ChatMarketItemViewModel, ChatMarket>>
                 ((_, _, func1, func2, func3) =>
                 {
                     newBuildResult = func1(newItem);
                     changedBuildResult = func2(changedItem);
                     deletedBuildResult = func3(deletedItem);
                 });


            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(newBuildResult.Id, Is.EqualTo(0));
            Assert.That(newBuildResult.Status, Is.EqualTo(EntityStatus.Active));
            Assert.That(newBuildResult.Market, Is.EqualTo("name-1"));

            Assert.That(changedBuildResult.Id, Is.EqualTo(2));
            Assert.That(changedBuildResult.Status, Is.EqualTo(EntityStatus.Active));
            Assert.That(changedBuildResult.Market, Is.EqualTo("name-2"));

            Assert.That(deletedBuildResult.Id, Is.EqualTo(3));
            Assert.That(deletedBuildResult.Status, Is.EqualTo(EntityStatus.Deleted));
            Assert.That(deletedBuildResult.Market, Is.EqualTo("name-3"));
        }

        [Test]
        public void ShouldSetIsBusyFalse_OnChatMarketUpdateResponseCompleted()
        {
            var changedMarket = new ChatMarketItemViewModel(Mock.Of<IChatMarketItemViewModelController>());

            changedMarket.SetChatMarket(new ChatMarket());
            changedMarket.IsDirty = true;
            changedMarket.IsValid = true;

            var viewModels = new List<ChatMarketItemViewModel>
            {
                new(Mock.Of<IChatMarketItemViewModelController>()) {IsValid = true},
                changedMarket
            };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(viewModels)
                                                                                              .Build();

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ChatMarketsUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldSetIsBusyFalseAndDisplayDialog_OnChatMarketUpdateResponseError()
        {
            var changedMarket = new ChatMarketItemViewModel(Mock.Of<IChatMarketItemViewModelController>());

            changedMarket.SetChatMarket(new ChatMarket());
            changedMarket.IsDirty = true;
            changedMarket.IsValid = true;

            var viewModels = new List<ChatMarketItemViewModel>
            {
                new(Mock.Of<IChatMarketItemViewModelController>()) {IsValid = true},
                changedMarket
            };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(viewModels)
                                                                                              .Build();

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ChatMarketsUpdateResponse.OnError(new Exception("failed"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
           
            Mock.Get(testObjects.MessageDialogService)
                .Verify(md => md.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "failed" 
                                                                                  && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldNotPopulateMarkets_When_Disposed()
        {
            var chatMarkets = new List<ChatMarket>
            {
                new(101, EntityStatus.Active, "market-B"),
                new(102, EntityStatus.Active, "market-A")
            };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ChatMarkets.OnNext(chatMarkets);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatMarketItems.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldSetValidationErrors_When_Errors()
        {
            var errors = new List<string> { "error" };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Mock.Get(testObjects.ToolBarService).Verify(tb => tb.SetValidationErrors(errors));
        }

        [Test]
        public void ShouldClearValidationErrors_When_NoErrors()
        {
            var errors = new List<string>();

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Mock.Get(testObjects.ToolBarService).Verify(tb => tb.ClearValidation());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var chatMarkets = new List<ChatMarket>
            {
                new(101, EntityStatus.Active, "market-B"),
                new(102, EntityStatus.Active, "market-A")
            };

            var testObjects = new ChatBrokerMarketsAdminViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.ChatMarkets.OnNext(chatMarkets);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatMarketItems.Count, Is.EqualTo(0));
        }
    }
}
