﻿using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Market.Controllers;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Market.Controllers
{
    internal interface IChatMarketItemViewModelControllerTestObjects
    {
        IChatMarketDependencyService ChatMarketDependencyService { get; }
        IChatMarketItemValidationService ValidationService { get; }
        ISubject<bool> HasChatMarketDependencies { get; }
        ChatMarketItemViewModelController Controller { get; }
        ChatMarketItemViewModel ViewModel { get; }
    }

    [TestFixture]
    public class ChatMarketItemViewModelControllerTests
    {
        private class ChatMarketItemViewModelControllerTestObjectBuilder
        {
            private ChatMarket _chatMarket;
            private bool _isDuplicate;
            private string _errorText;

            public ChatMarketItemViewModelControllerTestObjectBuilder WithChatMarket(ChatMarket value)
            {
                _chatMarket = value;
                return this;
            }

            public ChatMarketItemViewModelControllerTestObjectBuilder WithIsDuplicate(bool value)
            {
                _isDuplicate = value;
                return this;
            }

            public ChatMarketItemViewModelControllerTestObjectBuilder WithErrorText(string value)
            {
                _errorText = value;
                return this;
            }

            public IChatMarketItemViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatMarketItemViewModelControllerTestObjects>();

                var hasDependencies = new Subject<bool>();
                testObjects.SetupGet(o => o.HasChatMarketDependencies).Returns(hasDependencies);

                var dependencyService = new Mock<IChatMarketDependencyService>();

                dependencyService.Setup(d => d.HasDependents(It.IsAny<int>()))
                                 .Returns(hasDependencies);

                var validationService = new Mock<IChatMarketItemValidationService>();

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(validationService.Object);

                testObjects.SetupGet(o => o.ChatMarketDependencyService).Returns(dependencyService.Object);

                var controller = new ChatMarketItemViewModelController(dependencyService.Object, 
                                                                       validationService.Object);

                if (_chatMarket != null)
                {
                    controller.ViewModel.SetChatMarket(_chatMarket);
                    controller.ViewModel.Name = _chatMarket.Market;
                    controller.ViewModel.IsDirty = false;
                }

                controller.ViewModel.IsDuplicate = _isDuplicate;
                controller.ViewModel.ErrorText = _errorText;

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachValidationService()
        {
            // ACT
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldEnableDeleteCommand()
        {
            // ACT
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.DeleteCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldSetIsDeleted_OnDeleteCommand()
        {
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.True);
        }

        [Test]
        public void ShouldSetIsDeletedFalse_OnUndoDeleteCommand()
        {
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.DeleteCommand.Execute();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.False);
            Assert.That(testObjects.ViewModel.DeleteCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_AllItemsInitialized()
        {
            var chatMarket = new ChatMarket(10, EntityStatus.Active, "market");

            // ACT
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().WithChatMarket(chatMarket)
                                                                                      .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_NameChanged()
        {
            var chatMarket = new ChatMarket(10, EntityStatus.Active, "market-1");

            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().WithChatMarket(chatMarket)
                                                                                      .Build();
            // ACT
            testObjects.ViewModel.Name = "market-2";

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldTrimSpaces_OnName()
        {
            var chatMarket = new ChatMarket(10, EntityStatus.Active, "market-1");

            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().WithChatMarket(chatMarket)
                                                                                      .Build();
            // ACT
            testObjects.ViewModel.Name = " market-2 ";

            // ASSERT
            Assert.That(testObjects.ViewModel.Name, Is.EqualTo("market-2"));
        }

        [Test]
        public void ShouldDisableDeleteCommand_When_MarketHasDependents_And_IdSet()
        {
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.Id = 1;

            // ACT
            testObjects.HasChatMarketDependencies.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.DeleteCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableDeleteCommand_When_MarketHasDependents_False()
        {
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.Id = 1;
            testObjects.HasChatMarketDependencies.OnNext(true);

            // ACT
            testObjects.HasChatMarketDependencies.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.DeleteCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisposeRowValidation_On_Dispose()
        {
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().Build();
   
            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ChatMarketItemViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Dispose(), Times.Once);
        }
    }
}
