﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Services
{
    internal interface IBrokerAdminUpdateServiceTestObjects
    {
        IChatScraperAdminUpdateService ChatScraperAdminUpdateService { get; }
        ISubject<Unit> NewRecordsUpdateResponse { get; }
        ISubject<Unit> ChangedRecordsUpdateResponse { get; }
        IScheduler Scheduler { get; }
        BrokerAdminUpdateService<IEditableItem, object>  BrokerAdminUpdateService { get; }
    }


    [TestFixture]
    public class BrokerAdminUpdateServiceTests
    {
        private class BrokerAdminUpdateServiceTestObjectBuilder
        {
            public IBrokerAdminUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IBrokerAdminUpdateServiceTestObjects>();

                var newRecordsUpdateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.NewRecordsUpdateResponse)
                           .Returns(newRecordsUpdateResponse);

                var changedRecordsUpdateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.ChangedRecordsUpdateResponse)
                           .Returns(changedRecordsUpdateResponse);

                var chatScraperAdminUpdateService = new Mock<IChatScraperAdminUpdateService>();

                chatScraperAdminUpdateService.Setup(f => f.UpdateChatScraperProfile(It.IsAny<IScheduler>(),
                                              It.IsAny<List<object>>(),
                                              true))
                                          .Returns(newRecordsUpdateResponse);

                chatScraperAdminUpdateService.Setup(f => f.UpdateChatScraperProfile(It.IsAny<IScheduler>(),
                                                                                 It.IsAny<List<object>>(),
                                                                                 false))
                                          .Returns(changedRecordsUpdateResponse);

                testObjects.SetupGet(o => o.ChatScraperAdminUpdateService)
                           .Returns(chatScraperAdminUpdateService.Object);

                testObjects.SetupGet(o => o.Scheduler).Returns(Scheduler.Immediate);

                var brokerAdminUpdateService = new BrokerAdminUpdateService<IEditableItem, object>(chatScraperAdminUpdateService.Object);

                testObjects.SetupGet(o => o.BrokerAdminUpdateService)
                           .Returns(brokerAdminUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetIsInEditFalse_OnChangedRows()
        {
            var changedRow = Mock.Of<IEditableItem>(r => r.IsInEdit);
            var unchangedRow = Mock.Of<IEditableItem>();

            var rows = new[] { changedRow, unchangedRow };

            object GetNewObjects(IEditableItem row) => new();
            object GetChangedObjects(IEditableItem row) => null;
            object GetDeletedObjects(IEditableItem row) => null;

            var testObjects = new BrokerAdminUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.BrokerAdminUpdateService.Update(rows,
                                                        testObjects.Scheduler,
                                                        GetNewObjects,
                                                        GetChangedObjects,
                                                        GetDeletedObjects);

            // ASSERT
            Assert.That(changedRow.IsInEdit, Is.False);
        }

        [Test]
        public void ShouldInvokeChatScraperAdminUpdateService_With_AddNewTrue_When_UpdateNewRows()
        {
            var newRow = Mock.Of<IEditableItem>(r => r.NewRecord && r.IsDirty && r.IsValid);
            var unchangedRow = Mock.Of<IEditableItem>(r => r.IsValid);

            var rows = new[] {newRow, unchangedRow};

            object GetNewObjects(IEditableItem row) => new();
            object GetChangedObjects(IEditableItem row) => null;
            object GetDeletedObjects(IEditableItem row) => null;

            var testObjects = new BrokerAdminUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.BrokerAdminUpdateService.Update(rows,
                                                        testObjects.Scheduler,
                                                        GetNewObjects,
                                                        GetChangedObjects,
                                                        GetDeletedObjects);

            // ASSERT
            Mock.Get(testObjects.ChatScraperAdminUpdateService)
                .Verify(cs => cs.UpdateChatScraperProfile(testObjects.Scheduler, 
                                                          It.Is<List<object>>(o => o.Count == 1 && o[0] != null), 
                                                          true), Times.Once);

            Mock.Get(testObjects.ChatScraperAdminUpdateService)
                .Verify(cs => cs.UpdateChatScraperProfile(testObjects.Scheduler,
                                                          It.IsAny<List<object>>(),
                                                          false), Times.Never);

        }

        [Test]
        public void ShouldInvokeChatScraperAdminUpdateService_With_AddNewFalse_When_UpdateChangedAndDeletedRows()
        {
            var changedRow = Mock.Of<IEditableItem>(r => r.IsDirty && r.IsValid);
            var deletedRow = Mock.Of<IEditableItem>(r => r.IsDeleted);
            var unchangedRow = Mock.Of<IEditableItem>(r => r.IsValid);

            var rows = new[] { changedRow, deletedRow, unchangedRow };

            object GetNewObjects(IEditableItem row) => null;
            object GetChangedObjects(IEditableItem row) => new();
            object GetDeletedObjects(IEditableItem row) => new();

            var testObjects = new BrokerAdminUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.BrokerAdminUpdateService.Update(rows,
                                                        testObjects.Scheduler,
                                                        GetNewObjects,
                                                        GetChangedObjects,
                                                        GetDeletedObjects);

            // ASSERT
            Mock.Get(testObjects.ChatScraperAdminUpdateService)
                .Verify(cs => cs.UpdateChatScraperProfile(testObjects.Scheduler,
                                                          It.IsAny<List<object>>(),
                                                          true), Times.Never);

            Mock.Get(testObjects.ChatScraperAdminUpdateService)
                .Verify(cs => cs.UpdateChatScraperProfile(testObjects.Scheduler,
                                                          It.Is<List<object>>(o => o.Count == 2 && o[0] != null && o[1] != null),
                                                          false), Times.Once);
        }

        [Test]
        public void ShouldPublishResponse_When_UpdateComplete_With_NewRecordsOnly()
        {
            var newRow = Mock.Of<IEditableItem>(r => r.NewRecord && r.IsDirty && r.IsValid);
            var unchangedRow = Mock.Of<IEditableItem>(r => r.IsValid);

            var rows = new[] { newRow, unchangedRow };

            object GetNewObjects(IEditableItem row) => new();
            object GetChangedObjects(IEditableItem row) => null;
            object GetDeletedObjects(IEditableItem row) => null;

            var testObjects = new BrokerAdminUpdateServiceTestObjectBuilder().Build();

            var response =  testObjects.BrokerAdminUpdateService.Update(rows, 
                                                                        testObjects.Scheduler, 
                                                                        GetNewObjects, 
                                                                        GetChangedObjects, 
                                                                        GetDeletedObjects);
            var result = false;

            using (response.Subscribe(_ => result = true))
            {
                // ACT
                testObjects.NewRecordsUpdateResponse.OnNext(Unit.Default);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishResponse_When_UpdateComplete_With_ChangedRecordsOnly()
        {
            var changedRow = Mock.Of<IEditableItem>(r => r.IsDirty && r.IsValid);
            var deletedRow = Mock.Of<IEditableItem>(r => r.IsDeleted);
            var unchangedRow = Mock.Of<IEditableItem>(r => r.IsValid);

            var rows = new[] { changedRow, deletedRow, unchangedRow };

            object GetNewObjects(IEditableItem row) => null;
            object GetChangedObjects(IEditableItem row) => new();
            object GetDeletedObjects(IEditableItem row) => new();

            var testObjects = new BrokerAdminUpdateServiceTestObjectBuilder().Build();

            // ACT
            var response = testObjects.BrokerAdminUpdateService.Update(rows, 
                                                                       testObjects.Scheduler, 
                                                                       GetNewObjects, 
                                                                       GetChangedObjects, 
                                                                       GetDeletedObjects);
            var result = false;

            using (response.Subscribe(_ => result = true))
            {
                // ACT
                testObjects.ChangedRecordsUpdateResponse.OnNext(Unit.Default);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishResponse_When_BothUpdatesComplete_With_NewAndChangedRecords()
        {
            var newRow = Mock.Of<IEditableItem>(r => r.NewRecord && r.IsDirty && r.IsValid);
            var changedRow = Mock.Of<IEditableItem>(r => r.IsDirty && r.IsValid);
            var deletedRow = Mock.Of<IEditableItem>(r => r.IsDeleted);
            var unchangedRow = Mock.Of<IEditableItem>(r => r.IsValid);

            var rows = new[] {newRow, changedRow, deletedRow, unchangedRow };

            object GetNewObjects(IEditableItem row) => null;
            object GetChangedObjects(IEditableItem row) => new();
            object GetDeletedObjects(IEditableItem row) => new();

            var testObjects = new BrokerAdminUpdateServiceTestObjectBuilder().Build();

            // ACT
            var response = testObjects.BrokerAdminUpdateService.Update(rows,
                                                                       testObjects.Scheduler,
                                                                       GetNewObjects,
                                                                       GetChangedObjects,
                                                                       GetDeletedObjects);
            var result = 0;

            using (response.Subscribe(_ => result++))
            {
                // ACT
                testObjects.NewRecordsUpdateResponse.OnNext(Unit.Default);
                testObjects.ChangedRecordsUpdateResponse.OnNext(Unit.Default);

                // ASSERT
                Assert.That(result, Is.EqualTo(1));
            }
        }
    }
}
