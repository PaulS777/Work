﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Messages.Services;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Services
{
    [TestFixture]
    public class ChatMessageHistoryViewModelBuilderTests
    {

        [Test]
        public void ShouldCreateChatMessageHistoryViewModel_From_ChatMessageHistory()
        {
            var markets = new List<ChatMarket>
            {
                new ChatMarket(1, EntityStatus.Active, "new chat market 1"),
                new ChatMarket(2, EntityStatus.Active, "new chat market 2"),
                new ChatMarket(3, EntityStatus.Active, "new chat market 3"),
                new ChatMarket(4, EntityStatus.Active, "new chat market 4")
            };

            var messages = new List<ChatMessageHistory>
            {
                new ChatMessageHistory(1,  DateTime.Now, "ian hopkins", "ian hopkins", "AO", "1M",
                    "1M", new DateTime(2020, 02, 01), new DateTime(2020, 03, 01),
                    "4.5:5.5", 4.5, 5.5, 5.25, "100", 0, 1, 1,
                    EntityStatus.Active),
                new ChatMessageHistory(2,  DateTime.Now, "ian hopkins", "ian hopkins", "AO", "2M",
                    "2M", new DateTime(2020, 02, 01), new DateTime(2020, 04, 01),
                    "5.6:6.5", 5.6, 6.5, 5.25, "100", 0, 1, 1,
                    EntityStatus.Active),

            };

            var iceCodes = new List<ChatIceMap>
            {
                new ChatIceMap(1, EntityStatus.Active, "AO", 1, 1,
                    "ao"),
                new ChatIceMap(2, EntityStatus.Active, "AX", 2, 0,
                    "ax")
            };

            var chatMessageViewModelBuilder = new ChatMessageHistoryViewModelBuilder();

            // ACT
            var viewModel = chatMessageViewModelBuilder.CreateChatMessageHistoryViewModel(messages[0],
                iceCodes,
                markets);

            // ASSERT
            Assert.AreEqual("new chat market 1", viewModel.Market);
            Assert.AreEqual("AO", viewModel.PriceCurveName);
            Assert.AreEqual("AO", viewModel.Commodity);
        }
    }
}
