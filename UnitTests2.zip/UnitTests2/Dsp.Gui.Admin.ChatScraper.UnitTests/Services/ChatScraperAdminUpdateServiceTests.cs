﻿using System;
using System.Reactive;
using System.Reactive.Subjects;
using System.Threading.Tasks;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Services;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Services
{
    public interface IChatScraperUpdateServiceTestObjects
    {
        IAdminApiServiceClient AdminApiServiceClient { get; }

        IChatScraperAdminUpdateService ChatScraperAdminUpdateService { get; }

        ISubject<Unit> ServiceUpdate { get; }
    }

    [TestFixture]
    public class ChatScraperAdminUpdateServiceTests
    {
        private class ChatScraperAdminUpdateServiceTestObjectBuilder
        {
            private AdminApiServiceResponse _serviceResponse;
            private Exception _serviceException;

            public ChatScraperAdminUpdateServiceTestObjectBuilder WithServiceResponse(AdminApiServiceResponse value)
            {
                _serviceResponse = value;
                return this;
            }

            public ChatScraperAdminUpdateServiceTestObjectBuilder WithServiceException(Exception value)
            {
                _serviceException = value;
                return this;
            }

            public IChatScraperUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatScraperUpdateServiceTestObjects>();

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                adminApiServiceClient.Setup(a => a.Add(It.IsAny<object>()))
                                     .Returns(Task.FromResult(_serviceResponse));

                adminApiServiceClient.Setup(a => a.Update(It.IsAny<object>()))
                                     .Returns(Task.FromResult(_serviceResponse));

                if (_serviceException != null)
                {
                    adminApiServiceClient.Setup(a => a.Update(It.IsAny<object>()))
                                         .Throws(_serviceException);
                }

                testObjects.SetupGet(o => o.AdminApiServiceClient)
                           .Returns(adminApiServiceClient.Object);

                var userUpdated = new Subject<Unit>();
                testObjects.SetupGet(o => o.ServiceUpdate).Returns(userUpdated);

                var chatScraperUpdateService =
                    new ChatScraperAdminUpdateService(adminApiServiceClient.Object, Mocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.ChatScraperAdminUpdateService)
                           .Returns(chatScraperUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishCompleted_On_UpdateResponseSuccess()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(true);

            var testObjects = new ChatScraperAdminUpdateServiceTestObjectBuilder().WithServiceResponse(response)
                                                                                  .Build();
            var completed = false;

            var model = new object();

            using (testObjects.ChatScraperAdminUpdateService
                              .UpdateChatScraperProfile(testScheduler, model, false)
                              .Subscribe(_ => { },
                                         () => completed = true))
            {
                // ACT
                testObjects.ServiceUpdate.OnNext(Unit.Default);
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(completed, Is.True);
            }
        }

        [Test]
        public void ShouldPublishCompleted_On_AddResponseSuccess()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(true);

            var testObjects = new ChatScraperAdminUpdateServiceTestObjectBuilder().WithServiceResponse(response)
                                                                                  .Build();
            var completed = false;

            var model = new object();

            using (testObjects.ChatScraperAdminUpdateService
                              .UpdateChatScraperProfile(testScheduler, model, true)
                              .Subscribe(_ => { },
                                         () => completed = true))
            {
                // ACT
                testObjects.ServiceUpdate.OnNext(Unit.Default);
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(completed, Is.True);
            }
        }

        [TestCase(true)]
        [TestCase(false)]
        public void ShouldPublishError_On_Add_Or_Update_ResponseFailed(bool add)
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(AdminApiServiceResponseReason.DspServerError);

            var testObjects = new ChatScraperAdminUpdateServiceTestObjectBuilder().WithServiceResponse(response)
                                                                                  .Build();
            var model = new object();

            Exception result = null;

            using (testObjects.ChatScraperAdminUpdateService
                              .UpdateChatScraperProfile(testScheduler, model, add)
                              .Subscribe(_ => { },
                                         ex => result = ex))
            {
                // ACT
                testObjects.ServiceUpdate.OnNext(Unit.Default);
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(result.Message, Is.EqualTo(response.ReasonText));
            }
        }

        [TestCase(true)]
        [TestCase(false)]
        public void ShouldPublishError_On_Add_Or_Update_ResponseException(bool add)
        {
            var testScheduler = new TestScheduler();

            var serviceException = new Exception("error");

            var testObjects = new ChatScraperAdminUpdateServiceTestObjectBuilder().WithServiceException(serviceException)
                                                                                  .Build();
            var model = new object();

            Exception result = null;

            using (testObjects.ChatScraperAdminUpdateService
                              .UpdateChatScraperProfile(testScheduler, model, add)
                              .Subscribe(_ => { },
                                         ex => result = ex))
            {
                // ACT
                testObjects.ServiceUpdate.OnNext(Unit.Default);
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.IsNotNull(result);
            }
        }
    }
}
