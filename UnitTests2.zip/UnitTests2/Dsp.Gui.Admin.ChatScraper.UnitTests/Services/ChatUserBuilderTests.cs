﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Controllers;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Services
{
    [TestFixture]
    public class ChatUserBuilderTests
    {
        [Test]
        public void ShouldGetUpdatedChatUser_WithMarkets()
        {
            var chatMarkets = new List<ChatMarket>
            {
                new(101, EntityStatus.Active, "market-1"),
                new(102, EntityStatus.Active, "market-2")
            };

            var marketItem = new MarketItemViewModel {MarketId = 101};

            var viewModel = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "user",
                Markets = new List<object> {marketItem},
                References = null
            };
            viewModel.SetChatUser(new ChatUser(99, EntityStatus.Active, "name", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var builder = new ChatUserBuilder();

            // ACT
            var result = builder.GetUpdatedChatUser(viewModel, chatMarkets);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(99));
            Assert.That(result.Name, Is.EqualTo("user"));
            Assert.That(result.ChatUserMarkets.Count, Is.EqualTo(1));
            Assert.That(result.ChatUserMarkets[0].Id, Is.EqualTo(0));
            Assert.That(result.ChatUserMarkets[0].ChatMarketId, Is.EqualTo(101));
            Assert.That(result.ChatUserMarkets[0].ChatUserId, Is.EqualTo(99));
        }

        [Test]
        public void ShouldGetUpdatedChatUser_WithReferences()
        {
            var chatMarkets = new List<ChatMarket>();

            var viewModel = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "user",
                Markets = null,
                References = new List<object> { "ref-1"}
            };
            viewModel.SetChatUser(new ChatUser(99, EntityStatus.Active, "name", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var builder = new ChatUserBuilder();

            // ACT
            var result = builder.GetUpdatedChatUser(viewModel, chatMarkets);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(99));
            Assert.That(result.Name, Is.EqualTo("user"));
            Assert.That(result.ChatUserReferences.Count, Is.EqualTo(1));
            Assert.That(result.ChatUserReferences[0].Id, Is.EqualTo(0));
            Assert.That(result.ChatUserReferences[0].ExternalRef, Is.EqualTo("ref-1"));
            Assert.That(result.ChatUserReferences[0].ChatUserId, Is.EqualTo(99));
        }

        [Test]
        public void ShouldGetDeletedChatUser()
        {
            var chatMarkets = new List<ChatMarket>();

            var viewModel = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "user",
                Markets = null,
                References = null
            };
            viewModel.SetChatUser(new ChatUser(99, EntityStatus.Active, "name", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var builder = new ChatUserBuilder();

            // ACT
            var result = builder.GetDeletedChatUser(viewModel, chatMarkets);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(99));
            Assert.That(result.Name, Is.EqualTo("user"));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Deleted));
        }

        [Test]
        public void ShouldGetNewChatUser()
        {
            var chatMarkets = new List<ChatMarket>();

            var viewModel = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "user",
                Markets = null,
                References = null
            };

            var builder = new ChatUserBuilder();

            // ACT
            var result = builder.GetNewChatUser(viewModel, chatMarkets);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(0));
            Assert.That(result.Name, Is.EqualTo("user"));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Active));
        }
    }
}
