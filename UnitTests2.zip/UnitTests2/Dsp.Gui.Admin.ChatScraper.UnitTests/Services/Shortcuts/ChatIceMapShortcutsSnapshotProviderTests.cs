﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Services.Shortcuts
{
    internal interface IChatIceMapShortcutsSnapshotProviderTestObjects
    {
        ChatIceMapShortcutsProvider ChatIceMapShortcutsSnapshotProvider { get; }
    }

    [TestFixture]
    public class ChatIceMapShortcutsSnapshotProviderTests
    {
        private class ChatIceMapShortcutsSnapshotProviderTestObjectBuilder
        {
            private IEnumerable<ChatIceMap> _chatIceMaps;

            public ChatIceMapShortcutsSnapshotProviderTestObjectBuilder WithChatIceMaps(IEnumerable<ChatIceMap> values)
            {
                _chatIceMaps = values;
                return this;
            }

            public IChatIceMapShortcutsSnapshotProviderTestObjects Build()
            {
                var testObjects = new Mock<IChatIceMapShortcutsSnapshotProviderTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.Setup(c => c.GetChatIceMapSnapshot())
                                   .Returns(_chatIceMaps);

                var provider = new ChatIceMapShortcutsProvider(curveControlService.Object);

                testObjects.SetupGet(o => o.ChatIceMapShortcutsSnapshotProvider)
                           .Returns(provider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetSnapshotFromChatIceMaps()
        {
            var chatIceMaps = new[]
            {
                new ChatIceMap(1, EntityStatus.Active, "curve", 51, null, "ref-1;ref-2"),
                new ChatIceMap(2, EntityStatus.Deleted, "curve", 52, null, "ref-3"),
                new ChatIceMap(3, EntityStatus.Active, "curve", 53, null, null),
                new ChatIceMap(4, EntityStatus.Active, "curve", 54, null, ""),
                new ChatIceMap(5, EntityStatus.Active, "curve", 55, null, "ref-4")
            };

            var testObjects = new ChatIceMapShortcutsSnapshotProviderTestObjectBuilder().WithChatIceMaps(chatIceMaps)
                                                                                        .Build();

            // ACT
            var result = testObjects.ChatIceMapShortcutsSnapshotProvider.GetSnapshot().ToList();

            // ASSERT
            Assert.That(result.Count == 3 
                        && result[0] == "ref-1"
                        && result[1] == "ref-2"
                        && result[2] == "ref-4");
        }
    }
}
