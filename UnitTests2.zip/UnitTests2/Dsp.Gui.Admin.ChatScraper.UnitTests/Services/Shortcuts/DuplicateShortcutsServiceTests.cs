﻿using System.Collections.Generic;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Admin.ChatScraper.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Services.Shortcuts
{
    internal interface IDuplicateShortcutsServiceTestObjects
    {
        DuplicateShortcutsService DuplicateShortcutsService { get; }
    }

    [TestFixture]
    public class DuplicateShortcutsServiceTests
    {
        private class DuplicateShortcutsServiceTestObjectBuilder
        {
            private IEnumerable<string> _shortcutsSnapshot = new List<string>();

            public DuplicateShortcutsServiceTestObjectBuilder WithShortcutsSnapshot(IEnumerable<string> values)
            {
                _shortcutsSnapshot = values;
                return this;
            }

            public IDuplicateShortcutsServiceTestObjects Build()
            {
                var testObjects = new Mock<IDuplicateShortcutsServiceTestObjects>();

                var shortcutsSnapshotProvider = new Mock<IShortcutsSnapshotProvider>();

                shortcutsSnapshotProvider.Setup(p => p.GetSnapshot())
                                         .Returns(_shortcutsSnapshot);

                var duplicatesShortcutsService = new DuplicateShortcutsService(shortcutsSnapshotProvider.Object);

                testObjects.SetupGet(o => o.DuplicateShortcutsService)
                           .Returns(duplicatesShortcutsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetIsDuplicateTrue_When_DuplicateShortcutItemAdded()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object>{ "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var item3 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 3);

            var items = new[] { item1, item2, item3 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            // ACT
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object>{"ref-1"});

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.True);
            Assert.That(item2.IsDuplicateShortcut, Is.True);
            Assert.That(item3.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldSetIsDuplicateTrue_When_DuplicateShortcutItemAdded_With_DifferentCase()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var item3 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 3);

            var items = new[] { item1, item2, item3 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            // ACT
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "Ref-1" });

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.True);
            Assert.That(item2.IsDuplicateShortcut, Is.True);
            Assert.That(item3.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldSetIsDuplicateFalse_When_DuplicateShortcutItemRemoved()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var item3 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 3);

            var items = new[] { item1, item2, item3 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });

            // ACT
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-2" });

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.False);
            Assert.That(item2.IsDuplicateShortcut, Is.False);
            Assert.That(item3.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldSetIsDuplicateFalse_When_DuplicateShortcutItemDeleted()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var item3 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 3);

            var items = new[] { item1, item2, item3 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });

            // ACT
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.IsDeleted, true);

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.False);
            Assert.That(item2.IsDuplicateShortcut, Is.False);
            Assert.That(item3.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldSetIsDuplicateTrue_When_DuplicateShortcutItemUndoDelete()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var item3 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 3);

            var items = new[] { item1, item2, item3 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.IsDeleted, true);

            // ACT
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.IsDeleted, false);

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.True);
            Assert.That(item2.IsDuplicateShortcut, Is.True);
            Assert.That(item3.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldSetIsDuplicateTrue_When_NewItemAdded_And_DuplicateShortcutItemAdded()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
     
            var items = new[] { item1, item2 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            var item3 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 3);

            testObjects.DuplicateShortcutsService.AddItem(item3);

            // ACT
            Mock.Get(item3).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.True);
            Assert.That(item2.IsDuplicateShortcut, Is.False);
            Assert.That(item3.IsDuplicateShortcut, Is.True);
        }

        [Test]
        public void ShouldSetIsDuplicateTrue_When_ShortcutItemAdded_With_SnapshotDuplicate()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1);
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);

            var items = new[] { item1, item2 };

            var snapshot = new[] { "ref-1","ref-2" };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().WithShortcutsSnapshot(snapshot)
                                                                              .Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            // ACT
            Mock.Get(item1).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.True);
            Assert.That(item2.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldSetIsDuplicateFalse_When_ShortcutItemRemoved_With_ChatIceMapsDuplicate()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1);
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);

            var items = new[] { item1, item2 };

            var snapshot = new[] { "ref-1","ref-2" };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().WithShortcutsSnapshot(snapshot)
                                                                              .Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);
            Mock.Get(item1).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });

            // ACT
            Mock.Get(item1).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-3" });

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.False);
            Assert.That(item2.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldUnRegisterDuplicateCheck_When_RefreshItems()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var items = new[] { item1, item2 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            var item1Update = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2Update = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var itemsUpdate = new[] { item1Update, item2Update };

            testObjects.DuplicateShortcutsService.RefreshItems(itemsUpdate);

            // ACT
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.False);
            Assert.That(item2.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldUnRegisterDuplicateCheck_When_Dispose()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var items = new[] { item1, item2 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            testObjects.DuplicateShortcutsService.Dispose();

            // ACT
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.False);
            Assert.That(item2.IsDuplicateShortcut, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Dispose()
        {
            var item1 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 1 && r.Shortcuts == new List<object> { "ref-1" });
            var item2 = Mock.Of<IEditableItemWithShortcuts>(r => r.Id == 2);
            var items = new[] { item1, item2 };

            var testObjects = new DuplicateShortcutsServiceTestObjectBuilder().Build();

            testObjects.DuplicateShortcutsService.RefreshItems(items);

            testObjects.DuplicateShortcutsService.Dispose();

            // ACT
            testObjects.DuplicateShortcutsService.Dispose();
            Mock.Get(item2).NotifyPropertyChanged(vm => vm.Shortcuts, new List<object> { "ref-1" });

            // ASSERT
            Assert.That(item1.IsDuplicateShortcut, Is.False);
            Assert.That(item2.IsDuplicateShortcut, Is.False);
        }
    }
}
