﻿using System.Collections.Generic;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Services.Shortcuts
{
    public class ChatShortcutsComparerTests
    {
        [Test]
        public void ShouldReturnTrue_When_Compare_With_SameShortcuts()
        {
            var viewModelShortcuts = new List<object> { "ref-1", "ref-2" };
            var chatShortcuts = "ref-1;ref-2";

            var comparer = new ChatShortcutsComparer();

            // ACT
            var result = comparer.CompareShortcuts(viewModelShortcuts, chatShortcuts);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_Compare_With_SameShortcuts_DifferentOrder()
        {
            var viewModelShortcuts = new List<object> { "ref-1", "ref-2" };
            var chatShortcuts = "ref-2;ref-1";

            var comparer = new ChatShortcutsComparer();

            // ACT
            var result = comparer.CompareShortcuts(viewModelShortcuts, chatShortcuts);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_DifferentShortcuts()
        {
            var viewModelShortcuts = new List<object> { "ref-1", "ref-2" };
            var chatShortcuts = "ref-1;ref-3";

            var comparer = new ChatShortcutsComparer();

            // ACT
            var result = comparer.CompareShortcuts(viewModelShortcuts, chatShortcuts);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_NullChatShortcuts()
        {
            var viewModelShortcuts = new List<object> { "ref-1", "ref-2" };

            var comparer = new ChatShortcutsComparer();

            // ACT
            var result = comparer.CompareShortcuts(viewModelShortcuts, null);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_NullViewModelShortcuts()
        {
            var chatShortcuts = "ref-1";

            var comparer = new ChatShortcutsComparer();

            // ACT
            var result = comparer.CompareShortcuts(null, chatShortcuts);

            // ASSERT
            Assert.That(result, Is.False);
        }
    }
}
