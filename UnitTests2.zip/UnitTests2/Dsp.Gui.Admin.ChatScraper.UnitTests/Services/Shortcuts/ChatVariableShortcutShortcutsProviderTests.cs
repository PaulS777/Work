﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Services.Shortcuts
{
    internal interface IChatVariableShortcutShortcutsProviderTestObjects
    {
        ChatVariableShortcutShortcutsProvider ChatVariableShortcutShortcutsProvider { get; }
    }

    [TestFixture]
    public class ChatVariableShortcutShortcutsProviderTests
    {
        private class ChatVariableShortcutShortcutsProviderTestObjectBuilder
        {
            private IEnumerable<ChatVariableShortcut> _chatVariableShortcuts;

            public ChatVariableShortcutShortcutsProviderTestObjectBuilder WithVariableShortcuts(IEnumerable<ChatVariableShortcut> values)
            {
                _chatVariableShortcuts = values;
                return this;
            }

            public IChatVariableShortcutShortcutsProviderTestObjects Build()
            {
                var testObjects = new Mock<IChatVariableShortcutShortcutsProviderTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.Setup(c => c.GetChatVariableShortcutSnapshot())
                                   .Returns(_chatVariableShortcuts);

                var provider = new ChatVariableShortcutShortcutsProvider(curveControlService.Object);

                testObjects.SetupGet(o => o.ChatVariableShortcutShortcutsProvider)
                           .Returns(provider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetSnapshotFromChatVariableShortcuts()
        {
            var chatVariableShortcuts = new[]
            {
                new ChatVariableShortcut(1, EntityStatus.Active, "name", "ref-1;ref-2", new List<ChatVariableShortcutVariation>()),
                new ChatVariableShortcut(2, EntityStatus.Deleted, "name", "ref-3", new List<ChatVariableShortcutVariation>()),
                new ChatVariableShortcut(3, EntityStatus.Active, "name", null, new List<ChatVariableShortcutVariation>()),
                new ChatVariableShortcut(4, EntityStatus.Active, "name", "", new List<ChatVariableShortcutVariation>()),
                new ChatVariableShortcut(5, EntityStatus.Active, "name", "ref-4", new List<ChatVariableShortcutVariation>())
            };

            var testObjects = new ChatVariableShortcutShortcutsProviderTestObjectBuilder().WithVariableShortcuts(chatVariableShortcuts)
                                                                                          .Build();

            // ACT
            var result = testObjects.ChatVariableShortcutShortcutsProvider.GetSnapshot().ToList();

            // ASSERT
            Assert.That(result.Count == 3
                        && result[0] == "ref-1"
                        && result[1] == "ref-2"
                        && result[2] == "ref-4");
        }
    }
}
