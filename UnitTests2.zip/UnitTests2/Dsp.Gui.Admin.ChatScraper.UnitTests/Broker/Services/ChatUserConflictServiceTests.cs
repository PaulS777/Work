﻿using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Broker.Services
{
    [TestFixture]
    public class ChatUserConflictServiceTests
    {
        [Test]
        public void ShouldConstructChatUserRowConflictService()
        {
            var dialogService = new Mock<IChatBrokerAdminMessageDialogService>();

            // ACT
            var chatUserConflictService = new ChatUserItemsConflictService(dialogService.Object);

            // ASSERT
            Assert.IsNotNull(chatUserConflictService);
        }
    }
}
