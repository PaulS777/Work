﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Broker.Services
{
    [TestFixture]
    public class ChatUserDuplicateItemsServiceTests
    {
        [Test]
        public void ShouldSetIsDuplicateTrue_When_MatchingNames()
        {
            var item1 = new ChatUserItemViewModel(Mock.Of<IDisposable>()) { Name = "name" };
            var item2 = new ChatUserItemViewModel(Mock.Of<IDisposable>());

            var items = new List<ChatUserItemViewModel> { item1, item2 };

            var service = new ChatUserDuplicateItemsService();

            service.RefreshItems(items);

            // ACT
            item2.Name = "name";

            // ASSERT
            Assert.That(item1.IsDuplicate, Is.True);
            Assert.That(item2.IsDuplicate, Is.True);
        }
    }
}
