﻿using System;
using Dsp.Gui.Admin.ChatScraper.Broker.Rules;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Broker.Services
{
    [TestFixture]
    public class ChatUserItemValidationServiceTests
    {
        [Test]
        public void ShouldSetIsValidTrue_When_Attach_With_ValidName()
        {
            var viewModel = new ChatUserItemViewModel(Mock.Of<IDisposable>())
            {
                Name = "user"
            };

            var service = new ChatUserItemValidationService(new ChatUserNameRule());

            // ACT
            service.Attach(viewModel);

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_Name_Empty()
        {
            var viewModel = new ChatUserItemViewModel(Mock.Of<IDisposable>())
            {
                Name = "user"
            };

            var service = new ChatUserItemValidationService(new ChatUserNameRule());

            service.Attach(viewModel);

            // ACT
            viewModel.Name = "";

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText, Is.EqualTo("Missing Name"));
        }

        [Test]
        public void ShouldSetIsValidTrue_When_Name_Valid()
        {
            var viewModel = new ChatUserItemViewModel(Mock.Of<IDisposable>())
            {
                Name = ""
            };

            var service = new ChatUserItemValidationService(new ChatUserNameRule());

            service.Attach(viewModel);

            // ACT
            viewModel.Name = "user";

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnIsDuplicateText()
        {
            var service = new ChatUserItemValidationService(new ChatUserNameRule());

            // ACT
            var result = service.IsDuplicateText();

            // ASSERT
            Assert.That(result, Is.EqualTo("Duplicate Name"));
        }
    }
}