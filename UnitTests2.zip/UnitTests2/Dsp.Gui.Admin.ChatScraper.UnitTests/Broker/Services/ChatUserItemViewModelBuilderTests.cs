﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Controllers;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Broker.Services
{
    internal interface IChatUserItemViewModelBuilderTestObjects
    {
        ChatUserItemViewModelBuilder ChatUserItemViewModelBuilder { get; }
    }

    [TestFixture]
    public class ChatUserItemViewModelBuilderTests
    {
        private class ChatUserItemViewModelBuilderTestObjectBuilder
        {
            public IChatUserItemViewModelBuilderTestObjects Build()
            {
                var testObjects = new Mock<IChatUserItemViewModelBuilderTestObjects>();

                var controller = new ChatUserItemViewModelController(Mock.Of<IChatUserItemValidationService>());

                var factory = new Mock<IServiceFactory<IChatUserItemViewModelController>>();

                factory.Setup(f => f.Create())
                       .Returns(controller);

                var builder = new ChatUserItemViewModelBuilder
                              {
                                  Factory = factory.Object
                              };

                testObjects.SetupGet(o => o.ChatUserItemViewModelBuilder).Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCreateNewChatUserRowViewModel()
        {
            var testObjects = new ChatUserItemViewModelBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ChatUserItemViewModelBuilder.CreateNewItem();

            // ASSERT
            Assert.That(result.NewRecord, Is.True);
            Assert.That(result.IsDirty, Is.True);
        }

        [Test]
        public void ShouldCreateChatUserRowViewModel_From_ChatUser()
        {
            var markets = new List<ChatUserMarket>
            {
                new(101, 99, 501)
            };

            var references = new List<ChatUserReference>
            {
                new(401, 99, "ext-ref-1"),
                new(402, 99, "ext-ref-2")
            };

            var chatUser = new ChatUser(10, EntityStatus.Active, "name", markets, references);

            var marketItem = new MarketItemViewModel {MarketId = 501, MarketName = "market-1"};

            var marketItems = new[]
            {
                marketItem,
                new MarketItemViewModel {MarketId = 502, MarketName = "market-2"},
            };

            var testObjects = new ChatUserItemViewModelBuilderTestObjectBuilder().Build();

            // ACT

            var result = testObjects.ChatUserItemViewModelBuilder.CreateItemFromChatUser(chatUser, marketItems);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(10));
            Assert.That(result.Name, Is.EqualTo("name"));

            Assert.That(result.Markets.Count, Is.EqualTo(1));
            Assert.AreSame(marketItem, result.Markets[0]);

            Assert.That(result.References.Count, Is.EqualTo(2));
            Assert.That(result.References[0], Is.EqualTo("ext-ref-1"));
            Assert.That(result.References[1], Is.EqualTo("ext-ref-2"));

            Assert.That(result.IsDirty, Is.False);
        }

        [Test]
        public void ShouldUpdateChatUserRowViewModel_From_ChatUser()
        {
            var markets = new List<ChatUserMarket>
            {
                new(101, 99, 501)
            };

            var references = new List<ChatUserReference>
            {
                new(401, 99, "ext-ref-1"),
                new(402, 99, "ext-ref-2")
            };

            var chatUser = new ChatUser(10, EntityStatus.Active, "name", markets, references);

            var marketItem = new MarketItemViewModel { MarketId = 501, MarketName = "market-1" };

            var marketItems = new[]
            {
                marketItem,
                new MarketItemViewModel {MarketId = 502, MarketName = "market-2"},
            };

            var testObjects = new ChatUserItemViewModelBuilderTestObjectBuilder().Build();

            var rowViewModel = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>());

            // ACT
            testObjects.ChatUserItemViewModelBuilder.UpdateItemFromChatUser(rowViewModel, chatUser, marketItems);

            // ASSERT
            Assert.That(rowViewModel.Name, Is.EqualTo("name"));

            Assert.That(rowViewModel.Markets.Count, Is.EqualTo(1));
            Assert.AreSame(marketItem, rowViewModel.Markets[0]);

            Assert.That(rowViewModel.References.Count, Is.EqualTo(2));
            Assert.That(rowViewModel.References[0], Is.EqualTo("ext-ref-1"));
            Assert.That(rowViewModel.References[1], Is.EqualTo("ext-ref-2"));

            Assert.That(rowViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldUpdateNewChatUserRowViewModelId_From_ChatUser()
        {
            var markets = new List<ChatUserMarket>();
            var references = new List<ChatUserReference>();
            var marketItems = new List<MarketItemViewModel>();

            var chatUser = new ChatUser(10, EntityStatus.Active, "name", markets, references);

            var testObjects = new ChatUserItemViewModelBuilderTestObjectBuilder().Build();

            var rowViewModel = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                NewRecord = true
            };

            // ACT
            testObjects.ChatUserItemViewModelBuilder.UpdateItemFromChatUser(rowViewModel, chatUser, marketItems);

            // ASSERT
            Assert.That(rowViewModel.Id, Is.EqualTo(10));
            Assert.That(rowViewModel.NewRecord, Is.False);
            Assert.That(rowViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldUpdateChatUserRowViewModel_With_MarketItems()
        {
            var marketItems = new List<object>
            {
                new MarketItemViewModel { MarketId = 501, MarketName = "market-1"},
                new MarketItemViewModel { MarketId = 502, MarketName = "market-2"},
            };

            var testObjects = new ChatUserItemViewModelBuilderTestObjectBuilder().Build();

            var rowViewModel = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Markets = marketItems
            };

            var marketItemsUpdate = new[]
            {
                new MarketItemViewModel { MarketId = 501, MarketName = "market-1B"},
                new MarketItemViewModel { MarketId = 503, MarketName = "market-3"},
            };

            // ACT
            testObjects.ChatUserItemViewModelBuilder.UpdateUserMarkets(rowViewModel,  marketItemsUpdate);

            // ASSERT
            Assert.That(rowViewModel.Markets.Count, Is.EqualTo(1));
            Assert.AreSame(marketItemsUpdate[0], rowViewModel.Markets[0]);
        }

        [Test]
        public void ShouldUpdateNotChatUserRowViewModel_With_MarketItems_When_NoneSelected()
        {
            var testObjects = new ChatUserItemViewModelBuilderTestObjectBuilder().Build();

            var rowViewModel = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>());

            var marketItemsUpdate = new[]
            {
                new MarketItemViewModel { MarketId = 501, MarketName = "market-1B"},
                new MarketItemViewModel { MarketId = 503, MarketName = "market-3"},
            };

            // ACT
            testObjects.ChatUserItemViewModelBuilder.UpdateUserMarkets(rowViewModel, marketItemsUpdate);

            // ASSERT
            Assert.IsNull(rowViewModel.Markets);
        }
    }
}
