﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Controllers;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Broker.Controllers
{
    internal interface IChatBrokerUsersAdminViewModelControllerTestObjects
    {
        IChatUserAdminUpdateService ChatUserAdminUpdateService { get; }
        ICurveControlService CurveControlService { get; }
        IChatUserItemViewModelBuilder ChatUserItemViewModelBuilder { get; }
        IChatUserBuilder ChatUserBuilder { get; }
        IChatUserItemCollectionProvider ChatUserItemCollectionProvider { get; }
        IChatUserItemCollectionService ChatUserItemCollectionService { get; }
        IChatBrokerAdminMessageDialogService MessageDialogService { get; }
        IChatUserItemsConflictService ChatUserConflictService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IChatScraperBrokerAdminToolBarService ToolBarService { get; }
        TestScheduler TestScheduler { get; }
        ISubject<Unit> ChatUserUpdateResponse { get; }
        ISubject<IList<ChatUser>> ChatUsers { get; }
        ISubject<List<ChatMarket>> ChatMarkets { get; }
        ISubject<bool> CanExecuteUpdateCommand { get; }
        ISubject<bool> CanExecuteUndoCommand { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        ISubject<Unit> ToolBarUndo { get; }
        ISubject<IList<string>> ValidationErrors { get; }
        ChatBrokerUsersAdminViewModel ViewModel { get; }
        ChatBrokerUsersAdminViewModelController Controller { get; }
    }

    [TestFixture]
    public class ChatBrokerUsersAdminViewModelControllerTests
    {
        private class ChatBrokerUsersAdminViewModelControllerTestObjectBuilder
        {
            private List<ChatUser> _chatUsersSnapshot;
            private List<ChatUserItemViewModel> _itemsProviderResult = new();
            private List<ChatMarket> _chatMarkets = new();
            private ChatUserItemViewModel _newChatUserViewModel;
            private IList<ChatUserItemViewModel> _conflicts = new List<ChatUserItemViewModel>();

            public ChatBrokerUsersAdminViewModelControllerTestObjectBuilder WithChatUsersSnapshot(List<ChatUser> value)
            {
                _chatUsersSnapshot = value;
                return this;
            }

            public ChatBrokerUsersAdminViewModelControllerTestObjectBuilder WithItemsProviderResult(List<ChatUserItemViewModel> values)
            {
                _itemsProviderResult = values;
                return this;
            }

            public ChatBrokerUsersAdminViewModelControllerTestObjectBuilder WithNewChatUserRow(ChatUserItemViewModel value)
            {
                _newChatUserViewModel = value;
                return this;
            }

            public ChatBrokerUsersAdminViewModelControllerTestObjectBuilder WithChatMarkets(List<ChatMarket> value)
            {
                _chatMarkets = value;
                return this;
            }

            public ChatBrokerUsersAdminViewModelControllerTestObjectBuilder WithRowConflicts(IList<ChatUserItemViewModel> values)
            {
                _conflicts = values;
                return this;
            }

            public IChatBrokerUsersAdminViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatBrokerUsersAdminViewModelControllerTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                var chatUsers = new BehaviorSubject<IList<ChatUser>>(null);

                testObjects.SetupGet(o => o.ChatUsers)
                           .Returns(chatUsers);

                curveControlService.SetupGet(c => c.ChatUsers)
                                   .Returns(chatUsers);

                curveControlService.Setup(c => c.GetChatUsersSnapshot())
                                   .Returns(_chatUsersSnapshot);

                var chatMarkets = new BehaviorSubject<List<ChatMarket>>(_chatMarkets);

                testObjects.SetupGet(o => o.ChatMarkets)
                           .Returns(chatMarkets);

                curveControlService.SetupGet(c => c.ChatMarkets)
                                   .Returns(chatMarkets);
                
                curveControlService.Setup(c => c.GetChatMarketSnapshot())
                                   .Returns(_chatMarkets);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService.Object);

                var chatUserUpdateResponse = new Subject<Unit>();
                testObjects.SetupGet(o => o.ChatUserUpdateResponse).Returns(chatUserUpdateResponse);

                var chatUserBuilder = new Mock<IChatUserBuilder>();
                testObjects.SetupGet(o => o.ChatUserBuilder).Returns(chatUserBuilder.Object);

                var chatUserAdminUpdateService = new Mock<IChatUserAdminUpdateService>();

                chatUserAdminUpdateService.Setup(c => c.Update(It.IsAny<IList<ChatUserItemViewModel>>(),
                                                               It.IsAny<IScheduler>(),
                                                               It.IsAny<Func<ChatUserItemViewModel, ChatUser>>(),
                                                               It.IsAny<Func<ChatUserItemViewModel, ChatUser>>(),
                                                               It.IsAny<Func<ChatUserItemViewModel, ChatUser>>()))
                                          .Returns(chatUserUpdateResponse);

                testObjects.SetupGet(o => o.ChatUserAdminUpdateService)
                           .Returns(chatUserAdminUpdateService.Object);

                var chatUserViewModelBuilder = new Mock<IChatUserItemViewModelBuilder>();

                chatUserViewModelBuilder.Setup(b => b.CreateNewItem()).Returns(_newChatUserViewModel);

                testObjects.SetupGet(o => o.ChatUserItemViewModelBuilder).Returns(chatUserViewModelBuilder.Object);

                var chatUserRowCollectionProvider = new Mock<IChatUserItemCollectionProvider>();

                chatUserRowCollectionProvider.Setup(p => p.GetCollection(
                                                              It.IsAny<IList<ChatUserItemViewModel>>(),
                                                              It.IsAny<IList<ChatUser>>(),
                                                              It.IsAny<Func<ChatUserItemViewModel, ChatUser, bool>>(),
                                                              It.IsAny<Action<ChatUserItemViewModel, ChatUser>>(),
                                                              It.IsAny<Func<ChatUser, ChatUserItemViewModel>>()))
                                                   .Returns(_itemsProviderResult);

                testObjects.SetupGet(o => o.ChatUserItemCollectionProvider)
                           .Returns(chatUserRowCollectionProvider.Object);

                var canExecuteUpdateCommand = new Subject<bool>();
                testObjects.SetupGet(o => o.CanExecuteUpdateCommand).Returns(canExecuteUpdateCommand);

                var canExecuteUndoCommand = new Subject<bool>();
                testObjects.SetupGet(o => o.CanExecuteUndoCommand).Returns(canExecuteUndoCommand);

                var validationErrors = new Subject<IList<string>>();
                testObjects.SetupGet(o => o.ValidationErrors).Returns(validationErrors);

                var chatUserRowService = new Mock<IChatUserItemCollectionService>();

                chatUserRowService.SetupGet(c => c.CanExecuteUpdateCommand).Returns(canExecuteUpdateCommand);
                chatUserRowService.SetupGet(c => c.CanExecuteUndoCommand).Returns(canExecuteUndoCommand);
                chatUserRowService.SetupGet(c => c.ValidationErrors).Returns(validationErrors);

                testObjects.SetupGet(o => o.ChatUserItemCollectionService).Returns(chatUserRowService.Object);

                var messageDialogService = new Mock<IChatBrokerAdminMessageDialogService>();
                testObjects.SetupGet(o => o.MessageDialogService).Returns(messageDialogService.Object);

                var chatUserConflictService = new Mock<IChatUserItemsConflictService>();

                chatUserConflictService.Setup(c => c.GetConflicts(It.IsAny<IList<ChatUserItemViewModel>>(), It.IsAny<IEnumerable<ChatUser>>()))
                                       .Returns(_conflicts);

                testObjects.SetupGet(o => o.ChatUserConflictService).Returns(chatUserConflictService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();
                testObjects.SetupGet(o => o.PopupNotificationService).Returns(popupNotificationService.Object);

                var toolBarUpdate = new Subject<Unit>();
                testObjects.SetupGet(o => o.ToolBarUpdate).Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();
                testObjects.SetupGet(o => o.ToolBarUndo).Returns(toolBarUndo);

                var toolBarService = new Mock<IChatScraperBrokerAdminToolBarService>();

                toolBarService.SetupGet(tb => tb.Update).Returns(toolBarUpdate);
                toolBarService.SetupGet(tb => tb.Undo).Returns(toolBarUndo);

                testObjects.SetupGet(o => o.ToolBarService).Returns(toolBarService.Object);

                var controller = new ChatBrokerUsersAdminViewModelController(
                    curveControlService.Object,
                    chatUserViewModelBuilder.Object,
                    chatUserRowCollectionProvider.Object,
                    chatUserRowService.Object,
                    toolBarService.Object,
                    Mocks.GetSchedulerProvider().Object,
                    Mocks.GetLoggerFactory().Object)
                {
                    PopupNotificationService = popupNotificationService.Object,
                    ErrorMessageDialogService = messageDialogService.Object,
                    ChatUserConflictService = chatUserConflictService.Object,
                    ChatUserBuilder = chatUserBuilder.Object,
                    ChatUserAdminUpdateService = chatUserAdminUpdateService.Object,
                };

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                controller.ViewModel.ChatUserItems = new ObservableCollection<ChatUserItemViewModel>();

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPopulateMarketItems_From_ActiveMarkets()
        {
            var chatUserRows = new List<ChatUserItemViewModel>
            {
                new(Mock.Of<IChatUserItemViewModelController>())
            };

            var chatUsers = new List<ChatUser>
            {
                new(1, EntityStatus.Active, "chat_user_1", new List<ChatUserMarket>(), new List<ChatUserReference>()),
                new(2, EntityStatus.Deleted, "chat_user_2", new List<ChatUserMarket>(), new List<ChatUserReference>())
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(100, EntityStatus.Active, "market_1"),
                new(101, EntityStatus.Deleted, "market_2")
            };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(chatUserRows)
                                                                                            .WithChatMarkets(chatMarkets)
                                                                                            .Build();
            // ACT
            testObjects.ChatUsers.OnNext(chatUsers);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatUserItems.Count, Is.EqualTo(1));

            Assert.That(testObjects.ViewModel.MarketItems.Count, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.MarketItems[0].MarketName, Is.EqualTo("market_1"));
            Assert.That(testObjects.ViewModel.MarketItems[0].MarketId, Is.EqualTo(100));
        }

        [Test]
        public void ShouldPopulateItemsWithMarkets_From_ActiveChatUsers_And_ActiveMarkets()
        {
            var row = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>()) {Name = "name-1"};
            row.SetChatUser(new ChatUser(0, EntityStatus.Active, "name-1", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var chatUserRows = new List<ChatUserItemViewModel> {row};

            var user = new ChatUser(1, EntityStatus.Active, "name-1", new List<ChatUserMarket>(), new List<ChatUserReference>());

            var chatUsers = new List<ChatUser> {user};

            var chatMarkets = new List<ChatMarket>
            {
                new(100, EntityStatus.Active, "market-1"),
            };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithChatMarkets(chatMarkets)
                                                                                            .Build();

            var comparerResult = false;

            Mock.Get(testObjects.ChatUserItemCollectionProvider)
                .Setup(p => p.GetCollection(
                           It.IsAny<IList<ChatUserItemViewModel>>(),
                           It.IsAny<IList<ChatUser>>(),
                           It.IsAny<Func<ChatUserItemViewModel, ChatUser, bool>>(),
                           It.IsAny<Action<ChatUserItemViewModel, ChatUser>>(),
                           It.IsAny<Func<ChatUser, ChatUserItemViewModel>>()))
                .Returns(chatUserRows)
                .Callback<IList<ChatUserItemViewModel>,
                         IList<ChatUser>,
                         Func<ChatUserItemViewModel, ChatUser, bool>,
                         Action<ChatUserItemViewModel, ChatUser>,
                         Func<ChatUser, ChatUserItemViewModel>>
                     ((_, _, comparer, updater, builder) =>
                     {
                         comparerResult = comparer(row, user);
                         updater(row, user);
                         builder(user);
                     });

            // ACT
            testObjects.ChatUsers.OnNext(chatUsers);

            // ASSERT
            Assert.That(comparerResult, Is.True);

            Mock.Get(testObjects.ChatUserItemViewModelBuilder)
                .Verify(b => b.UpdateItemFromChatUser(row, user, testObjects.ViewModel.MarketItems));

            Mock.Get(testObjects.ChatUserItemViewModelBuilder)
                .Verify(b => b.CreateItemFromChatUser(user, testObjects.ViewModel.MarketItems));
        }

        [Test]
        public void ShouldUpdateItemsWithMarkets_From_MarketsUpdates()
        {
            var item = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>()) { Name = "name-1" };

            item.SetChatUser(new ChatUser(0, EntityStatus.Active, "name-1", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var items = new List<ChatUserItemViewModel> { item };

            var user = new ChatUser(1, EntityStatus.Active, "name-1", new List<ChatUserMarket>(), new List<ChatUserReference>());

            var chatUsers = new List<ChatUser> { user };

            var chatMarkets = new List<ChatMarket>
            {
                new(100, EntityStatus.Active, "market-1"),
            };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                            .WithChatMarkets(chatMarkets)
                                                                                            .Build();
            testObjects.ChatUsers.OnNext(chatUsers);

            var chatMarketsUpdate = new List<ChatMarket>
            {
                new(100, EntityStatus.Active, "market-2"),
            };

            // ACT
            testObjects.ChatMarkets.OnNext(chatMarketsUpdate);

            // ASSERT
            Mock.Get(testObjects.ChatUserItemViewModelBuilder)
                .Verify(b => b.UpdateUserMarkets(item, It.Is<ObservableCollection<MarketItemViewModel>>(i => i.Count == 1)));
        }

        [Test]
        public void ShouldCheckConflicts_OnUsersUpdate()
        {
            var user = new ChatUser(1, EntityStatus.Active, "name-1", new List<ChatUserMarket>(), new List<ChatUserReference>());

            var chatUsers = new List<ChatUser> { user };

            var chatMarkets = new List<ChatMarket>
            {
                new(100, EntityStatus.Active, "market-1"),
            };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithChatMarkets(chatMarkets)
                                                                                            .Build();
            // ACT
            testObjects.ChatUsers.OnNext(chatUsers);

            // ASSERT
            Mock.Get(testObjects.ChatUserConflictService)
                .Verify(c => c.GetConflicts(It.IsAny<IList<ChatUserItemViewModel>>(), chatUsers));
        }

        [Test]
        public void ShouldShowMessageDialog_WhenConflicts()
        {
            var user = new ChatUser(1, EntityStatus.Active, "name-1", new List<ChatUserMarket>(), new List<ChatUserReference>());

            var chatUsers = new List<ChatUser> { user };

            var chatMarkets = new List<ChatMarket>
            {
                new(100, EntityStatus.Active, "market-1"),
            };

            var conflicts = new List<ChatUserItemViewModel> {new(Mock.Of<IDisposable>()){Name = "name"}};

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithChatMarkets(chatMarkets)
                                                                                            .WithRowConflicts(conflicts)
                                                                                            .Build();
            // ACT
            testObjects.ChatUsers.OnNext(chatUsers);

            // ASSERT
            Mock.Get(testObjects.ChatUserConflictService)
                .Verify(c => c.ShowConflictsDialog(It.Is<IEnumerable<string>>(s => s.ToArray().Length == 1)));
        }

        [Test]
        public void ShouldEnableUpdateCommand_OnCanExecuteUpdateCommandTrue()
        {
            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CanExecuteUpdateCommand.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldEnableUndoCommand_OnCanExecuteUndoCommandTrue()
        {
            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CanExecuteUndoCommand.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(true));
        }

        [Test]
        public void ShouldInvokeChatUserRowService_On_AddChatUserCommand()
        {
            var item1 = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "chat_user_1", IsValid = true
            };
            item1.SetChatUser(new ChatUser(1, EntityStatus.Active, "chat_user_1", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var item2 = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "chat_user_2", IsValid = true, NewRecord = true
            };
            item2.SetChatUser(new ChatUser(2, EntityStatus.Active, "chat_user_2", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var items = new List<ChatUserItemViewModel> { item1 };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                            .WithNewChatUserRow(item2)
                                                                                            .Build();
            // ACT
            testObjects.ViewModel.AddChatUserCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ChatUserItemCollectionService)
                .Verify(c => c.AddNewItem(item2, It.IsAny<IList<ChatUserItemViewModel>>(), testObjects.ViewModel));
        }

        [Test]
        public void ShouldRefreshItems_On_ToolBarUndo()
        {
            var chatUser = new ChatUser(1, EntityStatus.Active, "chat_user_1", new List<ChatUserMarket>(), new List<ChatUserReference>());

            var chatUsers = new List<ChatUser> { chatUser };

            var items = new List<ChatUserItemViewModel> { new(Mock.Of<IChatUserItemViewModelController>()) };

            var chatMarket = new ChatMarket(100, EntityStatus.Active, "market");

            var chatMarkets = new List<ChatMarket> { chatMarket };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithChatUsersSnapshot(chatUsers)
                                                                                            .WithChatMarkets(chatMarkets)
                                                                                            .Build();

            Mock.Get(testObjects.ChatUserItemCollectionProvider)
                .Setup(p => p.GetCollectionReset(It.IsAny<IList<ChatUser>>(),
                                                    It.IsAny<Func<ChatUser, ChatUserItemViewModel>>()))
                .Returns(items)
                .Callback<IList<ChatUser>, Func<ChatUser, ChatUserItemViewModel>>
                 ((_, builder) =>
                 {
                     builder(chatUser);
                 });


            testObjects.ViewModel.ChatUserItems = new ObservableCollection<ChatUserItemViewModel>
            {
                new(Mock.Of<IChatUserItemViewModelController>()),
                new(Mock.Of<IChatUserItemViewModelController>())
            };

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatUserItems.Count, Is.EqualTo(1));

            Mock.Get(testObjects.ChatUserItemCollectionService)
                .Verify(c => c.RefreshItems(It.IsAny<IList<ChatUserItemViewModel>>()));
        }

        [Test]
        public void ShouldSetIsBusy_On_ToolBarUpdate()
        {
            var items = new List<ChatUserItemViewModel> { new(Mock.Of<IChatUserItemViewModelController>()) };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                            .Build();

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void Should_InvokeAdminUpdateService_With_BuilderFunctions_On_ToolBarUpdate()
        {
            var item = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>());

            var items = new List<ChatUserItemViewModel> { new(Mock.Of<IChatUserItemViewModelController>())};

            var chatMarkets = new List<ChatMarket>
            {
                new(100, EntityStatus.Active, "market_1"),
                new(101, EntityStatus.Deleted, "market_2")
            };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                            .WithChatMarkets(chatMarkets)
                                                                                            .Build();
            Mock.Get(testObjects.ChatUserAdminUpdateService)
                .Setup(c => c.Update(It.IsAny<IList<ChatUserItemViewModel>>(),
                                     It.IsAny<IScheduler>(),
                                     It.IsAny<Func<ChatUserItemViewModel, ChatUser>>(),
                                     It.IsAny<Func<ChatUserItemViewModel, ChatUser>>(),
                                     It.IsAny<Func<ChatUserItemViewModel, ChatUser>>()))

                .Returns(Observable.Return(Unit.Default))
                .Callback<IList<ChatUserItemViewModel>,
                     IScheduler,
                     Func<ChatUserItemViewModel, ChatUser>,
                     Func<ChatUserItemViewModel, ChatUser>,
                     Func<ChatUserItemViewModel, ChatUser>>
                 ((_, _, func1, func2, func3) =>
                 {
                     func1(item);
                     func2(item);
                     func3(item);
                 });

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ChatUserBuilder).Verify(b => b.GetNewChatUser(item, chatMarkets), Times.Once);
            Mock.Get(testObjects.ChatUserBuilder).Verify(b => b.GetUpdatedChatUser(item, chatMarkets), Times.Once);
            Mock.Get(testObjects.ChatUserBuilder).Verify(b => b.GetDeletedChatUser(item, chatMarkets), Times.Once);
        }

        [Test]
        public void ShouldShowPopupAndSetIsBusyFalse_On_UpdateCompleted()
        {
            var item1 = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "chat_user_1", IsValid = true
            };
            item1.SetChatUser(new ChatUser(1, EntityStatus.Active, "chat_user_1", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var item2 = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "chat_user_2", IsValid = true, IsDirty = true
            };
            item2.SetChatUser(new ChatUser(2, EntityStatus.Active, "chat_user_2", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var items = new List<ChatUserItemViewModel> { item1, item2 };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                            .Build();
            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ChatUserUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), null));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        [Test]
        public void ShouldSetIsBusyFalse_And_ShowDialog_On_UpdateFailed()
        {
            var item1 = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "chat_user_1", IsValid = true
            };
            item1.SetChatUser(new ChatUser(1, EntityStatus.Active, "chat_user_1", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var item2 = new ChatUserItemViewModel(Mock.Of<IChatUserItemViewModelController>())
            {
                Name = "chat_user_2", IsValid = true, IsDirty = true
            };
            item2.SetChatUser(new ChatUser(1, EntityStatus.Active, "chat_user_2", new List<ChatUserMarket>(), new List<ChatUserReference>()));

            var items = new List<ChatUserItemViewModel> { item1, item2 };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().WithItemsProviderResult(items)
                                                                                            .Build();

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ChatUserUpdateResponse.OnError(new Exception("failed"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);

            Mock.Get(testObjects.MessageDialogService)
                .Verify(md => md.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "failed"
                                                                          && args.ShowSendFeedback)));

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), null), Times.Never);
        }

        [Test]
        public void ShouldSetValidationErrors_When_Errors()
        {
            var errors = new List<string> { "error" };

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetValidationErrors(errors));
        }

        [Test]
        public void ShouldClearValidationErrors_When_NoErrors()
        {
            var errors = new List<string>();

            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.ClearValidation());
        }

        [Test]
        public void ShouldNotEnableUpdateCommand_WhenDisposed()
        {
            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.CanExecuteUpdateCommand.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(It.IsAny<bool>()), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_WhenDisposed()
        {
            var testObjects = new ChatBrokerUsersAdminViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.CanExecuteUpdateCommand.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(It.IsAny<bool>()), Times.Never);
        }
    }
}
