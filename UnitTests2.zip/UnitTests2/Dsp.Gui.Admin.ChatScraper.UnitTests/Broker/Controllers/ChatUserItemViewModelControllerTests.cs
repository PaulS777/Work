﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Controllers;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Broker.Controllers
{
    internal interface IChatUserItemViewModelControllerTestObjects
    {
        IChatUserItemValidationService ValidationService { get; }
        ChatUserItemViewModelController Controller { get; }
        ChatUserItemViewModel ViewModel { get; }
    }

    [TestFixture]
    public class ChatUserItemViewModelControllerTests
    {
        private class ChatUserItemViewModelControllerTestObjectBuilder
        {
            private string _name;
            private ChatUser _chatUser;
            private IList<MarketItemViewModel> _marketItems;
            private IList<string> _references;

            public ChatUserItemViewModelControllerTestObjectBuilder WithName(string value)
            {
                _name = value;
                return this;
            }

            public ChatUserItemViewModelControllerTestObjectBuilder WithChatUser(ChatUser value)
            {
                _chatUser = value;
                return this;
            }

            public ChatUserItemViewModelControllerTestObjectBuilder WithMarketItems(IList<MarketItemViewModel> values)
            {
                _marketItems = values;
                return this;
            }

            public ChatUserItemViewModelControllerTestObjectBuilder WithReferences(IList<string> values)
            {
                _references = values;
                return this;
            }

            public IChatUserItemViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatUserItemViewModelControllerTestObjects>();

                var rowValidation = new Mock<IChatUserItemValidationService>();

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(rowValidation.Object);

                var controller = new ChatUserItemViewModelController(rowValidation.Object);
                
                controller.ViewModel.SetChatUser(_chatUser);

                controller.ViewModel.Name = _name;
                controller.ViewModel.Markets = _marketItems?.Cast<object>().ToList();
                controller.ViewModel.References = _references?.Cast<object>().ToList();

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachValidation()
        {
            // ACT
            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSetIsDeleted_OnDeleteCommand()
        {
            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.True);
        }

        [Test]
        public void ShouldSetIsDeletedFalse_OnUndoDeleteCommand()
        {
            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.DeleteCommand.Execute();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.False);
            Assert.That(testObjects.ViewModel.DeleteCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_AllRowValuesInitialized()
        {
            var chatUserMarkets = new List<ChatUserMarket>();
            var chatUserReferences = new List<ChatUserReference>();

            var chatUser = new ChatUser(10, EntityStatus.Active, "name-1", chatUserMarkets, chatUserReferences);

            var marketItems = new List<MarketItemViewModel>();
            var references = new List<string>();

            // ACT
            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().WithChatUser(chatUser)
                                                                                    .WithMarketItems(marketItems)
                                                                                    .WithReferences(references)
                                                                                    .WithName("name-1")
                                                                                    .Build();
            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_NameChanged()
        {
            var chatUserMarkets = new List<ChatUserMarket>();
            var chatUserReferences = new List<ChatUserReference>();

            var chatUser = new ChatUser(10, EntityStatus.Active, "name-1", chatUserMarkets, chatUserReferences);

            var marketItems = new List<MarketItemViewModel>();
            var references = new List<string>();

            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().WithChatUser(chatUser)
                                                                                    .WithMarketItems(marketItems)
                                                                                    .WithReferences(references)
                                                                                    .WithName("name-1")
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.Name = "name-2";

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldTrimSpaces_OnName()
        {
            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.Name = " name-2 ";

            // ASSERT
            Assert.That(testObjects.ViewModel.Name, Is.EqualTo("name-2"));
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_MarketsChanged()
        {
            var chatUserMarkets = new List<ChatUserMarket>();
            var chatUserReferences = new List<ChatUserReference>();

            var chatUser = new ChatUser(10, EntityStatus.Active, "name-1", chatUserMarkets, chatUserReferences);

            var marketItems = new [] {new MarketItemViewModel {MarketId = 101}};

            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().WithChatUser(chatUser)
                                                                                    .WithMarketItems(marketItems)
                                                                                    .WithName("name-1")
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.Markets = new object[] {new MarketItemViewModel {MarketId = 102}};

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_MarketsRemoved()
        {
            var chatUserMarkets = new List<ChatUserMarket>();
            var chatUserReferences = new List<ChatUserReference>();

            var chatUser = new ChatUser(10, EntityStatus.Active, "name-1", chatUserMarkets, chatUserReferences);

            var marketItems = new[] { new MarketItemViewModel { MarketId = 101 } };

            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().WithChatUser(chatUser)
                                                                                    .WithMarketItems(marketItems)
                                                                                    .WithName("name-1")
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.References = null;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_ReferencesChanged()
        {
            var chatUserMarkets = new List<ChatUserMarket>();
            var chatUserReferences = new List<ChatUserReference>(new[] { new ChatUserReference(101, 10, "ref") });

            var chatUser = new ChatUser(10, EntityStatus.Active, "name-1", chatUserMarkets, chatUserReferences);

            var references = new[] {"ref-1"};

            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().WithChatUser(chatUser)
                                                                                    .WithReferences(references)
                                                                                    .WithName("name-1")
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.References = new object[] {"ref-2"};

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_ReferencesRemoved()
        {
            var chatUserMarkets = new List<ChatUserMarket>();
            var chatUserReferences = new List<ChatUserReference>(new[] { new ChatUserReference(101, 10, "ref") });

            var chatUser = new ChatUser(10, EntityStatus.Active, "name-1", chatUserMarkets, chatUserReferences);

            var references = new[] { "ref-1" };

            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().WithChatUser(chatUser)
                                                                                    .WithReferences(references)
                                                                                    .WithName("name-1")
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.References = null;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldDisposeRowValidation_On_Dispose()
        {
            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ChatUserItemViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Dispose(), Times.Once);
        }
    }
}
