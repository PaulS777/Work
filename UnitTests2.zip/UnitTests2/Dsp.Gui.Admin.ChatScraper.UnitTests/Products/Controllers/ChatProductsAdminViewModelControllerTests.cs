﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.ChatScraper.Product.Controllers;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Products.Controllers
{
    internal interface IChatProductAdminViewModelControllerTestObjects
    {
        IChatIceMapAdminUpdateService ChatIceMapAdminUpdateService { get; }
        IChatIceMapBuilder ChatIceMapBuilder { get; }
        IChatProductItemViewModelBuilder ChatIceMapRowViewModelBuilder { get; }
        IChatProductItemCollectionProvider ChatIceMapRowCollectionProvider { get; }
        ICurveControlService CurveControlService { get; }
        IChatProductItemCollectionService ChatProductItemCollectionService { get; }
        IDeletedProductItemMappingsObserver DeletedProductItemMappingsObserver { get; }
        IDuplicateShortcutsService DuplicateShortcutsService { get; }
        IChatProductItemFilterService ChatIceMapFilterService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IChatScraperProductAdminToolBarService ToolBarService { get; }
        ISubject<List<ChatIceMap>> ChatIceMaps { get; }
        ISubject<List<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        ISubject<List<ChatMarket>> ChatMarkets { get; }
        ISubject<bool> HasDeletedWithExistingMappings { get; }
        ISubject<Unit> IceChatMapUpdateResponse { get; }
        ISubject<bool> CanExecuteUpdateCommand { get; }
        ISubject<bool> CanExecuteUndoCommand { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        ISubject<Unit> ToolBarUndo { get; }
        ISubject<IList<string>> ValidationErrors { get; }
        ChatProductsAdminViewModelController Controller { get; }
        ChatProductsAdminViewModel ViewModel { get; }
    }

    [TestFixture]
    public class ChatProductAdminViewModelControllerTests
    {
        private class ChatProductAdminViewModelControllerTestObjectBuilder
        {
            private List<ChatMarket> _chatMarkets;
            private List<ChatIceMap> _chatIceMaps;
            private List<ChatIceMap> _chatIceMapSnapshot;
            private IEnumerable<ChatVariableShortcut> _chatVariableShortcuts;
            private List<PriceCurveDefinition> _priceCurveDefinitions;
            private List<ChatProductItemViewModel> _rowCollectionProviderResult;
            private List<ChatProductItemViewModel> _rowCollectionResetResult;
            private List<ChatProductItemViewModel> _filteredRows = new();
            private ObservableCollection<ChatProductItemViewModel> _chatIceMapRows;
            private ChatProductItemViewModel _newChatProductItem;

            public ChatProductAdminViewModelControllerTestObjectBuilder WithChatIceMaps(List<ChatIceMap> values)
            {
                _chatIceMaps = values;
                return this;
            }

            public ChatProductAdminViewModelControllerTestObjectBuilder WithChatIceMapsSnapshot(List<ChatIceMap> values)
            {
                _chatIceMapSnapshot = values;
                return this;
            }

            public ChatProductAdminViewModelControllerTestObjectBuilder WithChatMarkets(List<ChatMarket> values)
            {
                _chatMarkets = values;
                return this;
            }

            public ChatProductAdminViewModelControllerTestObjectBuilder WithChatVariableShortcuts(IEnumerable<ChatVariableShortcut> values)
            {
                _chatVariableShortcuts = values;
                return this;
            }

            public ChatProductAdminViewModelControllerTestObjectBuilder WithPriceCurveDefinitions(List<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public ChatProductAdminViewModelControllerTestObjectBuilder WithRowCollectionProviderResult(List<ChatProductItemViewModel> values)
            {
                _rowCollectionProviderResult = values;
                return this;
            }

            public ChatProductAdminViewModelControllerTestObjectBuilder WithRowCollectionResetResult(List<ChatProductItemViewModel> values)
            {
                _rowCollectionResetResult = values;
                return this;
            }

            public ChatProductAdminViewModelControllerTestObjectBuilder WithFilteredRows(List<ChatProductItemViewModel> values)
            {
                _filteredRows = values;
                return this;
            }
            public ChatProductAdminViewModelControllerTestObjectBuilder WithChatIceMapRows(ObservableCollection<ChatProductItemViewModel> values)
            {
                _chatIceMapRows = values;
                return this;
            }

            public ChatProductAdminViewModelControllerTestObjectBuilder WithNewChatIceMapRow(ChatProductItemViewModel value)
            {
                _newChatProductItem = value;
                return this;
            }

            public IChatProductAdminViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatProductAdminViewModelControllerTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                var chatIceMaps = new BehaviorSubject<List<ChatIceMap>>(_chatIceMaps);

                testObjects.SetupGet(o => o.ChatIceMaps)
                           .Returns(chatIceMaps);

                curveControlService.SetupGet(c => c.ChatIceMaps)
                                   .Returns(chatIceMaps);

                curveControlService.Setup(c => c.GetChatIceMapSnapshot())
                                   .Returns(_chatIceMapSnapshot);

                curveControlService.Setup(c => c.GetChatVariableShortcutSnapshot())
                                   .Returns(_chatVariableShortcuts);

                var chatMarkets = new BehaviorSubject<List<ChatMarket>>(_chatMarkets);

                testObjects.SetupGet(o => o.ChatMarkets)
                           .Returns(chatMarkets);

                curveControlService.SetupGet(c => c.ChatMarkets)
                                   .Returns(chatMarkets);

                curveControlService.Setup(c => c.GetChatMarketSnapshot())
                                   .Returns(_chatMarkets);

                var priceCurveDefinitions = new BehaviorSubject<List<PriceCurveDefinition>>(_priceCurveDefinitions);

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurveDefinitions);

                curveControlService.SetupGet(c => c.PriceCurveDefinitions)
                                   .Returns(priceCurveDefinitions);

                curveControlService.Setup(c => c.GetPriceCurveDefinitionsSnapshot())
                                   .Returns(_priceCurveDefinitions);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService.Object);

                var chatIceMapUpdateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.IceChatMapUpdateResponse)
                           .Returns(chatIceMapUpdateResponse);

                var chatIceMapAdminUpdateService = new Mock<IChatIceMapAdminUpdateService>();

                chatIceMapAdminUpdateService.Setup(c => c.Update(It.IsAny<IList<ChatProductItemViewModel>>(),
                                                                 It.IsAny<IScheduler>(),
                                                                 It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>(),
                                                                 It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>(),
                                                                 It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>()))
                                            .Returns(chatIceMapUpdateResponse);

                testObjects.SetupGet(o => o.ChatIceMapAdminUpdateService)
                           .Returns(chatIceMapAdminUpdateService.Object);

                var chatIceMapBuilder = new Mock<IChatIceMapBuilder>();

                testObjects.SetupGet(o => o.ChatIceMapBuilder)
                           .Returns(chatIceMapBuilder.Object);

                var chatProductsViewModelBuilder = new Mock<IChatProductItemViewModelBuilder>();

                chatProductsViewModelBuilder.Setup(b => b.CreateNewItem())
                                            .Returns(_newChatProductItem);

                testObjects.SetupGet(o => o.ChatIceMapRowViewModelBuilder)
                           .Returns(chatProductsViewModelBuilder.Object);

                var rowCollectionProvider = new Mock<IChatProductItemCollectionProvider>();

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var toolBarUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUpdate)
                           .Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUndo)
                           .Returns(toolBarUndo);

                var toolBarService = new Mock<IChatScraperProductAdminToolBarService>();

                toolBarService.SetupGet(tb => tb.Update)
                              .Returns(toolBarUpdate);

                toolBarService.SetupGet(tb => tb.Undo)
                              .Returns(toolBarUndo);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBarService.Object);

                rowCollectionProvider.Setup(p => p.GetCollection(It.IsAny<IList<ChatProductItemViewModel>>(),
                                                                 It.IsAny<IList<ChatIceMap>>(),
                                                                 It.IsAny<Func<ChatProductItemViewModel, ChatIceMap, bool>>(),
                                                                 It.IsAny<Action<ChatProductItemViewModel, ChatIceMap>>(),
                                                                 It.IsAny<Func<ChatIceMap, ChatProductItemViewModel>>()))
                                     .Returns(_rowCollectionProviderResult);

                rowCollectionProvider.Setup(p => p.GetCollectionReset(It.IsAny<IList<ChatIceMap>>(),
                                                                         It.IsAny<Func<ChatIceMap, ChatProductItemViewModel>>()))
                                     .Returns(_rowCollectionResetResult);

                testObjects.SetupGet(o => o.ChatIceMapRowCollectionProvider)
                           .Returns(rowCollectionProvider.Object);

                var canExecuteUpdateCommand = new Subject<bool>();

                testObjects.SetupGet(o => o.CanExecuteUpdateCommand)
                           .Returns(canExecuteUpdateCommand);

                var canExecuteUndoCommand = new Subject<bool>();

                testObjects.SetupGet(o => o.CanExecuteUndoCommand)
                           .Returns(canExecuteUndoCommand);

                var validationErrors = new Subject<IList<string>>();

                testObjects.SetupGet(o => o.ValidationErrors)
                           .Returns(validationErrors);

                var chatIceMapRowService = new Mock<IChatProductItemCollectionService>();

                chatIceMapRowService.SetupGet(c => c.CanExecuteUpdateCommand)
                                    .Returns(canExecuteUpdateCommand);

                chatIceMapRowService.SetupGet(c => c.CanExecuteUndoCommand)
                                    .Returns(canExecuteUndoCommand);

                chatIceMapRowService.SetupGet(c => c.ValidationErrors)
                                    .Returns(validationErrors);

                testObjects.SetupGet(o => o.ChatProductItemCollectionService)
                           .Returns(chatIceMapRowService.Object);

                var filterService = new Mock<IChatProductItemFilterService>();

                filterService.Setup(f => f.RefreshItems(It.IsAny<IList<ChatProductItemViewModel>>(), It.IsAny<string>()))
                             .Returns(_filteredRows);

                filterService.Setup(f => f.FilterItems(It.IsAny<string>()))
                             .Returns(_filteredRows);

                testObjects.SetupGet(o => o.ChatIceMapFilterService)
                           .Returns(filterService.Object);

                var duplicateShortcutsService = new Mock<IChatVariableShortcutDuplicateShortcutsService>();

                testObjects.SetupGet(o => o.DuplicateShortcutsService)
                           .Returns(duplicateShortcutsService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var hasDeletedWithExistingMappings = new BehaviorSubject<bool>(false);

                testObjects.SetupGet(o => o.HasDeletedWithExistingMappings)
                           .Returns(hasDeletedWithExistingMappings);

                var deletedRowMappingsObserver = new Mock<IDeletedProductItemMappingsObserver>();

                deletedRowMappingsObserver.SetupGet(d => d.HasDeletedWithExistingMappings)
                                          .Returns(hasDeletedWithExistingMappings);

                testObjects.SetupGet(o => o.DeletedProductItemMappingsObserver)
                           .Returns(deletedRowMappingsObserver.Object);

                var controller = new ChatProductsAdminViewModelController(curveControlService.Object,
                                                                          chatProductsViewModelBuilder.Object,
                                                                          rowCollectionProvider.Object,
                                                                          chatIceMapRowService.Object,
                                                                          filterService.Object,
                                                                          duplicateShortcutsService.Object,
                                                                          deletedRowMappingsObserver.Object,
                                                                          toolBarService.Object,
                                                                          Mocks.GetSchedulerProvider().Object,
                                                                          Mocks.GetLoggerFactory().Object)
                {
                    PopupNotificationService = popupNotificationService.Object,
                    ChatIceMapAdminUpdateService = chatIceMapAdminUpdateService.Object,
                    ChatIceMapBuilder = chatIceMapBuilder.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object
                };

                if (_chatIceMapRows != null)
                {
                    controller.ViewModel.ChatProductItems = _chatIceMapRows;
                }

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldStartWithCanShowMappedRowsOnlyTrue()
        {
            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.CanFilterRows, Is.True);
        }

        [Test]
        public void ShouldPopulatePriceCurveItems_From_PriceCurveDefinitions_OrderedByName()
        {
            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                                   .WithName("curve-B")
                                                                                   .Build();

            var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                   .WithName("curve-A")
                                                                                   .Build();
            var priceCurves = new List<PriceCurveDefinition>
            {
                priceCurveDefinition1,
                priceCurveDefinition2
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market")
            };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatMarkets(chatMarkets)
                                                                                        .Build();

            // ACT
            testObjects.PriceCurveDefinitions.OnNext(priceCurves);

            // ASSERT
            Assert.That(testObjects.ViewModel.PriceCurveDefinitionItems.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.PriceCurveDefinitionItems[0].Name, Is.EqualTo("curve-A"));
        }

        [Test]
        public void ShouldPopulateChatMarketItems_From_ChatMarkets_OrderedByMarket()
        {
            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                   .WithName("curve-A")
                                                                                   .Build();
            var priceCurves = new List<PriceCurveDefinition>
            {
                priceCurveDefinition1
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market-B"),
                new(22, EntityStatus.Active, "market-A")
            };

            // ACT
            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                        .Build();

            // ACT
            testObjects.ChatMarkets.OnNext(chatMarkets);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatMarketItems.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.ChatMarketItems[0].Name, Is.EqualTo("market-A"));
        }

        [Test]
        public void ShouldPopulateChatIceMapRows_From_ChatIceMapUpdate()
        {
            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                   .WithName("curve-A")
                                                                                   .Build();

            var iceMaps = new List<ChatIceMap>
            {
                new(10, EntityStatus.Active, priceCurveDefinition1.Name, 51, priceCurveDefinition1.Id, "")
            };

            var iceMapRows = new List<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market")
            };

            var priceCurves = new List<PriceCurveDefinition>
            {
                priceCurveDefinition1
            };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithRowCollectionProviderResult(iceMapRows)
                                                                                        .WithChatMarkets(chatMarkets)
                                                                                        .WithPriceCurveDefinitions(priceCurves)
                                                                                        .WithFilteredRows(iceMapRows)
                                                                                        .Build();
            // ACT
            testObjects.ChatIceMaps.OnNext(iceMaps);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatProductItems.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldInvokeBuilderFunctions_WithRowProvider()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .Build();

            var priceCurveDefinitionItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var iceMap = new ChatIceMap(10, EntityStatus.Active, "ice-code", 51, priceCurveDefinition.Id, "");
            var iceMaps = new List<ChatIceMap> { iceMap };

            var iceMapRow = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveDefinition = priceCurveDefinitionItem };
            var iceMapRows = new List<ChatProductItemViewModel> { iceMapRow };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market")
            };

            var priceCurves = new List<PriceCurveDefinition>
            {
                priceCurveDefinition
            };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatMarkets(chatMarkets)
                                                                                        .WithPriceCurveDefinitions(priceCurves)
                                                                                        .Build();
            var comparerResult = false;

            Mock.Get(testObjects.ChatIceMapRowCollectionProvider)
                .Setup(p => p.GetCollection(It.IsAny<IList<ChatProductItemViewModel>>(),
                                            It.IsAny<IList<ChatIceMap>>(),
                                            It.IsAny<Func<ChatProductItemViewModel, ChatIceMap, bool>>(),
                                            It.IsAny<Action<ChatProductItemViewModel, ChatIceMap>>(),
                                            It.IsAny<Func<ChatIceMap, ChatProductItemViewModel>>()))
                .Returns(iceMapRows)
                .Callback<IList<ChatProductItemViewModel>,
                          IList<ChatIceMap>,
                          Func<ChatProductItemViewModel, ChatIceMap, bool>,
                          Action<ChatProductItemViewModel, ChatIceMap>,
                          Func<ChatIceMap, ChatProductItemViewModel>>
                 ((_, _, comparer, updater, builder) =>
                 {
                     comparerResult = comparer(iceMapRow, iceMap);
                     updater(iceMapRow, iceMap);
                     builder(iceMap);
                 });

            // ACT
            testObjects.ChatIceMaps.OnNext(iceMaps);

            // ASSERT
            Assert.That(comparerResult, Is.True);

            Mock.Get(testObjects.ChatIceMapRowViewModelBuilder)
                .Verify(b => b.UpdateItemFromChatIceMap(iceMapRow, iceMap, testObjects.ViewModel.PriceCurveDefinitionItems, testObjects.ViewModel.ChatMarketItems));

            Mock.Get(testObjects.ChatIceMapRowViewModelBuilder)
                .Verify(b => b.CreateItemFromChatIceMap(iceMap, testObjects.ViewModel.PriceCurveDefinitionItems, testObjects.ViewModel.ChatMarketItems));
        }

        [Test]
        public void ShouldFilterChatIceMapRows_When_SearchTextUpdated()
        {
            var iceMapRows = new ObservableCollection<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatIceMapRows(iceMapRows)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.SearchText = "ice";

            // ASSERT
            Mock.Get(testObjects.ChatIceMapFilterService)
                .Verify(f => f.FilterItems("ice"));
        }

        [Test]
        public void ShouldInvokeRefreshRows_And_SubscribeUpdates_On_ChatIceMaps()
        {
            var iceMaps = new List<ChatIceMap>
            {
                new(10, EntityStatus.Active, "ice", 51, 101, "")
            };

            var iceMapRows = new List<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var chatMarkets = new List<ChatMarket>();
            var priceCurves = new List<PriceCurveDefinition>();

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithRowCollectionProviderResult(iceMapRows)
                                                                                        .WithChatMarkets(chatMarkets)
                                                                                        .WithPriceCurveDefinitions(priceCurves)
                                                                                        .Build();
            // ACT
            testObjects.ChatIceMaps.OnNext(iceMaps);

            // ASSERT
            Mock.Get(testObjects.ChatProductItemCollectionService)
                .Verify(r => r.RefreshItems(It.Is<IList<ChatProductItemViewModel>>(i => i.Count == 1)));

            Mock.Get(testObjects.DuplicateShortcutsService)
                .Verify(r => r.RefreshItems(It.Is<IList<ChatProductItemViewModel>>(i => i.Count == 1)));

            Mock.Get(testObjects.DeletedProductItemMappingsObserver)
                .Verify(r => r.RefreshItems(It.Is<IList<ChatProductItemViewModel>>(i => i.Count == 1)));

            Assert.That(iceMapRows[0].SubscribeUpdates, Is.True);
        }

        [Test]
        public void ShouldAddNewRow_On_AddRowCommand()
        {
            var newRow = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithNewChatIceMapRow(newRow)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.AddProductItemCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ChatProductItemCollectionService)
                .Verify(r => r.AddNewItem(newRow, It.IsAny<IList<ChatProductItemViewModel>>(), testObjects.ViewModel));

            Mock.Get(testObjects.DuplicateShortcutsService)
                .Verify(r => r.AddItem(newRow));

            Mock.Get(testObjects.DeletedProductItemMappingsObserver)
                .Verify(r => r.AddItem(newRow));

            Assert.That(newRow.SubscribeUpdates, Is.True);
        }

        [Test]
        public void ShouldShowMessageDialog_OnUpdate_With_Conflicts()
        {
            var iceMapRows = new ObservableCollection<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>()){Id = 10, IsInEdit = true}
            };

            var iceMapRowProviderResult = new List<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>()){Id = 10}
            };

            var chatMarkets = new List<ChatMarket>();
            var priceCurves = new List<PriceCurveDefinition>();

            var testObjects =
                new ChatProductAdminViewModelControllerTestObjectBuilder().WithRowCollectionProviderResult(iceMapRowProviderResult)
                                                                          .WithChatMarkets(chatMarkets)
                                                                          .WithPriceCurveDefinitions(priceCurves)
                                                                          .WithChatIceMapRows(new ObservableCollection<ChatProductItemViewModel>(iceMapRows))
                                                                          .Build();

            var iceMaps = new List<ChatIceMap>
            {
                new(10, EntityStatus.Active, "ice-1", 51, 101, "")
            };

            // ACT
            testObjects.ChatIceMaps.OnNext(iceMaps);

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldNotShowMessageDialog_OnUpdate_With_NoConflicts()
        {
            var iceMapRows = new ObservableCollection<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>()){Id = 10}
            };

            var iceMapRowProviderResult = new List<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>()){Id = 10}
            };

            var chatMarkets = new List<ChatMarket>();
            var priceCurves = new List<PriceCurveDefinition>();

            var testObjects
                = new ChatProductAdminViewModelControllerTestObjectBuilder().WithRowCollectionProviderResult(iceMapRowProviderResult)
                                                                            .WithChatMarkets(chatMarkets)
                                                                            .WithPriceCurveDefinitions(priceCurves)
                                                                            .WithChatIceMapRows(new ObservableCollection<ChatProductItemViewModel>(iceMapRows))
                                                                            .Build();

            var iceMaps = new List<ChatIceMap>
            {
                new(10, EntityStatus.Active, "ice-1", 51, 101, "")
            };

            // ACT
            testObjects.ChatIceMaps.OnNext(iceMaps);

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()), Times.Never);
        }

        [Test]
        public void ShouldEnableUpdateCommand_OnCanExecuteUpdateCommandTrue()
        {
            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CanExecuteUpdateCommand.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldEnableUndoCommand_OnCanExecuteUndoCommandTrue()
        {
            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CanExecuteUndoCommand.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(true));
        }

        [Test]
        public void ShouldDisableFilter_When_RowIsDirty()
        {
            var row1 = new ChatProductItemViewModel(Mock.Of<IDisposable>());
            var row2 = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            var iceMapRows = new List<ChatProductItemViewModel>
            {
                row1, row2
            };

            var iceMaps = new List<ChatIceMap>();

            var chatMarkets = new List<ChatMarket>();
            var priceCurves = new List<PriceCurveDefinition>();

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithRowCollectionProviderResult(iceMapRows)
                                                                                        .WithChatMarkets(chatMarkets)
                                                                                        .WithChatIceMaps(iceMaps)
                                                                                        .WithPriceCurveDefinitions(priceCurves)
                                                                                        .Build();
            // ACT
            row1.IsDirty = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanFilterRows, Is.False);
        }

        [Test]
        public void ShouldEnableFilter_When_RowIsDirtyFalse()
        {
            var row1 = new ChatProductItemViewModel(Mock.Of<IDisposable>());
            var row2 = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            var iceMapRows = new List<ChatProductItemViewModel>
            {
                row1, row2
            };

            var iceMaps = new List<ChatIceMap>();

            var chatMarkets = new List<ChatMarket>();
            var priceCurves = new List<PriceCurveDefinition>();

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithRowCollectionProviderResult(iceMapRows)
                                                                                        .WithChatMarkets(chatMarkets)
                                                                                        .WithChatIceMaps(iceMaps)
                                                                                        .WithPriceCurveDefinitions(priceCurves)
                                                                                        .Build();
            row1.IsDirty = true;

            // ACT
            row1.IsDirty = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanFilterRows, Is.True);
        }

        [Test]
        public void ShouldRefreshRows_On_ToolBarUndo()
        {
            var iceMaps = new List<ChatIceMap>
            {
                new(10, EntityStatus.Active, "ice-1", 51, 101, "")
            };

            var chatMarkets = new List<ChatMarket>();
            var priceCurves = new List<PriceCurveDefinition>();

            var iceMapRows = new ObservableCollection<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var filteredRows = new List<ChatProductItemViewModel>
            {

                new(Mock.Of<IDisposable>())
            };
            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatIceMapRows(iceMapRows)
                                                                                        .WithChatIceMapsSnapshot(iceMaps)
                                                                                        .WithChatMarkets(chatMarkets)
                                                                                        .WithPriceCurveDefinitions(priceCurves)
                                                                                        .WithRowCollectionResetResult(filteredRows)
                                                                                        .WithFilteredRows(filteredRows)
                                                                                        .Build();
            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ChatIceMapRowCollectionProvider)
                .Verify(p => p.GetCollectionReset(iceMaps, It.IsAny<Func<ChatIceMap, ChatProductItemViewModel>>()));

            Mock.Get(testObjects.ChatProductItemCollectionService)
                .Verify(s => s.RefreshItems(It.Is<IList<ChatProductItemViewModel>>(r => r.Count == 1)));

            Mock.Get(testObjects.DuplicateShortcutsService)
                .Verify(s => s.RefreshItems(It.Is<IList<ChatProductItemViewModel>>(r => r.Count == 1)));

            Mock.Get(testObjects.DeletedProductItemMappingsObserver)
                .Verify(r => r.RefreshItems(It.Is<IList<ChatProductItemViewModel>>(i => i.Count == 1)));

            Assert.That(testObjects.ViewModel.ChatProductItems.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldSetIsBusy_On_ToolBarUpdate()
        {
            var iceMapRows = new ObservableCollection<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatIceMapRows(iceMapRows)
                                                                                        .Build();

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldInvokeAdminUpdateService_OnToolBarUpdate()
        {
            var row = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            var iceMapRows = new ObservableCollection<ChatProductItemViewModel> { row };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatIceMapRows(iceMapRows)
                                                                                        .Build();
            // ASSERT
            Mock.Get(testObjects.ChatIceMapAdminUpdateService)
                .Setup(u => u.Update(It.IsAny<IList<ChatProductItemViewModel>>(),
                                     It.IsAny<IScheduler>(),
                                     It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>(),
                                     It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>(),
                                     It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>()))
                             .Returns(Observable.Return(Unit.Default))
                             .Callback<IList<ChatProductItemViewModel>, IScheduler, Func<ChatProductItemViewModel, ChatIceMap>, Func<ChatProductItemViewModel, ChatIceMap>, Func<ChatProductItemViewModel, ChatIceMap>>
                              ((_, _, func1, func2, func3) =>
                              {
                                  func1(row);
                                  func2(row);
                                  func3(row);
                              });
            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ChatIceMapBuilder)
                .Verify(b => b.GetNewChatIceMap(row), Times.Once);

            Mock.Get(testObjects.ChatIceMapBuilder)
                .Verify(b => b.GetUpdatedChatIceMap(row), Times.Once);

            Mock.Get(testObjects.ChatIceMapBuilder)
                .Verify(b => b.GetDeletedChatIceMap(row), Times.Once);
        }

        [Test]
        public void ShouldShowPopupAndSetIsBusyFalse_OnChatIceMapUpdateCompleted()
        {
            var row1 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { IsDirty = true, IsValid = true };

            var iceMapRows = new ObservableCollection<ChatProductItemViewModel> { row1 };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatIceMapRows(iceMapRows)
                                                                                        .Build();

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.IceChatMapUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), null));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldSetIsBusyFalseAndShowDialog_OnChatIceMapUpdateError_WithCommand()
        {
            var row1 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { IsDirty = true, IsValid = true };

            var iceMapRows = new ObservableCollection<ChatProductItemViewModel> { row1 };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatIceMapRows(iceMapRows)
                                                                                        .Build();

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.IceChatMapUpdateResponse.OnError(new Exception("error"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "error"
                                                                                && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldValidateExistingMappings_On_ToolBarUpdate_With_DeletedRows()
        {
            var row = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveName = "curve",
                IsDeleted = true
            };

            var iceMapRows = new ObservableCollection<ChatProductItemViewModel> { row };

            var shortcuts = new List<ChatVariableShortcut>
            {
                new(1, EntityStatus.Active, "name", "ref", new List<ChatVariableShortcutVariation>
                                                           {
                                                               new(21, 1, 51, "curve")
                                                           })
            };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatIceMapRows(iceMapRows)
                                                                                        .WithChatVariableShortcuts(shortcuts)
                                                                                        .Build();

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(row.IsDeletedWithExistingMapping, Is.True);

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Header == "Chat Product Validation Failed")));

            Mock.Get(testObjects.ChatIceMapAdminUpdateService)
                .Verify(u => u.Update(It.IsAny<IList<ChatProductItemViewModel>>(),
                                      It.IsAny<IScheduler>(),
                                      It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>(),
                                      It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>(),
                                      It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>()),
                        Times.Never());
        }

        [Test]
        public void ShouldUpdate_On_ToolBarUpdate_With_DeletedRows_And_NoExistingMappings()
        {
            var row = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveName = "curve",
                IsDeleted = true
            };

            var iceMapRows = new ObservableCollection<ChatProductItemViewModel> { row };

            var shortcuts = new List<ChatVariableShortcut>
            {
                new(1, EntityStatus.Active, "name", "ref", new List<ChatVariableShortcutVariation>
                                                           {
                                                               new(21, 1, 51, "curve-2")
                                                           })
            };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithChatIceMapRows(iceMapRows)
                                                                                        .WithChatVariableShortcuts(shortcuts)
                                                                                        .Build();

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(row.IsDeletedWithExistingMapping, Is.False);

            Mock.Get(testObjects.ChatIceMapAdminUpdateService)
                .Verify(u => u.Update(It.IsAny<IList<ChatProductItemViewModel>>(),
                                      It.IsAny<IScheduler>(),
                                      It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>(),
                                      It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>(),
                                      It.IsAny<Func<ChatProductItemViewModel, ChatIceMap>>()));
        }
        [Test]
        public void ShouldSetValidationErrors_When_Errors()
        {
            var errors = new List<string> { "error" };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetValidationErrors(errors));
        }

        [Test]
        public void ShouldClearValidationErrors_When_NoErrors()
        {
            var errors = new List<string>();

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.ClearValidation());
        }

        [Test]
        public void ShouldNotPopulateChatIceMapRows_When_Disposed()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("curve")
                                                                                  .Build();
            var iceMaps = new List<ChatIceMap>
            {
                new(10, EntityStatus.Active, priceCurveDefinition.Name, 51, priceCurveDefinition.Id, "")
            };

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var iceMapRows = new List<ChatProductItemViewModel>
            {
                new(Mock.Of<IDisposable>()) {PriceCurveName = "ice-B", PriceCurveDefinition = priceCurveItem},
                new(Mock.Of<IDisposable>()) {PriceCurveName = "ice-A"}
            };

            var chatMarkets = new List<ChatMarket>
            {
                new(21, EntityStatus.Active, "market")
            };

            var priceCurves = new List<PriceCurveDefinition>
            {
                priceCurveDefinition
            };

            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().WithRowCollectionProviderResult(iceMapRows)
                                                                                        .WithFilteredRows(iceMapRows)
                                                                                        .WithChatMarkets(chatMarkets)
                                                                                        .WithPriceCurveDefinitions(priceCurves)
                                                                                        .Build();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.ChatIceMaps.OnNext(iceMaps);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatProductItems.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ChatProductItemCollectionService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.DuplicateShortcutsService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.DeletedProductItemMappingsObserver)
                .Verify(r => r.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ChatProductAdminViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ChatProductItemCollectionService)
                .Verify(s => s.Dispose(), Times.Once);

            Mock.Get(testObjects.DuplicateShortcutsService)
                .Verify(s => s.Dispose(), Times.Once);

            Mock.Get(testObjects.DeletedProductItemMappingsObserver)
                .Verify(r => r.Dispose(), Times.Once);
        }
    }
}