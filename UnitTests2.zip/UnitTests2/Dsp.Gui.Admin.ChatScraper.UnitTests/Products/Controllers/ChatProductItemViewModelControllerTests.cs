﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.Controllers;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Products.Controllers
{
    internal interface IChatProductItemViewModelControllerTestObjects
    {
        ISubject<List<ChatVariableShortcut>> ChatVariableShortcuts { get; }
        IChatProductItemValidationService ValidationService { get; }
        ChatProductItemViewModelController Controller { get; }
        ChatProductItemViewModel ViewModel { get; }
    }

    [TestFixture]
    public class ChatProductItemViewModelControllerTests
    { 
        private class ChatProductItemViewModelControllerTestObjectBuilder
        {
            private bool _newRecord;
            private ChatIceMap _chatIceMap;
            private PriceCurveDefinitionItem _priceCurveDefinition;
            private ChatMarketItem _chatMarket;
            private bool _isDeleted;
            private bool _isDeletedWithExistingMapping;
            private bool _subscribeUpdates;

            public ChatProductItemViewModelControllerTestObjectBuilder WithNewRecord(bool value)
            {
                _newRecord = value;
                return this;
            }

            public ChatProductItemViewModelControllerTestObjectBuilder WithChatIceMap(ChatIceMap value)
            {
                _chatIceMap = value;
                return this;
            }

            public ChatProductItemViewModelControllerTestObjectBuilder WithPriceCurveDefinition(PriceCurveDefinitionItem value)
            {
                _priceCurveDefinition = value;
                return this;
            }

            public ChatProductItemViewModelControllerTestObjectBuilder WithChatMarket(ChatMarketItem value)
            {
                _chatMarket = value;
                return this;
            }

            public ChatProductItemViewModelControllerTestObjectBuilder WithIsDeleted(bool value)
            {
                _isDeleted = value;
                return this;
            }

            public ChatProductItemViewModelControllerTestObjectBuilder WithIsDeletedWithExistingMapping(bool value)
            {
                _isDeletedWithExistingMapping = value;
                return this;
            }

            public ChatProductItemViewModelControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public IChatProductItemViewModelControllerTestObjects Build() 
            {
                var testObjects = new Mock<IChatProductItemViewModelControllerTestObjects>();

                var chatVariableShortcuts = new Subject<List<ChatVariableShortcut>>();

                testObjects.SetupGet(o => o.ChatVariableShortcuts)
                           .Returns(chatVariableShortcuts);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ChatVariableShortcuts)
                                   .Returns(chatVariableShortcuts);

                var validationService = new Mock<IChatProductItemValidationService>();

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(validationService.Object);

                var controller = new ChatProductItemViewModelController(curveControlService.Object,
                                                                        validationService.Object);

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                controller.ViewModel.NewRecord = _newRecord;

                controller.ViewModel.SetChatIceMap(_chatIceMap);

                controller.ViewModel.PriceCurveDefinition = _priceCurveDefinition;
                controller.ViewModel.ChatMarket = _chatMarket;
                controller.ViewModel.IsDeleted = _isDeleted;
                controller.ViewModel.IsDeletedWithExistingMapping = _isDeletedWithExistingMapping;

                testObjects.SetupGet(o => o.Controller).Returns(controller); 
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPopulatePriceCurveDetails_From_PriceCurveDefinitionItem()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("curve-101")
                                                                                  .WithDescription("desc")
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.PriceCurveDefinition = priceCurveItem;

            // ASSERT
            Assert.That(testObjects.ViewModel.PriceCurveName, Is.EqualTo("curve-101"));
            Assert.That(testObjects.ViewModel.PriceCurveDescription, Is.EqualTo("desc"));
        }

        [Test]
        public void ShouldValidateNewItem_When_SubscribeUpdates()
        {
            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithNewRecord(true)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldNotValidate_When_SubscribeUpdatesFalse()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("curve-101")
                                                                                  .WithDescription("desc")
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));

            var chatIceMap = new ChatIceMap(1, EntityStatus.Active, priceCurveDefinition.Name, 10, priceCurveDefinition.Id, "");

            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithChatIceMap(chatIceMap)
                                                                                     .WithPriceCurveDefinition(priceCurveItem)
                                                                                     .WithChatMarket(chatMarketItem)
                                                                                     .Build();
            // ACT                                                                   
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Attach(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_PriceCurveChanged()
        {
            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                   .WithName("curve-101")
                                                                                   .Build();

            var priceCurveItem1 = new PriceCurveDefinitionItem(priceCurveDefinition1);

            var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                                   .WithName("curve-102")
                                                                                   .Build();

            var priceCurveItem2 = new PriceCurveDefinitionItem(priceCurveDefinition2);

            var chatIceMap = new ChatIceMap(1, EntityStatus.Active, priceCurveDefinition1.Name, 10, priceCurveDefinition1.Id, "");

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));

            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithChatIceMap(chatIceMap)
                                                                                     .WithPriceCurveDefinition(priceCurveItem1)
                                                                                     .WithChatMarket(chatMarketItem)
                                                                                     .WithSubscribeUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.PriceCurveDefinition = priceCurveItem2;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_PriceCurveChangeReverted()
        {
            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                   .WithName("curve-101")
                                                                                   .Build();

            var priceCurveItem1 = new PriceCurveDefinitionItem(priceCurveDefinition1);

            var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                                   .WithName("curve-102")
                                                                                   .Build();

            var priceCurveItem2 = new PriceCurveDefinitionItem(priceCurveDefinition2);

            var chatIceMap = new ChatIceMap(1, EntityStatus.Active, priceCurveDefinition1.Name, 10, priceCurveDefinition1.Id, string.Empty);

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));

            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithChatIceMap(chatIceMap)
                                                                                       .WithPriceCurveDefinition(priceCurveItem1)
                                                                                       .WithChatMarket(chatMarketItem)
                                                                                       .WithSubscribeUpdates(true)
                                                                                       .Build();

            testObjects.ViewModel.PriceCurveDefinition = priceCurveItem2;

            // ACT
            testObjects.ViewModel.PriceCurveDefinition = priceCurveItem1;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_ShortcutsChanged()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("curve-101")
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);


            var chatIceMap = new ChatIceMap(1, EntityStatus.Active, priceCurveDefinition.Name, 10, priceCurveDefinition.Id, 
                                            "ref-1;ref-2"
                                            );

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));

            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithChatIceMap(chatIceMap)
                                                                                       .WithPriceCurveDefinition(priceCurveItem)
                                                                                       .WithChatMarket(chatMarketItem)
                                                                                       .WithSubscribeUpdates(true)
                                                                                       .Build();

            // ACT
            testObjects.ViewModel.Shortcuts = new List<object> {"ref-1","ref-99"};

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.True);
        }

        [Test] 
        public void ShouldSetIsDirtyFalse_When_ShortcutsChangeReverted()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("curve-101")
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var chatIceMap = new ChatIceMap(1,
                                            EntityStatus.Active, 
                                            priceCurveDefinition.Name, 
                                            10, 
                                            priceCurveDefinition.Id,
                                            "ref-1;ref-2");

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));

            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithChatIceMap(chatIceMap)
                                                                                       .WithPriceCurveDefinition(priceCurveItem)
                                                                                       .WithChatMarket(chatMarketItem)
                                                                                       .WithSubscribeUpdates(true)
                                                                                       .Build();

            testObjects.ViewModel.Shortcuts = new List<object> { "ref-1", "ref-99" };

            // ACT
            testObjects.ViewModel.Shortcuts = new List<object> { "ref-1", "ref-2" };

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDirty, Is.False);
        }

        [Test]
        public void ShouldSetIsDeletedTrue_On_DeleteCommand()
        {
            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.True);
        }

        [Test]
        public void ShouldSetIsDeletedFalse_On_UndoDeleteCommand()
        {
            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithIsDeleted(true)
                                                                                       .Build();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.False);
        }

        [Test]
        public void ShouldSetIsDeletedWithExistingMappingFalse_On_UndoDeleteCommand()
        {
            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithIsDeleted(true)
                                                                                       .WithIsDeletedWithExistingMapping(true)
                                                                                       .WithSubscribeUpdates(true)
                                                                                       .Build();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeletedWithExistingMapping, Is.False);
        }

        [Test]
        public void ShouldDisableDelete_On_ChatVariableShortcuts_With_ExistingProductMapping()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("curve")
                                                                                  .WithDescription("desc")
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var shortcuts = new List<ChatVariableShortcut>
            {
                new(1, EntityStatus.Active, "name", "ref", new List<ChatVariableShortcutVariation>
                                                           {
                                                               new(21, 1, 51, "curve")
                                                           })
            };

            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithPriceCurveDefinition(priceCurveItem)
                                                                                     .WithSubscribeUpdates(true)
                                                                                     .Build();

            // ACT
            testObjects.ChatVariableShortcuts.OnNext(shortcuts);

            // ASSERT
            Assert.That(testObjects.ViewModel.DeleteCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldNotDisableDelete_On_ChatVariableShortcuts_With_ProductMappingDeleted()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("curve")
                                                                                  .WithDescription("desc")
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var shortcuts = new List<ChatVariableShortcut>
            {
                new(1, EntityStatus.Deleted, "name", "ref", new List<ChatVariableShortcutVariation>
                                                            {
                                                                new(21, 1, 51, "curve")
                                                            })
            };

            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().WithPriceCurveDefinition(priceCurveItem)
                                                                                       .WithSubscribeUpdates(true)
                                                                                       .Build();

            // ACT
            testObjects.ChatVariableShortcuts.OnNext(shortcuts);

            // ASSERT
            Assert.That(testObjects.ViewModel.DeleteCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisposeValidation_When_Dispose()
        {
            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.Dispose();

            // VERIFY
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ChatProductItemViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.Dispose();

            // ACT
            testObjects.Controller.ViewModel.Dispose();

            // ACT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Dispose(), Times.Once);
        }
    }
}
