﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Moq;
using NUnit.Framework;


namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Products.Services
{
    [TestFixture]
    public class ChatProductItemFilterServiceTests
    {
        [Test]
        public void ShouldRefresh_And_ReturnEmptyList_WhenNoItems()
        {
            var filterService = new ChatProductItemFilterService();

            // ACT
            var result = filterService.RefreshItems(null, string.Empty);

            // ASSERT
            Assert.That(result.Count(), Is.EqualTo(0));
        }

        [Test]
        public void ShouldRefresh_And_ReturnRows_WhenNoFilter()
        {
            var mappedItem = new ChatProductItemViewModel(Mock.Of<IDisposable>());
            mappedItem.SetChatIceMap(new ChatIceMap(1, EntityStatus.Active, "code", 51, 101, string.Empty));

            var unmappedItem = new ChatProductItemViewModel(Mock.Of<IDisposable>());
            unmappedItem.SetChatIceMap(new ChatIceMap(2, EntityStatus.Active, "code", 52, 0, string.Empty));


            var items = new List<ChatProductItemViewModel> { mappedItem, unmappedItem };

            var filterService = new ChatProductItemFilterService();

            // ACT
            var result = filterService.RefreshItems(items, string.Empty);

            // ASSERT
            Assert.That(result.Count(), Is.EqualTo(2));
        }

        [Test]
        public void ShouldReturnItems_AfterRefresh_WhenNoFilter()
        {
            var mappedItem = new ChatProductItemViewModel(Mock.Of<IDisposable>());
            mappedItem.SetChatIceMap(new ChatIceMap(1, EntityStatus.Active, "code", 51, 101, string.Empty));

            var unmappedItem = new ChatProductItemViewModel(Mock.Of<IDisposable>());
            unmappedItem.SetChatIceMap(new ChatIceMap(2, EntityStatus.Active, "code", 52, 0, string.Empty));


            var items = new List<ChatProductItemViewModel> { mappedItem, unmappedItem };

            var filterService = new ChatProductItemFilterService();

            filterService.RefreshItems(items, string.Empty);

            // ACT
            var result = filterService.FilterItems(string.Empty);

            // ASSERT
            Assert.That(result.Count(), Is.EqualTo(2));
        }

        [Test]
        public void ShouldRefresh_And_ReturnFilteredItems_WhenFilterBySearchText_OnPriceCurveName()
        {
            var item1 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveName = "ice-code", PriceCurveDescription = "name-1"};
            var item2 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveName = "other", PriceCurveDescription = "other" }; ;

            var items = new List<ChatProductItemViewModel> { item1, item2 };

            var filterService = new ChatProductItemFilterService();

            // ACT
            var result = filterService.RefreshItems(items, "ice").ToList();

            // ASSERT
            Assert.That(result.Count == 1 && result[0].PriceCurveName == "ice-code");
        }

        [Test]
        public void ShouldRefresh_And_ReturnFilteredItems_WhenFilterBySearchText_OnIceName()
        {
            var item1 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveName = "code", PriceCurveDescription = "ice-name"};
            var item2 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveName = "other", PriceCurveDescription = "other" }; ;

            var items = new List<ChatProductItemViewModel> { item1, item2 };

            var filterService = new ChatProductItemFilterService();

            // ACT
            var result = filterService.RefreshItems(items, "ice").ToList();

            // ASSERT
            Assert.That(result.Count == 1 && result[0].PriceCurveName == "code");
        }

        [Test]
        public void ShouldReturnFilteredItems_AfterRefresh_WhenFilterBySearchText_OrderedByPriceCurveName()
        {
            var item1 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveName = "ice-code-2", PriceCurveDescription = "name-2" };
            var item2 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveName = "ice-code-1", PriceCurveDescription = "name-1" };
            var item3 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveName = "other", PriceCurveDescription = "other" }; ;

            var items = new List<ChatProductItemViewModel> { item1, item2, item3 };

            var filterService = new ChatProductItemFilterService();

            // ACT
            var result = filterService.RefreshItems(items, "ice").ToList();

            // ASSERT
            Assert.That(result.Count == 2 && result[0].PriceCurveName == "ice-code-1" && result[1].PriceCurveName == "ice-code-2");
        }
    }
}
