﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Products.Services
{
    [TestFixture]
    internal class ChatIceMapBuilderTests
    {
        [Test]
        public void ShouldGetNewChatIceMap()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(103)
                                                                                  .WithName("name")
                                                                                  .WithDescription("desc")
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var chatMarketItem = new ChatMarketItem(new ChatMarket(20, EntityStatus.Active, "market"));

            viewModel.PriceCurveDefinition = priceCurveItem;
            viewModel.ChatMarket = chatMarketItem;
            viewModel.Shortcuts = new List<object> { "ref-1", "ref-2" };

            var builder = new ChatIceMapBuilder();

            // ACT
            var result = builder.GetNewChatIceMap(viewModel);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(0));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Active));
            Assert.That(result.PriceCurveDefinitionId, Is.EqualTo(103));
            Assert.That(result.PriceCurveName, Is.EqualTo("name"));
            Assert.That(result.ChatMarketId, Is.EqualTo(20));
            Assert.That(result.Shortcuts, Is.EqualTo("ref-1;ref-2"));
        }

        [Test]
        public void ShouldGetUpdatedChatIceMap()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            var chatIceMap = new ChatIceMap(1, 
                                            EntityStatus.Active, 
                                            "curve-1", 
                                            20, 
                                            101, 
                                            "ref-1");

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                                  .WithName("curve-2")
                                                                                  .WithDescription("desc")
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);

            var chatMarketItem = new ChatMarketItem(new ChatMarket(21, EntityStatus.Active, "market"));

            viewModel.SetChatIceMap(chatIceMap);

            viewModel.Id = 1;
            viewModel.PriceCurveDefinition = priceCurveItem;
            viewModel.ChatMarket = chatMarketItem;
            viewModel.Shortcuts = new List<object> { "ref-1", "ref-2" };

            var builder = new ChatIceMapBuilder();

            // ACT
            var result = builder.GetUpdatedChatIceMap(viewModel);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(1));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Active));
            Assert.That(result.PriceCurveName, Is.EqualTo("curve-2"));
            Assert.That(result.ChatMarketId, Is.EqualTo(21));
            Assert.That(result.Shortcuts, Is.EqualTo("ref-1;ref-2"));
        }

        [Test]
        public void ShouldGetDeletedChatIceMap()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            var chatIceMap = new ChatIceMap(1, EntityStatus.Active, "ice-code", 51, 101,
                                            "ice-code");

            var priceCurveItem = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().WithId(100).Build());

            viewModel.SetChatIceMap(chatIceMap);

            viewModel.Id = 1;
            viewModel.PriceCurveDefinition = priceCurveItem;
            viewModel.Shortcuts = new List<object> { "ref-1", "ref-2" };

            var builder = new ChatIceMapBuilder();

            // ACT
            var result = builder.GetDeletedChatIceMap(viewModel);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(1));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Deleted));
        }
    }
}
