﻿using System;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Moq;
using NUnit.Framework;


namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Products.Services
{
    [TestFixture]
    public class DeletedProductItemMappingsObserverTests
    {
        [Test]
        public void ShouldPublishTrue_When_ItemIsDeletedWithExistingMappingTrue()
        {
            var items = new[]
            {
                new ChatProductItemViewModel(Mock.Of<IDisposable>()),
                new ChatProductItemViewModel(Mock.Of<IDisposable>())
            };

            var deletedProductItemMappingsObserver = new DeletedProductItemMappingsObserver();

            deletedProductItemMappingsObserver.RefreshItems(items);

            var result = false;

            using (deletedProductItemMappingsObserver.HasDeletedWithExistingMappings
                                                     .Subscribe(value => result = value))
            {
                // ACT
                items[0].IsDeletedWithExistingMapping = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_ItemIsDeletedWithExistingMappingFalse()
        {
            var items = new[]
            {
                new ChatProductItemViewModel(Mock.Of<IDisposable>()),
                new ChatProductItemViewModel(Mock.Of<IDisposable>())
            };

            var deletedProductItemMappingsObserver = new DeletedProductItemMappingsObserver();

            deletedProductItemMappingsObserver.RefreshItems(items);

            var result = false;

            using (deletedProductItemMappingsObserver.HasDeletedWithExistingMappings
                                                     .Subscribe(value => result = value))
            {
                items[0].IsDeletedWithExistingMapping = true;

                // ACT
                items[0].IsDeletedWithExistingMapping = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_AddedItemIsDeletedWithExistingMappingTrue()
        {
            var items = new[]
            {
                new ChatProductItemViewModel(Mock.Of<IDisposable>())
            };

            var deletedProductItemMappingsObserver = new DeletedProductItemMappingsObserver();

            deletedProductItemMappingsObserver.RefreshItems(items);

            var newItem = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            deletedProductItemMappingsObserver.AddItem(newItem);

            var result = false;

            using (deletedProductItemMappingsObserver.HasDeletedWithExistingMappings
                                                     .Subscribe(value => result = value))
            {
                // ACT
                newItem.IsDeletedWithExistingMapping = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotPublishTrue_When_Disposed()
        {
            var items = new[]
            {
                new ChatProductItemViewModel(Mock.Of<IDisposable>())
            };

            var deletedProductItemMappingsObserver = new DeletedProductItemMappingsObserver();

            deletedProductItemMappingsObserver.RefreshItems(items);

            var result = false;

            using (deletedProductItemMappingsObserver.HasDeletedWithExistingMappings
                                                     .Subscribe(value => result = value))
            {
                deletedProductItemMappingsObserver.Dispose();

                // ACT
                items[0].IsDeletedWithExistingMapping = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var items = new[]
            {
                new ChatProductItemViewModel(Mock.Of<IDisposable>())
            };

            var deletedProductItemMappingsObserver = new DeletedProductItemMappingsObserver();

            deletedProductItemMappingsObserver.RefreshItems(items);

            var result = false;

            using (deletedProductItemMappingsObserver.HasDeletedWithExistingMappings
                                                     .Subscribe(value => result = value))
            {
                deletedProductItemMappingsObserver.Dispose();

                // ACT
                deletedProductItemMappingsObserver.Dispose();
                items[0].IsDeletedWithExistingMapping = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
