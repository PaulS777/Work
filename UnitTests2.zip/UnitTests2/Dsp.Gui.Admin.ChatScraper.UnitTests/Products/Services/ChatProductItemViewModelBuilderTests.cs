﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.Controllers;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Products.Services
{
    internal interface IChatProductItemViewModelBuilderTestObjects
    {
        IChatProductItemValidationService ValidationService { get; }
        ChatProductItemViewModelBuilder ChatProductItemViewModelBuilder { get; }
    }

    [TestFixture]
    public class ChatProductItemViewModelBuilderTests
    {
        private class ChatProductItemViewModelBuilderTestObjectBuilder
        {
            public IChatProductItemViewModelBuilderTestObjects Build()
            {
                var testObjects = new Mock<IChatProductItemViewModelBuilderTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                var validationService = new Mock<IChatProductItemValidationService>();

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(validationService.Object);
                
                var controller = new ChatProductItemViewModelController(curveControlService.Object,
                                                                        validationService.Object);

                var factory = new Mock<IServiceFactory<IChatProductItemViewModelController>>();

                factory.Setup(f => f.Create())
                       .Returns(controller);

                var builder = new ChatProductItemViewModelBuilder
                              {
                                  Factory = factory.Object
                              };

                testObjects.SetupGet(o => o.ChatProductItemViewModelBuilder)
                           .Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCreateNewItem()
        {
            var testObjects = new ChatProductItemViewModelBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ChatProductItemViewModelBuilder.CreateNewItem();

            // ASSERT
            Assert.That(result.NewRecord, Is.True);
        }

        [Test]
        public void ShouldCreateChatProductItemViewModel_From_ChatIceMap()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);
            var priceCurveItems = new List<PriceCurveDefinitionItem> { priceCurveItem };

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));
            var chatMarketItems = new List<ChatMarketItem> { chatMarketItem };

            var chatIceMap = new ChatIceMap(1,
                                            EntityStatus.Active,
                                            priceCurveDefinition.Name,
                                            10,
                                            priceCurveDefinition.Id,
                                            "ref-1;ref-2");

            var testObjects = new ChatProductItemViewModelBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ChatProductItemViewModelBuilder.CreateItemFromChatIceMap(chatIceMap, 
                                                                                           priceCurveItems, 
                                                                                           chatMarketItems);
            // ASSERT
            Assert.AreSame(chatIceMap, result.ChatIceMap());

            Assert.That(result.Id, Is.EqualTo(1));
            Assert.AreSame(chatIceMap, result.ChatIceMap());
            Assert.AreSame(chatMarketItem, result.ChatMarket);
            Assert.AreSame(priceCurveItem, result.PriceCurveDefinition);

            Assert.That(result.Shortcuts.Count == 2
                        && result.Shortcuts[0].ToString() == "ref-1"
                        && result.Shortcuts[1].ToString() == "ref-2");
        }

        [Test]
        public void ShouldSetShortcutsToNull_When_CreateItem_With_ChatIceMapShortcutsNull()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);
            var priceCurveItems = new List<PriceCurveDefinitionItem> { priceCurveItem };

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));
            var chatMarketItems = new List<ChatMarketItem> { chatMarketItem };

            var chatIceMap = new ChatIceMap(1,
                                            EntityStatus.Active,
                                            priceCurveDefinition.Name,
                                            10,
                                            priceCurveDefinition.Id,
                                            null);

            var testObjects = new ChatProductItemViewModelBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ChatProductItemViewModelBuilder.CreateItemFromChatIceMap(chatIceMap,
                                                                                              priceCurveItems,
                                                                                              chatMarketItems);
            // ASSERT
            Assert.IsNull(result.Shortcuts);
        }

        [Test]
        public void ShouldSetShortcutsEmptyArray_When_CreateRow_With_ChatIceMapShortcutEmptyString()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);
            var priceCurveItems = new List<PriceCurveDefinitionItem> { priceCurveItem };

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));
            var chatMarketItems = new List<ChatMarketItem> { chatMarketItem };

            var chatIceMap = new ChatIceMap(1,
                                            EntityStatus.Active,
                                            priceCurveDefinition.Name,
                                            10,
                                            priceCurveDefinition.Id,
                                            string.Empty);

            var testObjects = new ChatProductItemViewModelBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ChatProductItemViewModelBuilder.CreateItemFromChatIceMap(chatIceMap,
                                                                                              priceCurveItems,
                                                                                              chatMarketItems);

            // ASSERT
            Assert.That(result.Shortcuts.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldUpdateChatProductItenViewModel_From_ChatIceMap()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .Build();

            var priceCurveItem = new PriceCurveDefinitionItem(priceCurveDefinition);
            var priceCurveItems = new List<PriceCurveDefinitionItem> { priceCurveItem };

            var chatMarketItem = new ChatMarketItem(new ChatMarket(10, EntityStatus.Active, "market"));
            var chatMarketItems = new List<ChatMarketItem> {chatMarketItem};

            var chatIceMap = new ChatIceMap(1,
                                            EntityStatus.Active,
                                            priceCurveDefinition.Name,
                                            10,
                                            priceCurveDefinition.Id,
                                            "ref-1;ref-2");

            var testObjects = new ChatProductItemViewModelBuilderTestObjectBuilder().Build();

            var viewModel = new ChatProductItemViewModel(Mock.Of<IChatProductItemViewModelController>());

            // ACT
            testObjects.ChatProductItemViewModelBuilder.UpdateItemFromChatIceMap(viewModel, 
                                                                                 chatIceMap, 
                                                                                 priceCurveItems, 
                                                                                 chatMarketItems);
            // ASSERT
            Assert.AreSame(chatIceMap, viewModel.ChatIceMap());

            Assert.That(viewModel.Id, Is.EqualTo(1));
            Assert.AreSame(chatIceMap, viewModel.ChatIceMap());
            Assert.AreSame(chatMarketItem, viewModel.ChatMarket);
            Assert.AreSame(priceCurveItem, viewModel.PriceCurveDefinition);

            Assert.That(viewModel.Shortcuts.Count == 2
                        && viewModel.Shortcuts[0].ToString() == "ref-1"
                        && viewModel.Shortcuts[1].ToString() == "ref-2");

            Assert.That(viewModel.SubscribeUpdates, Is.True);
        }
    }
}
