﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Products.Services
{
    [TestFixture]
    internal class ChatProductDuplicateItemsServiceTests
    {
        [Test]
        public void ShouldSetPriceCurveNameDuplicateTrue_When_MatchingNames()
        {
            

            var item = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().WithId(100).Build());



            var row1 = new ChatProductItemViewModel(Mock.Of<IDisposable>()) { PriceCurveDefinition = item};
            var row2 = new ChatProductItemViewModel(Mock.Of<IDisposable>());

            var rows = new List<ChatProductItemViewModel> { row1, row2 };

            var service = new ChatProductDuplicateItemsService();

            service.RefreshItems(rows);

            // ACT
            row2.PriceCurveDefinition = item;

            // ASSERT
            Assert.That(row1.IsDuplicate, Is.True);
            Assert.That(row2.IsDuplicate, Is.True);
        }
    }
}
