﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.Rules;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.ChatScraper.UnitTests.Products.Services
{
    [TestFixture]
    public class ChatProductItemValidationServiceTests
    {
        [Test]
        public void ShouldSetIsValidTrue_When_Attach_With_ValidItem()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveDefinition = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().Build()),
                ChatMarket = new ChatMarketItem(new ChatMarket(1, EntityStatus.Active, "market")),
                IsDuplicateShortcut = false
            };

            var validationService = new ChatProductItemValidationService(new ChatProductItemPriceCurveDefinitionRule(),
                                                                         new ChatProductItemMarketRule(),
                                                                         new ChatProductItemShortcutRule());

            // ACT
            validationService.Attach(viewModel);

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_Attach_When_PriceCurveNull()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveDefinition = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().Build()),
                ChatMarket = new ChatMarketItem(new ChatMarket(1, EntityStatus.Active, "market")),
                IsDuplicateShortcut = false
            };

            var validationService = new ChatProductItemValidationService(new ChatProductItemPriceCurveDefinitionRule(),
                                                                         new ChatProductItemMarketRule(),
                                                                         new ChatProductItemShortcutRule());

            validationService.Attach(viewModel);

            // ACT
            viewModel.PriceCurveDefinition = null;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText, Is.EqualTo("Missing Price Curve"));
        }

        [Test]
        public void ShouldSetIsValidTrue_When_Attach_When_PriceCurveSet()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveDefinition = null,
                ChatMarket = new ChatMarketItem(new ChatMarket(1, EntityStatus.Active, "market")),
                IsDuplicateShortcut = false
            };

            var validationService = new ChatProductItemValidationService(new ChatProductItemPriceCurveDefinitionRule(),
                                                                         new ChatProductItemMarketRule(),
                                                                         new ChatProductItemShortcutRule());

            validationService.Attach(viewModel);

            // ACT
            viewModel.PriceCurveDefinition = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().Build());

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_Attach_When_MarketNull()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveDefinition = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().Build()),
                ChatMarket = new ChatMarketItem(new ChatMarket(1, EntityStatus.Active, "market")),
                IsDuplicateShortcut = false
            };

            var validationService = new ChatProductItemValidationService(new ChatProductItemPriceCurveDefinitionRule(),
                                                                         new ChatProductItemMarketRule(),
                                                                         new ChatProductItemShortcutRule());

            validationService.Attach(viewModel);

            // ACT
            viewModel.ChatMarket = null;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText, Is.EqualTo("Missing Market"));
        }

        [Test]
        public void ShouldSetIsValidTrue_When_Attach_When_MarketSet()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveDefinition = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().Build()),
                ChatMarket = null,
                IsDuplicateShortcut = false
            };

            var validationService = new ChatProductItemValidationService(new ChatProductItemPriceCurveDefinitionRule(),
                                                                         new ChatProductItemMarketRule(),
                                                                         new ChatProductItemShortcutRule());

            validationService.Attach(viewModel);

            // ACT
            viewModel.ChatMarket = new ChatMarketItem(new ChatMarket(1, EntityStatus.Active, "market"));

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_Attach_When_IsDuplicateShortcut()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveDefinition = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().Build()),
                ChatMarket = new ChatMarketItem(new ChatMarket(1, EntityStatus.Active, "market")),
                IsDuplicateShortcut = false
            };

            var validationService = new ChatProductItemValidationService(new ChatProductItemPriceCurveDefinitionRule(),
                                                                         new ChatProductItemMarketRule(),
                                                                         new ChatProductItemShortcutRule());

            validationService.Attach(viewModel);

            // ACT
            viewModel.IsDuplicateShortcut = true;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.False);
            Assert.That(viewModel.ErrorText, Is.EqualTo("Duplicate Shortcut"));
        }

        [Test]
        public void ShouldSetIsValidTrue_When_Attach_When_IsDuplicateShortcutFalse()
        {
            var viewModel = new ChatProductItemViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveDefinition = new PriceCurveDefinitionItem(new PriceCurveDefinitionTestObjectBuilder().Build()),
                ChatMarket = new ChatMarketItem(new ChatMarket(1, EntityStatus.Active, "market")),
                IsDuplicateShortcut = true
            };

            var validationService = new ChatProductItemValidationService(new ChatProductItemPriceCurveDefinitionRule(),
                                                                         new ChatProductItemMarketRule(),
                                                                         new ChatProductItemShortcutRule());

            validationService.Attach(viewModel);

            // ACT
            viewModel.IsDuplicateShortcut = false;

            // ASSERT
            Assert.That(viewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnIsDuplicateText()
        {
            var priceCurveRule = new Mock<IChatProductItemPriceCurveDefinitionRule>();
            var marketRule = new Mock<IChatProductItemMarketRule>();
            var shortcutRule = new Mock<IChatProductItemShortcutRule>();

            var service = new ChatProductItemValidationService(priceCurveRule.Object,
                                                             marketRule.Object,
                                                             shortcutRule.Object);

            // ACT
            var result = service.IsDuplicateText();

            // ASSERT
            Assert.That(result, Is.EqualTo("Duplicate Price Curve Mapping"));
        }
    }
}
