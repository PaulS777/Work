﻿using System.Collections.Generic;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.Controllers;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.FlatPrice.Controllers
{
    [TestFixture]
    public class CurveContributionViewModelControllerTests
    {
        [Test]
        public void ShouldInitializeFromCurveContributionDefinition()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> {priceCurveItem1, priceCurveItem2, priceCurveItem3};

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var controller = new CurveContributionViewModelController();

            // ACT
            controller.SetCurveContribution(curveContribution);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
            Assert.That(controller.ViewModel.IsDeleted, Is.False);
            Assert.That(controller.ViewModel.IsValid, Is.True);
        }


        [Test]
        public void ShouldSetHasChangedTrue_WhenFactorChanged()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var controller = new CurveContributionViewModelController();

            controller.SetCurveContribution(curveContribution);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.ViewModel.Factor = 2.5;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedFalse_WhenFactorChangeReverted()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var controller = new CurveContributionViewModelController();

            controller.SetCurveContribution(curveContribution);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            controller.ViewModel.Factor = 2.5;

            // ACT
            controller.ViewModel.Factor = 2.0;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldSetHasChangedTrue_WhenSelectedPriceCurveItemChanged()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var controller = new CurveContributionViewModelController();

            controller.SetCurveContribution(curveContribution);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem1;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedFalse_WhenSelectedPriceCurveItemChangeReverted()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var controller = new CurveContributionViewModelController();

            controller.SetCurveContribution(curveContribution);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem1;

            // ACT
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldSetIsDeletedTrueAndHasChanged_WhenRemoveCommandInvoked()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var controller = new CurveContributionViewModelController();

            controller.SetCurveContribution(curveContribution);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem1;

            // ACT
            controller.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.That(controller.ViewModel.IsDeleted, Is.True);
            Assert.That(controller.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldRevertIsDeletedAndHasChanged_WhenRemoveCommandInvokedAndIsDeletedTrue()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var controller = new CurveContributionViewModelController();

            controller.SetCurveContribution(curveContribution);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            controller.ViewModel.DeleteCommand.Execute();

            // ACT
            controller.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.That(controller.ViewModel.IsDeleted, Is.False);
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldNotUpdateHasChangedWhenDisposed()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var controller = new CurveContributionViewModelController();

            controller.SetCurveContribution(curveContribution);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.Dispose();

            controller.ViewModel.Factor = 2.5;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem1;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }
    }
}
