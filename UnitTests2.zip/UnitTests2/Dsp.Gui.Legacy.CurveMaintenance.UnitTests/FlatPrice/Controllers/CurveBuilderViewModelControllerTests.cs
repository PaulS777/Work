﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Exceptions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.Controllers;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.Services;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.ViewModels;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.FlatPrice.Controllers
{
    internal interface ICurveBuilderViewModelControllerTestObjects
    {
        ICurveProvider CurveProvider { get; }
        ICurveControlService CurveControlService { get; }
        IPriceCurveSettingsProvider PriceCurveSettingsProvider { get; }
        ICurveContributionViewModelProvider CurveContributionViewModelProvider { get; }
        IFlatPriceCurveUpdateService FlatPriceCurveUpdateService { get; }
        IPricingFailureParser PricingFailureParser { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IFlatPriceCurveEditorToolBarService ToolBarService { get; }
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        ISubject<bool> CurvesLoaded { get; }
        ISubject<Unit> CurveUpdated { get; }
        TestScheduler TestScheduler { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        ISubject<Unit> ToolBarUndo { get; }
        CurveBuilderViewModelController Controller { get; }
        CurveBuilderViewModel ViewModel { get; }
    }

    [TestFixture]
    public class CurveBuilderViewModelControllerTests
    {
        private class CurveBuilderViewModelControllerTestObjectBuilder
        {
            private bool _curvesLoaded;
            private List<PriceCurveDefinition> _priceCurveDefinitions;
            private List<DerivedCurveDefinition> _derivedCurveDefinitions;
            private List<FlatPriceCurveDefinition<MonthlyTenor>> _flatPriceCurveDefinitions;
            private Dictionary<int, PriceCurveSetting> _priceCurveSettings;
            private int _userId;
            private bool _canParseFailures;

            private CurveContributionViewModel _addedCurveContributionViewModel = new()
                                                                                  {
                                                                                      HasChanged = false,
                                                                                      IsValid = true,
                                                                                      IsDeleted = false
                                                                                  };

            public CurveBuilderViewModelControllerTestObjectBuilder WithCurvesLoaded(bool value)
            {
                _curvesLoaded = value;
                return this;
            }

            public CurveBuilderViewModelControllerTestObjectBuilder WithPriceCurveSettings(Dictionary<int, PriceCurveSetting> value)
            {
                _priceCurveSettings = value;
                return this;
            }

            public CurveBuilderViewModelControllerTestObjectBuilder WithPriceCurveDefinitions(List<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public CurveBuilderViewModelControllerTestObjectBuilder WithDerivedCurveDefinitions(List<DerivedCurveDefinition> values)
            {
                _derivedCurveDefinitions = values;
                return this;
            }

            public CurveBuilderViewModelControllerTestObjectBuilder WithFlatPriceCurveDefinitions(List<FlatPriceCurveDefinition<MonthlyTenor>> values)
            {
                _flatPriceCurveDefinitions = values;
                return this;
            }

            public CurveBuilderViewModelControllerTestObjectBuilder WithAddedCurveContributionViewModel(CurveContributionViewModel value)
            {
                _addedCurveContributionViewModel = value;
                return this;
            }

            public CurveBuilderViewModelControllerTestObjectBuilder WithUserId(int value)
            {
                _userId = value;
                return this;
            }

            public CurveBuilderViewModelControllerTestObjectBuilder WithCanParseFailures(bool value)
            {
                _canParseFailures = value;
                return this;
            }

            public ICurveBuilderViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<ICurveBuilderViewModelControllerTestObjects>();

                var testScheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(testScheduler);

                schedulerProvider.SetupGet(p => p.Dispatcher)
                                 .Returns(Scheduler.Immediate);

                schedulerProvider.SetupGet(p => p.Immediate)
                                 .Returns(Scheduler.Immediate);

                var curvesLoaded = new BehaviorSubject<bool>(_curvesLoaded);

                testObjects.SetupGet(o => o.CurvesLoaded)
                           .Returns(curvesLoaded);

                var curveProvider = new Mock<ICurveProvider>();

                curveProvider.SetupGet(c => c.CurvesLoaded)
                             .Returns(curvesLoaded);

                curveProvider.SetupGet(c => c.PriceCurveDefinitions)
                             .Returns(_priceCurveDefinitions);

                curveProvider.SetupGet(c => c.DerivedCurveDefinitions)
                             .Returns(_derivedCurveDefinitions);

                curveProvider.SetupGet(c => c.FlatPriceCurveDefinitions)
                             .Returns(_flatPriceCurveDefinitions);

                testObjects.SetupGet(o => o.CurveProvider)
                           .Returns(curveProvider.Object);

                var priceCurveSettings = new BehaviorSubject<Dictionary<int, PriceCurveSetting>>(_priceCurveSettings);

                testObjects.SetupGet(o => o.PriceCurveSettings)
                           .Returns(priceCurveSettings);

                var curveControlService = new Mock<ICurveControlService>();

                var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();

                priceCurveSettingsProvider.Setup(p => p.PriceCurveSettings)
                                          .Returns(priceCurveSettings);

                testObjects.SetupGet(o => o.PriceCurveSettingsProvider)
                           .Returns(priceCurveSettingsProvider.Object);

                var user = new UserBuilder().WithId(_userId).User();

                curveControlService.SetupGet(s => s.CurrentUserSnapshot)
                                   .Returns(user);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService.Object);

                var curveContributionViewModelProvider = new Mock<ICurveContributionViewModelProvider>();

                curveContributionViewModelProvider
                    .Setup(p => p.GetCurveContributionViewModel(It.IsAny<CurveContributionDefinition>()))
                    .Returns(new CurveContributionViewModel
                    {
                        HasChanged = false,
                        IsValid = true,
                        IsDeleted = false
                    });

                curveContributionViewModelProvider.Setup(p => p.GetNewCurveContributionViewModel())
                                                  .Returns(_addedCurveContributionViewModel);

                testObjects.SetupGet(o => o.CurveContributionViewModelProvider)
                           .Returns(curveContributionViewModelProvider.Object);

                var curveUpdated = new Subject<Unit>();
                testObjects.SetupGet(o => o.CurveUpdated).Returns(curveUpdated);

                var flatPriceCurveUpdateService = new Mock<IFlatPriceCurveUpdateService>();

                flatPriceCurveUpdateService.Setup(f => f.UpdateFlatPriceCurves(It.IsAny<IScheduler>(),
                                                       It.IsAny<FlatPriceCurveDefinition<MonthlyTenor>>(),
                                                       It.IsAny<CurveBuilderViewModel>()))
                                           .Returns(curveUpdated);

                testObjects.SetupGet(o => o.FlatPriceCurveUpdateService)
                           .Returns(flatPriceCurveUpdateService.Object);

                var flatPriceUpdateFailureParser = new Mock<IPricingFailureParser>();

                string[] messages;
                flatPriceUpdateFailureParser.Setup(p => p.TryParsePricingFailures(
                    It.IsAny<Dictionary<LinkedCurve, string>>(),
                    It.IsAny<List<PricingFailure>>(),
                    out messages)).Returns(_canParseFailures);

                testObjects.SetupGet(o => o.PricingFailureParser)
                           .Returns(flatPriceUpdateFailureParser.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var toolBarUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUpdate)
                           .Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUndo)
                           .Returns(toolBarUndo);

                var toolBarService = new Mock<IFlatPriceCurveEditorToolBarService>();

                toolBarService.SetupGet(tb => tb.Update)
                              .Returns(toolBarUpdate);

                toolBarService.SetupGet(tb => tb.Undo).
                               Returns(toolBarUndo);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBarService.Object);

                var controller = new CurveBuilderViewModelController(curveProvider.Object,
                                                                     curveControlService.Object,
                                                                     priceCurveSettingsProvider.Object,
                                                                     curveContributionViewModelProvider.Object,
                                                                     toolBarService.Object,
                                                                     schedulerProvider.Object,
                                                                     TestMocks.GetLoggerFactory().Object)
                {
                    PopupNotificationService = popupNotificationService.Object,
                    PricingFailureParser = flatPriceUpdateFailureParser.Object,
                    FlatPriceCurveUpdateService = flatPriceCurveUpdateService.Object
                };

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeDialogWithAvailableFlatPriceCurves()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(
                201, "flat-price", "desc", 101, 10, new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve), null);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>> { flatPriceCurve })
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

            // ACT
            testObjects.CurvesLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.FlatPriceCurveDefinitions.Count, Is.EqualTo(1));

            Mock.Get(testObjects.CurveContributionViewModelProvider)
                .Verify(p => p.Initialize(It.Is<Dictionary<LinkedCurve, string>>(d => d.Count == 2)));

            Assert.IsNull(testObjects.ViewModel.SelectedFlatPriceCurveDefinition);
            Assert.That(testObjects.ViewModel.ShowCurveDetails, Is.False);
        }

        [Test]
        public void ShouldPopulateDetailsWhenFlatPriceCurveSelected()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("price-curve").Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

            // ACT
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowCurveDetails, Is.True);
            Assert.That(testObjects.ViewModel.SpreadCurveDefinition, Is.EqualTo("price-curve"));
            Assert.That(testObjects.ViewModel.AnchorPointIndex, Is.EqualTo(2));

            Mock.Get(testObjects.CurveContributionViewModelProvider)
                .Verify(p => p.DisposeControllers(), Times.Once);

            Mock.Get(testObjects.CurveContributionViewModelProvider)
                .Verify(p => p.GetCurveContributionViewModel(It.IsAny<CurveContributionDefinition>()), Times.Exactly(2));

            Assert.That(testObjects.ViewModel.CurveContributions.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldAddNewContributedCurve_WhenAddCommandInvoked()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[] { curveContributionDefinition1, curveContributionDefinition2 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var newCurveContribution = new CurveContributionViewModel
            {
                HasChanged = true,
                IsValid = false,
                IsDeleted = false
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>> { flatPriceCurve })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .WithAddedCurveContributionViewModel(newCurveContribution)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            testObjects.ViewModel.AddCurveContributionCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.CurveContributions.Count, Is.EqualTo(3));
        }

        [Test]
        public void ShouldEnableUpdate_WhenAddedContributedCurveIsValid()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[] { curveContributionDefinition1, curveContributionDefinition2 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };


            var newCurveContribution = new CurveContributionViewModel
            {
                HasChanged = true,
                IsValid = false,
                IsDeleted = false
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>> { flatPriceCurve })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .WithAddedCurveContributionViewModel(newCurveContribution)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            testObjects.ViewModel.AddCurveContributionCommand.Execute();

            // ACT
            newCurveContribution.IsValid = true;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldRemoveAddedContributedCurve_When_Deleted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[] { curveContributionDefinition1, curveContributionDefinition2 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var newCurveContribution = new CurveContributionViewModel
            {
                HasChanged = true,
                IsValid = false,
                IsDeleted = false
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .WithAddedCurveContributionViewModel(newCurveContribution)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;
            testObjects.ViewModel.AddCurveContributionCommand.Execute();

            // ACT
            newCurveContribution.IsDeleted = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CurveContributions.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldNotRemoveExistingContributedCurve_When_Deleted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            testObjects.ViewModel.CurveContributions[1].IsDeleted = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CurveContributions.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldEnableUpdate_When_ExistingContributedCurveChanged()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            testObjects.ViewModel.CurveContributions[1].HasChanged = true;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldDisableUpdate_When_ContributedCurveChangeIsReverted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            testObjects.ViewModel.CurveContributions[1].HasChanged = true;
            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.CurveContributions[1].HasChanged = false;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
        }

        [Test]
        public void ShouldEnableUpdateCommand_WhenAnchorPointUpdated()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            testObjects.ViewModel.AnchorPointIndex = 4;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldDisableUpdateCommand_WhenSelectedFlatPriceCurveDefinitionIsNull()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;
            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = null;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
        }

        [Test]
        public void ShouldUpdateIsBusyAndInvokeUpdateService_OnToolBarUpdate()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.FlatPriceCurveUpdateService)
                .Verify(f => f.UpdateFlatPriceCurves(It.IsAny<IScheduler>(), flatPriceCurve, It.IsAny<CurveBuilderViewModel>()), Times.Once);
        }

        [Test]
        public void ShouldHandleErrorAndShowDialog_OnUpdatePricingFailuresException()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .WithCanParseFailures(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            var pricingFailure = new PricingFailure(201, 101, PricingFailureReason.AnchorPointTenorReferenceNotFound, new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), string.Empty);

            var exception = new Exception("failed", new PricingFailuresException(new List<PricingFailure> { pricingFailure }));

            testObjects.CurveUpdated.OnError(exception);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);

            string[] messages;
            Mock.Get(testObjects.PricingFailureParser).Verify(p => p.TryParsePricingFailures(
                It.IsAny<Dictionary<LinkedCurve, string>>(),
                It.IsAny<List<PricingFailure>>(),
                out messages), Times.Once);
        }

        [Test]
        public void ShouldHandleErrorAndShowDialog_OnUpdateCommandOnException()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .WithCanParseFailures(false)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            var exception = new Exception("failed");

            testObjects.CurveUpdated.OnError(exception);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(testObjects.ViewModel.MessageDialog.DialogMessages.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldRetainBusyDialog_OnCurveUpdateCompleted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.CurveUpdated.OnNext(Unit.Default);
            testObjects.CurveUpdated.OnCompleted();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
        }

        [Test]
        public void ShouldHandleCurveRefresh_And_SendPopupNotification_AfterUpdateCommandSuccess()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[] { curveContributionDefinition1, curveContributionDefinition2 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            testObjects.ToolBarUpdate.OnNext(Unit.Default);
            testObjects.CurveUpdated.OnNext(Unit.Default);
            testObjects.CurveUpdated.OnCompleted();

            // ACT
            testObjects.CurvesLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.AreSame(flatPriceCurve, testObjects.ViewModel.SelectedFlatPriceCurveDefinition);

            Mock.Get(testObjects.CurveContributionViewModelProvider)
                .Verify(p => p.GetCurveContributionViewModel(It.IsAny<CurveContributionDefinition>()), Times.Exactly(4));

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldNotUpdateSelectedCurveDetails_WhenCurvesReload_AndNotInUpdate()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;
            testObjects.ViewModel.AnchorPointIndex = 4;

            Mock.Get(testObjects.CurveContributionViewModelProvider).Reset();

            // ACT
            testObjects.CurvesLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.AnchorPointIndex, Is.EqualTo(4));

            Mock.Get(testObjects.CurveContributionViewModelProvider)
                .Verify(p => p.GetCurveContributionViewModel(It.IsAny<CurveContributionDefinition>()), Times.Never);
        }

        [Test]
        public void ShouldCloseMessageDialog_OnDialogOkCommand()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(
                201, "flat-price", "desc", 101, 10, new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve), null);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.ShowDialog = true;

            // ACT
            testObjects.ViewModel.MessageDialog.DialogOkCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldNotEnableUpdateCommand_WhenDisposed()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[] { curveContributionDefinition1, curveContributionDefinition2 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            testObjects.Controller.Dispose();

            Mock.Get(testObjects.ToolBarService)
                .Invocations.Clear();

            // ACT
            testObjects.ViewModel.AnchorPointIndex = 4;
            testObjects.ViewModel.CurveContributions[0].HasChanged = true;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true), Times.Never);
        }

        [Test]
        public void ShouldBeAbleToEditCurveWhenUserSelectsCurveWithSamePublisher()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithPriceCurveSettings(priceCurveSettings)
                                                                                    .WithUserId(10)
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.True);
        }

        [Test]
        public void ShouldNotBeAbleToEditCurveWhenUserSelectsCurveWithOtherPublisher()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };


            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithPriceCurveSettings(priceCurveSettings)
                                                                                    .WithUserId(10)
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.False);
        }

        [Test]
        public void ShouldUpdateCurveToEditableWhenSelectedCurvePublisherIsUpdatedToCurrentUser()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>> { flatPriceCurve })
                                                                                    .WithPriceCurveSettings(priceCurveSettings)
                                                                                    .WithUserId(10)
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            var priceCurveSettingsUpdate = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            testObjects.PriceCurveSettings.OnNext(priceCurveSettingsUpdate);
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.True);
        }

        [Test]
        public void ShouldUpdateCurveToNonEditableWhenSelectedCurvePublisherIsUpdatedToOtherUser()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithPriceCurveSettings(priceCurveSettings)
                                                                                    .WithUserId(10)
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            var priceCurveSettingsUpdate = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            testObjects.PriceCurveSettings.OnNext(priceCurveSettingsUpdate);
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.False);
        }

        [Test]
        public void ShouldSetCanEditCurveTrueWhenPriceCurveSettingUpdateWithNoCurveSelected()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };


            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithPriceCurveSettings(priceCurveSettings)
                                                                                    .WithUserId(10)
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = null;

            // ACT
            var priceCurveSettingsUpdate = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            testObjects.PriceCurveSettings.OnNext(priceCurveSettingsUpdate);
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.True);
        }

        [Test]
        public void ShouldEnableToolBarUndo_WhenSelectedCurveHasChanged()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var newCurveContribution = new CurveContributionViewModel
            {
                HasChanged = true,
                IsValid = false,
                IsDeleted = false
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .WithAddedCurveContributionViewModel(newCurveContribution)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            testObjects.ViewModel.AddCurveContributionCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(true));
        }

        [Test]
        public void ShouldDisableToolBarUndo_WhenCurveChangedAreReverted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var newCurveContribution = new CurveContributionViewModel
            {
                HasChanged = true,
                IsValid = false,
                IsDeleted = false
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .WithAddedCurveContributionViewModel(newCurveContribution)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            // ACT
            testObjects.ViewModel.AddCurveContributionCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(true));
        }

        [Test]
        public void ShouldResetDialog_When_Undo_WithCurveSelected()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var curveContributionDefinition1 = new CurveContributionDefinition(new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve));
            var curveContributionDefinition2 = new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve));

            var anchorPoint = new AnchorPoint(2, new[]
                                                 {
                                                     curveContributionDefinition1, curveContributionDefinition2
                                                 });

            var spreadDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var flatPriceCurve = new FlatPriceCurveDefinition<MonthlyTenor>(201, "flat-price", "desc", 101, 10, spreadDefinitionId, anchorPoint);

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(flatPriceCurve)),
                new()
            };

            var testObjects = new CurveBuilderViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                    .WithDerivedCurveDefinitions(derivedCurves)
                                                                                    .WithFlatPriceCurveDefinitions(new List<FlatPriceCurveDefinition<MonthlyTenor>>
                                                                                                                   {
                                                                                                                       flatPriceCurve
                                                                                                                   })
                                                                                    .WithCurvesLoaded(true)
                                                                                    .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedFlatPriceCurveDefinition = flatPriceCurve;

            testObjects.ViewModel.AnchorPointIndex = 4;
            testObjects.ViewModel.AddCurveContributionCommand.Execute();

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.CurveContributions.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.AnchorPointIndex, Is.EqualTo(2));

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(false));
        }
    }
}
