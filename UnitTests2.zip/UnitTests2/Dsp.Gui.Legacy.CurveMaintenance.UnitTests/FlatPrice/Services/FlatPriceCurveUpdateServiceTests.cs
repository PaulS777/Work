﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Exceptions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.Services;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.ViewModels;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.FlatPrice.Services
{
    internal interface IFlatPriceCurveUpdateServiceTestObjects
    {
        IAdminApiServiceClient AdminApiServiceClient { get; }
        IFlatPriceCurveDefinitionBuilder FlatPriceCurveDefinitionBuilder { get; }
        FlatPriceCurveUpdateService FlatPriceCurveUpdateService { get; }
    }

    [TestFixture]
    public class FlatPriceCurveUpdateServiceTests
    {
        private class FlatPriceCurveUpdateServiceTestObjectBuilder
        {
            private bool _updateResponse;
            private List<PricingFailure> _pricingFailures;
            private DerivedCurveDefinition<MonthlyTenor> _derivedCurveDefinition;

            public FlatPriceCurveUpdateServiceTestObjectBuilder WithUpdateResponse(bool value, List<PricingFailure> pricingFailures = null)
            {
                _updateResponse = value;
                _pricingFailures = pricingFailures;
                return this;
            }

            public FlatPriceCurveUpdateServiceTestObjectBuilder WithUpdatedDerivedCurveDefinition(DerivedCurveDefinition<MonthlyTenor> value)
            {
                _derivedCurveDefinition = value;
                return this;
            }

            public IFlatPriceCurveUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IFlatPriceCurveUpdateServiceTestObjects>();

                var response = _updateResponse
                    ? new AdminApiServiceResponse(true)
                    : new AdminApiServiceResponse(_pricingFailures);

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                adminApiServiceClient.Setup(a => a.Update(It.IsAny<int>(), It.IsAny<DerivedCurveDefinition>()))
                                     .Returns(Task.FromResult(response));

                testObjects.SetupGet(o => o.AdminApiServiceClient).Returns(adminApiServiceClient.Object);

                var flatPriceCurveDefinitionBuilder = new Mock<IFlatPriceCurveDefinitionBuilder>();

                flatPriceCurveDefinitionBuilder.Setup(b => b.GetFlatPriceCurve(
                                                   It.IsAny<FlatPriceCurveDefinition<MonthlyTenor>>(),
                                                   It.IsAny<int>(),
                                                   It.IsAny<IReadOnlyList<CurveContributionViewModel>>()))
                                               .Returns(_derivedCurveDefinition);

                testObjects.SetupGet(o => o.FlatPriceCurveDefinitionBuilder)
                           .Returns(flatPriceCurveDefinitionBuilder.Object);

                var flatPriceCurveUpdateService = new FlatPriceCurveUpdateService(
                    adminApiServiceClient.Object,
                    flatPriceCurveDefinitionBuilder.Object);

                testObjects.SetupGet(o => o.FlatPriceCurveUpdateService).Returns(flatPriceCurveUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateFlatPriceCurves()
        {
            var testScheduler = new TestScheduler();

            var viewModel = new CurveBuilderViewModel
            {
                AnchorPointIndex = 2,
                CurveContributions = new ObservableCollection<CurveContributionViewModel> { new() }
            };

            var updatedCurve = new DerivedCurveDefinition<MonthlyTenor>(new FlatPriceCurveDefinition<MonthlyTenor>
            (
                101, "name", "desc", 201, 1,
                new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve),
                new AnchorPoint(2, new List<CurveContributionDefinition> { new(new LinkedCurve(99, PriceCurveDefinitionType.DerivedCurve)) })
            ));

            var testObjects = new FlatPriceCurveUpdateServiceTestObjectBuilder().WithUpdatedDerivedCurveDefinition(updatedCurve)
                                                                                .WithUpdateResponse(true)
                                                                                .Build();
            var completed = false;

            // ACT
            var flatPrice = new FlatPriceCurveDefinition<MonthlyTenor>
            (
                101, "name", "desc", 201, 1, new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve), new AnchorPoint(1, new List<CurveContributionDefinition>())
            );

            testObjects.FlatPriceCurveUpdateService.UpdateFlatPriceCurves(testScheduler, flatPrice, viewModel)
                       .Subscribe(_ => completed = true);

            testScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.FlatPriceCurveDefinitionBuilder).Verify(b =>
                b.GetFlatPriceCurve(flatPrice, 2, It.Is<ObservableCollection<CurveContributionViewModel>>(l => l.Count == 1)), Times.Once);

            Mock.Get(testObjects.AdminApiServiceClient).Verify(a => a.Update(101, It.IsAny<DerivedCurveDefinition>()), Times.Once);
            Assert.That(completed, Is.True);
        }

        [Test]
        public void ShouldHandlePricingFailuresErrorOnUpdate()
        {
            var testScheduler = new TestScheduler();

            var viewModel = new CurveBuilderViewModel
            {
                AnchorPointIndex = 2,
                CurveContributions = new ObservableCollection<CurveContributionViewModel> { new() }
            };

            var updatedCurve = new DerivedCurveDefinition<MonthlyTenor>(new FlatPriceCurveDefinition<MonthlyTenor>
            (
                101, "name", "desc", 201, 1,
                new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve),
                new AnchorPoint(2, new List<CurveContributionDefinition> { new(new LinkedCurve(99, PriceCurveDefinitionType.DerivedCurve)) })
            ));

            var failures = new List<PricingFailure> { new(101, 201, PricingFailureReason.AnchorPointIndexExceedsSpreadCurveLength, null, null) };

            var testObjects = new FlatPriceCurveUpdateServiceTestObjectBuilder().WithUpdatedDerivedCurveDefinition(updatedCurve)
                                                                                .WithUpdateResponse(false, failures)
                                                                                .Build();
            var completed = false;
            Exception error = null;

            // ACT
            var flatPrice = new FlatPriceCurveDefinition<MonthlyTenor>
            (
                101, "name", "desc", 201, 1, new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve), new AnchorPoint(1,  new List<CurveContributionDefinition>())
            );

            testObjects.FlatPriceCurveUpdateService.UpdateFlatPriceCurves(testScheduler, flatPrice, viewModel)
                       .Subscribe(_ => completed = true,
                                  ex => error = ex);

            testScheduler.AdvanceBy(10);

            // ASSERT
            Assert.That(completed, Is.False);
            Assert.IsNotNull(error);
            // ReSharper disable once PossibleNullReferenceException
            Assert.That(((PricingFailuresException)error.InnerException).PricingFailures.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldThrowErrorOnInvalidViewModel()
        {
            var testScheduler = new TestScheduler();

            var viewModel = new CurveBuilderViewModel
            {
                AnchorPointIndex = null,
                CurveContributions = new ObservableCollection<CurveContributionViewModel> { new() }
            };


            var testObjects = new FlatPriceCurveUpdateServiceTestObjectBuilder().Build();
            var completed = false;
            Exception error = null;

            // ACT
            var flatPrice = new FlatPriceCurveDefinition<MonthlyTenor>
            (
                101, "name", "desc", 201, 1, new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve), new AnchorPoint(1, new List<CurveContributionDefinition>())
            );

            testObjects.FlatPriceCurveUpdateService.UpdateFlatPriceCurves(testScheduler, flatPrice, viewModel)
                       .Subscribe(_ => completed = true,
                                  ex => error = ex);

            testScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.FlatPriceCurveDefinitionBuilder).Verify(b =>
                b.GetFlatPriceCurve(flatPrice, It.IsAny<int>(), It.IsAny<IReadOnlyList<CurveContributionViewModel>>()), Times.Never());

            Mock.Get(testObjects.AdminApiServiceClient).Verify(a => a.Update(It.IsAny<int>(), It.IsAny<DerivedCurveDefinition>()), Times.Never);

            Assert.That(completed, Is.False);
            Assert.IsNotNull(error);
        }
    }
}
