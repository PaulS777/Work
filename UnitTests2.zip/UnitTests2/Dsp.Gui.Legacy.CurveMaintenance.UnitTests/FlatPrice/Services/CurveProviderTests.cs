﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.FlatPrice.Services
{
    internal interface ICurveProviderTestObjects
    {
        ISubject<List<DerivedCurveDefinition>> DerivedCurves { get; }
        ISubject<List<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        CurveProvider CurveProvider { get; }
    }

    [TestFixture]
    public class CurveProviderTests
    {
        private class CurveProviderTestObjectBuilder
        {
            public ICurveProviderTestObjects Build()
            {
                var testObjects = new Mock<ICurveProviderTestObjects>();

                var derivedCurves = new BehaviorSubject<List<DerivedCurveDefinition>>(null);
                testObjects.SetupGet(o => o.DerivedCurves).Returns(derivedCurves);

                var priceCurves = new BehaviorSubject<List<PriceCurveDefinition>>(null);

                testObjects.SetupGet(o => o.PriceCurveDefinitions).Returns(priceCurves);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.DerivedCurveDefinitions).Returns(derivedCurves);

                curveControlService.SetupGet(c => c.PriceCurveDefinitions).Returns(priceCurves);

                var provider = new CurveProvider(curveControlService.Object,
                                                 TestMocks.GetSchedulerProvider().Object,
                                                 TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.CurveProvider).Returns(provider);

                return testObjects.Object;
            }
        }

        //private static ProductDefinition ProductDefinition()
        //{
        //    return new ProductDefinition(99, "product", "desc", new List<CurveRegion>(), CurveGroup.Crude, 1, UnitOfMeasure.MT, 1, 1, 1, new Density(), 1);
        //}

        [Test]
        public void ShouldPublishOnCurvesLoaded()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().Build()
            };

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>())
            };

            var testObjects = new CurveProviderTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveProvider.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext(priceCurves);
                testObjects.DerivedCurves.OnNext(derivedCurves);

                // ASSERT
                Assert.That(result, Is.True);
                Assert.That(testObjects.CurveProvider.PriceCurveDefinitions.Count, Is.EqualTo(1));
                Assert.That(testObjects.CurveProvider.DerivedCurveDefinitions.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotPublishCuresLoaded_WhenPriceCurvesNull()
        {
            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>())
            };

            var testObjects = new CurveProviderTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveProvider.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext(null);
                testObjects.DerivedCurves.OnNext(derivedCurves);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishCurvesLoaded_WhenDerivedCurvesNull()
        {
            var priceCurve = new PriceCurveDefinitionTestObjectBuilder().Build();

			var testObjects = new CurveProviderTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveProvider.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext([priceCurve]);
                testObjects.DerivedCurves.OnNext(null);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldGetFlatPriceCurveDefinitions()
        {
			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().Build();

			var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(
                    new DerivedCurveDefinition<MonthlyTenor>(
                                                             new FlatPriceCurveDefinition<MonthlyTenor>
                                                                 (
                                                                  201, "flat-price","desc",101, 10, new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve), null
                                                                 )))
            };

            var testObjects = new CurveProviderTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveProvider.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext([priceCurve]);
                testObjects.DerivedCurves.OnNext(derivedCurves);

                // ASSERT
                Assert.That(result, Is.True);
                Assert.That(testObjects.CurveProvider.FlatPriceCurveDefinitions.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotPublishWhenDisposed()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().Build()
            };

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>())
            };

            var testObjects = new CurveProviderTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveProvider.CurvesLoaded.Subscribe(r => result = r))
            {
                testObjects.CurveProvider.Dispose();

                // ACT
                testObjects.PriceCurveDefinitions.OnNext(priceCurves);
                testObjects.DerivedCurves.OnNext(derivedCurves);

                // ASSERT
                Assert.That(result, Is.False);
                Assert.IsNull(testObjects.CurveProvider.PriceCurveDefinitions);
                Assert.IsNull(testObjects.CurveProvider.DerivedCurveDefinitions);
            }
        }
    }
}
