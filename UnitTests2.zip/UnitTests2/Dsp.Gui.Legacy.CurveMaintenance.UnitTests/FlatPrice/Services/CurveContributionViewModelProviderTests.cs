﻿using System.Collections.Generic;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.Controllers;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.Services;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.FlatPrice.Services
{
    internal interface ICurveContributionViewModelProviderTestObjects
    {
        ICurveContributionViewModelController Controller { get; }
        CurveContributionViewModelProvider CurveContributionViewModelProvider { get; }
    }

    [TestFixture]
    public class CurveContributionViewModelProviderTests
    {
        private class CurveContributionViewModelProviderTestObjectBuilder
        {
            public ICurveContributionViewModelProviderTestObjects Build()
            {
                var testObjects = new Mock<ICurveContributionViewModelProviderTestObjects>();

                var viewModel = new CurveContributionViewModel();

                var controller = new Mock<ICurveContributionViewModelController>();

                controller.SetupGet(c => c.ViewModel)
                          .Returns(viewModel);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller.Object);
  
                var factory = new Mock<IServiceFactory<ICurveContributionViewModelController>>();

                factory.Setup(f => f.Create())
                       .Returns(controller.Object);

                var provider = new CurveContributionViewModelProvider
                               {
                                   Factory = factory.Object
                               };

                testObjects.SetupGet(o => o.CurveContributionViewModelProvider)
                           .Returns(provider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCreateCurveContributionViewModelFromDefinition()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var curveLookup = new Dictionary<LinkedCurve, string>
            {
                {priceCurveDefinition1, "price-curve-1"},
                {priceCurveDefinition2, "derived-curve-1"},
                {priceCurveDefinition3, "derived-curve-2"}
            };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var testObjects = new CurveContributionViewModelProviderTestObjectBuilder().Build();

            testObjects.CurveContributionViewModelProvider.Initialize(curveLookup);

            // ACT
            var result = testObjects.CurveContributionViewModelProvider
                                    .GetCurveContributionViewModel(curveContribution);

            // ASSERT
            Mock.Get(testObjects.Controller)
                .Verify(c => c.SetCurveContribution(curveContribution));

            Assert.That(result.PriceCurveItems.Count, Is.EqualTo(3));
            Assert.That(result.Factor, Is.EqualTo(2.0d));
            Assert.That(result.SelectedPriceCurveItem.LinkedCurve, Is.EqualTo(priceCurveDefinition2));            
        }

        [Test]
        public void ShouldGetNewCurveContributionViewModel()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var curveLookup = new Dictionary<LinkedCurve, string>
            {
                {priceCurveDefinition1, "price-curve-1"},
                {priceCurveDefinition2, "derived-curve-1"},
                {priceCurveDefinition3, "derived-curve-2"}
            };

            var testObjects = new CurveContributionViewModelProviderTestObjectBuilder().Build();

            testObjects.CurveContributionViewModelProvider.Initialize(curveLookup);

            // ACT
            var result = testObjects.CurveContributionViewModelProvider.GetNewCurveContributionViewModel();

            // ASSERT
            Assert.That(result.PriceCurveItems.Count, Is.EqualTo(3));
            Assert.That(result.Factor, Is.EqualTo(1.0d));
            Assert.That(result.HasChanged, Is.True);
            Assert.IsNull(result.SelectedPriceCurveItem);
        }

        [Test]
        public void ShouldDisposeControllers()
        {
            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var curveLookup = new Dictionary<LinkedCurve, string>
            {
                {priceCurveDefinition1, "price-curve-1"},
                {priceCurveDefinition2, "derived-curve-1"},
                {priceCurveDefinition3, "derived-curve-2"}
            };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);

            var testObjects = new CurveContributionViewModelProviderTestObjectBuilder().Build();

            testObjects.CurveContributionViewModelProvider.Initialize(curveLookup);

            testObjects.CurveContributionViewModelProvider.GetCurveContributionViewModel(curveContribution);

            // ACT
            testObjects.CurveContributionViewModelProvider.DisposeControllers();

            // ASSERT
            Mock.Get(testObjects.Controller)
                .Verify(c => c.Dispose());
        }
    }
}
