﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.Services;
using Dsp.Gui.Legacy.CurveMaintenance.FlatPrice.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.FlatPrice.Services
{
    [TestFixture]
    public class FlatPriceCurveDefinitionBuilderTests
    {
        [Test]
        public void ShouldGenerateFlatPriceCurveDefinition()
        {
            var spreadCurveDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);

            var anchorPoint = new AnchorPoint(1, new List<CurveContributionDefinition>());

            var definition = new FlatPriceCurveDefinition<MonthlyTenor>(101, "flat-price", "desc", 201, 10,
                spreadCurveDefinitionId, anchorPoint);

            var contributionLinkedCurve = new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem = new PriceCurveItem(contributionLinkedCurve, string.Empty);

            var viewModel = new CurveContributionViewModel { Factor = 2, SelectedPriceCurveItem = priceCurveItem };

            var builder = new FlatPriceCurveDefinitionBuilder();

            // ACT
            var result = builder.GetFlatPriceCurve(definition, 3, new[] { viewModel });

            // ASSERT
            Assert.That(result.FlatPriceCurveDefinition.Id, Is.EqualTo(101));
            Assert.That(result.FlatPriceCurveDefinition.Name, Is.EqualTo("flat-price"));
            Assert.That(result.FlatPriceCurveDefinition.Description, Is.EqualTo("desc"));
            Assert.That(result.FlatPriceCurveDefinition.PriceCurveDefinitionId, Is.EqualTo(201));
            Assert.That(result.FlatPriceCurveDefinition.PublisherId, Is.EqualTo(10));
            Assert.That(result.FlatPriceCurveDefinition.SpreadLinkedCurve, Is.EqualTo(spreadCurveDefinitionId));
            Assert.That(result.FlatPriceCurveDefinition.AnchorPoint.OneBasedIndex, Is.EqualTo(3));
            Assert.That(result.FlatPriceCurveDefinition.AnchorPoint.CurveContributions.Count, Is.EqualTo(1));
            Assert.That(result.FlatPriceCurveDefinition.AnchorPoint.CurveContributions[0].Factor, Is.EqualTo(2));
            Assert.That(result.FlatPriceCurveDefinition.AnchorPoint.CurveContributions[0].LinkedCurve, Is.EqualTo(contributionLinkedCurve));
        }

        [Test]
        public void ShouldIgnoreDeletedContributedCurves()
        {
            var spreadCurveDefinitionId = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);

            var anchorPoint = new AnchorPoint(1, new List<CurveContributionDefinition>());

            var definition = new FlatPriceCurveDefinition<MonthlyTenor>(101, "flat-price", "desc", 201, 10,
                spreadCurveDefinitionId, anchorPoint);

            var contributionLinkedCurve = new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem = new PriceCurveItem(contributionLinkedCurve, string.Empty);

            var viewModel = new CurveContributionViewModel { Factor = 2, SelectedPriceCurveItem = priceCurveItem };
            var deletedViewModel = new CurveContributionViewModel { Factor = 2, SelectedPriceCurveItem = priceCurveItem, IsDeleted = true };

            var builder = new FlatPriceCurveDefinitionBuilder();

            // ACT
            var result = builder.GetFlatPriceCurve(definition, 3, new[] { viewModel, deletedViewModel });

            // ASSERT
            Assert.That(result.FlatPriceCurveDefinition.Id, Is.EqualTo(101));
            Assert.That(result.FlatPriceCurveDefinition.Name, Is.EqualTo("flat-price"));
            Assert.That(result.FlatPriceCurveDefinition.Description, Is.EqualTo("desc"));
            Assert.That(result.FlatPriceCurveDefinition.PriceCurveDefinitionId, Is.EqualTo(201));
            Assert.That(result.FlatPriceCurveDefinition.PublisherId, Is.EqualTo(10));
            Assert.That(result.FlatPriceCurveDefinition.SpreadLinkedCurve, Is.EqualTo(spreadCurveDefinitionId));
            Assert.That(result.FlatPriceCurveDefinition.AnchorPoint.OneBasedIndex, Is.EqualTo(3));
            Assert.That(result.FlatPriceCurveDefinition.AnchorPoint.CurveContributions.Count, Is.EqualTo(1));
            Assert.That(result.FlatPriceCurveDefinition.AnchorPoint.CurveContributions[0].Factor, Is.EqualTo(2));
            Assert.That(result.FlatPriceCurveDefinition.AnchorPoint.CurveContributions[0].LinkedCurve, Is.EqualTo(contributionLinkedCurve));
        }
    }
}
