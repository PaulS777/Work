﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.Services;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.Partition.Services
{
    [TestFixture]
    public class PartitionedCurveDefinitionBuilderTests
    {
        [Test]
        public void ShouldGeneratePartitionedCurveDefinition()
        {
            var definition = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partitioned", "desc", 101, 10, new CurvePartition<MonthlyTenor>[] { }
            );

            var contributionCurveDefinitionId = new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem = new PriceCurveItem(contributionCurveDefinitionId, string.Empty);

            var viewModels = new[]
            {
                new CurvePartitionViewModel
                {
                    StartDate = new DateTime(2019, 1, 1),
                    SelectedPriceCurveItem = priceCurveItem,
                    Factor = 2
                }
            };

            var builder = new PartitionedCurveDefinitionBuilder();

            // ACT
            var result = builder.GetPartitionedCurve(definition, viewModels);

            var tenor = new MonthlyTenor(2019, 1);

            // ASSERT
            Assert.That(result.PartitionedCurveDefinition.Id, Is.EqualTo(201));
            Assert.That(result.PartitionedCurveDefinition.Name, Is.EqualTo("partitioned"));
            Assert.That(result.PartitionedCurveDefinition.Description, Is.EqualTo("desc"));
            Assert.That(result.PartitionedCurveDefinition.PriceCurveDefinitionId, Is.EqualTo(101));
            Assert.That(result.PartitionedCurveDefinition.PublisherId, Is.EqualTo(10));
            Assert.That(result.PartitionedCurveDefinition.Partitions.Count, Is.EqualTo(1));
            Assert.That(result.PartitionedCurveDefinition.Partitions[0].Start, Is.EqualTo(tenor));
            Assert.That(result.PartitionedCurveDefinition.Partitions[0].CurveContributionDefinition.LinkedCurve.Id, Is.EqualTo(301));
            Assert.That(result.PartitionedCurveDefinition.Partitions[0].CurveContributionDefinition.Factor, Is.EqualTo(2));
        }

        [Test]
        public void ShouldIgnoreDeletedContributedCurves()
        {
            var definition = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partitioned", "desc", 101, 10, new CurvePartition<MonthlyTenor>[] { }
            );

            var contributionCurveDefinitionId = new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem = new PriceCurveItem(contributionCurveDefinitionId, string.Empty);

            var viewModels = new[]
            {
                new CurvePartitionViewModel
                {
                    StartDate = new DateTime(2019, 1, 1),
                    SelectedPriceCurveItem = priceCurveItem,
                    Factor = 2
                },
                new CurvePartitionViewModel
                {
                    StartDate = new DateTime(2019, 1, 2),
                    SelectedPriceCurveItem = priceCurveItem,
                    Factor = 2,
                    IsDeleted = true
                }
            };

            var builder = new PartitionedCurveDefinitionBuilder();

            // ACT
            var result = builder.GetPartitionedCurve(definition, viewModels);

            // ASSERT
            Assert.That(result.PartitionedCurveDefinition.Partitions.Count, Is.EqualTo(1));
        }
    }
}
