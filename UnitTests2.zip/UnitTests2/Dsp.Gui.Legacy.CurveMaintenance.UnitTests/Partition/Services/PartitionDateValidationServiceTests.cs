﻿using System;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.Services;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.Partition.Services
{
    [TestFixture]
    public class PartitionDateValidationServiceTests
    {
        [TestCase(1, 2, 3, true, true, true)]
        [TestCase(1, 3, 2, true, true, false)]
        [TestCase(3, 1, 2, true, false, false)]
        [TestCase(2, 1, 3, true, false, true)]
        public void ShouldValidatePartitionDates(int month1, int month2, int month3, 
                                                 bool expected1, bool expected2, bool expected3)
        {
            var partition1 = new CurvePartitionViewModel {StartDate = new DateTime(2019, month1, 1)};
            var partition2 = new CurvePartitionViewModel { StartDate = new DateTime(2019, month2, 1) };
            var partition3 = new CurvePartitionViewModel { StartDate = new DateTime(2019, month3, 1) };

            var partitions = new[] {partition1, partition2, partition3};

            var validationService = new PartitionDateValidationService();

            // ACT
            validationService.ValidatePartitionDates(partitions);

            // ASSERT
            Assert.That(partition1.IsStartDateValid, Is.EqualTo(expected1));
            Assert.That(partition2.IsStartDateValid, Is.EqualTo(expected2));
            Assert.That(partition3.IsStartDateValid, Is.EqualTo(expected3));
        }

    }
}
