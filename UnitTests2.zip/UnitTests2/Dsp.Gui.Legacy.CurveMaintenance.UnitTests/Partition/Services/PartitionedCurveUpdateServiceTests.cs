﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Exceptions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.Services;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.ViewModels;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.Partition.Services
{
    internal interface IPartitionedCurveUpdateServiceTestObjects
    {
        IAdminApiServiceClient AdminApiServiceClient { get; }
        IPartitionedCurveDefinitionBuilder PartitionedCurveDefinitionBuilder { get; }
        PartitionedCurveUpdateService PartitionedCurveUpdateService { get; }
    }

    [TestFixture]
    public class PartitionedCurveUpdateServiceTests
    {
        private class PartitionedCurveUpdateServiceTestObjectBuilder
        {
            private bool _updateResponse;
            private List<PricingFailure> _pricingFailures;
            private DerivedCurveDefinition<MonthlyTenor> _derivedCurveDefinition;

            public PartitionedCurveUpdateServiceTestObjectBuilder WithUpdateResponse(bool value, List<PricingFailure> pricingFailures = null)
            {
                _updateResponse = value;
                _pricingFailures = pricingFailures;
                return this;
            }

            public PartitionedCurveUpdateServiceTestObjectBuilder WithUpdatedDerivedCurveDefinition(DerivedCurveDefinition<MonthlyTenor> value)
            {
                _derivedCurveDefinition = value;
                return this;
            }

            public IPartitionedCurveUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IPartitionedCurveUpdateServiceTestObjects>();

                var response = _updateResponse
                    ? new AdminApiServiceResponse(true)
                    : new AdminApiServiceResponse(_pricingFailures);

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                adminApiServiceClient.Setup(a => a.Update(It.IsAny<int>(), It.IsAny<DerivedCurveDefinition>()))
                                     .Returns(Task.FromResult(response));

                testObjects.SetupGet(o => o.AdminApiServiceClient).Returns(adminApiServiceClient.Object);

                var partitionedCurveDefinitionBuilder = new Mock<IPartitionedCurveDefinitionBuilder>();

                partitionedCurveDefinitionBuilder.Setup(b => b.GetPartitionedCurve(
                                                     It.IsAny<PartitionedCurveDefinition<MonthlyTenor>>(),
                                                     It.IsAny<IReadOnlyList<CurvePartitionViewModel>>()))
                                                 .Returns(_derivedCurveDefinition);

                testObjects.SetupGet(o => o.PartitionedCurveDefinitionBuilder)
                           .Returns(partitionedCurveDefinitionBuilder.Object);

                var partitionedCurveUpdateService = new PartitionedCurveUpdateService(
                    adminApiServiceClient.Object,
                    partitionedCurveDefinitionBuilder.Object);

                testObjects.SetupGet(o => o.PartitionedCurveUpdateService).Returns(partitionedCurveUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdatePartitionedCurves()
        {
            var testScheduler = new TestScheduler();

            var viewModel = new PartitionCurveEditorViewModel
            {
                CurvePartitions = new ObservableCollection<CurvePartitionViewModel> {new()}
            };


            var partitions = new[]
            {
                new CurvePartition<MonthlyTenor>(
                    new MonthlyTenor(2019, 1),
                    new CurveContributionDefinition(new LinkedCurve(99,
                        PriceCurveDefinitionType.DerivedCurve)))
            };

            var updatedCurve = new DerivedCurveDefinition<MonthlyTenor>
            (
                new PartitionedCurveDefinition<MonthlyTenor>(
                    101, "name", "desc", 201, 10, partitions)
            );

            var testObjects = new PartitionedCurveUpdateServiceTestObjectBuilder().WithUpdatedDerivedCurveDefinition(updatedCurve)
                                                                                  .WithUpdateResponse(true)
                                                                                  .Build();

            var completed = false;

            // ACT
            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            ( 
                101, "name", "desc", 201, 10, new List<CurvePartition<MonthlyTenor>>()
            );

            testObjects.PartitionedCurveUpdateService
                       .UpdatePartitionedCurves(testScheduler, partitionedCurve, viewModel)
                       .Subscribe(_ => completed = true);

            testScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PartitionedCurveDefinitionBuilder).Verify(b =>
                b.GetPartitionedCurve(partitionedCurve, It.Is<ObservableCollection<CurvePartitionViewModel>>(l => l.Count == 1)), Times.Once);

            Mock.Get(testObjects.AdminApiServiceClient).Verify(a => a.Update(101, It.IsAny<DerivedCurveDefinition>()), Times.Once);
            Assert.That(completed, Is.True);
        }

        [Test]
        public void ShouldHandlePricingFailuresErrorOnUpdate()
        {
            var testScheduler = new TestScheduler();

            var viewModel = new PartitionCurveEditorViewModel
            {
                CurvePartitions = new ObservableCollection<CurvePartitionViewModel> { new() }
            };

            var partitions = new[]
            {
                new CurvePartition<MonthlyTenor>(
                    new MonthlyTenor(2019, 1),
                    new CurveContributionDefinition(new LinkedCurve(99,
                        PriceCurveDefinitionType.DerivedCurve)))
            };

            var updatedCurve = new DerivedCurveDefinition<MonthlyTenor>
            (
                new PartitionedCurveDefinition<MonthlyTenor>(
                    101, "name", "desc", 201, 10, partitions)
            );
            var failures = new List<PricingFailure> { new(101, 201, PricingFailureReason.PartitionPriceCurveDefinitionMismatch, null, null) };

            var testObjects = new PartitionedCurveUpdateServiceTestObjectBuilder().WithUpdatedDerivedCurveDefinition(updatedCurve)
                                                                                  .WithUpdateResponse(false, failures)
                                                                                  .Build();

            var completed = false;
            Exception error = null;

            // ACT
            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                101, "name", "desc", 201, 10, new List<CurvePartition<MonthlyTenor>>()
            );

            testObjects.PartitionedCurveUpdateService
                       .UpdatePartitionedCurves(testScheduler, partitionedCurve, viewModel)
                       .Subscribe(_ => completed = true,
                                  ex => error = ex);

            testScheduler.AdvanceBy(10);

            // ASSERT
            Assert.That(completed, Is.False);
            Assert.IsNotNull(error);
            // ReSharper disable once PossibleNullReferenceException
            Assert.That(((PricingFailuresException)error.InnerException).PricingFailures.Count, Is.EqualTo(1));
        }

    }
}
