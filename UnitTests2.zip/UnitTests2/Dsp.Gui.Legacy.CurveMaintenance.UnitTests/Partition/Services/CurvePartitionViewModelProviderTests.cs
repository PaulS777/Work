﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.Controllers;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.Services;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.Partition.Services
{
    internal interface ICurvePartitionViewModelProviderTestObjects
    {
        ICurvePartitionViewModelController CurvePartitionViewModelController { get; }
        CurvePartitionViewModelProvider CurvePartitionViewModelProvider { get; }
    }

    [TestFixture]
    public class CurvePartitionViewModelProviderTests
    {
        private class CurvePartitionViewModelProviderTestObjectBuilder
        {
            public ICurvePartitionViewModelProviderTestObjects Build()
            {
                var testObjects = new Mock<ICurvePartitionViewModelProviderTestObjects>();

                var viewModel = new CurvePartitionViewModel();
                var controller = new Mock<ICurvePartitionViewModelController>();
                controller.SetupGet(c => c.ViewModel).Returns(viewModel);

                testObjects.SetupGet(o => o.CurvePartitionViewModelController).Returns(controller.Object);

                var factory = new Mock<IServiceFactory<ICurvePartitionViewModelController>>();

                factory.Setup(f => f.Create())
                       .Returns(controller.Object);

                var provider = new CurvePartitionViewModelProvider()
                               {
                                   Factory = factory.Object
                               };
                
                testObjects.SetupGet(o => o.CurvePartitionViewModelProvider).Returns(provider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPopulateAvailableCurvePartitionsByMatchingPriceCurveId()
        {
            var curveId = 101;

            var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201)
                                                                               .WithCurveId(curveId)
                                                                               .Build();

            var manualCurve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202)
                                                                               .WithCurveId(curveId)
                                                                               .Build();

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>(
                curveId, "partition", "desc", curveId, 10, new[] {partition1, partition2});

            var manualCurve4 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(211)
                                                                               .WithCurveId(111)
                                                                               .Build();

            var manualCurve5 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(212)
                                                                               .WithCurveId(112)
                                                                               .Build();

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(manualCurve1)),
                new(new DerivedCurveDefinition<MonthlyTenor>(manualCurve2)),
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new(new DerivedCurveDefinition<MonthlyTenor>(manualCurve4)),
                new(new DerivedCurveDefinition < MonthlyTenor >(manualCurve5))
            };

            var partition = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve)));

            var provider = new CurvePartitionViewModelProviderTestObjectBuilder().Build()
                                                                                 .CurvePartitionViewModelProvider;

            provider.Initialize(derivedCurves);

            // ACT
            var viewModel = provider.GetCurvePartitionViewModel(partition, curveId);

            // ASSERT
            Assert.That(viewModel.PriceCurveItems.Count, Is.EqualTo(2));
            Assert.That(viewModel.PriceCurveItems[0].LinkedCurve.Id, Is.EqualTo(201));
            Assert.That(viewModel.PriceCurveItems[1].LinkedCurve.Id, Is.EqualTo(202));
            Assert.That(viewModel.SelectedPriceCurveItem.LinkedCurve.Id, Is.EqualTo(201));
            Assert.That(viewModel.StartDate.Year, Is.EqualTo(2019));
            Assert.That(viewModel.StartDate.Month, Is.EqualTo(1));
        }

        [Test]
        public void ShouldGetNewCurvePartitionViewModel()
        {
            var curveId = 101;

            var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201)
                                                                               .WithCurveId(curveId)
                                                                               .Build();

            var manualCurve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202)
                                                                               .WithCurveId(curveId)
                                                                               .Build();

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>(
                curveId, "partition", "desc", curveId, 10, new[] { partition1, partition2 });

            var manualCurve4 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(211)
                                                                               .WithCurveId(111)
                                                                               .Build();

            var manualCurve5 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(212)
                                                                               .WithCurveId(112)
                                                                               .Build();

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(manualCurve1)),
                new(new DerivedCurveDefinition < MonthlyTenor >(manualCurve2)),
                new(new DerivedCurveDefinition < MonthlyTenor >(partitionedCurve)),
                new(new DerivedCurveDefinition < MonthlyTenor >(manualCurve4)),
                new(new DerivedCurveDefinition < MonthlyTenor >(manualCurve5))
            };

            var provider = new CurvePartitionViewModelProviderTestObjectBuilder().Build()
                                                                                 .CurvePartitionViewModelProvider;

            provider.Initialize(derivedCurves);

            var startDate = new DateTime(2019, 1, 1);

            // ACT
            var viewModel = provider.GetNewCurvePartitionViewModel(startDate, curveId);

            // ASSERT
            Assert.That(viewModel.PriceCurveItems.Count, Is.EqualTo(2));
            Assert.That(viewModel.PriceCurveItems[0].LinkedCurve.Id, Is.EqualTo(201));
            Assert.That(viewModel.PriceCurveItems[1].LinkedCurve.Id, Is.EqualTo(202));
            Assert.IsNull(viewModel.SelectedPriceCurveItem);
            Assert.That(viewModel.StartDate, Is.EqualTo(startDate));
        }

        [Test]
        public void ShouldDisposeControllers()
        {
            var curveId = 101;

            var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201)
                                                                               .WithCurveId(curveId)
                                                                               .Build();

            var manualCurve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202)
                                                                               .WithCurveId(curveId)
                                                                               .Build();

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>(
                curveId, "partition", "desc", curveId, 10, new[] { partition1, partition2 });

            var manualCurve4 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(211)
                                                                               .WithCurveId(111)
                                                                               .Build();

            var manualCurve5 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(212)
                                                                               .WithCurveId(112)
                                                                               .Build();

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(manualCurve1)),
                new(new DerivedCurveDefinition < MonthlyTenor >(manualCurve2)),
                new(new DerivedCurveDefinition < MonthlyTenor >(partitionedCurve)),
                new(new DerivedCurveDefinition < MonthlyTenor >(manualCurve4)),
                new(new DerivedCurveDefinition < MonthlyTenor >(manualCurve5))
            };

            var testObjects = new CurvePartitionViewModelProviderTestObjectBuilder().Build();
            var provider = testObjects.CurvePartitionViewModelProvider;

            provider.Initialize(derivedCurves);

            var startDate = new DateTime(2019, 1, 1);

            provider.GetNewCurvePartitionViewModel(startDate, curveId);

            // ACT
            provider.DisposeControllers();

            // ASSERT
            Mock.Get(testObjects.CurvePartitionViewModelController)
                .Verify(c => c.Dispose());
        }
    }
}
