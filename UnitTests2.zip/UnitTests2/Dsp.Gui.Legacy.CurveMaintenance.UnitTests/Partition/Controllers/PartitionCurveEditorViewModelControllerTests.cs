﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Exceptions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.Controllers;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.Services;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.ViewModels;
using Dsp.Gui.Legacy.CurveMaintenance.Services;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.Partition.Controllers
{
    internal interface IPartitionCurveEditorViewModelControllerTestObjects
    {
        ICurveDefinitionProvider CurveDefinitionProvider { get; }
        ICurveControlService CurveControlService { get; }
        IPriceCurveSettingsProvider PriceCurveSettingsProvider { get; }
        ICurvePartitionViewModelProvider CurvePartitionViewModelProvider { get; }
        IPartitionedCurveUpdateService PartitionedCurveUpdateService { get; }
        IPricingFailureParser PricingFailuresParser { get; }
        IPartitionDateValidationService PartitionDateValidationService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IPartitionCurveEditorToolBarService ToolBarService { get; }
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        ISubject<bool> CurvesLoaded { get; }
        ISubject<Unit> CurveUpdated { get; }
        TestScheduler TestScheduler { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        ISubject<Unit> ToolBarUndo { get; }
        PartitionCurveEditorViewModelController Controller { get; }
        PartitionCurveEditorViewModel ViewModel { get; }
    }

    [TestFixture]
    public class PartitionCurveEditorViewModelControllerTests
    {
        private class PartitionCurveEditorViewModelControllerTestObjectBuilder
        {
            private bool _curvesLoaded;
            private List<PriceCurveDefinition> _priceCurveDefinitions;
            private List<DerivedCurveDefinition> _derivedCurveDefinitions;
            private List<PartitionedCurveDefinition<MonthlyTenor>> _partitionedCurveDefinitions;
            private Dictionary<int, PriceCurveSetting> _priceCurveSettings;
            private int _userId;
            private bool _canParseFailures;

            private CurvePartitionViewModel _addedCurvePartitionViewModel = new()
                                                                            {
                                                                                HasChanged = false,
                                                                                IsValid = true,
                                                                                IsDeleted = false
                                                                            };

            public PartitionCurveEditorViewModelControllerTestObjectBuilder WithCurvesLoaded(bool value)
            {
                _curvesLoaded = value;
                return this;
            }

            public PartitionCurveEditorViewModelControllerTestObjectBuilder WithPriceCurveSettings(
                Dictionary<int, PriceCurveSetting> value)
            {
                _priceCurveSettings = value;
                return this;
            }


            public PartitionCurveEditorViewModelControllerTestObjectBuilder WithPriceCurveDefinitions(
                List<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public PartitionCurveEditorViewModelControllerTestObjectBuilder WithDerivedCurveDefinitions(
                List<DerivedCurveDefinition> values)
            {
                _derivedCurveDefinitions = values;
                return this;
            }

            public PartitionCurveEditorViewModelControllerTestObjectBuilder WithPartitionedCurveDefinitions(
                List<PartitionedCurveDefinition<MonthlyTenor>> values)
            {
                _partitionedCurveDefinitions = values;
                return this;
            }

            public PartitionCurveEditorViewModelControllerTestObjectBuilder WithAddedCurvePartitionViewModel(
                CurvePartitionViewModel value)
            {
                _addedCurvePartitionViewModel = value;
                return this;
            }

            public PartitionCurveEditorViewModelControllerTestObjectBuilder WithUserId(int value)
            {
                _userId = value;
                return this;
            }
            public PartitionCurveEditorViewModelControllerTestObjectBuilder WithCanParseFailures(bool value)
            {
                _canParseFailures = value;
                return this;
            }

            public IPartitionCurveEditorViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IPartitionCurveEditorViewModelControllerTestObjects>();

                var testScheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();
                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
                schedulerProvider.SetupGet(p => p.Immediate).Returns(Scheduler.Immediate);

                var curvesLoaded = new BehaviorSubject<bool>(_curvesLoaded);
                testObjects.SetupGet(o => o.CurvesLoaded).Returns(curvesLoaded);

                var curveDefinitionProvider = new Mock<ICurveDefinitionProvider>();
                curveDefinitionProvider.SetupGet(c => c.CurvesLoaded).Returns(curvesLoaded);
                curveDefinitionProvider.SetupGet(c => c.PriceCurveDefinitions).Returns(_priceCurveDefinitions);
                curveDefinitionProvider.SetupGet(c => c.DerivedCurveDefinitions).Returns(_derivedCurveDefinitions);
                curveDefinitionProvider.SetupGet(c => c.PartitionedCurveDefinitions)
                                       .Returns(_partitionedCurveDefinitions);
                testObjects.SetupGet(o => o.CurveDefinitionProvider).Returns(curveDefinitionProvider.Object);

                var priceCurveSettings = new BehaviorSubject<Dictionary<int, PriceCurveSetting>>(_priceCurveSettings);
                testObjects.SetupGet(o => o.PriceCurveSettings).Returns(priceCurveSettings);

                var curveControlService = new Mock<ICurveControlService>();

                var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();
                priceCurveSettingsProvider.Setup(p => p.PriceCurveSettings).Returns(priceCurveSettings);
                testObjects.SetupGet(o => o.PriceCurveSettingsProvider).Returns(priceCurveSettingsProvider.Object);

                var user = new UserBuilder().WithId(_userId).User();


                curveControlService.SetupGet(s => s.CurrentUserSnapshot).Returns(user);
                testObjects.SetupGet(o => o.CurveControlService).Returns(curveControlService.Object);

                var curvePartitionViewModelProvider = new Mock<ICurvePartitionViewModelProvider>();

                curvePartitionViewModelProvider
                    .Setup(p => p.GetCurvePartitionViewModel(It.IsAny<CurvePartition<MonthlyTenor>>(), It.IsAny<int>()))
                    .Returns(new CurvePartitionViewModel
                    {
                        HasChanged = false,
                        IsValid = true,
                        IsDeleted = false
                    });

                curvePartitionViewModelProvider.Setup(p => p.GetNewCurvePartitionViewModel(It.IsAny<DateTime>(), It.IsAny<int>()))
                                               .Returns(_addedCurvePartitionViewModel);

                testObjects.SetupGet(o => o.CurvePartitionViewModelProvider)
                           .Returns(curvePartitionViewModelProvider.Object);

                var curveUpdated = new Subject<Unit>();
                testObjects.SetupGet(o => o.CurveUpdated).Returns(curveUpdated);

                var partitionedCurveUpdateService = new Mock<IPartitionedCurveUpdateService>();

                partitionedCurveUpdateService.Setup(u => u.UpdatePartitionedCurves(It.IsAny<IScheduler>(),
                                                 It.IsAny<PartitionedCurveDefinition<MonthlyTenor>>(),
                                                 It.IsAny<PartitionCurveEditorViewModel>()))
                                             .Returns(curveUpdated);

                testObjects.SetupGet(o => o.PartitionedCurveUpdateService)
                           .Returns(partitionedCurveUpdateService.Object);

                var pricingFailuresParser = new Mock<IPricingFailureParser>();

                string[] messages;

                pricingFailuresParser.Setup(p => p.TryParsePricingFailures(
                    It.IsAny<Dictionary<LinkedCurve, string>>(),
                    It.IsAny<List<PricingFailure>>(),
                    out messages))
                .Returns(_canParseFailures);

                testObjects.SetupGet(o => o.PricingFailuresParser).Returns(pricingFailuresParser.Object);

                var partitionDateValidationService = new Mock<IPartitionDateValidationService>();
                testObjects.SetupGet(o => o.PartitionDateValidationService)
                           .Returns(partitionDateValidationService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();
                testObjects.SetupGet(o => o.PopupNotificationService).Returns(popupNotificationService.Object);

                var toolBarUpdate = new Subject<Unit>();
                testObjects.SetupGet(o => o.ToolBarUpdate).Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();
                testObjects.SetupGet(o => o.ToolBarUndo).Returns(toolBarUndo);

                var toolBarService = new Mock<IPartitionCurveEditorToolBarService>();

                toolBarService.SetupGet(tb => tb.Update).Returns(toolBarUpdate);
                toolBarService.SetupGet(tb => tb.Undo).Returns(toolBarUndo);

                testObjects.SetupGet(o => o.ToolBarService).Returns(toolBarService.Object);

                var controller = new PartitionCurveEditorViewModelController(
                    curveDefinitionProvider.Object,
                    curveControlService.Object,
                    priceCurveSettingsProvider.Object,
                    curvePartitionViewModelProvider.Object,
                    toolBarService.Object,
                    schedulerProvider.Object,
                    TestMocks.GetLoggerFactory().Object)
                {
                    PopupNotificationService = popupNotificationService.Object,
                    PartitionedCurveUpdateService = partitionedCurveUpdateService.Object,
                    PricingFailureParser = pricingFailuresParser.Object,
                    PartitionDateValidationService = partitionDateValidationService.Object
                };

                testObjects.SetupGet(o => o.Controller).Returns(controller);

                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeDialogWithAvailablePartitionCurves()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new CurvePartition<MonthlyTenor>[] { }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects = new PartitionCurveEditorViewModelControllerTestObjectBuilder()
                              .WithPriceCurveDefinitions(priceCurves)
                              .WithDerivedCurveDefinitions(derivedCurves)
                              .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                               {
                                                                   partitionedCurve
                                                               })
                              .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

            // ACT
            testObjects.CurvesLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.PartitionedCurveDefinitions.Count, Is.EqualTo(1));

            Mock.Get(testObjects.CurvePartitionViewModelProvider)
                .Verify(p => p.Initialize(It.Is<List<DerivedCurveDefinition>>(d => d.Count == 2)));

            Assert.IsNull(testObjects.ViewModel.SelectedPartitionedCurveDefinition);
            Assert.That(testObjects.ViewModel.ShowCurveDetails, Is.False);
        }

        [Test]
        public void ShouldPopulateDetailsWhenPartitionedCurveSelected()
        {
            var curveId = 101;

            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(curveId).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102,
                    PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103,
                    PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", curveId, 10, new[] {partition1, partition2}
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects = new PartitionCurveEditorViewModelControllerTestObjectBuilder()
                              .WithPriceCurveDefinitions(priceCurves)
                              .WithDerivedCurveDefinitions(derivedCurves)
                              .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                               {
                                                                   partitionedCurve
                                                               })
                              .WithCurvesLoaded(true)
                              .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

            // ACT
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowCurveDetails, Is.True);

            Mock.Get(testObjects.CurvePartitionViewModelProvider)
                .Verify(p => p.DisposeControllers(), Times.Once);

            Mock.Get(testObjects.CurvePartitionViewModelProvider)
                .Verify(p => p.GetCurvePartitionViewModel(It.IsAny<CurvePartition<MonthlyTenor>>(), curveId), Times.Exactly(2));

            Assert.That(testObjects.ViewModel.CurvePartitions.Count, Is.EqualTo(2));

            Mock.Get(testObjects.PartitionDateValidationService)
                .Verify(v => v.ValidatePartitionDates(testObjects.ViewModel.CurvePartitions));
        }

        [Test]
        public void ShouldAddNewCurvePartition_And_DisableUpdate_WhenAddCommandInvoked()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102,
                    PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103,
                    PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] {partition1, partition2}
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var newPartition = new CurvePartitionViewModel
            {
                HasChanged = true, IsValid = false, IsDeleted = false
            };

            var testObjects = new PartitionCurveEditorViewModelControllerTestObjectBuilder()
                              .WithPriceCurveDefinitions(priceCurves)
                              .WithDerivedCurveDefinitions(derivedCurves)
                              .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                               {
                                                                   partitionedCurve
                                                               })
                              .WithCurvesLoaded(true)
                              .WithAddedCurvePartitionViewModel(newPartition)
                              .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.AddCurvePartitionCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.CurvePartitions.Count, Is.EqualTo(3));

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
        }

        [Test]
        public void ShouldValidatePartitionDates_WhenNewPartitionAdded()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102,
                    PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103,
                    PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var newPartition = new CurvePartitionViewModel { HasChanged = true, IsValid = false, IsDeleted = false };

            var testObjects = new PartitionCurveEditorViewModelControllerTestObjectBuilder()
                              .WithPriceCurveDefinitions(priceCurves)
                              .WithDerivedCurveDefinitions(derivedCurves)
                              .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                               {
                                                                   partitionedCurve
                                                               })
                              .WithCurvesLoaded(true)
                              .WithAddedCurvePartitionViewModel(newPartition)
                              .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            Mock.Get(testObjects.PartitionDateValidationService).Reset();

            // ACT
            testObjects.ViewModel.AddCurvePartitionCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.PartitionDateValidationService)
                .Verify(v => v.ValidatePartitionDates(It.IsAny<IList<CurvePartitionViewModel>>()), Times.Once);
        }

        [Test]
        public void ShouldValidatePartitionDates_PartitionDateChangedOnAddedPartition()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var newPartition = new CurvePartitionViewModel { HasChanged = true, IsValid = false, IsDeleted = false };

            var testObjects = new PartitionCurveEditorViewModelControllerTestObjectBuilder()
                              .WithPriceCurveDefinitions(priceCurves)
                              .WithDerivedCurveDefinitions(derivedCurves)
                              .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                               {
                                                                   partitionedCurve
                                                               })
                              .WithCurvesLoaded(true)
                              .WithAddedCurvePartitionViewModel(newPartition)
                              .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ViewModel.AddCurvePartitionCommand.Execute();

            Mock.Get(testObjects.PartitionDateValidationService).Reset();

            // ACT
            newPartition.StartDate = new DateTime(2019, 6, 1);

            // ASSERT
            Mock.Get(testObjects.PartitionDateValidationService)
                .Verify(v => v.ValidatePartitionDates(It.IsAny<IList<CurvePartitionViewModel>>()), Times.Once);
        }

        [Test]
        public void ShouldValidatePartitionDates_NewPartitionRemoved()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var newPartition = new CurvePartitionViewModel { HasChanged = true, IsValid = false, IsDeleted = false };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .WithAddedCurvePartitionViewModel(newPartition)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ViewModel.AddCurvePartitionCommand.Execute();

            Mock.Get(testObjects.PartitionDateValidationService).Reset();

            // ACT
            newPartition.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.PartitionDateValidationService)
                .Verify(v => v.ValidatePartitionDates(It.IsAny<IList<CurvePartitionViewModel>>()));
        }

        [Test]
        public void ShouldEnableToolBarUpdate_WhenAddedCurvePartitionIsValid()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] {partition1, partition2}
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var newPartition = new CurvePartitionViewModel {HasChanged = true, IsValid = false, IsDeleted = false};

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .WithAddedCurvePartitionViewModel(newPartition)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ViewModel.AddCurvePartitionCommand.Execute();

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            newPartition.IsValid = true;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldRemoveAddedCurvePartition_When_Deleted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] {partition1, partition2}
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var newPartition = new CurvePartitionViewModel {HasChanged = true, IsValid = false, IsDeleted = false};

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .WithAddedCurvePartitionViewModel(newPartition)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ViewModel.AddCurvePartitionCommand.Execute();

            // ACT
            newPartition.IsDeleted = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CurvePartitions.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldEnableToolBarUpdate_When_ExistingContributedCurveChanged()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] {partition1, partition2}
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.CurvePartitions[1].HasChanged = true;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldDisableToolBarUpdate_When_CurvePartitionChangeIsReverted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ViewModel.CurvePartitions[1].HasChanged = true;
            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.CurvePartitions[1].HasChanged = false;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
        }

        [Test]
        public void ShouldInvokePartitionDateValidationWhenCurvePartitionStartDateChanged()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {partitionedCurve})
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            Mock.Get(testObjects.PartitionDateValidationService).Reset();

            // ACT
            testObjects.ViewModel.CurvePartitions[1].StartDate = new DateTime(2019, 9, 1);

            // ASSERT
            Mock.Get(testObjects.PartitionDateValidationService)
                .Verify(v => v.ValidatePartitionDates(testObjects.ViewModel.CurvePartitions));
        }

        [Test]
        public void ShouldUpdateIsBusyAndInvokeUpdateService_OnToolBarUpdate()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.PartitionedCurveUpdateService)
                .Verify(f => f.UpdatePartitionedCurves(It.IsAny<IScheduler>(), partitionedCurve, 
                                                       It.IsAny<PartitionCurveEditorViewModel>()), 
                        Times.Once);
        }

        [Test]
        public void ShouldHandleErrorAndShowDialog_OnUpdateCommandPricingFailuresException()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .WithCanParseFailures(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            var pricingFailure = new PricingFailure(201, 101, PricingFailureReason.AnchorPointTenorReferenceNotFound, new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), string.Empty);
            
            var exception = new Exception("failed", new PricingFailuresException(new List<PricingFailure> { pricingFailure }));
            
            testObjects.CurveUpdated.OnError(exception);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);

            string[] messages;

            Mock.Get(testObjects.PricingFailuresParser)
                .Verify(p => p.TryParsePricingFailures(It.IsAny<Dictionary<LinkedCurve, string>>(),
                                                       It.IsAny<List<PricingFailure>>(),
                                                       out messages), Times.Once);
        }

        [Test]
        public void ShouldHandleErrorAndShowDialog_OnUpdateCommandOnException()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };


            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .WithCanParseFailures(false)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            var exception = new Exception("failed");

            testObjects.CurveUpdated.OnError(exception);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(testObjects.ViewModel.MessageDialog.DialogMessages.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldRetainBusyDialog_OnCurveUpdateCompleted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.CurveUpdated.OnNext(Unit.Default);
            testObjects.CurveUpdated.OnCompleted();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
        }

        [Test]
        public void ShouldHandleCurveRefresh_AfterUpdateCommandSuccess()
        {
            var priceCurveDefinitionId = 101;

            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", priceCurveDefinitionId, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ToolBarUpdate.OnNext(Unit.Default);
            testObjects.CurveUpdated.OnNext(Unit.Default);
            testObjects.CurveUpdated.OnCompleted();

            // ACT
            testObjects.CurvesLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(partitionedCurve, Is.SameAs(testObjects.ViewModel.SelectedPartitionedCurveDefinition));

            Mock.Get(testObjects.CurvePartitionViewModelProvider)
                .Verify(p => p.GetCurvePartitionViewModel(It.IsAny<CurvePartition<MonthlyTenor>>(), 
                                                          priceCurveDefinitionId), 
                        Times.Exactly(4));

            Mock.Get(testObjects.PopupNotificationService).Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldNotUpdateSelectedCurveDetails_WhenCurvesReload_AndNotInUpdate()
        {
            var priceCurveDefinitionId = 101;

            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", priceCurveDefinitionId, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            // ARRANGE - PARTITION CHANGE
            testObjects.ViewModel.CurvePartitions[1].Factor = 2.0;
            testObjects.ViewModel.CurvePartitions[1].HasChanged = true;

            Mock.Get(testObjects.CurvePartitionViewModelProvider).Reset();

            // ACT
            testObjects.CurvesLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.CurvePartitions[1].Factor, Is.EqualTo(2.0));

            Mock.Get(testObjects.CurvePartitionViewModelProvider)
                .Verify(p => p.GetCurvePartitionViewModel(It.IsAny<CurvePartition<MonthlyTenor>>(), 
                                                          It.IsAny<int>()), 
                        Times.Never);
        }

        [Test]
        public void ShouldCloseMessageDialog_OnDialogOkCommand()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.ShowDialog = true;

            // ACT
            testObjects.ViewModel.MessageDialog.DialogOkCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldNotEnableToolBarUpdate_WhenDisposed()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ARRANGE - Dispose
            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.CurvePartitions[1].Factor = 2.0;
            testObjects.ViewModel.CurvePartitions[1].HasChanged = true;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true), Times.Never);
        }

        [Test]
        public void ShouldBeAbleToEditCurveWhenUserSelectsCurveWithSamePublisher()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102,
                    PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103,
                    PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101, 
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithPriceCurveSettings(priceCurveSettings)
                                                                                .WithUserId(10)
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.True);
        }

        [Test]
        public void ShouldNotBeAbleToEditCurveWhenUserSelectsCurveWithOtherPublisher()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                  
                                                                                                                 {partitionedCurve})
                                                                                .WithPriceCurveSettings(priceCurveSettings)
                                                                                .WithUserId(10)
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.False);
        }

        [Test]
        public void ShouldUpdateCurveToEditableWhenSelectedCurvePublisherIsUpdatedToCurrentUser()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithPriceCurveSettings(priceCurveSettings)
                                                                                .WithUserId(10)
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            // ACT
            var priceCurveSettingsUpdate = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            testObjects.PriceCurveSettings.OnNext(priceCurveSettingsUpdate);
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.True);
        }

        [Test]
        public void ShouldUpdateCurveToNonEditableWhenSelectedCurvePublisherIsUpdatedToOtherUser()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithPriceCurveSettings(priceCurveSettings)
                                                                                .WithUserId(10)
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            // ACT
            var priceCurveSettingsUpdate = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            testObjects.PriceCurveSettings.OnNext(priceCurveSettingsUpdate);
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);


            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.False);
        }

        [Test]
        public void ShouldSetCanEditCurveTrueWhenPriceCurveSettingUpdateWithNoCurveSelected()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithPriceCurveSettings(priceCurveSettings)
                                                                                .WithUserId(10)
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = null;

            // ACT
            var priceCurveSettingsUpdate = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            testObjects.PriceCurveSettings.OnNext(priceCurveSettingsUpdate);
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);


            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditCurve, Is.True);
        }

        [TestCase(true)]
        [TestCase(false)]
        public void ShouldEnableToolBarUndo_WhenCurvePartitionIsChanged(bool isValid)
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            // ACT
            testObjects.ViewModel.CurvePartitions[0].HasChanged = true;
            testObjects.ViewModel.CurvePartitions[0].IsValid = isValid;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(true));
        }

        [Test]
        public void ShouldDisableToolBarUndo_WhenCurvePartitionChangesAreReverted()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;
            testObjects.ViewModel.CurvePartitions[0].HasChanged = true;
            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.CurvePartitions[0].HasChanged = false;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(false));
        }

        [Test]
        public void ShouldResetDialog_When_ToolBarUndo_WithCurveSelected()
        {
            var priceCurves = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build()
            };

            var partition1 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 1),
                new CurveContributionDefinition(new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve)));

            var partition2 = new CurvePartition<MonthlyTenor>(
                new MonthlyTenor(2019, 2),
                new CurveContributionDefinition(new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve)));

            var partitionedCurve = new PartitionedCurveDefinition<MonthlyTenor>
            (
                201, "partition", "desc", 101, 10, new[] { partition1, partition2 }
            );

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(partitionedCurve)),
                new()
            };

            var newPartition = new CurvePartitionViewModel
            {
                HasChanged = true,
                IsValid = false,
                IsDeleted = false
            };

            var testObjects 
                = new PartitionCurveEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                .WithDerivedCurveDefinitions(derivedCurves)
                                                                                .WithPartitionedCurveDefinitions(new List<PartitionedCurveDefinition<MonthlyTenor>>
                                                                                                                 {
                                                                                                                     partitionedCurve
                                                                                                                 })
                                                                                .WithCurvesLoaded(true)
                                                                                .WithAddedCurvePartitionViewModel(newPartition)
                                                                                .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.SelectedPartitionedCurveDefinition = partitionedCurve;

            testObjects.ViewModel.AddCurvePartitionCommand.Execute();
            newPartition.IsValid = true;

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.CurvePartitions.Count, Is.EqualTo(2));

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(false));
        }
    }
}
