﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Legacy.CurveMaintenance.Partition.Controllers;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.Partition.Controllers
{
    [TestFixture]
    public class CurvePartitionViewModelControllerTests
    {
        [Test]
        public void ShouldInitializeFromCurvePartition()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> {priceCurveItem1, priceCurveItem2, priceCurveItem3};

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            // ACT
            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
            Assert.That(controller.ViewModel.IsDeleted, Is.False);
        }

        [Test] public void ShouldSetIsValidFalse_WhenNewCurvePartitionInitializedWithNoCurveSelected()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            // ACT
            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;

            // ASSERT
            Assert.That(controller.ViewModel.IsValid, Is.False);
        }

        [Test]
        public void ShouldSetHasChangedTrue_WhenStartDateChanged()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);
            var date2 = new DateTime(2019, 2, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.ViewModel.StartDate = date2;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedTrue_WhenStartDateChangeReverted()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);
            var date2 = new DateTime(2019, 2, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;
            controller.ViewModel.StartDate = date2;

            // ACT
            controller.ViewModel.StartDate = date1;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldSetHasChangedTrue_WhenFactorChanged()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.ViewModel.Factor = 2.5;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedTrue_WhenFactorChangeReverted()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;
            controller.ViewModel.Factor = 2.5;

            // ACT
            controller.ViewModel.Factor = 2.0;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldSetHasChangedTrue_WhenSelectedPriceCurveItemChanged()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem1;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedTrue_WhenSelectedPriceCurveItemChangeReverted()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem1;

            // ACT
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldSetIsDeletedTrueAndHasChanged_WhenRemoveCommandInvoked()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.ViewModel.RemoveCommand.Execute();

            // ASSERT
            Assert.That(controller.ViewModel.IsDeleted, Is.True);
            Assert.That(controller.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldRevertIsDeletedAndHasChanged_WhenRemoveCommandInvokedAndIsDeletedTrue()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            controller.ViewModel.RemoveCommand.Execute();

            // ACT
            controller.ViewModel.RemoveCommand.Execute();

            // ASSERT
            Assert.That(controller.ViewModel.IsDeleted, Is.False);
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldSetIsValidTrueWhenStartDateIsValid()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.ViewModel.IsStartDateValid = true;

            // ASSERT
            Assert.That(controller.ViewModel.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalseWhenStartDateIsInValid()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;
            controller.ViewModel.IsStartDateValid = true;
         
            // ACT
            controller.ViewModel.IsStartDateValid = false;

            // ASSERT
            Assert.That(controller.ViewModel.IsValid, Is.False);
        }

        [Test]
        public void ShouldNotUpdateHasChangedWhenDisposed()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var date1 = new DateTime(2019, 1, 1);
            var date2 = new DateTime(2019, 2, 1);

            var priceCurveDefinition1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCurveDefinition2 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var priceCurveDefinition3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCurveItem1 = new PriceCurveItem(priceCurveDefinition1, "price-curve-1");
            var priceCurveItem2 = new PriceCurveItem(priceCurveDefinition2, "derived-curve-1");
            var priceCurveItem3 = new PriceCurveItem(priceCurveDefinition3, "derived-curve-2");

            var priceCurveItems = new List<PriceCurveItem> { priceCurveItem1, priceCurveItem2, priceCurveItem3 };

            var curveContribution = new CurveContributionDefinition(priceCurveDefinition2, 2.0d);
            var curvePartition = new CurvePartition<MonthlyTenor>(tenor1, curveContribution);

            var controller = new CurvePartitionViewModelController();

            controller.SetCurvePartition(curvePartition);
            controller.ViewModel.PriceCurveItems = priceCurveItems;
            controller.ViewModel.StartDate = date1;
            controller.ViewModel.Factor = 2.0;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem2;

            // ACT
            controller.Dispose();

            controller.ViewModel.StartDate = date2;
            controller.ViewModel.Factor = 2.5;
            controller.ViewModel.SelectedPriceCurveItem = priceCurveItem1;

            // ASSERT
            Assert.That(controller.ViewModel.HasChanged, Is.False);
        }
    }
}
