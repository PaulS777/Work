﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Services;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.PartitionShift.Services
{
    [TestFixture]
    public class PartitionDateShiftCalculatorTests
    {
        [Test]
        public void ShouldShiftPartitionsByPinUpdate()
        {
            var partition1 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 1,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 1, 1), new DateTime(2019, 1, 1) }

                },
                Partitions = new List<string> { "19-Jan", "19-Jan" }
            };

            var partition2 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 2,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 3, 1), new DateTime(2019, 4, 1) }

                },
                Partitions = new List<string> { "19-Mar", "19-Apr" }
            };

            var partition3 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 3,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 6, 1), new DateTime(2019, 7, 1) }

                },
                Partitions = new List<string> { "19-Jun", "19-Jul" }
            };

            var partitions = new List<AggregatedPartitionViewModel> { partition1, partition2, partition3 };

            var service = new PartitionDateShiftCalculator();

            // ACT
            service.ShiftPartitionsByPin(2, 2, partitions);

            // ASSERT
            Assert.That(partitions[0].IsPartitionShiftPin, Is.False);
            Assert.That(partitions[0].IsPartitionShift, Is.False);
            Assert.That(partitions[0].Partitions[0], Is.EqualTo("19-Jan"));
            Assert.That(partitions[0].Partitions[1], Is.EqualTo("19-Jan"));

            Assert.That(partitions[1].IsPartitionShiftPin, Is.True);
            Assert.That(partitions[1].IsPartitionShift, Is.True);
            Assert.That(partitions[1].Partitions[0], Is.EqualTo("19-May"));
            Assert.That(partitions[1].Partitions[1], Is.EqualTo("19-Jun"));

            Assert.That(partitions[2].IsPartitionShiftPin, Is.False);
            Assert.That(partitions[2].IsPartitionShift, Is.True);
            Assert.That(partitions[2].Partitions[0], Is.EqualTo("19-Aug"));
            Assert.That(partitions[2].Partitions[1], Is.EqualTo("19-Sep"));
        }


        [Test]
        public void ShouldRevertTenorShiftOnPartitionsBeforeShiftPin()
        {
            var partition1 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 1,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 1, 1), new DateTime(2019, 1, 1) }

                },
                Partitions = new List<string> { "19-Jan", "19-Jan" }
            };

            var partition2 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 2,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 3, 1), new DateTime(2019, 4, 1) }

                },
                Partitions = new List<string> { "19-May", "19-Jul" },
                IsPartitionShiftPin = true,
                IsPartitionShift = true
            };

            var partition3 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 3,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 6, 1), new DateTime(2019, 7, 1) }

                },
                Partitions = new List<string> { "19-Aug", "19-Sep" },
                IsPartitionShiftPin = false,
                IsPartitionShift = true
            };

            var partitions = new List<AggregatedPartitionViewModel> { partition1, partition2, partition3 };

            var service = new PartitionDateShiftCalculator();

            // ACT
            service.ShiftPartitionsByPin(3, 2, partitions);

            // ASSERT
            Assert.That(partitions[1].IsPartitionShiftPin, Is.False);
            Assert.That(partitions[1].IsPartitionShift, Is.False);
            Assert.That(partitions[1].Partitions[0], Is.EqualTo("19-Mar"));
            Assert.That(partitions[1].Partitions[1], Is.EqualTo("19-Apr"));

            Assert.That(partitions[2].IsPartitionShiftPin, Is.True);
            Assert.That(partitions[2].IsPartitionShift, Is.True);
            Assert.That(partitions[2].Partitions[0], Is.EqualTo("19-Aug"));
            Assert.That(partitions[2].Partitions[1], Is.EqualTo("19-Sep"));
        }

        [Test]
        public void ShouldShiftPartitionsByTenor()
        {
            var partition1 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 1,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 1, 1), new DateTime(2019, 1, 1) }

                },
                Partitions = new List<string> { "19-Jan", "19-Jan" }
            };

            var partition2 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 2,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 3, 1), new DateTime(2019, 4, 1) }

                },
                Partitions = new List<string> { "19-Mar", "19-Apr" },
                IsPartitionShiftPin = true,
                IsPartitionShift = true
            };

            var partition3 = new AggregatedPartitionViewModel
            {
                AggregatedPartition = new AggregatedPartition
                {
                    PartitionIndex = 3,
                    PartitionDates = new DateTime?[] { new DateTime(2019, 6, 1), new DateTime(2019, 7, 1) }

                },
                Partitions = new List<string> { "19-Jun", "19-Jul" },
                IsPartitionShift = true
            };

            var partitions = new List<AggregatedPartitionViewModel> { partition1, partition2, partition3 };

            var service = new PartitionDateShiftCalculator();

            // ACT
            service.ApplyTenorShiftToPartitions(2, partitions);

            // ASSERT
            Assert.That(partitions[0].IsPartitionShiftPin, Is.False);
            Assert.That(partitions[0].IsPartitionShift, Is.False);
            Assert.That(partitions[0].Partitions[0], Is.EqualTo("19-Jan"));
            Assert.That(partitions[0].Partitions[1], Is.EqualTo("19-Jan"));

            Assert.That(partitions[1].IsPartitionShiftPin, Is.True);
            Assert.That(partitions[1].IsPartitionShift, Is.True);
            Assert.That(partitions[1].Partitions[0], Is.EqualTo("19-May"));
            Assert.That(partitions[1].Partitions[1], Is.EqualTo("19-Jun"));

            Assert.That(partitions[2].IsPartitionShiftPin, Is.False);
            Assert.That(partitions[2].IsPartitionShift, Is.True);
            Assert.That(partitions[2].Partitions[0], Is.EqualTo("19-Aug"));
            Assert.That(partitions[2].Partitions[1], Is.EqualTo("19-Sep"));
        }
    }
}
