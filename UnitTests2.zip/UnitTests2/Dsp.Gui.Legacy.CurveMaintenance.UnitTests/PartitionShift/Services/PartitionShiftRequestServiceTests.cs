﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Exceptions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Services;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.PartitionShift.Services
{
    internal interface IPartitionedCurveUpdateServiceTestObjects
    {
        IAdminApiServiceClient AdminApiServiceClient { get; }

        PartitionShiftRequestService PartitionShiftRequestService { get; }
    }

    [TestFixture]
    public class PartitionShiftRequestServiceTests
    {
        private class PartitionShiftRequestServiceTestObjectBuilder
        {
            private bool _updateResponse;
            private List<PricingFailure> _pricingFailures;

            public PartitionShiftRequestServiceTestObjectBuilder WithUpdateResponse(
                bool value, List<PricingFailure> pricingFailures = null)
            {
                _updateResponse = value;
                _pricingFailures = pricingFailures;
                return this;
            }

            public IPartitionedCurveUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IPartitionedCurveUpdateServiceTestObjects>();

                var response = _updateResponse
                    ? new AdminApiServiceResponse(true)
                    : new AdminApiServiceResponse(_pricingFailures);

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                adminApiServiceClient.Setup(a => a.Update(It.IsAny<PartitionShiftRequest>()))
                                     .Returns(Task.FromResult(response));

                testObjects.SetupGet(o => o.AdminApiServiceClient).Returns(adminApiServiceClient.Object);

                var partitionedShiftRequestService = new PartitionShiftRequestService(adminApiServiceClient.Object);

                testObjects.SetupGet(o => o.PartitionShiftRequestService).Returns(partitionedShiftRequestService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdatePartitionShift()
        {
            var testScheduler = new TestScheduler();

            var testObjects = new PartitionShiftRequestServiceTestObjectBuilder().WithUpdateResponse(true)
                                                                                 .Build();

            var ids = new[] {101, 102};

            var completed = false;

            // ACT
            testObjects.PartitionShiftRequestService
                       .UpdatePartitionShift(ids, 1, 2, testScheduler)
                       .Subscribe(_ => completed = true);

            testScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.AdminApiServiceClient).Verify(a =>
                a.Update(It.Is<PartitionShiftRequest>(r => r.PartitionedCurveDefinitionIds.Count == 2
                                                           && r.OneBasedPartitionId == 1
                                                           && r.TenorAmountToShift == 2)));

            Assert.That(completed, Is.True);
        }

        [Test]
        public void ShouldHandlePricingFailuresErrorOnUpdate()
        {
            var testScheduler = new TestScheduler();

            var failures = new List<PricingFailure> { new(101, 201, PricingFailureReason.PartitionPriceCurveDefinitionMismatch, null, null) };

            var testObjects = new PartitionShiftRequestServiceTestObjectBuilder().WithUpdateResponse(false, failures)
                                                                                 .Build();

            var ids = new[] {101, 102};

            var completed = false;
            Exception error = null;

            // ACT
            testObjects.PartitionShiftRequestService
                       .UpdatePartitionShift(ids, 1, 2, testScheduler)
                       .Subscribe(_ => completed = true,
                                  ex => error = ex);

            testScheduler.AdvanceBy(10);

            // ASSERT
            Assert.That(completed, Is.False);
            Assert.IsNotNull(error);
            // ReSharper disable once PossibleNullReferenceException
            Assert.That(((PricingFailuresException)error.InnerException).PricingFailures.Count, Is.EqualTo(1));
        }
    }
}
