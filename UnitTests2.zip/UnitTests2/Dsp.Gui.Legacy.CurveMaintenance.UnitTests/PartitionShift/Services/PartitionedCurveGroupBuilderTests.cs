﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Services;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.PartitionShift.Services
{
    [TestFixture]
    public class PartitionedCurveGroupBuilderTests
    {
        [Test]
        public void ShouldBuildCurveGroups()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var moGas = new CurveGroupTestObjectBuilder().MoGas();
            var fuelOil = new CurveGroupTestObjectBuilder().MoGas();

			// ARRANGE PRICE CURVES
			var productDefinitionGasOil = new ProductDefinition(
                30, "product-1", "desc", new List<CurveRegion>(),
                crude, 
                1, UnitOfMeasure.BBL, 1,1,1,new Density(),1 );

            var productDefinitionJet = new ProductDefinition(
                31, "product-2", "desc", new List<CurveRegion>(),
                moGas,
                1, UnitOfMeasure.BBL, 1, 1, 1, new Density(), 1);

            var productDefinitionCrude = new ProductDefinition(
                32, "product-3", "desc", new List<CurveRegion>(),
                fuelOil,
                1, UnitOfMeasure.BBL, 1, 1, 1, new Density(), 1);

            var priceCurve1 = new PriceCurveDefinition(
                101, "price-curve-1", "desc", productDefinitionGasOil, CurveRegion.UnitedStates, CurveType.Spread, UnitOfMeasure.BBL, 1000, null, null, false);

            var priceCurve2 = new PriceCurveDefinition(
                102, "price-curve-2", "desc", productDefinitionGasOil, CurveRegion.UnitedStates, CurveType.Spread, UnitOfMeasure.BBL, 1000, null, null, false);

            var priceCurve3 = new PriceCurveDefinition(
                103, "price-curve-3", "desc", productDefinitionJet, CurveRegion.UnitedStates, CurveType.Spread, UnitOfMeasure.BBL, 1000, null, null, false);

            var priceCurve4 = new PriceCurveDefinition(
                104, "price-curve-4", "desc", productDefinitionJet, CurveRegion.UnitedStates, CurveType.Spread, UnitOfMeasure.BBL, 1000, null, null, false);

            var priceCurve5 = new PriceCurveDefinition(
                105, "price-curve-5", "desc", productDefinitionCrude, CurveRegion.UnitedStates, CurveType.Spread, UnitOfMeasure.BBL, 1000, null, null, false);

            var priceCurves = new List<PriceCurveDefinition> {priceCurve1, priceCurve2, priceCurve3, priceCurve4, priceCurve5};

            // ARRANGE PARTITIONED CURVES
            var partition1 = new PartitionedCurveDefinition<MonthlyTenor>(
                201, "partition-1", "desc", 101, 10,
                []);

            var partition2 = new PartitionedCurveDefinition<MonthlyTenor>(
                202, "partition-2", "desc", 102, 10,
                []);

            var partition3 = new PartitionedCurveDefinition<MonthlyTenor>(
                203, "partition-3", "desc", 103, 10,
                []);

            var partition4 = new PartitionedCurveDefinition<MonthlyTenor>(
                204, "partition-4", "desc", 104, 10,
                []);

            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
                {partition1, partition2, partition3, partition4};

            var builder = new PartitionedCurveGroupBuilder();

            // ACT
            var result = builder.BuildCurveGroups(partitionedCurves, priceCurves);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(2));

            Assert.That(result[0].CurveGroupName, Is.EqualTo(CurveGroupNames.Crude));
            Assert.That(result[0].PartitionedCurveItems.Count, Is.EqualTo(2));

            Assert.That(result[0].PartitionedCurveItems[0].PartitionedCurve.CurveGroup, Is.EqualTo(crude));
            Assert.That(result[0].PartitionedCurveItems[0].PartitionedCurve.Id, Is.EqualTo(201));
            Assert.That(result[0].PartitionedCurveItems[0].PartitionedCurve.PriceCurveId, Is.EqualTo(101));
            Assert.That(result[0].PartitionedCurveItems[0].PartitionedCurve.Name, Is.EqualTo("partition-1"));

            Assert.That(result[0].PartitionedCurveItems[1].PartitionedCurve.CurveGroup.Id, Is.EqualTo(crude.Id));
            Assert.That(result[0].PartitionedCurveItems[1].PartitionedCurve.Id, Is.EqualTo(202));
            Assert.That(result[0].PartitionedCurveItems[1].PartitionedCurve.PriceCurveId, Is.EqualTo(102));
            Assert.That(result[0].PartitionedCurveItems[1].PartitionedCurve.Name, Is.EqualTo("partition-2"));

            Assert.That(result[1].CurveGroupName, Is.EqualTo(CurveGroupNames.MOGAS));
            Assert.That(result[1].PartitionedCurveItems.Count, Is.EqualTo(2));

            Assert.That(result[1].PartitionedCurveItems[0].PartitionedCurve.CurveGroup.Id, Is.EqualTo(moGas.Id));
            Assert.That(result[1].PartitionedCurveItems[0].PartitionedCurve.Id, Is.EqualTo(203));
            Assert.That(result[1].PartitionedCurveItems[0].PartitionedCurve.PriceCurveId, Is.EqualTo(103));
            Assert.That(result[1].PartitionedCurveItems[0].PartitionedCurve.Name, Is.EqualTo("partition-3"));

            Assert.That(result[1].PartitionedCurveItems[1].PartitionedCurve.CurveGroup.Id, Is.EqualTo(moGas.Id));
            Assert.That(result[1].PartitionedCurveItems[1].PartitionedCurve.Id, Is.EqualTo(204));
            Assert.That(result[1].PartitionedCurveItems[1].PartitionedCurve.PriceCurveId, Is.EqualTo(104));
            Assert.That(result[1].PartitionedCurveItems[1].PartitionedCurve.Name, Is.EqualTo("partition-4"));
        }
    }
}
