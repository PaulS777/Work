﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Services;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.PartitionShift.Services
{
    [TestFixture]
    public class PartitionShiftPromptMessageBuilderTests
    {
        [Test]
        public void ShouldBuildMessages()
        {
            var partition1 = new PartitionedCurveDefinition<MonthlyTenor>(
                201, "partition-1", "desc", 101, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(new MonthlyTenor(2019, 1), new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(new MonthlyTenor(2019, 3), new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(new MonthlyTenor(2019, 5), new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partition2 = new PartitionedCurveDefinition<MonthlyTenor>(
                202, "partition-2", "desc", 101, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(new MonthlyTenor(2019, 1), new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(new MonthlyTenor(2019, 4), new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(new MonthlyTenor(2019, 6), new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partition3 = new PartitionedCurveDefinition<MonthlyTenor>(
                202, "partition-3", "desc", 101, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(new MonthlyTenor(2019, 2), new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partitions = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                partition1,
                partition2,
                partition3
            };

            var builder = new PartitionShiftPromptMessageBuilder();

            // ACT
            var messages = builder.BuildMessages(partitions, 2, 3);

            Assert.That(messages.Count, Is.EqualTo(8));
            Assert.That(messages[0], Is.EqualTo("partition-1"));
            Assert.That(messages[1], Is.EqualTo("Mar19 -> Jun19"));
            Assert.That(messages[2], Is.EqualTo("May19 -> Aug19"));
            Assert.That(messages[3], Is.EqualTo(""));
            Assert.That(messages[4], Is.EqualTo("partition-2"));
            Assert.That(messages[5], Is.EqualTo("Apr19 -> Jul19"));
            Assert.That(messages[6], Is.EqualTo("Jun19 -> Sep19"));
            Assert.That(messages[7], Is.EqualTo(""));
        }
    }
}
