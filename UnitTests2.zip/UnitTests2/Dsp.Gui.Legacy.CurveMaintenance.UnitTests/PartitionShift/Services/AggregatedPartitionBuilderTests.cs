﻿using System;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Controllers;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Services;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.PartitionShift.Services
{
    internal interface IAggregatedPartitionBuilderTestObjects
    {
        IAggregatedPartitionViewModelController Controller1 { get; }
        IAggregatedPartitionViewModelController Controller2 { get; }
        IAggregatedPartitionViewModelController Controller3 { get; }
        IAggregatedPartitionViewModelController Controller4 { get; }
        AggregatedPartitionBuilder AggregatedPartitionBuilder { get; }
    }

    [TestFixture]
    public class AggregatedPartitionBuilderTests
    {
        private class AggregatedPartitionBuilderTestObjectBuilder
        {
            public IAggregatedPartitionBuilderTestObjects Build()
            {
                var testObjects = new Mock<IAggregatedPartitionBuilderTestObjects>();

                var viewModel1 = new AggregatedPartitionViewModel();
                var controller1 = Mock.Of<IAggregatedPartitionViewModelController>(c => c.ViewModel == viewModel1);

                var viewModel2 = new AggregatedPartitionViewModel();
                var controller2 = Mock.Of<IAggregatedPartitionViewModelController>(c => c.ViewModel == viewModel2);

                var viewModel3 = new AggregatedPartitionViewModel();
                var controller3 = Mock.Of<IAggregatedPartitionViewModelController>(c => c.ViewModel == viewModel3);

                var viewModel4 = new AggregatedPartitionViewModel();
                var controller4 = Mock.Of<IAggregatedPartitionViewModelController>(c => c.ViewModel == viewModel4);

                testObjects.SetupGet(o => o.Controller1)
                           .Returns(controller1);

                testObjects.SetupGet(o => o.Controller2)
                           .Returns(controller2);

                testObjects.SetupGet(o => o.Controller3)
                           .Returns(controller3);

                testObjects.SetupGet(o => o.Controller4)
                           .Returns(controller4);

                var factory = new Mock<IServiceFactory<IAggregatedPartitionViewModelController>>();

                factory.SetupSequence(f => f.Create())
                       .Returns(controller1)
                       .Returns(controller2)
                       .Returns(controller3)
                       .Returns(controller4);

                var builder = new AggregatedPartitionBuilder
                              {
                                  Factory = factory.Object
                              };

                testObjects.SetupGet(o => o.AggregatedPartitionBuilder)
                           .Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAddNewAggregatedPartitionViewModel_WithHeader_ToEmptyCollection()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var tenor2 = new MonthlyTenor(2019, 2);

            var dateTime1 = new DateTime(2019, 1, 1);
            var dateTime2 = new DateTime(2019, 2, 1);

            var partition = new PartitionedCurveDefinition<MonthlyTenor>(
                201, "partition-1", "desc", 101, 10,
                new []
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor2, new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partitions = new [] {partition};
            var viewModels = new ObservableCollection<AggregatedPartitionViewModel>();

            var testObjects = new AggregatedPartitionBuilderTestObjectBuilder().Build();

            // ACT
            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitions, 
                                                                           viewModels, 
                                                                           out var added, 
                                                                           out var removed);

            // ASSERT
            Assert.That(viewModels.Count, Is.EqualTo(3));

            Assert.That(viewModels[0].IsHeader, Is.True);
            Assert.That(viewModels[0].Partitions[0], Is.EqualTo("partition-1"));

            Assert.That(viewModels[1].IsHeader, Is.False);
            Assert.IsNull(viewModels[1].Partitions);
            Assert.That(viewModels[1].AggregatedPartition.PartitionDates.Length, Is.EqualTo(1));
            Assert.That(viewModels[1].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime1));

            Assert.That(viewModels[2].IsHeader, Is.False);
            Assert.IsNull(viewModels[2].Partitions);
            Assert.That(viewModels[2].AggregatedPartition.PartitionDates.Length, Is.EqualTo(1));
            Assert.That(viewModels[2].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime2));

            Assert.That(removed.Count, Is.EqualTo(0));
            Assert.That(added.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldAppendExistingHeadersAndDates_When_CurveAdded_WithSamePartitionCount()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var tenor2 = new MonthlyTenor(2019, 2);
            var tenor3 = new MonthlyTenor(2019, 3);

            var dateTime1 = new DateTime(2019, 1, 1);
            var dateTime2 = new DateTime(2019, 2, 1);
            var dateTime3 = new DateTime(2019, 3, 1);

            var partition1 = new PartitionedCurveDefinition<MonthlyTenor>(
                201, "partition-1", "desc", 101, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor2, new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partition2 = new PartitionedCurveDefinition<MonthlyTenor>(
                202, "partition-2", "desc", 102, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(303, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor3, new CurveContributionDefinition(new LinkedCurve(304, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partitions = new[] { partition1 };
            var viewModels = new ObservableCollection<AggregatedPartitionViewModel>();

            var testObjects = new AggregatedPartitionBuilderTestObjectBuilder().Build();

            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitions,
                                                                           viewModels,
                                                                           out _,
                                                                           out _);

            var partitionsUpdate = new[] { partition1, partition2 };

            // ACT
            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitionsUpdate, 
                                                                           viewModels, 
                                                                           out var added2, 
                                                                           out var removed2);

            // ASSERT
            Assert.That(viewModels.Count, Is.EqualTo(3));
            Assert.That(viewModels[0].Partitions.Count, Is.EqualTo(2));
            Assert.That(viewModels[0].Partitions[0], Is.EqualTo("partition-1"));
            Assert.That(viewModels[0].Partitions[1], Is.EqualTo("partition-2"));


            Assert.That(viewModels[1].AggregatedPartition.PartitionDates.Length, Is.EqualTo(2));
            Assert.That(viewModels[1].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime1));
            Assert.That(viewModels[1].AggregatedPartition.PartitionDates[1], Is.EqualTo(dateTime1));

            Assert.That(viewModels[2].AggregatedPartition.PartitionDates.Length, Is.EqualTo(2));
            Assert.That(viewModels[2].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime2));
            Assert.That(viewModels[2].AggregatedPartition.PartitionDates[1], Is.EqualTo(dateTime3));

            Assert.That(added2.Count, Is.EqualTo(0));
            Assert.That(removed2.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldAddNewViewModel_When_PartitionDefinitionAdded_WithAdditionalPartitions()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var tenor2 = new MonthlyTenor(2019, 2);
            var tenor3 = new MonthlyTenor(2019, 3);
            var tenor4 = new MonthlyTenor(2019, 4);

            var dateTime1 = new DateTime(2019, 1, 1);
            var dateTime2 = new DateTime(2019, 2, 1);
            var dateTime3 = new DateTime(2019, 3, 1);
            var dateTime4 = new DateTime(2019, 4, 1);

            var partition1 = new PartitionedCurveDefinition<MonthlyTenor>(
                201, "partition-1", "desc", 101, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor2, new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partition2 = new PartitionedCurveDefinition<MonthlyTenor>(
                202, "partition-2", "desc", 102, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(303, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor3, new CurveContributionDefinition(new LinkedCurve(304, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor4, new CurveContributionDefinition(new LinkedCurve(305, PriceCurveDefinitionType.DerivedCurve)))
                });

            var testObjects = new AggregatedPartitionBuilderTestObjectBuilder().Build();

            var partitions = new[] { partition1 };
            var viewModels = new ObservableCollection<AggregatedPartitionViewModel>();

            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitions, 
                                                                           viewModels, 
                                                                           out _, 
                                                                           out _);

            var partitionsUpdate = new[] { partition1, partition2 };

            // ACT
            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitionsUpdate, 
                                                                           viewModels, 
                                                                           out var added2, 
                                                                           out var removed2);

            // ASSERT
            Assert.That(viewModels.Count, Is.EqualTo(4));

            Assert.That(viewModels[1].AggregatedPartition.PartitionDates.Length, Is.EqualTo(2));
            Assert.That(viewModels[1].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime1));
            Assert.That(viewModels[1].AggregatedPartition.PartitionDates[1], Is.EqualTo(dateTime1));

            Assert.That(viewModels[2].AggregatedPartition.PartitionDates.Length, Is.EqualTo(2));
            Assert.That(viewModels[2].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime2));
            Assert.That(viewModels[2].AggregatedPartition.PartitionDates[1], Is.EqualTo(dateTime3));

            Assert.That(viewModels[3].AggregatedPartition.PartitionDates.Length, Is.EqualTo(2));
            Assert.IsNull(viewModels[3].AggregatedPartition.PartitionDates[0]);
            Assert.That(viewModels[3].AggregatedPartition.PartitionDates[1], Is.EqualTo(dateTime4));

            Assert.That(added2.Count, Is.EqualTo(1));
            Assert.That(removed2.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldRemoveCurveFromHeadersAndPartitionDates()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var tenor2 = new MonthlyTenor(2019, 2);
            var tenor3 = new MonthlyTenor(2019, 3);

            var dateTime1 = new DateTime(2019, 1, 1);
            var dateTime2 = new DateTime(2019, 2, 1);

            var partition1 = new PartitionedCurveDefinition<MonthlyTenor>(
                201, "partition-1", "desc", 101, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor2, new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partition2 = new PartitionedCurveDefinition<MonthlyTenor>(
                202, "partition-2", "desc", 102, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(303, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor3, new CurveContributionDefinition(new LinkedCurve(304, PriceCurveDefinitionType.DerivedCurve)))
                });

            var testObjects = new AggregatedPartitionBuilderTestObjectBuilder().Build();

            var partitions = new[] { partition1, partition2 };
            var viewModels = new ObservableCollection<AggregatedPartitionViewModel>();

            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitions, 
                                                                           viewModels, 
                                                                           out _, 
                                                                           out _);

            // ACT
            var partitionsUpdate = new[] { partition1 };

            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitionsUpdate, 
                                                                           viewModels, 
                                                                           out var added2, 
                                                                           out var removed2);

            // ASSERT
            Assert.That(viewModels.Count, Is.EqualTo(3));

            Assert.That(viewModels[0].Partitions.Count, Is.EqualTo(1));
            Assert.That(viewModels[0].Partitions[0], Is.EqualTo("partition-1"));

            Assert.That(viewModels[1].AggregatedPartition.PartitionDates.Length, Is.EqualTo(1));
            Assert.That(viewModels[1].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime1));

            Assert.That(viewModels[2].AggregatedPartition.PartitionDates.Length, Is.EqualTo(1));
            Assert.That(viewModels[2].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime2));

            Assert.That(added2.Count, Is.EqualTo(0));
            Assert.That(removed2.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldRemoveViewModel_When_CurveRemoved_WithAdditionalPartitions()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var tenor2 = new MonthlyTenor(2019, 2);
            var tenor3 = new MonthlyTenor(2019, 3);
            var tenor4 = new MonthlyTenor(2019, 4);

            var dateTime1 = new DateTime(2019, 1, 1);
            var dateTime2 = new DateTime(2019, 2, 1);

            var partition1 = new PartitionedCurveDefinition<MonthlyTenor>(
                201, "partition-1", "desc", 101, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor2, new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partition2 = new PartitionedCurveDefinition<MonthlyTenor>(
                202, "partition-2", "desc", 102, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(303, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor3, new CurveContributionDefinition(new LinkedCurve(304, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor4, new CurveContributionDefinition(new LinkedCurve(305, PriceCurveDefinitionType.DerivedCurve)))
                });

            var testObjects = new AggregatedPartitionBuilderTestObjectBuilder().Build();

            var partitions = new[] { partition1, partition2 };
            var viewModels = new ObservableCollection<AggregatedPartitionViewModel>();

            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitions, 
                                                                           viewModels, 
                                                                           out _, 
                                                                           out _);

            // ACT
            var partitionsUpdate = new[] { partition1 };

            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitionsUpdate, 
                                                                           viewModels, 
                                                                           out var added2, 
                                                                           out var removed2);

            // ASSERT
            Assert.That(viewModels.Count, Is.EqualTo(3));

            Assert.That(viewModels[1].AggregatedPartition.PartitionDates.Length, Is.EqualTo(1));
            Assert.That(viewModels[1].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime1));

            Assert.That(viewModels[2].AggregatedPartition.PartitionDates.Length, Is.EqualTo(1));
            Assert.That(viewModels[2].AggregatedPartition.PartitionDates[0], Is.EqualTo(dateTime2));

            Assert.That(added2.Count, Is.EqualTo(0));
            Assert.That(removed2.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldClearViewModels_When_AllPartitionDefinitionsRemoved()
        {
            var tenor1 = new MonthlyTenor(2019, 1);
            var tenor2 = new MonthlyTenor(2019, 2);
            var tenor3 = new MonthlyTenor(2019, 3);
            var tenor4 = new MonthlyTenor(2019, 4);

            var partition1 = new PartitionedCurveDefinition<MonthlyTenor>(
                201, "partition-1", "desc", 101, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(301, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor2, new CurveContributionDefinition(new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partition2 = new PartitionedCurveDefinition<MonthlyTenor>(
                202, "partition-2", "desc", 102, 10,
                new[]
                {
                    new CurvePartition<MonthlyTenor>(tenor1, new CurveContributionDefinition(new LinkedCurve(303, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor3, new CurveContributionDefinition(new LinkedCurve(304, PriceCurveDefinitionType.DerivedCurve))),
                    new CurvePartition<MonthlyTenor>(tenor4, new CurveContributionDefinition(new LinkedCurve(305, PriceCurveDefinitionType.DerivedCurve)))
                });

            var partitions = new[] { partition1, partition2 };
            var viewModels = new ObservableCollection<AggregatedPartitionViewModel>();

            var testObjects = new AggregatedPartitionBuilderTestObjectBuilder().Build();

            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitions, 
                                                                           viewModels, 
                                                                           out _, 
                                                                           out _);

            // ACT
            var partitionsUpdate = new PartitionedCurveDefinition<MonthlyTenor>[] { };

            testObjects.AggregatedPartitionBuilder.UpdatePartitionedCurves(partitionsUpdate, 
                                                                           viewModels, 
                                                                           out var added2, 
                                                                           out var removed2);

            // ASSERT
            Assert.That(viewModels.Count, Is.EqualTo(0));
            Assert.That(added2.Count, Is.EqualTo(0));
            Assert.That(removed2.Count, Is.EqualTo(3));
        }
    }
}
