﻿using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Controllers;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.PartitionShift.Controllers
{
    public class AggregatedPartitionViewModelControllerTests
    {
        [Test]
        public void ShouldUpdateIsPartitionShiftPinOnCommand()
        {
            var controller = new AggregatedPartitionViewModelController();

            // ACT
            controller.ViewModel.PinPartitionShiftCommand.Execute();

            // ASSERT
            Assert.That(controller.ViewModel.IsPartitionShiftPin, Is.True);
        }
    }
}
