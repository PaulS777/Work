﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Exceptions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Controllers;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.Services;
using Dsp.Gui.Legacy.CurveMaintenance.PartitionShift.ViewModels;
using Dsp.Gui.Legacy.CurveMaintenance.Services;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Legacy.CurveMaintenance.UnitTests.PartitionShift.Controllers
{
    internal interface IPartitionShiftViewModelControllerTestObjects
    {
        ICurveDefinitionProvider CurveDefinitionProvider { get; }
        ICurveControlService CurveControlService { get; }
        IPriceCurveSettingsProvider PriceCurveSettingsProvider { get; }
        IPartitionedCurveGroupBuilder PartitionedCurveGroupBuilder { get; }
        IAggregatedPartitionBuilder AggregatedPartitionBuilder { get; }
        IPartitionDateShiftCalculator PartitionDateShiftCalculator { get; }
        IPartitionShiftPromptMessageBuilder PartitionShiftPromptMessageBuilder { get; }
        IPartitionShiftRequestService PartitionShiftRequestService { get; }
        IPricingFailureParser PricingFailuresParser { get; }
        IPartitionShiftToolBarService ToolBarService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        ISubject<bool> CurvesLoaded { get; }
        ISubject<Unit> CurveUpdated { get; }
        TestScheduler TestScheduler { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        PartitionShiftEditorViewModelController Controller { get; }
        PartitionShiftEditorViewModel ViewModel { get; }

    }

    public class PartitionShiftViewModelControllerTests
    {
        private class PartitionShiftViewModelControllerTestObjectBuilder
        {
            private bool _curvesLoaded;
            private List<PartitionedCurveDefinition<MonthlyTenor>> _partitionedCurveDefinitions = new();
            private Dictionary<int, PriceCurveSetting> _priceCurveSettings;
            private List<PartitionedCurveGroup> _partitionedCurveGroups;
            private List<AggregatedPartitionViewModel> _aggregatedPartitions = new();
            private int _userId;
            private bool _canParseFailures;
            private List<string> _promptMessages;

            public PartitionShiftViewModelControllerTestObjectBuilder WithCurvesLoaded(bool value)
            {
                _curvesLoaded = value;
                return this;
            }

            public PartitionShiftViewModelControllerTestObjectBuilder WithPriceCurveSettings(
                Dictionary<int, PriceCurveSetting> value)
            {
                _priceCurveSettings = value;
                return this;
            }

            public PartitionShiftViewModelControllerTestObjectBuilder WithPartitionedCurveDefinitions(
                List<PartitionedCurveDefinition<MonthlyTenor>> values)
            {
                _partitionedCurveDefinitions = values;
                return this;
            }

            public PartitionShiftViewModelControllerTestObjectBuilder WithPartitionedCurveGroups(
                List<PartitionedCurveGroup> values)
            {
                _partitionedCurveGroups = values;
                return this;
            }

            public PartitionShiftViewModelControllerTestObjectBuilder WithAggregatedPartitions(
                List<AggregatedPartitionViewModel> values)
            {
                _aggregatedPartitions = values;
                return this;
            }

            public PartitionShiftViewModelControllerTestObjectBuilder WithUserId(int value)
            {
                _userId = value;
                return this;
            }

            public PartitionShiftViewModelControllerTestObjectBuilder WithPromptMessages(IEnumerable<string> values)
            {
                _promptMessages = values.ToList();
                return this;
            }

            public PartitionShiftViewModelControllerTestObjectBuilder WithCanParseFailures(bool value)
            {
                _canParseFailures = value;
                return this;
            }

            private delegate void MockCallback(IList<PartitionedCurveDefinition<MonthlyTenor>> curves,
                                       IList<AggregatedPartitionViewModel> viewModels,
                                       out IList<AggregatedPartitionViewModel> added,
                                       out IList<AggregatedPartitionViewModel> removed);

            public IPartitionShiftViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IPartitionShiftViewModelControllerTestObjects>();

                var testScheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(testScheduler);
                var schedulerProvider = new Mock<ISchedulerProvider>();
                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
                schedulerProvider.SetupGet(p => p.Immediate).Returns(Scheduler.Immediate);

                var curvesLoaded = new BehaviorSubject<bool>(_curvesLoaded);
                testObjects.SetupGet(o => o.CurvesLoaded).Returns(curvesLoaded);

                var priceCurveDefinitions = new List<PriceCurveDefinition>();
                var derivedCurveDefinitions = new List<DerivedCurveDefinition>();

                var curveDefinitionProvider = new Mock<ICurveDefinitionProvider>();
                curveDefinitionProvider.SetupGet(c => c.CurvesLoaded).Returns(curvesLoaded);
                curveDefinitionProvider.SetupGet(c => c.PriceCurveDefinitions).Returns(priceCurveDefinitions);
                curveDefinitionProvider.SetupGet(c => c.DerivedCurveDefinitions).Returns(derivedCurveDefinitions);

                curveDefinitionProvider.SetupGet(c => c.PartitionedCurveDefinitions)
                                       .Returns(_partitionedCurveDefinitions);

                testObjects.SetupGet(o => o.CurveDefinitionProvider).Returns(curveDefinitionProvider.Object);

                var priceCurveSettings = new BehaviorSubject<Dictionary<int, PriceCurveSetting>>(_priceCurveSettings);
                testObjects.SetupGet(o => o.PriceCurveSettings).Returns(priceCurveSettings);

                var curveControlService = new Mock<ICurveControlService>();

                var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();
                priceCurveSettingsProvider.Setup(p => p.PriceCurveSettings).Returns(priceCurveSettings);
                testObjects.SetupGet(o => o.PriceCurveSettingsProvider).Returns(priceCurveSettingsProvider.Object);

                var user = new UserBuilder().WithId(_userId).User();

                curveControlService.SetupGet(s => s.CurrentUserSnapshot)
                                   .Returns(user);

                curveControlService.SetupGet(s => s.CurrentUser)
                                   .Returns(Observable.Return(user));

                testObjects.SetupGet(o => o.CurveControlService).Returns(curveControlService.Object);

                var partitionedCurveGroupBuilder = new Mock<IPartitionedCurveGroupBuilder>();

                partitionedCurveGroupBuilder.Setup(b => b.BuildCurveGroups(
                                                It.IsAny<IList<PartitionedCurveDefinition<MonthlyTenor>>>(),
                                                It.IsAny<IList<PriceCurveDefinition>>()))
                                            .Returns(_partitionedCurveGroups);

                testObjects.SetupGet(o => o.PartitionedCurveGroupBuilder).Returns(partitionedCurveGroupBuilder.Object);

                var aggregatedPartitionBuilder = new Mock<IAggregatedPartitionBuilder>();

                testObjects.SetupGet(o => o.AggregatedPartitionBuilder).Returns(aggregatedPartitionBuilder.Object);

                var curveUpdated = new Subject<Unit>();
                testObjects.SetupGet(o => o.CurveUpdated).Returns(curveUpdated);

                var partitionShiftPromptMessageBuilder = new Mock<IPartitionShiftPromptMessageBuilder>();

                partitionShiftPromptMessageBuilder.Setup(b => b.BuildMessages(
                                                      It.IsAny<List<PartitionedCurveDefinition<MonthlyTenor>>>(),
                                                      It.IsAny<int>(), It.IsAny<int>()))
                                                  .Returns(_promptMessages);

                testObjects.SetupGet(o => o.PartitionShiftPromptMessageBuilder)
                           .Returns(partitionShiftPromptMessageBuilder.Object);

                var partitionShiftRequestService = new Mock<IPartitionShiftRequestService>();

                partitionShiftRequestService.Setup(r =>
                                                r.UpdatePartitionShift(It.IsAny<IEnumerable<int>>(),
                                                    It.IsAny<int>(),
                                                    It.IsAny<int>(),
                                                    It.IsAny<IScheduler>()))
                                            .Returns(curveUpdated);

                testObjects.SetupGet(o => o.PartitionShiftRequestService).Returns(partitionShiftRequestService.Object);

                var pricingFailuresParser = new Mock<IPricingFailureParser>();

                string[] messages;

                pricingFailuresParser.Setup(p => p.TryParsePricingFailures(
                                         It.IsAny<Dictionary<LinkedCurve, string>>(),
                                         It.IsAny<List<PricingFailure>>(),
                                         out messages))
                                     .Returns(_canParseFailures);

                testObjects.SetupGet(o => o.PricingFailuresParser).Returns(pricingFailuresParser.Object);

                var partitionDateShiftCalculator = new Mock<IPartitionDateShiftCalculator>();

                testObjects.SetupGet(o => o.PartitionDateShiftCalculator).Returns(partitionDateShiftCalculator.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();
                testObjects.SetupGet(o => o.PopupNotificationService).Returns(popupNotificationService.Object);

                var toolBarUpdate = new Subject<Unit>();
                testObjects.SetupGet(o => o.ToolBarUpdate).Returns(toolBarUpdate);


                var toolBarService = new Mock<IPartitionShiftToolBarService>();
                toolBarService.SetupGet(tb => tb.Update).Returns(toolBarUpdate);

                testObjects.SetupGet(o => o.ToolBarService).Returns(toolBarService.Object);

                var controller = new PartitionShiftEditorViewModelController(
                    curveDefinitionProvider.Object,
                    curveControlService.Object,
                    priceCurveSettingsProvider.Object,
                    partitionedCurveGroupBuilder.Object,
                    toolBarService.Object,
                    schedulerProvider.Object,
                    TestMocks.GetLoggerFactory().Object)
                {
                    PopupNotificationService = popupNotificationService.Object,
                    PartitionShiftPromptMessageBuilder = partitionShiftPromptMessageBuilder.Object,
                    PartitionShiftRequestService = partitionShiftRequestService.Object,
                    PricingFailureParser = pricingFailuresParser.Object,
                    PartitionDateShiftCalculator = partitionDateShiftCalculator.Object,
                    AggregatedPartitionBuilder = aggregatedPartitionBuilder.Object
                };

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                IList<AggregatedPartitionViewModel> added;
                IList<AggregatedPartitionViewModel> removed;

                aggregatedPartitionBuilder.Setup(b => b.UpdatePartitionedCurves(
                                              It.IsAny<IList<PartitionedCurveDefinition<MonthlyTenor>>>(),
                                              It.IsAny<IList<AggregatedPartitionViewModel>>(),
                                              out added,
                                              out removed))
                                          .Callback(new MockCallback((
                                              IList<PartitionedCurveDefinition<MonthlyTenor>> _,
                                              IList<AggregatedPartitionViewModel> _,
                                              out IList<AggregatedPartitionViewModel> addedVms,
                                              out IList<AggregatedPartitionViewModel> removedVms) =>
                                          {
                                              addedVms = new List<AggregatedPartitionViewModel>(_aggregatedPartitions);
                                              removedVms = new List<AggregatedPartitionViewModel>();

                                              controller.ViewModel.AggregatedPartitionViewModels =
                                                  new ObservableCollection<AggregatedPartitionViewModel>(
                                                      _aggregatedPartitions);
                                          }));

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializePartitionedCurveGroups_WithPartitionsHidden_WhenCurvesLoaded()
        {
            var curveGroups = new List<PartitionedCurveGroup>
            {
                new()
                {
                    PartitionedCurveItems = new List<PartitionedCurveItem>()
                }
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveGroups(curveGroups)
                                                                          .Build();
            // ACT
            testObjects.CurvesLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.CurveGroups.Count, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.ShowPartitions, Is.False);
        }

        [Test]
        public void ShouldApplyUserSettingsToCurveGroups()
        {
            var item1 = new PartitionedCurveItem {PartitionedCurve = new PartitionedCurve {PriceCurveId = 101}};
            var item2 = new PartitionedCurveItem {PartitionedCurve = new PartitionedCurve {PriceCurveId = 102}};
            var item3 = new PartitionedCurveItem {PartitionedCurve = new PartitionedCurve {PriceCurveId = 103}};
            var item4 = new PartitionedCurveItem {PartitionedCurve = new PartitionedCurve {PriceCurveId = 104}};

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1, item2}},
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item3, item4}}
            };

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101, 
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                    //new PriceCurveSetting(101, 10, true, true, true)
                },
                {
                    102,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).WithPublisherId(99).Build()
                    //new PriceCurveSetting(102, 99, true, true, true)
                },
                {
                    103,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(103).WithPublisherId(10).Build()
                    //new PriceCurveSetting(103, 10, true, true, true)
                },
                {
                    104,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(104).WithPublisherId(99).Build()
                    //new PriceCurveSetting(104, 99, true, true, true)
                }
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithUserId(10)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithPriceCurveSettings(settings)
                                                                          .Build();
            // ACT
            testObjects.CurvesLoaded.OnNext(true);

            // ASSERT
            Assert.That(item1.CanEdit, Is.True);
            Assert.That(item2.CanEdit, Is.False);
            Assert.That(item3.CanEdit, Is.True);
            Assert.That(item4.CanEdit, Is.False);
        }

        [Test]
        public void ShouldUpdateAggregatedPartitions_AndShowPartitions_WhenCurveItemSelected()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(202, "partition", "desc", 102, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(203, "partition", "desc", 103, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(204, "partition", "desc", 104, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };
            var item2 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 202, PriceCurveId = 102}
                        };
            var item3 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 203, PriceCurveId = 103}
                        };
            var item4 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 204, PriceCurveId = 104}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1, item2}},
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item3, item4}}
            };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                new() {IsHeader = true},
                new()
            };

            var testObjects
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            IList<AggregatedPartitionViewModel> added;
            IList<AggregatedPartitionViewModel> removed;

            // ACT
            item1.IsSelected = true;

            // ASSERT
            Mock.Get(testObjects.AggregatedPartitionBuilder)
                .Verify(c => c.UpdatePartitionedCurves(It.Is<IList<PartitionedCurveDefinition<MonthlyTenor>>>(p => p.Count == 1 && p[0].Id == 201),
                                                       It.IsAny<IList<AggregatedPartitionViewModel>>(),
                                                       out added,
                                                       out removed));

            Assert.That(testObjects.ViewModel.AggregatedPartitionViewModels.Count, Is.EqualTo(2));

            Mock.Get(testObjects.PartitionDateShiftCalculator)
                .Verify(c => c.ApplyTenorShiftToPartitions(0, It.Is<IList<AggregatedPartitionViewModel>>(a => a.Count == 1 && a[0].IsHeader == false)));

            Assert.That(testObjects.ViewModel.ShowPartitions, Is.True);
        }

        [Test]
        public void ShouldUpdateAggregatedPartitions_AndHidePartitions_WhenCurveItemDeselected()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(202, "partition", "desc", 102, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(203, "partition", "desc", 103, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(204, "partition", "desc", 104, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };
            var item2 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 202, PriceCurveId = 102}
                        };
            var item3 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 203, PriceCurveId = 103}
                        };
            var item4 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 204, PriceCurveId = 104}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1, item2}},
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item3, item4}}
            };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>();

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            IList<AggregatedPartitionViewModel> added;
            IList<AggregatedPartitionViewModel> removed;

            item1.IsSelected = true;

            // ACT
            item1.IsSelected = false;

            // ASSERT
            Mock.Get(testObjects.AggregatedPartitionBuilder).Verify(c =>
                c.UpdatePartitionedCurves(
                    It.Is<IList<PartitionedCurveDefinition<MonthlyTenor>>>(p => p.Count == 0),
                    It.IsAny<IList<AggregatedPartitionViewModel>>(),
                    out added,
                    out removed));

            Assert.That(testObjects.ViewModel.AggregatedPartitionViewModels.Count, Is.EqualTo(0));
            Assert.That(testObjects.ViewModel.ShowPartitions, Is.False);
        }

        [Test]
        public void ShouldShiftPartitions_WhenPartitionPinChanged()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(202, "partition", "desc", 102, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(203, "partition", "desc", 103, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(204, "partition", "desc", 104, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}, IsSelected = true
                        };
            var item2 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 202, PriceCurveId = 102}
                        };
            var item3 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 203, PriceCurveId = 103}
                        };
            var item4 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 204, PriceCurveId = 104}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1, item2}},
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item3, item4}}
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item2.IsSelected = true;

            // ACT
            aggregatedPartition2.IsPartitionShiftPin = true;

            // ASSERT
            Mock.Get(testObjects.PartitionDateShiftCalculator)
                .Verify(c => c.ShiftPartitionsByPin(2, 0, aggregatedPartitions));
        }

        [Test]
        public void ShouldShiftPartitions_AndHidePinPrompt_WhenTenorShiftChanged_WithPartitionPinSet()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(202, "partition", "desc", 102, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(203, "partition", "desc", 103, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(204, "partition", "desc", 104, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };
            var item2 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 202, PriceCurveId = 102}
                        };
            var item3 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 203, PriceCurveId = 103}
                        };
            var item4 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 204, PriceCurveId = 104}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1, item2}},
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item3, item4}}
            };


            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item1.IsSelected = true;
            item2.IsSelected = true;

            aggregatedPartition2.IsPartitionShiftPin = true;

            Mock.Get(testObjects.PartitionDateShiftCalculator).Reset();

            // ACT
            testObjects.ViewModel.TenorShift = 3;

            // ASSERT
            Mock.Get(testObjects.PartitionDateShiftCalculator)
                .Verify(c => c.ApplyTenorShiftToPartitions(3, aggregatedPartitions));

            Assert.That(testObjects.ViewModel.ShowPartitionPinPrompt, Is.False);
        }

        [Test]
        public void ShouldNotShiftPartitions_AndShowPinPrompt_WhenTenorShiftChanged_WithPartitionPinNotSet()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(202, "partition", "desc", 102, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(203, "partition", "desc", 103, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(204, "partition", "desc", 104, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };
            var item2 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 202, PriceCurveId = 102}
                        };
            var item3 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 203, PriceCurveId = 103}
                        };
            var item4 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 204, PriceCurveId = 104}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1, item2}},
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item3, item4}}
            };


            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item1.IsSelected = true;
            item2.IsSelected = true;

            Mock.Get(testObjects.PartitionDateShiftCalculator).Reset();

            // ACT
            testObjects.ViewModel.TenorShift = 3;

            // ASSERT
            Mock.Get(testObjects.PartitionDateShiftCalculator)
                .Verify(c => c.ApplyTenorShiftToPartitions(3, aggregatedPartitions), Times.Never);

            Assert.That(testObjects.ViewModel.ShowPartitionPinPrompt, Is.True);
        }

        [Test]
        public void ShouldEnablePartitionShiftUpdate_WhenPartitionPinnedAndTenorShiftIsNonZero()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1}}
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item1.IsSelected = true;

            // ACT
            aggregatedPartition2.IsPartitionShiftPin = true;
            aggregatedPartition2.IsPartitionShift = true;
            testObjects.ViewModel.TenorShift = 3;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldPromptPendingPartitionShiftChanges_OnToolBarUpdate()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
            { PartitionedCurve = new PartitionedCurve { Id = 201, PriceCurveId = 101 } };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new()
                {
                    PartitionedCurveItems = new List<PartitionedCurveItem> {item1}
                }
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition { PartitionIndex = 1 }
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition { PartitionIndex = 2 }
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var promptMessages = new[] { "message1", "message2" };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .WithPromptMessages(promptMessages)
                                                                          .Build();

            item1.IsSelected = true;

            aggregatedPartition2.IsPartitionShiftPin = true;
            aggregatedPartition2.IsPartitionShift = true;
            testObjects.ViewModel.TenorShift = 3;

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPartitionShiftPromptDialog, Is.True);
            Assert.That(testObjects.ViewModel.PartitionShiftPromptMessages.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldSetBusy_And_InvokePartitionShiftRequestService_OnPartitionShiftPromptOkCommand()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                {PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}};

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1}}
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item1.IsSelected = true;

            aggregatedPartition2.IsPartitionShiftPin = true;
            aggregatedPartition2.IsPartitionShift = true;
            testObjects.ViewModel.TenorShift = 3;

            // ACT
            testObjects.ViewModel.PartitionShiftPromptOkCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.EqualTo("Shifting Partitions.."));

            Mock.Get(testObjects.PartitionShiftRequestService)
                .Verify(r => r.UpdatePartitionShift(It.Is<IEnumerable<int>>(ids => ids.Count() == 1 && ids.First() == 201),
                                                    2,
                                                    3,
                                                    It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldNotUpdate_WhenPartitionPinIndexIsZero_OnPartitionShiftPromptOkCommand()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new()
                {
                    PartitionedCurveItems = new List<PartitionedCurveItem> {item1}
                }
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item1.IsSelected = true;

            testObjects.ViewModel.TenorShift = 3;

            // ACT
            testObjects.ViewModel.PartitionShiftPromptOkCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);

            Mock.Get(testObjects.PartitionShiftRequestService)
                .Verify(r => r.UpdatePartitionShift(It.IsAny<IEnumerable<int>>(),
                                                    It.IsAny<int>(),
                                                    It.IsAny<int>(),
                                                    It.IsAny<IScheduler>()),
                        Times.Never);
        }

        [Test]
        public void ShouldResetSelectedPartitions_OnPartitionShiftCompletedSuccessfully()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new()
                {
                    PartitionedCurveItems = new List<PartitionedCurveItem> {item1}
                }
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item1.IsSelected = true;

            aggregatedPartition2.IsPartitionShiftPin = true;
            aggregatedPartition2.IsPartitionShift = true;
            testObjects.ViewModel.TenorShift = 3;

            testObjects.ViewModel.PartitionShiftPromptOkCommand.Execute();

            // ACT
            testObjects.CurveUpdated.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(item1.IsSelected, Is.False);
            Assert.That(testObjects.ViewModel.TenorShift, Is.EqualTo(0));
            Assert.That(testObjects.ViewModel.ShowPartitions, Is.False);
        }

        [Test]
        public void ShouldHandleErrorAndShowDialog_OnUpdateCommandPricingFailuresException()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                {PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}};

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1}}
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveGroups(curveGroups)
                                                                          .WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .WithCanParseFailures(true)
                                                                          .Build();

            item1.IsSelected = true;

            aggregatedPartition2.IsPartitionShiftPin = true;
            aggregatedPartition2.IsPartitionShift = true;
            testObjects.ViewModel.TenorShift = 3;

            testObjects.ViewModel.PartitionShiftPromptOkCommand.Execute();

            var pricingFailure = new PricingFailure(201, 101, PricingFailureReason.AnchorPointTenorReferenceNotFound,
                new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), string.Empty);

            var exception = new Exception("failed",
                new PricingFailuresException(new List<PricingFailure> {pricingFailure}));

            // ACT
            testObjects.CurveUpdated.OnError(exception);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);

            string[] messages;
            Mock.Get(testObjects.PricingFailuresParser)
                .Verify(p => p.TryParsePricingFailures(It.IsAny<Dictionary<LinkedCurve, string>>(),
                                                       It.IsAny<List<PricingFailure>>(),
                                                       out messages), Times.Once);
        }

        [Test]
        public void ShouldHandleErrorAndShowDialog_OnUpdateCommandOnException()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new()
                {
                    PartitionedCurveItems = new List<PartitionedCurveItem> {item1}
                }
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveGroups(curveGroups)
                                                                          .WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item1.IsSelected = true;

            aggregatedPartition2.IsPartitionShiftPin = true;
            aggregatedPartition2.IsPartitionShift = true;
            testObjects.ViewModel.TenorShift = 3;

            testObjects.ViewModel.PartitionShiftPromptOkCommand.Execute();

            var exception = new Exception("failed");

            // ACT
            testObjects.CurveUpdated.OnError(exception);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(testObjects.ViewModel.MessageDialog.DialogMessages.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldRefreshCurveDefinitions_When_DefinitionsUpdated_And_CurveGroupsInitialized()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var partitionedCurvesUpdate = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, 
                    "partition-update", 
                    "desc", 
                    101, 
                    10, 
                    new[]
                    {
                        new CurvePartition<MonthlyTenor>(new MonthlyTenor(2019, 1),
                                                         new CurveContributionDefinition(new LinkedCurve(301,
                                                                                                         PriceCurveDefinitionType.DerivedCurve)))
                    })
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new()
                {
                    PartitionedCurveItems = new List<PartitionedCurveItem> {item1}
                }
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 1}
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition {PartitionIndex = 2}
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            testObjects.CurvesLoaded.OnNext(true);
            testObjects.CurveUpdated.OnNext(Unit.Default);

            Mock.Get(testObjects.CurveDefinitionProvider).Reset();

            Mock.Get(testObjects.CurveDefinitionProvider)
                .SetupGet(p => p.PartitionedCurveDefinitions)
                .Returns(partitionedCurvesUpdate);

            IList<AggregatedPartitionViewModel> added;
            IList<AggregatedPartitionViewModel> removed;

            // ACT
            testObjects.CurvesLoaded.OnNext(true);
            testObjects.TestScheduler.AdvanceBy(10);

            item1.IsSelected = true;

            // ASSERT
            Mock.Get(testObjects.AggregatedPartitionBuilder)
                .Verify(c => c.UpdatePartitionedCurves(
                                                       It.Is<IList<PartitionedCurveDefinition<MonthlyTenor>>>(p => p.Count == 1 
                                                                                                                   && p[0].Partitions.Count == 1),
                                                       It.IsAny<IList<AggregatedPartitionViewModel>>(),
                                                       out added,
                                                       out removed));
        }

        [Test]
        public void ShouldUpdateDialogAndSendPopupNotification_OnUpdateSuccess()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve { Id = 201, PriceCurveId = 101 }
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new()
                {
                    PartitionedCurveItems = new List<PartitionedCurveItem> {item1}
                }
            };

            var aggregatedPartition1 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition { PartitionIndex = 1 }
                                       };
            var aggregatedPartition2 = new AggregatedPartitionViewModel
                                       {
                                           AggregatedPartition = new AggregatedPartition { PartitionIndex = 2 }
                                       };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                aggregatedPartition1,
                aggregatedPartition2
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveGroups(curveGroups)
                                                                          .WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            item1.IsSelected = true;

            aggregatedPartition2.IsPartitionShiftPin = true;
            aggregatedPartition2.IsPartitionShift = true;
            testObjects.ViewModel.TenorShift = 3;

            testObjects.ViewModel.PartitionShiftPromptOkCommand.Execute();

            // ACT
            testObjects.CurveUpdated.OnNext(Unit.Default);

            // ASSERT
            Assert.That(item1.IsSelected, Is.False);
            Assert.That(testObjects.ViewModel.TenorShift, Is.EqualTo(0));
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
            Mock.Get(testObjects.PopupNotificationService).Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldCloseMessageDialog_OnCloseCommand()
        {
            var testObjects = new PartitionShiftViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ShowDialog = true;

            // ACT
            testObjects.ViewModel.MessageDialog.DialogOkCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldIgnoreChanges_WhenDisposed()
        {
            var partitionedCurves = new List<PartitionedCurveDefinition<MonthlyTenor>>
            {
                new(201, "partition", "desc", 101, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(202, "partition", "desc", 102, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(203, "partition", "desc", 103, 10, Array.Empty<CurvePartition<MonthlyTenor>>()),
                new(204, "partition", "desc", 104, 10, Array.Empty<CurvePartition<MonthlyTenor>>())
            };

            var item1 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 201, PriceCurveId = 101}
                        };
            var item2 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 202, PriceCurveId = 102}
                        };
            var item3 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 203, PriceCurveId = 103}
                        };
            var item4 = new PartitionedCurveItem
                        {
                            PartitionedCurve = new PartitionedCurve {Id = 204, PriceCurveId = 104}
                        };

            var curveGroups = new List<PartitionedCurveGroup>
            {
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item1, item2}},
                new() {PartitionedCurveItems = new List<PartitionedCurveItem> {item3, item4}}
            };

            var aggregatedPartitions = new List<AggregatedPartitionViewModel>
            {
                new() {IsHeader = true},
                new()
            };

            var testObjects 
                = new PartitionShiftViewModelControllerTestObjectBuilder().WithPartitionedCurveDefinitions(partitionedCurves)
                                                                          .WithPartitionedCurveGroups(curveGroups)
                                                                          .WithCurvesLoaded(true)
                                                                          .WithAggregatedPartitions(aggregatedPartitions)
                                                                          .Build();

            IList<AggregatedPartitionViewModel> added;
            IList<AggregatedPartitionViewModel> removed;


            testObjects.Controller.Dispose();

            // ACT
            item1.IsSelected = true;

            // ASSERT
            Mock.Get(testObjects.AggregatedPartitionBuilder)
                .Verify(c => c.UpdatePartitionedCurves(It.IsAny<IList<PartitionedCurveDefinition<MonthlyTenor>>>(),
                                                       It.IsAny<IList<AggregatedPartitionViewModel>>(),
                                                       out added,
                                                       out removed),
                Times.Never);

            Assert.That(testObjects.ViewModel.AggregatedPartitionViewModels.Count, Is.EqualTo(0));

            Mock.Get(testObjects.PartitionDateShiftCalculator)
                .Verify(c => c.ApplyTenorShiftToPartitions(It.IsAny<int>(), 
                                                           It.IsAny<IList<AggregatedPartitionViewModel>>()), 
                        Times.Never);

            Assert.That(testObjects.ViewModel.ShowPartitions, Is.False);
        }
    }
}
