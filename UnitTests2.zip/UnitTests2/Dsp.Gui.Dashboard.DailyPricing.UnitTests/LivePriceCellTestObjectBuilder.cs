﻿using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Dashboard.DailyPricing.Models;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests
{ 
    internal class LivePriceCellTestObjectBuilder
    {
        private RowTenorType _rowTenorType;
        private ITenor _tenor;
        private LinkedCurve _curveId;
        private double? _midPrice;
        private PriceDirection _priceDirection;
        private bool _isStale;
        private double? _infoMidPrice;
        private bool _infoIsStale;

        public LivePriceCellTestObjectBuilder WithRowTenorType(RowTenorType value)
        {
            _rowTenorType = value;
            return this;
        }

        public LivePriceCellTestObjectBuilder WithTenor(ITenor value)
        {
            _tenor = value;
            return this;
        }

        public LivePriceCellTestObjectBuilder WithCurveId(LinkedCurve value)
        {
            _curveId = value;
            return this;
        }

        public LivePriceCellTestObjectBuilder WithMidPrice(double? value)
        {
            _midPrice = value;
            return this;
        }

        public LivePriceCellTestObjectBuilder WithPriceDirection(PriceDirection value)
        {
            _priceDirection = value;
            return this;
        }

        public LivePriceCellTestObjectBuilder WithIsStale(bool value)
        {
            _isStale = value;
            return this;
        }

        public LivePriceCellTestObjectBuilder WithInfoMidPrice(double? value)
        {
            _infoMidPrice = value;
            return this;
        }

        public LivePriceCellTestObjectBuilder WithInfoIsStale(bool value)
        {
            _infoIsStale = value;
            return this;
        }

        public LivePriceCell Build()
        {
            var livePriceCell = new LivePriceCell
                                {
                                    RowTenorType = _rowTenorType,
                                    MidPrice = _midPrice,
                                    PriceDirection = _priceDirection,
                                    IsStale = _isStale
                                };

            livePriceCell.SetPriceInfo(new LivePriceInfo(_tenor, _curveId)
                                       {
                                           MidPrice = _infoMidPrice,
                                           IsStale = _infoIsStale
                                       });

            return livePriceCell;
        }
    }
}
