﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive.Subjects;
using Castle.Components.DictionaryAdapter;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Common.PriceGrid.Services.Grid;
using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.Dashboard.DailyPricing.Controllers;
using Dsp.Gui.Dashboard.DailyPricing.Services.Clipboard;
using Dsp.Gui.Dashboard.DailyPricing.Services.Commands;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using Dsp.Gui.Dashboard.DailyPricing.Services.DailyPrice;
using Dsp.Gui.Dashboard.DailyPricing.Services.Efp;
using Dsp.Gui.Dashboard.DailyPricing.Services.LivePrice;
using Dsp.Gui.Dashboard.DailyPricing.Services.ManualCurve;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.Services.DataSource;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers
{
    internal interface IDailyPricingViewModelControllerTestObjects
    {
        IDailyPriceRowDataSourceService DataSourceService { get; }
        IDailyPriceRowDataSource DataSource { get; }
        IDailyPriceDataRefreshService DailyPriceDataRefreshService { get; }
        ILivePriceCurvesService LivePriceCurvesService { get; }
        IEfpMonthItemsProvider EfpMonthItemsProvider { get; }
        ILivePriceStreamLookupService LivePriceStreamLookupService { get; }
        IDailyPriceGridRefreshService GridRefreshService { get; }
        IDailyPriceGridBuilder GridBuilder { get; }
        IBandSubscribeUpdatesService BandSubscribeUpdatesService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        ILinkedPremiumsUpdateFromParentService LinkedPremiumsUpdateFromParentService { get; }
        IEfpUpdateChildrenFromParentService EfpUpdateChildrenFromParentService { get; }
        IDailyPriceGridClipboardService ClipboardService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        IDailyPriceCurveUpdateService DailyPriceCurveUpdateService { get; }
        ITenorMarginsUpdateService TenorMarginsUpdateService { get; }
        ISetSelectedRowsService SetSelectedRowsService { get; }
        IEfpCellGroupingService EfpCellGroupingService { get; }
        ITenorPremiumCellGroupingService TenorPremiumCellGroupingService { get; }
        IDayOfWeekCalculator DatOfWeekCalculator { get; }
        ITenorTreeNodeExpansionService TenorTreeNodeExpansionService { get; }
        IClearPremiumsService ClearPremiumsService { get; }
        IDispatcherExecutionService Dispatcher { get; }
        ISubject<SystemRunConnectState> SystemRunConnectState { get; }
        ISubject<List<ILivePriceStreamService>> LivePriceStreams { get; }
        ISubject<DailyPriceDataRefreshArgs> DailyPriceDataRefresh { get; }
        ISubject<List<EfpMonthItem>> EfpMonthItems { get; }
        DailyPricingViewModelController Controller { get; }
        DailyPricingViewModel ViewModel { get; }
    }

    [TestFixture]
    public class DailyPricingViewModelControllerTests
    {
        private class DailyPricingViewModelControllerTestObjectBuilder
        {
            private int _parentCurveId;
            private int _monthlyCurveId;
            private SystemRunConnectState _systemRunConnectState;
            private List<ILivePriceStreamService> _livePriceStreamServices;
            private List<EfpMonthItem> _efpMonthItems;
            private DailyPriceGridRefreshArgs _dailyPriceGridRefreshArgs;
            private ReadOnlyObservableCollection<DailyPriceRowViewModel> _refreshPriceRowsResult;
            private List<DailyPriceRowViewModel> _dataSourceItems = new();
            private ObservableCollection<DailyPriceRowViewModel> _dailyPriceRowViewModels;
            private ObservableCollection<BandHeader> _bandHeaders;
            private IList<DailyPriceRowViewModel> _addedClipboardRows = new List<DailyPriceRowViewModel>();
            private bool _isPublisher;
            private bool _isPublisherEditor;
            private bool _tryUpdatePricesFromClipboardResult;
            private int _dayOfWeekCalculatorResult;
            private List<DailyPriceRowViewModel> _extendedDailyPriceRows;
            private List<string> _nodeExpansionKeys;
            private bool _isSubscribedManualCurveUpdates;
            private bool _isSubscribedTenorPremiumsUpdates;
			private Exception _updateDailyPricesException;

			public DailyPricingViewModelControllerTestObjectBuilder WithParentCurveId(int value)
            {
                _parentCurveId = value;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithMonthlyCurveId(int value)
            {
                _monthlyCurveId = value;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithSystemRunConnectState(SystemRunConnectState value)
            {
                _systemRunConnectState = value;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithLivePriceStreamServices(List<ILivePriceStreamService> values)
            {
                _livePriceStreamServices = values;
                return this;
            }
            public DailyPricingViewModelControllerTestObjectBuilder WithEfpMonthItems(List<EfpMonthItem> values)
            {
                _efpMonthItems = values;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithDailyPriceGridRefreshArgs(DailyPriceGridRefreshArgs value)
            {
                _dailyPriceGridRefreshArgs = value;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithRefreshPriceRowsResult(ReadOnlyObservableCollection<DailyPriceRowViewModel> values)
            {
                _refreshPriceRowsResult = values;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithDataSourceItems(IEnumerable<DailyPriceRowViewModel> values)
            {
                _dataSourceItems = new EditableList<DailyPriceRowViewModel>(values);
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithViewModelDailyPriceRows(ObservableCollection<DailyPriceRowViewModel> values)
            {
                _dailyPriceRowViewModels = values;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithViewModelBandHeaders(ObservableCollection<BandHeader> values)
            {
                _bandHeaders = values;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithAddedClipboardRows(IList<DailyPriceRowViewModel> values)
            {
                _addedClipboardRows = values;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithIsPublisher(bool value)
            {
                _isPublisher = value;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithIsPublisherEditor(bool value)
            {
                _isPublisherEditor = value;
                return this;
            }

			public DailyPricingViewModelControllerTestObjectBuilder WithTryUpdatePricesFromClipboardResult(bool value)
            {
                _tryUpdatePricesFromClipboardResult = value;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithDayOfWeekCalculatorResult(int value)
            {
                _dayOfWeekCalculatorResult = value;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithNodeExpansionKeys(List<string> values)
            {
                _nodeExpansionKeys = values;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithExtendedDailyPriceRows(List<DailyPriceRowViewModel> values)
            {
                _extendedDailyPriceRows = values;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithIsSubscribedManualCurveUpdates(bool value)
            {
                _isSubscribedManualCurveUpdates = value;
                return this;
            }

            public DailyPricingViewModelControllerTestObjectBuilder WithIsSubscribedTenorPremiumsUpdates(bool value)
            {
                _isSubscribedTenorPremiumsUpdates = value;
                return this;
            }

			public DailyPricingViewModelControllerTestObjectBuilder WithUpdateDailyPricesException(Exception value)
			{
				_updateDailyPricesException = value;
				return this;
			}

			public IDailyPricingViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IDailyPricingViewModelControllerTestObjects>();

                var curveIdsProvider = new Mock<IDatedBrentCurveIdsProvider>();

                curveIdsProvider.SetupGet(p => p.ParentCurveId)
                                .Returns(_parentCurveId);

                curveIdsProvider.SetupGet(p => p.MonthlyCurveId)
                                .Returns(_monthlyCurveId);

                var efpMonthItems = new BehaviorSubject<List<EfpMonthItem>>(_efpMonthItems);

                testObjects.SetupGet(o => o.EfpMonthItems)
                           .Returns(efpMonthItems);

                var efpMonthlyTenorsProvider = new Mock<IEfpMonthItemsProvider>();

                efpMonthlyTenorsProvider.Setup(p => p.GetEfpMonthItems(It.IsAny<ILivePriceStreamService>()))
                                        .Returns(efpMonthItems);

                efpMonthlyTenorsProvider.Setup(p => p.EfpMonthItemsSnapshot())
                                        .Returns(_efpMonthItems);

                testObjects.SetupGet(o => o.EfpMonthItemsProvider)
                           .Returns(efpMonthlyTenorsProvider.Object);

                var runState = new BehaviorSubject<SystemRunConnectState>(_systemRunConnectState);

                testObjects.SetupGet(o => o.SystemRunConnectState)
                           .Returns(runState);

                var connectionStatusService = new Mock<IConnectionRunStateMonitor>();

                connectionStatusService.SetupGet(c => c.RunState)
                                       .Returns(runState);

                var dailyPriceDataRefresh = new Subject<DailyPriceDataRefreshArgs>();

                testObjects.SetupGet(o => o.DailyPriceDataRefresh)
                           .Returns(dailyPriceDataRefresh);

                var dailyPriceDataRefreshService = new Mock<IDailyPriceDataRefreshService>();

                dailyPriceDataRefreshService.Setup(r => r.RefreshPriceGrid(It.IsAny<int>()))
                                            .Returns(dailyPriceDataRefresh);

                testObjects.SetupGet(o => o.DailyPriceDataRefreshService)
                           .Returns(dailyPriceDataRefreshService.Object);

                var gridRefreshService = new Mock<IDailyPriceGridRefreshService>();

                gridRefreshService.Setup(r => r.GetDailyPriceGrid(It.IsAny<int>(),
                                                                  It.IsAny<ManualCurveDefinition<DailyTenor>>(),
                                                                  It.IsAny<PublisherTenorPremium>(),
                                                                  It.IsAny<List<ILivePriceStreamService>>(),
                                                                  It.IsAny<IDispatcherExecutionService>(),
                                                                  It.IsAny<DateTime>()))
                                  .Returns(_dailyPriceGridRefreshArgs);

                testObjects.SetupGet(o => o.GridRefreshService)
                           .Returns(gridRefreshService.Object);

                var gridBuilder = new Mock<IDailyPriceGridBuilder>();

                gridBuilder.Setup(b => b.GetExtendedDailyPriceRows(It.IsAny<IList<DailyPriceRowViewModel>>(),
                                                                   It.IsAny<IList<EfpMonthItem>>(),
                                                                   It.IsAny<int>()))
                           .Returns(_extendedDailyPriceRows);

                testObjects.SetupGet(o => o.GridBuilder)
                           .Returns(gridBuilder.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var dispatcher = new Mock<IDispatcherExecutionService>();

                testObjects.SetupGet(o => o.Dispatcher)
                           .Returns(dispatcher.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var clipboardService = new Mock<IDailyPriceGridClipboardService>();

                clipboardService.Setup(c => c.TryUpdatePricesFromClipboard(It.IsAny<DailyPriceRowViewModel>()))
                                .Callback<DailyPriceRowViewModel>(_ => _dataSourceItems.AddRange(_addedClipboardRows))
                                .Returns(_tryUpdatePricesFromClipboardResult);

                testObjects.SetupGet(o => o.ClipboardService)
                           .Returns(clipboardService.Object);

                var priceCurveUpdateService = new Mock<IDailyPriceCurveUpdateService>();

				if (_updateDailyPricesException != null)
				{
					priceCurveUpdateService.Setup(d => d.UpdateDailyPrices(It.IsAny<IList<DailyPriceRowViewModel>>(),
																		   It.IsAny<ManualCurveDefinition<DailyTenor>>(),
																		   It.IsAny<IList<EfpMonthItem>>(),
																		   It.IsAny<bool>()))
										   .Throws(_updateDailyPricesException);
				}

                testObjects.SetupGet(o => o.DailyPriceCurveUpdateService)
                           .Returns(priceCurveUpdateService.Object);

                var tenorMarginsUpdateService = new Mock<ITenorMarginsUpdateService>();

                testObjects.SetupGet(o => o.TenorMarginsUpdateService)
                           .Returns(tenorMarginsUpdateService.Object);

                var setSelectedRowsService = new Mock<ISetSelectedRowsService>();

                testObjects.SetupGet(o => o.SetSelectedRowsService)
                           .Returns(setSelectedRowsService.Object);

                var efpCellGroupingService = new Mock<IEfpCellGroupingService>();

                testObjects.SetupGet(o => o.EfpCellGroupingService)
                           .Returns(efpCellGroupingService.Object);

                var tenorPremiumCellGroupingService = new Mock<ITenorPremiumCellGroupingService>();

                testObjects.SetupGet(o => o.TenorPremiumCellGroupingService)
                           .Returns(tenorPremiumCellGroupingService.Object);

                var efpUpdateChildrenFromParentService = new Mock<IEfpUpdateChildrenFromParentService>();

                testObjects.SetupGet(o => o.EfpUpdateChildrenFromParentService)
                           .Returns(efpUpdateChildrenFromParentService.Object);

                var dayOfWeekCalculator = new Mock<IDayOfWeekCalculator>();

                dayOfWeekCalculator.Setup(c => c.GetDaysToNextDayOfWeek(It.IsAny<DateTime>(), It.IsAny<DayOfWeek>()))
                                   .Returns(_dayOfWeekCalculatorResult);

                testObjects.SetupGet(o => o.DatOfWeekCalculator)
                           .Returns(dayOfWeekCalculator.Object);

                var tenorTreeNodeExpansionService = new Mock<ITenorTreeNodeExpansionService>();

                tenorTreeNodeExpansionService.Setup(t => t.GetTenorNodeExpansionKeys(It.IsAny<IList<ITenorNode>>(),
                                                                                     It.IsAny<ITenorNode>()))
                                             .Returns(_nodeExpansionKeys);

                testObjects.SetupGet(o => o.TenorTreeNodeExpansionService)
                           .Returns(tenorTreeNodeExpansionService.Object);

                var bandSubscribeUpdatesService = new Mock<IBandSubscribeUpdatesService>();

                bandSubscribeUpdatesService.SetupGet(b => b.IsSubscribedManualOverrideUpdates)
                                           .Returns(_isSubscribedManualCurveUpdates);

                bandSubscribeUpdatesService.SetupGet(b => b.IsSubscribedTenorPremiumsUpdates)
                                           .Returns(_isSubscribedTenorPremiumsUpdates);

				testObjects.SetupGet(o => o.BandSubscribeUpdatesService)
                           .Returns(bandSubscribeUpdatesService.Object);

                var dataSource = new Mock<IDailyPriceRowDataSource>();

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                dataSource.Setup(d => d.InitializeDataSource(It.IsAny<IList<DailyPriceRowViewModel>>()))
                          .Returns(_refreshPriceRowsResult);

                dataSource.Setup(d => d.Items())
                          .Returns(_dataSourceItems);

                dataSource.Setup(d => d.AddItems(It.IsAny<List<DailyPriceRowViewModel>>()))
                          .Callback(() => _dataSourceItems.AddRange(_extendedDailyPriceRows));

                var dataSourceService = new Mock<IDailyPriceRowDataSourceService>();

                dataSourceService.SetupGet(d => d.DataSource)
                                 .Returns(dataSource.Object);

                dataSourceService.Setup(d => d.BusinessDayRows())
                                 .Returns(_dataSourceItems.Where(i => i.IsBusinessDay).ToList);

                testObjects.SetupGet(o => o.DataSourceService)
                           .Returns(dataSourceService.Object);

                var livePriceStreams = new BehaviorSubject<List<ILivePriceStreamService>>(_livePriceStreamServices);

                testObjects.SetupGet(o => o.LivePriceStreams)
                           .Returns(livePriceStreams);

                var livePriceCurvesService = new Mock<ILivePriceCurvesService>();

                livePriceCurvesService.Setup(p => p.GenerateLivePrices(It.IsAny<int>(), It.IsAny<int>()))
                                      .Returns(livePriceStreams);

                testObjects.SetupGet(o => o.LivePriceCurvesService)
                           .Returns(livePriceCurvesService.Object);

                var livePriceStreamLookupService = new Mock<ILivePriceStreamLookupService>();

                testObjects.SetupGet(o => o.LivePriceStreamLookupService)
                           .Returns(livePriceStreamLookupService.Object);

                var clearPremiumsService = new Mock<IClearPremiumsService>();

                testObjects.SetupGet(o => o.ClearPremiumsService)
                           .Returns(clearPremiumsService.Object);

                var linkedPremiumsUpdateFromParentService = new Mock<ILinkedPremiumsUpdateFromParentService>();

                testObjects.SetupGet(o => o.LinkedPremiumsUpdateFromParentService)
                           .Returns(linkedPremiumsUpdateFromParentService.Object);

                var controller = new DailyPricingViewModelController(connectionStatusService.Object,
                                                                     curveIdsProvider.Object,
                                                                     efpMonthlyTenorsProvider.Object,
                                                                     dailyPriceDataRefreshService.Object,
                                                                     livePriceCurvesService.Object,
                                                                     dispatcher.Object,
                                                                     TestMocks.GetSchedulerProvider().Object,
                                                                     TestMocks.GetLoggerFactory().Object)
                {
                    GridBuilder = gridBuilder.Object,
                    DataSourceService = dataSourceService.Object,
                    BandSubscribeUpdatesService = bandSubscribeUpdatesService.Object,
                    DailyPriceCurveUpdateService = priceCurveUpdateService.Object,
                    LivePriceStreamLookupService = livePriceStreamLookupService.Object,
                    TenorMarginsUpdateService = tenorMarginsUpdateService.Object,
                    ClipboardService = clipboardService.Object,
                    PopupNotificationService = popupNotificationService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    SetSelectedRowsService = setSelectedRowsService.Object,
                    EfpCellGroupingService = efpCellGroupingService.Object,
                    TenorPremiumCellGroupingService = tenorPremiumCellGroupingService.Object,
                    DayOfWeekCalculator = dayOfWeekCalculator.Object,
                    DailyPriceGridRefreshService = gridRefreshService.Object,
                    TenorTreeNodeExpansionService = tenorTreeNodeExpansionService.Object,
                    EfpUpdateChildrenFromParentService = efpUpdateChildrenFromParentService.Object,
                    ClearPremiumsService = clearPremiumsService.Object,
                    LinkedPremiumsUpdateFromParentService= linkedPremiumsUpdateFromParentService.Object
                };

                if (_dailyPriceRowViewModels != null)
                {
                    controller.ViewModel.DailyPriceRows = new ReadOnlyObservableCollection<DailyPriceRowViewModel>(_dailyPriceRowViewModels);
                }

                if (_bandHeaders != null)
                {
                    controller.ViewModel.BandHeaders = _bandHeaders;
                }

                controller.ViewModel.IsPublisher = _isPublisher;
                controller.ViewModel.IsPublisherEditor = _isPublisherEditor;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region Initialize Connection
  
        [Test]
        public void ShouldSetIsBusyFalse_When_FailedStartup()
        {
            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.FailedStartup);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
        }

        [TestCase(SystemRunConnectState.Connected)]
        [TestCase(SystemRunConnectState.Reconnected)]
        public void ShouldSetIsBusyTrue_And_RefreshGrid_When_Connected_Or_Reconnected(SystemRunConnectState connectState)
        {
            var monthlyCurveId = new LinkedCurve(200, PriceCurveDefinitionType.PriceCurve);

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(monthlyCurveId).Build();

            var stream2 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(201, PriceCurveDefinitionType.PriceCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService>
                                   {
                                       stream1.Object, stream2.Object
                                   };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithParentCurveId(100)
                                                                                    .WithMonthlyCurveId(monthlyCurveId.Id)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .Build();

            // ACT
            testObjects.SystemRunConnectState.OnNext(connectState);

            // ASSERT
            Mock.Get(testObjects.LivePriceCurvesService)
                .Verify(l => l.GenerateLivePrices(100, 200));

            Mock.Get(testObjects.EfpMonthItemsProvider)
                .Verify(p => p.GetEfpMonthItems(stream1.Object));

            Mock.Get(testObjects.DailyPriceDataRefreshService)
                .Verify(d => d.RefreshPriceGrid(It.IsAny<int>()));

            Assert.That(testObjects.ViewModel.IsBusy, Is.True);

            Assert.IsNotNull(testObjects.ViewModel.BusyText);
        }

        #endregion

        #region Rebuild Grid - Initialize and Unsubscribe Updates

        [Test]
        public void ShouldRebuildGrid_And_InitializeLivePriceUpdates_When_DataRefresh_With_RebuildArgs()
        {
            var date = new DateTime(2023, 1, 1);

            var monthlyCurveId = new LinkedCurve(200, PriceCurveDefinitionType.PriceCurve);

            var curve = new ManualCurveDefinitionBuilder<DailyTenor>().WithName("daily-curve")
                                                                      .Build();

            var premium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var priceRows = new List<DailyPriceRowViewModel>
                            {
                                new(Mock.Of<IDisposable>()),
                                new(Mock.Of<IDisposable>())
                            };

            var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
            var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            var livePriceBandHeaders = new[]
                                       {
                                           new BandHeader(new LivePriceBandHeader()),
                                           new BandHeader(new LivePriceBandHeader())
                                       };

            var bandHeaders = new List<BandHeader>
                              {
                                  manualCurveBandHeader,
                                  tenorPremiumsBandHeader,
                                  livePriceBandHeaders[0],
                                  livePriceBandHeaders[1]
                              };

            var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
                                            {
                                                DailyPriceRows = priceRows,
                                                Bands = bandHeaders
                                            };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(monthlyCurveId)
                                                                 .WithTenorType(TenorType.Month)
                                                                 .Build();

            var stream2 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(201, PriceCurveDefinitionType.PriceCurve))
                                                                 .WithTenorType(TenorType.Day)
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService>
                                   {
                                       stream1.Object, stream2.Object
                                   };

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(new MonthlyTenor(2023, 1), true)
                                };

            var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>(new ObservableCollection<DailyPriceRowViewModel>(priceRows));

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithMonthlyCurveId(monthlyCurveId.Id)
                                                                                    .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithRefreshPriceRowsResult(refreshResult)
                                                                                    .WithEfpMonthItems(efpMonthItems)
                                                                                    .Build();

            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
                                                                true,
                                                                true,
                                                                date,
                                                                curve,
                                                                premium);

            var expectedDailyStreams = new[] { stream2.Object };

            // ACT
            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
            Assert.That(testObjects.ViewModel.GridLoaded, Is.True);

            Mock.Get(testObjects.GridRefreshService)
                .Verify(r => r.GetDailyPriceGrid(50, 
                                                 curve, 
                                                 premium, 
                                                 It.Is<IList<ILivePriceStreamService>>(s => s.SequenceEqual(expectedDailyStreams)), 
                                                 testObjects.Dispatcher, 
                                                 date));

            Mock.Get(testObjects.DailyPriceCurveUpdateService)
                .Verify(p => p.UpdateDailyPrices(It.Is<IList<DailyPriceRowViewModel>>(r => r.Count == 2), 
                                                 curve, 
                                                 efpMonthItems,
                                                 false));

            Mock.Get(testObjects.LivePriceStreamLookupService)
                .Verify(l => l.Update(It.Is<IList<ILivePriceStreamService>>(s => s.Count == 1)));

            Mock.Get(testObjects.TenorMarginsUpdateService)
                .Verify(p => p.UpdateTenorMargins(It.Is<IList<DailyPriceRowViewModel>>(r => r.Count == 2), premium, true));

            Assert.That(testObjects.ViewModel.CurveName, Is.EqualTo("daily-curve"));

            Mock.Get(testObjects.DataSource)
                .Verify(d => d.InitializeDataSource(It.Is<IList<DailyPriceRowViewModel>>(rows => rows.Count == 2)));

            Assert.That(testObjects.ViewModel.DailyPriceRows.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.BandHeaders.Count, Is.EqualTo(4));

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeLivePriceUpdates(It.Is<IList<LivePriceBandHeader>>(bands => bands.Count == 2)));

            Mock.Get(testObjects.Dispatcher)
                .Verify(d => d.Start());
        }

        [Test]
        public void ShouldUnsubscribeUpdates_When_RebuildGrid_With_IsSubscribedUpdatesTrue()
        {
            var date = new DateTime(2023, 1, 1);

            var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
            var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            var bandHeaders = new ObservableCollection<BandHeader>
                              {
                                  manualCurveBandHeader,
                                  tenorPremiumsBandHeader
                              };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService>
                                   {
                                       stream1.Object
                                   };

            var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
            {
                DailyPriceRows = [], Bands = []
            };

            var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>([]);

            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithSubscribeManualCurveUpdates(true).Build();

            var rows = new List<DailyPriceRowViewModel> { row };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithRefreshPriceRowsResult(refreshResult)
                                                                                    .WithViewModelBandHeaders(bandHeaders)
                                                                                    .WithIsSubscribedManualCurveUpdates(true)
                                                                                    .WithIsSubscribedTenorPremiumsUpdates(true)
                                                                                    .WithDataSourceItems(rows)
                                                                                    .Build();

            // ACT
            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
                                                                false,
                                                                false,
                                                                date,
                                                                null,
                                                                null);

            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

            // ASSERT
            Assert.That(row.SubscribeManualCurveUpdates, Is.False);

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.UnsubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader));

            Assert.That(row.SubscribeTenorPremiumUpdates, Is.False);

			Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.UnsubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader));
		}

        [Test]
        public void ShouldNotUnsubscribeUpdates_When_RebuildGrid_With_IsSubscribedUpdatesFalse()
        {
            var date = new DateTime(2023, 1, 1);

            var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
            var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            var bandHeaders = new ObservableCollection<BandHeader>
                              {
                                  manualCurveBandHeader,
                                  tenorPremiumsBandHeader
                              };

            var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
            {
                DailyPriceRows = [], Bands = []
            };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService>
                                   {
                                       stream1.Object
                                   };

            var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>([]);

            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithSubscribeManualCurveUpdates(false).Build();

            var rows = new List<DailyPriceRowViewModel> { row };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithRefreshPriceRowsResult(refreshResult)
                                                                                    .WithViewModelBandHeaders(bandHeaders)
                                                                                    .WithIsSubscribedManualCurveUpdates(false)
                                                                                    .WithIsSubscribedTenorPremiumsUpdates(false)
                                                                                    .WithDataSourceItems(rows)
                                                                                    .Build();

            // ACT
            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
                                                                false,
                                                                false,
                                                                date,
                                                                null,
                                                                null);

            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

            // ASSERT
            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.UnsubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader), Times.Never);

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.UnsubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader), Times.Never);
		}

        [Test]
        public void ShouldSubscribeManualCurve_And_TenorPremiumUpdates_When_RebuildGrid_With_IsPublisherTrue_ExcelSourceFalse()
        {
            var date = new DateTime(2023, 1, 1);

            var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
            var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            var premium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithSubscribeManualCurveUpdates(false).Build();

            var priceRows = new List<DailyPriceRowViewModel> { row };

            var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
            {
                DailyPriceRows = new EditableList<DailyPriceRowViewModel> { row },
                Bands =
                [
                    manualCurveBandHeader,
                    tenorPremiumsBandHeader
                ]
            };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

            var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>(new ObservableCollection<DailyPriceRowViewModel>(priceRows));

            var rows = new List<DailyPriceRowViewModel> { row };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithRefreshPriceRowsResult(refreshResult)
                                                                                    .WithDataSourceItems(rows)
                                                                                    .Build();

            // ACT
            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
                                                                true,
                                                                false,
                                                                date,
                                                                null,
                                                                premium);

            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

			// ASSERT
			Assert.That(testObjects.ViewModel.IsPublisher, Is.True);
            Assert.That(testObjects.ViewModel.IsPublisherEditor, Is.True);

			Assert.That(row.SubscribeManualCurveUpdates, Is.True);

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader));

            Assert.That(row.SubscribeTenorPremiumUpdates, Is.True);

			Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader));
		}

		[Test]
		public void ShouldSubscribeTenorPremiumUpdates_When_RebuildGrid_With_IsPublisherTrue_ExcelSourceTrue()
		{
			var date = new DateTime(2023, 1, 1);

			var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
			var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

			var premium = new PublisherTenorPremiumTestObjectBuilder().Build();

			var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithSubscribeManualCurveUpdates(false).Build();

			var priceRows = new List<DailyPriceRowViewModel> { row };

			var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
			{
				DailyPriceRows = new EditableList<DailyPriceRowViewModel> { row },
				Bands =
				[
					manualCurveBandHeader,
					tenorPremiumsBandHeader
				]
			};

			var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
																 .Build();

			var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

			var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>(new ObservableCollection<DailyPriceRowViewModel>(priceRows));

			var rows = new List<DailyPriceRowViewModel> { row };

			var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
																					.WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
																					.WithLivePriceStreamServices(livePriceStreams)
																					.WithRefreshPriceRowsResult(refreshResult)
																					.WithDataSourceItems(rows)
																					.Build();

			// ACT
			var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
																true,
																true,
																date,
																null,
																premium);

			testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

			// ASSERT
			Assert.That(testObjects.ViewModel.IsPublisher, Is.True);
			Assert.That(testObjects.ViewModel.IsPublisherEditor, Is.False);

            Assert.That(row.SubscribeTenorPremiumUpdates, Is.True);

			Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader));

            Assert.That(row.SubscribeManualCurveUpdates, Is.False);

			Mock.Get(testObjects.BandSubscribeUpdatesService)
				.Verify(b => b.SubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader), Times.Never);
		}

		[Test]
        public void ShouldNotSubscribeUpdates_When_RebuildGrid_With_IsPublisherFalse()
        {
            var date = new DateTime(2023, 1, 1);

            var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
            var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            var priceRows = new List<DailyPriceRowViewModel>
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build(),
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build(),
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build()
                            };

            var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
                                            {
                                                DailyPriceRows = priceRows,
                                                Bands =
                                                [
                                                    manualCurveBandHeader,
                                                    tenorPremiumsBandHeader
                                                ]
                                            };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

            var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>(new ObservableCollection<DailyPriceRowViewModel>(priceRows));

            var row = new DailyPriceRowTestObjectBuilder().WithSubscribeManualCurveUpdates(false).Build();

            var rows = new [] { row };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithRefreshPriceRowsResult(refreshResult)
                                                                                    .WithDataSourceItems(rows)
                                                                                    .Build();

            // ACT
            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
                                                                false,
                                                                false,
                                                                date,
                                                                null,
                                                                null);

            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

            // ASSERT
            Assert.That(row.SubscribeManualCurveUpdates, Is.False);

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader), Times.Never);

            Assert.That(row.SubscribeTenorPremiumUpdates, Is.False);

			Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader), Times.Never);

			Assert.That(testObjects.ViewModel.IsPublisher, Is.False);
        }

        #endregion

        #region Enable Commands

        [Test]
        public void ShouldEnableAllCommands_When_RebuildGrid_With_IsPublisherTrue_IsExcelSourceFalse()
        {
            var date = new DateTime(2023, 1, 1);

            var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
                                            {
                                                DailyPriceRows = [],
                                                Bands = []
                                            };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

            var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>([]);

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithRefreshPriceRowsResult(refreshResult)
                                                                                    .Build();

            // ACT
            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
                                                                true,
                                                                false,
                                                                date,
                                                                null,
                                                                null);

            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsPublisher, Is.True);
            Assert.That(testObjects.ViewModel.IsPublisherEditor, Is.True);

			Assert.That(testObjects.ViewModel.AddRowsCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.PastePricesCommand.CanExecute(null), Is.True);
            Assert.That(testObjects.ViewModel.SetMarginParentCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.SetMarginChildrenCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.ClearMarginDependenciesCommand.CanExecute(), Is.True);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

		[Test]
		public void ShouldDisablePriceAndEfpCommands_When_RebuildGrid_With_IsPublisherTrue_IsPublisherWithExcelTrue()
		{
			var date = new DateTime(2023, 1, 1);

			var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
			{
				DailyPriceRows = [], Bands = []
            };

			var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
																 .Build();

			var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

			var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>([]);

			var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
																					.WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
																					.WithLivePriceStreamServices(livePriceStreams)
																					.WithRefreshPriceRowsResult(refreshResult)
																					.Build();

			// ACT
			var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
																true,
																true,
																date,
																null,
																null);

			testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

			// ASSERT
            Assert.That(testObjects.ViewModel.IsPublisher, Is.True);
            Assert.That(testObjects.ViewModel.IsPublisherEditor, Is.False);

			Assert.That(testObjects.ViewModel.AddRowsCommand.CanExecute(), Is.False);
			Assert.That(testObjects.ViewModel.PastePricesCommand.CanExecute(null), Is.False);
			Assert.That(testObjects.ViewModel.SetMarginParentCommand.CanExecute(), Is.True);
			Assert.That(testObjects.ViewModel.SetMarginChildrenCommand.CanExecute(), Is.True);
			Assert.That(testObjects.ViewModel.ClearMarginDependenciesCommand.CanExecute(), Is.True);
		}

		[Test]
        public void ShouldDisableCommands_When_RebuildGrid_With_IsPublisherFalse()
        {
            var date = new DateTime(2023, 1, 1);

            var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
            {
                DailyPriceRows = [], Bands = []
            };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

            var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>([]);

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithRefreshPriceRowsResult(refreshResult)
                                                                                    .Build();

            // ACT
            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
                                                                false,
                                                                false,
                                                                date,
                                                                null,
                                                                null);

            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsPublisher, Is.False);
            Assert.That(testObjects.ViewModel.IsPublisherEditor, Is.False);

			Assert.That(testObjects.ViewModel.AddRowsCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.PastePricesCommand.CanExecute(null), Is.False);
            Assert.That(testObjects.ViewModel.SetMarginParentCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.SetMarginChildrenCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.ClearMarginDependenciesCommand.CanExecute(), Is.False);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        #endregion

        #region Publisher Editor changed - Popup

        [Test]
        public void ShouldShowPopup_When_RebuildGrid_With_IsPublisherChangedToFalse()
        {
            var date = new DateTime(2023, 1, 1);

            var dailyPriceGridRefreshArgs = new DailyPriceGridRefreshArgs
            {
                DailyPriceRows = [],
                Bands = []
            };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

            var refreshResult = new ReadOnlyObservableCollection<DailyPriceRowViewModel>([]);

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithIsPublisher(true)
                                                                                    .WithIsPublisherEditor(true)
                                                                                    .WithDailyPriceGridRefreshArgs(dailyPriceGridRefreshArgs)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithRefreshPriceRowsResult(refreshResult)
                                                                                    .Build();

            // ACT
            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Rebuild,
                                                                false,
                                                                false,
                                                                date,
                                                                null,
                                                                null);

            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        #endregion

        #region Update Grid

        [Test]
        public void ShouldUpdatePricesAndPremiums_When_DataRefresh_With_Update()
        {
            var date = new DateTime(2023, 1, 1);

            var curve = new ManualCurveDefinitionBuilder<DailyTenor>().Build();
            var premium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var priceRows = new ObservableCollection<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>()),
                new(Mock.Of<IDisposable>())
            };

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
                                                                 .Build();

            var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(new MonthlyTenor(2023, 1), true)
                                };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithViewModelDailyPriceRows(priceRows)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .WithEfpMonthItems(efpMonthItems)
                                                                                    .Build();

            // ACT
            var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Update,
                                                                true,
                                                                true,
                                                                date,
                                                                curve,
                                                                premium);

            testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

            // ASSERT
            Mock.Get(testObjects.DailyPriceCurveUpdateService)
                .Verify(p => p.UpdateDailyPrices(It.Is<IList<DailyPriceRowViewModel>>(r => r.Count == 2), 
                                                 curve, 
                                                 efpMonthItems, 
                                                 false));

            Mock.Get(testObjects.TenorMarginsUpdateService)
                .Verify(p => p.UpdateTenorMargins(It.Is<IList<DailyPriceRowViewModel>>(r => r.Count == 2),
                                                  premium, 
                                                  true));

            Mock.Get(testObjects.DataSourceService)
                .Verify(d => d.RemoveExcessRows());
        }

		#endregion

		[Test]
		public void ShouldShowDialog_When_DataRefresh_With_InvalidPricesException()
		{
			var date = new DateTime(2023, 1, 1);

			var curve = new ManualCurveDefinitionBuilder<DailyTenor>().Build();
			var premium = new PublisherTenorPremiumTestObjectBuilder().Build();

			var priceRows = new ObservableCollection<DailyPriceRowViewModel>
			{
				new(Mock.Of<IDisposable>()),
				new(Mock.Of<IDisposable>())
			};

			var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve))
																 .Build();

			var livePriceStreams = new List<ILivePriceStreamService> { stream1.Object };

			var efpMonthItems = new List<EfpMonthItem>();

			var exception = new Exception("error");

			var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
																					.WithViewModelDailyPriceRows(priceRows)
																					.WithLivePriceStreamServices(livePriceStreams)
																					.WithEfpMonthItems(efpMonthItems)
																					.WithUpdateDailyPricesException(exception)
																					.Build();

			// ACT
			var dataRefreshArgs = new DailyPriceDataRefreshArgs(DailyPriceDataRefreshAction.Update,
																true,
																true,
																date,
																curve,
																premium);

			testObjects.DailyPriceDataRefresh.OnNext(dataRefreshArgs);

			// ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
				.Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
		}

		[Test]
        public void ShouldSetIsBusyFalse_On_DailyPriceGridError()
        {
            var stream = new MockLivePriceStreamServiceBuilder().Build();

            var livePriceStreams = new List<ILivePriceStreamService> { stream.Object };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                    .WithLivePriceStreamServices(livePriceStreams)
                                                                                    .Build();

            // ACT
            testObjects.DailyPriceDataRefresh.OnError(new ApplicationException("error"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldSetIsSelectedOnSelectedRow()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithPriceIsSelected(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new[] { row1, row2 };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.SelectedRow = priceRows[1];

            // ASSERT
            Assert.That(row1.ManualPriceCell.IsSelected, Is.False);
            Assert.That(row2.ManualPriceCell.IsSelected, Is.True);
        }

        [Test]
        public void ShouldClearIsSelected_When_SelectedRowIsNull()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithPriceIsSelected(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new[] { row1, row2 };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.SelectedRow = null;

            // ASSERT
            Assert.That(priceRows[0].ManualPriceCell.IsSelected, Is.False);
        }

        [Test]
        public void ShouldAddRows_And_RefreshSubscribeUpdates_On_AddRowsCommand()
        {
            var date1 = new DateTime(2023, 3, 1);
            var date2 = new DateTime(2023, 3, 2);

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithRowTenorType(RowTenorType.Daily)
                                                           .WithDailyTenor(new DailyTenor(date1))
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithRowTenorType(RowTenorType.Daily)
                                                           .WithDailyTenor(new DailyTenor(date2))
                                                           .Build();

            var row3Extended = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(false)
                                                                   .WithIsExtended(true)
                                                                   .WithIsNew(true)
                                                                   .Build();

            var row4Extended = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                                   .WithIsExtended(true)
                                                                   .WithIsNew(true)
                                                                   .Build();

            var priceRows = new []
                            {
                                row1, row2
                            };

            var businessDayRows = new List<DailyPriceRowViewModel> { row1, row2 };

            var extendedRows = new List<DailyPriceRowViewModel>
            {
                row3Extended, row4Extended
            };

            var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
            var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            var bandHeaders = new ObservableCollection<BandHeader>
                              {
                                  manualCurveBandHeader,
                                  tenorPremiumsBandHeader
                              };

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(new MonthlyTenor(2023, 1), true)
                                };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                    .WithViewModelBandHeaders(bandHeaders)
                                                                                    .WithDayOfWeekCalculatorResult(2)
                                                                                    .WithExtendedDailyPriceRows(extendedRows)
                                                                                    .WithEfpMonthItems(efpMonthItems)
                                                                                    .WithDataSourceItems(businessDayRows)
                                                                                    .WithIsPublisher(true)
                                                                                    .WithIsPublisherEditor(true)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.AddRowsCommand.Execute();

            // ASSERT
            Assert.That(businessDayRows.All(r => r.SubscribeManualCurveUpdates), Is.True);

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.UnsubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader));

            Assert.That(businessDayRows.All(r => r.SubscribeTenorPremiumUpdates), Is.True);

			Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.UnsubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader));

            Mock.Get(testObjects.DatOfWeekCalculator)
                .Verify(c => c.GetDaysToNextDayOfWeek(date2, DayOfWeek.Friday));

            Mock.Get(testObjects.GridBuilder)
                .Verify(b => b.GetExtendedDailyPriceRows(It.IsAny<IList<DailyPriceRowViewModel>>(), 
                                                         efpMonthItems, 
                                                         2));

            Mock.Get(testObjects.DataSource)
                .Verify(d => d.AddItems(extendedRows));

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader));

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader));
		}

        [Test]
        public void ShouldSetSelectedRow_And_ExpandTreeNodes_On_AddRowsCommand()
        {
            var date = new DateTime(2023, 3, 1);

            var row = new DailyPriceRowTestObjectBuilder().WithRowTenorType(RowTenorType.Daily)
                                                          .WithIsBusinessDay(true)
                                                          .WithDailyTenor(new DailyTenor(date))
                                                          .WithIsBusinessDay(true)
                                                          .Build();

            var priceRows = new[] { row };

            var lastRow = new DailyPriceRowTestObjectBuilder().WithIsNew(true)
                                                              .WithIsExtended(true)
                                                              .WithIsBusinessDay(true)
                                                              .Build();

            var extendedRows = new List<DailyPriceRowViewModel>
            {
                new DailyPriceRowTestObjectBuilder().WithIsNew(true)
                                                    .WithIsExtended(true)
                                                    .WithIsBusinessDay(true)
                                                    .Build(),
                lastRow
            };

            var nodeKeys = new List<string> { "node" };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                    .WithDayOfWeekCalculatorResult(5)
                                                                                    .WithExtendedDailyPriceRows(extendedRows)
                                                                                    .WithNodeExpansionKeys(nodeKeys)
                                                                                    .WithIsPublisher(true)
                                                                                    .WithIsPublisherEditor(true)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.AddRowsCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedRow, Is.SameAs(lastRow));

            Mock.Get(testObjects.TenorTreeNodeExpansionService)
                .Verify(t => t.GetTenorNodeExpansionKeys(It.Is<ITenorNode[]>(n => n.Length == 3),
                                                         testObjects.ViewModel.SelectedRow));

            Assert.That(testObjects.ViewModel.NodeExpansionKeys.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldPastePrices_On_PasteCommand_With_IsPublisherEditor()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var rows = new[] { row1, row2 };

            var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
            var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            var bandHeaders = new ObservableCollection<BandHeader>
                              {
                                  manualCurveBandHeader,
                                  tenorPremiumsBandHeader
                              };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
                                                                                    .WithDataSourceItems(rows)
                                                                                    .WithViewModelBandHeaders(bandHeaders)
                                                                                    .WithIsPublisher(true)
                                                                                    .WithIsPublisherEditor(true)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.PastePricesCommand.Execute(row2);

            // ASSERT
            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.UnsubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader));

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader));

			Mock.Get(testObjects.ClipboardService)
                .Verify(c => c.TryUpdatePricesFromClipboard(row2));

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeManualOverrideUpdates(manualCurveBandHeader.ManualCurveBandHeader));

            Mock.Get(testObjects.BandSubscribeUpdatesService)
                .Verify(b => b.SubscribeTenorPremiumsUpdates(tenorPremiumsBandHeader.TenorPremiumsBandHeader));
        }

        [Test]
        public void ShouldSetLastRowSelected_When_PastePrices_With_AddedRows_With_IsPublisherEditor()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var rows = new[] { row1, row2 };

            var manualCurveBandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));
            var tenorPremiumsBandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            var bandHeaders = new ObservableCollection<BandHeader>
                              {
                                  manualCurveBandHeader,
                                  tenorPremiumsBandHeader
                              };

            var lastRow = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                              .WithIsExtended(true)
                                                              .Build();

            var addedRows = new ObservableCollection<DailyPriceRowViewModel>
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                                    .WithIsExtended(true)
                                                                    .Build(),
                                lastRow
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
                                                                                    .WithDataSourceItems(rows)
                                                                                    .WithViewModelBandHeaders(bandHeaders)
                                                                                    .WithAddedClipboardRows(addedRows)
                                                                                    .WithIsPublisher(true)
                                                                                    .WithIsPublisherEditor(true)
                                                                                    .WithTryUpdatePricesFromClipboardResult(true)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.PastePricesCommand.Execute(row2);

            // ASSERT
            Assert.AreSame(lastRow, testObjects.ViewModel.SelectedRow);
        }

        [Test]
        public void ShouldNotPastePrices_When_PastePrices_With_IsPublisherEditorFalse()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var rows = new[] { row1, row2 };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
                                                                                    .WithIsPublisherEditor(false)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.PastePricesCommand.Execute(row2);

            // ASSERT
            Mock.Get(testObjects.ClipboardService)
                .Verify(c => c.TryUpdatePricesFromClipboard(It.IsAny<DailyPriceRowViewModel>()),Times.Never());
        }

        [Test]
        public void ShouldNotPastePrices_On_PasteCommand_WithNoneSelected()
        {
            var rows = new[]
                       {
                           new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build()
                       };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
                                                                                    .WithIsPublisher(true)
                                                                                    .WithIsPublisher(true)
                                                                                    .WithIsPublisherEditor(false)
																					.Build();
            // ACT
            testObjects.ViewModel.PastePricesCommand.Execute(null);

            // ASSERT
            Mock.Get(testObjects.ClipboardService)
                .Verify(c => c.TryUpdatePricesFromClipboard(It.IsAny<DailyPriceRowViewModel>()), Times.Never);
        }

        [Test]
        public void ShouldShowMessageDialog_On_PastePricesFailed()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var rows = new[] { row1, row2 };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
                                                                                    .WithTryUpdatePricesFromClipboardResult(false)
                                                                                    .WithIsPublisher(true)
                                                                                    .WithIsPublisherEditor(true)
																					.Build();
            // ACT
            testObjects.ViewModel.PastePricesCommand.Execute(row2);

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(m => m.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.ShowSendFeedback == false)));
        }

        [Test]
        public void ShouldSetSelectedRows()
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var rows = new[]
                       {
                           priceRow,
                           new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build()
                       };


            var selected = new[] {priceRow};

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.SetSelectedRowCommand.Execute(selected);

            // ASSERT
            Mock.Get(testObjects.SetSelectedRowsService)
                .Verify(s => s.SetSelectedRows(It.Is<IList<DailyPriceRowViewModel>>(p => p.Count == 2), selected));
        }

        [Test]
        public void ShouldSetMarginParent()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithCanApplyMargins(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithCanApplyMargins(true)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .Build();

            var priceRows = new List<DailyPriceRowViewModel>
                            {
                                row1, row2, row3
                            };

            var expectedSequence = new[] { row1.TenorPremium, row2.TenorPremium };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.SetMarginParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumCellGroupingService)
                .Verify(c => c.UpdateParent(It.Is<List<TenorPremiumViewModel>>(tp => tp.SequenceEqual(expectedSequence))));
        }

        [Test]
        public void ShouldSetChildren_And_UpdateMargins_When_SetMarginChildren()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithCanApplyMargins(true)
                                                           .WithIsMarginParent(true)
                                                           .WithBidMarginValue(-0.1m)
                                                           .WithAskMarginValue(0.1m)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithCanApplyMargins(true)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .Build();

            var priceRows = new []
                            {
                                row1, row2, row3
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
																					.Build();

            var expectedTenorPremiums = new[] { row1.TenorPremium, row2.TenorPremium };

            // ACT
            testObjects.ViewModel.SetMarginChildrenCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumCellGroupingService)
                .Verify(c => c.UpdateChildren(It.Is<List<TenorPremiumViewModel>>(tp => tp.SequenceEqual(expectedTenorPremiums))));

            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateBidAskMarginsFromParent(-0.1m, 0.1m, It.Is<IEnumerable<DailyPriceRowViewModel>>(p => p.SequenceEqual(priceRows))));
        }

        [Test]
        public void ShouldSetChildren_And_UpdateMargins_When_SetMarginChildrenBelowParent()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithCanApplyMargins(true)
                                                           .WithIsMarginParent(true)
                                                           .WithBidMarginValue(-0.1m)
                                                           .WithAskMarginValue(0.1m)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithCanApplyMargins(true)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .Build();

            var priceRows = new List<DailyPriceRowViewModel>
                            {
                                row1, row2, row3
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
																					.Build();

            var expectedTenorPremiums = new[] { row1.TenorPremium, row2.TenorPremium };

            // ACT
            testObjects.ViewModel.SetMarginChildrenBelowParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumCellGroupingService)
                .Verify(c => c.UpdateChildrenBelowParent(It.Is<List<TenorPremiumViewModel>>(tp => tp.SequenceEqual(expectedTenorPremiums))));

            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateBidAskMarginsFromParent(-0.1m, 0.1m, It.Is<IEnumerable<DailyPriceRowViewModel>>(p => p.SequenceEqual(priceRows))));
        }

        [Test]
        public void ShouldClearMarginDependencies()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithCanApplyMargins(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithCanApplyMargins(true)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .Build();

            var priceRows = new List<DailyPriceRowViewModel>
                            {
                                row1, row2, row3
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
																					.Build();

            var expectedTenorPremiums = new[] { row1.TenorPremium, row2.TenorPremium };

            // ACT
            testObjects.ViewModel.ClearMarginDependenciesCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumCellGroupingService)
                .Verify(c => c.ClearDependencies(It.Is<List<TenorPremiumViewModel>>(tp => tp.SequenceEqual(expectedTenorPremiums))));
        }

        [Test]
        public void ShouldDisableSetMarginChildrenBelowParent_When_No_Parent()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsMarginParent(false).Build(),
                                new DailyPriceRowTestObjectBuilder().WithIsMarginParent(false).Build()
                            };

            // ACT
            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                    .WithIsPublisher(true)
                                                                                    .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.SetMarginChildrenBelowParentCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableSetMarginChildrenBelowParent_When_ParentExists_With_IsPublisherEditor()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsMarginParent(true).Build(),
                                new DailyPriceRowTestObjectBuilder().WithIsMarginParent(false).Build()
                            };

            // ACT
            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                    .WithIsPublisher(true)
                                                                                    .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.SetMarginChildrenBelowParentCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableEfpCommands_When_IsPublisherEditor()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build(),
                                new DailyPriceRowTestObjectBuilder().Build()
                            };

            // ACT
            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithIsPublisherEditor(true)
                                                                                    .WithDataSourceItems(priceRows)
                                                                                    .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.SetEfpParentCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.SetEfpChildrenCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.ClearEfpDependenciesCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableEfpCommands_When_IsPublisherEditorFalse()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build(),
                                new DailyPriceRowTestObjectBuilder().Build()
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithIsPublisherEditor(true)
                                                                                    .WithDataSourceItems(priceRows)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.IsPublisherEditor = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.SetEfpParentCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.SetEfpChildrenCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.ClearEfpDependenciesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldSetEfpParent_On_Command()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build(),
                                new DailyPriceRowTestObjectBuilder().Build()
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
																					.Build();

            // ACT
            testObjects.ViewModel.SetEfpParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.EfpCellGroupingService)
                .Verify(s => s.UpdateParent(It.Is<List<EfpNarrativeViewModel>>(cells => cells.Count == 1)));
        }

        [Test]
        public void ShouldSetEfpChildren_And_UpdateValues_On_Command()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build()
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
																					.Build();

            // ACT
            testObjects.ViewModel.SetEfpChildrenCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.EfpCellGroupingService)
                .Verify(s => s.UpdateChildren(It.Is<List<EfpNarrativeViewModel>>(cells => cells.Count == 1)));
        }

        [Test]
        public void ShouldSetEfpValuesFromParent_When_SetEfpChildren_With_Parent()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithEfpIsParent(true).Build();
            var selected = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithEfpIsSelected(true).Build();
            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithEfpIsSelected(true).Build();

            var rows = new []
                       {
                           parent, selected, row
                       };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
																					.Build();

            // ACT
            testObjects.ViewModel.SetEfpChildrenCommand.Execute();

            // ASSERT1
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(e => e.UpdateEfpChildrenFromParent(parent.EfpNarrative, rows));
        }

        [Test]
        public void ShouldSetEfpChildrenAndValues_When_SetEfpChildrenBelowParent_With_Parent()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithEfpIsParent(true).Build();
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var rows = new []
                       {
                           parent, row1, row2
                       };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
																					.Build();

            // ACT
            testObjects.ViewModel.SetEfpChildrenBelowParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.EfpCellGroupingService)
                .Verify(s => s.UpdateChildrenBelowParent(parent.EfpNarrative, It.Is<List<EfpNarrativeViewModel>>(efp => efp.Count == 3)));

            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(e => e.UpdateEfpChildrenFromParent(parent.EfpNarrative, rows));
        }

        [Test]
        public void ShouldNotSetEfpChildrenAndValues_When_SetEfpChildrenBelowParent_With_MissingParent()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var selected1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithEfpIsSelected(true).Build();
            var selected2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithEfpIsSelected(true).Build();

            var rows = new []
                       {
                           row, selected1, selected2
                       };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
																					.Build();

            // ACT
            testObjects.ViewModel.SetEfpChildrenBelowParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.EfpCellGroupingService)
                .Verify(s => s.UpdateChildrenBelowParent(It.IsAny<EfpNarrativeViewModel>(), It.IsAny<List<EfpNarrativeViewModel>>()),
                        Times.Never);

            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(e => e.UpdateEfpChildrenFromParent(It.IsAny<EfpNarrativeViewModel>(), rows), 
                        Times.Never);
        }

        [Test]
        public void ShouldClearEfpDependencies_On_Command()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build(),
                                new DailyPriceRowTestObjectBuilder().Build()
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
																					.Build();

            // ASSERT
            testObjects.ViewModel.ClearEfpDependenciesCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.EfpCellGroupingService)
                .Verify(s => s.ClearDependencies(It.Is<List<EfpNarrativeViewModel>>(cells => cells.Count == 1)));
        }

        [Test]
        public void ShouldDisableSetEfpChildrenBelowParentCommand_When_NoEfpParent()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build(),
                                new DailyPriceRowTestObjectBuilder().Build()
                            };

            // ASSERT
            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
																				    .WithIsPublisherEditor(true)
                                                                                    .Build();

            // ACT
            Assert.That(testObjects.ViewModel.SetEfpChildrenBelowParentCommand.CanExecute(), Is.False);
        }

        [Test] 
        public void ShouldEnableSetEfpChildrenBelowParentCommand_When_EfpParentExists()
        {
            var priceRows = new[]
                            {
                                new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithEfpIsParent(true).Build(),
                                new DailyPriceRowTestObjectBuilder().Build()
                            };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(priceRows)
																					.WithIsPublisherEditor(true)
                                                                                    .Build();

            // ASSERT
            testObjects.ViewModel.SetEfpParentCommand.Execute();

            // ACT
            Assert.That(testObjects.ViewModel.SetEfpChildrenBelowParentCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableClearPremiums_When_SelectedRow_IsExtended()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsExtended(true).Build();

            var rows = new [] { row1, row2 };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
                                                                                    .WithIsPublisher(true)
																					.Build();

            // ACT
            testObjects.ViewModel.SelectedRow = row2;

            // ASSERT
            Assert.That(testObjects.ViewModel.ClearPremiumsCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldNotEnableClearPremiums_When_SelectedRow_IsNotExtended()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsExtended(true).Build();

            var rows = new[] { row1, row2 };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
                                                                                    .WithIsPublisher(true)
																					.Build();

            // ACT
            testObjects.ViewModel.SelectedRow = row1;

            // ASSERT
            Assert.That(testObjects.ViewModel.ClearPremiumsCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldClearPremiums_On_Command()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsExtended(true).Build();

            var rows = new[] { row1, row2 };

            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().WithDataSourceItems(rows)
																					.Build();

            testObjects.ViewModel.SelectedRow = row2;

            // ACT
            testObjects.ViewModel.ClearPremiumsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ClearPremiumsService)
                .Verify(c => c.ClearPremiums(It.Is<List<DailyPriceRowViewModel>>(r => r.SequenceEqual(rows)), row2));
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.Dispatcher)
                .Verify(d => d.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new DailyPricingViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.Dispatcher)
                .Verify(d => d.Dispose(), Times.Once);
        }
    }
}
