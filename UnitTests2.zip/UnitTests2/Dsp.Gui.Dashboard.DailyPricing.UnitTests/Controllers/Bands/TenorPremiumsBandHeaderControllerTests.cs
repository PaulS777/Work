﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Controllers.Bands;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Moq;
using NUnit.Framework;
using System.Reactive.Subjects;
using System.Reactive;
using System.Reactive.Concurrency;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.Dashboard.DailyPricing.Models;
using Dsp.Gui.Dashboard.DailyPricing.Services.ServerUpdate;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.DataSource;
using DynamicData;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers.Bands
{
    internal interface ITenorPremiumsBandHeaderControllerTestObjects
    {
        ITenorPremiumsChangedService TenorPremiumsChangedService { get; }
        ITenorPremiumsValidationService TenorPremiumsValidationService { get; }
        ILinkedPremiumsTextUpdateService LinkedPremiumsTextUpdateService { get; }
        ITenorPremiumsSpinUpdateService TenorPremiumsSpinUpdateService { get; }
        ITenorPremiumsUndoChangesService TenorPremiumsUndoChangesService { get; }
        IDailyPriceRowDataSourceService DataSourceService { get; }
        IObservable<IChangeSet<DailyPriceRowViewModel>> DataSourceConnect { get; }
        IPublisherTenorPremiumBuilder PublisherTenorPremiumBuilder { get; set; }
        IPublisherTenorPremiumUpdateService PublisherTenorPremiumUpdateService { get; set; }
        IPopupNotificationService PopupNotificationService { get; set; }
        IErrorMessageDialogService ErrorMessageDialogService { get; set; }
        ISubject<Unit> TenorPremiumUpdateResponse { get; }
        TestScheduler TestScheduler { get; }
        TenorPremiumsBandHeader ViewModel { get; }
        TenorPremiumsBandHeaderController Controller { get; }
    }

    [TestFixture]
    public class TenorPremiumsBandHeaderControllerTests
    {
        private class TenorPremiumsBandHeaderControllerTestObjectBuilder
        {
            private List<DailyPriceRowViewModel> _dataSourceItems;
            private bool _subscribeUpdates;
            private bool _hasChanges;
            private bool _hasErrors;
            private bool _canUpdatePremiums;
            private bool _isBusy;
            private PublisherTenorPremium _publisherTenorPremium;
            private PublisherTenorPremium _publisherTenorPremiumBuilderResult;

            public TenorPremiumsBandHeaderControllerTestObjectBuilder WithDataSourceItems(List<DailyPriceRowViewModel> values)
            {
                _dataSourceItems = values;
                return this;
            }

            public TenorPremiumsBandHeaderControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public TenorPremiumsBandHeaderControllerTestObjectBuilder WithHasChanges(bool value)
            {
                _hasChanges = value;
                return this;
            }

            public TenorPremiumsBandHeaderControllerTestObjectBuilder WithHasErrors(bool value)
            {
                _hasErrors = value;
                return this;
            }

            public TenorPremiumsBandHeaderControllerTestObjectBuilder WithCanUpdatePremiums(bool value)
            {
                _canUpdatePremiums = value;
                return this;
            }

            public TenorPremiumsBandHeaderControllerTestObjectBuilder WithIsBusy(bool value)
            {
                _isBusy = value;
                return this;
            }

            public TenorPremiumsBandHeaderControllerTestObjectBuilder WithPublisherTenorPremiumBuilderResult(PublisherTenorPremium value)
            {
                _publisherTenorPremiumBuilderResult = value;
                return this;
            }

            public TenorPremiumsBandHeaderControllerTestObjectBuilder WithPublisherTenorPremium(PublisherTenorPremium value)
            {
                _publisherTenorPremium = value;
                return this;
            }

            public ITenorPremiumsBandHeaderControllerTestObjects Build()
            {
                var testObjects = new Mock<ITenorPremiumsBandHeaderControllerTestObjects>();

                var changedService = new Mock<ITenorPremiumsChangedService>();

                testObjects.SetupGet(o => o.TenorPremiumsChangedService)
                           .Returns(changedService.Object);

                var validationService = new Mock<ITenorPremiumsValidationService>();

                testObjects.SetupGet(o => o.TenorPremiumsValidationService)
                           .Returns(validationService.Object);

                var linkedPremiumsTextUpdateService = new Mock<ILinkedPremiumsTextUpdateService>();

                testObjects.SetupGet(o => o.LinkedPremiumsTextUpdateService)
                           .Returns(linkedPremiumsTextUpdateService.Object);

                var tenorPremiumsSpinUpdateService = new Mock<ITenorPremiumsSpinUpdateService>();

                testObjects.SetupGet(o => o.TenorPremiumsSpinUpdateService)
                           .Returns(tenorPremiumsSpinUpdateService.Object);

                var undoChangesService = new Mock<ITenorPremiumsUndoChangesService>();

                testObjects.SetupGet(o => o.TenorPremiumsUndoChangesService)
                           .Returns(undoChangesService.Object);

                var premiumBuilder = new Mock<IPublisherTenorPremiumBuilder>();

                premiumBuilder.Setup(b => b.CreatePublisherTenorPremium(It.IsAny<PublisherTenorPremium>(),
                                                                        It.IsAny<IList<DailyPriceRowViewModel>>()))
                              .Returns(_publisherTenorPremiumBuilderResult);

                testObjects.SetupGet(o => o.PublisherTenorPremiumBuilder)
                           .Returns(premiumBuilder.Object);

                var updateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.TenorPremiumUpdateResponse)
                           .Returns(updateResponse);

                var updateService = new Mock<IPublisherTenorPremiumUpdateService>();

                updateService.Setup(u => u.Update(It.IsAny<PublisherTenorPremium>(), 
                                                  It.IsAny<IScheduler>()))
                             .Returns(updateResponse);

                updateService.Setup(u => u.Add(It.IsAny<IList<PublisherTenorPremium>>(),
                                               It.IsAny<IScheduler>()))
                             .Returns(updateResponse);

                testObjects.SetupGet(o => o.PublisherTenorPremiumUpdateService)
                           .Returns(updateService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);
                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);

                var connect = new Subject<IChangeSet<DailyPriceRowViewModel>>();

                testObjects.SetupGet(o => o.DataSourceConnect)
                           .Returns(connect);

                var dataSourceService = new Mock<IDailyPriceRowDataSourceService>();

                dataSourceService.Setup(d => d.ConnectBusinessDays())
                                 .Returns(connect);

                dataSourceService.Setup(d => d.BusinessDayRows())
                                 .Returns(_dataSourceItems);

                testObjects.SetupGet(o => o.DataSourceService)
                           .Returns(dataSourceService.Object);

                var controller = new TenorPremiumsBandHeaderController(changedService.Object,
                                                                       validationService.Object,
                                                                       linkedPremiumsTextUpdateService.Object,
                                                                       tenorPremiumsSpinUpdateService.Object,
                                                                       schedulerProvider.Object,
                                                                       TestMocks.GetLoggerFactory().Object)
                                 {
                                     UndoChangesService = undoChangesService.Object,
                                     PublisherTenorPremiumBuilder = premiumBuilder.Object,
                                     PublisherTenorPremiumUpdateService = updateService.Object,
                                     PopupNotificationService = popupNotificationService.Object,
                                     ErrorMessageDialogService = errorMessageDialogService.Object,
                                     DataSourceService = dataSourceService.Object
                                 };
                
                controller.ViewModel.SetDetails(new BandInfoDetails
                                                {
                                                    PublisherTenorPremium = _publisherTenorPremium
                                                });

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;
                controller.ViewModel.HasChanges = _hasChanges;
                controller.ViewModel.HasErrors = _hasErrors;
                controller.ViewModel.CanUpdatePremiums = _canUpdatePremiums;
                controller.ViewModel.IsBusy = _isBusy;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachBandInfo()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().Build();

            Mock.Get(testObjects.TenorPremiumsChangedService)
                .Verify(s => s.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.TenorPremiumsValidationService)
                .Verify(s => s.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.TenorPremiumsSpinUpdateService)
                .Verify(s => s.AttachBandInfo(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSubscribeUpdates_On_SubscribeUpdatesTrue()
        {
            var priceRows = new List<DailyPriceRowViewModel>
                            {
                                new DailyPriceRowTestObjectBuilder().Build()
                            };

            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsChangedService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.TenorPremiumsValidationService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.LinkedPremiumsTextUpdateService)
                .Verify(s => s.SubscribeUpdates(It.Is<IReadOnlyList<DailyPriceRowViewModel>>(r => r.SequenceEqual(priceRows))));

            Mock.Get(testObjects.TenorPremiumsSpinUpdateService)
                .Verify(s => s.SubscribeUpdates(It.Is<IList<DailyPriceRowViewModel>>(r => r.SequenceEqual(priceRows))));
        }

        [Test]
        public void ShouldUnsubscribeUpdates_On_SubscribeUpdatesFalse()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsChangedService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.TenorPremiumsValidationService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.LinkedPremiumsTextUpdateService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.TenorPremiumsSpinUpdateService)
                .Verify(s => s.UnsubscribeUpdates());
        }

        [Test]
        public void ShouldUndoChanges_On_UndoChangesCommand()
        {
            var items = new List<DailyPriceRowViewModel> { new(Mock.Of<IDisposable>()) };

            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithDataSourceItems(items)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.UndoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsUndoChangesService)
                .Verify(s => s.UndoChanges(items));
        }

        [Test]
        public void ShouldSuspendSubscriptionUpdates_When_UndoChanges()
        {
            var priceRows = new List<DailyPriceRowViewModel> { new(Mock.Of<IDisposable>()) };

            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                      .WithSubscribeUpdates(true)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.UndoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsChangedService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.TenorPremiumsValidationService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.LinkedPremiumsTextUpdateService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.TenorPremiumsSpinUpdateService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.TenorPremiumsChangedService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.TenorPremiumsValidationService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.LinkedPremiumsTextUpdateService)
                .Verify(s => s.SubscribeUpdates(It.Is<IReadOnlyList<DailyPriceRowViewModel>>(r => r.SequenceEqual(priceRows))));

            Mock.Get(testObjects.TenorPremiumsSpinUpdateService)
                .Verify(s => s.SubscribeUpdates(It.Is<IList<DailyPriceRowViewModel>>(r => r.SequenceEqual(priceRows))));
        }

        [Test]
        public void ShouldSetCanUpdateTrue_When_HasChanges_And_HasErrorsFalse()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithHasErrors(false)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.HasChanges = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdatePremiums, Is.True);
        }

        [Test]
        public void ShouldSetCanUpdateFalse_When_HasChangesFalse()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithHasErrors(false)
                                                                                      .WithHasChanges(true)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.HasChanges = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdatePremiums, Is.False);
        }

        [Test]
        public void ShouldSetCanUpdateFalse_When_HasErrorsTrue()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithHasErrors(false)
                                                                                      .WithHasChanges(true)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.HasErrors = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdatePremiums, Is.False);
        }

        [Test]
        public void ShouldSetCanUndoChangesTrue_When_HasChanges_With_IsBusyFalse()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithHasChanges(false)
                                                                                      .WithIsBusy(false)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.HasChanges = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.True);
        }

        [Test]
        public void ShouldSetCanUndoChangesFalse_When_IsBusyTrue()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithHasChanges(true)
                                                                                      .WithIsBusy(false)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.IsBusy = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.False);
        }

        [Test]
        public void ShouldSetCanUndoChangesFalse_When_HasChangesFalse()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithHasChanges(true)
                                                                                      .WithIsBusy(false)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.HasChanges = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.False);
        }

        [Test]
        public void ShouldDisableUpdatePremiums_And_SetIsBusyTrueOnMargins_On_UpdatePremiumCommand()
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new List<DailyPriceRowViewModel> { priceRow };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(10).Build();

            var updatedPremium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var testObjects = 
                new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                        .WithPublisherTenorPremium(premium)
                                                                        .WithPublisherTenorPremiumBuilderResult(updatedPremium)
                                                                        .WithCanUpdatePremiums(true)
                                                                        .Build();
            // ACT
            testObjects.ViewModel.UpdatePremiumsCommand.Execute();
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdatePremiums, Is.False);
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(priceRow.TenorPremium.BidMargin.IsBusy, Is.True);
            Assert.That(priceRow.TenorPremium.AskMargin.IsBusy, Is.True);
        }

        [Test]
        public void ShouldUpdateTenorPremiums_On_UpdatePremiumCommand_WithIdNotEqualsZero()
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new List<DailyPriceRowViewModel> { priceRow };

            var premium = new PublisherTenorPremiumTestObjectBuilder().Build();
            var updatedPremium = new PublisherTenorPremiumTestObjectBuilder().WithId(10).Build();

            var testObjects =
                new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                        .WithPublisherTenorPremium(premium)
                                                                        .WithPublisherTenorPremiumBuilderResult(updatedPremium)
                                                                        .Build();
            // ACT
            testObjects.ViewModel.UpdatePremiumsCommand.Execute();
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumBuilder)
                .Verify(b => b.CreatePublisherTenorPremium(premium, priceRows));

            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(u => u.Update(updatedPremium, It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldAddTenorPremium_On_UpdatePremiumCommand_WithIdEqualsZero()
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new List<DailyPriceRowViewModel> { priceRow };

            var premium = new PublisherTenorPremiumTestObjectBuilder().Build();
            var updatedPremium = new PublisherTenorPremiumTestObjectBuilder().WithId(0).Build();

            var testObjects =
                new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                        .WithPublisherTenorPremium(premium)
                                                                        .WithPublisherTenorPremiumBuilderResult(updatedPremium)
                                                                        .Build();
            // ACT
            testObjects.ViewModel.UpdatePremiumsCommand.Execute();
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumBuilder)
                .Verify(b => b.CreatePublisherTenorPremium(premium, priceRows));

            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(u => u.Add(It.Is<IList<PublisherTenorPremium>>(p => p.Count == 1), It.IsAny<IScheduler>()));
        }

        [TestCase(0)]
        [TestCase(10)]
        public void ShouldSetIsBusyFalseAndShowPopup_On_AddOrUpdatePremiumsCompleted(int id)
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();
            var priceRows = new List<DailyPriceRowViewModel> { priceRow };
            var updatedPremium = new PublisherTenorPremiumTestObjectBuilder().WithId(id).Build();

            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                      .WithPublisherTenorPremiumBuilderResult(updatedPremium)
                                                                                      .Build();
    
            testObjects.ViewModel.UpdatePremiumsCommand.Execute();

            // ACT
            testObjects.TenorPremiumUpdateResponse.OnNext(Unit.Default);
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(priceRow.TenorPremium.BidMargin.IsBusy, Is.False);
            Assert.That(priceRow.TenorPremium.AskMargin.IsBusy, Is.False);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestCase(0)]
        [TestCase(10)]
        public void ShouldSetIsBusyFalseAndShowErrorDialog_On_AndOrUpdatePremiumsError(int id)
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();
            var priceRows = new List<DailyPriceRowViewModel> { priceRow };
            var updatedPremium = new PublisherTenorPremiumTestObjectBuilder().WithId(id).Build();

            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().WithDataSourceItems(priceRows)
                                                                                      .WithPublisherTenorPremiumBuilderResult(updatedPremium)
                                                                                      .Build();

            testObjects.ViewModel.UpdatePremiumsCommand.Execute();

            // ACT
            testObjects.TenorPremiumUpdateResponse.OnError(new Exception());
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(priceRow.TenorPremium.BidMargin.IsBusy, Is.False);
            Assert.That(priceRow.TenorPremium.AskMargin.IsBusy, Is.False);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsChangedService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.TenorPremiumsValidationService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.LinkedPremiumsTextUpdateService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.TenorPremiumsSpinUpdateService)
                .Verify(s => s.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_AlreadyDisposed()
        {
            var testObjects = new TenorPremiumsBandHeaderControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();
            Mock.Get(testObjects.TenorPremiumsChangedService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsChangedService)
                .Verify(s => s.Dispose(), Times.Never);
        }
    }
}
