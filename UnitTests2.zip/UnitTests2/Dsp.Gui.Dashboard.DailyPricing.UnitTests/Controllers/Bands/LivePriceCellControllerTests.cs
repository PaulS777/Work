﻿using Dsp.Gui.Dashboard.DailyPricing.Controllers;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers.Bands
{
    [TestFixture]
    public class LivePriceCellControllerTests
    {
        [Test]
        public void ShouldGetViewModel()
        {
            // ACT
            var controller = new LivePriceCellController();

            // ASSERT
            Assert.That(controller.ViewModel, Is.Not.Null);
        }
    }
}
