﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Dashboard.DailyPricing.Controllers.Bands;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Overrides;
using Dsp.Gui.Dashboard.DailyPricing.Services.DataSource;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using DynamicData;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers.Bands
{
    internal interface IManualOverridesBandControllerTestObjects
    {
        IDailyPriceRowDataSourceService DataSourceService { get; }
        IManualOverridesChangedService ManualOverridesChangedService { get; }
        IManualOverridesValidationService  ManualOverridesValidationService { get; }
        ICurveEditRegistrationService CurveEditRegistrationService { get; }
		IManualOverridesUndoChangesService ManualOverridesUndoChangesService { get; }
        IObservable<IChangeSet<DailyPriceRowViewModel>> DataSourceConnectBusinessDays { get; }
        IObservable<IChangeSet<DailyPriceRowViewModel>> DataSourceConnectWeeksAndBusinessDays { get; }
        ManualOverridesBand ViewModel { get; }
        ManualOverridesBandController Controller { get; }
    }

    [TestFixture]
    public class ManualOverridesBandControllerTests
    {
        private class ManualOverridesBandControllerTestObjectBuilder
        {
            private LinkedCurve _linkedCurve;
            private List<DailyPriceRowViewModel> _businessDayRows;
            private bool _subscribeUpdates;
            private bool _hasChanges;
            private bool _isBusy;

            public ManualOverridesBandControllerTestObjectBuilder WithLinkedCurve(LinkedCurve value)
            {
                _linkedCurve = value;
                return this;
            }

			public ManualOverridesBandControllerTestObjectBuilder WithBusinessDayRows(List<DailyPriceRowViewModel> values)
            {
                _businessDayRows = values;
                return this;
            }

            public ManualOverridesBandControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public ManualOverridesBandControllerTestObjectBuilder WithHasChanges(bool value)
            {
                _hasChanges = value;
                return this;
            }

            public ManualOverridesBandControllerTestObjectBuilder WithIsBusy(bool value)
            {
                _isBusy = value;
                return this;
            }

            public IManualOverridesBandControllerTestObjects Build()
            {
                var testObjects = new Mock<IManualOverridesBandControllerTestObjects>();

                var changedService = new Mock<IManualOverridesChangedService>();

                testObjects.SetupGet(o => o.ManualOverridesChangedService)
                           .Returns(changedService.Object);

                var validationService = new Mock<IManualOverridesValidationService>();

                testObjects.SetupGet(o => o.ManualOverridesValidationService)
                           .Returns(validationService.Object);

                var undoChangesService = new Mock<IManualOverridesUndoChangesService>();

                testObjects.SetupGet(o => o.ManualOverridesUndoChangesService)
                           .Returns(undoChangesService.Object);

                var connect = new Subject<IChangeSet<DailyPriceRowViewModel>>();

                testObjects.SetupGet(o => o.DataSourceConnectBusinessDays)
                           .Returns(connect);

                var connectWeeksAndBusinessDays = new Subject<IChangeSet<DailyPriceRowViewModel>>();

                testObjects.SetupGet(o => o.DataSourceConnectWeeksAndBusinessDays)
                           .Returns(connectWeeksAndBusinessDays);

                var dataSourceService = new Mock<IDailyPriceRowDataSourceService>();

                dataSourceService.Setup(d => d.ConnectBusinessDays())
                                 .Returns(connect);

                dataSourceService.Setup(d => d.ConnectWeeksAndBusinessDays())
                                 .Returns(connectWeeksAndBusinessDays);

                dataSourceService.Setup(d => d.BusinessDayRows())
                                 .Returns(_businessDayRows);

                testObjects.SetupGet(o => o.DataSourceService)
                           .Returns(dataSourceService.Object);

                var curveEditRegistrationService = new Mock<ICurveEditRegistrationService>();

                testObjects.SetupGet(o => o.CurveEditRegistrationService)
                           .Returns(curveEditRegistrationService.Object);

                var controller = new ManualOverridesBandController(changedService.Object,
                                                                   validationService.Object,
                                                                   curveEditRegistrationService.Object)
                                 {
                                     UndoChangesService = undoChangesService.Object,
                                     DataSourceService = dataSourceService.Object
                                 };

                controller.ViewModel.LinkedCurve = _linkedCurve;
                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;
                controller.ViewModel.HasChanges = _hasChanges;
                controller.ViewModel.IsBusy = _isBusy;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetViewModel()
        {
            // ACT
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel, Is.Not.Null);
        }

        [Test]
        public void ShouldAttachValidationService()
        {
            // ACT
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.AttachBandInfo(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSubscribeUpdates_On_SubscribeUpdatesTrue()
        {
            var linkedCurve = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnectWeeksAndBusinessDays));

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnectBusinessDays));

            Mock.Get(testObjects.CurveEditRegistrationService)
                .Verify(r => r.RegisterCurve(testObjects.ViewModel, 201));
        }

        [Test]
        public void ShouldUnsubscribeUpdates_On_SubscribeUpdatesFalse()
        {
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.UnsubscribeUpdates());
        }

        [Test]
        public void ShouldUndoChanges_On_UndoChangesCommand()
        {
            var rows = new List<DailyPriceRowViewModel> { new(Mock.Of<IDisposable>()) };

            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().WithBusinessDayRows(rows)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.UndoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.DataSourceService)
                .Verify(d => d.RemoveNewRows());

            Mock.Get(testObjects.ManualOverridesUndoChangesService)
                .Verify(s => s.UndoChanges(rows));
        }

        [Test]
        public void ShouldSuspendSubscriptionUpdates_When_UndoChanges()
        {
            var rows = new List<DailyPriceRowViewModel> { new(Mock.Of<IDisposable>()) };

            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().WithBusinessDayRows(rows)
                                                                                  .WithSubscribeUpdates(true)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.UndoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnectWeeksAndBusinessDays));

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnectBusinessDays));
        }

        [Test]
        public void ShouldSetCanUndoChangesTrue_When_HasChanges_With_IsBusyFalse()
        {
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().WithHasChanges(false)
                                                                                  .WithIsBusy(false)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.HasChanges = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.True);
        }

        [Test]
        public void ShouldSetCanUndoChangesFalse_When_IsBusyTrue()
        {
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().WithHasChanges(true)
                                                                                  .WithIsBusy(false)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.IsBusy = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.False);
        }

        [Test]
        public void ShouldSetCanUndoChangesFalse_When_HasChangesFalse()
        {
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().WithHasChanges(true)
                                                                                  .WithIsBusy(false)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.HasChanges = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.False);
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var linkedCurve = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var testObjects = new ManualOverridesBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.CurveEditRegistrationService)
                .Verify(r => r.UnRegisterCurve(201));
		}

        [Test]
        public void ShouldNotDisposeServices_When_AlreadyDisposed()
        {
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();
            Mock.Get(testObjects.ManualOverridesValidationService).Invocations.Clear();
            Mock.Get(testObjects.ManualOverridesChangedService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.Dispose(), Times.Never);

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.Dispose(), Times.Never);
        }

        [Test]
        public void ShouldDisposeController_When_DisposeViewModel()
        {
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.Dispose();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.Dispose());
        }

        [Test]
        public void ShouldNotDisposeController_When_AlreadyDisposed()
        {
            var testObjects = new ManualOverridesBandControllerTestObjectBuilder().Build();

            testObjects.ViewModel.Dispose();
            Mock.Get(testObjects.ManualOverridesValidationService).Invocations.Clear();
            Mock.Get(testObjects.ManualOverridesChangedService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.Dispose();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(s => s.Dispose(), Times.Never);

            Mock.Get(testObjects.ManualOverridesValidationService)
                .Verify(s => s.Dispose(), Times.Never);
        }
    }
}
