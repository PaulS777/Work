﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.Dashboard.DailyPricing.Controllers.Bands;
using Dsp.Gui.Dashboard.DailyPricing.Models;
using Dsp.Gui.Dashboard.DailyPricing.Services.DataSource;
using Dsp.Gui.Dashboard.DailyPricing.Services.ServerUpdate;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers.Bands
{
    internal interface IManualCurveBandHeaderControllerTestObjects
    {
        IDerivedCurveDefinitionUpdateService DerivedCurveDefinitionUpdateService { get; }
        IDerivedCurveDefinitionBuilder DerivedCurveDefinitionBuilder { get; }
        IPopupNotificationService PopupNotificationService { get; set; }
        IErrorMessageDialogService ErrorMessageDialogService { get; set; }
        ISubject<Unit> CurveUpdateResponse { get; }
        TestScheduler TestScheduler { get; }
        ManualCurveBandHeader ViewModel { get; }
        ManualCurveBandHeaderController Controller { get; }
    }

    [TestFixture]
    public class ManualCurveBandHeaderControllerTests
    {
        private class ManualCurveBandHeaderControllerTestObjectBuilder
        {
            private ManualCurveDefinition<DailyTenor> _manualCurveDefinition;
            private List<DailyPriceRowViewModel> _dailyPriceRows;
            private DerivedCurveDefinition _derivedCurveDefinitionBuilderResult;
            private bool _canUpdateCurve;
            private bool _priceHasChanges;
            private bool _efpHasChanges;
            private bool _subscribeUpdates;
            private bool _priceHasErrors;
            private bool _efpHasErrors;
            private string _priceErrorText;
            private string _efpErrorText;

            public ManualCurveBandHeaderControllerTestObjectBuilder WithManualCurveDefinition(ManualCurveDefinition<DailyTenor> value)
            {
                _manualCurveDefinition = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithDailyPriceRows(List<DailyPriceRowViewModel> values)
            {
                _dailyPriceRows = values;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithDerivedCurveDefinitionBuilderResult(DerivedCurveDefinition value)
            {
                _derivedCurveDefinitionBuilderResult = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithCanUpdateCurve(bool value)
            {
                _canUpdateCurve = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithPriceHasChanges(bool value)
            {
                _priceHasChanges = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithEfpHasChanges(bool value)
            {
                _efpHasChanges = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithPriceHasErrors(bool value)
            {
                _priceHasErrors = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithEfpHasErrors(bool value)
            {
                _efpHasErrors = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithPriceErrorText(string value)
            {
                _priceErrorText = value;
                return this;
            }

            public ManualCurveBandHeaderControllerTestObjectBuilder WithEfpErrorText(string value)
            {
                _efpErrorText = value;
                return this;
            }

            public IManualCurveBandHeaderControllerTestObjects Build()
            {
                var testObjects = new Mock<IManualCurveBandHeaderControllerTestObjects>();

                var curveBuilder = new Mock<IDerivedCurveDefinitionBuilder>();

                curveBuilder.Setup(b => b.GetDailyCurveDefinition(It.IsAny<ManualCurveDefinition<DailyTenor>>(),
                                                                  It.IsAny<IList<DailyPriceRowViewModel>>()))
                            .Returns(_derivedCurveDefinitionBuilderResult);

                testObjects.SetupGet(o => o.DerivedCurveDefinitionBuilder)
                           .Returns(curveBuilder.Object);

                var curveUpdateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.CurveUpdateResponse)
                           .Returns(curveUpdateResponse);

                var curveUpdateService = new Mock<IDerivedCurveDefinitionUpdateService>();

                curveUpdateService.Setup(u => u.Update(It.IsAny<DerivedCurveDefinition>(), It.IsAny<IScheduler>()))
                                  .Returns(curveUpdateResponse);

                testObjects.SetupGet(o => o.DerivedCurveDefinitionUpdateService)
                           .Returns(curveUpdateService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);

                var dataSourceService = new Mock<IDailyPriceRowDataSourceService>();

                dataSourceService.Setup(d => d.BusinessDayRows())
                                 .Returns(_dailyPriceRows);

                var controller = new ManualCurveBandHeaderController(schedulerProvider.Object,
                                                                     TestMocks.GetLoggerFactory().Object)
                                 {
                                     DataSourceService = dataSourceService.Object,
                                     DerivedCurveDefinitionBuilder = curveBuilder.Object,
                                     DerivedCurveDefinitionUpdateService = curveUpdateService.Object,
                                     PopupNotificationService = popupNotificationService.Object,
                                     ErrorMessageDialogService = errorMessageDialogService.Object
                                 };

                controller.ViewModel.SetDetails(new BandInfoDetails
                                                {
                                                    DailyCurveDefinition = _manualCurveDefinition
                                                });

                controller.ViewModel.ManualOverridesBand = new ManualOverridesBand(Mock.Of<IDisposable>())
                                                           {
                                                               HasChanges = _priceHasChanges,
                                                               HasErrors = _priceHasErrors,
                                                               ErrorText = _priceErrorText
                                                           };

                controller.ViewModel.EfpBand = new EfpBand(Mock.Of<IDisposable>())
                                               {
                                                   HasChanges = _efpHasChanges,
                                                   HasErrors = _efpHasErrors,
                                                   ErrorText = _efpErrorText
                                               };

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;
                controller.ViewModel.CanUpdateCurve = _canUpdateCurve;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetViewModel()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().Build();

            // ACT
            Assert.That(testObjects.Controller.ViewModel, Is.Not.Null);
        }

        [TestCase(true, false)]
        [TestCase(false, true)]
        public void ShouldSetHasErrorsTrue_When_SubscribeUpdatesTrue_With_PriceOrEfpErrors(bool priceHasErrors, bool efpHasErrors)
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(priceHasErrors)
                                                                                    .WithEfpHasErrors(efpHasErrors)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasErrors, Is.True);
        }

        [Test]
        public void ShouldSetHasErrorsFalse_When_SubscribeUpdatesTrue_With_NoPriceOrEfpErrors()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasErrors, Is.False);
        }

        [Test]
        public void ShouldSetHasErrorsTrue_When_PriceHasErrors_With_SubscribeUpdates()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.ManualOverridesBand.HasErrors = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasErrors, Is.True);
        }

        [Test]
        public void ShouldSetHasErrorsTrue_When_EfpHasErrors_With_SubscribeUpdates()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.EfpBand.HasErrors = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasErrors, Is.True);
        }

        [Test]
        public void ShouldSetErrorText_When_SubscribeUpdates_With_PriceOrEfpErrors()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceErrorText("price")
                                                                                    .WithEfpErrorText("efp")
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ErrorText, Is.EqualTo("price\r\nefp\r\n"));
        }

        [Test]
        public void ShouldSetCanUpdateCurveTrue_When_PriceChanges_With_SubscribeUpdates_And_NoErrors()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.ManualOverridesBand.HasChanges = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.True);
        }

        [Test]
        public void ShouldSetCanUpdateCurveTrue_When_EfpChanges_With_SubscribeUpdates_And_NoErrors()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.EfpBand.HasChanges = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.True);
        }

        [Test]
        public void ShouldSetCanUpdateCurveFalse_When_PriceHasErrors_With_SubscribeUpdates_And_Changes()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithPriceHasChanges(true)
                                                                                    .WithEfpHasChanges(true)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.ManualOverridesBand.HasErrors = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.False);
        }

        [Test]
        public void ShouldSetCanUpdateCurveFalse_When_EfpHasErrors_With_SubscribeUpdates_And_Changes()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithPriceHasChanges(true)
                                                                                    .WithEfpHasChanges(true)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.EfpBand.HasErrors = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.False);
        }

        [Test]
        public void ShouldSetNotHasErrors_When_UnsubscribeUpdates()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;
            testObjects.ViewModel.ManualOverridesBand.HasErrors = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasErrors, Is.False);
        }

        [Test]
        public void ShouldDisableUpdateCurve_And_SetIsBusyTrueOnPriceCells_On_UpdateCurveCommand()
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new List<DailyPriceRowViewModel> { priceRow };

            var dailyCurveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithDailyPriceRows(priceRows)
                                                                                    .WithManualCurveDefinition(dailyCurveDefinition)
                                                                                    .WithCanUpdateCurve(true)
                                                                                    .Build();

            // ACT
            testObjects.ViewModel.UpdateCurveCommand.Execute();
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.False);
            Assert.That(testObjects.ViewModel.ManualOverridesBand.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.EfpBand.IsBusy, Is.True);
            Assert.That(priceRow.ManualPriceCell.IsBusy, Is.True);
            Assert.That(priceRow.EfpNarrative.IsBusy, Is.True);
        }

        [Test]
        public void ShouldUpdateDailyCurveDefinition_On_UpdateCurveCommand()
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new List<DailyPriceRowViewModel> { priceRow };

            var dailyCurveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

            var derivedCurve = new DerivedCurveDefinition(new DerivedCurveDefinition<DailyTenor>());

            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithDailyPriceRows(priceRows)
                                                                                    .WithManualCurveDefinition(dailyCurveDefinition)
                                                                                    .WithDerivedCurveDefinitionBuilderResult(derivedCurve)
                                                                                    .Build();
            // ACT
            testObjects.ViewModel.UpdateCurveCommand.Execute();
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ASSERT
            Mock.Get(testObjects.DerivedCurveDefinitionBuilder)
                .Verify(b => b.GetDailyCurveDefinition(dailyCurveDefinition, priceRows));

            Mock.Get(testObjects.DerivedCurveDefinitionUpdateService)
                .Verify(u => u.Update(derivedCurve, It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldSetIsBusyFalseAndShowPopup_On_CurveUpdateCompleted()
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new List<DailyPriceRowViewModel> { priceRow };

            var dailyCurveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

            var derivedCurve = new DerivedCurveDefinition(new DerivedCurveDefinition<DailyTenor>());

            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithDailyPriceRows(priceRows)
                                                                                    .WithManualCurveDefinition(dailyCurveDefinition)
                                                                                    .WithDerivedCurveDefinitionBuilderResult(derivedCurve)
                                                                                    .Build();
            testObjects.ViewModel.UpdateCurveCommand.Execute();
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ACT
            testObjects.CurveUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualOverridesBand.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.EfpBand.IsBusy, Is.False);
            Assert.That(priceRow.ManualPriceCell.IsBusy, Is.False);
            Assert.That(priceRow.EfpNarrative.IsBusy, Is.False);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldSetIsBusyFalseAndShowErrorDialog_On_CurveUpdateError()
        {
            var priceRow = new DailyPriceRowTestObjectBuilder().Build();

            var priceRows = new List<DailyPriceRowViewModel> { priceRow };

            var dailyCurveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

            var derivedCurve = new DerivedCurveDefinition(new DerivedCurveDefinition<DailyTenor>());

            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithDailyPriceRows(priceRows)
                                                                                    .WithManualCurveDefinition(dailyCurveDefinition)
                                                                                    .WithDerivedCurveDefinitionBuilderResult(derivedCurve)
                                                                                    .Build();
            testObjects.ViewModel.UpdateCurveCommand.Execute();
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(2).Ticks);

            // ACT
            testObjects.CurveUpdateResponse.OnError(new Exception());

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualOverridesBand.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.EfpBand.IsBusy, Is.False);
            Assert.That(priceRow.ManualPriceCell.IsBusy, Is.False);
            Assert.That(priceRow.EfpNarrative.IsBusy, Is.False);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldSetNotHasErrors_When_PriceHasErrors_When_Disposed()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();

            // ARRANGE
            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.ManualOverridesBand.HasErrors = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasErrors, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ManualCurveBandHeaderControllerTestObjectBuilder().WithPriceHasErrors(false)
                                                                                    .WithEfpHasErrors(false)
                                                                                    .WithSubscribeUpdates(true)
                                                                                    .Build();

            // ARRANGE
            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.ManualOverridesBand.HasErrors = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasErrors, Is.False);
        }
    }
}
