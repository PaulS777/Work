﻿using Dsp.Gui.Dashboard.DailyPricing.Controllers.Bands;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers.Bands
{
    internal interface ITradeableSwitchBandControllerTestObjects
    {
        TradeableSwitchBandController Controller { get; }
    }

    [TestFixture]
    public class TradeableSwitchBandControllerTests
    {
        private class TradeableSwitchBandControllerTestObjectBuilder
        {
            public ITradeableSwitchBandControllerTestObjects Build()
            {
                var testObjects = new Mock<ITradeableSwitchBandControllerTestObjects>();

                var controller = new TradeableSwitchBandController();

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetViewModel()
        {
            var testObjects = new TradeableSwitchBandControllerTestObjectBuilder().Build();

            // ACT
            Assert.That(testObjects.Controller.ViewModel, Is.Not.Null);
        }
    }
}
