﻿using Dsp.Gui.Dashboard.DailyPricing.Controllers.Bands;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Efp;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using DynamicData;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.DailyPricing.Services.DataSource;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers.Bands
{
    internal interface IEfpBandControllerTestObjects
    {
        IEfpValidationService EfpValidationService { get; }
        IEfpChangedService EfpChangedService { get; }
        IEfpParentValueChangedService EfpParentValueChangedService { get; }
        IEfpUndoChangesService EfpUndoChangesService { get; }
        IDailyPriceRowDataSourceService DataSourceService { get; }
        IObservable<IChangeSet<DailyPriceRowViewModel>> DataSourceConnect { get; }
        EfpBand ViewModel { get; }
        EfpBandController Controller { get; }
    }

    [TestFixture]
    public class EfpBandControllerTests
    {
        private class EfpBandControllerTestObjectBuilder
        {
            private List<DailyPriceRowViewModel> _businessDayRows;
            private bool _subscribeUpdates;
            private bool _hasChanges;
            private bool _isBusy;

            public EfpBandControllerTestObjectBuilder WithBusinessDayRows(List<DailyPriceRowViewModel> values)
            {
                _businessDayRows = values;
                return this;
            }

            public EfpBandControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public EfpBandControllerTestObjectBuilder WithHasChanges(bool value)
            {
                _hasChanges = value;
                return this;
            }

            public EfpBandControllerTestObjectBuilder WithIsBusy(bool value)
            {
                _isBusy = value;
                return this;
            }

            public IEfpBandControllerTestObjects Build()
            {
                var testObjects = new Mock<IEfpBandControllerTestObjects>();

                var validationService = new Mock<IEfpValidationService>();

                testObjects.SetupGet(o => o.EfpValidationService)
                           .Returns(validationService.Object);

                var changedService = new Mock<IEfpChangedService>();

                testObjects.SetupGet(o => o.EfpChangedService)
                           .Returns(changedService.Object);

                var parentValueChangedService = new Mock<IEfpParentValueChangedService>();

                testObjects.SetupGet(o => o.EfpParentValueChangedService)
                           .Returns(parentValueChangedService.Object);

                var undoChangesService = new Mock<IEfpUndoChangesService>();

                testObjects.SetupGet(o => o.EfpUndoChangesService)
                           .Returns(undoChangesService.Object);

                var connect = new Subject<IChangeSet<DailyPriceRowViewModel>>();

                testObjects.SetupGet(o => o.DataSourceConnect)
                           .Returns(connect);

                var dataSourceService = new Mock<IDailyPriceRowDataSourceService>();

                dataSourceService.Setup(d => d.ConnectBusinessDays())
                                 .Returns(connect);

                dataSourceService.Setup(d => d.BusinessDayRows())
                                 .Returns(_businessDayRows);

                testObjects.SetupGet(o => o.DataSourceService)
                           .Returns(dataSourceService.Object);

                var controller = new EfpBandController(validationService.Object,
                                                       changedService.Object,
                                                       parentValueChangedService.Object)
                                 {
                                     UndoChangesService = undoChangesService.Object,
                                     DataSourceService = dataSourceService.Object
                                 };

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;
                controller.ViewModel.HasChanges = _hasChanges;
                controller.ViewModel.IsBusy = _isBusy;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetViewModel()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().Build();

            // ACT
            Assert.That(testObjects.Controller.ViewModel, Is.Not.Null);
        }

        [Test]
        public void ShouldAttachServices()
        {
            // ACT
            var testObjects = new EfpBandControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.EfpChangedService)
                .Verify(s => s.AttachBandInfo(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSubscribeUpdates_On_SubscribeUpdatesTrue()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.EfpChangedService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.EfpParentValueChangedService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));
        }

        [Test]
        public void ShouldUnsubscribeUpdates_On_SubscribeUpdatesFalse()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                      .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.EfpChangedService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.EfpParentValueChangedService)
                .Verify(s => s.UnsubscribeUpdates());
        }

        [Test]
        public void ShouldUndoChanges_On_UndoChangesCommand()
        {
            var items = new List<DailyPriceRowViewModel> { new(Mock.Of<IDisposable>()) };

            var testObjects = new EfpBandControllerTestObjectBuilder().WithBusinessDayRows(items)
                                                                      .Build();

            // ACT
            testObjects.ViewModel.UndoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.EfpUndoChangesService)
                .Verify(s => s.UndoChanges(items));
        }

        [Test]
        public void ShouldSuspendSubscriptionUpdates_When_UndoChanges()
        {
            var items = new List<DailyPriceRowViewModel> { new(Mock.Of<IDisposable>()) };

            var testObjects = new EfpBandControllerTestObjectBuilder().WithBusinessDayRows(items)
                                                                      .WithSubscribeUpdates(true)
                                                                      .Build();

            // ACT
            testObjects.ViewModel.UndoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.EfpChangedService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.EfpParentValueChangedService)
                .Verify(s => s.UnsubscribeUpdates());

            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.EfpChangedService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.EfpParentValueChangedService)
                .Verify(s => s.SubscribeUpdates(testObjects.DataSourceConnect));
        }

        [Test]
        public void ShouldSetCanUndoChangesTrue_When_HasChanges_With_IsBusyFalse()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().WithHasChanges(false)
                                                                      .WithIsBusy(false)
                                                                      .Build();

            // ACT
            testObjects.ViewModel.HasChanges = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.True);
        }

        [Test]
        public void ShouldSetCanUndoChangesFalse_When_IsBusyTrue()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().WithHasChanges(true)
                                                                      .WithIsBusy(false)
                                                                      .Build();

            // ACT
            testObjects.ViewModel.IsBusy = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.False);
        }

        [Test]
        public void ShouldSetCanUndoChangesFalse_When_HasChangesFalse()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().WithHasChanges(true)
                                                                      .WithIsBusy(false)
                                                                      .Build();

            // ACT
            testObjects.ViewModel.HasChanges = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUndoChanges, Is.False);
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.EfpChangedService)
                .Verify(s => s.Dispose());

            Mock.Get(testObjects.EfpParentValueChangedService)
                .Verify(s => s.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_AlreadyDisposed()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            Mock.Get(testObjects.EfpValidationService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.Dispose(), Times.Never);
        }

        [Test]
        public void ShouldDisposeController_When_DisposeViewModel()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.Dispose();

            // ASSERT
            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.Dispose());
        }

        [Test]
        public void ShouldNotDisposeController_When_AlreadyDisposed()
        {
            var testObjects = new EfpBandControllerTestObjectBuilder().Build();

            testObjects.ViewModel.Dispose();
            Mock.Get(testObjects.EfpValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.Dispose();

            // ASSERT
            Mock.Get(testObjects.EfpValidationService)
                .Verify(s => s.Dispose(), Times.Never);
        }
    }
}
