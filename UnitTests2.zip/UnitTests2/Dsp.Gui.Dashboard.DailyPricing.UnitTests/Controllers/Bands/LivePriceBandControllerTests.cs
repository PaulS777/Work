﻿using Dsp.Gui.Dashboard.DailyPricing.Controllers.Bands;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.LivePrice;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Dashboard.DailyPricing.Services.DataSource;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers.Bands
{
    internal interface ILivePriceBandControllerTestObjects
    {
        ILivePriceStreamLookupService LivePriceStreamLookupService { get; }
        ISubject<Dictionary<LinkedCurve, ILivePriceStreamService>> LivePriceStreams { get; }
        ISubject<PriceCurve> PriceCurveStream { get; }
        ICurrentUserIsPublisherObserver CurrentUserIsPublisherObserver { get; }
        ISubject<bool> CurrentUserIsPublisher { get; }
        IPriceCurveSettingObserver PriceCurveSettingObserver { get; }
        ISubject<PriceCurveSetting> PriceCurveSetting { get; }
        IToggleIsTradeableService ToggleIsTradeableService { get; }
        IDispatcherExecutionService Dispatcher { get; }
        ILivePriceCellsUpdateService LivePriceCellsUpdateService { get; }
        LivePriceBand ViewModel { get; }
        LivePriceBandController Controller { get; }
    }

    [TestFixture]
    public class LivePriceBandControllerTests
    {
        private class LivePriceBandControllerTestObjectBuilder
        {
            private LinkedCurve _linkedCurve;
            private bool _subscribeLivePriceUpdates;
            private Dictionary<LinkedCurve, ILivePriceStreamService> _livePriceStreams;
            private List<DailyPriceRowViewModel> _dataSourceItems;

            public LivePriceBandControllerTestObjectBuilder WithLinkedCurve(LinkedCurve value)
            {
                _linkedCurve = value;
                return this;
            }

            public LivePriceBandControllerTestObjectBuilder WithSubscribeLivePriceUpdates(bool value)
            {
                _subscribeLivePriceUpdates = value;
                return this;
            }

            public LivePriceBandControllerTestObjectBuilder WithLivePriceStreams(Dictionary<LinkedCurve, ILivePriceStreamService> values)
            {
                _livePriceStreams = values;
                return this;
            }

            public LivePriceBandControllerTestObjectBuilder WithDataSourceItems(List<DailyPriceRowViewModel> values)
            {
                _dataSourceItems = values;
                return this;
            }

            public ILivePriceBandControllerTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceBandControllerTestObjects>();

                var dataSource = new Mock<IDailyPriceRowDataSource>();

                dataSource.Setup(d => d.Items())
                          .Returns(_dataSourceItems);

                var dataSourceService = new Mock<IDailyPriceRowDataSourceService>();

                dataSourceService.SetupGet(d => d.DataSource)
                                 .Returns(dataSource.Object);

                var livePriceStreams = new BehaviorSubject<Dictionary<LinkedCurve, ILivePriceStreamService>>(_livePriceStreams);

                testObjects.SetupGet(o => o.LivePriceStreams)
                           .Returns(livePriceStreams);

                var liveStreamLookupService = new Mock<ILivePriceStreamLookupService>();

                liveStreamLookupService.SetupGet(o => o.LivePriceStreams)
                                       .Returns(livePriceStreams);

                testObjects.SetupGet(o => o.LivePriceStreamLookupService)
                           .Returns(liveStreamLookupService.Object);

                var livePriceCellsUpdateService = new Mock<ILivePriceCellsUpdateService>();

                testObjects.SetupGet(o => o.LivePriceCellsUpdateService)
                           .Returns(livePriceCellsUpdateService.Object);

                var currentUserIsPublisher = new Subject<bool>();

                testObjects.SetupGet(o => o.CurrentUserIsPublisher)
                           .Returns(currentUserIsPublisher);

                var currentUserIsPublisherObserver = new Mock<ICurrentUserIsPublisherObserver>();

                currentUserIsPublisherObserver.Setup(o => o.Observe(It.IsAny<int>()))
                                              .Returns(currentUserIsPublisher);

                testObjects.SetupGet(o => o.CurrentUserIsPublisherObserver)
                           .Returns(currentUserIsPublisherObserver.Object);

                var priceCurveSetting = new Subject<PriceCurveSetting>();

                testObjects.SetupGet(o => o.PriceCurveSetting)
                           .Returns(priceCurveSetting);

                var priceCurveSettingObserver = new Mock<IPriceCurveSettingObserver>();

                priceCurveSettingObserver.Setup(o => o.Observe(It.IsAny<int>()))
                                         .Returns(priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSettingObserver)
                           .Returns(priceCurveSettingObserver.Object);

                var toggleIsTradeableService = new Mock<IToggleIsTradeableService>();

                testObjects.SetupGet(o => o.ToggleIsTradeableService)
                           .Returns(toggleIsTradeableService.Object);

                var dispatcher = new Mock<IDispatcherExecutionService>();

                dispatcher.Setup(d => d.Schedule(It.IsAny<Action>()))
                          .Callback<Action>(action => action());

                testObjects.SetupGet(o => o.Dispatcher)
                           .Returns(dispatcher.Object);

                var controller = new LivePriceBandController(liveStreamLookupService.Object,
                                                             livePriceCellsUpdateService.Object,
                                                             currentUserIsPublisherObserver.Object,
                                                             priceCurveSettingObserver.Object,
                                                             toggleIsTradeableService.Object,
                                                             TestMocks.GetSchedulerProvider().Object)
                                 {
                                     Dispatcher = dispatcher.Object,
                                     DataSourceService = dataSourceService.Object
                                 };

                controller.ViewModel.LinkedCurve = _linkedCurve;
                controller.ViewModel.SubscribeLivePriceUpdates = _subscribeLivePriceUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachToggleIsTradeableService()
        {
            // ACT
            var testObjects = new LivePriceBandControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSubscribeLivePriceStreamsLookup_On_SubscribeLivePriceUpdatesTrue()
        {
            var testObjects = new LivePriceBandControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeLivePriceUpdates = true;

            // ASSERT
            Mock.Get(testObjects.LivePriceStreamLookupService)
                .VerifyGet(l => l.LivePriceStreams, Times.Once);
        }

        [Test]
        public void ShouldObserveCurrentUserIsPublisher_On_SubscribeLivePriceUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                            .Build();

            // ACT
            testObjects.ViewModel.SubscribeLivePriceUpdates = true;

            // ASSERT
            Mock.Get(testObjects.CurrentUserIsPublisherObserver)
                .Verify(o => o.Observe(101));
        }

        [Test]
        public void ShouldObservePriceCurveSettings_On_SubscribeLivePriceUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                            .Build();

            // ACT
            testObjects.ViewModel.SubscribeLivePriceUpdates = true;

            // ASSERT
            Mock.Get(testObjects.PriceCurveSettingObserver)
                .Verify(o => o.Observe(101));
        }

        [Test]
        public void ShouldSubscribeToggleIsTradeable_On_SubscribeLivePriceUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                            .Build();

            // ACT
            testObjects.ViewModel.SubscribeLivePriceUpdates = true;

            // ASSERT
            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.SubscribeUpdates());
        }

        [Test]
        public void ShouldSubscribeLiveStreamPriceCurve_With_MatchingLinkedCurve()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var priceCurveSubject = new Subject<PriceCurve>();

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1)
                                                                 .WithPriceCurve(priceCurveSubject)
                                                                 .Build();

            var stream2 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve2)
                                                                 .Build();

            var livePriceStreams = new Dictionary<LinkedCurve, ILivePriceStreamService>
                                   {
                                       { linkedCurve1, stream1.Object },
                                       { linkedCurve2, stream2.Object }
                                   };

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve1)
                                                                            .WithSubscribeLivePriceUpdates(true)
                                                                            .Build();

            // ACT
            testObjects.LivePriceStreams.OnNext(livePriceStreams);

            // ASSERT
            stream1.VerifyGet(s => s.PriceCurve);
            stream2.VerifyGet(s => s.PriceCurve, Times.Never);
        }

        [Test]
        public void ShouldUpdateRagStatus_On_PriceCurveUpdate()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            
            var priceCurveSubject = new Subject<PriceCurve>();

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1)
                                                                 .WithPriceCurve(priceCurveSubject)
                                                                 .Build();


            var livePriceStreams = new Dictionary<LinkedCurve, ILivePriceStreamService>
                                   {
                                       { linkedCurve1, stream1.Object }
                                   };

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve1)
                                                                            .WithSubscribeLivePriceUpdates(true)
                                                                            .WithLivePriceStreams(livePriceStreams)
                                                                            .WithDataSourceItems(new List<DailyPriceRowViewModel>())
                                                                            .Build();

            var priceCurve = new PriceCurveBuilder().WithValidityIndicator(ValidityIndicator.Valid).Build();

            // ACT
            priceCurveSubject.OnNext(priceCurve);

            // ASSERT

            Mock.Get(testObjects.Dispatcher)
                .Verify(d => d.Schedule(It.IsAny<Action>()));

            Assert.That(testObjects.ViewModel.RagStatus, Is.EqualTo(ValidityIndicator.Valid));
        }

        [Test]
        public void ShouldUpdatePriceCells_On_PriceCurveUpdate()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var priceCurveSubject = new Subject<PriceCurve>();

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1)
                                                                 .WithPriceCurve(priceCurveSubject)
                                                                 .Build();

            var livePriceStreams = new Dictionary<LinkedCurve, ILivePriceStreamService>
                                   {
                                       { linkedCurve1, stream1.Object }
                                   };

            var cell1 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve1).Build();
            var cell2 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve2).Build();

            var livePriceCellsRow1 = new[] { cell1, cell2 };

            var row1 = new DailyPriceRowTestObjectBuilder().WithLivePriceCells(livePriceCellsRow1).Build();

            var cell3 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve1).Build();
            var cell4 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve2).Build();

            var livePriceCellsRow2 = new[] { cell3, cell4 };

            var row2 = new DailyPriceRowTestObjectBuilder().WithLivePriceCells(livePriceCellsRow2).Build();

            var priceRows = new List<DailyPriceRowViewModel>
                            {
                                row1, row2
                            };

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve1)
                                                                            .WithSubscribeLivePriceUpdates(true)
                                                                            .WithLivePriceStreams(livePriceStreams)
                                                                            .WithDataSourceItems(priceRows)
                                                                            .Build();

            var expectedPriceCells = new[] { cell1, cell3 };

            var priceCurve = new PriceCurve();

            // ACT
            priceCurveSubject.OnNext(priceCurve);

            // ASSERT
            Mock.Get(testObjects.LivePriceCellsUpdateService)
                .Verify(u => u.UpdatePriceCells(It.Is<IList<LivePriceCell>>(cells => cells.SequenceEqual(expectedPriceCells)),
                                                priceCurve,
                                                testObjects.Dispatcher));
        }

        [Test]
        public void ShouldUpdateViewModel_On_CurrentUserIsPublisher()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                            .WithSubscribeLivePriceUpdates(true)
                                                                            .Build();

            // ACT
            testObjects.CurrentUserIsPublisher.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.CurrentUserIsPublisher, Is.True);
        }

        [Test]
        public void ShouldUpdateViewModel_On_PriceCurveSettings()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                            .WithSubscribeLivePriceUpdates(true)
                                                                            .Build();

            var setting = new PriceCurveSetting(101, 10, true, true, false, false, null);

            // ACT
            testObjects.PriceCurveSetting.OnNext(setting);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditIsTradeable, Is.True);
            Assert.That(testObjects.ViewModel.IsTradeable, Is.True);
            Assert.That(testObjects.ViewModel.PriceCurveSetting(), Is.SameAs(setting));
        }

        [Test]
        public void ShouldNotUpdatePriceCells_When_Disposed()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var priceCurveSubject = new Subject<PriceCurve>();

            var stream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1)
                                                                 .WithPriceCurve(priceCurveSubject)
                                                                 .Build();


            var livePriceStreams = new Dictionary<LinkedCurve, ILivePriceStreamService>
                                   {
                                       { linkedCurve1, stream1.Object },
                                   };

            var cell1 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve1).Build();
            var cell2 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve2).Build();

            var livePriceCellsRow1 = new[] { cell1, cell2 };

            var row1 = new DailyPriceRowTestObjectBuilder().WithLivePriceCells(livePriceCellsRow1).Build();


            var cell3 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve1).Build();
            var cell4 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve2).Build();

            var livePriceCellsRow2 = new[] { cell3, cell4 };

            var row2 = new DailyPriceRowTestObjectBuilder().WithLivePriceCells(livePriceCellsRow2).Build();

            var priceRows = new List<DailyPriceRowViewModel>
                            {
                                row1, row2
                            };

            var testObjects = new LivePriceBandControllerTestObjectBuilder().WithLinkedCurve(linkedCurve1)
                                                                            .WithSubscribeLivePriceUpdates(true)
                                                                            .WithLivePriceStreams(livePriceStreams)
                                                                            .WithDataSourceItems(priceRows)
                                                                            .Build();
            var priceCurve = new PriceCurve();

            testObjects.ViewModel.Dispose();

            // ACT
            priceCurveSubject.OnNext(priceCurve);

            // ASSERT
            Mock.Get(testObjects.LivePriceCellsUpdateService)
                .Verify(u => u.UpdatePriceCells(It.IsAny<IList<LivePriceCell>>(), priceCurve, testObjects.Dispatcher), Times.Never);
        }

        [Test]
        public void ShouldDisposeToggleIsTradeable_When_Dispose()
        {
            var testObjects = new LivePriceBandControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new LivePriceBandControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.Dispose(), Times.Once);
        }
    }
}
