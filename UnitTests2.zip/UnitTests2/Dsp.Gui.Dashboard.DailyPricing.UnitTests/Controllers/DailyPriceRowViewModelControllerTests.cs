﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.Controllers;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Controllers
{
    internal interface IDailyPriceRowViewModelControllerTestObjects
    {
        ITenorPremiumPresentationService TenorPremiumPresentationService { get; }
        ITenorPremiumChangedService TenorPremiumChangedService { get; }
        ITenorMarginsValidationService TenorMarginsValidationService { get; }
        ICoerceMarginEditValuesService CoerceMarginEditValuesService { get; }
        DailyPriceRowViewModelController Controller { get; }
        DailyPriceRowViewModel ViewModel { get; }
        TenorPremiumViewModel TenorPremium { get; }
    }

    [TestFixture]
    public class DailyPriceRowViewModelControllerTests
    {
        private class DailyPriceRowViewModelControllerTestObjectBuilder
        {
            private bool _isPublisherEditor;
            private bool _isTradeable;
            private decimal? _midPriceServer;
            private decimal? _midPriceManual;
            private decimal? _midPrice;
            private bool _hasManualChangeMidPrice;

            private IList<EfpMonthItem> _efpMonthItems;
            private EfpMonthItem _efpMonthItem;
            private MonthlyTenor? _efpMonthServer;
            private MonthlyTenor? _efpMonthManual;

            private decimal? _efpValue;
            private decimal? _efpValueServer;
            private decimal? _efpValueManual;
            private bool _efpValueEnabled;
            private bool _efpHasChanged;
            private bool _efpIsValid;
            private string _efpError;
            private bool _subscribeManualCurveUpdates;
            private bool _subscribeTenorPremiumUpdates;

            public DailyPriceRowViewModelControllerTestObjectBuilder WithIsPublisherEditor(bool value)
            {
                _isPublisherEditor = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithIsTradeable(bool value)
            {
                _isTradeable = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithHasManualChangeMidPrice(bool value)
            {
                _hasManualChangeMidPrice = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithMidPriceServer(decimal? value)
            {
                _midPriceServer = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithMidPriceManual(decimal? value)
            {
                _midPriceManual = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithMidPrice(decimal? value)
            {
                _midPrice = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpMonthItems(IList<EfpMonthItem> values)
            {
                _efpMonthItems = values;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpMonthItem(EfpMonthItem value)
            {
                _efpMonthItem = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpMonthServer(MonthlyTenor? value)
            {
                _efpMonthServer = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpMonthManual(MonthlyTenor? value)
            {
                _efpMonthManual = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpValue(decimal? value)
            {
                _efpValue = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpValueServer(decimal? value)
            {
                _efpValueServer = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpValueManual(decimal? value)
            {
                _efpValueManual = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpValueEnabled(bool value)
            {
                _efpValueEnabled = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpHasChanged(bool value)
            {
                _efpHasChanged = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpIsValid(bool value)
            {
                _efpIsValid = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithEfpError(string value)
            {
                _efpError = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithSubscribeManualCurveUpdates(bool value)
            {
                _subscribeManualCurveUpdates = value;
                return this;
            }

            public DailyPriceRowViewModelControllerTestObjectBuilder WithSubscribeTenorPremiumUpdates(bool value)
            {
                _subscribeTenorPremiumUpdates = value;
                return this;
            }

			public IDailyPriceRowViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IDailyPriceRowViewModelControllerTestObjects>();

                var tenorPremiumPresentationService = new Mock<ITenorPremiumPresentationService>();

                testObjects.SetupGet(o => o.TenorPremiumPresentationService)
                           .Returns(tenorPremiumPresentationService.Object);

                var tenorPremiumChanged = new Mock<ITenorPremiumChangedService>();

                testObjects.SetupGet(o => o.TenorPremiumChangedService)
                           .Returns(tenorPremiumChanged.Object);

                var tenorMarginsValidation = new Mock<ITenorMarginsValidationService>();

                testObjects.SetupGet(o => o.TenorMarginsValidationService)
                           .Returns(tenorMarginsValidation.Object);

                var extendedRowPremiumsService = new Mock<ICoerceMarginEditValuesService>();

                testObjects.SetupGet(o => o.CoerceMarginEditValuesService)
                           .Returns(extendedRowPremiumsService.Object);

                var controller = new DailyPriceRowViewModelController(tenorPremiumPresentationService.Object,
                                                                      tenorPremiumChanged.Object,
                                                                      tenorMarginsValidation.Object,
                                                                      extendedRowPremiumsService.Object);
            
                testObjects.SetupGet(o => o.Controller).Returns(controller);
                
                var viewModel = controller.ViewModel;

                testObjects.SetupGet(o => o.ViewModel).Returns(viewModel);

                controller.ViewModel.IsPublisherEditor = _isPublisherEditor;
                viewModel.ManualPriceCell.IsTradeable = _isTradeable;
                
                viewModel.ManualPriceCell.MidPrice = _midPrice;
                viewModel.Model().MidPriceServer = _midPriceServer;
                viewModel.Model().MidPriceManual = _midPriceManual;
                viewModel.ManualPriceCell.HasManualChange = _hasManualChangeMidPrice;

                viewModel.EfpNarrative.EfpMonthItems = _efpMonthItems;
                viewModel.EfpNarrative.EfpMonthItem = _efpMonthItem;
                viewModel.EfpNarrative.EfpValue = _efpValue;
                viewModel.EfpNarrative.CanEditEfpValue = _efpValueEnabled;
                viewModel.Model().EfpMonthServer = _efpMonthServer;
                viewModel.Model().EfpMonthManual = _efpMonthManual;
                viewModel.Model().EfpValueServer = _efpValueServer;
                viewModel.Model().EfpValueManual = _efpValueManual;
                viewModel.EfpNarrative.HasChanged = _efpHasChanged;
                viewModel.EfpNarrative.IsValueValid = _efpIsValid;
                viewModel.EfpNarrative.ValueError = _efpError;

                viewModel.SubscribeManualCurveUpdates = _subscribeManualCurveUpdates;
                viewModel.SubscribeTenorPremiumUpdates = _subscribeTenorPremiumUpdates;
                
                var tenorPremium = controller.ViewModel.TenorPremium;

                testObjects.SetupGet(o => o.TenorPremium).Returns(tenorPremium);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachServices()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(p => p.Attach(testObjects.ViewModel.TenorPremium));

            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Attach(testObjects.ViewModel.TenorPremium));

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(p => p.AttachPremium(testObjects.ViewModel.TenorPremium));
        }

        #region Efp Validation

        [Test]
        public void ShouldClearEfpValidation_When_IsPublisherFalse()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsPublisherEditor(true)
                                                                                     .WithEfpIsValid(false)
                                                                                     .WithEfpError("error")
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.IsPublisherEditor = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsValueValid, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.ValueError, Is.Null);
        }

        [Test]
        public void ShouldSetEfpMonthIsValid_When_SubscribeUpdates_With_EfpMonthItemEnabled()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var efpMonthItem = new EfpMonthItem(jan23, true);

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithEfpMonthItem(efpMonthItem)
                                                                                     .WithEfpValue(1.0M)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.SubscribeManualCurveUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsMonthValid, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.MonthError, Is.Null);
        }

        [Test]
        public void ShouldSetEfpMonthIsValidFalse_When_SubscribeUpdates_With_EfpMonthItemEnabledFalse()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var efpMonthItem = new EfpMonthItem(jan23, false);

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithEfpMonthItem(efpMonthItem)
                                                                                     .WithEfpValue(1.0M)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.SubscribeManualCurveUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsMonthValid, Is.False);
            Assert.That(testObjects.ViewModel.EfpNarrative.MonthError, Is.Not.Null);
        }

        [Test]
        public void ShouldSetEfpValueIsValid_When_SubscribeUpdates_With_EfpMonthItemAndValueNotNull()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var efpMonthItem = new EfpMonthItem(jan23, true);

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithEfpMonthItem(efpMonthItem)
                                                                                     .WithEfpValue(1.0M)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.SubscribeManualCurveUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsValueValid, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.ValueError, Is.Null);
        }

        [Test]
        public void ShouldValidateEfp_When_SubscribeUpdate_With_EfpMonthAndValueNotSet()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithEfpMonthItem(null)
                                                                                     .WithEfpValue(null)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.SubscribeManualCurveUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsValueValid, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.ValueError, Is.Null);
        }

        #endregion

        #region Tenor Premiums

		[Test]
        public void ShouldSubscribeMargins_When_SubscribeTenorPremiumUpdates()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeTenorPremiumUpdates = true;

            // ASSERT
            Mock.Get(testObjects.CoerceMarginEditValuesService)
                .Verify(c => c.SubscribeMargins(testObjects.ViewModel));
        }

        [Test]
        public void ShouldUnsubscribeMargins_When_SubscribeTenorPremiumsUpdatesFalse()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.SubscribeTenorPremiumUpdates = false;

            // ASSERT
            Mock.Get(testObjects.CoerceMarginEditValuesService)
                .Verify(c => c.UnsubscribeMargins());
        }

        #endregion

		[Test]
        public void ShouldCalculateMidPriceHasChanged_And_EnableEfp_When_SubscribeManualCurveUpdates()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPrice(2.0M)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.SubscribeManualCurveUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.Model().MidPriceManual, Is.EqualTo(2.0M));
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpMonth, Is.True);
        }

        [Test]
        public void ShouldUpdatePriceCellFromManualPriceChange()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.0M)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = 2.0M;

            // ASSERT
            Assert.That(testObjects.ViewModel.Model().MidPriceManual, Is.EqualTo(2.0M));
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.True);
        }

        [Test]
        public void ShouldNotUpdatePriceCell_With_UnsubscribeManualCurveUpdates()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.0M)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();

            testObjects.ViewModel.SubscribeManualCurveUpdates = false;

            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = 2.0M;

            // ASSERT
            Assert.That(testObjects.ViewModel.Model().MidPriceManual, Is.Null);
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.False);
        }

        [Test]
        public void ShouldAllowSubscribeManualCurveUpdates_After_UnsubscribeManualCurveUpdates()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.0M)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();

            testObjects.ViewModel.SubscribeManualCurveUpdates = false;
            testObjects.ViewModel.SubscribeManualCurveUpdates = true;

            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = 2.0M;

            // ASSERT
            Assert.That(testObjects.ViewModel.Model().MidPriceManual, Is.EqualTo(2.0M));
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.True);
        }

        [Test]
        public void ShouldEnableEfpValue_When_EfpMonthItemUpdated()
        {
            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(new MonthlyTenor(2023, 1), true),
                                    new(new MonthlyTenor(2023, 2), true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(null)
                                                                                     .WithEfpMonthServer(null)
                                                                                     .WithEfpValue(null)
                                                                                     .WithEfpValueServer(null)
                                                                                     .WithEfpValueEnabled(false)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.EfpNarrative.EfpMonthItem = efpMonthItems[0];

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpValue, Is.True);
        }

        [Test]
        public void ShouldDisableEfpValue_When_EfpMonthItemUpdatedToNull()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .WithEfpMonthItem(new EfpMonthItem(new MonthlyTenor(2023, 1), true))
                                                                                     .WithEfpValue(2.1M)
                                                                                     .WithEfpValueEnabled(true)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.EfpNarrative.EfpMonthItem = null;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpValue, Is.False);
            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpValue);
            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpValueBackup);
            Assert.That(testObjects.ViewModel.EfpNarrative.ShowBackupValues, Is.False);
        }

        [Test]
        public void ShouldDisableEfpCells_When_EfpIsChildTrue()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .WithEfpMonthItem(new EfpMonthItem(new MonthlyTenor(2023, 1), true))
                                                                                     .WithEfpValue(2.1M)
                                                                                     .WithEfpValueEnabled(true)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.EfpNarrative.IsChild = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpMonth, Is.False);
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpValue, Is.False);
        }

        [Test]
        public void ShouldEnableEfpCells_When_EfpIsChildFalse()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .WithEfpMonthItem(new EfpMonthItem(new MonthlyTenor(2023, 1), true))
                                                                                     .WithEfpValue(2.1M)
                                                                                     .WithEfpValueEnabled(true)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            testObjects.ViewModel.EfpNarrative.IsChild = true;

            // ACT
            testObjects.ViewModel.EfpNarrative.IsChild = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpMonth, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpValue, Is.True);
        }

        [Test]
        public void ShouldSetHasManualChangeFalse_When_ManualPriceChangeReverted()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.0M)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            testObjects.ViewModel.ManualPriceCell.MidPrice = 2.0M;

            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = 1.0M;

            // ASSERT
            Assert.IsNull(testObjects.ViewModel.Model().MidPriceManual);
            Assert.That(testObjects.ViewModel.ManualPriceCell.MidPrice, Is.EqualTo(1.0M));
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.False);
            Assert.That(testObjects.ViewModel.Model().MidPriceServer, Is.EqualTo(1.0M));
        }

        [Test]
        public void ShouldClearMidPriceAndEfpCells_When_IsTradeableFalse()
        {
            var jan23 = new MonthlyTenor(2023, 1);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(new MonthlyTenor(2023, 2), true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.1M)
                                                                                     .WithMidPrice(1.1M)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(efpMonthItems[0])
                                                                                     .WithEfpMonthServer(jan23)
                                                                                     .WithEfpValue(2.2M)
                                                                                     .WithEfpValueServer(2.2M)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.ManualPriceCell.IsTradeable = false;

            // ASSERT
            Assert.IsNull(testObjects.ViewModel.ManualPriceCell.MidPrice);
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.True);
            Assert.That(testObjects.ViewModel.ManualPriceCell.MidPriceNonTradeable, Is.EqualTo(1.1M));

            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpMonthItem);
            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpValue);
            Assert.That(testObjects.ViewModel.EfpNarrative.HasChanged, Is.False);
            Assert.That(testObjects.ViewModel.EfpNarrative.EfpMonthBackup, Is.EqualTo(jan23));
            Assert.That(testObjects.ViewModel.EfpNarrative.EfpValueBackup, Is.EqualTo(2.2M));
            Assert.That(testObjects.ViewModel.EfpNarrative.ShowBackupValues, Is.True);
        }

        [Test]
        public void ShouldRetainEfpHasChangedTrue_When_IsTradeableFalse()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var feb23 = new MonthlyTenor(2023, 2);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(feb23, true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.1M)
                                                                                     .WithMidPrice(1.1M)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(efpMonthItems[1])
                                                                                     .WithEfpMonthServer(jan23)
                                                                                     .WithEfpMonthManual(feb23)
                                                                                     .WithEfpValue(2.2M)
                                                                                     .WithEfpValueServer(2.3M)
                                                                                     .WithEfpValueManual(2.2M)
                                                                                     .WithEfpHasChanged(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.ManualPriceCell.IsTradeable = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.HasChanged, Is.True);
        }

        [Test]
        public void ShouldRestoreFromServerValues_When_IsTradeableRevertedToTrue_With_NoManualChanges_And_SubscribeManualCurveUpdates()
        {
            var jan23 = new MonthlyTenor(2023, 1);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(new MonthlyTenor(2023, 2), true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.1M)
                                                                                     .WithMidPrice(1.1M)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(efpMonthItems[0])
                                                                                     .WithEfpMonthServer(jan23)
                                                                                     .WithEfpValue(2.2M)
                                                                                     .WithEfpValueServer(2.2M)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            testObjects.ViewModel.ManualPriceCell.IsTradeable = false;

            // ACT
            testObjects.ViewModel.ManualPriceCell.IsTradeable = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualPriceCell.MidPrice, Is.EqualTo(1.1M));
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.False);
            Assert.That(testObjects.ViewModel.EfpNarrative.EfpMonthItem, Is.SameAs(efpMonthItems[0]));
            Assert.That(testObjects.ViewModel.EfpNarrative.EfpValue, Is.EqualTo(2.2M));
            Assert.That(testObjects.ViewModel.EfpNarrative.HasChanged, Is.False);
            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpMonthBackup);
            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpValueBackup);
            Assert.That(testObjects.ViewModel.EfpNarrative.ShowBackupValues, Is.False);
        }

        [Test]
        public void ShouldRestoreManualChangesToMidPrice_When_IsTradeableRevertedToTrue_With_SubscribeManualCurveUpdates()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.1M)
                                                                                     .WithMidPriceManual(1.2M)
                                                                                     .WithMidPrice(1.2M)
                                                                                     .WithHasManualChangeMidPrice(true)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            testObjects.ViewModel.ManualPriceCell.IsTradeable = false;

            // ACT
            testObjects.ViewModel.ManualPriceCell.IsTradeable = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualPriceCell.MidPrice, Is.EqualTo(1.2M));
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.True);
        }

        [Test]
        public void ShouldRestoreManualEfpChanges_When_IsTradeableRevertedToTrue_With_SubscribeManualCurveUpdates()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var feb23 = new MonthlyTenor(2023, 2);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(feb23, true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(false)
                                                                                     .WithEfpMonthServer(jan23)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(efpMonthItems[1])
                                                                                     .WithEfpMonthManual(feb23)
                                                                                     .WithEfpValueServer(0.5m)
                                                                                     .WithEfpValue(0.5m)
                                                                                     .WithEfpValue(1.0M)
                                                                                     .WithEfpValueManual(1.0M)
                                                                                     .WithEfpHasChanged(true)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.ManualPriceCell.IsTradeable = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.EfpMonthItem, Is.SameAs(efpMonthItems[1]));
            Assert.That(testObjects.ViewModel.EfpNarrative.EfpValue, Is.EqualTo(1.0M));
            Assert.That(testObjects.ViewModel.EfpNarrative.HasChanged, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.ShowBackupValues, Is.False);
        }

        [Test]
        public void ShouldClearEfpCells_When_MidPriceSetToNull()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var efpMonthItem = new EfpMonthItem(jan23, true);

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.1M)
                                                                                     .WithMidPrice(1.1M)
                                                                                     .WithEfpMonthItem(efpMonthItem)
                                                                                     .WithEfpMonthServer(jan23)
                                                                                     .WithEfpValue(2.2M)
                                                                                     .WithEfpValueServer(2.2M)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = null;

            // ASSERT
            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpMonthItem);
            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpValue);
            Assert.That(testObjects.ViewModel.EfpNarrative.HasChanged, Is.False);
            Assert.IsNull(testObjects.ViewModel.EfpNarrative.EfpMonthBackup);
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpMonth, Is.False);
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpValue, Is.False);
            Assert.That(testObjects.ViewModel.EfpNarrative.ShowBackupValues, Is.False);
        }

        [Test]
        public void ShouldClearEfpValidation_When_MidPriceSetToNull()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var efpMonthItem = new EfpMonthItem(jan23, true);

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPrice(1.1M)
                                                                                     .WithEfpMonthItem(efpMonthItem)
                                                                                     .WithEfpValue(null)
                                                                                     .WithEfpIsValid(false)
                                                                                     .WithEfpError("error")
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = null;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsMonthValid, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.MonthError, Is.Null);
            Assert.That(testObjects.ViewModel.EfpNarrative.IsValueValid, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.ValueError, Is.Null);
        }

        [Test]
        public void ShouldSetEfpHasChangedFalse_When_MidPriceSetToNull()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var feb23 = new MonthlyTenor(2023, 2);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(feb23, true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.1M)
                                                                                     .WithMidPrice(1.1M)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(efpMonthItems[1])
                                                                                     .WithEfpMonthServer(jan23)
                                                                                     .WithEfpValue(2.4M)
                                                                                     .WithEfpValueServer(2.2M)
                                                                                     .WithEfpHasChanged(true)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = null;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.HasChanged, Is.False);
        }

        [Test]
        public void ShouldRevertEfpHasChangedTrue_When_MidPriceRevertedBackToValueFromNull()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var feb23 = new MonthlyTenor(2023, 2);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(feb23, true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.1M)
                                                                                     .WithMidPrice(1.1M)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(efpMonthItems[1])
                                                                                     .WithEfpMonthServer(jan23)
                                                                                     .WithEfpValue(2.4M)
                                                                                     .WithEfpValueServer(2.2M)
                                                                                     .WithEfpHasChanged(true)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();

            testObjects.ViewModel.ManualPriceCell.MidPrice = null;

            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = 1.1M;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.HasChanged, Is.True);
        }

        [Test]
        public void ShouldEnable_EfpMonth_When_MidPriceRevertedBackToValueFromNull_With_SubscribeManualCurveUpdates()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var feb23 = new MonthlyTenor(2023, 2);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(feb23, true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.1M)
                                                                                     .WithMidPrice(1.1M)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(efpMonthItems[0])
                                                                                     .WithEfpMonthServer(jan23)
                                                                                     .WithEfpValue(2.2M)
                                                                                     .WithEfpValueServer(2.2M)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            
            testObjects.ViewModel.ManualPriceCell.MidPrice = null;

            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = 1.1M;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpMonth, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.CanEditEfpValue, Is.False);
            Assert.That(testObjects.ViewModel.EfpNarrative.EfpMonthItem, Is.Null);
            Assert.That(testObjects.ViewModel.EfpNarrative.EfpValue, Is.Null);
            Assert.That(testObjects.ViewModel.EfpNarrative.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetEfpIsValueValidFalse_When_EfpMonthItemSet_With_EfpValueNull()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var feb23 = new MonthlyTenor(2023, 2);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(feb23, true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(null)
                                                                                     .WithEfpValue(null)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.EfpNarrative.EfpMonthItem = efpMonthItems[0];

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsValueValid, Is.False);
            Assert.That(testObjects.ViewModel.EfpNarrative.ValueError, Is.Not.Null);
        }

        [Test]
        public void ShouldSetEfpIsValidTrue_When_EfpValueSet()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var feb23 = new MonthlyTenor(2023, 2);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(feb23, true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(null)
                                                                                     .WithEfpValue(null)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();

            testObjects.ViewModel.EfpNarrative.EfpMonthItem = efpMonthItems[0];

            // ACT
            testObjects.ViewModel.EfpNarrative.EfpValue = 0.5M;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsValueValid, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.ValueError, Is.Null);
        }

        [Test]
        public void ShouldSetEfpIsValidTrue_When_IsTradeableFalse()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var feb23 = new MonthlyTenor(2023, 2);

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(jan23, true),
                                    new(feb23, true)
                                };

            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithEfpMonthItems(efpMonthItems)
                                                                                     .WithEfpMonthItem(null)
                                                                                     .WithEfpValue(null)
                                                                                     .WithSubscribeManualCurveUpdates(true)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.EfpNarrative.EfpMonthItem = efpMonthItems[0];

            // ACT
            testObjects.ViewModel.ManualPriceCell.IsTradeable = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.EfpNarrative.IsValueValid, Is.True);
            Assert.That(testObjects.ViewModel.EfpNarrative.ValueError, Is.Null);
        }

        [Test]
        public void ShouldNotAllowManualCurveSubscribeUpdates_When_Disposed()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.0M)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .Build();
            testObjects.Controller.Dispose();

            testObjects.ViewModel.SubscribeManualCurveUpdates = true;

            // ACT
            testObjects.ViewModel.ManualPriceCell.MidPrice = 2.0M;

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualPriceCell.HasManualChange, Is.False);
        }

        [Test]
        public void ShouldDisposeServices_On_Dispose()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().WithIsTradeable(true)
                                                                                     .WithMidPriceServer(1.0M)
                                                                                     .WithMidPrice(1.0M)
                                                                                     .Build();
            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(p => p.Dispose());

            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Dispose());

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(p => p.Dispose());

            Mock.Get(testObjects.CoerceMarginEditValuesService)
                .Verify(p => p.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().Build();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(p => p.Dispose(), Times.Once);

            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Dispose(), Times.Once);

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(p => p.Dispose(), Times.Once);

            Mock.Get(testObjects.CoerceMarginEditValuesService)
                .Verify(p => p.Dispose(), Times.Once);
        }

        [Test]
        public void ShouldNotDispose_When_ViewModelDisposed()
        {
            var testObjects = new DailyPriceRowViewModelControllerTestObjectBuilder().Build();
            // ACT
            testObjects.ViewModel.Dispose();

            // ACT
            testObjects.ViewModel.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(p => p.Dispose(), Times.Once);

            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Dispose(), Times.Once);

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(p => p.Dispose(), Times.Once);

            Mock.Get(testObjects.CoerceMarginEditValuesService)
                .Verify(p => p.Dispose(), Times.Once);
        }
    }
}
