﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests
{
    internal class DailyPriceRowTestObjectBuilder
    {
        private bool _isBusinessDay;
        private DailyTenor _dailyTenor;
        private RowTenorType _rowTenorType;
        private bool _isWeeklyTenor;
        private decimal? _midPrice;
        private decimal? _midPriceManual;
        private decimal? _midPriceServer;
        private bool _priceHasManualChange;
        private bool _priceIsSelected;
        private bool _isPublisher;
        private bool _isPublisherEditor;
        private bool _isTradeable;
        private bool _isMandatory;
        private bool _isNew;
        private bool _isExtended;

        private bool _efpIsParent;
        private bool _efpIsChild;
        private bool _efpIsMonthValid;
        private bool _efpIsValueValid;
        private bool _efpShowBackupValues;
        private IList<EfpMonthItem> _efpMonthItems;
        private EfpMonthItem _efpMonthItem;
        private MonthlyTenor? _efpMonthServer;
        private MonthlyTenor? _efpMonthManual;
        private MonthlyTenor? _efpMonthBackup;
        private decimal? _efpValue;
        private decimal? _efpValueServer;
        private decimal? _efpValueManual;
        private decimal? _efpValueBackup;
        private bool _efpHasChanged;
        private bool _efpIsSelected;

        private bool _canApplyMargins;
        private bool _isMarginParent;
        private bool _isMarginChild;
        private bool _bidMarginHasChanged;
        private bool _askMarginHasChanged;
        private bool _marginChanged;
        private bool _hasMarginErrors;
        private decimal? _bidMarginEditValue;
        private decimal? _bidMarginValue;
        private decimal? _bidMarginServerValue;
        private decimal? _askMarginEditValue;
        private decimal? _askMarginValue;
        private decimal? _askMarginServerValue;

        private IList<LivePriceCell> _livePriceCells = new List<LivePriceCell>();

        private bool _subscribeManualCurveUpdates;
        private bool _subscribeTenorPeriodUpdates;

        public DailyPriceRowTestObjectBuilder WithIsBusinessDay(bool value)
        {
            _isBusinessDay = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithDailyTenor(DailyTenor value)
        {
            _dailyTenor = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithRowTenorType(RowTenorType value)
        {
            _rowTenorType = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithIsWeeklyTenor(bool value)
        {
            _isWeeklyTenor = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithMidPrice(decimal? value)
        {
            _midPrice = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithMidPriceManual(decimal? value)
        {
            _midPriceManual = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithMidPriceServer(decimal? value)
        {
            _midPriceServer = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithPriceHasManualChange(bool value)
        {
            _priceHasManualChange = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithPriceIsSelected(bool value)
        {
            _priceIsSelected = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithIsPublisher(bool value)
        {
            _isPublisher = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithIsPublisherEditor(bool value)
        {
            _isPublisherEditor = value;
            return this;
        }

		public DailyPriceRowTestObjectBuilder WithIsTradeable(bool value)
        {
            _isTradeable = value;
            return this;
        }
        public DailyPriceRowTestObjectBuilder WithIsMandatory(bool value)
        {
            _isMandatory = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithIsNew(bool value)
        {
            _isNew = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithIsExtended(bool value)
        {
            _isExtended = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpIsMonthValid(bool value)
        {
            _efpIsMonthValid = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpIsValueValid(bool value)
        {
            _efpIsValueValid = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpShowBackupValues(bool value)
        {
            _efpShowBackupValues = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpMonthItem(EfpMonthItem value)
        {
            _efpMonthItem = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpMonthItems(IList<EfpMonthItem> values)
        {
            _efpMonthItems = values;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpMonthServer(MonthlyTenor value)
        {
            _efpMonthServer = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpMonthManual(MonthlyTenor value)
        {
            _efpMonthManual = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpMonthBackup(MonthlyTenor value)
        {
            _efpMonthBackup = value;
            return this;
        }


        public DailyPriceRowTestObjectBuilder WithEfpValue(decimal value)
        {
            _efpValue = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpValueServer(decimal value)
        {
            _efpValueServer = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpValueManual(decimal value)
        {
            _efpValueManual = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpValueBackup(decimal value)
        {
            _efpValueBackup = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpHasChanged(bool value)
        {
            _efpHasChanged = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpIsParent(bool value)
        {
            _efpIsParent = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpIsChild(bool value)
        {
            _efpIsChild = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithEfpIsSelected(bool value)
        {
            _efpIsSelected = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithCanApplyMargins(bool value)
        {
            _canApplyMargins = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithIsMarginParent(bool value)
        {
            _isMarginParent = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithIsMarginChild(bool value)
        {
            _isMarginChild = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithBidMarginHasChanged(bool value)
        {
            _bidMarginHasChanged = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithMarginChanged(bool value)
        {
            _marginChanged = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithAskMarginHasChanged(bool value)
        {
            _askMarginHasChanged = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithHasMarginErrors(bool value)
        {
            _hasMarginErrors = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithBidMarginEditValue(decimal? value)
        {
            _bidMarginEditValue = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithBidMarginValue(decimal? value)
        {
            _bidMarginValue = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithBidMarginServerValue(decimal? value)
        {
            _bidMarginServerValue = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithAskMarginEditValue(decimal? value)
        {
            _askMarginEditValue = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithAskMarginValue(decimal? value)
        {
            _askMarginValue = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithAskMarginServerValue(decimal? value)
        {
            _askMarginServerValue = value;
            return this;
        }
        public DailyPriceRowTestObjectBuilder WithBidAskMarginEditValues(decimal? bid, decimal? ask)
        {
            _bidMarginEditValue = bid;
            _askMarginEditValue = ask;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithBidAskMarginValues(decimal? bid, decimal? ask)
        {
            _bidMarginValue = bid;
            _askMarginValue = ask;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithLivePriceCells(IList<LivePriceCell> values)
        {
            _livePriceCells = values;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithSubscribeManualCurveUpdates(bool value)
        {
            _subscribeManualCurveUpdates = value;
            return this;
        }

        public DailyPriceRowTestObjectBuilder WithSubscribeTenorPeriodUpdates(bool value)
        {
            _subscribeTenorPeriodUpdates = value;
            return this;
        }

		public DailyPriceRowViewModel Build()
        {
            var viewModel = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                RowTenorType = _rowTenorType,
                DailyTenor = _dailyTenor,
                IsWeeklyTenor = _isWeeklyTenor,
                IsPublisherEditor =  _isPublisherEditor,
                IsBusinessDay = _isBusinessDay,
                IsNewRow = _isNew,
                IsExtended = _isExtended,
                SubscribeManualCurveUpdates = _subscribeManualCurveUpdates,
                SubscribeTenorPremiumUpdates = _subscribeTenorPeriodUpdates,
                ManualPriceCell =
                {
                    IsPublisherEditor = _isPublisher,
                    IsTradeable = _isTradeable,
                    MidPrice = _midPrice,
                    HasManualChange = _priceHasManualChange,
                    IsSelected = _priceIsSelected
                },
                EfpNarrative =
                {
                    IsPublisherEditor = _isPublisher,
                    EfpMonthItems = _efpMonthItems,
                    EfpMonthItem = _efpMonthItem,
                    EfpMonthBackup = _efpMonthBackup,
                    EfpValue = _efpValue,
                    EfpValueBackup = _efpValueBackup,
                    ShowBackupValues = _efpShowBackupValues,
                    HasChanged = _efpHasChanged,
                    IsMonthValid = _efpIsMonthValid,
                    IsValueValid = _efpIsValueValid,
                    IsParent = _efpIsParent,
                    IsChild = _efpIsChild,
                    IsSelected = _efpIsSelected
                },
                TenorPremium =
                {
                    IsParent = _isMarginParent,
                    IsChild = _isMarginChild,
                    HasMarginErrors = _hasMarginErrors,
                    MarginChanged = _marginChanged,
                    BidMargin =
                    {
                        HasChanged = _bidMarginHasChanged,
                        Margin =
                        {
                            EditValue = _bidMarginEditValue,
                            Value = _bidMarginValue,
                            ServerValue = _bidMarginServerValue
                        }
                    },
                    AskMargin =
                    {
                        HasChanged = _askMarginHasChanged,
                        Margin =
                        {
                            EditValue = _askMarginEditValue,
                            Value = _askMarginValue,
                            ServerValue = _askMarginServerValue
                        }
                    }
                },

                LivePrices = new ObservableCollection<LivePriceCell>(_livePriceCells)
            };

            viewModel.Model().MidPriceManual = _midPriceManual;
            viewModel.Model().MidPriceServer = _midPriceServer;
            viewModel.Model().EfpMonthManual= _efpMonthManual;
            viewModel.Model().EfpMonthServer = _efpMonthServer;
            viewModel.Model().EfpValueManual = _efpValueManual;
            viewModel.Model().EfpValueServer = _efpValueServer;

            viewModel.ManualPriceCell.SetModel(viewModel.Model());
            viewModel.EfpNarrative.SetModel(viewModel.Model());
            viewModel.Model().IsMandatory = _isMandatory;
            viewModel.TenorPremium.Model().CanApplyMargins = _canApplyMargins;

            return viewModel;
        }
    }
}
