﻿using System;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.ViewModels.Bands
{
    [TestFixture]
    public class BandHeaderTests
    {
        [Test]
        public void ShouldGenerateManualCurveBandHeader()
        {
            var bandHeader = new BandHeader(new ManualCurveBandHeader(Mock.Of<IDisposable>()));

            // ASSERT
            Assert.That(bandHeader.BandHeaderType, Is.EqualTo(BandHeaderType.ManualCurveHeader));
            Assert.That(bandHeader.ManualCurveBandHeader, Is.Not.Null);
        }

        [Test]
        public void ShouldGenerateLivePriceBandHeader()
        {
            var bandHeader = new BandHeader(new LivePriceBandHeader());

            // ASSERT
            Assert.That(bandHeader.BandHeaderType, Is.EqualTo(BandHeaderType.LivePriceHeader));
            Assert.That(bandHeader.LivePriceBandHeader, Is.Not.Null);
        }

        [Test]
        public void ShouldGenerateTenorPremiumsBandHeader()
        {
            var bandHeader = new BandHeader(new TenorPremiumsBandHeader(Mock.Of<IDisposable>()));

            // ASSERT
            Assert.That(bandHeader.BandHeaderType, Is.EqualTo(BandHeaderType.TenorPremiumsHeader));
            Assert.That(bandHeader.TenorPremiumsBandHeader, Is.Not.Null);
        }

        [Test]
        public void ShouldGenerateTenorBandHeader()
        {
            var bandHeader = new BandHeader(BandHeaderType.TenorHeader);

            // ASSERT
            Assert.That(bandHeader.BandHeaderType, Is.EqualTo(BandHeaderType.TenorHeader));
        }

        [TestCase(BandHeaderType.ManualCurveHeader)]
        public void ShouldThrowArgumentException_When_Construct_With_NonTenorBandHeaderType(BandHeaderType bandHeaderType)
        {
            ArgumentException result = null;

            try
            {
                var bandHeader = new BandHeader(bandHeaderType);
            }
            catch (ArgumentException ex)
            {
                result = ex;
            }

            // ASSERT
            Assert.That(result, Is.Not.Null);
        }
    }
}
