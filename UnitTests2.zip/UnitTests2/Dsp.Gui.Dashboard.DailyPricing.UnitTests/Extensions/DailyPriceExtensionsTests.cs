﻿using System;
using Dsp.Gui.Dashboard.DailyPricing.Extensions;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Extensions
{
    [TestFixture]
    public class DailyPriceExtensionsTests
    {
        [Test]
        public void ShouldSetIsBusinessDay()
        {
            var dailyPriceRow = new DailyPriceRowViewModel(Mock.Of<IDisposable>());

            // ACT
            dailyPriceRow.SetIsBusinessDay(true);

            // ASSERT
            Assert.IsTrue(dailyPriceRow.IsBusinessDay);
            Assert.IsTrue(dailyPriceRow.TenorPremium.Model().CanApplyMargins);
        }

        [Test]
        public void ShouldSetMarginPrecision()
        {
            var dailyPriceRow = new DailyPriceRowViewModel(Mock.Of<IDisposable>());

            // ACT
            dailyPriceRow.SetMarginPrecision(2);

            // ASSERT
            Assert.AreEqual(2, dailyPriceRow.TenorPremium.BidMargin.Precision);
            Assert.AreEqual(2, dailyPriceRow.TenorPremium.AskMargin.Precision);
        }
    }
}
