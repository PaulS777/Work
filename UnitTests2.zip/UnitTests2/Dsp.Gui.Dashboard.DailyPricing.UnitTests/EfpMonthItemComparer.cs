﻿using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using System;
using System.Collections.Generic;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests
{
    internal class EfpMonthItemComparer : IEqualityComparer<EfpMonthItem>
    {
        public bool Equals(EfpMonthItem x, EfpMonthItem y)
        {
            if (ReferenceEquals(x, y))
            {
                return true;
            }

            if (ReferenceEquals(x, null))
            {
                return false;
            }

            if (ReferenceEquals(y, null))
            {
                return false;
            }

            if (x.GetType() != y.GetType())
            {
                return false;
            }

            return x.IsEnabled == y.IsEnabled && x.Tenor.Equals(y.Tenor);
        }

        public int GetHashCode(EfpMonthItem obj)
        {
            return HashCode.Combine(obj.Tenor, obj.IsEnabled);
        }
    }
}
