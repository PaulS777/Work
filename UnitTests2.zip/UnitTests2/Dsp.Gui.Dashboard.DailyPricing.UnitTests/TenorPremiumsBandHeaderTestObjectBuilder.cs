﻿using System;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Moq;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests
{
    internal class TenorPremiumsBandHeaderTestObjectBuilder
    {
        private bool _hasChanges;

        public TenorPremiumsBandHeaderTestObjectBuilder WithHasChanges(bool value)
        {
            _hasChanges = value;
            return this;
        }

        public TenorPremiumsBandHeader Build()
        {
            var band = new TenorPremiumsBandHeader(Mock.Of<IDisposable>());

            band.HasChanges = _hasChanges;

            return band;
        }
    }
}
