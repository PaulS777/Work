﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Dashboard.DailyPricing.Services.Clipboard;
using Dsp.Gui.Dashboard.DailyPricing.Services.DataSource;
using Dsp.Gui.Dashboard.DailyPricing.Services.Efp;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Clipboard
{
    internal interface IDailyPriceGridClipboardServiceTestObjects
    {
        IClipboardGetTextService ClipboardGetTextService { get; }
        ICalendarService CalendarService { get; }
        IDailyPriceGridBuilder GridBuilder { get; }
        IDailyPriceRowDataSource DataSource { get; }
        IDailyPriceRowDataSourceService DateSourceService { get; }
        ILogger Logger { get; }
        DailyPriceGridClipboardService DailyPriceGridClipboardService { get; }
    }

    [TestFixture]
    public class DailyPriceGridClipboardServiceTests
    {
        private class DailyPriceGridClipboardServiceTestObjectBuilder
        {
            private List<decimal?> _parsedPrices;
            private Exception _clipboardParserException;
            private int _additionalDayCount;
            private List<DailyPriceRowViewModel> _extendedRows;
            private List<DailyPriceRowViewModel> _dataSourceItems;
            private List<EfpMonthItem> _efpMonthItems;

            public DailyPriceGridClipboardServiceTestObjectBuilder WithParsedPrices(List<decimal?> values)
            {
                _parsedPrices = values;
                return this;
            }

            public DailyPriceGridClipboardServiceTestObjectBuilder WithClipboardParserException(Exception value)
            {
                _clipboardParserException = value;
                return this;
            }

            public DailyPriceGridClipboardServiceTestObjectBuilder WithAdditionalDayCount(int value)
            {
                _additionalDayCount = value;
                return this;
            }

            public DailyPriceGridClipboardServiceTestObjectBuilder WithExtendedRows(List<DailyPriceRowViewModel> values)
            {
                _extendedRows = values;
                return this;
            }

            public DailyPriceGridClipboardServiceTestObjectBuilder WithDataSourceItems(List<DailyPriceRowViewModel> values)
            {
                _dataSourceItems = values;
                return this;
            }

            public DailyPriceGridClipboardServiceTestObjectBuilder WithEfpMonthItems(List<EfpMonthItem> values)
            {
                _efpMonthItems = values;
                return this;
            }

            public IDailyPriceGridClipboardServiceTestObjects Build()
            {
                var testObjects = new Mock<IDailyPriceGridClipboardServiceTestObjects>();

                var clipboardGetTextService = new Mock<IClipboardGetTextService>();

                testObjects.SetupGet(o => o.ClipboardGetTextService)
                           .Returns(clipboardGetTextService.Object);

                var priceParser = new Mock<IDailyPriceClipboardParser>();

                if (_clipboardParserException != null)
                {
                    priceParser.Setup(p => p.GetPricesFromClipboardText(It.IsAny<string>()))
                               .Throws(_clipboardParserException);
                }
                else
                {
                    priceParser.Setup(p => p.GetPricesFromClipboardText(It.IsAny<string>()))
                               .Returns(_parsedPrices);
                }

                var calendarService = new Mock<ICalendarService>();

                calendarService.Setup(c => c.GetDayCountIncludingNonBusinessDays(It.IsAny<DateTime>(), It.IsAny<int>()))
                               .Returns(_additionalDayCount);

                testObjects.SetupGet(o => o.CalendarService)
                           .Returns(calendarService.Object);

                var efpMonthItemsProvider = new Mock<IEfpMonthItemsProvider>();

                efpMonthItemsProvider.Setup(p => p.EfpMonthItemsSnapshot())
                                     .Returns(_efpMonthItems);

                var gridBuilder = new Mock<IDailyPriceGridBuilder>();

                gridBuilder.Setup(b => b.GetExtendedDailyPriceRows(It.IsAny<IList<DailyPriceRowViewModel>>(),
                                                                   It.IsAny<IList<EfpMonthItem>>(),
                                                                   It.IsAny<int>()))
                           .Returns(_extendedRows);

                testObjects.SetupGet(o => o.GridBuilder)
                           .Returns(gridBuilder.Object);

                var dataSource = new Mock<IDailyPriceRowDataSource>();

                dataSource.Setup(d => d.Items())
                          .Returns(_dataSourceItems);

                dataSource.Setup(d => d.AddItems(It.IsAny<List<DailyPriceRowViewModel>>()))
                          .Callback(() => _dataSourceItems.AddRange(_extendedRows));

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var dataSourceService = new Mock<IDailyPriceRowDataSourceService>();

                dataSourceService.SetupGet(d => d.DataSource)
                                 .Returns(dataSource.Object);

                testObjects.SetupGet(o => o.DateSourceService)
                           .Returns(dataSourceService.Object);

                var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

                var loggerFactory = new Mock<ILoggerFactory>();
         
                loggerFactory.Setup(f => f.Create(It.IsAny<Type>())).Returns(logger.Object);

                var dailyPriceClipboardService = new DailyPriceGridClipboardService(priceParser.Object,
                                                                                    clipboardGetTextService.Object,
                                                                                    calendarService.Object,
                                                                                    gridBuilder.Object,
                                                                                    efpMonthItemsProvider.Object,
                                                                                    loggerFactory.Object)
                                                 {
                                                     DataSourceService = dataSourceService.Object
                                                 };

                testObjects.SetupGet(o => o.DailyPriceGridClipboardService)
                           .Returns(dailyPriceClipboardService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetClipboardTextFromClipboardService()
        {
            var selectedRow = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
                              {
                                  RowTenorType = RowTenorType.Daily, 
                                  DailyTenor = new DailyTenor(2021, 1, 1)
                              };

            var dailyPrices = new List<DailyPriceRowViewModel> { selectedRow };

            var testObjects = new DailyPriceGridClipboardServiceTestObjectBuilder().WithDataSourceItems(dailyPrices)
                                                                                   .Build();

            // ACT
            testObjects.DailyPriceGridClipboardService.TryUpdatePricesFromClipboard(selectedRow);

            // ASSERT
            Mock.Get(testObjects.ClipboardGetTextService)
                .Verify(c => c.GetClipboardText());
        }

        [Test]
        public void ShouldLogWarningAndReturnFalse_When_ClipboardParserException()
        {
            var tenorDate = new DateTime(2021, 1, 1);

            var selectedRow = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
                              {
                                  RowTenorType = RowTenorType.Daily, 
                                  DailyTenor = new DailyTenor(tenorDate)
                              };

            var dailyPrices = new List<DailyPriceRowViewModel> { selectedRow };
            var parseException = new Exception("failed");

            var testObjects = new DailyPriceGridClipboardServiceTestObjectBuilder().WithDataSourceItems(dailyPrices)
                                                                                   .WithClipboardParserException(parseException)
                                                                                   .Build();

            // ACT
            var result = testObjects.DailyPriceGridClipboardService.TryUpdatePricesFromClipboard(selectedRow);

            // ASSERT
            Assert.That(result, Is.False);

            Mock.Get(testObjects.Logger)
                .Verify(log => log.Warn(It.IsAny<string>()));
        }

        [Test]
        public void ShouldNotExtendGrid_When_UpdatePricesFromClipboard_With_ClipboardRangeWithinPriceRange()
        {
            var tenorDate = new DateTime(2021, 1, 1);

            var selectedRow = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
                              {
                                  RowTenorType = RowTenorType.Daily, 
                                  IsBusinessDay = true,
                                  DailyTenor = new DailyTenor(tenorDate)
                              };

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    IsBusinessDay = true,
                    ManualPriceCell = { MidPrice = 0.5M}
                },
                selectedRow,
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    IsBusinessDay = true
                }
            };

            var parsedPrices = new List<decimal?>
                               {
                                   1.1M, 1.2M
                               };

            var testObjects = new DailyPriceGridClipboardServiceTestObjectBuilder().WithDataSourceItems(dailyPrices)
                                                                                   .WithParsedPrices(parsedPrices)
                                                                                   .Build();
            // ACT
            var result = testObjects.DailyPriceGridClipboardService.TryUpdatePricesFromClipboard(selectedRow);

            // ASSERT
            Mock.Get(testObjects.GridBuilder)
                .Verify(b => b.GetExtendedDailyPriceRows(It.IsAny<List<DailyPriceRowViewModel>>(), 
                                                         It.IsAny<IList<EfpMonthItem>>(),
                                                         It.IsAny<int>()), 
                        Times.Never);

            Assert.That(result, Is.True);

            Assert.That(dailyPrices[0].ManualPriceCell.MidPrice, Is.EqualTo(0.5M));
            Assert.That(dailyPrices[1].ManualPriceCell.MidPrice, Is.EqualTo(1.1M));
            Assert.That(dailyPrices[2].ManualPriceCell.MidPrice, Is.EqualTo(1.2M));
        }

        [Test]
        public void ShouldIgnoreWeeklyTenors_When_UpdatePricesFromClipboard()
        {
            var tenorDate = new DateTime(2021, 1, 1);

            var selectedRow = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
                              {
                                  RowTenorType = RowTenorType.Daily, 
                                  DailyTenor = new DailyTenor(tenorDate),
                                  IsBusinessDay = true
                              };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  new(Mock.Of<IDisposable>())
                                  {
                                      RowTenorType = RowTenorType.Daily, 
                                      IsBusinessDay = true,
                                      ManualPriceCell = { MidPrice = 0.5M}
                                  },
                                  selectedRow,
                                  new(Mock.Of<IDisposable>())
                                  {
                                      RowTenorType = RowTenorType.Weekly
                                  },
                                  new(Mock.Of<IDisposable>())
                                  {
                                      RowTenorType = RowTenorType.Daily,
                                      IsBusinessDay = true
                                  }
                              };

            var parsedPrices = new List<decimal?> { 1.1M, 1.2M };

            var testObjects = new DailyPriceGridClipboardServiceTestObjectBuilder().WithDataSourceItems(dailyPrices)
                                                                                   .WithParsedPrices(parsedPrices)
                                                                                   .Build();
            // ACT
            var result = testObjects.DailyPriceGridClipboardService.TryUpdatePricesFromClipboard(selectedRow);

            // ASSERT
            Assert.That(result, Is.True);

            Assert.That(dailyPrices[0].ManualPriceCell.MidPrice, Is.EqualTo(0.5M));
            Assert.That(dailyPrices[1].ManualPriceCell.MidPrice, Is.EqualTo(1.1M));
            Assert.That(dailyPrices[2].ManualPriceCell.MidPrice, Is.Null);
            Assert.That(dailyPrices[3].ManualPriceCell.MidPrice, Is.EqualTo(1.2M));
        }


        [Test]
        public void ShouldExtendGrid_When_ClipboardRange_Exceeds_GridPrices()
        {
            var tenorDate1 = new DateTime(2023, 7, 6); // thu
            var tenorDate2 = new DateTime(2023, 7, 7); // fri - selected
            var tenorDate3 = new DateTime(2021, 7, 10); // mon - last grid
            var tenorDate4 = new DateTime(2021, 7, 11); // tue - extended

            var selectedRow = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                RowTenorType = RowTenorType.Daily,
                DailyTenor = new DailyTenor(tenorDate2),
                IsBusinessDay = true
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(tenorDate1),
                    IsBusinessDay = true,
                    ManualPriceCell = { MidPrice = 0.5M}
                },
                selectedRow,
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Weekly
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(tenorDate3),
                    IsBusinessDay = true
                }
            };

            var parsedPrices = new List<decimal?>
                               {
                                   1.1M, 1.2M, 1.3M
                               };

            var extendedRows = new List<DailyPriceRowViewModel>
                               {
                                   new(Mock.Of<IDisposable>())
                                   {
                                       RowTenorType = RowTenorType.Daily,
                                       IsBusinessDay = true
                                   }
                               };

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(new MonthlyTenor(2023, 1), true)
                                };

            var testObjects = new DailyPriceGridClipboardServiceTestObjectBuilder().WithDataSourceItems(dailyPrices)
                                                                                   .WithParsedPrices(parsedPrices)
                                                                                   .WithAdditionalDayCount(1) 
                                                                                   .WithExtendedRows(extendedRows)
                                                                                   .WithEfpMonthItems(efpMonthItems)
                                                                                   .Build();
            // ACT5
            var result = testObjects.DailyPriceGridClipboardService.TryUpdatePricesFromClipboard(selectedRow);

            // ASSERT
            Assert.That(result, Is.True);

            Mock.Get(testObjects.CalendarService)
                .Verify(c => c.GetDayCountIncludingNonBusinessDays(tenorDate4, 1));

            Mock.Get(testObjects.GridBuilder)
                .Verify(b => b.GetExtendedDailyPriceRows(It.Is<List<DailyPriceRowViewModel>>(rows => rows.Count == 4), 
                                                         efpMonthItems, 
                                                         1));

            Mock.Get(testObjects.DataSource)
                .Verify(d => d.AddItems(It.Is<List<DailyPriceRowViewModel>>(rows => rows.Count == 1)));

            Assert.That(dailyPrices[0].ManualPriceCell.MidPrice, Is.EqualTo(0.5M)); // unchanged
            Assert.That(dailyPrices[1].ManualPriceCell.MidPrice, Is.EqualTo(1.1M)); // selected cell
            // weekend 
            Assert.That(dailyPrices[3].ManualPriceCell.MidPrice, Is.EqualTo(1.2M)); // updated
            Assert.That(dailyPrices[4].ManualPriceCell.MidPrice, Is.EqualTo(1.3M)); // extended

        }

        [Test]
        public void ShouldIgnoreWeeklyTenors_When_UpdateGridPricesFromClipboard_With_ExtendedRows()
        {
            var tenorDate = new DateTime(2021, 1, 1);

            var selectedRow = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                RowTenorType = RowTenorType.Daily,
                DailyTenor = new DailyTenor(tenorDate),
                IsBusinessDay = true
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                    {
                        RowTenorType  = RowTenorType.Daily,
                        IsBusinessDay = true,
                        ManualPriceCell = { MidPrice = 0.5M}
                    },
                selectedRow,
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    IsBusinessDay = true
                }
            };

            var parsedPrices = new List<decimal?> { 1.1M, 1.2M, 1.3M };

            var extendedRows = new List<DailyPriceRowViewModel>
                               {
                                   new(Mock.Of<IDisposable>())
                                   {
                                       RowTenorType = RowTenorType.Weekly
                                   },
                                   new(Mock.Of<IDisposable>())
                                   {
                                       RowTenorType = RowTenorType.Daily,
                                       IsBusinessDay = true
                                   }
                               };

            var testObjects = new DailyPriceGridClipboardServiceTestObjectBuilder().WithDataSourceItems(dailyPrices)
                                                                                   .WithParsedPrices(parsedPrices)
                                                                                   .WithExtendedRows(extendedRows)
                                                                                   .Build();
            // ACT
            var result = testObjects.DailyPriceGridClipboardService.TryUpdatePricesFromClipboard(selectedRow);

            // ASSERT
            Assert.That(result, Is.True);
            Assert.That(dailyPrices.Count, Is.EqualTo(5));
            Assert.That(dailyPrices[3].ManualPriceCell.MidPrice, Is.Null);
            Assert.That(dailyPrices[4].ManualPriceCell.MidPrice, Is.EqualTo(1.3M));
        }
    }
}
