﻿using System;
using Dsp.Gui.Dashboard.DailyPricing.Services.Clipboard;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Clipboard
{
    [TestFixture]
    internal class DailyPriceClipboardParserTests
    {
        [Test]
        public void ShouldGetPricesFromClipboardText()
        {
            const string text = "2.25\r\n2.35\r\n";
            var clipboardParser = new DailyPriceClipboardParser();

            // ACT
            var prices = clipboardParser.GetPricesFromClipboardText(text);

            // ASSERT
            Assert.That(prices.Count, Is.EqualTo(2));
            Assert.That(prices[0], Is.EqualTo(2.25));
            Assert.That(prices[1], Is.EqualTo(2.35));
        }

        [Test]
        public void ShouldThrowExceptionIfClipboardTextContainsInvalidNumber()
        {
            Exception result = null;

            try
            {
                const string text = "2.25\r\n\r\nX";
                var clipboardParser = new DailyPriceClipboardParser();

                // ACT
                clipboardParser.GetPricesFromClipboardText(text);
            }
            catch (Exception ex)
            {
                result = ex;
            }
            
            Assert.IsNotNull(result);
        }

        [Test]
        public void ShouldParseSpacesAsNullPrices()
        {
            const string text = "2.25\r\n\r\n   \r\n2.35\r\n";
            var clipboardParser = new DailyPriceClipboardParser();

            // ACT
            var prices = clipboardParser.GetPricesFromClipboardText(text);

            // ASSERT
            Assert.That(prices.Count, Is.EqualTo(4));
            Assert.That(prices[0], Is.EqualTo(2.25));
            Assert.IsNull(prices[1]);
            Assert.IsNull(prices[2]);
            Assert.That(prices[3], Is.EqualTo(2.35));
        }

    }
}
