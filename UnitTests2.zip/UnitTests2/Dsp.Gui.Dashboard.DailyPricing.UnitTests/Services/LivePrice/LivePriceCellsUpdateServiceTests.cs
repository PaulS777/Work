﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.LivePrice;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.LivePrice
{
    internal interface ILivePriceCellsUpdateServiceTestObjects
    {
        IDispatcherExecutionService DispatcherExecutionService { get; }
        LivePriceCellsUpdateService LivePriceCellsUpdateService { get; }
    }

    [TestFixture]
    public class LivePriceCellsUpdateServiceTests
    {
        private class LivePriceCellsUpdateServiceTestObjectBuilder
        {
            public ILivePriceCellsUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceCellsUpdateServiceTestObjects>();

                var dispatcher = new Mock<IDispatcherExecutionService>();

                dispatcher.Setup(d => d.Schedule(It.IsAny<Action>()))
                          .Callback<Action>(action => action());

                testObjects.SetupGet(o => o.DispatcherExecutionService)
                           .Returns(dispatcher.Object);

                var livePriceCellsUpdateService = new LivePriceCellsUpdateService();

                testObjects.SetupGet(o => o.LivePriceCellsUpdateService)
                           .Returns(livePriceCellsUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdatePriceCellInfo_And_ScheduleDispatcher_When_PriceCurveContains_PriceMatchOnWeeklyTenor()
        {
            var week = new WeeklyTenor(2023, 8);
            var timestamp = new DateTime(2023, 7, 11);
            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new LivePriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Weekly)
                                                                .WithCurveId(curveId)
                                                                .WithTenor(week)
                                                                .WithIsStale(true)
                                                                .Build();

            var priceCells = new[] { priceCell };

            var weeklyPrices = new TenorPrices<WeeklyTenor>(new List<WeeklyTenor> { week },
                                                            null,
                                                            new List<double?> { 1.1 },
                                                            null,
                                                            null);

            var priceCurve = new PriceCurveBuilder().WithWeeklyPrices(weeklyPrices)
                                                    .WithTimestamp(timestamp)
                                                    .WithValidityIndicator(ValidityIndicator.Valid)
                                                    .Build();

            var testObjects = new LivePriceCellsUpdateServiceTestObjectBuilder().Build();

            var dispatcher = new Mock<IDispatcherExecutionService>();

            // ACT
            testObjects.LivePriceCellsUpdateService.UpdatePriceCells(priceCells, 
                                                                     priceCurve, 
                                                                     dispatcher.Object);

            // ASSERT
            Assert.That(priceCell.Info().MidPrice, Is.EqualTo(1.1));
            Assert.That(priceCell.Info().Timestamp, Is.EqualTo(timestamp));
            Assert.That(priceCell.ToolTip, Is.Not.Null);

            Assert.That(priceCell.MidPrice, Is.Null);
            Assert.That(priceCell.IsStale, Is.True);

            dispatcher.Verify(d => d.Schedule(It.IsAny<Action>()), Times.Exactly(2));
        }

        [Test]
        public void ShouldUpdatePriceCellInfo_And_ScheduleDispatcher_When_PriceCurveContains_PriceMatchOnDailyTenor()
        {
            var day = new DailyTenor(2023, 8, 2);
            var timestamp = new DateTime(2023, 7, 11);
            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new LivePriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Daily)
                                                                .WithCurveId(curveId)
                                                                .WithTenor(day)
                                                                .WithIsStale(true)
                                                                .Build();

            var priceCells = new[] { priceCell };

            var dailyPrices = new TenorPrices<DailyTenor>(new List<DailyTenor> { day },
                                                          null,
                                                          new List<double?> { 1.2 },
                                                          null,
                                                          null);

            var priceCurve = new PriceCurveBuilder().WithDailyPrices(dailyPrices)
                                                    .WithTimestamp(timestamp)
                                                    .WithValidityIndicator(ValidityIndicator.Valid)
                                                    .Build();

            var testObjects = new LivePriceCellsUpdateServiceTestObjectBuilder().Build();

            var dispatcher = new Mock<IDispatcherExecutionService>();

            // ACT
            testObjects.LivePriceCellsUpdateService.UpdatePriceCells(priceCells,
                                                                     priceCurve,
                                                                     dispatcher.Object);

            // ASSERT
            Assert.That(priceCell.Info().MidPrice, Is.EqualTo(1.2));
            Assert.That(priceCell.Info().Timestamp, Is.EqualTo(timestamp));
            Assert.That(priceCell.ToolTip, Is.Not.Null);

            Assert.That(priceCell.MidPrice, Is.Null);
            Assert.That(priceCell.IsStale, Is.True);

            dispatcher.Verify(d => d.Schedule(It.IsAny<Action>()), Times.Exactly(2));
        }

        [Test]
        public void ShouldScheduleWeeklyPriceCellUpdatesOnDispatcher()
        {
            var week = new WeeklyTenor(2023, 8);
            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new LivePriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Weekly)
                                                                .WithCurveId(curveId)
                                                                .WithTenor(week)
                                                                .WithIsStale(true)
                                                                .Build();

            var priceCells = new[] { priceCell };

            var weeklyPrices = new TenorPrices<WeeklyTenor>(new List<WeeklyTenor> { week },
                                                            null,
                                                            new List<double?> { 1.1 },
															null,
															null);

            var priceCurve = new PriceCurveBuilder().WithWeeklyPrices(weeklyPrices)
                                                    .WithValidityIndicator(ValidityIndicator.Valid)
                                                    .Build();

            var testObjects = new LivePriceCellsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.LivePriceCellsUpdateService.UpdatePriceCells(priceCells,
                                                                     priceCurve,
                                                                     testObjects.DispatcherExecutionService);

            // ASSERT
            Assert.That(priceCell.MidPrice, Is.EqualTo(1.1));
            Assert.That(priceCell.IsStale, Is.False);
        }

        [Test]
        public void ShouldScheduleDailyPriceCellUpdatesOnDispatcher()
        {
            var day = new DailyTenor(2023, 8, 2);
            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new LivePriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Daily)
                                                                .WithCurveId(curveId)
                                                                .WithTenor(day)
                                                                .WithIsStale(true)
                                                                .Build();

            var priceCells = new[] { priceCell };

            var dailyPrices = new TenorPrices<DailyTenor>(new List<DailyTenor> { day },
                                                          null,
                                                          new List<double?> { 1.2 },
														  null,
														  null);

            var priceCurve = new PriceCurveBuilder().WithDailyPrices(dailyPrices)
                                                    .WithValidityIndicator(ValidityIndicator.Valid)
                                                    .Build();

            var testObjects = new LivePriceCellsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.LivePriceCellsUpdateService.UpdatePriceCells(priceCells,
                                                                     priceCurve,
                                                                     testObjects.DispatcherExecutionService);

            // ASSERT
            Assert.That(priceCell.MidPrice, Is.EqualTo(1.2));
            Assert.That(priceCell.IsStale, Is.False);
        }

        [Test]
        public void ShouldClearPriceCells_When_PriceDoesNotContainMatchingTenor()
        {
            var week1 = new WeeklyTenor(2023, 8);
            var day1 = new DailyTenor(2023, 8, 2);
            var week2 = new WeeklyTenor(2023, 9);
            var day2 = new DailyTenor(2023, 9, 2);
            var timestamp = new DateTime(2023, 7, 11);

            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCellWeekly = new LivePriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Weekly)
                                                                      .WithCurveId(curveId)
                                                                      .WithTenor(week1)
                                                                      .WithMidPrice(1.1)
                                                                      .WithInfoMidPrice(1.1)
                                                                      .WithIsStale(true)
                                                                      .WithInfoIsStale(true)
                                                                      .WithPriceDirection(PriceDirection.Up)
                                                                      .Build();

            var priceCellDaily = new LivePriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Daily)
                                                                     .WithCurveId(curveId)
                                                                     .WithTenor(day1)
                                                                     .WithMidPrice(1.2)
                                                                     .WithInfoMidPrice(1.2)
                                                                     .WithIsStale(true)
                                                                     .WithInfoIsStale(true)
                                                                     .WithPriceDirection(PriceDirection.Up)
                                                                     .Build();

            var priceCells = new[] { priceCellWeekly, priceCellDaily };

            var weeklyPrices = new TenorPrices<WeeklyTenor>(new List<WeeklyTenor> { week2 },
                                                            null,
                                                            new List<double?> { 1.1 },
															null,
															null);

            var dailyPrices = new TenorPrices<DailyTenor>(new List<DailyTenor> { day2 },
                                                          null,
                                                          new List<double?> { 1.2 },
														  null,
														  null);

            var priceCurve = new PriceCurveBuilder().WithWeeklyPrices(weeklyPrices)
                                                    .WithDailyPrices(dailyPrices)
                                                    .WithTimestamp(timestamp)
                                                    .WithValidityIndicator(ValidityIndicator.Valid)
                                                    .Build();

            var testObjects = new LivePriceCellsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.LivePriceCellsUpdateService.UpdatePriceCells(priceCells,
                                                                     priceCurve,
                                                                     testObjects.DispatcherExecutionService);

            // ASSERT
            Assert.That(priceCellWeekly.Info().MidPrice, Is.Null);
            Assert.That(priceCellWeekly.Info().IsStale, Is.False);
            Assert.That(priceCellWeekly.Info().Timestamp, Is.Null);
            Assert.That(priceCellWeekly.MidPrice, Is.Null);
            Assert.That(priceCellWeekly.PriceDirection, Is.EqualTo(PriceDirection.None));
            Assert.That(priceCellWeekly.IsStale, Is.False);
            Assert.That(priceCellWeekly.ToolTip, Is.Null);

            Assert.That(priceCellDaily.Info().MidPrice, Is.Null);
            Assert.That(priceCellDaily.Info().IsStale, Is.False);
            Assert.That(priceCellDaily.Info().Timestamp, Is.Null);
            Assert.That(priceCellDaily.MidPrice, Is.Null);
            Assert.That(priceCellDaily.PriceDirection, Is.EqualTo(PriceDirection.None));
            Assert.That(priceCellDaily.IsStale, Is.False);
            Assert.That(priceCellDaily.ToolTip, Is.Null);
        }

        [Test]
        public void ShouldSetPriceDirectionUp_When_PriceCellUpdate_With_GreaterThanPrevious()
        {
            var week = new WeeklyTenor(2023, 8);
            var timestamp = new DateTime(2023, 7, 11);

            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCellWeekly = new LivePriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Weekly)
                                                                      .WithCurveId(curveId)
                                                                      .WithTenor(week)
                                                                      .WithMidPrice(1.1)
                                                                      .WithInfoMidPrice(1.1)
                                                                      .Build();

            var priceCells = new[] { priceCellWeekly };

            var weeklyPrices = new TenorPrices<WeeklyTenor>(new List<WeeklyTenor> { week },
                                                            null,
                                                            new List<double?> { 1.3 },
															null,
															null);

            var priceCurve = new PriceCurveBuilder().WithWeeklyPrices(weeklyPrices)
                                                    .WithTimestamp(timestamp)
                                                    .WithValidityIndicator(ValidityIndicator.Valid)
                                                    .Build();

            var testObjects = new LivePriceCellsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.LivePriceCellsUpdateService.UpdatePriceCells(priceCells,
                                                                     priceCurve,
                                                                     testObjects.DispatcherExecutionService);

            // ASSERT
            Assert.That(priceCellWeekly.Info().PriceDirection, Is.EqualTo(PriceDirection.Up));
            Assert.That(priceCellWeekly.PriceDirection, Is.EqualTo(PriceDirection.Up));
        }

        [Test]
        public void ShouldSetPriceDirectionDown_When_PriceCellUpdate_With_LessThanPrevious()
        {
            var week = new WeeklyTenor(2023, 8);
            var timestamp = new DateTime(2023, 7, 11);

            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCellWeekly = new LivePriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Weekly)
                                                                      .WithCurveId(curveId)
                                                                      .WithTenor(week)
                                                                      .WithMidPrice(1.1)
                                                                      .WithInfoMidPrice(1.1)
                                                                      .Build();

            var priceCells = new[] { priceCellWeekly };

            var weeklyPrices = new TenorPrices<WeeklyTenor>(new List<WeeklyTenor> { week },
                                                            null,
                                                            new List<double?> { 0.9 },
															null,
															null);

            var priceCurve = new PriceCurveBuilder().WithWeeklyPrices(weeklyPrices)
                                                    .WithTimestamp(timestamp)
                                                    .WithValidityIndicator(ValidityIndicator.Valid)
                                                    .Build();

            var testObjects = new LivePriceCellsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.LivePriceCellsUpdateService.UpdatePriceCells(priceCells,
                                                                     priceCurve,
                                                                     testObjects.DispatcherExecutionService);

            // ASSERT
            Assert.That(priceCellWeekly.Info().PriceDirection, Is.EqualTo(PriceDirection.Down));
            Assert.That(priceCellWeekly.PriceDirection, Is.EqualTo(PriceDirection.Down));
        }
    }
}
