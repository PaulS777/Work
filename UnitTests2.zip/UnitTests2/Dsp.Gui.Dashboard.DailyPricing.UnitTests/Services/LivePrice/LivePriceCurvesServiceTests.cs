﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.LivePrice;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.LivePrice
{
    internal interface ILivePriceCurvesServiceTestObjects
    {
        ISubject<List<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        ILivePriceStreamSubscriptionService LivePriceStreamSubscriptionService { get; }
        ISubject<List<ILivePriceStreamService>> LivePriceStreams { get; }
        LivePriceCurvesService LivePriceCurvesService { get; }
    }

    [TestFixture]
    public class LivePriceCurvesServiceTests
    {
        private class LivePriceCurvesServiceTestObjectBuilder
        {
            private List<PriceCurveDefinition> _priceCurveDefinitions;

            public LivePriceCurvesServiceTestObjectBuilder WithPriceCurveDefinitions(List<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public ILivePriceCurvesServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceCurvesServiceTestObjects>();

                var priceCurveDefinitions = new BehaviorSubject<List<PriceCurveDefinition>>(_priceCurveDefinitions);

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurveDefinitions);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.PriceCurveDefinitions)
                                   .Returns(priceCurveDefinitions);

                var livePriceStreams = new Subject<List<ILivePriceStreamService>>();

                testObjects.SetupGet(o => o.LivePriceStreams)
                           .Returns(livePriceStreams);

                var livePriceStreamSubscriptionService = new Mock<ILivePriceStreamSubscriptionService>();

                livePriceStreamSubscriptionService.Setup(s => s.RefreshPriceStreams(It.IsAny<IList<PriceCurveDetails>>(), 
                                                                                    It.IsAny<bool>()))
                                                  .Returns(livePriceStreams);

                testObjects.SetupGet(o => o.LivePriceStreamSubscriptionService)
                           .Returns(livePriceStreamSubscriptionService.Object);

                var livePriceCurveService = new LivePriceCurvesService(curveControlService.Object,
                                                                       livePriceStreamSubscriptionService.Object);

                testObjects.SetupGet(o => o.LivePriceCurvesService)
                           .Returns(livePriceCurveService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldRefreshPriceStreams_With_LiveCurvesMatchedOn_Id_Or_MarginParentCurveId()
        {
            var parentId = 100;
            var monthlyId = 201;

            var crude = new CurveGroupTestObjectBuilder().Crude();

			var parentCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(parentId)
                                                                                   .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                                   .WithName("curve-1")
                                                                                   .WithProductCurveGroup(crude)
                                                                                   .WithProductPrecision(2)
                                                                                   .Build();

            var childCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                                  .WithName("curve-2")
                                                                                  .WithProductCurveGroup(crude)
                                                                                  .WithProductPrecision(2)
                                                                                  .WithMarginParentCurveId(parentId)
                                                                                  .Build();

            var dailyCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                                  .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                                  .WithName("curve-3")
                                                                                  .WithProductCurveGroup(crude)
                                                                                  .WithProductPrecision(2)
                                                                                  .Build();

            var monthlyCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(monthlyId)
                                                                                     .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                                     .WithName("curve-4")
                                                                                     .WithProductCurveGroup(crude)
                                                                                     .WithProductPrecision(2)
                                                                                     .Build();

            var monthlyCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(202)
                                                                                     .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                                     .Build();

            var curveDefinitions = new List<PriceCurveDefinition>
                                   {
                                       dailyCurveDefinition, 
                                       parentCurveDefinition, 
                                       childCurveDefinition, 
                                       monthlyCurveDefinition1, 
                                       monthlyCurveDefinition2
                                   };

            var testObjects = new LivePriceCurvesServiceTestObjectBuilder().WithPriceCurveDefinitions(curveDefinitions)
                                                                           .Build();

            var expectedDetails = new PriceCurveDetails[]
                                  {
                                      new(PriceCurveType.Live, new LinkedCurve(parentId, PriceCurveDefinitionType.PriceCurve), 2)
                                      {
                                          Name = "curve-1", CurveGroup = crude, TenorType = TenorType.Day
                                      } ,
                                      new(PriceCurveType.Live, new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 2)
                                      {
                                          Name = "curve-2", CurveGroup = crude, TenorType = TenorType.Day
                                      },
                                      new(PriceCurveType.Live, new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 2)
                                      {
                                          Name = "curve-3", CurveGroup = crude, TenorType = TenorType.Day
                                      },
                                      new(PriceCurveType.Live, new LinkedCurve(monthlyId, PriceCurveDefinitionType.PriceCurve), 2)
                                      {
                                          Name = "curve-4", CurveGroup = crude, TenorType = TenorType.Month
                                      }
                                  };

            // ACT
            var livePrices = testObjects.LivePriceCurvesService.GenerateLivePrices(parentId, monthlyId);

            using (livePrices.Subscribe(_ => {}))
            {
                // ASSERT
                Mock.Get(testObjects.LivePriceStreamSubscriptionService)
                    .Verify(s => s.RefreshPriceStreams(It.Is<IList<PriceCurveDetails>>(d => d.SequenceEqual(expectedDetails)), true));
            }
        }

        [Test]
        public void ShouldShareStreamSubscriptions_Across_MultipleSubscribers()
        {
            var parentId = 100;
            var monthlyId = 201;

            var crude = new CurveGroupTestObjectBuilder().Crude();

			var parentCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(parentId)
                                                                                   .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                                   .WithName("curve-1")
                                                                                   .WithProductCurveGroup(crude)
                                                                                   .WithProductPrecision(2)
                                                                                   .Build();

            var childCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                                  .WithName("curve-2")
                                                                                  .WithProductCurveGroup(crude)
                                                                                  .WithProductPrecision(2)
                                                                                  .WithMarginParentCurveId(parentId)
                                                                                  .Build();

            var dailyCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                                  .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                                  .WithName("curve-3")
                                                                                  .WithProductCurveGroup(crude)
                                                                                  .WithProductPrecision(2)
                                                                                  .Build();

            var monthlyCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(monthlyId)
                                                                                     .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                                     .WithName("curve-4")
                                                                                     .WithProductCurveGroup(crude)
                                                                                     .WithProductPrecision(2)
                                                                                     .Build();

            var monthlyCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(202)
                                                                                     .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                                     .Build();

            var curveDefinitions = new List<PriceCurveDefinition>
                                   {
                                       dailyCurveDefinition,
                                       parentCurveDefinition,
                                       childCurveDefinition,
                                       monthlyCurveDefinition1,
                                       monthlyCurveDefinition2
                                   };

            var testObjects = new LivePriceCurvesServiceTestObjectBuilder().WithPriceCurveDefinitions(curveDefinitions)
                                                                           .Build();

            var livePrices = testObjects.LivePriceCurvesService.GenerateLivePrices(parentId, monthlyId);

            var disposable1 = livePrices.Subscribe(_ => { });

            // ACT
            var disposable2 = livePrices.Subscribe(_ => { });

            // ASSERT
            Mock.Get(testObjects.LivePriceStreamSubscriptionService)
                .Verify(s => s.RefreshPriceStreams(It.IsAny<IList<PriceCurveDetails>>(), true), Times.Once);

            disposable1.Dispose();
            disposable2.Dispose();
        }

        [Test]
        public void ShouldNotRefreshStreams_After_FirstRefresh()
        {
            var parentId = 100;

            var parentCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(parentId)
                                                                                   .Build();

            var childCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithMarginParentCurveId(parentId)
                                                                                  .Build();

            var nonMatchedCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

            var curveDefinitions = new List<PriceCurveDefinition>
                                   {
                                       parentCurveDefinition, childCurveDefinition, nonMatchedCurveDefinition
                                   };

            var testObjects = new LivePriceCurvesServiceTestObjectBuilder().WithPriceCurveDefinitions(curveDefinitions)
                                                                           .Build();

            var livePrices = testObjects.LivePriceCurvesService.GenerateLivePrices(parentId, 201);

            using (livePrices.Subscribe(_ => { }))
            {
                Mock.Get(testObjects.LivePriceStreamSubscriptionService).Invocations.Clear();

                var update = new List<PriceCurveDefinition> 
                             {
                                 parentCurveDefinition, childCurveDefinition, nonMatchedCurveDefinition, new PriceCurveDefinitionTestObjectBuilder().Build()
                             };

                // ACT
                testObjects.PriceCurveDefinitions.OnNext(update);

                // ASSERT
                Mock.Get(testObjects.LivePriceStreamSubscriptionService)
                    .Verify(s => s.RefreshPriceStreams(It.IsAny<IList<PriceCurveDetails>>(), It.IsAny<bool>()), Times.Never);
            }
        }

        [Test]
        public void ShouldPublishPriceStreams()
        {
            var parentId = 100;

            var parentCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(parentId)
                                                                                   .Build();

            var childCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithMarginParentCurveId(parentId)
                                                                                  .Build();

            var nonMatchedCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

            var curveDefinitions = new List<PriceCurveDefinition>
                                   {
                                       parentCurveDefinition, childCurveDefinition, nonMatchedCurveDefinition
                                   };

            var testObjects = new LivePriceCurvesServiceTestObjectBuilder().WithPriceCurveDefinitions(curveDefinitions)
                                                                           .Build();

            var priceStreams = new List<ILivePriceStreamService>
                               {
                                   new MockLivePriceStreamServiceBuilder().Build().Object
                               };

            var livePrices = testObjects.LivePriceCurvesService.GenerateLivePrices(parentId, 201);

            List<ILivePriceStreamService> result = null;

            using (livePrices.Subscribe(streams => result = streams))
            {
                // ACT
                testObjects.LivePriceStreams.OnNext(priceStreams);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }
    }
}
