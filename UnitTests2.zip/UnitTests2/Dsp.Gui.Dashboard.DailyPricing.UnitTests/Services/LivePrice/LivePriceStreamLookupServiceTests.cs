﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Dashboard.DailyPricing.Services.LivePrice;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.LivePrice
{
    [TestFixture]
    public class LivePriceStreamLookupServiceTests
    {
        [Test]
        public void ShouldPublishLivePriceStreams()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var liveStream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1).Build();
            var liveStream2 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve2).Build();

            var liveStreams = new[]
                              {
                                  liveStream1.Object, liveStream2.Object
                              };

            var lookupService = new LivePriceStreamLookupService();

            Dictionary<LinkedCurve, ILivePriceStreamService> result = null;

            using (lookupService.LivePriceStreams.Subscribe(lookup => result = lookup))
            {
                // ACT 
                lookupService.Update(liveStreams);

                // ASSERT
                Assert.That(result, Is.Not.Null);
                Assert.That(result.Count, Is.EqualTo(2));
                Assert.That(result[linkedCurve1], Is.SameAs(liveStream1.Object));
                Assert.That(result[linkedCurve2], Is.SameAs(liveStream2.Object));
            }
        }
    }
}
