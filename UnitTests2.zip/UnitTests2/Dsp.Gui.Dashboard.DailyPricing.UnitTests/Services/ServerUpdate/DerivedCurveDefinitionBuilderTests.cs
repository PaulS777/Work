﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Dashboard.DailyPricing.Services.ServerUpdate;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.ServerUpdate
{
    [TestFixture]
    internal class DerivedCurveDefinitionBuilderTests
    {
        [Test]
        public void ShouldGetDerivedCurveDefinition_WithEfpNarratives()
        {
            var jan23 = new MonthlyTenor(2023, 1);

            var curveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(101)
                                                                                .Build();

            var priceRows = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2021, 1, 1),
                    ManualPriceCell = {MidPrice = 1.1M},
                    EfpNarrative = { EfpMonthItem = new EfpMonthItem(jan23, true), EfpValue = 2.1M}
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2021, 2, 1),
                    ManualPriceCell = {MidPrice = 1.2M},
                    EfpNarrative = { EfpMonthItem = null, EfpValue = null}
                }
            };

            var builder = new DerivedCurveDefinitionBuilder();

            // ACT
            var result = builder.GetDailyCurveDefinition(curveDefinition, priceRows);

            // ASSERT
            Assert.That(result.DailyDefinition.ManualCurveDefinition.Overrides.Count, Is.EqualTo(2));
            Assert.That(result.DailyDefinition.ManualCurveDefinition.Overrides[0].Value, Is.EqualTo(1.1));
            Assert.That(result.DailyDefinition.ManualCurveDefinition.Overrides[1].Value, Is.EqualTo(1.2));
            Assert.That(result.DailyDefinition.ManualCurveDefinition.EfpNarratives.Count, Is.EqualTo(2));
            Assert.That(result.DailyDefinition.ManualCurveDefinition.EfpNarratives[0].EfpMonth, Is.EqualTo(jan23));
            Assert.That(result.DailyDefinition.ManualCurveDefinition.EfpNarratives[0].EfpValue, Is.EqualTo(2.1));
            Assert.IsNull(result.DailyDefinition.ManualCurveDefinition.EfpNarratives[1]);
        }

        [Test]
        public void ShouldSetEfpNarrativesNull_When_AllEfpValuesNull()
        {
            var curveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(101)
                                                                                .Build();

            var priceRows = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2021, 1, 1),
                    ManualPriceCell = {MidPrice = 1.1M},
                    EfpNarrative = { EfpMonthItem = null, EfpValue = null}
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2021, 2, 1),
                    ManualPriceCell = {MidPrice = 1.2M},
                    EfpNarrative = { EfpMonthItem = null, EfpValue = null}
                }
            };

            var builder = new DerivedCurveDefinitionBuilder();

            // ACT
            var result = builder.GetDailyCurveDefinition(curveDefinition, priceRows);

            // ASSERT
            Assert.IsNull(result.DailyDefinition.ManualCurveDefinition.EfpNarratives);
        }
    }
}
