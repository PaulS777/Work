﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.DailyPricing.Services.ServerUpdate;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.ServerUpdate
{
    [TestFixture]
    internal class PublisherTenorPremiumBuilderTests
    {
        [Test]
        public void ShouldCreatePublisherTenorPremium()
        {
            var tenor1 = new DailyTenor(new DateTime(2021, 1, 4));
            var tenor2 = new DailyTenor(new DateTime(2021, 1, 5));
            var tenor3 = new DailyTenor(new DateTime(2021, 1, 6));
            var tenor4 = new DailyTenor(new DateTime(2021, 1, 7));

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    DailyTenor = tenor1,
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = -0.1M}},
                        AskMargin = {Margin = {Value = 0.1M}}
                    }
                },
                new(Mock.Of<IDisposable>())
                {
                    DailyTenor = tenor2,
                    IsBusinessDay = false
                },
                new(Mock.Of<IDisposable>())
                {
                    DailyTenor = tenor3,
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = -0.2M}},
                        AskMargin = {Margin = {Value = 0.2M}}
                    }
                },
                new(Mock.Of<IDisposable>())
                {
                    DailyTenor = tenor4,
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = null}},
                        AskMargin = {Margin = {Value = null}}
                    }
                }
            };

            var builder = new PublisherTenorPremiumBuilder();

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(50)
                                                                      .WithPriceCurveId(101)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            // ACT
            var result = builder.CreatePublisherTenorPremium(premium, dailyPrices);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(50));
            Assert.That(result.PriceCurveId, Is.EqualTo(101));
            Assert.That(result.PublisherId, Is.EqualTo(10));
            Assert.That(result.TenorPremiums.Count, Is.EqualTo(2));

            Assert.That(result.TenorPremiums[0].Tenor, Is.EqualTo(tenor1));
            Assert.That(result.TenorPremiums[0].BidMargin, Is.EqualTo(-0.1M));
            Assert.That(result.TenorPremiums[0].AskMargin, Is.EqualTo(0.1M));

            Assert.That(result.TenorPremiums[1].Tenor, Is.EqualTo(tenor3));
            Assert.That(result.TenorPremiums[1].BidMargin, Is.EqualTo(-0.2M));
            Assert.That(result.TenorPremiums[1].AskMargin, Is.EqualTo(0.2M));
        }
    }
}
