﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.TenorPremiums
{
    internal interface ITenorMarginsUpdateServiceTestObjects
    {
        ITenorPremiumViewModelUpdater TenorPremiumViewModelUpdater { get; }
        TenorMarginsUpdateService TenorMarginsUpdateService { get; }
    }

    [TestFixture]
    public class TenorMarginsUpdateServiceTests
    {
        private class TenorMarginsUpdateServiceTestObjectBuilder
        {
            public ITenorMarginsUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<ITenorMarginsUpdateServiceTestObjects>();

                var viewModelUpdater = new Mock<ITenorPremiumViewModelUpdater>();

                testObjects.SetupGet(o => o.TenorPremiumViewModelUpdater)
                           .Returns(viewModelUpdater.Object);

                var tenorMarginsUpdateService = new TenorMarginsUpdateService()
                {
                    TenorPremiumViewModelUpdater = viewModelUpdater.Object
                };

                testObjects.SetupGet(o => o.TenorMarginsUpdateService)
                           .Returns(tenorMarginsUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateTenorMargins()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of < IDisposable >())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor1
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor2
                }
            };

            var tenorPremiums = new List<TenorPremium>
            {
                new(tenor1, -0.1, 0.1),
                new(tenor2, -0.2, 0.2)
            };

            var publisherTenorPremium = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums(tenorPremiums)
                                                                                    .Build();

            var testObjects = new TenorMarginsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorMarginsUpdateService.UpdateTenorMargins(dailyPrices, publisherTenorPremium, true);

            // ASSERT
            Mock.Get(testObjects.TenorPremiumViewModelUpdater)
                .Verify(u => u.UpdateTenorPremium(dailyPrices[0].TenorPremium, -0.1M, 0.1M, true));

            Mock.Get(testObjects.TenorPremiumViewModelUpdater)
                .Verify(u => u.UpdateTenorPremium(dailyPrices[1].TenorPremium, -0.2M, 0.2M, true));
        }

        [Test]
        public void ShouldHandlePremiumUpdate_When_NoMatchingTenorMargins()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor1
                }
            };

            var tenorPremiums = new List<TenorPremium>
            {
                new(tenor2, -0.2, 0.2)
            };

            var publisherTenorPremium = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums(tenorPremiums)
                                                                                    .Build();

            var testObjects = new TenorMarginsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorMarginsUpdateService.UpdateTenorMargins(dailyPrices, publisherTenorPremium, true);

            // ASSERT
            Mock.Get(testObjects.TenorPremiumViewModelUpdater)
                .Verify(u => u.UpdateTenorPremium(dailyPrices[0].TenorPremium, 0, 0, true));
        }

        [Test]
        public void ShouldResetTenorMarginsToZero_When_MandatoryRow_With_PremiumsEmpty()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor1
                }
            };

            dailyPrices[0].TenorPremium.BidMargin.Margin.ServerValue = -0.1M;
            dailyPrices[0].TenorPremium.AskMargin.Margin.ServerValue = 0.1M;

            var publisherTenorPremium = new PublisherTenorPremiumTestObjectBuilder().WithId(10)
                                                                                    .WithPriceCurveId(101)
                                                                                    .WithPublisherId(9)
                                                                                    .Build();

            var testObjects = new TenorMarginsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorMarginsUpdateService.UpdateTenorMargins(dailyPrices, publisherTenorPremium, false);

            // ASSERT
            Mock.Get(testObjects.TenorPremiumViewModelUpdater)
                .Verify(u => u.UpdateTenorPremium(dailyPrices[0].TenorPremium, 0, 0, false));
        }

        [Test]
        public void ShouldResetTenorMarginsToNull_When_ExtendedRow_With_PremiumsEmpty()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                   DailyTenor = tenor1, 
                   IsExtended = true
                }
            };

            dailyPrices[0].TenorPremium.BidMargin.Margin.ServerValue = -0.1M;
            dailyPrices[0].TenorPremium.AskMargin.Margin.ServerValue = 0.1M;

            var publisherTenorPremium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var testObjects = new TenorMarginsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorMarginsUpdateService.UpdateTenorMargins(dailyPrices, publisherTenorPremium, false);

            // ASSERT
            Mock.Get(testObjects.TenorPremiumViewModelUpdater)
                .Verify(u => u.UpdateTenorPremium(dailyPrices[0].TenorPremium, null, null, false));
        }

        [Test]
        public void ShouldNotSetIsNewTrue_When_NewRew_With_MatchingTenorUpdate()
        {
            var tenor = new DailyTenor(2021, 1, 1);

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor, 
                    IsNewRow = true
                }
            };

            var tenorPremiums = new List<TenorPremium>
            {
                new(tenor, -0.2, 0.2)
            };

            var publisherTenorPremium = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums(tenorPremiums)
                                                                                    .Build();

            var testObjects = new TenorMarginsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorMarginsUpdateService.UpdateTenorMargins(dailyPrices, publisherTenorPremium, true);

            // ASSERT
            Assert.That(dailyPrices[0].IsNewRow, Is.False);
        }

        [Test]
        public void ShouldNotSetIsNewFalse_When_NewRew_With_NoMatchingTenorUpdate()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of < IDisposable >())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor1, 
                    IsNewRow = true
                }
            };

            var publisherTenorPremium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var testObjects = new TenorMarginsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorMarginsUpdateService.UpdateTenorMargins(dailyPrices, publisherTenorPremium, true);

            // ASSERT
            Assert.That(dailyPrices[0].IsNewRow, Is.True);
        }
    }
}
