﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums.Calculators;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.TenorPremiums.Calculators
{
    [TestFixture]
    public class TenorPremiumsContinuityCheckerTests
    {
        [Test]
        public void ShouldReturnTrue_When_PremiumsAreContiguous_AcrossBusinessDays()
        {
            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2023, 4, 27),
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = -0.01M}},
                        AskMargin = {Margin = {Value = -0.01M}}
                    }
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2023, 4, 28),
                    IsBusinessDay = false,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = null}},
                        AskMargin = {Margin = {Value = null}},
                    }
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Weekly
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2023, 5, 1),
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = -0.01M}},
                        AskMargin = {Margin = {Value = -0.01M}}
                    }
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2023, 5, 2),
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = null}},
                        AskMargin = {Margin = {Value = null}},
                    }
                },
            };

            var checker = new TenorPremiumsContinuityCalculator();

            // ACT
            var result = checker.CheckPremiumsContinuity(dailyPrices);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_MissingPremium_AcrossBusinessDays()
        {
            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2021, 4, 1),
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = -0.01M}},
                        AskMargin = {Margin = {Value = -0.01M}}
                    }
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2021, 4, 2),
                    IsBusinessDay = false,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = null}},
                        AskMargin = {Margin = {Value = null}},
                    }
                },
                // missing margins
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2021, 4, 3),
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = null}},
                        AskMargin = {Margin = {Value = null}},
                    }
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(2021, 4, 4),
                    IsBusinessDay = true,
                    TenorPremium =
                    {
                        BidMargin = {Margin = {Value = -0.01M}},
                        AskMargin = {Margin = {Value = -0.01M}}
                    }
                },
            };

            var checker = new TenorPremiumsContinuityCalculator();

            // ACT
            var result = checker.CheckPremiumsContinuity(dailyPrices);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_NoRows()
        {
            var dailyPrices = new List<DailyPriceRowViewModel>();

            var checker = new TenorPremiumsContinuityCalculator();

            // ACT
            var result = checker.CheckPremiumsContinuity(dailyPrices);

            // ASSERT
            Assert.That(result, Is.False);
        }
    }
}
