﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.TenorPremiums
{
    [TestFixture]
    public class ClearPremiumsServiceTests
    {
        [Test]
        public void ShouldSetMarginsToZero_When_ClearPremiums_With_MidPrice()
        {

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsExtended(true)
                                                           .WithBidAskMarginEditValues(-1, 1)
                                                           .WithBidAskMarginValues(-1, 1)
                                                           .Build();

            var selected = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                               .WithIsExtended(true)
                                                               .WithMidPrice(5.0m)
                                                               .WithBidAskMarginEditValues(-1, 1)
                                                               .WithBidAskMarginValues(-1, 1)
                                                               .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsExtended(true)
                                                           .WithMidPrice(5.0m)
                                                           .WithBidAskMarginEditValues(-1, 1)
                                                           .WithBidAskMarginValues(-1, 1)
                                                           .Build();

            var rows = new List<DailyPriceRowViewModel>{ row1, selected, row2};

            var clearPremiumsService = new ClearPremiumsService();

            // ACT
            clearPremiumsService.ClearPremiums(rows, selected);

            // ASSERT
            Assert.That(row1.TenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1));
            Assert.That(row1.TenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1));
            Assert.That(row1.TenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1));
            Assert.That(row1.TenorPremium.AskMargin.Margin.Value, Is.EqualTo(1));

            Assert.That(selected.TenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0));
            Assert.That(selected.TenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0));
            Assert.That(selected.TenorPremium.BidMargin.Margin.Value, Is.EqualTo(0));
            Assert.That(selected.TenorPremium.AskMargin.Margin.Value, Is.EqualTo(0));

            Assert.That(row2.TenorPremium.BidMargin.Margin.Value, Is.EqualTo(0));
            Assert.That(row2.TenorPremium.AskMargin.Margin.Value, Is.EqualTo(0));
        }

        [Test]
        public void ShouldSetMarginsToNull_When_ClearPremiums_With_MidPriceNull()
        {

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsExtended(true)
                                                           .WithBidAskMarginEditValues(-1, 1)
                                                           .WithBidAskMarginValues(-1, 1)
                                                           .Build();

            var selected = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                               .WithIsExtended(true)
                                                               .WithMidPrice(null)
                                                               .WithBidAskMarginEditValues(-1, 1)
                                                               .WithBidAskMarginValues(-1, 1)
                                                               .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsExtended(true)
                                                           .WithMidPrice(null)
                                                           .WithBidAskMarginEditValues(-1, 1)
                                                           .WithBidAskMarginValues(-1, 1)
                                                           .Build();

            var rows = new List<DailyPriceRowViewModel> { row1, selected, row2 };

            var clearPremiumsService = new ClearPremiumsService();

            // ACT
            clearPremiumsService.ClearPremiums(rows, selected);

            // ASSERT
            Assert.That(row1.TenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1));
            Assert.That(row1.TenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1));
            Assert.That(row1.TenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1));
            Assert.That(row1.TenorPremium.AskMargin.Margin.Value, Is.EqualTo(1));

            Assert.That(selected.TenorPremium.BidMargin.Margin.EditValue, Is.Null);
            Assert.That(selected.TenorPremium.AskMargin.Margin.EditValue, Is.Null);
            Assert.That(selected.TenorPremium.BidMargin.Margin.Value, Is.Null);
            Assert.That(selected.TenorPremium.AskMargin.Margin.Value, Is.Null);

            Assert.That(row2.TenorPremium.BidMargin.Margin.EditValue, Is.Null);
            Assert.That(row2.TenorPremium.AskMargin.Margin.EditValue, Is.Null);
            Assert.That(row2.TenorPremium.BidMargin.Margin.Value, Is.Null);
            Assert.That(row2.TenorPremium.AskMargin.Margin.Value, Is.Null);
        }

        [Test]
        public void ShouldNotThrowException_When_ClearPremiums_With_NullRows()
        {
            Exception result = null;

            try
            {
                var clearPremiumsService = new ClearPremiumsService();

                // ACT
                clearPremiumsService.ClearPremiums(null, new DailyPriceRowViewModel(Mock.Of<IDisposable>()));
            }
            catch (Exception ex)
            {
                result = ex;
            }

            // ASSERT
            Assert.That(result, Is.Null);
        }

        [Test]
        public void ShouldNotThrowException_When_ClearPremiums_With_NullSelectedRow()
        {
            Exception result = null;

            try
            {
                var clearPremiumsService = new ClearPremiumsService();

                // ACT
                clearPremiumsService.ClearPremiums([], null);
            }
            catch (Exception ex)
            {
                result = ex;
            }

            // ASSERT
            Assert.That(result, Is.Null);
        }
    }
}
