﻿using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.TenorPremiums
{
    internal interface ICoerceMarginEditValuesServiceTestObjects
    {
        ITenorPremiumsMarginCalculator TenorPremiumsMarginCalculator { get; }
        CoerceMarginEditValuesService CoerceMarginEditValuesService { get; }
    }

    [TestFixture]
    public class CoerceMarginEditValuesServiceTests
    {
        private class ExtendedRowPremiumsServiceTestObjectBuilder
        {
            private decimal? _calculateBidMarginEditCallbackValue;
            private decimal? _calculateAskMarginEditCallbackValue;
            private decimal? _calculateBidAskMarginEditCallbackValue;

            public ExtendedRowPremiumsServiceTestObjectBuilder WithCalculateBidMarginEditCallbackValue(decimal? value)
            {
                _calculateBidMarginEditCallbackValue = value;
                return this;
            }

            public ExtendedRowPremiumsServiceTestObjectBuilder WithCalculateAskMarginEditCallbackValue(decimal? value)
            {
                _calculateAskMarginEditCallbackValue = value;
                return this;
            }

            public ExtendedRowPremiumsServiceTestObjectBuilder WithCalculateBidAskMarginsEditCallbackValue(decimal? value)
            {
                _calculateBidAskMarginEditCallbackValue = value;
                return this;
            }

            public ICoerceMarginEditValuesServiceTestObjects Build()
            {
                var testObjects = new Mock<ICoerceMarginEditValuesServiceTestObjects>();

                var marginsCalculator = new Mock<ITenorPremiumsMarginCalculator>();

                if (_calculateBidMarginEditCallbackValue.HasValue)
                {
                    marginsCalculator.Setup(c => c.CalculateTenorPremiumFromBidMargin(It.IsAny<TenorPremiumViewModel>(),
                                                                                      It.IsAny<decimal?>(),
                                                                                      It.IsAny<bool>(),
                                                                                      It.IsAny<bool>()))
                                     .Callback<TenorPremiumViewModel, decimal?, bool, bool>((vm, _, _, _) =>
                                                                                            {
                                                                                                vm.BidMargin.Margin.EditValue = _calculateBidMarginEditCallbackValue;
                                                                                            });
                }

                if (_calculateAskMarginEditCallbackValue.HasValue)
                {
                    marginsCalculator.Setup(c => c.CalculateTenorPremiumFromAskMargin(It.IsAny<TenorPremiumViewModel>(),
                                                                                      It.IsAny<decimal?>(),
                                                                                      It.IsAny<bool>(),
                                                                                      It.IsAny<bool>()))
                                     .Callback<TenorPremiumViewModel, decimal?, bool, bool>((vm, _, _, _) =>
                                                                                            {
                                                                                                vm.AskMargin.Margin.EditValue = _calculateAskMarginEditCallbackValue;
                                                                                            });
                }

                if (_calculateBidAskMarginEditCallbackValue.HasValue)
                {
                    marginsCalculator.Setup(c => c.CalculateTenorPremiumFromBidAskMargins(It.IsAny<TenorPremiumViewModel>(),
                                                                                          It.IsAny<decimal?>(),
                                                                                          It.IsAny<decimal?>(),
                                                                                          It.IsAny<bool>(),
                                                                                          It.IsAny<bool>()))
                                     .Callback<TenorPremiumViewModel, decimal?, decimal?, bool, bool>((vm, _, _, _, _) =>
                                                                                                      {
                                                                                                          vm.BidMargin.Margin.EditValue = _calculateBidAskMarginEditCallbackValue;
                                                                                                          vm.AskMargin.Margin.EditValue = _calculateBidAskMarginEditCallbackValue;
                                                                                                      });
                }

                testObjects.SetupGet(o => o.TenorPremiumsMarginCalculator)
                           .Returns(marginsCalculator.Object);

                var extendedRowPremiumsService = new CoerceMarginEditValuesService(marginsCalculator.Object);
                
                testObjects.SetupGet(o => o.CoerceMarginEditValuesService)
                           .Returns(extendedRowPremiumsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCalculateFromBidAsk_When_MidPriceSetToNull_With_SubscribeMargins()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(1.0m)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().Build();

            // ARRANGE
            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ACT
            row.ManualPriceCell.MidPrice = null;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidAskMargins(row.TenorPremium, -0.1m, 0.1m, false, true), Times.Once);
        }

        [Test]
        public void ShouldNotCalculateFromBidAsk_When_MidPriceSetToNull_With_UnsubscribeMargins()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(1.0m)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ARRANGE
            testObjects.CoerceMarginEditValuesService.UnsubscribeMargins();

            // ACT
            row.ManualPriceCell.MidPrice = null;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidAskMargins(row.TenorPremium,
                                                                      It.IsAny<decimal?>(),
                                                                      It.IsAny<decimal?>(),
                                                                      It.IsAny<bool>(),
                                                                      It.IsAny<bool>()), Times.Never);
        }

        [Test]
        public void ShouldCalculateFromBidAsk_When_MidPriceSetToValue()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(null)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ACT
            row.ManualPriceCell.MidPrice = 1.0m;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidAskMargins(row.TenorPremium, -0.1m, 0.1m, true, true), Times.Once);
        }

        [Test]
        public void ShouldCalculateFromBidAskEditValues_When_MidPriceSetToNull_With_IsNotExtended()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(false)
                                                          .WithMidPrice(1.0m)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ACT
            row.ManualPriceCell.MidPrice = null;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidAskMargins(row.TenorPremium, -0.1m, 0.1m, false, false), Times.Once);
        }

        [Test]
        public void ShouldCalculateFromBidEditValue_When_BidMarginChanged()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(null)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ACT
            row.TenorPremium.BidMargin.Margin.EditValue = -0.2M;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidMargin(row.TenorPremium, -0.2m, false, true), Times.Once);
        }

        [Test]
        public void ShouldCalculateFromAskEditValue_When_AskMarginChanged_With_IsExtended()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(null)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ACT
            row.TenorPremium.AskMargin.Margin.EditValue = 0.2M;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromAskMargin(row.TenorPremium, 0.2m, false, true), Times.Once);
        }

        [Test]
        public void ShouldNotCalculateFromBidEditValue_During_BidCalculation()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(null)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().WithCalculateBidMarginEditCallbackValue(-0.21m)
                                                                               .Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ACT
            row.TenorPremium.BidMargin.Margin.EditValue = -0.2M;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidMargin(row.TenorPremium, It.IsAny<decimal?>(), false, true), Times.Once);
        }

        [Test]
        public void ShouldNotCalculateFromAskEditValue_During_AskCalculation()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(null)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().WithCalculateAskMarginEditCallbackValue(0.21m)
                                                                               .Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ACT
            row.TenorPremium.AskMargin.Margin.EditValue = -0.2M;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromAskMargin(row.TenorPremium, It.IsAny<decimal?>(), false, true), Times.Once);
        }

        [Test]
        public void ShouldNotCalculateFromBidOrAskEditValues_During_BidAskCalculation()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(null)
                                                          .WithBidMarginEditValue(-0.1m)
                                                          .WithAskMarginEditValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().WithCalculateBidAskMarginsEditCallbackValue(0.21m)
                                                                               .Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            // ACT
            row.ManualPriceCell.MidPrice = 1.0m;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidMargin(row.TenorPremium, 
                                                                  It.IsAny<decimal?>(), 
                                                                  It.IsAny<bool>(),
                                                                  It.IsAny<bool>()), Times.Never);

            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromAskMargin(row.TenorPremium, 
                                                                  It.IsAny<decimal?>(),
                                                                  It.IsAny<bool>(),
                                                                  It.IsAny<bool>()), Times.Never);
        }

        [Test]
        public void ShouldNotCalculate_When_Disposed()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(null)
                                                          .WithBidMarginValue(-0.1m)
                                                          .WithAskMarginValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            testObjects.CoerceMarginEditValuesService.Dispose();

            // ACT
            row.TenorPremium.BidMargin.Margin.EditValue = -0.2M;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidMargin(row.TenorPremium, 
                                                                  It.IsAny<decimal?>(),
                                                                  It.IsAny<bool>(), 
                                                                  It.IsAny<bool>()), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsExtended(true)
                                                          .WithMidPrice(null)
                                                          .WithBidMarginValue(-0.1m)
                                                          .WithAskMarginValue(0.1m)
                                                          .Build();

            var testObjects = new ExtendedRowPremiumsServiceTestObjectBuilder().Build();

            testObjects.CoerceMarginEditValuesService.SubscribeMargins(row);

            testObjects.CoerceMarginEditValuesService.Dispose();

            // ACT
            testObjects.CoerceMarginEditValuesService.Dispose();
            row.TenorPremium.BidMargin.Margin.EditValue = -0.2M;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsMarginCalculator)
                .Verify(m => m.CalculateTenorPremiumFromBidMargin(row.TenorPremium, 
                                                                  It.IsAny<decimal?>(),
                                                                  It.IsAny<bool>(), 
                                                                  It.IsAny<bool>()), Times.Never);
        }
    }
}
