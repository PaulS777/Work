﻿using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.TenorPremiums
{
    [TestFixture]
    public class TenorPremiumsMarginCalculatorTests
    {
        #region Both Sides, Non Optional => Value or Zero

        [Test]
        public void ShouldSetBidAskValues_When_CalculateNonOptional_With_BidAskHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidAskMargins(tenorPremium, -1.0m, 1.0m, true, false);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0m));
        }

        [Test]
        public void ShouldSetBidAskZeros_When_CalculateNonOptional_With_BidAskNull()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = -1.0m } },
                                   AskMargin = { Margin = { Value = 1.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidAskMargins(tenorPremium, null, null, true, false);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0m));
        }

        #endregion

        #region Both Sides, Optional, Has Price => Value or Zero

        [Test]
        public void ShouldSetBidAskValues_When_CalculateOptionalHasPrice_BidAskValues()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidAskMargins(tenorPremium, -1.0m, 1.0m, true, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0m));
        }

        [Test]
        public void ShouldSetBidAskZeros_When_CalculateOptionalHasPrice_BidAskNull()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = -1.0m } },
                                   AskMargin = { Margin = { Value = 1.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidAskMargins(tenorPremium, null, null, true, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0.0m));
        }

        #endregion

        #region Both Sides, Optional, Missing Price => Value or Null

        [Test]
        public void ShouldSetBidAskValues_When_CalculateOptionalNoPrice_BidAskValues()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = null } },
                                   AskMargin = { Margin = { Value = null } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidAskMargins(tenorPremium, -1.0m, 1.0m, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0m));
        }

        [Test]
        public void ShouldSetBidAskNull_When_CalculateOptionalNoPrice_With_BidAskZeros()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = -1.0m } },
                                   AskMargin = { Margin = { Value = 1.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidAskMargins(tenorPremium, 0.0m, 0.0m, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.Null);
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.Null);
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.Null);
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.Null);
        }


        #endregion

        #region Single Side (BID), Non Optional => Value or Zero

        [Test]
        public void ShouldSetBidValue_When_CalculateNonOptional_With_BidHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidMargin(tenorPremium, -1.0m, true, false);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0m));
        }

        [Test]
        public void ShouldSetBidZero_When_CalculateNonOptional_With_BidNull()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = -1.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidMargin(tenorPremium, null, true, false);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0.0m));
        }

        #endregion

        #region Single Side (ASK), Non Optional => Value or Zero

        [Test]
        public void ShouldSetAskValue_When_CalculateNonOptional_With_AskHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromAskMargin(tenorPremium, 1.0m, true, false);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0m));
        }

        [Test]
        public void ShouldSetAskZero_When_CalculateNonOptional_With_AskNull()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 1.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromAskMargin(tenorPremium, null, true, false);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0.0m));
        }

        #endregion

        #region Single Side (BID), Optional, Has Price => Value or Zero

        [Test]
        public void ShouldSetBidValue_When_CalculateOptionalHasPrice_With_BidHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidMargin(tenorPremium, -1.0m, true, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0.0m));
        }

        [Test]
        public void ShouldSetBidZero_When_CalculateOptionalHasPrice_With_BidNull()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = -1.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidMargin(tenorPremium, null, true, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0.0m));
        }

        #endregion

        #region Single Side (ASK), Optional, Has Price => Value or Zero

        [Test]
        public void ShouldSetAskValue_When_CalculateOptionalHasPrice_With_AskHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromAskMargin(tenorPremium, 1.0m, true, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0m));
        }

        [Test]
        public void ShouldSetAskZero_When_CalculateOptionalHasPrice_With_AskNull()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 1.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromAskMargin(tenorPremium, null, true, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0.0m));
        }

        #endregion

        #region Single Side (BID), Optional, Missing Price => Value or Zeros or Nulls

        [Test]
        public void ShouldSetBidValue_When_CalculateOptionalNoPrice_With_BidHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = 0.0m } },
                                   AskMargin = { Margin = { Value = 1.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidMargin(tenorPremium, -1.0m, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0m));
        }

        [Test]
        public void ShouldSetBidZero_When_CalculateOptionalNoPrice_With_BidNull_CurrentAskHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = -1.0m } },
                                   AskMargin = { Margin = { Value = 1.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidMargin(tenorPremium, null, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0m));
        }

        [Test]
        public void ShouldSetBidAskNull_When_CalculateOptionalNoPrice_With_BidNull_CurrentAskZero()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = -1.0m } },
                                   AskMargin = { Margin = { Value = 0.0m } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidMargin(tenorPremium, null, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.Null);
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.Null);
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.Null);
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.Null);
        }

        [Test]
        public void ShouldSetAskZero_When_CalculateOptionalNoPrice_With_BidValue_CurrentAskNull()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   BidMargin = { Margin = { Value = -1.0m } },
                                   AskMargin = { Margin = { Value = null } }
                               };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromBidMargin(tenorPremium, -1.1m, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.1m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.1m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0.0m));
        }

        #endregion

        #region Single Side (ASK), Optional, Missing Price => Value or Zeros or Nulls

        [Test]
        public void ShouldSetAskValue_When_CalculateOptionalNoPrice_With_AskHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
            {
                BidMargin = { Margin = { Value = -1.0m } },
                AskMargin = { Margin = { Value = 0.0m } }
            };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromAskMargin(tenorPremium, 1.0m, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0m));
        }

        [Test]
        public void ShouldSetAskZero_When_CalculateOptionalNoPrice_With_AskNull_CurrentBidHasValue()
        {
            var tenorPremium = new TenorPremiumViewModel
            {
                BidMargin = { Margin = { Value = -1.0m } },
                AskMargin = { Margin = { Value = 1.0m } }
            };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromAskMargin(tenorPremium, null, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(0.0m));
        }

        [Test]
        public void ShouldSetBidAskNull_When_CalculateOptionalNoPrice_With_AskNull_CurrentBidZero()
        {
            var tenorPremium = new TenorPremiumViewModel
            {
                BidMargin = { Margin = { Value = 0.0m } },
                AskMargin = { Margin = { Value = 1.0m } }
            };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromAskMargin(tenorPremium, null, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.Null);
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.Null);
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.Null);
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.Null);
        }

        [Test]
        public void ShouldSetBidZero_When_CalculateOptionalNoPrice_With_AskValue_CurrentBidNull()
        {
            var tenorPremium = new TenorPremiumViewModel
            {
                BidMargin = { Margin = { Value = null } },
                AskMargin = { Margin = { Value = 1.0m } }
            };

            var calculator = new TenorPremiumsMarginCalculator();

            // ACT
            calculator.CalculateTenorPremiumFromAskMargin(tenorPremium, 1.1m, false, true);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.Value, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.1m));
            Assert.That(tenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(0.0m));
            Assert.That(tenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.1m));
        }

        #endregion
    }
}
