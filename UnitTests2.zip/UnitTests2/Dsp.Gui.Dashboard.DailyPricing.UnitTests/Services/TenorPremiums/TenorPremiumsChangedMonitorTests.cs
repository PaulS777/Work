﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums.Calculators;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.TenorPremiums
{
    internal interface ITenorPremiumsChangedMonitorTestObjects
    {
        TenorPremiumsChangedMonitor TenorPremiumsChangedMonitor { get; }
    }

    [TestFixture]
    public class TenorPremiumsChangedMonitorTests
    {
        private class TenorPremiumsChangedMonitorTestObjectBuilder
        {
            private bool _continuityCheckResult;

            public TenorPremiumsChangedMonitorTestObjectBuilder WithContinuityCheckResult(bool value)
            {
                _continuityCheckResult = value;
                return this;
            }

            public ITenorPremiumsChangedMonitorTestObjects Build()
            {
                var testObjects = new Mock<ITenorPremiumsChangedMonitorTestObjects>();

                var calculator = new Mock<ITenorPremiumsContinuityCalculator>();

                calculator.Setup(c => c.CheckPremiumsContinuity(It.IsAny<IList<DailyPriceRowViewModel>>()))
                          .Returns(_continuityCheckResult);

                var monitor = new TenorPremiumsChangedMonitor
                {
                    TenorPremiumsContinuityCalculator = calculator.Object
                };

                testObjects.SetupGet(o => o.TenorPremiumsChangedMonitor)
                           .Returns(monitor);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldMonitorBidMarginSpinUpdate()
        {
            var premium1 = new TenorPremiumViewModel();
            var premium2 = new TenorPremiumViewModel();

            var tenorPremiums = new[] { premium1, premium2 };

            var testObjects = new TenorPremiumsChangedMonitorTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                .Build();

            TenorPremiumViewModel result = null;

            using (testObjects.TenorPremiumsChangedMonitor.MonitorSpinUpdate(tenorPremiums)
                              .Subscribe(r => result = r))
            {
                premium1.Model().MarginSpinUpdate.OnNext(1.0M);

                // ASSERT
                Assert.AreSame(premium1, result);
            }
        }

        [Test]
        public void ShouldMonitorAskMarginSpinUpdate()
        {
            var premium1 = new TenorPremiumViewModel();
            var premium2 = new TenorPremiumViewModel();

            var tenorPremiums = new [] { premium1, premium2 };

            var testObjects = new TenorPremiumsChangedMonitorTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                .Build();

            TenorPremiumViewModel result = null;

            using (testObjects.TenorPremiumsChangedMonitor.MonitorSpinUpdate(tenorPremiums)
                              .Subscribe(r => result = r))
            {
                premium1.Model().MarginSpinUpdate.OnNext(1.1M);

                // ASSERT
                Assert.AreSame(premium1, result);
            }
        }

        [Test]
        public void ShouldMonitorBidMarginTextUpdate()
        {
            var premium1 = new TenorPremiumViewModel();
            var premium2 = new TenorPremiumViewModel();

            var tenorPremiums = new[] { premium1, premium2 };

            var testObjects = new TenorPremiumsChangedMonitorTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                .Build();

            TenorPremiumViewModel result = null;

            using (testObjects.TenorPremiumsChangedMonitor.MonitorBidTextUpdate(tenorPremiums)
                              .Subscribe(r => result = r))
            {
                premium1.Model().BidMarginTextUpdate.OnNext(0.99M);

                // ASSERT
                Assert.AreSame(premium1, result);
            }
        }

        [Test]
        public void ShouldMonitorAskMarginTextUpdate()
        {
            var premium1 = new TenorPremiumViewModel();
            var premium2 = new TenorPremiumViewModel();

            var tenorPremiums = new [] { premium1, premium2 };

            var testObjects = new TenorPremiumsChangedMonitorTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                .Build();

            TenorPremiumViewModel result = null;

            using (testObjects.TenorPremiumsChangedMonitor.MonitorAskTextUpdate(tenorPremiums)
                              .Subscribe(r => result = r))
            {
                premium1.Model().AskMarginTextUpdate.OnNext(1.01M);

                // ASSERT
                Assert.AreSame(premium1, result);
            }
        }
    }
}
