﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.DailyPricing.Services.DailyPrice;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.DailyPrice
{
    [TestFixture]
    internal class DailyPriceCurveUpdateServiceTests
    {
        [Test]
        public void ShouldUpdatePriceRowIsPublisherEditor_And_ShowIsTradeable_With_IsBusinessDay()
        {
            var tenor = new DailyTenor(2021, 1, 1);

            var dailyCurveDefinition 
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>())
                                                                .Build();

            var dailyPrice = new DailyPriceRowTestObjectBuilder().WithDailyTenor(tenor).WithIsBusinessDay(true).Build();

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      true);

            // ASSERT
            Assert.That(dailyPrice.IsPublisherEditor, Is.True);
            Assert.That(dailyPrice.ManualPriceCell.IsPublisherEditor, Is.True);
            Assert.That(dailyPrice.EfpNarrative.IsPublisherEditor, Is.True);
            Assert.That(dailyPrice.ShowIsTradeable, Is.True);
        }

        [Test]
        public void ShouldSet_ShowIsTradeableFalse_When_IsBusinessDayFalse()
        {
            var tenor = new DailyTenor(2021, 1, 1);

            var dailyCurveDefinition
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>())
                                                                .Build();

            var dailyPrice = new DailyPriceRowTestObjectBuilder().WithDailyTenor(tenor).WithIsBusinessDay(false).Build();

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      true);

            // ASSERT
            Assert.That(dailyPrice.ShowIsTradeable, Is.False);
        }

        [Test]
        public void ShouldUpdateDailyPrices()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);

            var curvePoint1 = new CurvePoint<DailyTenor>(tenor1, 1.1);
            var curvePoint2 = new CurvePoint<DailyTenor>(tenor2, 1.2);

            var curvePoints = new List<CurvePoint<DailyTenor>> { curvePoint1, curvePoint2 };

            var dailyCurveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints)
                                                                                     .Build();

            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor1
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor2
            };

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice1, dailyPrice2 };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      true);

            // ASSERT
            Assert.That(dailyPrice1.Model().MidPriceServer, Is.EqualTo(1.1M));
            Assert.IsNull(dailyPrice1.Model().MidPriceManual);
            Assert.That(dailyPrice1.ManualPriceCell.MidPrice, Is.EqualTo(1.1M));

            Assert.That(dailyPrice2.Model().MidPriceServer, Is.EqualTo(1.2M));
            Assert.IsNull(dailyPrice2.Model().MidPriceManual);
            Assert.That(dailyPrice2.ManualPriceCell.MidPrice, Is.EqualTo(1.2M));
        }

        [Test]
        public void ShouldUpdateDailyPrices_With_EfpNarratives()
        {
            var jan21 = new MonthlyTenor(2021, 1);
            var feb21 = new MonthlyTenor(2021, 2);

            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);

            var efpNarratives = new List<EfpNarrative<DailyTenor>>
            {
                new(tenor1, jan21, 2.1),
                new(tenor2, feb21, 2.2)
            };

            var dailyCurveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().WithEfpNarratives(efpNarratives)
                                                                                     .Build();

            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor1
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor2
            };

            var efpMonthsItems = new List<EfpMonthItem>
                                 {
                                    new(jan21, true),
                                    new(feb21, true),
                                    new(new MonthlyTenor(2021, 3), true)
                                 };

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice1, dailyPrice2 };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      efpMonthsItems, 
                                      true);

            // ASSERT
            Assert.That(dailyPrice1.EfpNarrative.EfpMonthItems, Is.SameAs(efpMonthsItems));
            Assert.That(dailyPrice1.EfpNarrative.EfpMonthItem, Is.SameAs(efpMonthsItems[0]));
            Assert.That(dailyPrice1.EfpNarrative.EfpValue, Is.EqualTo(2.1M));
            Assert.That(dailyPrice1.Model().EfpMonthServer, Is.EqualTo(jan21));
            Assert.That(dailyPrice1.Model().EfpValueServer, Is.EqualTo(2.1M));
            Assert.IsNull(dailyPrice1.Model().EfpMonthManual);
            Assert.IsNull(dailyPrice1.Model().EfpValueManual);

            Assert.That(dailyPrice2.EfpNarrative.EfpMonthItems, Is.SameAs(efpMonthsItems));
            Assert.That(dailyPrice2.EfpNarrative.EfpMonthItem, Is.SameAs(efpMonthsItems[1]));
            Assert.That(dailyPrice2.EfpNarrative.EfpValue, Is.EqualTo(2.2M));
            Assert.That(dailyPrice2.Model().EfpMonthServer, Is.EqualTo(feb21));
            Assert.That(dailyPrice2.Model().EfpValueServer, Is.EqualTo(2.2M));
            Assert.IsNull(dailyPrice2.Model().EfpMonthManual);
            Assert.IsNull(dailyPrice2.Model().EfpValueManual);
        }

        [Test]
        public void ShouldSetCanEditEdfValues()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);
            var tenor3 = new DailyTenor(2021, 1, 3);

            var curvePoint1 = new CurvePoint<DailyTenor>(tenor1, 1.1);
            var curvePoint2 = new CurvePoint<DailyTenor>(tenor2, 1.2);
            var curvePoint3 = new CurvePoint<DailyTenor>(tenor3, null);

            var curvePoints = new List<CurvePoint<DailyTenor>>
            {
                curvePoint1, 
                curvePoint2,
                curvePoint3
            };

            var efpNarratives = new List<EfpNarrative<DailyTenor>>
            {
                new(tenor1, new MonthlyTenor(2021, 4), 2.1),
                new(tenor2, null, null),
                new(tenor2, null, null)
            };

            var dailyCurveDefinition 
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints)
                                                                .WithEfpNarratives(efpNarratives)
                                                                .Build();

            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor1
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor2
            };

            var dailyPrice3 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor3
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2, dailyPrice3
                              };


            var efpMonthsItems = new List<EfpMonthItem>
                                 {
                                     new(new MonthlyTenor(2021, 4), true)
                                 };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      efpMonthsItems, 
                                      true);

            // ASSERT
            Assert.That(dailyPrice1.EfpNarrative.CanEditEfpMonth, Is.True);
            Assert.That(dailyPrice1.EfpNarrative.CanEditEfpValue, Is.True);
            Assert.That(dailyPrice2.EfpNarrative.CanEditEfpMonth, Is.True);
            Assert.That(dailyPrice2.EfpNarrative.CanEditEfpValue, Is.False);
            Assert.That(dailyPrice3.EfpNarrative.CanEditEfpMonth, Is.False);
            Assert.That(dailyPrice3.EfpNarrative.CanEditEfpValue, Is.False);
        }

        [Test]
        public void ShouldSetEfpNarrativesReadonly_When_IsChildTrue()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);

            var curvePoint1 = new CurvePoint<DailyTenor>(tenor1, 1.1);

            var curvePoints = new List<CurvePoint<DailyTenor>>
            {
                curvePoint1
            };

            var efpNarratives = new List<EfpNarrative<DailyTenor>>
            {
                new(tenor1, new MonthlyTenor(2021, 2), 2.1)
            };

            var dailyCurveDefinition
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints)
                                                                .WithEfpNarratives(efpNarratives)
                                                                .Build();

            var dailyPrice = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor1,
                EfpNarrative = { IsChild = true}
            };

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      true);

            // ASSERT
            Assert.That(dailyPrice.EfpNarrative.CanEditEfpMonth, Is.False);
            Assert.That(dailyPrice.EfpNarrative.CanEditEfpValue, Is.False);
        }

        [Test]
        public void ShouldSetIsNewFalse_Where_NewRowsHaveTenors_LessThanOrEqualToLastOverride()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);
            var tenor3 = new DailyTenor(2021, 1, 3);

            var curvePoint1 = new CurvePoint<DailyTenor>(tenor1, 1.1);
            var curvePoint2 = new CurvePoint<DailyTenor>(tenor2, 1.1);

            var curvePoints = new List<CurvePoint<DailyTenor>>
                              {
                                  curvePoint1, curvePoint2
                              };

            var dailyCurveDefinition 
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints)
                                                                .Build();

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>()){DailyTenor = tenor1, IsNewRow = true},
                new(Mock.Of<IDisposable>()){DailyTenor = tenor2, IsNewRow = true},
                new(Mock.Of<IDisposable>()){DailyTenor = tenor3, IsNewRow = true}
            };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      false);

            // ASSERT
            Assert.That(dailyPrices[0].IsNewRow, Is.False);
            Assert.That(dailyPrices[1].IsNewRow, Is.False);
            Assert.That(dailyPrices[2].IsNewRow, Is.True);
        }

        [Test]
        public void ShouldHandleDailyPriceUpdate_When_NoMatchingPriceCell()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);

            var curvePoint = new CurvePoint<DailyTenor>(tenor2, 1.2);

            var curvePoints = new List<CurvePoint<DailyTenor>> { curvePoint };

            var dailyCurveDefinition 
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints)
                                                                .Build();

            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor1
            };

            var dailyPrices = new List<DailyPriceRowViewModel> {dailyPrice1};

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      false);

            // ASSERT
            Assert.IsNull(dailyPrice1.Model().MidPriceServer);
        }

        [Test]
        public void ShouldResetManualChangedStatus()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var curvePoint1 = new CurvePoint<DailyTenor>(tenor1, 1.1);

            var curvePoints = new List<CurvePoint<DailyTenor>> { curvePoint1 };

            var dailyCurveDefinition 
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints)
                                                                .Build();

            var dailyPrice = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor1,
                ManualPriceCell =
                {
                    HasManualChange = true, CurveOverridesChanged = true
                }
            };

            dailyPrice.Model().MidPriceManual = 1.5M;

            var dailyPrices = new List<DailyPriceRowViewModel> {dailyPrice};

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      true);

            // ASSERT
            Assert.That(dailyPrice.ManualPriceCell.HasManualChange, Is.False);
            Assert.That(dailyPrice.ManualPriceCell.CurveOverridesChanged, Is.False);
        }

        [Test]
        public void ShouldClearExcessPriceCellValues_OnPriceCurveUpdate_With_ShortenedTenorRange()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);

            var curvePoint1 = new CurvePoint<DailyTenor>(tenor1, 1.1);
            var curvePoints = new List<CurvePoint<DailyTenor>> {curvePoint1};

            var dailyCurveDefinition 
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints)
                                                                .Build();

            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor1
            };

            dailyPrice1.Model().MidPriceManual = 1.5M;

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor2, ManualPriceCell =
                {
                    HasManualChange = true, CurveOverridesChanged = true
                }
            };

            dailyPrice2.Model().MidPriceManual = 1.6M;
            dailyPrice2.Model().MidPriceServer = 2.1M;

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      true);

            // ASSERT
            Assert.IsNull(dailyPrice2.Model().MidPriceServer);
            Assert.IsNull(dailyPrice2.Model().MidPriceManual);
            Assert.That(dailyPrice2.ManualPriceCell.HasManualChange, Is.False);
            Assert.That(dailyPrice2.ManualPriceCell.CurveOverridesChanged, Is.False);
            Assert.IsNull(dailyPrice2.ManualPriceCell.MidPrice);
        }

        [Test]
        public void ShouldClearAllPriceCellValues_OnPriceCurveUpdate_With_NoOverrides()
        {
            var tenor1 = new DailyTenor(2021, 1, 1);
            var tenor2 = new DailyTenor(2021, 1, 2);

            var dailyCurveDefinition 
                = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>())
                                                                .Build();

            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor1
            };

            dailyPrice1.Model().MidPriceManual = 1.5M;

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                DailyTenor = tenor2,
                ManualPriceCell = { HasManualChange = true, CurveOverridesChanged = true }
            };

            dailyPrice2.Model().MidPriceManual = 1.6M;
            dailyPrice2.Model().MidPriceServer = 2.1M;

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var service = new DailyPriceCurveUpdateService();

            // ACT
            service.UpdateDailyPrices(dailyPrices, 
                                      dailyCurveDefinition, 
                                      new List<EfpMonthItem>(), 
                                      true);

            // ASSERT
            Assert.IsNull(dailyPrice1.Model().MidPriceServer);
            Assert.IsNull(dailyPrice1.Model().MidPriceManual);
            Assert.That(dailyPrice1.ManualPriceCell.HasManualChange, Is.False);
            Assert.That(dailyPrice1.ManualPriceCell.CurveOverridesChanged, Is.False);
            Assert.IsNull(dailyPrice1.ManualPriceCell.MidPrice);

            Assert.IsNull(dailyPrice2.Model().MidPriceServer);
            Assert.IsNull(dailyPrice2.Model().MidPriceManual);
            Assert.That(dailyPrice2.ManualPriceCell.HasManualChange, Is.False);
            Assert.That(dailyPrice2.ManualPriceCell.CurveOverridesChanged, Is.False);
            Assert.IsNull(dailyPrice2.ManualPriceCell.MidPrice);
        }
    }
}
