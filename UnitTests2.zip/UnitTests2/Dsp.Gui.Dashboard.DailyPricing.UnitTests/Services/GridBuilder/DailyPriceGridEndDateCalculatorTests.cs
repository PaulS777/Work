﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.GridBuilder
{
    [TestFixture]
    internal class DailyPriceGridEndDateCalculatorTests
    {
        [Test]
        public void ShouldCalculateEndDate_With_OverridesAsFurthestDate()
        {
            var date1 = new DateTime(2021, 1, 4);
            var date2 = new DateTime(2021, 1, 5);

            var tenor1 = new DailyTenor(date1);
            var tenor2 = new DailyTenor(date2);

            var curvePoints = new List<CurvePoint<DailyTenor>> { new(tenor1, 1.1), new(tenor2, 1.1) };

            var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints).Build();

            var tenorPremium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var liveStream = new MockLivePriceStreamServiceBuilder().WithPriceCurveSnapshot(new PriceCurveBuilder().Build())
                                                                    .Build();
            
            var mandatoryDate = date1;

            var calculator = new DailyPriceGridEndDateCalculator();

            // ACT
            var result = calculator.GetCurveEndDate(dailyCurve, tenorPremium, new[]{liveStream.Object}, mandatoryDate);

            // ASSERT
            Assert.That(result, Is.EqualTo(date2));
        }

        [Test]
        public void ShouldCalculateEndDate_With_TenorPremiumsAsFurthestDate()
        {
            var date1 = new DateTime(2021, 1, 4);
            var date2 = new DateTime(2021, 1, 5);

            var tenor1 = new DailyTenor(date1);
            var tenor2 = new DailyTenor(date2);

            var curvePoints = new List<CurvePoint<DailyTenor>> { new(tenor1, 1.1) };

            var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints).Build();

            var premiums = new List<TenorPremium> { new(tenor1, 0, 0), new(tenor2, 0, 0) };
            
            var tenorPremium = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums(premiums).Build();

            var liveStream = new MockLivePriceStreamServiceBuilder().WithPriceCurveSnapshot(new PriceCurveBuilder().Build())
                                                                    .Build();

            var mandatoryDate = date1;

            var calculator = new DailyPriceGridEndDateCalculator();

            // ACT
            var result = calculator.GetCurveEndDate(dailyCurve, tenorPremium, new[] { liveStream.Object }, mandatoryDate);

            // ASSERT
            Assert.That(result, Is.EqualTo(date2));
        }

        [Test]
        public void ShouldCalculateEndDate_With_LivePriceStreamAsFurthestDate()
        {
            var date1 = new DateTime(2021, 1, 4);
            var date2 = new DateTime(2021, 1, 5);

            var tenor1 = new DailyTenor(date1);
            var tenor2 = new DailyTenor(date2);

            var curvePoints = new List<CurvePoint<DailyTenor>> { new(tenor1, 1.1) };

            var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(curvePoints).Build();

            var premiums = new List<TenorPremium> { new(tenor1, 0, 0) };

            var tenorPremium = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums(premiums).Build();

            var tenorPrice1 = new TenorPrices<DailyTenor>(new[] { tenor1 }, new List<double?>(), new List<double?>(), new List<double?>(), new List<double?>());
            var tenorPrice2 = new TenorPrices<DailyTenor>(new[] { tenor1, tenor2 }, new List<double?>(), new List<double?>(), new List<double?>(), new List<double?>());

            var curve1 = new PriceCurveBuilder().WithDailyPrices(tenorPrice1).Build();
            var curve2 = new PriceCurveBuilder().WithDailyPrices(tenorPrice2).Build();

            var liveStream1 = new MockLivePriceStreamServiceBuilder().WithPriceCurveSnapshot(curve1).Build();
            var liveStream2 = new MockLivePriceStreamServiceBuilder().WithPriceCurveSnapshot(curve2).Build();

            var liveStreams = new[] { liveStream1.Object, liveStream2.Object };

            var mandatoryDate = date1;

            var calculator = new DailyPriceGridEndDateCalculator();

            // ACT
            var result = calculator.GetCurveEndDate(dailyCurve, tenorPremium, liveStreams, mandatoryDate);

            // ASSERT
            Assert.That(result, Is.EqualTo(date2));
        }

        [Test]
        public void ShouldCalculateEndDate_With_MandatoryDateAsFurthestDate()
        {
            var date1 = new DateTime(2021, 1, 4);
            var date2 = new DateTime(2021, 1, 5);

            var tenor1 = new DailyTenor(date1);

            var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>()).Build();

            var premiums = new List<TenorPremium> { new(tenor1, 0, 0) };

            var tenorPremium = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums(premiums).Build();

            var liveStream = new MockLivePriceStreamServiceBuilder().WithPriceCurveSnapshot(new PriceCurveBuilder().Build())
                                                                    .Build();

            var mandatoryDate = date2;

            var calculator = new DailyPriceGridEndDateCalculator();

            // ACT
            var result = calculator.GetCurveEndDate(dailyCurve, tenorPremium, new[] { liveStream.Object }, mandatoryDate);

            // ASSERT
            Assert.That(result, Is.EqualTo(date2));
        }
    }
}
