﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Controllers;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.GridBuilder
{
    internal interface IDailyPriceGridBuilderTestObjects
    {
        IDailyTenorSequenceGenerator TenorSequenceGenerator { get; }
        ICalendarService CalendarService { get; }
        DailyPriceGridBuilder DailyPriceGridBuilder { get; }
    }

    [TestFixture]
    public class DailyPriceGridBuilderTests
    {
        private class DailyPriceGridBuilderTestObjectBuilder
        {
            private List<ITenor> _tenorSequence = new();

            public DailyPriceGridBuilderTestObjectBuilder WithTenorSequence(List<ITenor> values)
            {
                _tenorSequence = values;
                return this;
            }

            public IDailyPriceGridBuilderTestObjects Build()
            {
                var testObjects = new Mock<IDailyPriceGridBuilderTestObjects>();

                var tenorGenerator = new Mock<IDailyTenorSequenceGenerator>();

                tenorGenerator.Setup(t => t.GetTenorSequence(It.IsAny<DateTime>(), 
                                                             It.IsAny<DateTime>(),
                                                             It.IsAny<bool>()))
                              .Returns(_tenorSequence);

                testObjects.SetupGet(o => o.TenorSequenceGenerator)
                           .Returns(tenorGenerator.Object);

                var row1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>());
                var row2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>());
                var row3 = new DailyPriceRowViewModel(Mock.Of<IDisposable>());

                var controller1 = new Mock<IDailyPriceRowViewModelController>();

                controller1.SetupGet(c => c.ViewModel)
                           .Returns(row1);

                var controller2 = new Mock<IDailyPriceRowViewModelController>();

                controller2.SetupGet(c => c.ViewModel)
                           .Returns(row2);

                var controller3 = new Mock<IDailyPriceRowViewModelController>();

                controller3.SetupGet(c => c.ViewModel)
                           .Returns(row3);

                var rowFactory = new Mock<IServiceFactory<IDailyPriceRowViewModelController>>();

                rowFactory.SetupSequence(f => f.Create())
                          .Returns(controller1.Object)
                          .Returns(controller2.Object)
                          .Returns(controller3.Object);

                var livePriceCell1 = new LivePriceCellTestObjectBuilder().Build();

                var livePriceCellController1 = new Mock<ILivePriceCellController>();

                livePriceCellController1.SetupGet(c => c.ViewModel)
                                        .Returns(livePriceCell1);

                var livePriceCell2 = new LivePriceCellTestObjectBuilder().Build();

                var livePriceCellController2 = new Mock<ILivePriceCellController>();

                livePriceCellController2.SetupGet(c => c.ViewModel)
                                        .Returns(livePriceCell2);

                var livePriceCell3 = new LivePriceCellTestObjectBuilder().Build();

                var livePriceCellController3 = new Mock<ILivePriceCellController>();

                livePriceCellController3.SetupGet(c => c.ViewModel)
                                        .Returns(livePriceCell3);

                var livePriceCell4 = new LivePriceCellTestObjectBuilder().Build();

                var livePriceCellController4 = new Mock<ILivePriceCellController>();

                livePriceCellController4.SetupGet(c => c.ViewModel)
                                        .Returns(livePriceCell4);

                var livePriceCell5 = new LivePriceCellTestObjectBuilder().Build();

                var livePriceCellController5 = new Mock<ILivePriceCellController>();

                livePriceCellController5.SetupGet(c => c.ViewModel)
                                        .Returns(livePriceCell5);

                var livePriceCell6 = new LivePriceCellTestObjectBuilder().Build();

                var livePriceCellController6 = new Mock<ILivePriceCellController>();

                livePriceCellController6.SetupGet(c => c.ViewModel)
                                        .Returns(livePriceCell6);

                var livePriceCellFactory = new Mock<IServiceFactory<ILivePriceCellController>>();

                livePriceCellFactory.SetupSequence(f => f.Create())
                                    .Returns(livePriceCellController1.Object)
                                    .Returns(livePriceCellController2.Object)
                                    .Returns(livePriceCellController3.Object)
                                    .Returns(livePriceCellController4.Object)
                                    .Returns(livePriceCellController5.Object)
                                    .Returns(livePriceCellController6.Object);

                var calendarService = new Mock<ICalendarService>();

                testObjects.SetupGet(o => o.CalendarService)
                           .Returns(calendarService.Object);

                var gridBuilder = new DailyPriceGridBuilder(tenorGenerator.Object, 
                                                            calendarService.Object)
                                  {
                                      RowFactory = rowFactory.Object,
                                      LivePriceCellFactory = livePriceCellFactory.Object
                                  };

                testObjects.SetupGet(o => o.DailyPriceGridBuilder)
                           .Returns(gridBuilder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetDailyPriceRows_With_WeeklyAndDailyTenors()
        {
            var startDate = new DateTime(2023, 4, 24);
            var endDate = new DateTime(2023, 4, 25);

            var weeklyTenor = new WeeklyTenor(startDate);
            var dailyTenor1 = new DailyTenor(startDate);
            var dailyTenor2 = new DailyTenor(endDate);

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var livePriceCurveIds = new[] { curveId1, curveId2 };

            var tenors = new List<ITenor>
            {
                weeklyTenor, dailyTenor1, dailyTenor2
            };

            var testObjects = new DailyPriceGridBuilderTestObjectBuilder().WithTenorSequence(tenors)
                                                                          .Build();

            // ACT
            var result = testObjects.DailyPriceGridBuilder.GetDailyPriceRows(livePriceCurveIds,
                                                                             startDate, 
                                                                             endDate, 
                                                                             endDate);
            // ASSERT
            Mock.Get(testObjects.TenorSequenceGenerator)
                .Verify(t => t.GetTenorSequence(startDate, endDate, true));

            Assert.That(result.Count, Is.EqualTo(3));

            Assert.That(result[0].RowTenorType, Is.EqualTo(RowTenorType.Weekly));
            Assert.That(result[0].IsWeeklyTenor, Is.True);
            Assert.That(result[0].TenorIdentifier, Is.EqualTo("2023W17"));

            Assert.That(result[0].ParentTenorIdentifier, Is.Null);
            Assert.That(result[0].TenorDisplay, Is.EqualTo("24-28/04"));

            Assert.That(result[0].ManualPriceCell.Model(), Is.SameAs(result[0].Model()));
            Assert.That(result[0].EfpNarrative.Model(), Is.SameAs(result[0].Model()));
            Assert.That(result[0].Model().Date, Is.EqualTo(startDate));

            Assert.That(result[0].LivePrices.Count, Is.EqualTo(2));
            Assert.That(result[0].LivePrices[0].RowTenorType, Is.EqualTo(RowTenorType.Weekly));
            Assert.That(result[0].LivePrices[0].Info().CurveId, Is.EqualTo(curveId1));
            Assert.That(result[0].LivePrices[1].Info().CurveId, Is.EqualTo(curveId2));

            Assert.That(result[1].RowTenorType, Is.EqualTo(RowTenorType.Daily));
            Assert.That(result[1].DailyTenor, Is.EqualTo(dailyTenor1));
            Assert.That(result[1].TenorIdentifier, Is.EqualTo("20230424"));
            Assert.That(result[1].ParentTenorIdentifier, Is.EqualTo("2023W17"));
            Assert.That(result[1].IsNewRow, Is.False);
            Assert.That(result[1].TenorDisplay, Is.EqualTo("24 Apr 23"));
            Assert.That(result[1].ManualPriceCell.Model(), Is.SameAs(result[1].Model()));
            Assert.That(result[1].EfpNarrative.Model(), Is.SameAs(result[1].Model()));
            Assert.That(result[1].Model().Date, Is.EqualTo(startDate));
            Assert.That(result[1].ManualPriceCell.IsValid, Is.True);
            Assert.That(result[1].EfpNarrative.IsMonthValid, Is.True);
            Assert.That(result[1].EfpNarrative.IsValueValid, Is.True);
            Assert.That(result[1].TenorPremium.BidMargin.Precision, Is.EqualTo(2));
            Assert.That(result[1].TenorPremium.AskMargin.Precision, Is.EqualTo(2));

            Assert.That(result[1].LivePrices.Count, Is.EqualTo(2));
            Assert.That(result[1].LivePrices[0].RowTenorType, Is.EqualTo(RowTenorType.Daily));

            Assert.That(result[2].RowTenorType, Is.EqualTo(RowTenorType.Daily));
            Assert.That(result[2].DailyTenor, Is.EqualTo(dailyTenor2));
            Assert.That(result[2].TenorIdentifier, Is.EqualTo("20230425"));
            Assert.That(result[2].ParentTenorIdentifier, Is.EqualTo("2023W17"));
            Assert.That(result[2].TenorDisplay, Is.EqualTo("25 Apr 23"));
            Assert.That(result[2].Model().Date, Is.EqualTo(endDate));

            Mock.Get(testObjects.CalendarService)
                .Verify(c => c.ApplyBusinessDays(result));
        }

        [Test]
        public void ShouldSetMandatoryPriceOnCellsUpToMandatoryEndDate()
        {
            var startDate = new DateTime(2023, 4, 24);
            var endDate = new DateTime(2023, 4, 25);

            var tenors = new List<ITenor>
            {
                new DailyTenor(2023, 4, 24),
                new DailyTenor(2023, 4, 25),
                new DailyTenor(2023, 4, 26)
            };

            var testObjects = new DailyPriceGridBuilderTestObjectBuilder().WithTenorSequence(tenors)
                                                                          .Build();

            // ACT
            var result = testObjects.DailyPriceGridBuilder.GetDailyPriceRows(Array.Empty<LinkedCurve>(), 
                                                                             startDate, 
                                                                             endDate, 
                                                                             endDate);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(3));

            Assert.That(result[0].Model().IsMandatory, Is.True);
            Assert.That(result[1].Model().IsMandatory, Is.True);
            Assert.That(result[2].Model().IsMandatory, Is.False);
        }

        [Test]
        public void ShouldSetIsExtendedOnPriceCellsAfterMandatoryEndDate()
        {
            var startDate = new DateTime(2023, 4, 24);
            var mandatoryEndDate = new DateTime(2023, 4, 25);
            var endDate = new DateTime(2023, 4, 25);

            var tenors = new List<ITenor>
            {
                new DailyTenor(2023, 4, 24),
                new DailyTenor(2023, 4, 25),
                new DailyTenor(2023, 4, 26)
            };

            var testObjects = new DailyPriceGridBuilderTestObjectBuilder().WithTenorSequence(tenors)
                                                                          .Build();

            // ACT
            var result = testObjects.DailyPriceGridBuilder.GetDailyPriceRows(Array.Empty<LinkedCurve>(), 
                                                                             startDate, 
                                                                             endDate, 
                                                                             mandatoryEndDate);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(3));

            Assert.That(result[0].IsExtended, Is.False);
            Assert.That(result[1].IsExtended, Is.False);
            Assert.That(result[2].IsExtended, Is.True);
        }

        [Test]
        public void ShouldGetExtendedRow()
        {
            var date1 = new DateTime(2023, 4, 24); // mon
            var date2 = new DateTime(2023, 4, 25); // tue
            var date3 = new DateTime(2023, 4, 26); // wed
            var date4 = new DateTime(2023, 4, 27); // thu

            var tenor1 = new DailyTenor(date1);
            var tenor2 = new DailyTenor(date2);
            var tenor3 = new DailyTenor(date3);
            var tenor4 = new DailyTenor(date4);

            var tenors = new List<ITenor>
            {
                tenor3, tenor4
            };

            var testObjects = new DailyPriceGridBuilderTestObjectBuilder().WithTenorSequence(tenors)
                                                                          .Build();

            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var livePrice1 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve1).Build();
            var livePrice2 = new LivePriceCellTestObjectBuilder().WithCurveId(linkedCurve2).Build();

            var dailyPriceRows = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily, 
                    DailyTenor = tenor1
                },
                new(Mock.Of<IDisposable>()) 
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor2,
                    LivePrices = [livePrice1, livePrice2]
                }
            };

            var efpMonthlyItems = new List<EfpMonthItem>
                                  {
                                      new(new MonthlyTenor(2023, 1), true)
                                  };

            // ACT
            var result = testObjects.DailyPriceGridBuilder.GetExtendedDailyPriceRows(dailyPriceRows, 
                                                                                     efpMonthlyItems, 
                                                                                     2);

            // ASSERT
            Mock.Get(testObjects.TenorSequenceGenerator)
                .Verify(t => t.GetTenorSequence(date3, date4, false));

            Assert.That(result.Count, Is.EqualTo(2));

            Assert.That(result[0].RowTenorType, Is.EqualTo(RowTenorType.Daily));
            Assert.That(result[0].DailyTenor, Is.EqualTo(tenor3));
            Assert.That(result[0].TenorIdentifier, Is.EqualTo("20230426"));

            Assert.That(result[0].ManualPriceCell.IsPublisherEditor, Is.True);
            Assert.That(result[0].EfpNarrative.IsPublisherEditor, Is.True);
            Assert.That(result[0].EfpNarrative.EfpMonthItems, Is.SameAs(efpMonthlyItems));
            Assert.That(result[0].Model().IsMandatory, Is.False);
            Assert.That(result[0].IsExtended, Is.True);
            Assert.That(result[0].IsNewRow, Is.True);
            Assert.That(result[0].IsPublisherEditor, Is.True);
            Assert.That(result[0].ManualPriceCell.IsTradeable, Is.True);
            Assert.That(result[0].TenorPremium.IsCurrentUserPublisher, Is.True);
            Assert.That(result[0].TenorPremium.BidMargin.Precision, Is.EqualTo(2));
            Assert.That(result[0].TenorPremium.AskMargin.Precision, Is.EqualTo(2));

            Assert.That(result[0].LivePrices.Count, Is.EqualTo(2));
            Assert.That(result[0].LivePrices[0].RowTenorType, Is.EqualTo(RowTenorType.Daily));
            Assert.That(result[0].LivePrices[0].Info().CurveId, Is.EqualTo(linkedCurve1));
            Assert.That(result[0].LivePrices[1].Info().CurveId, Is.EqualTo(linkedCurve2));

            Assert.That(result[1].RowTenorType, Is.EqualTo(RowTenorType.Daily));
            Assert.That(result[1].DailyTenor, Is.EqualTo(tenor4));
            Assert.That(result[1].TenorIdentifier, Is.EqualTo("20230427"));

            Assert.That(result[1].ManualPriceCell.IsPublisherEditor, Is.True);
            Assert.That(result[1].EfpNarrative.IsPublisherEditor, Is.True);
            Assert.That(result[1].EfpNarrative.EfpMonthItems, Is.SameAs(efpMonthlyItems));
            Assert.That(result[1].Model().IsMandatory, Is.False);
            Assert.That(result[1].IsExtended, Is.True);
            Assert.That(result[1].IsNewRow, Is.True);
            Assert.That(result[0].IsPublisherEditor, Is.True);
			Assert.That(result[1].ManualPriceCell.IsTradeable, Is.True);
            Assert.That(result[1].TenorPremium.IsCurrentUserPublisher, Is.True);
            Assert.That(result[1].TenorPremium.BidMargin.Precision, Is.EqualTo(2));
            Assert.That(result[1].TenorPremium.AskMargin.Precision, Is.EqualTo(2));

            Assert.That(result[1].LivePrices.Count, Is.EqualTo(2));
            Assert.That(result[1].LivePrices[0].RowTenorType, Is.EqualTo(RowTenorType.Daily));
            Assert.That(result[1].LivePrices[0].Info().CurveId, Is.EqualTo(linkedCurve1));
            Assert.That(result[1].LivePrices[1].Info().CurveId, Is.EqualTo(linkedCurve2));

            Mock.Get(testObjects.CalendarService)
                .Verify(c => c.ApplyBusinessDays(result));
        }

        [Test]
        public void ShouldGetExtendedRows_With_ParentTenorIdentifier_From_ExistingRows()
        {
            var date1 = new DateTime(2023, 4, 24); 
            var date2 = new DateTime(2023, 4, 25); 
            var date3 = new DateTime(2023, 4, 26);
            var date4 = new DateTime(2023, 4, 27);

            var weeklyTenor = new WeeklyTenor(date1);
            var tenor1 = new DailyTenor(date1);
            var tenor2 = new DailyTenor(date2);
            var tenor3 = new DailyTenor(date3);
            var tenor4 = new DailyTenor(date4);

            var tenors = new List<ITenor>
            {
                tenor3, tenor4
            };

            var testObjects = new DailyPriceGridBuilderTestObjectBuilder().WithTenorSequence(tenors)
                                                                          .Build();

            var dailyPriceRows = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Weekly,
                    IsWeeklyTenor = true,
                    TenorIdentifier = weeklyTenor.ToString()
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor1
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = tenor2,
                    LivePrices = new ObservableCollection<LivePriceCell>()
                }
            };

            // ACT
            var result = testObjects.DailyPriceGridBuilder.GetExtendedDailyPriceRows(dailyPriceRows,
                                                                                     new List<EfpMonthItem>(), 
                                                                                     2);

            // ASSERT
            Assert.That(result[0].ParentTenorIdentifier, Is.EqualTo("2023W17"));
            Assert.That(result[1].ParentTenorIdentifier, Is.EqualTo("2023W17"));
        }

        [Test]
        public void ShouldNotExtendDailyPriceGrid_When_GridIsEmpty()
        {
            var testObjects = new DailyPriceGridBuilderTestObjectBuilder().Build();

            var dailyPriceRows = new List<DailyPriceRowViewModel>();

            // ACT
            testObjects.DailyPriceGridBuilder.GetExtendedDailyPriceRows(dailyPriceRows, 
                                                                        new List<EfpMonthItem>(),  
                                                                        2);

            // ASSERT
            Assert.That(dailyPriceRows.Count, Is.EqualTo(0));
        }
    }
}
