﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.GridBuilder
{
    [TestFixture]
    public class DailyTenorSequenceGeneratorTests
    {
        [Test]
        public void TenorSequenceShouldStartWithWeeklyTenor_When_FirstTenorFriday_And_StartWithWeeklyTenorTrue()
        {
            var friday = new DateTime(2023, 4, 28);
            var end = new DateTime(2023, 5, 1);

            var tenorGenerator = new DailyTenorSequenceGenerator();

            // ACT
            var results = tenorGenerator.GetTenorSequence(friday, end, true);

            // ASSERT
            Assert.That(results.Count, Is.EqualTo(6));

            Assert.That(results[0].TenorType(), Is.EqualTo(TenorType.Week));
            Assert.That(results[0].StartDate(), Is.EqualTo(friday.AddDays(-4)));

            Assert.That(results[1].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[1].StartDate(), Is.EqualTo(friday));

            Assert.That(results[2].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[2].StartDate(), Is.EqualTo(friday.AddDays(1)));

            Assert.That(results[3].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[3].StartDate(), Is.EqualTo(friday.AddDays(2)));

            Assert.That(results[4].TenorType(), Is.EqualTo(TenorType.Week));
            Assert.That(results[4].StartDate(), Is.EqualTo(friday.AddDays(3)));

            Assert.That(results[5].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[5].StartDate(), Is.EqualTo(friday.AddDays(3)));
        }

        [TestCase(true)]
        [TestCase(false)]
        public void TenorSequenceShouldStartWithWeeklyTenor_When_FirstTenorMonday_And_StartWithWeeklyTenorTrueOrFalse(bool startWithWeeklyTenor)
        {
            var start = new DateTime(2023, 4, 24);
            var end = new DateTime(2023, 4, 28);

            var tenorGenerator = new DailyTenorSequenceGenerator();

            // ACT
            var results = tenorGenerator.GetTenorSequence(start, end, startWithWeeklyTenor);

            // ASSERT
            Assert.That(results.Count, Is.EqualTo(6));

            Assert.That(results[0].TenorType(), Is.EqualTo(TenorType.Week));
            Assert.That(results[0].StartDate(), Is.EqualTo(start));

            Assert.That(results[1].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[1].StartDate(), Is.EqualTo(start));

            Assert.That(results[2].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[2].StartDate(), Is.EqualTo(start.AddDays(1)));

            Assert.That(results[3].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[3].StartDate(), Is.EqualTo(start.AddDays(2)));

            Assert.That(results[4].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[4].StartDate(), Is.EqualTo(start.AddDays(3)));

            Assert.That(results[5].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[5].StartDate(), Is.EqualTo(start.AddDays(4)));
        }

        [Test]
        public void TenorSequenceShouldStartWithDailyTenor_When_FirstTenorFriday_And_StartWithWeeklyTenorFalse()
        {
            var friday = new DateTime(2023, 4, 28);
            var end = new DateTime(2023, 5, 1);

            var tenorGenerator = new DailyTenorSequenceGenerator();

            // ACT
            var results = tenorGenerator.GetTenorSequence(friday, end, false);

            // ASSERT
            Assert.That(results.Count, Is.EqualTo(5));

            Assert.That(results[0].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[0].StartDate(), Is.EqualTo(friday));

            Assert.That(results[1].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[1].StartDate(), Is.EqualTo(friday.AddDays(1)));

            Assert.That(results[2].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[2].StartDate(), Is.EqualTo(friday.AddDays(2)));

            Assert.That(results[3].TenorType(), Is.EqualTo(TenorType.Week));
            Assert.That(results[3].StartDate(), Is.EqualTo(friday.AddDays(3)));

            Assert.That(results[4].TenorType(), Is.EqualTo(TenorType.Day));
            Assert.That(results[4].StartDate(), Is.EqualTo(friday.AddDays(3)));
        }

        //[Test]
        //public void TenorSequenceShouldStartWithWeeklyTenor_When_FirstTenorMonday_And_StartWithWeeklyTenorFalse()
        //{
        //    var start = new DateTime(2023, 4, 24);
        //    var end = new DateTime(2023, 4, 28);

        //    var tenorGenerator = new DailyTenorSequenceGenerator();

        //    // ACT
        //    var results = tenorGenerator.GetTenorSequence(start, end, false);

        //    // ASSERT
        //    Assert.That(results.Count, Is.EqualTo(6));

        //    Assert.That(results[0].TenorType(), Is.EqualTo(TenorType.Week));
        //    Assert.That(results[0].StartDate(), Is.EqualTo(start));

        //    Assert.That(results[1].TenorType(), Is.EqualTo(TenorType.Day));
        //    Assert.That(results[1].StartDate(), Is.EqualTo(start));

        //    Assert.That(results[2].TenorType(), Is.EqualTo(TenorType.Day));
        //    Assert.That(results[2].StartDate(), Is.EqualTo(start.AddDays(1)));

        //    Assert.That(results[3].TenorType(), Is.EqualTo(TenorType.Day));
        //    Assert.That(results[3].StartDate(), Is.EqualTo(start.AddDays(2)));

        //    Assert.That(results[4].TenorType(), Is.EqualTo(TenorType.Day));
        //    Assert.That(results[4].StartDate(), Is.EqualTo(start.AddDays(3)));

        //    Assert.That(results[5].TenorType(), Is.EqualTo(TenorType.Day));
        //    Assert.That(results[5].StartDate(), Is.EqualTo(start.AddDays(4)));
        //}
    }
}
