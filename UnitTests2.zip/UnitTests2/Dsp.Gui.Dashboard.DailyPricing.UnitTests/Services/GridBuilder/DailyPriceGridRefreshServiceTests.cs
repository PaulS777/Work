﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Models;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.GridBuilder
{
    internal interface IDailyPriceGridRefreshServiceTestObjects
    {
        IDailyPriceGridBuilder GridBuilder { get; }
        IBandBuilder BandBuilder { get; }
        DailyPriceGridRefreshService DailyPriceGridRefreshService { get; }
    }

    [TestFixture]
    public class DailyPriceGridRefreshServiceTests
    {
        private class DailyPriceGridRefreshServiceTestObjectBuilder
        {
            private List<DailyPriceRowViewModel> _dailyPriceGridBuilderResult;
            private List<BandHeader> _bandBuilderResult;
            private DateTime _curveEndDate;

            public DailyPriceGridRefreshServiceTestObjectBuilder WithDailyPriceGridBuilderResult(List<DailyPriceRowViewModel> values)
            {
                _dailyPriceGridBuilderResult = values;
                return this;
            }

            public DailyPriceGridRefreshServiceTestObjectBuilder WithBandBuilderResult(List<BandHeader> values)
            {
                _bandBuilderResult = values;
                return this;
            }

            public DailyPriceGridRefreshServiceTestObjectBuilder WithCurveEndDate(DateTime value)
            {
                _curveEndDate = value;
                return this;
            }

            public IDailyPriceGridRefreshServiceTestObjects Build()
            {
                var testObjects = new Mock<IDailyPriceGridRefreshServiceTestObjects>();

                var endDateCalculator = new Mock<IDailyPriceGridEndDateCalculator>();

                endDateCalculator.Setup(c => c.GetCurveEndDate(It.IsAny<ManualCurveDefinition<DailyTenor>>(),
                                                               It.IsAny<PublisherTenorPremium>(),
                                                               It.IsAny<IList<ILivePriceStreamService>>(),
                                                               It.IsAny<DateTime>()))
                                 .Returns(_curveEndDate);

                var gridBuilder = new Mock<IDailyPriceGridBuilder>();

                gridBuilder.Setup(b => b.GetDailyPriceRows(It.IsAny<IList<LinkedCurve>>(),
                                                           It.IsAny<DateTime>(), 
                                                           It.IsAny<DateTime>(), 
                                                           It.IsAny<DateTime>()))
                           .Returns(_dailyPriceGridBuilderResult);

                testObjects.SetupGet(o => o.GridBuilder)
                           .Returns(gridBuilder.Object);

                var bandBuilder = new Mock<IBandBuilder>();

                bandBuilder.Setup(b => b.CreateBands(It.IsAny<BandInfoDetails>(), 
                                                     It.IsAny<IList<ILivePriceStreamService>>(),
                                                     It.IsAny<IDispatcherExecutionService>()))
                           .Returns(_bandBuilderResult);

                testObjects.SetupGet(o => o.BandBuilder)
                           .Returns(bandBuilder.Object);

                var refreshService = new DailyPriceGridRefreshService
                                     {
                                         DailyPriceGridBuilder = gridBuilder.Object,
                                         BandBuilder = bandBuilder.Object,
                                         DailyPriceGridEndDateCalculator = endDateCalculator.Object
                                     };

                testObjects.SetupGet(o => o.DailyPriceGridRefreshService)
                           .Returns(refreshService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldBuildDailyPriceGrid()
        {
            var currentDate = new DateTime(2021, 1, 1);
            var expectedMandatoryDate = new DateTime(2021, 1, 6);
            var curveEndDate = new DateTime(2021, 1, 8);

            var dailyCurve= new ManualCurveDefinitionBuilder<DailyTenor>().WithId(101)
                                                                          .WithName("curve")
                                                                          .Build();
  
            var premium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var rows = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var bands = new List<BandHeader> { new(BandHeaderType.TenorHeader)};

            var dispatcher = Mock.Of<IDispatcherExecutionService>();

            var testObjects = new DailyPriceGridRefreshServiceTestObjectBuilder().WithCurveEndDate(curveEndDate)
                                                                                 .WithDailyPriceGridBuilderResult(rows)
                                                                                 .WithBandBuilderResult(bands)
                                                                                 .Build();

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var livePriceCurveIds = new[] { curveId1, curveId2 };

            var livePriceStream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(curveId1).Build();
            var livePriceStream2 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(curveId2).Build();

            var livePriceStreams = new[] { livePriceStream1.Object, livePriceStream2.Object };

            // ACT
            var result = testObjects.DailyPriceGridRefreshService.GetDailyPriceGrid(5, 
                                                                                    dailyCurve, 
                                                                                    premium,
                                                                                    livePriceStreams,
                                                                                    dispatcher,
                                                                                    currentDate);

            // ASSERT
            Mock.Get(testObjects.GridBuilder)
                .Verify(b => b.GetDailyPriceRows(It.Is<IList<LinkedCurve>>(ids => ids.SequenceEqual(livePriceCurveIds)), 
                                                 currentDate, 
                                                 It.Is<DateTime>(dt => dt == curveEndDate), 
                                                 It.Is<DateTime>(dt => dt == expectedMandatoryDate)));

            Mock.Get(testObjects.BandBuilder)
                .Verify(b => b.CreateBands(It.Is<BandInfoDetails>(i => i.LinkedCurve.Id == 101 
                                                                       && i.Name == "curve"
                                                                       && ReferenceEquals(i.DailyCurveDefinition, dailyCurve)
                                                                       && ReferenceEquals(i.PublisherTenorPremium, premium)), 
                                           It.Is<IList<ILivePriceStreamService>>(s => s.SequenceEqual(livePriceStreams)),
                                           dispatcher));

            Assert.That(result.DailyPriceRows, Is.SameAs(rows));
            Assert.That(result.Bands, Is.SameAs(bands));
        }

        [Test]
        public void ShouldSetManualBandCurveGroup_From_Matching_LiveCurve()
        {
            var currentDate = new DateTime(2021, 1, 1);
            var curveEndDate = new DateTime(2021, 1, 8);

            var crude = new CurveGroupTestObjectBuilder().Crude();
            var moGas = new CurveGroupTestObjectBuilder().MoGas();

			var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(101)
                                                                           .Build();

            var premium = new PublisherTenorPremiumTestObjectBuilder().Build();

            var rows = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
            };

            var bands = new List<BandHeader> { new(BandHeaderType.TenorHeader)};

            var dispatcher = Mock.Of<IDispatcherExecutionService>();

            var testObjects = new DailyPriceGridRefreshServiceTestObjectBuilder().WithCurveEndDate(curveEndDate)
                                                                                 .WithDailyPriceGridBuilderResult(rows)
                                                                                 .WithBandBuilderResult(bands)
                                                                                 .Build();

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var livePriceStream1 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(curveId1).WithCurveGroup(crude).Build();
            var livePriceStream2 = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(curveId2).WithCurveGroup(moGas).Build();

            var livePriceStreams = new[] { livePriceStream1.Object, livePriceStream2.Object };

            // ACT
            testObjects.DailyPriceGridRefreshService.GetDailyPriceGrid(5,
                                                                       dailyCurve,
                                                                       premium,
                                                                       livePriceStreams,
                                                                       dispatcher,
                                                                       currentDate);

            // ASSERT
            Mock.Get(testObjects.BandBuilder)
                .Verify(b => b.CreateBands(It.Is<BandInfoDetails>(i => i.CurveGroup.Id == crude.Id),
                                           It.IsAny<IList<ILivePriceStreamService>>(),
                                           dispatcher));
        }
    }
}
