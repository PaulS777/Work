﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Controllers.Bands;
using Dsp.Gui.Dashboard.DailyPricing.Models;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.GridBuilder
{
    internal interface IBandBuilderTestObjects
    {
        BandBuilder BandBuilder { get; }
    }

    [TestFixture]
    public class BandBuilderTests
    {
        private class BandBuilderTestObjectBuilder
        {
            private Mock<ILivePriceBandController> _livePriceBandController = new();

            public BandBuilderTestObjectBuilder WithLivePriceBandController(Mock<ILivePriceBandController> value)
            {
                _livePriceBandController = value;
                return this;
            }

            public IBandBuilderTestObjects Build()
            {
                var testObjects = new Mock<IBandBuilderTestObjects>();

                var manualCurveBandHeaderFactory = new Mock<IServiceFactory<IManualCurveBandHeaderController>>();
                var manualOverridesBandFactory = new Mock<IServiceFactory<IManualOverridesBandController>>();
                var tradeableSwitchBandFactory = new Mock<IServiceFactory<ITradeableSwitchBandController>>();
                var efpBandFactory = new Mock<IServiceFactory<IEfpBandController>>();
                var tenorPremiumsBandHeaderFactory = new Mock<IServiceFactory<ITenorPremiumsBandHeaderController>>();
                var livePriceBandHeaderFactory = new Mock<IServiceFactory<ILivePriceBandHeaderController>>();
                var livePriceBandFactory = new Mock<IServiceFactory<ILivePriceBandController>>();

                var manualCurveBandHeaderController = new Mock<IManualCurveBandHeaderController>();

                var manualCurveBandHeader = new ManualCurveBandHeader(Mock.Of<IDisposable>());

                manualCurveBandHeaderController.SetupGet(c => c.ViewModel)
                                               .Returns(manualCurveBandHeader);

                manualCurveBandHeaderFactory.Setup(f => f.Create())
                                            .Returns(manualCurveBandHeaderController.Object);

                var manualOverridesBandController = new Mock<IManualOverridesBandController>();

                var manualOverridesBand = new ManualOverridesBand(Mock.Of<IDisposable>());

                manualOverridesBandController.SetupGet(c => c.ViewModel)
                                             .Returns(manualOverridesBand);

                manualOverridesBandFactory.Setup(f => f.Create())
                                          .Returns(manualOverridesBandController.Object);

                var tradeableSwitchBandController = new Mock<ITradeableSwitchBandController>();

                var tradeableSwitchBand = new TradeableSwitchBand();

                tradeableSwitchBandController.SetupGet(c => c.ViewModel)
                                             .Returns(tradeableSwitchBand);

                tradeableSwitchBandFactory.Setup(f => f.Create())
                                          .Returns(tradeableSwitchBandController.Object);

                var efpBandController = new Mock<IEfpBandController>();

                var efpBand = new EfpBand(Mock.Of<IDisposable>());

                efpBandController.SetupGet(c => c.ViewModel)
                                 .Returns(efpBand);

                efpBandFactory.Setup(f => f.Create())
                              .Returns(efpBandController.Object);

                var tenorPremiumsBandHeaderController = new Mock<ITenorPremiumsBandHeaderController>();

                var tenorPremiumsBandHeader = new TenorPremiumsBandHeader(Mock.Of<IDisposable>());

                tenorPremiumsBandHeaderController.SetupGet(c => c.ViewModel)
                                                 .Returns(tenorPremiumsBandHeader);

                tenorPremiumsBandHeaderFactory.Setup(f => f.Create())
                                              .Returns(tenorPremiumsBandHeaderController.Object);

                var livePriceBandHeaderController1 = new Mock<ILivePriceBandHeaderController>();

                var livePriceBandHeader1 = new LivePriceBandHeader();

                livePriceBandHeaderController1.SetupGet(c => c.ViewModel)
                                              .Returns(livePriceBandHeader1);

                var livePriceBandHeaderController2 = new Mock<ILivePriceBandHeaderController>();

                var livePriceBandHeader2 = new LivePriceBandHeader();

                livePriceBandHeaderController2.SetupGet(c => c.ViewModel)
                                              .Returns(livePriceBandHeader2);

                livePriceBandHeaderFactory.SetupSequence(f => f.Create())
                                          .Returns(livePriceBandHeaderController1.Object)
                                          .Returns(livePriceBandHeaderController2.Object);

                var livePriceBandController1 = _livePriceBandController;

                var livePriceBand1 = new LivePriceBand(Mock.Of<IDisposable>());

                livePriceBandController1.SetupGet(c => c.ViewModel)
                                        .Returns(livePriceBand1);

                var livePriceBandController2 = new Mock<ILivePriceBandController>();

                var livePriceBand2 = new LivePriceBand(Mock.Of<IDisposable>());

                livePriceBandController2.SetupGet(c => c.ViewModel)
                                        .Returns(livePriceBand2);

                livePriceBandFactory.SetupSequence(f => f.Create())
                                    .Returns(livePriceBandController1.Object)
                                    .Returns(livePriceBandController2.Object);

                var builder = new BandBuilder
                              {
                                  ManualCurveBandHeaderFactory = manualCurveBandHeaderFactory.Object,
                                  ManualOverridesBandFactory = manualOverridesBandFactory.Object,
                                  TradeableSwitchBandFactory = tradeableSwitchBandFactory.Object,
                                  EfpBandFactory = efpBandFactory.Object,
                                  TenorPremiumsHeaderBandFactory = tenorPremiumsBandHeaderFactory.Object,
                                  LivePriceBandHeaderFactory = livePriceBandHeaderFactory.Object,
                                  LivePriceBandFactory = livePriceBandFactory.Object
                              };

                testObjects.SetupGet(o => o.BandBuilder)
                           .Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCreateBands_For_ManualCurve()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);

            var details = new BandInfoDetails
                          {
                              LinkedCurve = linkedCurve,
                              Name = "Manual"
                          };

            var liveStreams = new List<ILivePriceStreamService>();

            var testObjects = new BandBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.BandBuilder.CreateBands(details, 
                                                             liveStreams,
                                                             Mock.Of<IDispatcherExecutionService>());

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(3));

            Assert.That(result[0].BandHeaderType, Is.EqualTo(BandHeaderType.TenorHeader));

            Assert.That(result[1].BandHeaderType, Is.EqualTo(BandHeaderType.ManualCurveHeader));
            Assert.That(result[1].ManualCurveBandHeader, Is.Not.Null);


            Assert.That(result[1].ManualCurveBandHeader.BandInfos.Count, Is.EqualTo(3));
            Assert.That(result[1].ManualCurveBandHeader.Details(), Is.SameAs(details));
            Assert.That(result[1].ManualCurveBandHeader.LinkedCurve, Is.EqualTo(linkedCurve));
            Assert.That(result[1].ManualCurveBandHeader.Header, Is.EqualTo("Manual"));

            Assert.That(result[1].ManualCurveBandHeader.BandInfos[0], Is.TypeOf<ManualOverridesBand>());
            Assert.That(result[1].ManualCurveBandHeader.BandInfos[0].BandType, Is.EqualTo(BandType.OverridesBand));
            Assert.That(result[1].ManualCurveBandHeader.ManualOverridesBand, Is.Not.Null);
            Assert.That(result[1].ManualCurveBandHeader.ManualOverridesBand.LinkedCurve, Is.EqualTo(linkedCurve));
			Assert.That(result[1].ManualCurveBandHeader.EfpBand, Is.Not.Null);

            Assert.That(result[1].ManualCurveBandHeader.BandInfos[1], Is.TypeOf<TradeableSwitchBand>());
            Assert.That(result[1].ManualCurveBandHeader.BandInfos[1].BandType, Is.EqualTo(BandType.TradeableSwitchBand));

            Assert.That(result[1].ManualCurveBandHeader.BandInfos[2], Is.TypeOf<EfpBand>());
            Assert.That(result[1].ManualCurveBandHeader.BandInfos[2].BandType, Is.EqualTo(BandType.EfpBand));

            Assert.That(result[2].BandHeaderType, Is.EqualTo(BandHeaderType.TenorPremiumsHeader));
            Assert.That(result[2].TenorPremiumsBandHeader, Is.Not.Null);
            Assert.That(result[2].TenorPremiumsBandHeader.Details(), Is.SameAs(details));
            Assert.That(result[2].TenorPremiumsBandHeader.LinkedCurve, Is.EqualTo(linkedCurve));
        }

        [Test]
        public void ShouldCreateBandsWithColumnBindings_For_LiveCurves()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var details = new BandInfoDetails();

            var dispatcher = Mock.Of<IDispatcherExecutionService>();

            var liveStream1 = new MockLivePriceStreamServiceBuilder().WithName("curve-1")
                                                                     .WithCurveGroup(crude)
                                                                     .WithLinkedCurve(linkedCurve1)
                                                                     .WithPriceCurveSnapshot(new PriceCurveBuilder().Build())
                                                                     .Build();

            var liveStream2 = new MockLivePriceStreamServiceBuilder().WithName("curve-2")
                                                                     .WithCurveGroup(crude)
                                                                     .WithLinkedCurve(linkedCurve2)
                                                                     .WithPriceCurveSnapshot(new PriceCurveBuilder().Build())
                                                                     .Build();

            var liveStreams = new[] { liveStream1.Object, liveStream2.Object };

            var livePriceBandController = new Mock<ILivePriceBandController>();

            var testObjects = new BandBuilderTestObjectBuilder().WithLivePriceBandController(livePriceBandController)
                                                                .Build();

            // ACT
            var result = testObjects.BandBuilder.CreateBands(details, 
                                                             liveStreams, 
                                                             dispatcher);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(5));

            var band1 = result[3];

            Assert.That(band1.BandHeaderType, Is.EqualTo(BandHeaderType.LivePriceHeader));
            Assert.That(band1.LivePriceBandHeader, Is.Not.Null);
            Assert.That(band1.LivePriceBandHeader.Header, Is.EqualTo("curve-1"));
            Assert.That(band1.LivePriceBandHeader.CurveGroup.Id, Is.EqualTo(crude.Id));

            livePriceBandController.VerifySet(c => c.Dispatcher= dispatcher);
            
            Assert.That(band1.LivePriceBandHeader.LivePriceBand.CurveGroup.Id, Is.EqualTo(crude.Id));
            Assert.That(band1.LivePriceBandHeader.LivePriceBand.BandType, Is.EqualTo(BandType.LivePriceBand));
            Assert.That(band1.LivePriceBandHeader.LivePriceBand.LinkedCurve, Is.EqualTo(linkedCurve1));
            // todo : IsTradeable, RAG Status
            Assert.That(band1.LivePriceBandHeader.LivePriceBand.ColumnInfo.ColumnType, Is.EqualTo(ColumnType.LivePrice));
            Assert.That(band1.LivePriceBandHeader.LivePriceBand.ColumnInfo.BindingPath, Is.EqualTo("LivePrices[0]"));

            var band2 = result[4];

            Assert.That(band2.BandHeaderType, Is.EqualTo(BandHeaderType.LivePriceHeader));
            Assert.That(band2.LivePriceBandHeader, Is.Not.Null);
            Assert.That(band2.LivePriceBandHeader.Header, Is.EqualTo("curve-2"));
            Assert.That(band2.LivePriceBandHeader.CurveGroup, Is.EqualTo(crude));
            Assert.That(band2.LivePriceBandHeader.LivePriceBand.CurveGroup.Id, Is.EqualTo(crude.Id));
            Assert.That(band2.LivePriceBandHeader.LivePriceBand.BandType, Is.EqualTo(BandType.LivePriceBand));
            Assert.That(band2.LivePriceBandHeader.LivePriceBand.LinkedCurve, Is.EqualTo(linkedCurve2));
            Assert.That(band2.LivePriceBandHeader.LivePriceBand.ColumnInfo.ColumnType, Is.EqualTo(ColumnType.LivePrice));
            Assert.That(band2.LivePriceBandHeader.LivePriceBand.ColumnInfo.BindingPath, Is.EqualTo("LivePrices[1]"));
        }
    }
}
