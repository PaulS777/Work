﻿using System;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.GridBuilder
{
    [TestFixture]
    public class DayOfWeekCalculatorTests
    {
        [TestCase(2, ExpectedResult = 4, TestName = "Monday")]
        [TestCase(3, ExpectedResult = 3, TestName = "Tuesday")]
        [TestCase(4, ExpectedResult = 2, TestName = "Wednesday")]
        [TestCase(5, ExpectedResult = 1, TestName = "Thursday")]
        [TestCase(6, ExpectedResult = 7, TestName = "Friday")]
        [TestCase(7, ExpectedResult = 6, TestName = "Saturday")]
        [TestCase(8, ExpectedResult = 5, TestName = "Sunday")]
        public int Test(int day)
        {
            var startDate = new DateTime(2023, 1, day);

            var calculator = new DayOfWeekCalculator();

            var result = calculator.GetDaysToNextDayOfWeek(startDate, DayOfWeek.Friday);

            return result;
        }
    }
}
