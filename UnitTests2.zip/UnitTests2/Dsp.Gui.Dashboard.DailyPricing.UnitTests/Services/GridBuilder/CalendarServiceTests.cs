﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.GridBuilder;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.GridBuilder
{
    internal interface ICalendarServiceTestObjects
    {
        ISubject<IList<Calendar>> Calendars { get; }
        ICalendarService CalendarService { get; }
    }

    [TestFixture]
    public class CalendarServiceTests
    {
        private class CalendarServiceTestObjectObjectBuilder
        {
            private IList<Calendar> _calendars;

            public CalendarServiceTestObjectObjectBuilder WithCalendars(IList<Calendar> values)
            {
                _calendars = values;
                return this;
            }

            public ICalendarServiceTestObjects Build()
            {
                var testObjects = new Mock<ICalendarServiceTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                var calendars = new BehaviorSubject<IList<Calendar>>(_calendars);

                testObjects.SetupGet(o => o.Calendars)
                           .Returns(calendars);

                curveControlService.SetupGet(c => c.Calendars)
                                   .Returns(calendars);

                var calendarService = new CalendarService(curveControlService.Object);

                testObjects.SetupGet(o => o.CalendarService)
                           .Returns(calendarService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetIsBusinessDayTrue_For_PriceCellOnWeekday()
        {
            var wednesday = new DateTime(2021, 1, 6, 0, 0, 0, DateTimeKind.Utc);

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(wednesday)
                }
            };

            var testObjects = new CalendarServiceTestObjectObjectBuilder().Build();

            // ACT
            testObjects.CalendarService.ApplyBusinessDays(dailyPrices);

            // ASSERT
            Assert.That(dailyPrices[0].IsBusinessDay, Is.True);
            Assert.That(dailyPrices[0].TenorPremium.Model().CanApplyMargins, Is.True);
        }

        [Test]
        public void ShouldSetIsBusinessDayFalse_When_PriceCellIsWeekTenor_Or_WeekendDaily()
        {
            var saturday= new DateTime(2021, 1, 9, 0, 0, 0, DateTimeKind.Utc);

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Weekly
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(saturday)
                }
            };

            var testObjects = new CalendarServiceTestObjectObjectBuilder().Build();

            // ACT
            testObjects.CalendarService.ApplyBusinessDays(dailyPrices);

            // ASSERT
            Assert.That(dailyPrices[0].IsBusinessDay, Is.False);
            Assert.That(dailyPrices[0].TenorPremium.Model().CanApplyMargins, Is.False);

            Assert.That(dailyPrices[1].IsBusinessDay, Is.False);
            Assert.That(dailyPrices[1].TenorPremium.Model().CanApplyMargins, Is.False);
        }

        [Test]
        public void ShouldApplyCalendarHolidays_With_UkCalendar()
        {
            var ukHoliday = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var nonUkHoliday = new DateTime(2021, 1, 4, 0, 0, 0, DateTimeKind.Utc);

            var ukHolidays = new List<DateTime> {ukHoliday, new(2021, 12, 25, 0, 0, 0, DateTimeKind.Utc) };
            var nonUkHolidays = new List<DateTime> {nonUkHoliday};

            var ukCalendar = new Calendar(18, "code", "desc", string.Empty, string.Empty, string.Empty, false, ukHolidays);
            var nonUkCalendar = new Calendar(99, "code", "desc", string.Empty, string.Empty, string.Empty, false, nonUkHolidays);

            var calendars = new List<Calendar> {ukCalendar, nonUkCalendar};

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(ukHoliday)
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(nonUkHoliday)
                }
            };

            var testObjects = new CalendarServiceTestObjectObjectBuilder().WithCalendars(calendars)
                                                                          .Build();

            // ACT
            testObjects.CalendarService.ApplyBusinessDays(dailyPrices);

            // ASSERT
            Assert.That(dailyPrices[0].IsBusinessDay, Is.False);
            Assert.That(dailyPrices[0].TenorPremium.Model().CanApplyMargins, Is.False);

            Assert.That(dailyPrices[1].IsBusinessDay, Is.True);
            Assert.That(dailyPrices[1].TenorPremium.Model().CanApplyMargins, Is.True);
        }

        [Test]
        public void ShouldSetIsExtended_On_ExtendedPrices()
        {
            var day1 = new DateTime(2021, 1, 4, 0, 0, 0, DateTimeKind.Utc);
            var day2 = new DateTime(2021, 1, 5, 0, 0, 0, DateTimeKind.Utc);
            var holiday = new DateTime(2021, 1, 6, 0, 0, 0, DateTimeKind.Utc);

            var ukHolidays = new List<DateTime> { holiday };

            var ukCalendar = new Calendar(18, "code", "desc", string.Empty, string.Empty, string.Empty, false, ukHolidays);

            var calendars = new List<Calendar> { ukCalendar };

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(day1)
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(day2), IsExtended = true
                },
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(holiday), IsExtended = true
                }
            };

            var testObjects = new CalendarServiceTestObjectObjectBuilder().WithCalendars(calendars)
                                                                          .Build();

            // ACT
            testObjects.CalendarService.ApplyBusinessDays(dailyPrices);

            // ASSERT
            Assert.That(dailyPrices[0].IsExtended, Is.False);
            Assert.That(dailyPrices[1].IsExtended, Is.True);
            Assert.That(dailyPrices[2].IsExtended, Is.True);
        }

        [TestCase(3, 2, 2, TestName = "Monday")]
        [TestCase(6, 2, 2, TestName = "Thursday")]
        [TestCase(7, 2, 4, TestName = "Friday")]
        public void ShouldCalculateAdditionalDaysFromWeekdays(int day, int addedCount, int expected)
        {
            var friday = new DateTime(2023, 7, day, 0, 0, 0, DateTimeKind.Utc);

            var testObjects = new CalendarServiceTestObjectObjectBuilder().Build();

            // ACT
            var result = testObjects.CalendarService.GetDayCountIncludingNonBusinessDays(friday, addedCount);

            // ASSERT
            Assert.That(result, Is.EqualTo(expected));
        }

        [Test]
        public void ShouldCalculateAdditionalDaysWithHolidays()
        {
            var friday = new DateTime(2023, 7, 7, 0, 0, 0, DateTimeKind.Utc);

            var holiday = new DateTime(2023, 7, 10, 0, 0, 0, DateTimeKind.Utc);

            var ukHolidays = new List<DateTime> { holiday };

            var ukCalendar = new Calendar(18, "code", "desc", string.Empty, string.Empty, string.Empty, false, ukHolidays);

            var calendars = new List<Calendar> { ukCalendar };

            var testObjects = new CalendarServiceTestObjectObjectBuilder().WithCalendars(calendars)
                                                                          .Build();

            // ACT
            var result = testObjects.CalendarService.GetDayCountIncludingNonBusinessDays(friday, 2);

            // ASSERT
            Assert.That(result, Is.EqualTo(5));
        }

        [Test]
        public void ShouldNotApplyCalendars_When_Disposed()
        {
            var ukHoliday = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var ukHolidays = new List<DateTime> { ukHoliday };

            var ukCalendar = new Calendar(18, "code", "desc", string.Empty, string.Empty, string.Empty, false, ukHolidays);

            var calendars = new List<Calendar> { ukCalendar };

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>()) 
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(ukHoliday)
                }
            };

            var testObjects = new CalendarServiceTestObjectObjectBuilder().Build();

            testObjects.CalendarService.ApplyBusinessDays(dailyPrices);

            testObjects.CalendarService.Dispose();

            // ACT
            testObjects.Calendars.OnNext(calendars);

            // ASSERT
            Assert.That(dailyPrices[0].IsBusinessDay, Is.True);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var ukHoliday = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var ukHolidays = new List<DateTime> { ukHoliday };

            var ukCalendar = new Calendar(18, "code", "desc", string.Empty, string.Empty, string.Empty, false, ukHolidays);

            var calendars = new List<Calendar> { ukCalendar };

            var dailyPrices = new List<DailyPriceRowViewModel>
            {
                new(Mock.Of<IDisposable>())
                {
                    RowTenorType = RowTenorType.Daily,
                    DailyTenor = new DailyTenor(ukHoliday)
                }
            };

            var testObjects = new CalendarServiceTestObjectObjectBuilder().Build();

            testObjects.CalendarService.ApplyBusinessDays(dailyPrices);

            testObjects.CalendarService.Dispose();

            // ACT
            testObjects.CalendarService.Dispose();
            testObjects.Calendars.OnNext(calendars);

            // ASSERT
            Assert.That(dailyPrices[0].IsBusinessDay, Is.True);
        }
    }
}
