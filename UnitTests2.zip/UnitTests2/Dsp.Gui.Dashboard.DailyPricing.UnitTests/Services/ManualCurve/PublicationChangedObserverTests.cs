﻿using System;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.ManualCurve;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.ManualCurve
{
    internal interface IPublicationChangedObserverTestObjects
    {
        IPriceCurveSettingObserver PriceCurveSettingObserver { get; }
        ISubject<PriceCurveSetting> PriceCurveSetting { get; }
        ISubject<DateTime?> SystemDate { get; }
		PublicationChangedObserver PublicationChangedObserver { get; }
	}

	[TestFixture]
	public class PublicationChangedObserverTests
	{
        private class PublicationChangedObserverTestObjectBuilder
        {
            private DateTime _systemDate;
            private PriceCurveSetting _priceCurveSetting;

            public PublicationChangedObserverTestObjectBuilder WithSystemDate(DateTime value)
            {
                _systemDate = value;
                return this;
            }

            public PublicationChangedObserverTestObjectBuilder WithPriceCurveSetting(PriceCurveSetting value)
            {
                _priceCurveSetting = value;
                return this;
            }

			public IPublicationChangedObserverTestObjects Build()
            {
                var testObjects = new Mock<IPublicationChangedObserverTestObjects>();

                var priceCurveSetting = new BehaviorSubject<PriceCurveSetting>(_priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSetting)
                           .Returns(priceCurveSetting);

                var priceCurveSettingsObserver = new Mock<IPriceCurveSettingObserver>();

                priceCurveSettingsObserver.Setup(o => o.Observe(It.IsAny<int>()))
                                          .Returns(priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSettingObserver)
                           .Returns(priceCurveSettingsObserver.Object);

				var systemDate = new BehaviorSubject<DateTime?>(_systemDate);

                testObjects.SetupGet(o => o.SystemDate)
                           .Returns(systemDate);

                var systemDateProvider = new Mock<ISystemDateProvider>();

                systemDateProvider.SetupGet(p => p.SystemDate)
                                  .Returns(systemDate);

				var publicationChangedObserver = new PublicationChangedObserver(priceCurveSettingsObserver.Object,
                                                                                systemDateProvider.Object);

                testObjects.SetupGet(o => o.PublicationChangedObserver)
                           .Returns(publicationChangedObserver);

                return testObjects.Object;
            }
		}

        [Test]
        public void ShouldObservePriceCurveSetting_With_Id()
        {
            var testObjects = new PublicationChangedObserverTestObjectBuilder().Build();

            // ACT
            testObjects.PublicationChangedObserver.PublicationChanged(101, 10);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSettingObserver)
                .Verify(o => o.Observe(101));
		}

        #region snapshot

        [Test]
        public void ShouldPublishSnapshot_On_PriceCurveSetting_With_SystemDate()
        {
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(99)
                                                                            .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, 10);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(priceCurveSetting);

                // ASSERT
                Assert.That(result, Is.Not.Null);

                Assert.That(result.SystemDate, Is.EqualTo(date));
            }
        }

        [Test]
        public void ShouldPublishSnapshot_On_PriceCurveSetting_With_UserIsPublisher_With_ExcelSource()
        {
            var userId = 10;
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(userId)
                                                                            .WithIsExcelSource(true)
                                                                            .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, userId);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(priceCurveSetting);

				// ASSERT
				Assert.That(result.IsPublisher, Is.True);
                Assert.That(result.IsExcelSource, Is.True);
                Assert.That(result.PublisherId, Is.EqualTo(10));
			}
        }

        [Test]
        public void ShouldPublishSnapshot_On_PriceCurveSetting_With_UserIsPublisher_With_ExcelSourceFalse()
        {
            var userId = 10;
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(userId)
                                                                            .WithIsExcelSource(false)
                                                                            .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, userId);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(priceCurveSetting);

                // ASSERT
                Assert.That(result.IsPublisher, Is.True);
                Assert.That(result.IsExcelSource, Is.False);
                Assert.That(result.PublisherId, Is.EqualTo(10));
			}
        }

		[Test]
        public void ShouldPublishSnapshot_On_PriceCurveSetting_With_UserIsNotPublisher_With_ExcelSource()
        {
            var userId = 10;
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(11)
                                                                            .WithIsExcelSource(true)
                                                                            .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, userId);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(priceCurveSetting);

                // ASSERT
                Assert.That(result.IsPublisher, Is.False);
                Assert.That(result.IsExcelSource, Is.True);
                Assert.That(result.PublisherId, Is.EqualTo(11));
			}
        }

		#endregion

		#region Publish Update

		[Test]
        public void ShouldPublishUpdate_OnNext_SystemDate_With_PriceCurveSetting()
        {
            var date1 = new DateTime(2025, 1, 1);
            var date2 = new DateTime(2025, 1, 2);

			var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(99)
                                                                            .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date1)
                                                                               .WithPriceCurveSetting(priceCurveSetting)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, 10);

            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.SystemDate.OnNext(date2);

                // ASSERT
                Assert.That(result.SystemDate, Is.EqualTo(date2));
            }
        }

        [Test]
        public void ShouldPublishUpdate_On_UserTakesPublication_With_ExcelSource()
        {
            var userId = 10;
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(99)
                                                                            .WithIsExcelSource(false)
                                                                            .Build();

            var update = new PriceCurveSettingTestObjectBuilder().WithPublisherId(userId)
                                                                            .WithIsExcelSource(true)
                                                                            .Build();

			var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .WithPriceCurveSetting(priceCurveSetting)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, userId);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(update);

                // ASSERT
                Assert.That(result.IsPublisher, Is.True);
                Assert.That(result.IsExcelSource, Is.True);
                Assert.That(result.PublisherId, Is.EqualTo(10));
            }
		}

        [Test]
        public void ShouldPublishUpdate_On_UserTakesPublication_With_ExcelSourceFalse()
        {
            var userId = 10;
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(99)
                                                                            .WithIsExcelSource(false)
                                                                            .Build();

            var update = new PriceCurveSettingTestObjectBuilder().WithPublisherId(userId)
                                                                 .WithIsExcelSource(false)
                                                                 .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .WithPriceCurveSetting(priceCurveSetting)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, userId);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(update);

                // ASSERT
                Assert.That(result.IsPublisher, Is.True);
                Assert.That(result.IsExcelSource, Is.False);
            }
        }

        [Test]
        public void ShouldPublishUpdate_On_ExcelSourceChanged_With_UserIsPublisher()
        {
            var userId = 10;
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(userId)
                                                                            .WithIsExcelSource(false)
                                                                            .Build();

            var update = new PriceCurveSettingTestObjectBuilder().WithPublisherId(userId)
                                                                 .WithIsExcelSource(true)
                                                                 .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .WithPriceCurveSetting(priceCurveSetting)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, userId);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(update);

                // ASSERT
                Assert.That(result.IsPublisher, Is.True);
                Assert.That(result.IsExcelSource, Is.True);
            }
        }

        [Test]
        public void ShouldPublishUpdate_On_OtherUserTakesPublication_With_UserIsPublisher()
        {
            var userId = 10;
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(userId)
                                                                            .WithIsExcelSource(false)
                                                                            .Build();

            var update = new PriceCurveSettingTestObjectBuilder().WithPublisherId(11)
                                                                 .WithIsExcelSource(false)
                                                                 .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .WithPriceCurveSetting(priceCurveSetting)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, userId);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(update);

                // ASSERT
                Assert.That(result.IsPublisher, Is.False);
                Assert.That(result.IsExcelSource, Is.False);
                Assert.That(result.PublisherId, Is.EqualTo(11));
			}
        }

        [Test]
        public void ShouldNotPublishUpdate_On_ExcelSourceChanged_With_OtherUserAsPublisher()
        {
            var userId = 10;
            var date = new DateTime(2025, 1, 1);

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(11)
                                                                            .WithIsExcelSource(false)
                                                                            .Build();

            var update = new PriceCurveSettingTestObjectBuilder().WithPublisherId(11)
                                                                 .WithIsExcelSource(true)
                                                                 .Build();

            var testObjects = new PublicationChangedObserverTestObjectBuilder().WithSystemDate(date)
                                                                               .WithPriceCurveSetting(priceCurveSetting)
                                                                               .Build();

            var publicationChanged = testObjects.PublicationChangedObserver.PublicationChanged(101, userId);


            PublicationChangedArgs result = null;

            using (publicationChanged.Subscribe(args => result = args))
            {
                // ARRANGE
                result = null;

                // ACT
                testObjects.PriceCurveSetting.OnNext(update);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }

		#endregion
	}
}
