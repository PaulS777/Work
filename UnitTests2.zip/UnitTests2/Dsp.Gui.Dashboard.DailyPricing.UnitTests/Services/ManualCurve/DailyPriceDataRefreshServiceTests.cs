﻿using System;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.ManualCurve;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.ManualCurve
{
    internal interface IDailyPriceDataRefreshServiceTestObjects
    {
        ISubject<User> CurrentUser { get; }
        ISubject<ManualCurveDefinition<DailyTenor>> DailyCurveDefinition { get; }
        IPublicationChangedObserver PublicationChangedObserver { get; }
        ISubject<PublicationChangedArgs> PublicationChanged { get; }
        IPriceCurveSettingObserver PriceCurveSettingObserver { get; }
        ISubject<PriceCurveSetting> PriceCurveSetting { get; }
        ISubject<PublisherTenorPremium> PublisherTenorPremium { get; }
        IPublisherTenorPremiumProvider PublisherTenorPremiumProvider { get; }
        IDataRefreshActionCalculator DataRefreshActionCalculator { get; }
        DailyPriceDataRefreshService DailyPriceDataRefreshService { get; }
    }

    [TestFixture]
    public class DailyPriceDataRefreshServiceTests
    {
        private class DailyPriceDataRefreshServiceTestObjectBuilder
        {
            private User _currentUser;
            private ManualCurveDefinition<DailyTenor> _dailyCurveDefinition;
            private PublicationChangedArgs _publicationChanged;
            private PriceCurveSetting _priceCurveSetting;
            private PublisherTenorPremium _publisherTenorPremium;
            private DailyPriceDataRefreshAction _dataRefreshAction;

			public DailyPriceDataRefreshServiceTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

            public DailyPriceDataRefreshServiceTestObjectBuilder WithDailyCurveDefinition(ManualCurveDefinition<DailyTenor> value)
            {
                _dailyCurveDefinition = value;
                return this;
            }

            public DailyPriceDataRefreshServiceTestObjectBuilder WithPublicationChanged(PublicationChangedArgs value)
            {
                _publicationChanged = value;
                return this;
            }


			public DailyPriceDataRefreshServiceTestObjectBuilder WithPriceCurveSetting(PriceCurveSetting value)
            {
                _priceCurveSetting = value;
                return this;
            }

			public DailyPriceDataRefreshServiceTestObjectBuilder WithPublisherTenorPremium(PublisherTenorPremium value)
            {
                _publisherTenorPremium = value;
                return this;
            }

            public DailyPriceDataRefreshServiceTestObjectBuilder WithDataRefreshAction(DailyPriceDataRefreshAction value)
            {
                _dataRefreshAction = value;
                return this;
            }

			public IDailyPriceDataRefreshServiceTestObjects Build()
            {
                var testObjects = new Mock<IDailyPriceDataRefreshServiceTestObjects>();

                var currentUser = new BehaviorSubject<User>(_currentUser);

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(currentUser);

                var dailyCurveDefinition = new BehaviorSubject<ManualCurveDefinition<DailyTenor>>(_dailyCurveDefinition);

                testObjects.SetupGet(o => o.DailyCurveDefinition)
                           .Returns(dailyCurveDefinition);

                var dailyCurveDefinitionProvider = new Mock<IDailyCurveDefinitionProvider>();

                dailyCurveDefinitionProvider.Setup(p => p.GetDailyCurveDefinition(It.IsAny<int>()))
                                            .Returns(dailyCurveDefinition);

                var publicationChanged = new BehaviorSubject<PublicationChangedArgs>(_publicationChanged);

                testObjects.SetupGet(o => o.PublicationChanged)
                           .Returns(publicationChanged);

                var publicationChangedObserver = new Mock<IPublicationChangedObserver>();

                publicationChangedObserver.Setup(p => p.PublicationChanged(It.IsAny<int>(), It.IsAny<int>()))
                                          .Returns(publicationChanged);

                testObjects.SetupGet(o => o.PublicationChangedObserver)
                           .Returns(publicationChangedObserver.Object);

				var priceCurveSetting = new BehaviorSubject<PriceCurveSetting>(_priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSetting)
                           .Returns(priceCurveSetting);

                var priceCurveSettingObserver = new Mock<IPriceCurveSettingObserver>();

                priceCurveSettingObserver.Setup(p => p.Observe(It.IsAny<int>()))
                                         .Returns(priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSettingObserver)
                           .Returns(priceCurveSettingObserver.Object);

				var publisherTenorPremium = new BehaviorSubject<PublisherTenorPremium>(_publisherTenorPremium);

                testObjects.SetupGet(o => o.PublisherTenorPremium)
                           .Returns(publisherTenorPremium);

                var publisherTenorPremiumProvider = new Mock<IPublisherTenorPremiumProvider>();

                publisherTenorPremiumProvider.Setup(p => p.GetCurrentPublisherTenorPremium(It.IsAny<int>(),
                                                                                           It.IsAny<IObservable<int>>()))
                                             .Returns(publisherTenorPremium);

                testObjects.SetupGet(o => o.PublisherTenorPremiumProvider)
                           .Returns(publisherTenorPremiumProvider.Object);


                var dataRefreshActionCalculator = new Mock<IDataRefreshActionCalculator>();

                dataRefreshActionCalculator.Setup(c => c.CalculateRefreshAction(It.IsAny<ManualCurveDefinition<DailyTenor>>(),
                                                                                It.IsAny<PublisherTenorPremium>()))
                                           .Returns(_dataRefreshAction);

                testObjects.SetupGet(o => o.DataRefreshActionCalculator)
                           .Returns(dataRefreshActionCalculator.Object);

                var dailyPriceRefreshDataService = new DailyPriceDataRefreshService(curveControlService.Object,
                                                                                    dailyCurveDefinitionProvider.Object,
                                                                                    publicationChangedObserver.Object,
                                                                                    priceCurveSettingObserver.Object,
                                                                                    publisherTenorPremiumProvider.Object, 
                                                                                    dataRefreshActionCalculator.Object,
                                                                                    TestMocks.GetLoggerFactory().Object);

                testObjects.Setup(o => o.DailyPriceDataRefreshService)
                           .Returns(dailyPriceRefreshDataService);

                return testObjects.Object;
            }
        }

        #region Observe Publication Changed

        [Test]
        public void ShouldObservePublicationChanged_On_CurrentUser_And_ManualCurveId_Loaded()
        {
            const int userId = 10;
            const int curveId = 101;

            var currentUser = new UserBuilder().WithId(userId).User();
            var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(curveId).Build();

            var testObjects = new DailyPriceDataRefreshServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                 .Build();

            using (testObjects.DailyPriceDataRefreshService.RefreshPriceGrid(101).Subscribe(_ => {}))
            {
                // ACT
                testObjects.DailyCurveDefinition.OnNext(dailyCurve);

                // ASSERT
                Mock.Get(testObjects.PublicationChangedObserver)
                    .Verify(p => p.PublicationChanged(curveId, userId));
            }
        }

        #endregion

        #region Publish Snapshot

        [Test]
        public void ShouldObserveCurveSettingAndPremiums_On_PublicationChanged()
        {
            const int userId = 10;
            const int curveId = 101;

            var currentUser = new UserBuilder().WithId(userId).User();
            var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(curveId).Build();

            var testObjects = new DailyPriceDataRefreshServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                 .WithDailyCurveDefinition(dailyCurve)
                                                                                 .Build();

            var args = new PublicationChangedArgs(false, false, 99, DateTime.MinValue);

            using (testObjects.DailyPriceDataRefreshService.RefreshPriceGrid(101).Subscribe(_ => { }))
            {
                // ACT
                testObjects.PublicationChanged.OnNext(args);

                // ASSERT
                Mock.Get(testObjects.PriceCurveSettingObserver)
                    .Verify(o => o.Observe(curveId));

                Mock.Get(testObjects.PublisherTenorPremiumProvider)
                    .Verify(p => p.GetCurrentPublisherTenorPremium(curveId, It.IsAny<IObservable<int>>()));
            }
		}

        [Test]
        public void ShouldPublishSnapshot_And_StoreSnapshot_On_CurveSettingsAndPremiums()
        {
            const int userId = 10;
 
            var systemDate = new DateTime(2025, 1, 1);
            var currentUser = new UserBuilder().WithId(userId).User();
            var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().Build();
            var publication = new PublicationChangedArgs(true, true, 10, systemDate);

            var curveSettings = new PriceCurveSettingTestObjectBuilder().Build();
            var tenorPremiums = new PublisherTenorPremiumTestObjectBuilder().Build();

            var testObjects = new DailyPriceDataRefreshServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                 .WithDailyCurveDefinition(dailyCurve)
                                                                                 .WithPublicationChanged(publication)
                                                                                 .Build();

            DailyPriceDataRefreshArgs result = null;

            var count = 0;

            using (testObjects.DailyPriceDataRefreshService.RefreshPriceGrid(101).Subscribe(args =>
                                                                                            {
                                                                                                result = args; count++;
                                                                                            }))
            {
                // ACT
                testObjects.PriceCurveSetting.OnNext(curveSettings);
                testObjects.PublisherTenorPremium.OnNext(tenorPremiums);

                // ASSERT
                Assert.That(result, Is.Not.Null);
                Assert.That(result.RefreshAction , Is.EqualTo(DailyPriceDataRefreshAction.Rebuild));
                Assert.That(result.SystemDate, Is.EqualTo(systemDate));
                Assert.That(result.IsPublisher, Is.True);
                Assert.That(result.IsExcelSource , Is.True);
                Assert.That(result.DailyCurveDefinition, Is.SameAs(dailyCurve));
                Assert.That(result.PublisherTenorPremium, Is.SameAs(tenorPremiums));

                Mock.Get(testObjects.DataRefreshActionCalculator)
                    .Verify(c => c.StoreSnapshot(dailyCurve, tenorPremiums));

                Assert.That(count, Is.EqualTo(1));
            }
		}

        #endregion

        #region User is Publisher (Excel Source False) - Curve and Premium Updates

        [Test]
        public void ShouldPublishCurveRefresh_On_CurveUpdate_With_UserIsPublisher_And_ExcelSourceFalse()
        {
            const int userId = 10;
            var systemDate = new DateTime(2025, 1, 1);
            var currentUser = new UserBuilder().WithId(userId).User();
            var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

            var publication = new PublicationChangedArgs(true, false, 10, systemDate);

            var curveSettings = new PriceCurveSettingTestObjectBuilder().Build();
            var tenorPremiums = new PublisherTenorPremiumTestObjectBuilder().Build();

            var dailyCurveUpdate = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

			var testObjects = new DailyPriceDataRefreshServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                 .WithDailyCurveDefinition(dailyCurve)
                                                                                 .WithPublicationChanged(publication)
                                                                                 .WithPriceCurveSetting(curveSettings)
                                                                                 .WithPublisherTenorPremium(tenorPremiums)
                                                                                 .Build();

            DailyPriceDataRefreshArgs result = null;

			var count = 0;

            using (testObjects.DailyPriceDataRefreshService.RefreshPriceGrid(101).Subscribe(args =>
                                                                                            {
                                                                                                result = args; count++;
                                                                                            }))
            {
                // ACT
                testObjects.DailyCurveDefinition.OnNext(dailyCurveUpdate);

				// ASSERT
				Assert.That(result.RefreshAction, Is.EqualTo(DailyPriceDataRefreshAction.Update));
                Assert.That(result.SystemDate, Is.EqualTo(systemDate));
                Assert.That(result.IsPublisher, Is.True);
                Assert.That(result.IsExcelSource, Is.False);
                Assert.That(result.DailyCurveDefinition, Is.SameAs(dailyCurveUpdate));
                Assert.That(result.PublisherTenorPremium, Is.Null);

                Mock.Get(testObjects.DataRefreshActionCalculator)
                    .Verify(c => c.StoreSnapshot(dailyCurveUpdate, null));

                Assert.That(count, Is.EqualTo(2));
            }
		}

		[Test]
		public void ShouldPublishTenorPremiumRefresh_On_CurveUpdate_With_UserIsPublisher_And_ExcelSourceFalse()
		{
			const int userId = 10;
			var systemDate = new DateTime(2025, 1, 1);
			var currentUser = new UserBuilder().WithId(userId).User();
			var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

			var publication = new PublicationChangedArgs(true, false, 10, systemDate);

			var curveSettings = new PriceCurveSettingTestObjectBuilder().Build();
			var tenorPremiums = new PublisherTenorPremiumTestObjectBuilder().Build();

            var tenorPremiumsUpdate = new PublisherTenorPremiumTestObjectBuilder().Build();

			var testObjects = new DailyPriceDataRefreshServiceTestObjectBuilder().WithCurrentUser(currentUser)
																				 .WithDailyCurveDefinition(dailyCurve)
																				 .WithPublicationChanged(publication)
																				 .WithPriceCurveSetting(curveSettings)
																				 .WithPublisherTenorPremium(tenorPremiums)
																				 .Build();

			DailyPriceDataRefreshArgs result = null;

			var count = 0;

			using (testObjects.DailyPriceDataRefreshService.RefreshPriceGrid(101).Subscribe(args =>
                                                                                            {
                                                                                                result = args; count++;
                                                                                            }))
			{
				// ACT
				testObjects.PublisherTenorPremium.OnNext(tenorPremiumsUpdate);

				// ASSERT
				Assert.That(result.RefreshAction, Is.EqualTo(DailyPriceDataRefreshAction.Update));
				Assert.That(result.SystemDate, Is.EqualTo(systemDate));
				Assert.That(result.IsPublisher, Is.True);
				Assert.That(result.IsExcelSource, Is.False);
				Assert.That(result.DailyCurveDefinition, Is.Null);
				Assert.That(result.PublisherTenorPremium, Is.SameAs(tenorPremiumsUpdate));

				Mock.Get(testObjects.DataRefreshActionCalculator)
					.Verify(c => c.StoreSnapshot(null, tenorPremiums));

				Assert.That(count, Is.EqualTo(2));
			}
		}

		#endregion

		#region User is Non Publisher or Publisher with Excel Source - Curve and Premium Updates

        [TestCase(false, false, DailyPriceDataRefreshAction.Update, Description = "Non Publisher with Excel Off - Update")]
        [TestCase(false, true, DailyPriceDataRefreshAction.Update, Description = "Non Publisher with Excel On - Update")]
		[TestCase(true, true, DailyPriceDataRefreshAction.Update, Description = "Publisher with Excel Off - Update")]
        [TestCase(false, false, DailyPriceDataRefreshAction.Rebuild, Description = "Non Publisher with Excel Off - Update")]
        [TestCase(false, true, DailyPriceDataRefreshAction.Rebuild, Description = "Non Publisher with Excel On - Update")]
        [TestCase(true, true, DailyPriceDataRefreshAction.Rebuild, Description = "Publisher with Excel Off - Update")]
		public void ShouldPublishCalculatedRefreshAction_With_Latest_On_CurveUpdate_With_UserNotPublisherEditor(bool isPublisher,
                                                                                                                bool isExcelSource,
                                                                                                                DailyPriceDataRefreshAction refreshAction)
		{
			const int userId = 10;
			var systemDate = new DateTime(2025, 1, 1);
			var currentUser = new UserBuilder().WithId(userId).User();
			var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

			var publication = new PublicationChangedArgs(isPublisher, isExcelSource, 10, systemDate);

			var curveSettings = new PriceCurveSettingTestObjectBuilder().Build();
			var tenorPremiums = new PublisherTenorPremiumTestObjectBuilder().Build();

			var dailyCurveUpdate = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

			var testObjects = new DailyPriceDataRefreshServiceTestObjectBuilder().WithCurrentUser(currentUser)
																				 .WithDailyCurveDefinition(dailyCurve)
																				 .WithPublicationChanged(publication)
																				 .WithPriceCurveSetting(curveSettings)
																				 .WithPublisherTenorPremium(tenorPremiums)
                                                                                 .WithDataRefreshAction(refreshAction)
																				 .Build();

			DailyPriceDataRefreshArgs result = null;

			var count = 0;

			using (testObjects.DailyPriceDataRefreshService.RefreshPriceGrid(101).Subscribe(args =>
                                                                                            {
                                                                                                result = args; count++;
                                                                                            }))
			{
				// ACT
				testObjects.DailyCurveDefinition.OnNext(dailyCurveUpdate);

				// ASSERT
				Mock.Get(testObjects.DataRefreshActionCalculator)
                    .Verify(c => c.CalculateRefreshAction(dailyCurveUpdate, tenorPremiums));

				Assert.That(result.RefreshAction, Is.EqualTo(refreshAction));
				Assert.That(result.SystemDate, Is.EqualTo(systemDate));
				Assert.That(result.IsPublisher, Is.EqualTo(isPublisher));
				Assert.That(result.IsExcelSource, Is.EqualTo(isExcelSource));
				Assert.That(result.DailyCurveDefinition, Is.SameAs(dailyCurveUpdate));
				Assert.That(result.PublisherTenorPremium, Is.SameAs(tenorPremiums));

				Mock.Get(testObjects.DataRefreshActionCalculator)
					.Verify(c => c.StoreSnapshot(dailyCurveUpdate, tenorPremiums));

				Assert.That(count, Is.EqualTo(2));
			}
		}

		[TestCase(false, false, DailyPriceDataRefreshAction.Update, Description = "Non Publisher with Excel Off - Update")]
		[TestCase(false, true, DailyPriceDataRefreshAction.Update, Description = "Non Publisher with Excel On - Update")]
		[TestCase(true, true, DailyPriceDataRefreshAction.Update, Description = "Publisher with Excel Off - Update")]
		[TestCase(false, false, DailyPriceDataRefreshAction.Rebuild, Description = "Non Publisher with Excel Off - Update")]
		[TestCase(false, true, DailyPriceDataRefreshAction.Rebuild, Description = "Non Publisher with Excel On - Update")]
		[TestCase(true, true, DailyPriceDataRefreshAction.Rebuild, Description = "Publisher with Excel Off - Update")]
		public void ShouldPublishCalculatedRefreshAction_With_Latest_On_TenorPremiumUpdate_With_UserNotPublisherEditor(bool isPublisher,
                                                                                                                       bool isExcelSource, 
                                                                                                                       DailyPriceDataRefreshAction refreshAction)
		{
			const int userId = 10;  
			var systemDate = new DateTime(2025, 1, 1);
			var currentUser = new UserBuilder().WithId(userId).User();
			var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().Build();

			var publication = new PublicationChangedArgs(isPublisher, isExcelSource, 10, systemDate);

			var curveSettings = new PriceCurveSettingTestObjectBuilder().Build();
			var tenorPremiums = new PublisherTenorPremiumTestObjectBuilder().Build();

            var tenorPremiumsUpdate = new PublisherTenorPremiumTestObjectBuilder().Build();

			var testObjects = new DailyPriceDataRefreshServiceTestObjectBuilder().WithCurrentUser(currentUser)
																				 .WithDailyCurveDefinition(dailyCurve)
																				 .WithPublicationChanged(publication)
																				 .WithPriceCurveSetting(curveSettings)
																				 .WithPublisherTenorPremium(tenorPremiums)
																				 .WithDataRefreshAction(refreshAction)
																				 .Build();

			DailyPriceDataRefreshArgs result = null;

			var count = 0;

			using (testObjects.DailyPriceDataRefreshService.RefreshPriceGrid(101).Subscribe(args => 
                                                                                            { 
                                                                                                result = args; count++;
                                                                                            }))
			{
				// ACT
				testObjects.PublisherTenorPremium.OnNext(tenorPremiumsUpdate);

				// ASSERT
				Mock.Get(testObjects.DataRefreshActionCalculator)
					.Verify(c => c.CalculateRefreshAction(dailyCurve, tenorPremiumsUpdate));

				Assert.That(result.RefreshAction, Is.EqualTo(refreshAction));
				Assert.That(result.SystemDate, Is.EqualTo(systemDate));
				Assert.That(result.IsPublisher, Is.EqualTo(isPublisher));
				Assert.That(result.IsExcelSource, Is.EqualTo(isExcelSource));
				Assert.That(result.DailyCurveDefinition, Is.SameAs(dailyCurve));
				Assert.That(result.PublisherTenorPremium, Is.SameAs(tenorPremiumsUpdate));

				Mock.Get(testObjects.DataRefreshActionCalculator)
					.Verify(c => c.StoreSnapshot(dailyCurve, tenorPremiumsUpdate));

				Assert.That(count, Is.EqualTo(2));
			}
		}

		#endregion

		#region Publication Changed

        [Test]
		public void ShouldResubscribe_And_PublishSnapshot_On_PublicationChanged_With_UserIsPublisher()
        {
            var curveId = 101;
			var systemDate = new DateTime(2025, 1, 1);
			var currentUser = new UserBuilder().User();
			var dailyCurve = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(curveId).Build();

			var publication = new PublicationChangedArgs(false, false, 10, systemDate);

			var curveSettings = new PriceCurveSettingTestObjectBuilder().Build();
			var tenorPremiums = new PublisherTenorPremiumTestObjectBuilder().Build();

            var publicationUpdate = new PublicationChangedArgs(true, false, 10, systemDate);

			var testObjects = new DailyPriceDataRefreshServiceTestObjectBuilder().WithCurrentUser(currentUser)
																				 .WithDailyCurveDefinition(dailyCurve)
																				 .WithPublicationChanged(publication)
																				 .WithPriceCurveSetting(curveSettings)
																				 .WithPublisherTenorPremium(tenorPremiums)
																				 .Build();

			DailyPriceDataRefreshArgs result = null;

			var count = 0;

			using (testObjects.DailyPriceDataRefreshService.RefreshPriceGrid(101).Subscribe(args =>
                                                                                            {
                                                                                                result = args; count++;
                                                                                            }))
			{
				// ACT
				testObjects.PublicationChanged.OnNext(publicationUpdate);

				// ASSERT
                Mock.Get(testObjects.PriceCurveSettingObserver)
                    .Verify(o => o.Observe(curveId));

                Mock.Get(testObjects.PublisherTenorPremiumProvider)
                    .Verify(p => p.GetCurrentPublisherTenorPremium(curveId, It.IsAny<IObservable<int>>()));

                Assert.That(result.RefreshAction, Is.EqualTo(DailyPriceDataRefreshAction.Rebuild));
                Assert.That(result.SystemDate, Is.EqualTo(systemDate));
                Assert.That(result.IsPublisher, Is.True);
                Assert.That(result.IsExcelSource, Is.False);
                Assert.That(result.DailyCurveDefinition, Is.SameAs(dailyCurve));
                Assert.That(result.PublisherTenorPremium, Is.SameAs(tenorPremiums));

                Mock.Get(testObjects.DataRefreshActionCalculator)
                    .Verify(c => c.StoreSnapshot(dailyCurve, tenorPremiums));

                Assert.That(count, Is.EqualTo(2));
			}
		}

		#endregion
    }
}
