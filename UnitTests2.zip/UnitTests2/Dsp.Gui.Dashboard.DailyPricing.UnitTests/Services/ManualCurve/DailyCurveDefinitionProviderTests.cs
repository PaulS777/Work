﻿// ***********************************************************************************************************************
// DailyCurveDefinitionProviderTests.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.ManualCurve;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.ManualCurve
{
    internal interface IDailyCurveDefinitionProviderTestObjects
    {
        ISubject<List<ManualCurveDefinition<DailyTenor>>> ManualCurveDefinitions { get; }
        DailyCurveDefinitionProvider DailyCurveDefinitionProvider { get; }
    }

    [TestFixture]
    public class DailyCurveDefinitionProviderTests
    {
        private class DailyCurveDefinitionProviderTestObjectBuilder
        {
            public IDailyCurveDefinitionProviderTestObjects Build()
            {
                var testObjects = new Mock<IDailyCurveDefinitionProviderTestObjects>();

                var manualCurveDefinitions = new Subject<List<ManualCurveDefinition<DailyTenor>>>();

                testObjects.SetupGet(o => o.ManualCurveDefinitions)
                           .Returns(manualCurveDefinitions);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.DailyOverrides)
                                   .Returns(manualCurveDefinitions);

                var dailyCurveDefinitionProvider = new DailyCurveDefinitionProvider(curveControlService.Object);

                testObjects.SetupGet(o => o.DailyCurveDefinitionProvider)
                           .Returns(dailyCurveDefinitionProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishDailyCurveDefinition_On_DailyOverrides_With_Curve()
        {
            var testObjects = new DailyCurveDefinitionProviderTestObjectBuilder().Build();

            var dailyCurve1 = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(101)
                                                                            .Build();

            var dailyCurve2 = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(102)
                                                                            .Build();

            var dailyCurves = new List<ManualCurveDefinition<DailyTenor>> { 
                                                                              dailyCurve1,
                                                                              dailyCurve2
                                                                          };

            ManualCurveDefinition<DailyTenor> result = null;

            using (testObjects.DailyCurveDefinitionProvider.GetDailyCurveDefinition(102)
                              .Subscribe(curve => result = curve))
            {
                // ACT
                testObjects.ManualCurveDefinitions.OnNext(dailyCurves);

                // ASSERT
                Assert.That(result.Id, Is.EqualTo(102));
            }
        }

        [Test]
        public void ShouldPublishError_On_DailyOverrides_NotFound()
        {
            var testObjects = new DailyCurveDefinitionProviderTestObjectBuilder().Build();

            var dailyCurves = new List<ManualCurveDefinition<DailyTenor>>();

            Exception result = null;

            using (testObjects.DailyCurveDefinitionProvider.GetDailyCurveDefinition(101)
                              .Subscribe(_ => {}, ex => result = ex))
            {
                // ACT
                testObjects.ManualCurveDefinitions.OnNext(dailyCurves);

                // ASSERT
                Assert.IsNotNull(result);
            }
        }
    }
}
