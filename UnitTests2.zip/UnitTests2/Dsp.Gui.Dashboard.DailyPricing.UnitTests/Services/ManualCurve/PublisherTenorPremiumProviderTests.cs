﻿// ***********************************************************************************************************************
// PublisherTenorPremiumProviderTests.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.ManualCurve;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.ManualCurve
{
    internal interface IPublisherTenorPremiumProviderTestObjects
    {
        TestScheduler TestScheduler { get; }
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        ISubject<List<PublisherTenorPremium>> PublisherTenorPremiums { get; }
        PublisherTenorPremiumProvider PublisherTenorPremiumProvider { get; }
    }

    [TestFixture]
    public class PublisherTenorPremiumProviderTests
    {
        private class PublisherTenorPremiumsProviderTestObjectBuilder
        {
            private List<PublisherTenorPremium> _publisherTenorPremiums;

            public PublisherTenorPremiumsProviderTestObjectBuilder WithPublisherTenorPremiums(List<PublisherTenorPremium> values)
            {
                _publisherTenorPremiums = values;
                return this;
            }

            public IPublisherTenorPremiumProviderTestObjects Build()
            {
                var testObjects = new Mock<IPublisherTenorPremiumProviderTestObjects>();

                var publisherTenorPremiums = new BehaviorSubject<List<PublisherTenorPremium>>(_publisherTenorPremiums);

                testObjects.SetupGet(o => o.PublisherTenorPremiums)
                           .Returns(publisherTenorPremiums);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.PublisherTenorPremiums)
                                   .Returns(publisherTenorPremiums);

                var publisherTenorPremiumProvider = new PublisherTenorPremiumProvider(curveControlService.Object,
                                                                                      TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.PublisherTenorPremiumProvider)
                           .Returns(publisherTenorPremiumProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishTenorPremiumForCurrentPublisher_OnSubscribe()
        {
            var curveId = 101;
            var userId = 10;
            var publisherId = new BehaviorSubject<int>(userId);

            var publisherTenorPremiums 
                = new List<PublisherTenorPremium> 
                  {
                      new PublisherTenorPremiumTestObjectBuilder().WithId(1001).WithPriceCurveId(curveId).WithPublisherId(userId).Build(),
                      new PublisherTenorPremiumTestObjectBuilder().WithId(1002).WithPriceCurveId(curveId).WithPublisherId(11).Build(),
                      new PublisherTenorPremiumTestObjectBuilder().WithId(1003).WithPriceCurveId(301).WithPublisherId(userId).Build(),
                      new PublisherTenorPremiumTestObjectBuilder().WithId(1004).WithPriceCurveId(301).WithPublisherId(11).Build(),
                  };

            var testObjects = new PublisherTenorPremiumsProviderTestObjectBuilder().WithPublisherTenorPremiums(publisherTenorPremiums)
                                                                                   .Build();

            PublisherTenorPremium result = null;

            var premiums = testObjects.PublisherTenorPremiumProvider.GetCurrentPublisherTenorPremium(curveId, publisherId);

            // ACT
            using (premiums.Subscribe(value => result = value))
            {
                // ASSERT
                Assert.That(result.Id, Is.EqualTo(1001));
            }
        }

        [Test]
        public void ShouldPublishTenorPremiumUpdateForCurrentPublisher()
        {
            var curveId = 101;
            var userId = 10;
            var publisherId = new BehaviorSubject<int>(userId);

            var publisherTenorPremiums
                = new List<PublisherTenorPremium>
                  {
                      new PublisherTenorPremiumTestObjectBuilder().WithId(1001).WithPriceCurveId(curveId).WithPublisherId(userId).Build(),
                      new PublisherTenorPremiumTestObjectBuilder().WithId(1002).WithPriceCurveId(curveId).WithPublisherId(11).Build()
                  };

            var testObjects = new PublisherTenorPremiumsProviderTestObjectBuilder().WithPublisherTenorPremiums(publisherTenorPremiums)
                                                                                   .Build();

            PublisherTenorPremium result = null;

            var premiums = testObjects.PublisherTenorPremiumProvider.GetCurrentPublisherTenorPremium(curveId, publisherId);

            using (premiums.Subscribe(value => result = value))
            {
                var publisherTenorPremiumsUpdate 
                    = new List<PublisherTenorPremium> 
                      {
                          new PublisherTenorPremiumTestObjectBuilder().WithId(1001)
                                                                      .WithPriceCurveId(curveId)
                                                                      .WithPublisherId(userId)
                                                                      .WithTenorPremiums(new List<TenorPremium>{new(Mock.Of<ITenor>(), -1, 1)})
                                                                      .Build(),

                          new PublisherTenorPremiumTestObjectBuilder().WithId(1002)
                                                                      .WithPriceCurveId(curveId)
                                                                      .WithPublisherId(11)
                                                                      .Build()
                      };

                // ACT
                testObjects.PublisherTenorPremiums.OnNext(publisherTenorPremiumsUpdate);

                // ASSERT
                Assert.That(result.TenorPremiums.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishTenorPremium_When_PublisherChanged()
        {
            var curveId = 101;
            var userId = 10;
            var publisherId = new BehaviorSubject<int>(userId);

            var publisherTenorPremiums
                = new List<PublisherTenorPremium>
                  {
                      new PublisherTenorPremiumTestObjectBuilder().WithId(1001).WithPriceCurveId(curveId).WithPublisherId(userId).Build(),
                      new PublisherTenorPremiumTestObjectBuilder().WithId(1002).WithPriceCurveId(curveId).WithPublisherId(11).Build()
                  };

            var testObjects = new PublisherTenorPremiumsProviderTestObjectBuilder().WithPublisherTenorPremiums(publisherTenorPremiums)
                                                                                   .Build();

            PublisherTenorPremium result = null;

            var premiums = testObjects.PublisherTenorPremiumProvider.GetCurrentPublisherTenorPremium(curveId, publisherId);

            using (premiums.Subscribe(value => result = value))
            {
                // ACT
                publisherId.OnNext(11);

                // ASSERT
                Assert.That(result.Id, Is.EqualTo(1002));
            }
        }
    }
}
