﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.DailyPricing.Services.ManualCurve;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.ManualCurve
{
	[TestFixture]
	public class DataRefreshActionCalculatorTests
	{
        #region Overrides

        [Test]
        public void ShouldPublishUpdate_When_Calculate_With_ManualCurveLastTenor_EqualToPrevious()
        {
            var snapshot = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>
                                                                                        {
                                                                                            new(new DailyTenor(2025, 1, 1), 1.0)
                                                                                        })
                                                                         .Build();

            var update = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>
                                                                                      {
                                                                                          new(new DailyTenor(2025, 1, 1), 1.0)
                                                                                      })
                                                                       .Build();

            var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(snapshot, null);

            // ACT
            var result = calculator.CalculateRefreshAction(update, null);

            // ASSERT
            Assert.That(result, Is.EqualTo(DailyPriceDataRefreshAction.Update));
        }

		[Test]
        public void ShouldPublishRefresh_When_Calculate_With_ManualCurveLastTenor_GreaterThanPrevious()
        {
            var snapshot = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>> 
                                                                                        {
                                                                                            new(new DailyTenor(2025, 1, 1), 1.0)
                                                                                        })
                                                                         .Build();

            var update = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>
                                                                                      {
                                                                                          new(new DailyTenor(2025, 1, 1), 1.0),
                                                                                          new(new DailyTenor(2025, 1, 2), 1.0)
                                                                                      })
                                                                       .Build();

            var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(snapshot, null);

			// ACT
            var result = calculator.CalculateRefreshAction(update, null);

            // ASSERT
            Assert.That(result , Is.EqualTo(DailyPriceDataRefreshAction.Rebuild));
        }

        [Test]
        public void ShouldPublishRefresh_When_Calculate_With_ManualCurveLastTenor_LessThanPrevious()
        {
            var snapshot = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>
                                                                                        {
                                                                                            new(new DailyTenor(2025, 1, 1), 1.0),
                                                                                            new(new DailyTenor(2025, 1, 2), 1.0)
                                                                                        })
                                                                         .Build();


            var update = new ManualCurveDefinitionBuilder<DailyTenor>().WithOverrides(new List<CurvePoint<DailyTenor>>
                                                                                      {
                                                                                          new(new DailyTenor(2025, 1, 1), 1.0)
                                                                                      })
                                                                       .Build();

            var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(snapshot, null);

            // ACT
            var result = calculator.CalculateRefreshAction(update, null);

            // ASSERT
            Assert.That(result, Is.EqualTo(DailyPriceDataRefreshAction.Rebuild));
        }

		#endregion

		#region EFP

		[Test]
        public void ShouldPublishUpdate_When_Calculate_With_EfpLastTenor_EqualToPrevious()
        {
            var snapshot = new ManualCurveDefinitionBuilder<DailyTenor>().WithEfpNarratives(new List<EfpNarrative<DailyTenor>>
                                                                                            {
                                                                                                new(new DailyTenor(2025, 1,1), null, null)
                                                                                            })
                                                                         .Build();

			var update = new ManualCurveDefinitionBuilder<DailyTenor>().WithEfpNarratives(new List<EfpNarrative<DailyTenor>>
                                                                                          {
                                                                                              new(new DailyTenor(2025, 1,1), null, null)
                                                                                          })
                                                                       .Build();

            var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(snapshot, null);

            // ACT
            var result = calculator.CalculateRefreshAction(update, null);

            // ASSERT
            Assert.That(result, Is.EqualTo(DailyPriceDataRefreshAction.Update));
        }

        [Test]
        public void ShouldPublishRebuild_When_Calculate_With_EfpLastTenor_GreaterThanPrevious()
        {
            var snapshot = new ManualCurveDefinitionBuilder<DailyTenor>().WithEfpNarratives(new List<EfpNarrative<DailyTenor>>
                                                                                            {
                                                                                                new(new DailyTenor(2025, 1,1), null, null)
                                                                                            })
                                                                         .Build();

            var update = new ManualCurveDefinitionBuilder<DailyTenor>().WithEfpNarratives(new List<EfpNarrative<DailyTenor>>
                                                                                          {
                                                                                              new(new DailyTenor(2025, 1,1), null, null),
                                                                                              new(new DailyTenor(2025, 1,2), null, null)
                                                                                          })
                                                                       .Build();

            var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(snapshot, null);

            // ACT
            var result = calculator.CalculateRefreshAction(update, null);

            // ASSERT
            Assert.That(result, Is.EqualTo(DailyPriceDataRefreshAction.Rebuild));
        }

        [Test]
        public void ShouldPublishRebuild_When_Calculate_With_EfpLastTenor_LessThanPrevious()
        {
            var snapshot = new ManualCurveDefinitionBuilder<DailyTenor>().WithEfpNarratives(new List<EfpNarrative<DailyTenor>>
                                                                                            {
                                                                                                new(new DailyTenor(2025, 1,1), null, null),
                                                                                                new(new DailyTenor(2025, 1,2), null, null)
                                                                                            })
                                                                         .Build();

            var update = new ManualCurveDefinitionBuilder<DailyTenor>().WithEfpNarratives(new List<EfpNarrative<DailyTenor>>
                                                                                          {
                                                                                              new(new DailyTenor(2025, 1,1), null, null)
                                                                                          })
                                                                       .Build();

            var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(snapshot, null);

            // ACT
            var result = calculator.CalculateRefreshAction(update, null);

            // ASSERT
            Assert.That(result, Is.EqualTo(DailyPriceDataRefreshAction.Rebuild));
        }

		#endregion

		#region Tenor Premiums

		[Test]
		public void ShouldPublishUpdate_When_Calculate_With_TenorPremiumLastTenor_EqualToPrevious()
        {
            var snapshot = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums([
                                                                                              new TenorPremium(new DailyTenor(2025,1,1), 0, 0)
                                                                                          ])
                                                                       .Build();

            var update = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums([
                                                                                            new TenorPremium(new DailyTenor(2025, 1, 1), 0, 0)
                                                                                        ])
                                                                       .Build();

			var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(null, snapshot);

            // ACT
            var result = calculator.CalculateRefreshAction(null, update);

            // ASSERT
            Assert.That(result, Is.EqualTo(DailyPriceDataRefreshAction.Update));
        }

        [Test]
        public void ShouldPublishUpdate_When_Calculate_With_TenorPremiumLastTenor_GreaterThanPrevious()
        {
            var snapshot = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums([
                                                                                              new TenorPremium(new DailyTenor(2025, 1, 1), 0, 0)
                                                                                          ])
                                                                       .Build();

            var update = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums([
                                                                                            new TenorPremium(new DailyTenor(2025, 1, 1), 0, 0),
                                                                                            new TenorPremium(new DailyTenor(2025, 1, 2), 0, 0)
																						])
                                                                     .Build();

            var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(null, snapshot);

            // ACT
            var result = calculator.CalculateRefreshAction(null, update);

            // ASSERT
            Assert.That(result, Is.EqualTo(DailyPriceDataRefreshAction.Rebuild));
        }

        [Test]
        public void ShouldPublishUpdate_When_Calculate_With_TenorPremiumLastTenor_LessThanPrevious()
        {
            var snapshot = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums([
                                                                                              new TenorPremium(new DailyTenor(2025, 1, 1), 0, 0)
                                                                                          ])
                                                                       .Build();

            var update = new PublisherTenorPremiumTestObjectBuilder().WithTenorPremiums([
                                                                                            new TenorPremium(new DailyTenor(2025, 1, 1), 0, 0),
                                                                                            new TenorPremium(new DailyTenor(2025, 1, 2), 0, 0)
                                                                                        ])
                                                                     .Build();

            var calculator = new DataRefreshActionCalculator();

            // ARRANGE
            calculator.StoreSnapshot(null, snapshot);

            // ACT
            var result = calculator.CalculateRefreshAction(null, update);

            // ASSERT
            Assert.That(result, Is.EqualTo(DailyPriceDataRefreshAction.Rebuild));
        }

		#endregion
	}
}
