﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.DailyPricing.Services.DataSource;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using DynamicData;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.DataSource
{
    internal interface IDailyPriceRowDataSourceServiceTestObjects
    {
        IDailyPriceRowDataSource DataSource { get; }
        ISubject<IChangeSet<DailyPriceRowViewModel>> DataSourceConnect { get; }
        DailyPriceRowDataSourceService DailyPriceRowDataSourceService { get; }
    }

    [TestFixture]
    public class DailyPriceRowDataSourceServiceTests
    {
        private class DailyPriceRowDataSourceServiceTestObjectBuilder
        {
            private List<DailyPriceRowViewModel> _dataSourceItems;
            
            public DailyPriceRowDataSourceServiceTestObjectBuilder WithDataSourceItems(List<DailyPriceRowViewModel> values)
            {
                _dataSourceItems = values;
                return this;
            }

            public IDailyPriceRowDataSourceServiceTestObjects Build()
            {
                var testObjects = new Mock<IDailyPriceRowDataSourceServiceTestObjects>();

                var connect = new Subject<IChangeSet<DailyPriceRowViewModel>>();

                testObjects.SetupGet(o => o.DataSourceConnect)
                           .Returns(connect);

                var dataSource = new Mock<IDailyPriceRowDataSource>();

                dataSource.Setup(d => d.Connect(It.IsAny<Func<DailyPriceRowViewModel, bool>>()))
                          .Returns(connect);

                dataSource.Setup(d => d.Items())
                          .Returns(_dataSourceItems);

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var service = new DailyPriceRowDataSourceService
                              {
                                  DataSource = dataSource.Object
                              };

                testObjects.SetupGet(o => o.DailyPriceRowDataSourceService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldConnectBusinessDayRows()
        {
            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().Build();

            // ACT
            testObjects.DailyPriceRowDataSourceService.ConnectBusinessDays();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.Connect(It.IsAny<Func<DailyPriceRowViewModel, bool>>()));
        }

        [Test]
        public void ShouldReturnDataSourceConnectObservable()
        {
            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().Build();

            IChangeSet<DailyPriceRowViewModel> result = null;

            // ACT
            using (testObjects.DailyPriceRowDataSourceService.ConnectBusinessDays().Subscribe(c => result = c))
            {
                testObjects.DataSourceConnect.OnNext(new ChangeSet<DailyPriceRowViewModel>());

                // ASSERT
                Assert.That(result, Is.Not.Null);
            }
        }

        [Test]
        public void ShouldGetBusinessDayRows()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var rows = new List<DailyPriceRowViewModel>
                       {
                           row1,
                           new DailyPriceRowTestObjectBuilder().Build(),
                           row2
                       };

            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().WithDataSourceItems(rows)
                                                                                   .Build();

            var expected = new[] { row1 };

            // ACT
            var result = testObjects.DailyPriceRowDataSourceService.BusinessDayRows();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.Items());

            Assert.That(result.SequenceEqual(expected));
        }

        [Test]
        public void ShouldRemoveItemsToLastNonNewRow_When_RemoveNewRows_With_NewRows()
        {
            var rows = new List<DailyPriceRowViewModel>
                       {
                           new DailyPriceRowTestObjectBuilder().Build(),
                           new DailyPriceRowTestObjectBuilder().Build(),
                           // remove from here
                           new DailyPriceRowTestObjectBuilder().WithIsNew(true).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsNew(true).Build()
                       };

            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().WithDataSourceItems(rows)
                                                                                   .Build();

            // ACT
            testObjects.DailyPriceRowDataSourceService.RemoveNewRows();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.RemoveItemsFromIndex(2));
        }

        [Test]
        public void ShouldNotRemoveItems_When_RemoveNewRows_With_NoNewRows()
        {
            var rows = new List<DailyPriceRowViewModel>
                       {
                           new DailyPriceRowTestObjectBuilder().WithIsNew(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsNew(false).Build()
                       };

            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().WithDataSourceItems(rows)
                                                                                   .Build();

            // ACT
            testObjects.DailyPriceRowDataSourceService.RemoveNewRows();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.RemoveItemsFromIndex(It.IsAny<int>()), Times.Never());
        }

        [Test]
        public void ShouldRemoveItemsToExtendedWithValue_When_RemoveExcessRows_With_Extended_And_NewRows()
        {
            var rows = new List<DailyPriceRowViewModel>
                       {
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).WithMidPriceServer(1.0M).Build(),
                           // remove from here
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsNew(true).WithIsBusinessDay(true).WithBidMarginServerValue(1.0M).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsNew(true).WithIsBusinessDay(true).WithBidMarginServerValue(1.0M).Build(),

                       };

            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().WithDataSourceItems(rows)
                                                                                   .Build();

            // ACT
            testObjects.DailyPriceRowDataSourceService.RemoveExcessRows();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.RemoveItemsFromIndex(4));
        }

        [Test]
        public void ShouldRemoveItemsToMandatoryRow_When_RemoveExcessRows_With_NewRows_And_NoExtended()
        {
            var rows = new List<DailyPriceRowViewModel>
                       {
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           // remove from here
                           new DailyPriceRowTestObjectBuilder().WithIsNew(true).WithBidMarginServerValue(1.0M).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsNew(true).WithBidMarginServerValue(1.0M).Build()
                       };

            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().WithDataSourceItems(rows)
                                                                                   .Build();

            // ACT
            testObjects.DailyPriceRowDataSourceService.RemoveExcessRows();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.RemoveItemsFromIndex(2));
        }

        [Test]
        public void ShouldRemoveItemsToExtendedWithValue_When_RemoveExcessRows_With_ExtendedRows_And_NoNewRows()
        {
            var rows = new List<DailyPriceRowViewModel>
                       {
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).WithMidPriceServer(5.0m).Build(),
                           // remove from here
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).Build()
                       };

            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().WithDataSourceItems(rows)
                                                                                   .Build();

            // ACT
            testObjects.DailyPriceRowDataSourceService.RemoveExcessRows();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.RemoveItemsFromIndex(4));
        }

        [Test]
        public void ShouldRemoveWeeklyTenorRow_When_RemoveExcessRows_With_ExtendedRows_And_NoNewRows()
        {
            var rows = new List<DailyPriceRowViewModel>
                       {
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).WithMidPriceServer(5.0m).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsWeeklyTenor(true).WithIsExtended(true).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).WithMidPriceServer(5.0m).Build(),
                           // remove from here
                           new DailyPriceRowTestObjectBuilder().WithIsWeeklyTenor(true).WithIsExtended(true).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(true).WithIsBusinessDay(true).Build()
                       };

            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().WithDataSourceItems(rows)
                                                                                   .Build();

            // ACT
            testObjects.DailyPriceRowDataSourceService.RemoveExcessRows();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.RemoveItemsFromIndex(6));
        }

        [Test]
        public void ShouldNotRemoveItems_When_RemoveExcessRows_With_NoExtended_Or_NewRows()
        {
            var rows = new List<DailyPriceRowViewModel>
                       {
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build(),
                           new DailyPriceRowTestObjectBuilder().WithIsExtended(false).Build()
                       };

            var testObjects = new DailyPriceRowDataSourceServiceTestObjectBuilder().WithDataSourceItems(rows)
                                                                                   .Build();

            // ACT
            testObjects.DailyPriceRowDataSourceService.RemoveExcessRows();

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.RemoveItemsFromIndex(It.IsAny<int>()), Times.Never);
        }
    }
}
