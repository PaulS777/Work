﻿using System;
using Dsp.Gui.Dashboard.DailyPricing.Services.Commands;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Commands
{
    [TestFixture]
    internal class SetSelectedRowsServiceTests
    {
        [Test]
        public void ShouldResetSelectedTenorPremiums_And_EfpNarratives()
        {
            var row1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                EfpNarrative = { IsSelected = true},
                TenorPremium = {IsSelected = true, BidMargin = {IsSelected = true}, AskMargin = {IsSelected = true}}
            };

            var row2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>());

            var grid = new[] {row1, row2};
            var selected = new[] {row2};

            var service = new SetSelectedRowsService();

            // ACT
            service.SetSelectedRows(grid, selected);

            // ASSERT
            Assert.That(row1.EfpNarrative.IsSelected, Is.False);
            Assert.That(row1.TenorPremium.IsSelected, Is.False);
            Assert.That(row1.TenorPremium.BidMargin.IsSelected, Is.False);
            Assert.That(row1.TenorPremium.AskMargin.IsSelected, Is.False);

            Assert.That(row2.EfpNarrative.IsSelected, Is.True);
            Assert.That(row2.TenorPremium.IsSelected, Is.True);
            Assert.That(row2.TenorPremium.BidMargin.IsSelected, Is.True);
            Assert.That(row2.TenorPremium.AskMargin.IsSelected, Is.True);
        }
    }
}
