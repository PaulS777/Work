﻿using System.Collections.Generic;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Overrides;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.Overrides
{
    [TestFixture]
    public class ManualOverridesUndoChangesServiceTests
    {
        [Test]
        public void ShouldUndoChanges_With_PriceIsTradeable()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithMidPriceServer(1.0M)
                                                          .WithMidPrice(1.2M)
                                                          .WithMidPriceManual(1.2M)
                                                          .WithIsTradeable(true)
                                                          .WithPriceHasManualChange(true)
                                                          .Build();

            var price = row.ManualPriceCell;

            var rows = new List<DailyPriceRowViewModel> { row };

            var service = new ManualOverridesUndoChangesService();

            // ACT
            service.UndoChanges(rows);

            // ASSERT
            Assert.That(price.MidPrice, Is.EqualTo(1.0M));
            Assert.That(price.Model().MidPriceManual, Is.Null);
            Assert.That(price.HasManualChange, Is.False);
        }

        [Test]
        public void ShouldUndoChanges_With_PriceNonTradeable()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithMidPriceServer(1.0M)
                                                          .WithMidPrice(null)
                                                          .WithMidPriceManual(null)
                                                          .WithIsTradeable(false)
                                                          .WithPriceHasManualChange(true)
                                                          .Build();

            var rows = new List<DailyPriceRowViewModel> { row };

            var service = new ManualOverridesUndoChangesService();

            // ACT
            service.UndoChanges(rows);

            // ASSERT
            Assert.That(row.ManualPriceCell.IsTradeable, Is.True);
            Assert.That(row.ManualPriceCell.MidPrice, Is.EqualTo(1.0M));
            Assert.That(row.ManualPriceCell.Model().MidPriceManual, Is.Null);
            Assert.That(row.ManualPriceCell.HasManualChange, Is.False);
        }
    }
}
