﻿using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Overrides;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using DynamicData;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.Overrides
{
    [TestFixture]
    internal class ManualOverridesChangedServiceTests
    {
        [Test]
        public void ShouldSetHasChangesFalse_When_SubscribeUpdates_With_NoChanges()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                {
                                                                    new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesChangedService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
            Assert.That(row1.ManualPriceCell.CurveOverridesChanged, Is.False);
            Assert.That(row2.ManualPriceCell.CurveOverridesChanged, Is.False);
        }

        [Test]
        public void ShouldSetHasChangesTrue_When_SubscribeUpdates_With_Change()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithPriceHasManualChange(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesChangedService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
            Assert.That(row1.ManualPriceCell.CurveOverridesChanged, Is.True);
            Assert.That(row2.ManualPriceCell.CurveOverridesChanged, Is.True);
        }

        [Test]
        public void ShouldSetBandHasChangesTrue_When_PriceChange()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });


            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.ManualPriceCell.HasManualChange = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
            Assert.That(row1.ManualPriceCell.CurveOverridesChanged, Is.True);
            Assert.That(row2.ManualPriceCell.CurveOverridesChanged, Is.True);
        }

        [Test]
        public void ShouldNotSetBandHasChangesTrue_After_UnsubscribeUpdates()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });


            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            service.UnsubscribeUpdates();

            // ACT
            row1.ManualPriceCell.HasManualChange = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }

        [Test]
        public void ShouldSubscribeUpdates_After_UnsubscribeUpdates()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });


            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);
            service.UnsubscribeUpdates();

            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.ManualPriceCell.HasManualChange = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
        }

        [Test]
        public void ShouldNotSubscribeUpdates_When_Disposed()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });


            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.Dispose();
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.ManualPriceCell.HasManualChange = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).Build();

            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });


            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesChangedService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.Dispose();

            // ACT
            service.Dispose(); 
            service.SubscribeUpdates(dailyPrices);

            row1.ManualPriceCell.HasManualChange = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }
    }
}
