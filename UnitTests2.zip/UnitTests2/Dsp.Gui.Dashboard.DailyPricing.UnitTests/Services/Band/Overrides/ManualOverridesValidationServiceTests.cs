﻿using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Overrides;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using DynamicData;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.Overrides
{
    [TestFixture]
    internal class ManualOverridesValidationServiceTests
    {
        [Test]
        public void ShouldSetIsValidTrue_When_SubscribeUpdates_With_AllPricesNotNull()
        {
            var band = new ManualOverridesBandTestObjectBuilder().WithHasErrors(true)
                                                                 .WithErrorText("error")
                                                                 .Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
            Assert.That(band.ErrorText, Is.Null);

            Assert.That(row1.ManualPriceCell.IsValid, Is.True);
            Assert.That(row2.ManualPriceCell.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_SubscribeUpdates_With_MissingPrice()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(null)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);

            Assert.That(row1.ManualPriceCell.IsValid, Is.True);
            Assert.That(row2.ManualPriceCell.IsValid, Is.False);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_EndOfRange_TradeablePriceSetToNull()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);

            service.SubscribeUpdates(dailyPrices);

            // ACT
            row2.ManualPriceCell.MidPrice = null;

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);

            Assert.That(row1.ManualPriceCell.IsValid, Is.True);
            Assert.That(row2.ManualPriceCell.IsValid, Is.False);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_StartOfRange_TradeablePriceSetToNull()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.2M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2, row3 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row1.ManualPriceCell.IsValid, Is.False);

            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);

            // ASSERT - Other prices valid
            Assert.That(row2.ManualPriceCell.IsValid, Is.True);
            Assert.That(row3.ManualPriceCell.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidTrue_When_StartOfRange_TradeableNullPriceSetToNonTradeable()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.2M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2, row3 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            row1.ManualPriceCell.MidPrice = null;

            // ACT
            row1.ManualPriceCell.IsTradeable = false;

            // ASSERT - Invalid missing price
            Assert.That(row1.ManualPriceCell.IsValid, Is.True);

            Assert.That(band.HasErrors, Is.False);
            Assert.That(band.ErrorText, Is.Null);

            // ASSERT - Other prices valid
            Assert.That(row2.ManualPriceCell.IsValid, Is.True);
            Assert.That(row3.ManualPriceCell.IsValid, Is.True);
        }


        [Test]
        public void ShouldSetIsValidTrue_When_StartOfRange_NonMandatoryTradeablePriceSetToNull()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(false)
                                                           .WithMidPrice(null)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(false)
                                                           .WithMidPrice(null)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(false)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.2M)
                                                           .Build();

            var row4 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(false)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.3M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] { row1, row2, row3, row4 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row3.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row3.ManualPriceCell.IsValid, Is.True);

            Assert.That(band.HasErrors, Is.False);
            Assert.That(band.ErrorText, Is.Null);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_EndOfRangeMandatory_TradeablePriceSetToNull()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.2M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2, row3 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row3.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row3.ManualPriceCell.IsValid, Is.False);

            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);

            // ASSERT - Other prices valid
            Assert.That(row1.ManualPriceCell.IsValid, Is.True);
            Assert.That(row2.ManualPriceCell.IsValid, Is.True);
        }

        [Test]
        public void ShouldSetIsValidTrue_When_EndOfRangeMandatory_NullPriceSetToNonTradeable()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.2M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2, row3 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            row3.ManualPriceCell.MidPrice = null;

            // ACT
            row3.ManualPriceCell.IsTradeable = false;

            // ASSERT - Invalid missing price
            Assert.That(row3.ManualPriceCell.IsValid, Is.True);

            Assert.That(band.HasErrors, Is.False);
            Assert.That(band.ErrorText, Is.Null);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_MidRangeMandatory_SetToNonTradeable()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();


            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.2M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2, row3 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            row2.ManualPriceCell.MidPrice = null;

            // ACT
            row2.ManualPriceCell.IsTradeable = false;

            // ASSERT - Invalid missing price
            Assert.That(row2.ManualPriceCell.IsValid, Is.False);

            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);
        }

        [Test]
        public void ShouldSetIsValidTrue_When_EndOfRangeNonMandatory_PriceSetToNull()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(false)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row2.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row2.ManualPriceCell.IsValid, Is.True);

            Assert.That(band.HasErrors, Is.False);
            Assert.That(band.ErrorText, Is.Null);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_MidRangeNonMandatory_PriceSetToNull()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(false)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(false)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.2M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2, row3})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row2.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row2.ManualPriceCell.IsValid, Is.False);

            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_MidRangeNonMandatory_SetToNonTradeable()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(false)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var row3 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(false)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.2M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2, row3})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            row2.ManualPriceCell.MidPrice = null;

            // ACT
            row2.ManualPriceCell.IsTradeable = false;

            // ASSERT - Invalid missing price
            Assert.That(row2.ManualPriceCell.IsValid, Is.False);

            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);
        }

        [Test]
        public void ShouldNotIsValidFalse_After_UnsubscribeUpdates()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.UnsubscribeUpdates();

            // ACT
            row2.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row2.ManualPriceCell.IsValid, Is.True);
        }

        [Test]
        public void ShouldSubscribeUpdates_After_UnsubscribeUpdates()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);
            service.UnsubscribeUpdates();

            // ARRANGE
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row2.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row2.ManualPriceCell.IsValid, Is.False);
        }

        [Test]
        public void ShouldNotSubscribeUpdates_When_Disposed()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.Dispose();
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row2.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row2.ManualPriceCell.IsValid, Is.True);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var band = new ManualOverridesBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.0M)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithIsMandatory(true)
                                                           .WithIsTradeable(true)
                                                           .WithMidPrice(1.1M)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new ManualOverridesValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);
            service.Dispose();

            // ARRANGE
            service.Dispose();
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row2.ManualPriceCell.MidPrice = null;

            // ASSERT - Invalid missing price
            Assert.That(row2.ManualPriceCell.IsValid, Is.True);
        }
    }
}
