﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Efp;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.Efp
{
    [TestFixture]
    internal class EfpUndoChangesTests
    {
        [Test]
        public void ShouldUndoChanges_With_TradeablePrice()
        {
            var efpMonth = new MonthlyTenor(2023, 1);
            var efpValue = 1.0M;

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(efpMonth, true),
                                    new(new MonthlyTenor(2023, 2), true)
                                };

            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                          .WithEfpMonthServer(efpMonth)
                                                          .WithEfpValueServer(efpValue)
                                                          .WithEfpMonthItems(efpMonthItems)
                                                          .WithEfpMonthItem(efpMonthItems[1])
                                                          .WithEfpMonthManual(efpMonthItems[1].Tenor)
                                                          .WithEfpValue(2.0M)
                                                          .WithEfpValueManual(2.0M)
                                                          .WithEfpHasChanged(true)
                                                          .Build();

            var rows = new List<DailyPriceRowViewModel> { row };

            var efp = row.EfpNarrative;

            var service = new EfpUndoChangesService();

            // ACT
            service.UndoChanges(rows);

            // ASSERT
            Assert.That(efp.EfpMonthItem, Is.SameAs(efpMonthItems[0]));
            Assert.That(efp.EfpValue, Is.EqualTo(efpValue));

            Assert.That(efp.Model().EfpMonthManual, Is.Null);
            Assert.That(efp.Model().EfpValueManual, Is.Null);

            Assert.That(efp.HasChanged, Is.False);
        }

        [Test]
        public void ShouldUndoChanges_With_ShowBackupValues()
        {
            var efpMonth = new MonthlyTenor(2023, 1);
            var efpValue = 1.0M;

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(efpMonth, true),
                                    new(new MonthlyTenor(2023, 2), true)
                                };

            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                          .WithEfpShowBackupValues(true)
                                                          .WithEfpMonthServer(efpMonth)
                                                          .WithEfpValueServer(efpValue)
                                                          .WithEfpMonthItems(efpMonthItems)
                                                          .WithEfpMonthItem(efpMonthItems[1])
                                                          .WithEfpValue(2.0M)
                                                          .WithEfpMonthManual(efpMonthItems[1].Tenor)
                                                          .WithEfpValueManual(2.0M)
                                                          .WithEfpMonthBackup(efpMonthItems[1].Tenor)
                                                          .WithEfpValueBackup(2.0M)
                                                          .WithEfpHasChanged(true)
                                                          .Build();

            var rows = new List<DailyPriceRowViewModel> { row };

            var efp = row.EfpNarrative;

            var service = new EfpUndoChangesService();

            // ACT
            service.UndoChanges(rows);

            // ASSERT
            Assert.That(efp.EfpMonthItem, Is.SameAs(efpMonthItems[0]));
            Assert.That(efp.EfpValue, Is.EqualTo(efpValue));

            Assert.That(efp.EfpMonthBackup, Is.EqualTo(efpMonth));
            Assert.That(efp.EfpValueBackup, Is.EqualTo(efpValue));

            Assert.That(efp.Model().EfpMonthManual, Is.Null);
            Assert.That(efp.Model().EfpValueManual, Is.Null);

            Assert.That(efp.HasChanged, Is.False);
        }

        [Test]
        public void ShouldNotUndoChanges_When_HasChangedFalse()
        {
            var efpMonth = new MonthlyTenor(2023, 6);
            var efpValue = 1.0M;

            var efpMonthItems = new List<EfpMonthItem>
                                {
                                    new(efpMonth, true),
                                    new(new MonthlyTenor(2023, 2), true)
                                };

            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                          .WithEfpMonthServer(efpMonth)
                                                          .WithEfpValueServer(efpValue)
                                                          .WithEfpMonthItems(efpMonthItems)
                                                          .WithMidPrice(null)
                                                          .WithEfpHasChanged(false)
                                                          .Build();

            var rows = new List<DailyPriceRowViewModel> { row };

            var efp = row.EfpNarrative;

            var service = new EfpUndoChangesService();

            // ACT
            service.UndoChanges(rows);

            // ASSERT
            Assert.That(efp.EfpMonthItem, Is.Null);
            Assert.That(efp.EfpValue, Is.Null);

            Assert.That(efp.Model().EfpMonthManual, Is.Null);
            Assert.That(efp.Model().EfpValueManual, Is.Null);

            Assert.That(efp.HasChanged, Is.False);
        }
    }
}
