﻿using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Efp;
using Dsp.Gui.Dashboard.DailyPricing.Services.Efp;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using DynamicData;
using Moq;
using NUnit.Framework;
namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.Efp
{
    internal interface IEfpParentValueChangedServiceTestObjects
    {
        IEfpUpdateChildrenFromParentService EfpUpdateChildrenFromParentService { get; }
        EfpParentValueChangedService EfpParentValueChangedService { get; }
    }

    [TestFixture]
    public class EfpParentValueChangedServiceTests
    {
        private class EfpParentValueChangedServiceTestObjectBuilder
        {
            public IEfpParentValueChangedServiceTestObjects Build()
            {
                var testObjects = new Mock<IEfpParentValueChangedServiceTestObjects>();

                var updateChildrenService = new Mock<IEfpUpdateChildrenFromParentService>();

                testObjects.SetupGet(o => o.EfpUpdateChildrenFromParentService)
                           .Returns(updateChildrenService.Object);

                var efpParentValueChangedService = new EfpParentValueChangedService
                                                   {
                                                       EfpUpdateChildrenFromParentService = updateChildrenService.Object
                                                   };

                testObjects.SetupGet(o => o.EfpParentValueChangedService)
                           .Returns(efpParentValueChangedService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldNotUpdateChildren_When_SubscribeUpdates()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithEfpIsParent(true).Build();
            var row = new DailyPriceRowTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new[] { parent, row })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new EfpParentValueChangedServiceTestObjectBuilder().Build();

            // ACT
            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);

            // ASSERT
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(u => u.UpdateEfpChildrenFromParent(It.IsAny<EfpNarrativeViewModel>(), 
                                                           It.IsAny<IReadOnlyCollection<DailyPriceRowViewModel>>()), 
                        Times.Never);
        }

        [Test]
        public void ShouldUpdateChildren_When_EfpMonthChanged_With_SubscribeUpdates()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithEfpIsParent(true).Build();
            var row = new DailyPriceRowTestObjectBuilder().Build();

            var rows = new[] { parent, row };

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, rows)
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new EfpParentValueChangedServiceTestObjectBuilder().Build();

            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);

            // ACT
            parent.EfpNarrative.EfpMonthItem = new EfpMonthItem(new MonthlyTenor(2023, 1), true);

            // ASSERT
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(u => u.UpdateEfpChildrenFromParent(parent.EfpNarrative, 
                                                           It.Is<IReadOnlyCollection<DailyPriceRowViewModel>>(r => r.SequenceEqual(rows))), 
                        Times.Once);
        }

        [Test]
        public void ShouldUpdateChildren_When_EfpValueChanged_With_SubscribeUpdates()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithDailyTenor(new DailyTenor(2023, 1, 1))
                                                             .WithEfpIsParent(true)
                                                             .Build();

            var row = new DailyPriceRowTestObjectBuilder().WithDailyTenor(new DailyTenor(2023, 2, 1))
                                                          .Build();

            var rows = new[] { parent, row };

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, rows)
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new EfpParentValueChangedServiceTestObjectBuilder().Build();

            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);
            
            // ACT
            parent.EfpNarrative.EfpValue = 0.5m;

            // ASSERT
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(u => u.UpdateEfpChildrenFromParent(parent.EfpNarrative,
                                                           It.Is<IReadOnlyCollection<DailyPriceRowViewModel>>(r => r.SequenceEqual(rows))),
                        Times.Once);
        }

        [Test]
        public void ShouldUpdateChildren_When_EfpMonthChanged_With_NewParent()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithDailyTenor(new DailyTenor(2023, 1, 1))
                                                             .WithEfpIsParent(true)
                                                             .Build();

            var row = new DailyPriceRowTestObjectBuilder().WithDailyTenor(new DailyTenor(2023, 2, 1))
                                                          .Build();

            var rows = new[] { parent, row };

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, rows)
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new EfpParentValueChangedServiceTestObjectBuilder().Build();

            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);

            parent.EfpNarrative.IsParent = false;
            row.EfpNarrative.IsParent = true;

            // ACT
            row.EfpNarrative.EfpMonthItem = new EfpMonthItem(new MonthlyTenor(2023, 1), true);

            // ASSERT
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(u => u.UpdateEfpChildrenFromParent(row.EfpNarrative,
                                                           It.Is<IReadOnlyCollection<DailyPriceRowViewModel>>(r => r.SequenceEqual(rows))),
                        Times.Once);
        }

        [Test]
        public void ShouldNotInvokeUpdateChildren_After_UnsubscribeUpdates()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithEfpIsParent(true).Build();
            var row = new DailyPriceRowTestObjectBuilder().Build();

            var rows = new[] { parent, row };

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, rows)
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new EfpParentValueChangedServiceTestObjectBuilder().Build();

            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);

            testObjects.EfpParentValueChangedService.UnsubscribeUpdates();

            // ACT
            parent.EfpNarrative.EfpMonthItem = new EfpMonthItem(new MonthlyTenor(2023, 1), true);

            // ASSERT
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(u => u.UpdateEfpChildrenFromParent(It.IsAny<EfpNarrativeViewModel>(),
                                                           It.IsAny<IReadOnlyCollection<DailyPriceRowViewModel>>()),
                        Times.Never);
        }

        [Test]
        public void ShouldSubscribeUpdates_After_UnsubscribeUpdates()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithDailyTenor(new DailyTenor(2023, 1, 1))
                                                             .WithEfpIsParent(true)
                                                             .Build();

            var row = new DailyPriceRowTestObjectBuilder().WithDailyTenor(new DailyTenor(2023, 2, 1))
                                                          .Build();

            var rows = new[] { parent, row };

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, rows)
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new EfpParentValueChangedServiceTestObjectBuilder().Build();

            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);

            testObjects.EfpParentValueChangedService.UnsubscribeUpdates();

            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);

            parent.EfpNarrative.IsParent = false;
            row.EfpNarrative.IsParent = true;

            // ACT
            row.EfpNarrative.EfpMonthItem = new EfpMonthItem(new MonthlyTenor(2023, 1), true);

            // ASSERT
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(u => u.UpdateEfpChildrenFromParent(row.EfpNarrative,
                                                           It.Is<IReadOnlyCollection<DailyPriceRowViewModel>>(r => r.SequenceEqual(rows))),
                        Times.Once);
        }

        [Test]
        public void ShouldNotSubscribeUpdates_When_Disposed()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithEfpIsParent(true).Build();
            var row = new DailyPriceRowTestObjectBuilder().Build();

            var rows = new[] { parent, row };

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, rows)
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new EfpParentValueChangedServiceTestObjectBuilder().Build();

            testObjects.EfpParentValueChangedService.Dispose();

            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);

            // ACT
            parent.EfpNarrative.EfpMonthItem = new EfpMonthItem(new MonthlyTenor(2023, 1), true);

            // ASSERT
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(u => u.UpdateEfpChildrenFromParent(It.IsAny<EfpNarrativeViewModel>(),
                                                           It.IsAny<IReadOnlyCollection<DailyPriceRowViewModel>>()),
                        Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var parent = new DailyPriceRowTestObjectBuilder().WithEfpIsParent(true).Build();
            var row = new DailyPriceRowTestObjectBuilder().Build();

            var rows = new[] { parent, row };

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, rows)
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new EfpParentValueChangedServiceTestObjectBuilder().Build();

            testObjects.EfpParentValueChangedService.Dispose();

            testObjects.EfpParentValueChangedService.Dispose();
            testObjects.EfpParentValueChangedService.SubscribeUpdates(dailyPrices);

            // ACT
            parent.EfpNarrative.EfpMonthItem = new EfpMonthItem(new MonthlyTenor(2023, 1), true);

            // ASSERT
            Mock.Get(testObjects.EfpUpdateChildrenFromParentService)
                .Verify(u => u.UpdateEfpChildrenFromParent(It.IsAny<EfpNarrativeViewModel>(),
                                                           It.IsAny<IReadOnlyCollection<DailyPriceRowViewModel>>()),
                        Times.Never);
        }
    }
}
