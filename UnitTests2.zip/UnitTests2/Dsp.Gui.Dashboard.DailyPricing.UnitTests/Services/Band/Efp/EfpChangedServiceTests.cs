﻿using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Efp;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using DynamicData;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.Efp
{
    [TestFixture]
    internal class EfpChangedServiceTests
    {
        [Test]
        public void ShouldSetBandHasChangesFalse_When_SubscribeUpdates_With_NoChanges()
        {
            var band = new EfpBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpChangedService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }

        [Test]
        public void ShouldSetBandHasChangesTrue_When_SubscribeUpdates_With_Changes()
        {
            var band = new EfpBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithEfpHasChanged(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpChangedService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
        }

        [Test]
        public void ShouldSetBandHasChangesTrue_When_Changed()
        {
            var band = new EfpBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.EfpNarrative.HasChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
        }

        [Test]
        public void ShouldNotSetBandHasChanges_After_UnsubscribeUpdates()
        {
            var band = new EfpBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.UnsubscribeUpdates();

            // ACT
            row1.EfpNarrative.HasChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }

        [Test]
        public void ShouldSubscribeUpdates_After_UnsubscribeUpdates()
        {
            var band = new EfpBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);
            service.UnsubscribeUpdates();

            // ACT
            service.SubscribeUpdates(dailyPrices);
            row1.EfpNarrative.HasChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
        }

        [Test]
        public void ShouldNotSubscribeUpdates_When_Disposed()
        {
            var band = new EfpBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.Dispose();

            // ACT
            service.SubscribeUpdates(dailyPrices);
            row1.EfpNarrative.HasChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var band = new EfpBandTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().Build();
            var row2 = new DailyPriceRowTestObjectBuilder().Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpChangedService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.SubscribeUpdates(dailyPrices);
            service.Dispose();

            // ACT
            service.Dispose();
            row1.EfpNarrative.HasChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }
    }
}
