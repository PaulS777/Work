﻿using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.Efp;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using DynamicData;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.Efp
{
    [TestFixture]
    internal class EfpValidationServiceTests
    {
        [Test]
        public void ShouldSetBandHasErrorsFalse_When_SubscribeUpdates_With_EfpNarrativesValid()
        {
            var band = new EfpBandTestObjectBuilder().WithHasErrors(true)
                                                     .WithErrorText("error")
                                                     .Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpValidationService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
            Assert.That(band.ErrorText, Is.Null);
        }

        [Test]
        public void ShouldSetBandHasErrorsTrue_When_SubscribeUpdates_With_EfpNarrativeIsValueValidFalse()
        {
            var band = new EfpBandTestObjectBuilder().WithHasErrors(true)
                                                     .WithErrorText("error")
                                                     .Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(false)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpValidationService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);
        }

        [Test]
        public void ShouldSetBandHasErrorsTrue_When_SubscribeUpdates_With_EfpNarrativeIsMonthValidFalse()
        {
            var band = new EfpBandTestObjectBuilder().WithHasErrors(true)
                                                     .WithErrorText("error")
                                                     .Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(false)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpValidationService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);
        }

        [Test]
        public void ShouldNotSetHasErrors_After_UnsubscribeUpdates()
        {
            var band = new EfpBandTestObjectBuilder().WithHasErrors(true)
                                                     .WithErrorText("error")
                                                     .Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.UnsubscribeUpdates();

            // ACT
            row1.EfpNarrative.IsValueValid = false;

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
        }

    

        [Test]
        public void ShouldSubscribeUpdates_After_UnsubscribeUpdates()
        {
            var band = new EfpBandTestObjectBuilder().WithHasErrors(true)
                                                     .WithErrorText("error")
                                                     .Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);
            service.UnsubscribeUpdates();

            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.EfpNarrative.IsValueValid = false;

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
            Assert.That(band.ErrorText, Is.Not.Null);
        }

        [Test]
        public void ShouldNotSubscribeUpdates_When_Disposed()
        {
            var band = new EfpBandTestObjectBuilder().WithHasErrors(true)
                                                     .WithErrorText("error")
                                                     .Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.Dispose();
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.EfpNarrative.IsValueValid = false;

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var band = new EfpBandTestObjectBuilder().WithHasErrors(true)
                                                     .WithErrorText("error")
                                                     .Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true)
                                                           .WithEfpIsMonthValid(true)
                                                           .WithEfpIsValueValid(true)
                                                           .Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new EfpValidationService();

            service.AttachBandInfo(band);
            service.SubscribeUpdates(dailyPrices);
            service.Dispose();

            // ARRANGE
            service.Dispose();
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.EfpNarrative.IsValueValid = false;

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
        }
    }
}
