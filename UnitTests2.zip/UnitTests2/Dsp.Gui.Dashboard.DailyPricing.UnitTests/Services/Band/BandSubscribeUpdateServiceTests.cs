﻿using System;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band
{
    [TestFixture]
    internal class BandSubscribeUpdateServiceTests
    {
        [Test]
        public void ShouldSetSubscribeUpdatesTrue_When_SubscribeManualOverrideUpdates()
        {
            var manualOverridesBand = new ManualOverridesBand(Mock.Of<IDisposable>());
            var efpBand = new EfpBand(Mock.Of<IDisposable>());

            var manualCurveBandHeader = new ManualCurveBandHeader(Mock.Of<IDisposable>())
                                        {
                                            ManualOverridesBand = manualOverridesBand,
                                            EfpBand = efpBand
                                        };

            var service = new BandSubscribeUpdatesService();

            // ACT
            service.SubscribeManualOverrideUpdates(manualCurveBandHeader);

            // ASSERT
            Assert.That(manualOverridesBand.SubscribeUpdates, Is.True);
            Assert.That(efpBand.SubscribeUpdates, Is.True);
            Assert.That(manualCurveBandHeader.SubscribeUpdates, Is.True);
            Assert.That(service.IsSubscribedManualOverrideUpdates, Is.True);
        }

        [Test]
        public void ShouldSetSubscribeUpdatesTrue_When_SubscribeTenorPremiumsUpdates()
        {
            var tenorPremiumBandHeader = new TenorPremiumsBandHeader(Mock.Of<IDisposable>());

            var service = new BandSubscribeUpdatesService();

            // ACT
            service.SubscribeTenorPremiumsUpdates(tenorPremiumBandHeader);

            // ASSERT
            Assert.That(tenorPremiumBandHeader.SubscribeUpdates, Is.True);
            Assert.That(service.IsSubscribedTenorPremiumsUpdates, Is.True);
        }

		[Test]
        public void ShouldSetSubscribeUpdatesFalse_When_UnsubscribeManualOverrideUpdates()
        {
            var manualOverridesBand = new ManualOverridesBand(Mock.Of<IDisposable>())
                                      {
                                          SubscribeUpdates = true
                                      };

            var efpBand = new EfpBand(Mock.Of<IDisposable>())
                          {
                              SubscribeUpdates = true
                          };

            var manualCurveBandHeader = new ManualCurveBandHeader(Mock.Of<IDisposable>())
                                        {
                                            SubscribeUpdates = true,
                                            ManualOverridesBand = manualOverridesBand,
                                            EfpBand = efpBand
                                        };

            var service = new BandSubscribeUpdatesService();

            // ACT
            service.UnsubscribeManualOverrideUpdates(manualCurveBandHeader);

            // ASSERT
            Assert.That(manualOverridesBand.SubscribeUpdates, Is.False);
            Assert.That(efpBand.SubscribeUpdates, Is.False);
            Assert.That(manualCurveBandHeader.SubscribeUpdates, Is.False);
            Assert.That(service.IsSubscribedManualOverrideUpdates, Is.False);
        }

        [Test]
        public void ShouldSetSubscribeUpdatesFalse_When_UnsubscribeTenorPremiumUpdates()
        {
            var tenorPremiumBandHeader = new TenorPremiumsBandHeader(Mock.Of<IDisposable>());

            var service = new BandSubscribeUpdatesService();

            // ACT
            service.UnsubscribeTenorPremiumsUpdates(tenorPremiumBandHeader);

            // ASSERT
            Assert.That(tenorPremiumBandHeader.SubscribeUpdates, Is.False);
        }

		[Test]
        public void ShouldSetSubscribeLivePriceUpdatesTrue_When_SubscribeLivePriceUpdates()
        {
            var bandHeader1 = new LivePriceBandHeader
                              { 
                                  LivePriceBand = new LivePriceBand(Mock.Of<IDisposable>())
                              };

            var bandHeader2 = new LivePriceBandHeader
                              {
                                  LivePriceBand = new LivePriceBand(Mock.Of<IDisposable>())
                              };

            var bandHeaders = new[]
                              {
                                  bandHeader1, bandHeader2
                              };

            var service = new BandSubscribeUpdatesService();

            // ACT
            service.SubscribeLivePriceUpdates(bandHeaders);

            // ASSERT
            Assert.That(bandHeader1.LivePriceBand.SubscribeLivePriceUpdates, Is.True);
            Assert.That(bandHeader2.LivePriceBand.SubscribeLivePriceUpdates, Is.True);
        }

        [Test]
        public void ShouldNotThrowException_When_SubscribeLivePriceUpdates_With_NullBands()
        {
            var service = new BandSubscribeUpdatesService();

            Exception result = null;

            // ACT
            try
            {
                service.SubscribeLivePriceUpdates(null);

            }
            catch (Exception ex)
            {
                result = ex;
            }
            
           
            // ASSERT
            Assert.That(result, Is.Null);
        }
    }
}
