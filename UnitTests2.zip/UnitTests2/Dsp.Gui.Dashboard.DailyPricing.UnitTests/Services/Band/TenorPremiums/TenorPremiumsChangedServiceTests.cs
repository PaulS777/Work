﻿using NUnit.Framework;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using DynamicData;
using System.Reactive.Subjects;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.TenorPremiums
{
    [TestFixture]
    internal class TenorPremiumsChangedServiceTests
    {
        [Test]
        public void ShouldSetBandHasChangesFalse_When_SubscribeUpdates_With_NoChanges()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().WithHasChanges(true).Build();

            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new TenorPremiumsChangedService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }

        [Test]
        public void ShouldSetBandHasChangesTrue_When_SubscribeUpdates_With_Change()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().WithHasChanges(false).Build();

            var row = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(true).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new TenorPremiumsChangedService();

            service.AttachBandInfo(band);

            // ACT
            service.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
        }

        [Test]
        public void ShouldSetBandHasChangesTrue_When_MarginChanged()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().WithHasChanges(false).Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new TenorPremiumsChangedService();

            service.AttachBandInfo(band);

            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.TenorPremium.MarginChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
        }

        [Test]
        public void ShouldNotSetBandHasChanges_After_UnsubscribeUpdates()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().WithHasChanges(false).Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new TenorPremiumsChangedService();

            service.AttachBandInfo(band);

            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.UnsubscribeUpdates();

            // ACT
            row1.TenorPremium.MarginChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }

        [Test]
        public void ShouldSubscribeUpdates_After_UnsubscribeUpdates()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().WithHasChanges(false).Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new TenorPremiumsChangedService();

            service.AttachBandInfo(band);

            service.SubscribeUpdates(dailyPrices);
            service.UnsubscribeUpdates();

            // ARRANGE
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.TenorPremium.MarginChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.True);
        }

        [Test]
        public void ShouldNotSubscribeUpdates_When_Disposed()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().WithHasChanges(false).Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new TenorPremiumsChangedService();

            service.AttachBandInfo(band);

            service.SubscribeUpdates(dailyPrices);

            // ARRANGE
            service.Dispose();
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.TenorPremium.MarginChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().WithHasChanges(false).Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithMarginChanged(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2})
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var service = new TenorPremiumsChangedService();

            service.AttachBandInfo(band);

            service.SubscribeUpdates(dailyPrices);
            service.Dispose();

            // ARRANGE
            service.Dispose();
            service.SubscribeUpdates(dailyPrices);

            // ACT
            row1.TenorPremium.MarginChanged = true;

            // ASSERT
            Assert.That(band.HasChanges, Is.False);
        }
    }
}
