﻿using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.TenorPremiums
{
    internal interface ILinkedPremiumsUpdateFromParentServiceTestObjects
    {
        ITenorPremiumsMarginCalculator Calculator { get; }
        LinkedPremiumsUpdateFromParentService Service { get; }
    }

    [TestFixture]
    public class LinkedPremiumsUpdateFromParentServiceTests
    {
        private class LinkedPremiumsUpdateFromParentServiceTestObjectBuilder
        {
            public ILinkedPremiumsUpdateFromParentServiceTestObjects Build()
            {
                var testObjects = new Mock<ILinkedPremiumsUpdateFromParentServiceTestObjects>();

                var calculator = new Mock<ITenorPremiumsMarginCalculator>();

                testObjects.SetupGet(o => o.Calculator)
                           .Returns(calculator.Object);

                var service = new LinkedPremiumsUpdateFromParentService(calculator.Object);

                testObjects.SetupGet(o => o.Service)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCalculateBidMarginsOnChildren_When_UpdateBidMarginsFromParent()
        {
            var nonChild = new DailyPriceRowTestObjectBuilder().Build();
            var child1 = new DailyPriceRowTestObjectBuilder().WithIsMarginChild(true).WithMidPrice(1.0m).Build();
            var child2 = new DailyPriceRowTestObjectBuilder().WithIsMarginChild(true).WithMidPrice(null).WithIsExtended(true).Build();

            var rows = new[] { nonChild, child1, child2 };

            var testObjects = new LinkedPremiumsUpdateFromParentServiceTestObjectBuilder().Build();

            // ACT
            testObjects.Service.UpdateBidMarginsFromParent(0.1m, rows);

            // ASSERT - Ignore Child, Calculate Children
            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromBidMargin(nonChild.TenorPremium, 
                                                                  It.IsAny<decimal?>(), 
                                                                  It.IsAny<bool>(), 
                                                                  It.IsAny<bool>()), Times.Never);

            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromBidMargin(child1.TenorPremium, 0.1m, true, false));

            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromBidMargin(child2.TenorPremium, 0.1m, false, true));

            Assert.That(child1.TenorPremium.IsAutoUpdate, Is.False);
        }

        [Test]
        public void ShouldCalculateAskMarginsOnChildren_When_UpdateAskMarginsFromParent()
        {
            var nonChild = new DailyPriceRowTestObjectBuilder().Build();
            var child1 = new DailyPriceRowTestObjectBuilder().WithIsMarginChild(true).WithMidPrice(1.0m).Build();
            var child2 = new DailyPriceRowTestObjectBuilder().WithIsMarginChild(true).WithMidPrice(null).WithIsExtended(true).Build();

            var rows = new[] { nonChild, child1, child2 };

            var testObjects = new LinkedPremiumsUpdateFromParentServiceTestObjectBuilder().Build();

            // ACT
            testObjects.Service.UpdateAskMarginsFromParent(0.1m, rows);

            // ASSERT - Ignore Child, Calculate Children
            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromAskMargin(nonChild.TenorPremium, 
                                                                  It.IsAny<decimal?>(), 
                                                                  It.IsAny<bool>(), 
                                                                  It.IsAny<bool>()), Times.Never);

            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromAskMargin(child1.TenorPremium, 0.1m, true, false));

            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromAskMargin(child2.TenorPremium, 0.1m, false, true));

            Assert.That(child1.TenorPremium.IsAutoUpdate, Is.False);
        }

        [Test]
        public void ShouldCalculateBidAskMarginsOnChildren_When_UpdateBidAskMarginsFromParent()
        {
            var nonChild = new DailyPriceRowTestObjectBuilder().Build();
            var child1 = new DailyPriceRowTestObjectBuilder().WithIsMarginChild(true).WithMidPrice(1.0m).Build();
            var child2 = new DailyPriceRowTestObjectBuilder().WithIsMarginChild(true).WithMidPrice(null).WithIsExtended(true).Build();

            var rows = new[] { nonChild, child1, child2 };

            var testObjects = new LinkedPremiumsUpdateFromParentServiceTestObjectBuilder().Build();

            // ACT
            testObjects.Service.UpdateBidAskMarginsFromParent(-0.1m, 0.1m, rows);

            // ASSERT - Ignore Child, Calculate Children
            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromBidAskMargins(nonChild.TenorPremium,
                                                                      It.IsAny<decimal?>(),
                                                                      It.IsAny<decimal?>(),
                                                                      It.IsAny<bool>(),
                                                                      It.IsAny<bool>()), Times.Never);

            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromBidAskMargins(child1.TenorPremium, -0.1m, 0.1m, true, false));

            Mock.Get(testObjects.Calculator)
                .Verify(c => c.CalculateTenorPremiumFromBidAskMargins(child2.TenorPremium, -0.1m, 0.1m, false, true));

            Assert.That(child1.TenorPremium.IsAutoUpdate, Is.False);
        }
    }
}
