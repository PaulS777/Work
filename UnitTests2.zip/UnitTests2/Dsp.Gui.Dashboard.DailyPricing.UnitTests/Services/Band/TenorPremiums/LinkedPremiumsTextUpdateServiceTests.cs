﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.TenorPremiums
{
    internal interface ILinkedPremiumsTextUpdateServiceTestObjects
    {
        ILinkedPremiumsUpdateFromParentService LinkedPremiumsUpdateFromParentService { get; }
        ISubject<TenorPremiumViewModel> BidTextUpdate { get; }
        ISubject<TenorPremiumViewModel> AskTextUpdate { get; }
        LinkedPremiumsTextUpdateService LinkedPremiumsTextUpdateService { get; }
    }

    [TestFixture]
    public class LinkedPremiumsTextUpdateServiceTests
    {
        private class LinkedPremiumsTextUpdateServiceTestObjectBuilder
        {
            public ILinkedPremiumsTextUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<ILinkedPremiumsTextUpdateServiceTestObjects>();

                var bidTextUpdate = new Subject<TenorPremiumViewModel>();

                testObjects.SetupGet(o => o.BidTextUpdate)
                           .Returns(bidTextUpdate);

                var askTextUpdate = new Subject<TenorPremiumViewModel>();

                testObjects.SetupGet(o => o.AskTextUpdate)
                           .Returns(askTextUpdate);

                var monitor = new Mock<ITenorPremiumsChangedMonitor>();

                monitor.Setup(m => m.MonitorBidTextUpdate(It.IsAny<IEnumerable<TenorPremiumViewModel>>()))
                       .Returns(bidTextUpdate);

                monitor.Setup(m => m.MonitorAskTextUpdate(It.IsAny<IEnumerable<TenorPremiumViewModel>>()))
                       .Returns(askTextUpdate);

                var linkedPremiumsUpdateFromParentService = new Mock<ILinkedPremiumsUpdateFromParentService>();

                testObjects.SetupGet(o => o.LinkedPremiumsUpdateFromParentService)
                           .Returns(linkedPremiumsUpdateFromParentService.Object);

                var linkedPremiumsTextUpdateService = new LinkedPremiumsTextUpdateService(monitor.Object,
                                                                                          linkedPremiumsUpdateFromParentService.Object);
                
                testObjects.SetupGet(o => o.LinkedPremiumsTextUpdateService)
                           .Returns(linkedPremiumsTextUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateBidMarginsFromParent_On_BidTextUpdate_With_SubscribeUpdates()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsMarginParent(true)
                                                          .WithBidMarginValue(0.1m)
                                                          .Build();

            var testObjects = new LinkedPremiumsTextUpdateServiceTestObjectBuilder().Build();

            var rows = new[]
                       {
                           row,
                           new DailyPriceRowTestObjectBuilder().Build()
                       };

            testObjects.LinkedPremiumsTextUpdateService.SubscribeUpdates(rows);

            // ACT
            testObjects.BidTextUpdate.OnNext(row.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateBidMarginsFromParent(0.1m, rows));
        }

        [Test]
        public void ShouldUpdateAskMarginsFromParent_On_AskTextUpdate_With_SubscribeUpdates()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsMarginParent(true)
                                                          .WithAskMarginValue(0.1m)
                                                          .Build();

            var testObjects = new LinkedPremiumsTextUpdateServiceTestObjectBuilder().Build();

            var rows = new[]
                       {
                           row,
                           new DailyPriceRowTestObjectBuilder().Build()
                       };

            testObjects.LinkedPremiumsTextUpdateService.SubscribeUpdates(rows);

            // ACT
            testObjects.AskTextUpdate.OnNext(row.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateAskMarginsFromParent(0.1m, rows));
        }

        [Test]
        public void ShouldNotUpdateBidMargins_On_BidTextUpdate_FromNonParent()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsMarginParent(false)
                                                          .WithBidMarginValue(0.1m)
                                                          .Build();

            var testObjects = new LinkedPremiumsTextUpdateServiceTestObjectBuilder().Build();

            var rows = new[]
                       {
                           row,
                           new DailyPriceRowTestObjectBuilder().Build()
                       };

            testObjects.LinkedPremiumsTextUpdateService.SubscribeUpdates(rows);

            // ACT
            testObjects.BidTextUpdate.OnNext(row.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateBidMarginsFromParent(It.IsAny<decimal?>(), It.IsAny<IEnumerable<DailyPriceRowViewModel>>()),
                        Times.Never);
        }

        [Test]
        public void ShouldNotUpdateAskMargins_On_AskTextUpdate_FromNonParent()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsMarginParent(false)
                                                          .WithAskMarginValue(0.1m)
                                                          .Build();

            var testObjects = new LinkedPremiumsTextUpdateServiceTestObjectBuilder().Build();

            var rows = new[]
                       {
                           row,
                           new DailyPriceRowTestObjectBuilder().Build()
                       };

            testObjects.LinkedPremiumsTextUpdateService.SubscribeUpdates(rows);

            // ACT
            testObjects.AskTextUpdate.OnNext(row.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateAskMarginsFromParent(It.IsAny<decimal?>(), It.IsAny<IEnumerable<DailyPriceRowViewModel>>()), 
                        Times.Never);
        }

        [Test]
        public void ShouldNotUpdateMargin_On_BidTextUpdate_With_UnsubscribeUpdates()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsMarginParent(true)
                                                          .WithBidMarginValue(0.1m)
                                                          .Build();

            var testObjects = new LinkedPremiumsTextUpdateServiceTestObjectBuilder().Build();

            var rows = new[]
                       {
                           row,
                           new DailyPriceRowTestObjectBuilder().Build()
                       };

            testObjects.LinkedPremiumsTextUpdateService.SubscribeUpdates(rows);

            // ARRANGE
            testObjects.LinkedPremiumsTextUpdateService.UnsubscribeUpdates();

            // ACT
            testObjects.BidTextUpdate.OnNext(row.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateBidMarginsFromParent(It.IsAny<decimal?>(), It.IsAny<IEnumerable<DailyPriceRowViewModel>>()),
                        Times.Never);
        }

        [Test]
        public void ShouldNotUpdateMargin_On_AskTextUpdate_With_UnsubscribeUpdates()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsMarginParent(true)
                                                          .WithAskMarginValue(0.1m)
                                                          .Build();

            var testObjects = new LinkedPremiumsTextUpdateServiceTestObjectBuilder().Build();

            var rows = new[]
                       {
                           row,
                           new DailyPriceRowTestObjectBuilder().Build()
                       };

            testObjects.LinkedPremiumsTextUpdateService.SubscribeUpdates(rows);

            // ARRANGE
            testObjects.LinkedPremiumsTextUpdateService.UnsubscribeUpdates();

            // ACT
            testObjects.AskTextUpdate.OnNext(row.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateAskMarginsFromParent(It.IsAny<decimal?>(), It.IsAny<IEnumerable<DailyPriceRowViewModel>>()),
                        Times.Never);
        }

        [Test]
        public void ShouldNotUpdateMargin_When_Disposed()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsMarginParent(true)
                                                          .WithBidMarginValue(0.1m)
                                                          .Build();

            var testObjects = new LinkedPremiumsTextUpdateServiceTestObjectBuilder().Build();

            var rows = new[]
                       {
                           row,
                           new DailyPriceRowTestObjectBuilder().Build()
                       };

            testObjects.LinkedPremiumsTextUpdateService.SubscribeUpdates(rows);

            // ARRANGE
            testObjects.LinkedPremiumsTextUpdateService.Dispose();

            // ACT
            testObjects.BidTextUpdate.OnNext(row.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateBidMarginsFromParent(It.IsAny<decimal?>(), It.IsAny<IEnumerable<DailyPriceRowViewModel>>()),
                        Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithIsMarginParent(true)
                                                          .WithBidMarginValue(0.1m)
                                                          .Build();

            var testObjects = new LinkedPremiumsTextUpdateServiceTestObjectBuilder().Build();

            var rows = new[]
                       {
                           row,
                           new DailyPriceRowTestObjectBuilder().Build()
                       };

            testObjects.LinkedPremiumsTextUpdateService.SubscribeUpdates(rows);

            // ARRANGE
            testObjects.LinkedPremiumsTextUpdateService.Dispose();

            // ACT
            testObjects.LinkedPremiumsTextUpdateService.Dispose();
            testObjects.BidTextUpdate.OnNext(row.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(l => l.UpdateBidMarginsFromParent(It.IsAny<decimal?>(), It.IsAny<IEnumerable<DailyPriceRowViewModel>>()),
                        Times.Never);
        }
    }
}
