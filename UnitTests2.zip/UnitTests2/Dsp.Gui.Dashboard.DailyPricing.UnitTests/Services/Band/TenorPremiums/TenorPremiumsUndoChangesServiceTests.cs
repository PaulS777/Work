﻿using System.Collections.Generic;
using NUnit.Framework;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.TenorPremiums
{
    [TestFixture]
    internal class TenorPremiumsUndoChangesServiceTests
    {
        [Test]
        public void ShouldUndoChanges()
        {
            var row = new DailyPriceRowTestObjectBuilder().WithBidMarginEditValue(-2.0M)
                                                          .WithBidMarginValue(-2.0M)
                                                          .WithBidMarginServerValue(-1.0M)
                                                          .WithBidMarginHasChanged(true)
                                                          .WithAskMarginEditValue(2.0M)
                                                          .WithAskMarginValue(2.0M)
                                                          .WithAskMarginServerValue(1.0M)
                                                          .WithAskMarginHasChanged(true)
                                                          .WithMarginChanged(true)
                                                          .Build();

            var rows = new List<DailyPriceRowViewModel> { row };

            var service = new TenorPremiumsUndoChangesService();

            // ACT
            service.UndoChanges(rows);

            // ASSERT
            Assert.That(row.TenorPremium.BidMargin.Margin.EditValue, Is.EqualTo(-1.0M));
            Assert.That(row.TenorPremium.BidMargin.Margin.Value, Is.EqualTo(-1.0M));
            Assert.That(row.TenorPremium.AskMargin.Margin.EditValue, Is.EqualTo(1.0M));
            Assert.That(row.TenorPremium.AskMargin.Margin.Value, Is.EqualTo(1.0M));
            Assert.That(row.TenorPremium.MarginChanged, Is.False);
            Assert.That(row.TenorPremium.BidMargin.HasChanged, Is.False);
            Assert.That(row.TenorPremium.AskMargin.HasChanged, Is.False);
        }
    }
}
