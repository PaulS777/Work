﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums.Calculators;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using DynamicData;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.TenorPremiums
{
    internal interface ITenorPremiumsValidationServiceTestObjects
    {
        TenorPremiumsValidationService TenorPremiumsValidationService { get; }
    }

    [TestFixture]
    public class TenorPremiumsValidationServiceTests
    {
        private class TenorPremiumsValidationServiceTestObjectBuilder
        {
            private bool _continuityCheckResult;

            public TenorPremiumsValidationServiceTestObjectBuilder WithContinuityCheckResult(bool value)
            {
                _continuityCheckResult = value;
                return this;
            }

            public ITenorPremiumsValidationServiceTestObjects Build()
            {
                var testObjects = new Mock<ITenorPremiumsValidationServiceTestObjects>();

                var calculator = new Mock<ITenorPremiumsContinuityCalculator>();

                calculator.Setup(c => c.CheckPremiumsContinuity(It.IsAny<IList<DailyPriceRowViewModel>>()))
                          .Returns(_continuityCheckResult);

                var service = new TenorPremiumsValidationService
                              {
                                  TenorPremiumsContinuityCalculator = calculator.Object
                              };

                testObjects.SetupGet(o => o.TenorPremiumsValidationService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetBandHasErrorsFalse_When_SubscribeUpdates_With_NoErrors()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            // ACT
            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
        }

        [Test]
        public void ShouldSetBandHasErrorsTrue_When_SubscribeUpdates_With_Errors()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(true).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            // ACT
            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
        }

        [Test]
        public void ShouldSetBandHasErrorsTrue_When_SubscribeUpdates_With_ContinuityCheckResultFalse()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(false)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            // ACT
            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
        }

        [Test]
        public void ShouldSetBandHasErrorsTrue_When_MarginError()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ACT
            row1.TenorPremium.HasMarginErrors = true;

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
        }

        [Test]
        public void ShouldSetBandHasErrorsFalse_When_MarginErrorSetToFalse()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(true).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ACT
            row2.TenorPremium.HasMarginErrors = false;

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
        }

        [Test]
        public void ShouldSetBandHasErrorsTrue_When_MarginErrorSetToTrue()
        {

            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ACT
            row2.TenorPremium.HasMarginErrors = true;

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
        }

        [Test] 
        public void ShouldSetBandHasErrorsTrue_When_MarginChanged_With_ContinuityCheckFalse()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(false)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ACT
            row2.TenorPremium.MarginChanged = true;

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
        }

        [Test]
        public void ShouldNotSetBandHasErrors_After_UnsubscribeUpdates()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ARRANGE
            testObjects.TenorPremiumsValidationService.UnsubscribeUpdates();

            // ACT
            row2.TenorPremium.HasMarginErrors = true;

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
        }

        [Test]
        public void ShouldSubscribeUpdates_After_UnsubscribeUpdates()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);
            testObjects.TenorPremiumsValidationService.UnsubscribeUpdates();

            // ARRANGE
            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ACT
            row2.TenorPremium.HasMarginErrors = true;

            // ASSERT
            Assert.That(band.HasErrors, Is.True);
        }


        [Test]
        public void ShouldNotSubscribeUpdates_When_Disposed()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);

            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ARRANGE
            testObjects.TenorPremiumsValidationService.Dispose();
            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ACT
            row1.TenorPremium.HasMarginErrors = true;

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var band = new TenorPremiumsBandHeaderTestObjectBuilder().Build();

            var row1 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();
            var row2 = new DailyPriceRowTestObjectBuilder().WithIsBusinessDay(true).WithHasMarginErrors(false).Build();

            var changeSet = new ChangeSet<DailyPriceRowViewModel>(new Change<DailyPriceRowViewModel>[]
                                                                  {
                                                                      new(ListChangeReason.AddRange, new [] {row1, row2 })
                                                                  });

            var dailyPrices = new BehaviorSubject<IChangeSet<DailyPriceRowViewModel>>(changeSet);



            var testObjects = new TenorPremiumsValidationServiceTestObjectBuilder().WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsValidationService.AttachBandInfo(band);

            testObjects.TenorPremiumsValidationService.Dispose();
            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ARRANGE
            testObjects.TenorPremiumsValidationService.Dispose();
            testObjects.TenorPremiumsValidationService.SubscribeUpdates(dailyPrices);

            // ACT
            row1.TenorPremium.HasMarginErrors = true;

            // ASSERT
            Assert.That(band.HasErrors, Is.False);
        }
    }
}
