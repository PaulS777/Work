﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.Dashboard.DailyPricing.Models;
using Dsp.Gui.Dashboard.DailyPricing.Services.Bands.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.Services.ServerUpdate;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums;
using Dsp.Gui.Dashboard.DailyPricing.Services.TenorPremiums.Calculators;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Band.TenorPremiums
{
    internal interface ITenorPremiumsSpinUpdateServiceTestObjects
    {
        ILinkedPremiumsUpdateFromParentService LinkedPremiumsUpdateFromParentService { get; }
        ISubject<TenorPremiumViewModel> SpinUpdate { get; }
        IPublisherTenorPremiumBuilder PublisherTenorPremiumBuilder { get; set; }
        IPublisherTenorPremiumUpdateService PublisherTenorPremiumUpdateService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        TestScheduler TestScheduler { get; }
        ISubject<Unit> ServerUpdateResponse { get; }
        TenorPremiumsBandHeader BandHeader { get; }
        TenorPremiumsSpinUpdateService TenorPremiumsSpinUpdateService { get; }
    }

    [TestFixture]
    public class TenorPremiumsSpinUpdateServiceTests
    {
        private class TenorPremiumsSpinUpdateServiceTestObjectBuilder
        {
            private bool _continuityCheckResult;
            private PublisherTenorPremium _publisherTenorPremium;
            private PublisherTenorPremium _publisherTenorPremiumBuilderResult;

            public TenorPremiumsSpinUpdateServiceTestObjectBuilder WithContinuityCheckResult(bool value)
            {
                _continuityCheckResult = value;
                return this;
            }

            public TenorPremiumsSpinUpdateServiceTestObjectBuilder WithPublisherTenorPremium(PublisherTenorPremium value)
            {
                _publisherTenorPremium = value;
                return this;
            }

            public TenorPremiumsSpinUpdateServiceTestObjectBuilder WithPublisherTenorPremiumResult(PublisherTenorPremium value)
            {
                _publisherTenorPremiumBuilderResult = value;
                return this;
            }

            public ITenorPremiumsSpinUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<ITenorPremiumsSpinUpdateServiceTestObjects>();

                var spinUpdate = new Subject<TenorPremiumViewModel>();

                testObjects.SetupGet(o => o.SpinUpdate)
                           .Returns(spinUpdate);

                var changeMonitor = new Mock<ITenorPremiumsChangedMonitor>();

                changeMonitor.Setup(m => m.MonitorSpinUpdate(It.IsAny<IEnumerable<TenorPremiumViewModel>>()))
                             .Returns(spinUpdate);

                var bandHeader = new TenorPremiumsBandHeader(Mock.Of<IDisposable>());

                var bandInfoDetails = new BandInfoDetails
                                      {
                                          PublisherTenorPremium = _publisherTenorPremium
                                      };

                bandHeader.SetDetails(bandInfoDetails);

                testObjects.SetupGet(o => o.BandHeader)
                           .Returns(bandHeader);

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.Dispatcher)
                                 .Returns(Scheduler.Immediate);

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(testScheduler);

                var popupService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var updateServiceResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.ServerUpdateResponse)
                           .Returns(updateServiceResponse);

                var publisherTenorPremiumBuilder = new Mock<IPublisherTenorPremiumBuilder>();

                publisherTenorPremiumBuilder.Setup(b => b.CreatePublisherTenorPremium(It.IsAny<PublisherTenorPremium>(),
                                                                                      It.IsAny<IList<DailyPriceRowViewModel>>()))
                                            .Returns(_publisherTenorPremiumBuilderResult);

                testObjects.SetupGet(o => o.PublisherTenorPremiumBuilder)
                           .Returns(publisherTenorPremiumBuilder.Object);

                var updateService = new Mock<IPublisherTenorPremiumUpdateService>();

                updateService.Setup(u => u.Update(It.IsAny<PublisherTenorPremium>(),
                                                  It.IsAny<IScheduler>()))
                             .Returns(updateServiceResponse);

                testObjects.SetupGet(o => o.PublisherTenorPremiumUpdateService)
                           .Returns(updateService.Object);

                var continuityCalculator = new Mock<ITenorPremiumsContinuityCalculator>();

                continuityCalculator.Setup(c => c.CheckPremiumsContinuity(It.IsAny<IList<DailyPriceRowViewModel>>()))
                                    .Returns(_continuityCheckResult);

                var linkedPremiumsService = new Mock<ILinkedPremiumsUpdateFromParentService>();

                testObjects.SetupGet(o => o.LinkedPremiumsUpdateFromParentService)
                           .Returns(linkedPremiumsService.Object);

                var tenorPremiumsSpinUpdateService = new TenorPremiumsSpinUpdateService(changeMonitor.Object,
                                                                                        updateService.Object,
                                                                                        linkedPremiumsService.Object,
                                                                                        schedulerProvider.Object,
                                                                                        TestMocks.GetLoggerFactory().Object)
                {
                    PublisherTenorPremiumBuilder = publisherTenorPremiumBuilder.Object,
                    PopupNotificationService = popupService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    TenorPremiumsContinuityCalculator = continuityCalculator.Object
                };

                testObjects.SetupGet(o => o.TenorPremiumsSpinUpdateService)
                           .Returns(tenorPremiumsSpinUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateTenorPremiums_On_ThrottleInterval_After_SpinUpdate_When_Unlinked()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.02M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice1, dailyPrice2 };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var premiumBuilderResult = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                                   .WithPublisherId(10)
                                                                                   .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .WithPublisherTenorPremiumResult(premiumBuilderResult)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumBuilder)
                .Verify(b => b.CreatePublisherTenorPremium(premium,
                                                           It.Is<IList<DailyPriceRowViewModel>>(dp => dp.Count == 2)));

            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(premiumBuilderResult, It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldSendPopupNotification_On_SpinUpdateServerResponseSuccess()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.02M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice1, dailyPrice2 };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var premiumBuilderResult = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                                   .WithPublisherId(10)
                                                                                   .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .WithPublisherTenorPremiumResult(premiumBuilderResult)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ACT
            testObjects.ServerUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldShowMessageDialog_On_SpinUpdateServerResponseError()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.02M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice1, dailyPrice2 };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var premiumBuilderResult = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                                   .WithPublisherId(10)
                                                                                   .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .WithPublisherTenorPremiumResult(premiumBuilderResult)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ACT
            testObjects.ServerUpdateResponse.OnError(new Exception("error"));

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "error"
                                                                        && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldNotUpdateTenorPremiums_After_SpinUpdate_With_InvalidPrice()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.02M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel> { dailyPrice1, dailyPrice2 };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var premiumBuilderResult = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                                   .WithPublisherId(10)
                                                                                   .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .WithPublisherTenorPremiumResult(premiumBuilderResult)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PublisherTenorPremium>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldThrottleMultipleSpinUpdates()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.02M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var premiumBuilderResult = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                                   .WithPublisherId(10)
                                                                                   .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .WithPublisherTenorPremiumResult(premiumBuilderResult)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(premiumBuilderResult, It.IsAny<IScheduler>()), Times.Once);
        }

        [Test]
        public void ShouldNotUpdateTenorPremiums_When_ContinuityCheckFails()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.02M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(false)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(260).Ticks);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PublisherTenorPremium>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldNotUpdateTenorPremiums_When_MarginSideIsNull()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.02M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = null}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(260).Ticks);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PublisherTenorPremium>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldNotUpdateTenorPremiums_When_Any_TenorPremiumIsInvalid()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    HasMarginErrors = true,
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.02M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(260).Ticks);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PublisherTenorPremium>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldNotUpdateTenorPremiums_When_Any_PremiumsHaveChanged()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    MarginChanged = true,
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(260).Ticks);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PublisherTenorPremium>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldUpdateTenorPremiumChildren_When_ParentPremiumChanged()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    IsParent = true,
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    IsChild = true,
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            // ACT
            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            // ASSERT
            Mock.Get(testObjects.LinkedPremiumsUpdateFromParentService)
                .Verify(p => p.UpdateBidAskMarginsFromParent(-0.01M,
                                                             0.01M,
                                                             It.Is<IEnumerable<DailyPriceRowViewModel>>(r => r.SequenceEqual(dailyPrices))));
        }

        [Test]
        public void ShouldUpdateTenorPremiums_When_OtherPremiumChangesAreChildrenOnly()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false, IsValid = true },
                TenorPremium =
                {
                    MarginChanged = true,
                    IsChild = true,
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var premiumBuilderResult = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                                   .WithPublisherId(10)
                                                                                   .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .WithPublisherTenorPremiumResult(premiumBuilderResult)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            // ACT
            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(premiumBuilderResult, It.IsAny<IScheduler>()), Times.Once);
        }

        [Test]
        public void ShouldNotUpdateTenorPremiums_When_OverridesHaveChanged()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = true },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            // ACT
            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PublisherTenorPremium>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldNotUpdateTenorPremiums_When_Disposed()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            testObjects.TenorPremiumsSpinUpdateService.Dispose();

            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            // ACT
            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PublisherTenorPremium>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var dailyPrice1 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrice2 = new DailyPriceRowViewModel(Mock.Of<IDisposable>())
            {
                ManualPriceCell = { HasManualChange = false },
                TenorPremium =
                {
                    BidMargin = {Margin = {Value = -0.01M, ServerValue = -0.01M}},
                    AskMargin = {Margin = {Value = 0.01M, ServerValue = 0.01M}}
                }
            };

            var dailyPrices = new List<DailyPriceRowViewModel>
                              {
                                  dailyPrice1, dailyPrice2
                              };

            var premium = new PublisherTenorPremiumTestObjectBuilder().WithId(201)
                                                                      .WithPublisherId(10)
                                                                      .Build();

            var testObjects = new TenorPremiumsSpinUpdateServiceTestObjectBuilder().WithPublisherTenorPremium(premium)
                                                                                   .WithContinuityCheckResult(true)
                                                                                   .Build();

            testObjects.TenorPremiumsSpinUpdateService.AttachBandInfo(testObjects.BandHeader);

            // ARRANGE
            testObjects.TenorPremiumsSpinUpdateService.SubscribeUpdates(dailyPrices);

            testObjects.TenorPremiumsSpinUpdateService.Dispose();
            testObjects.TenorPremiumsSpinUpdateService.Dispose();

            testObjects.SpinUpdate.OnNext(dailyPrice1.TenorPremium);

            // ACT
            var interval = TimeSpan.FromMilliseconds(260).Ticks;
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PublisherTenorPremium>(), It.IsAny<IScheduler>()), Times.Never);
        }
    }
}
