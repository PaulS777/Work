﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.DailyPricing.Services.Efp;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using Dsp.Gui.TestObjects;
using NUnit.Framework;
using Moq;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Efp
{
    internal interface IEfpMonthlyItemsProviderTestObjects
    {
        ILivePriceStreamService LivePriceStreamService { get; }
        ISubject<PriceCurve> PriceCurve { get; }
        ISubject<DateTime?> CurrentBusinessDate { get; }
        EfpMonthItemsProvider EfpMonthItemsProvider { get; }
    }

    public class EfpMonthlyItemsProviderTests
    {
        private class EfpMonthlyItemsProviderTestObjectBuilder
        {
            private DateTime _today;
            private PriceCurve _priceCurve;

            public EfpMonthlyItemsProviderTestObjectBuilder WithToday(DateTime value)
            {
                _today = value;
                return this;
            }

            public EfpMonthlyItemsProviderTestObjectBuilder WithPriceCurve(PriceCurve value)
            {
                _priceCurve = value;
                return this;
            }

            public IEfpMonthlyItemsProviderTestObjects Build()
            {
                var testObjects = new Mock<IEfpMonthlyItemsProviderTestObjects>();

                var priceCurve = new BehaviorSubject<PriceCurve>(_priceCurve);

                testObjects.SetupGet(o => o.PriceCurve)
                           .Returns(priceCurve);

                var stream = new Mock<ILivePriceStreamService>();

                stream.SetupGet(s => s.PriceCurve)
                      .Returns(priceCurve);

                testObjects.SetupGet(o => o.LivePriceStreamService)
                           .Returns(stream.Object);

                var today = new BehaviorSubject<DateTime?>(_today);

                testObjects.SetupGet(o => o.CurrentBusinessDate)
                           .Returns(today);

                var systemDateProvider = new Mock<ISystemDateProvider>();

                systemDateProvider.SetupGet(p => p.SystemDate)
                                  .Returns(today);

                var efpMonthlyTenorsProvider = new EfpMonthItemsProvider(systemDateProvider.Object);

                testObjects.SetupGet(o => o.EfpMonthItemsProvider)
                           .Returns(efpMonthlyTenorsProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishEpfMonthItems_With_IsEnabledTrue_After_MinCurveTenor()
        {
            var today = new DateTime(2023, 8, 15);

            var tenors = new List<MonthlyTenor>
                           {
                               new(2023, 10),
                               new(2023, 11),
                               new(2023, 12),
                               new(2024, 1)
                           };

            var tenorPrices = new TenorPrices<MonthlyTenor>(tenors, new List<double?>(), new List<double?>(), new List<double?>(), new List<double?>());

            var priceCurve = new PriceCurveBuilder().WithMonthlyPrices(tenorPrices).Build();

            var testObjects = new EfpMonthlyItemsProviderTestObjectBuilder().WithToday(today).Build();

            List<EfpMonthItem> result = null;

            var expected = new List<EfpMonthItem>
                           {
                               new(new MonthlyTenor(2023, 9), false),
                               new(new MonthlyTenor(2023, 10), true),
                               new(new MonthlyTenor(2023, 11), true),
                               new(new MonthlyTenor(2023, 12), true),
                               new(new MonthlyTenor(2024, 1), true),
                               new(new MonthlyTenor(2024, 2), true),
                               new(new MonthlyTenor(2024, 3), true),
                               new(new MonthlyTenor(2024, 4), true),
                               new(new MonthlyTenor(2024, 5), true),
                               new(new MonthlyTenor(2024, 6), true),
                               new(new MonthlyTenor(2024, 7), true),
                               new(new MonthlyTenor(2024, 8), true)
                           };

            var efpMonthItems = testObjects.EfpMonthItemsProvider.GetEfpMonthItems(testObjects.LivePriceStreamService);

            using (efpMonthItems.Subscribe(values => result = values))
            {
                // ACT
                testObjects.PriceCurve.OnNext(priceCurve);

                // ASSERT
                Assert.That(result.SequenceEqual(expected, new EfpMonthItemComparer()));
            }
        }

        [Test]
        public void ShouldGetSnapshot_After_EfpMonthItemsPublication()
        {
            var today = new DateTime(2023, 8, 15);

            var tenors = new List<MonthlyTenor>
                           {
                               new(2023, 10),
                               new(2023, 11),
                               new(2023, 12),
                               new(2024, 1)
                           };

            var tenorPrices = new TenorPrices<MonthlyTenor>(tenors, new List<double?>(), new List<double?>(), new List<double?>(), new List<double?>());

            var priceCurve = new PriceCurveBuilder().WithMonthlyPrices(tenorPrices).Build();

            var testObjects = new EfpMonthlyItemsProviderTestObjectBuilder().WithToday(today).Build();

            var expected = new List<EfpMonthItem>
                           {
                               new(new MonthlyTenor(2023, 9), false),
                               new(new MonthlyTenor(2023, 10), true),
                               new(new MonthlyTenor(2023, 11), true),
                               new(new MonthlyTenor(2023, 12), true),
                               new(new MonthlyTenor(2024, 1), true),
                               new(new MonthlyTenor(2024, 2), true),
                               new(new MonthlyTenor(2024, 3), true),
                               new(new MonthlyTenor(2024, 4), true),
                               new(new MonthlyTenor(2024, 5), true),
                               new(new MonthlyTenor(2024, 6), true),
                               new(new MonthlyTenor(2024, 7), true),
                               new(new MonthlyTenor(2024, 8), true)
                           };

            var efpMonthItems = testObjects.EfpMonthItemsProvider.GetEfpMonthItems(testObjects.LivePriceStreamService);

            using (efpMonthItems.Subscribe(_ => {}))
            {
                // ACT
                testObjects.PriceCurve.OnNext(priceCurve);

                var result = testObjects.EfpMonthItemsProvider.EfpMonthItemsSnapshot();

                // ASSERT
                Assert.That(result.SequenceEqual(expected, new EfpMonthItemComparer()));
            }
        }

        [Test]
        public void ShouldPublishUpdatedMonthlyTenors_When_DateChangeToNextMonth()
        {
            var today = new DateTime(2023, 8, 31);

            var tenors = new List<MonthlyTenor>
                         {
                             new(2023, 10),
                             new(2023, 11),
                             new(2023, 12),
                             new(2024, 1)
                         };

            var tenorPrices = new TenorPrices<MonthlyTenor>(tenors, new List<double?>(), new List<double?>(), new List<double?>(), new List<double?>());

            var priceCurve = new PriceCurveBuilder().WithMonthlyPrices(tenorPrices).Build();

            var testObjects = new EfpMonthlyItemsProviderTestObjectBuilder().WithToday(today)
                                                                             .WithPriceCurve(priceCurve)
                                                                             .Build();

            List<EfpMonthItem> result = null;

            var expected = new List<EfpMonthItem>
                           {
                               new(new MonthlyTenor(2023, 10), true),
                               new(new MonthlyTenor(2023, 11), true),
                               new(new MonthlyTenor(2023, 12), true),
                               new(new MonthlyTenor(2024, 1), true),
                               new(new MonthlyTenor(2024, 2), true),
                               new(new MonthlyTenor(2024, 3), true),
                               new(new MonthlyTenor(2024, 4), true),
                               new(new MonthlyTenor(2024, 5), true),
                               new(new MonthlyTenor(2024, 6), true),
                               new(new MonthlyTenor(2024, 7), true),
                               new(new MonthlyTenor(2024, 8), true),
                               new(new MonthlyTenor(2024, 9), true)
                           };

            var efpMonthItems = testObjects.EfpMonthItemsProvider.GetEfpMonthItems(testObjects.LivePriceStreamService);

            using (efpMonthItems.Subscribe(values => result = values))
            {
                // ACT
                testObjects.CurrentBusinessDate.OnNext(new DateTime(2023, 9, 1));

                // ASSERT
                Assert.That(result.SequenceEqual(expected, new EfpMonthItemComparer()));
            }
        }

        [Test]
        public void ShouldNotPublishUpdatedMonthlyTenors_When_PriceCurveUpdate_With_SameTenors()
        {
            var today = new DateTime(2023, 8, 15);

            var tenors = new List<MonthlyTenor>
                         {
                             new(2023, 10),
                             new(2023, 11),
                             new(2023, 12),
                             new(2024, 1)
                         };

            var tenorPrices = new TenorPrices<MonthlyTenor>(tenors, new List<double?>(), new List<double?>(), new List<double?>(), new List<double?>());

            var priceCurve = new PriceCurveBuilder().WithMonthlyPrices(tenorPrices).Build();

            var testObjects = new EfpMonthlyItemsProviderTestObjectBuilder().WithToday(today)
                                                                             .WithPriceCurve(priceCurve)
                                                                             .Build();

            List<EfpMonthItem> result = null;

            var efpMonthItems = testObjects.EfpMonthItemsProvider.GetEfpMonthItems(testObjects.LivePriceStreamService);

            using (efpMonthItems.Subscribe(values => result = values))
            {
                var tenorPricesUpdate = new TenorPrices<MonthlyTenor>(tenors, new List<double?>(), new List<double?>(), new List<double?>(), new List<double?>());

                var priceCurveUpdate = new PriceCurveBuilder().WithMonthlyPrices(tenorPricesUpdate).Build();

                result = null;

                // ACT
                testObjects.PriceCurve.OnNext(priceCurveUpdate);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
