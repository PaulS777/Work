﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.DailyPricing.Services.Efp;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests.Services.Efp
{
    [TestFixture]
    internal class EfpUpdateChildrenFromParentServiceTests
    {
        [Test]
        public void ShouldUpdateChildrenFromParent()
        {
            var efpMonthItem = new EfpMonthItem(new MonthlyTenor(2023, 1), true);

            var parent = new DailyPriceRowTestObjectBuilder().WithEfpIsParent(true)
                                                             .WithEfpMonthItem(efpMonthItem)
                                                             .WithEfpValue(0.5M)
                                                             .Build();

            var child1 = new DailyPriceRowTestObjectBuilder().WithEfpIsChild(true)
                                                             .WithIsTradeable(true)
                                                             .WithMidPrice(5.0M)
                                                             .Build();

            var child2 = new DailyPriceRowTestObjectBuilder().WithEfpIsChild(true)
                                                             .WithIsTradeable(true)
                                                             .WithMidPrice(5.0M)
                                                             .Build();


            var nonChild = new DailyPriceRowTestObjectBuilder().WithIsTradeable(true)
                                                               .WithMidPrice(5.0M)
                                                               .Build();

            var rows = new[]
                       {
                           parent, child1, child2, nonChild
                       };

            var service = new EfpUpdateChildrenFromParentService();

            // ACT
            service.UpdateEfpChildrenFromParent(parent.EfpNarrative, rows);

            // ASSERT
            Assert.That(child1.EfpNarrative.EfpMonthItem, Is.SameAs(efpMonthItem));
            Assert.That(child1.EfpNarrative.EfpValue, Is.EqualTo(0.5M));
            Assert.That(child2.EfpNarrative.EfpMonthItem, Is.SameAs(efpMonthItem));
            Assert.That(child2.EfpNarrative.EfpValue, Is.EqualTo(0.5M));
            Assert.That(nonChild.EfpNarrative.EfpMonthItem, Is.Null);
            Assert.That(nonChild.EfpNarrative.EfpValue, Is.Null);
        }

        [Test]
        public void ShouldUpdateEfpBackupValues_When_NonTradeable_And_ShowBackupValues()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var efpMonthItem = new EfpMonthItem(jan23, true);

            var parent = new DailyPriceRowTestObjectBuilder().WithEfpIsParent(true)
                                                             .WithEfpMonthItem(efpMonthItem)
                                                             .WithEfpValue(0.5M)
                                                             .Build();

            var child = new DailyPriceRowTestObjectBuilder().WithEfpIsChild(true)
                                                            .WithIsTradeable(false)
                                                            .WithMidPrice(null)
                                                            .WithEfpShowBackupValues(true)
                                                            .Build();

            var rows = new[] { parent, child };

            var service = new EfpUpdateChildrenFromParentService();

            // ACT
            service.UpdateEfpChildrenFromParent(parent.EfpNarrative, rows);

            // ASSERT
            Assert.That(child.EfpNarrative.EfpMonthBackup, Is.EqualTo(jan23));
            Assert.That(child.EfpNarrative.EfpValueBackup, Is.EqualTo(0.5M));
            Assert.That(child.EfpNarrative.EfpMonthItem, Is.SameAs(efpMonthItem));
            Assert.That(child.EfpNarrative.EfpValue, Is.EqualTo(0.5M));
        }

        [Test]
        public void ShouldNotUpdateEfpValues_When_Tradeable_And_NullPrice()
        {
            var jan23 = new MonthlyTenor(2023, 1);
            var efpMonthItem = new EfpMonthItem(jan23, true);

            var parent = new DailyPriceRowTestObjectBuilder().WithEfpIsParent(true)
                                                             .WithEfpMonthItem(efpMonthItem)
                                                             .WithEfpValue(0.5M)
                                                             .Build();

            var child = new DailyPriceRowTestObjectBuilder().WithEfpIsChild(true)
                                                            .WithIsTradeable(true)
                                                            .WithMidPrice(null)
                                                            .WithEfpShowBackupValues(true)
                                                            .Build();

            var rows = new[] { parent, child };

            var service = new EfpUpdateChildrenFromParentService();

            // ACT
            service.UpdateEfpChildrenFromParent(parent.EfpNarrative, rows);

            // ASSERT
            Assert.That(child.EfpNarrative.EfpMonthBackup, Is.Null);
            Assert.That(child.EfpNarrative.EfpValueBackup, Is.Null);
            Assert.That(child.EfpNarrative.EfpMonthItem, Is.Null);
            Assert.That(child.EfpNarrative.EfpValue, Is.Null);
        }
    }
}
