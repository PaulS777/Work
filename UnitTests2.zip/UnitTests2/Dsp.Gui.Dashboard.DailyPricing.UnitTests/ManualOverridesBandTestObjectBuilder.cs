﻿using System;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Moq;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests
{
    internal class ManualOverridesBandTestObjectBuilder
    {
        private bool _hasErrors;
        private string _errorText;
        private CurveGroup _curveGroup;


        public ManualOverridesBandTestObjectBuilder WithHasErrors(bool value)
        {
            _hasErrors = value;
            return this;
        }

        public ManualOverridesBandTestObjectBuilder WithErrorText(string value)
        {
            _errorText = value;
            return this;
        }

        public ManualOverridesBandTestObjectBuilder WithCurveGroup(CurveGroup value)
        {
            _curveGroup = value;
            return this;
        }

        public ManualOverridesBand Build()
        {
            var band = new ManualOverridesBand(Mock.Of<IDisposable>());

            band.HasErrors = _hasErrors;
            band.ErrorText = _errorText;
            band.CurveGroup = _curveGroup;

            return band;
        }
    }
}
