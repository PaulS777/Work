﻿using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.DailyPricing.ViewModels.Bands;
using Moq;
using System;

namespace Dsp.Gui.Dashboard.DailyPricing.UnitTests
{
    internal class EfpBandTestObjectBuilder
    {
        private bool _hasErrors;
        private string _errorText;
        private CurveGroup _curveGroup;

        public EfpBandTestObjectBuilder WithHasErrors(bool value)
        {
            _hasErrors = value;
            return this;
        }

        public EfpBandTestObjectBuilder WithErrorText(string value)
        {
            _errorText = value;
            return this;
        }

        public EfpBandTestObjectBuilder WithCurveGroup(CurveGroup value)
        {
            _curveGroup = value;
            return this;
        }

        public EfpBand Build()
        {
            var band = new EfpBand(Mock.Of<IDisposable>());

            band.HasErrors = _hasErrors;
            band.ErrorText = _errorText;
            band.CurveGroup = _curveGroup;

            return band;
        }
    }
}
