﻿using System.Collections.Generic;
using Dsp.Gui.Common.PriceGrid.Services.Grid;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Grid
{
    [TestFixture]
    public class TenorTreeNodeExpansionServiceTests
    {
        [Test]
        public void ShouldGenerateNodeKeys_When_SelectedNode_HasSingleParent()
        {
            var parentNode = Mock.Of<ITenorNode>(n => n.TenorIdentifier == "2");

            var selectedNode = Mock.Of<ITenorNode>(n => n.ParentTenorIdentifier == "2"
                                                        && n.TenorIdentifier == "4");

            var tenorNodes = new List<ITenorNode>
                             {
                                 Mock.Of<ITenorNode>(n => n.TenorIdentifier == "1"),
                                 parentNode,
                                 Mock.Of<ITenorNode>(n => n.TenorIdentifier == "3"),
                                 selectedNode
                             };

            var service = new TenorTreeNodeExpansionService();

            // ACT
            var result = service.GetTenorNodeExpansionKeys(tenorNodes, selectedNode);

            // ASSERT
            Assert.That(result.Count == 1 && result[0] == "2");
        }

        [Test]
        public void ShouldGenerateNodeKeys_When_SelectedNode_HasNestedParents()
        {
            var outerParentNode = Mock.Of<ITenorNode>(n => n.TenorIdentifier == "1");

            var innerParentNode = Mock.Of<ITenorNode>(n => n.TenorIdentifier == "2"
                                                           && n.ParentTenorIdentifier == "1");

            var selectedNode = Mock.Of<ITenorNode>(n => n.ParentTenorIdentifier == "2"
                                                        && n.TenorIdentifier == "4");

            var tenorNodes = new List<ITenorNode>
                             {
                                 outerParentNode,
                                 innerParentNode,
                                 Mock.Of<ITenorNode>(n => n.ParentTenorIdentifier == "3"),
                                 selectedNode
                             };

            var service = new TenorTreeNodeExpansionService();

            // ACT
            var result = service.GetTenorNodeExpansionKeys(tenorNodes, selectedNode);

            // ASSERT
            Assert.That(result.Count == 2);
            Assert.That(result[0], Is.EqualTo("2"));
            Assert.That(result[1], Is.EqualTo("1"));
        }
    }
}
