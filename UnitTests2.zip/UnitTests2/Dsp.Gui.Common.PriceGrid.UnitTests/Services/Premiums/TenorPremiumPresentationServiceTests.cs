﻿using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Premiums
{
    public interface ITenorPremiumPresentationServiceTestObjects
    {
        TenorPremiumPresentationService TenorPremiumPresentationService { get; }
    }

    [TestFixture]
    public class TenorPremiumPresentationServiceTests
    {
        public class TenorPremiumPresentationServiceTestObjectBuilder
        {
            public ITenorPremiumPresentationServiceTestObjects Build()
            {
                var testObjects = new Mock<ITenorPremiumPresentationServiceTestObjects>();

                var presentationService = new TenorPremiumPresentationService();

                testObjects.SetupGet(o => o.TenorPremiumPresentationService)
                           .Returns(presentationService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateMarginIsChild_When_IsChildChanged()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumPresentationServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumPresentationService.Attach(tenorPremium);

            // ACT
            tenorPremium.IsChild = true;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.IsMarginChild, Is.True);
            Assert.That(tenorPremium.AskMargin.IsMarginChild, Is.True);
        }

        [Test]
        public void ShouldSetMarginIsEditableFalse_When_IsChildTrue_With_IsPublisher()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            var testObjects = new TenorPremiumPresentationServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumPresentationService.Attach(tenorPremium);

            // ACT
            tenorPremium.IsChild = true;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.IsEditable, Is.False);
            Assert.That(tenorPremium.AskMargin.Margin.IsEditable, Is.False);
        }

        [Test]
        public void ShouldSetMarginIsEditableTrue_When_IsChildFalse_With_IsPublisher()
        {
            var tenorPremium = new TenorPremiumViewModel
            {
                IsChild = true,
                BidMargin = {Margin = {IsEditable = false}},
                AskMargin = {Margin = {IsEditable = false}},
                IsCurrentUserPublisher = true
            };

            var testObjects = new TenorPremiumPresentationServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumPresentationService.Attach(tenorPremium);

            // ACT
            tenorPremium.IsChild = false;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.IsEditable, Is.True);
            Assert.That(tenorPremium.AskMargin.Margin.IsEditable, Is.True);
        }

        [Test]
        public void ShouldUpdateMarginCellBorderTypes_When_CellBorderTypeChanged()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumPresentationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorPremiumPresentationService.Attach(tenorPremium);

            // ACT
            tenorPremium.CellBorderType = GroupedCellBorderType.Parent;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.CellBorderType, Is.EqualTo(GroupedCellBorderType.Parent));
            Assert.That(tenorPremium.AskMargin.CellBorderType, Is.EqualTo(GroupedCellBorderType.Parent));
        }

        [Test]
        public void ShouldNotUpdateMarginIsChild_When_Disposed()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumPresentationServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumPresentationService.Attach(tenorPremium);

            testObjects.TenorPremiumPresentationService.Dispose();

            // ACT
            tenorPremium.IsChild = true;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.IsMarginChild, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumPresentationServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumPresentationService.Attach(tenorPremium);

            testObjects.TenorPremiumPresentationService.Dispose();

            // ACT
            testObjects.TenorPremiumPresentationService.Dispose();
            tenorPremium.IsChild = true;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.IsMarginChild, Is.False);
        }
    }
}
