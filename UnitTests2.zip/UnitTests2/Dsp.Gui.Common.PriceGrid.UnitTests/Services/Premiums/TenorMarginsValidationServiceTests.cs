﻿using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Premiums
{
    [TestFixture]
    public class TenorMarginsValidationServiceTests
    {
        [Test]
        public void ShouldSetHasErrorsFalse_When_Attached_With_NoErrors_And_IsPublisherTrue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = -1.0M;
            tenorPremium.AskMargin.Margin.Value = 1.0M;

            var service = new TenorMarginsValidationService();

            // ACT
            service.AttachPremium(tenorPremium);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.HasMarginErrors, Is.False);
        }

        [Test]
        public void ShouldSetHasErrorsTrue_When_Attached_With_Errors_And_IsPublisherTrue()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = 0.0M;
            tenorPremium.AskMargin.Margin.Value = 0.0M;

            var service = new TenorMarginsValidationService();

            // ACT
            service.AttachPremium(tenorPremium);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.True);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.True);
            Assert.That(tenorPremium.HasMarginErrors, Is.True);
        }

        [Test]
        public void ShouldSetHasErrorsFalse_When_Attached_With_Errors_And_IsPublisherFalse()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = false
                               };

            tenorPremium.BidMargin.Margin.Value = 0.0M;
            tenorPremium.AskMargin.Margin.Value = 0.0M;

            var service = new TenorMarginsValidationService();

            // ACT
            service.AttachPremium(tenorPremium);

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.HasMarginErrors, Is.False);
        }

        [Test]
        public void ShouldSetHasErrorsTrue_When_BidValueChanged_ToGreaterThanAsk()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = -1.0M;
            tenorPremium.AskMargin.Margin.Value = 1.0M;

            var service = new TenorMarginsValidationService();

            service.AttachPremium(tenorPremium);

            // ACT
            tenorPremium.BidMargin.Margin.Value = 2.0M;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.True);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.True);
            Assert.That(tenorPremium.HasMarginErrors, Is.True);
        }

        [Test]
        public void ShouldSetHasErrorsFalse_When_BidValueChanged_ToLessThanAsk()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = -1.0M;
            tenorPremium.AskMargin.Margin.Value = 1.0M;

            var service = new TenorMarginsValidationService();

            service.AttachPremium(tenorPremium);
            tenorPremium.BidMargin.Margin.Value = 2.0M;

            // ACT
            tenorPremium.BidMargin.Margin.Value = -2.0M;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.HasMarginErrors, Is.False);
        }

        [Test]
        public void ShouldSetHasErrorsTrue_When_ValuesAreSame()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = -1.0M;
            tenorPremium.AskMargin.Margin.Value = 1.0M;

            var service = new TenorMarginsValidationService();

            service.AttachPremium(tenorPremium);

            // ACT
            tenorPremium.AskMargin.Margin.Value = -1.0M;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.True);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.True);
            Assert.That(tenorPremium.HasMarginErrors, Is.True);
        }

        [Test]
        public void ShouldSetHasErrorsFalse_When_IsPublisherUpdatedToFalse_With_Errors()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = 0.0M;
            tenorPremium.AskMargin.Margin.Value = 0.0M;

            var service = new TenorMarginsValidationService();

            service.AttachPremium(tenorPremium);

            // ACT
            tenorPremium.IsCurrentUserPublisher = false;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.HasMarginErrors, Is.False);
        }

        [Test]
        public void ShouldSetHasErrorsTrue_When_IsPublisherUpdatedToTrue_With_Errors()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = false
                               };

            tenorPremium.BidMargin.Margin.Value = 0.0M;
            tenorPremium.AskMargin.Margin.Value = 0.0M;

            var service = new TenorMarginsValidationService();

            service.AttachPremium(tenorPremium);

            // ACT
            tenorPremium.IsCurrentUserPublisher = true;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.True);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.True);
            Assert.That(tenorPremium.HasMarginErrors, Is.True);
        }

        [Test]
        public void ShouldNotValidateWhenDisposed()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = -1.0M;
            tenorPremium.AskMargin.Margin.Value = 1.0M;

            var service = new TenorMarginsValidationService();

            service.AttachPremium(tenorPremium);

            service.Dispose();

            // ACT
            tenorPremium.BidMargin.Margin.Value = 2.0M;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.False);
        }

        [Test]
        public void ShouldNotDisposeWhenDisposed()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = -1.0M;
            tenorPremium.AskMargin.Margin.Value = 1.0M;

            var service = new TenorMarginsValidationService();

            service.AttachPremium(tenorPremium);

            service.Dispose();

            // ACT
            service.Dispose();
            tenorPremium.BidMargin.Margin.Value = 2.0M;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.False);
        }

        [Test]
        public void ShouldSetHasErrorsFalse_When_ValuesSetToNull()
        {
            var tenorPremium = new TenorPremiumViewModel
                               {
                                   IsCurrentUserPublisher = true
                               };

            tenorPremium.BidMargin.Margin.Value = -1.0M;
            tenorPremium.AskMargin.Margin.Value = 1.0M;

            var service = new TenorMarginsValidationService();

            service.AttachPremium(tenorPremium);

            tenorPremium.AskMargin.Margin.Value = -1.0M;

            // ACT
            tenorPremium.AskMargin.Margin.Value = null;
            tenorPremium.BidMargin.Margin.Value = null;

            // ASSERT
            Assert.That(tenorPremium.BidMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.AskMargin.Margin.HasError, Is.False);
            Assert.That(tenorPremium.HasMarginErrors, Is.False);
        }
    }
}
