﻿using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Premiums
{
    [TestFixture]
    public class TenorPremiumViewModelUpdaterTests
    {
        [Test]
        public void ShouldUpdateMargins_And_IsPublisher()
        {
            var viewModel = new TenorPremiumViewModel();

            var updater = new TenorPremiumViewModelUpdater();

            // ACT
            updater.UpdateTenorPremium(viewModel, -0.1M, 0.1M, true);

            // ASSERT
            Assert.That(viewModel.IsCurrentUserPublisher, Is.True);
            Assert.That(viewModel.BidMargin.Margin.ServerValue, Is.EqualTo(-0.1M));
            Assert.That(viewModel.AskMargin.Margin.ServerValue, Is.EqualTo(0.1M));
        }

        [Test]
        public void ShouldNotChange_ParentChild_When_IsPublisherTrue()
        {
            var viewModel = new TenorPremiumViewModel()
            {
                BidMargin =
                {
                    Margin = {IsEditable = false},
                    IsMarginParent = true,
                    IsMarginChild = true
                },
                AskMargin =
                {
                    Margin = {IsEditable = false},
                    IsMarginParent = true,
                    IsMarginChild = true
                }
            };


            var updater = new TenorPremiumViewModelUpdater();

            // ACT
            updater.UpdateTenorPremium(viewModel, -0.1M, 0.1M, true);

            // ASSERT
            Assert.That(viewModel.BidMargin.IsMarginParent, Is.True);
            Assert.That(viewModel.BidMargin.IsMarginChild, Is.True);
            Assert.That(viewModel.AskMargin.IsMarginParent, Is.True);
            Assert.That(viewModel.AskMargin.IsMarginChild, Is.True);
        }

        [Test]
        public void ShouldSetIsEditableTrue_When_NotChild_And_IsPublisherTrue()
        {
            var viewModel = new TenorPremiumViewModel
            {
                BidMargin =
                {
                    Margin = {IsEditable = false},
                    IsMarginParent = false,
                    IsMarginChild = false
                },
                AskMargin =
                {
                    Margin = {IsEditable = false},
                    IsMarginParent = false,
                    IsMarginChild = false
                }
            };


            var updater = new TenorPremiumViewModelUpdater();

            // ACT
            updater.UpdateTenorPremium(viewModel, -0.1M, 0.1M, true);

            // ASSERT
            Assert.That(viewModel.BidMargin.Margin.IsEditable, Is.True);
            Assert.That(viewModel.AskMargin.Margin.IsEditable, Is.True);
        }

        [Test]
        public void ShouldSetIsEditableFalse_When_IsChild_And_IsPublisherTrue()
        {
            var viewModel = new TenorPremiumViewModel()
            {
                BidMargin =
                {
                    Margin = {IsEditable = false},
                    IsMarginParent = false,
                    IsMarginChild = true
                },
                AskMargin =
                {
                    Margin = {IsEditable = false},
                    IsMarginParent = false,
                    IsMarginChild = true
                }
            };


            var updater = new TenorPremiumViewModelUpdater();

            // ACT
            updater.UpdateTenorPremium(viewModel, -0.1M, 0.1M, true);

            // ASSERT
            Assert.That(viewModel.BidMargin.Margin.IsEditable, Is.False);
            Assert.That(viewModel.AskMargin.Margin.IsEditable, Is.False);
        }

        [Test]
        public void ShouldSetReadonly_And_ClearParentChild_When_IsPublisherFalse()
        {
            var viewModel = new TenorPremiumViewModel()
            {
                BidMargin =
                {
                    Margin = {IsEditable = true},
                    IsMarginParent = true,
                    IsMarginChild = true
                },
                AskMargin =
                {
                    Margin = {IsEditable = true},
                    IsMarginParent = true,
                    IsMarginChild = true
                }
            };


            var updater = new TenorPremiumViewModelUpdater();

            // ACT
            updater.UpdateTenorPremium(viewModel, -0.1M, 0.1M, false);

            // ASSERT
            Assert.That(viewModel.BidMargin.Margin.IsEditable, Is.False);
            Assert.That(viewModel.BidMargin.IsMarginParent, Is.False);
            Assert.That(viewModel.BidMargin.IsMarginChild, Is.False);
            Assert.That(viewModel.AskMargin.Margin.IsEditable, Is.False);
            Assert.That(viewModel.AskMargin.IsMarginParent, Is.False);
            Assert.That(viewModel.AskMargin.IsMarginChild, Is.False);
        }
    }
}
