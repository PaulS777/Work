﻿using System;
using System.Reactive.Subjects;
using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Premiums
{
    [TestFixture]
    public class MarginValueChangedServiceTests
    {
        [Test]
        public void ShouldInitializeValueFromServerValue()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid);

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            // ACT
            marginEditor.Margin.ServerValue = 2.0M;

            // ASSERT
            Assert.That(marginEditor.Margin.Value, Is.EqualTo(2.0));
            Assert.That(marginEditor.Margin.EditValue, Is.EqualTo(2.0));
            Assert.That(marginEditor.HasChanged, Is.False);
        }

        [Test]
        public void ShouldSetHasChangedTrue_When_ValueChanged()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid);

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            marginEditor.Margin.ServerValue = 2.0M;

            // ACT
            marginEditor.Margin.Value = 2.1M;

            // ASSERT
            Assert.That(marginEditor.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedFalse_When_ValueChangeReverted()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid);

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            marginEditor.Margin.ServerValue = 2.0M;
            marginEditor.Margin.Value = 2.1M;

            // ACT
            marginEditor.Margin.Value = 2.0M;

            // ASSERT
            Assert.That(marginEditor.HasChanged, Is.False);
        }

        [Test]
        public void ShouldNotUpdateValueFromServer_When_Disposed()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid);

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);
            service.Dispose();

            // ACT
            marginEditor.Margin.ServerValue = 2.0M;

            // ASSERT
            Assert.IsNull(marginEditor.Margin.Value);
        }

        [Test]
        public void ShouldNotUpdateHasChanged_When_Disposed()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid);

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            marginEditor.Margin.ServerValue = 2.0M;
            service.Dispose();

            // ACT
            marginEditor.Margin.Value = 2.1M;

            // ASSERT
            Assert.That(marginEditor.HasChanged, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid);

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            marginEditor.Margin.ServerValue = 2.0M;
            service.Dispose();

            // ACT
            service.Dispose();
            marginEditor.Margin.Value = 2.1M;

            // ASSERT
            Assert.That(marginEditor.HasChanged, Is.False);
        }

        [Test]
        public void ShouldPublishSpinUpdate_WhenMarginValueChange_AfterSpinCommandInvoked()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid);
            marginEditor.Margin.ServerValue = 1;

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            decimal? result = null;

            using (spinValue.Subscribe(value => result = value))
            {
                // ACT
                marginEditor.SpinCommand.Execute();
                marginEditor.Margin.Value = 1.01M;

                // ASSERT
                Assert.That(result, Is.EqualTo(1.01M));
            }
        }

        [Test]
        public void ShouldPublishMultipleSpinUpdates_WhenMarginValueChanged_AfterMultipleSpinCommandInvoked()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid)
                               {
                                   Margin =
                                   {
                                       ServerValue = 1
                                   }
                               };

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            var spinUpdates = 0;

            using (spinValue.Subscribe(_ => spinUpdates++))
            {
                marginEditor.SpinCommand.Execute();
                marginEditor.Margin.Value = 1.01M;

                // ACT
                marginEditor.SpinCommand.Execute();
                marginEditor.Margin.Value = 1.02M;

                // ASSERT
                Assert.That(spinUpdates, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldNotPublishSpinUpdate_WhenSpinValueChanged_AfterTextUpdate()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid);
            marginEditor.Margin.ServerValue = 1;

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            decimal? result = null;

            using (spinValue.Subscribe(value => result = value))
            {
                marginEditor.Margin.Value = 1.05M;

                marginEditor.SpinCommand.Execute();
                marginEditor.Margin.Value = 1.06M;

                // ACT
                marginEditor.SpinCommand.Execute();
                marginEditor.Margin.Value = 1.07M;

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldResetSpinUpdateAndPublishChanged_WhenSpinValueChanged_AfterServerUpdate()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid)
                               {
                                   Margin =
                                   {
                                       ServerValue = 1
                                   }
                               };

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            decimal? result = null;

            using (spinValue.Subscribe(value => result = value))
            {
                marginEditor.Margin.Value = 1.05M;

                marginEditor.SpinCommand.Execute();
                marginEditor.Margin.Value = 1.06M;

                marginEditor.Margin.ServerValue = 1.06M;

                // ACT
                marginEditor.SpinCommand.Execute();
                marginEditor.Margin.Value = 1.07M;

                // ASSERT
                Assert.That(result, Is.EqualTo(1.07));
            }
        }

        [Test]
        public void ShouldNotPublishTextUpdate_WhenMarginValueChange_CausedByTextEditor()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid)
                               {
                                   Margin =
                                   {
                                       ServerValue = 1
                                   }
                               };

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            decimal? result = null;

            using (textValue.Subscribe(value => result = value))
            {
                marginEditor.SpinCommand.Execute();

                // ACT
                marginEditor.Margin.Value = 1.01M;

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldPublishTextUpdate_WhenMarginValueChange_CausedByTextEditor()
        {
            var textValue = new Subject<decimal?>();
            var spinValue = new Subject<decimal?>();

            var marginEditor = new TenorMargin(TenorMarginSide.Bid)
                               {
                                   Margin =
                                   {
                                       ServerValue = 1
                                   }
                               };

            var service = new MarginValueChangedService();

            service.AttachMargin(marginEditor, textValue, spinValue);

            decimal? result = null;

            using (textValue.Subscribe(value => result = value))
            {
                // ACT
                marginEditor.Margin.Value = 1.01M;

                // ASSERT
                Assert.That(result, Is.EqualTo(1.01));
            }
        }
    }
}
