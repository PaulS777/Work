﻿// ***********************************************************************************************************************
// TenorPremiumChangedServiceTests.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------

using System;
using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Premiums
{
    public interface ITenorPremiumChangedServiceTestObjects
    {
        IMarginValueChangedService BidMarginValueChangedService { get; }
        IMarginValueChangedService AskMarginValueChangedService { get; }
        TenorPremiumChangedService TenorPremiumChangedService { get; }
    }

    [TestFixture]
    public class TenorPremiumChangedServiceTests
    {
        public class TenorPremiumChangedServiceTestObjectBuilder
        {
            public ITenorPremiumChangedServiceTestObjects Build()
            {
                var testObjects = new Mock<ITenorPremiumChangedServiceTestObjects>();

                var bidMarginValueChanged = new Mock<IMarginValueChangedService>();
                testObjects.SetupGet(o => o.BidMarginValueChangedService).Returns(bidMarginValueChanged.Object);

                var askMarginValueChanged = new Mock<IMarginValueChangedService>();
                testObjects.SetupGet(o => o.AskMarginValueChangedService).Returns(askMarginValueChanged.Object);

                var premiumChangedService = new TenorPremiumChangedService(bidMarginValueChanged.Object,
                                                                           askMarginValueChanged.Object);

                testObjects.SetupGet(o => o.TenorPremiumChangedService)
                           .Returns(premiumChangedService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeServices_On_AttachTenorPremium()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumChangedServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorPremiumChangedService.Attach(tenorPremium);

            // ASSERT
            Mock.Get(testObjects.BidMarginValueChangedService)
                .Verify(c => c.AttachMargin(tenorPremium.BidMargin, It.IsAny<IObserver<decimal?>>(), It.IsAny<IObserver<decimal?>>()));

            Mock.Get(testObjects.BidMarginValueChangedService)
                .Verify(c => c.AttachMargin(tenorPremium.BidMargin, It.IsAny<IObserver<decimal?>>(), It.IsAny<IObserver<decimal?>>()));
        }

        [Test]
        public void ShouldUpdateMarginChanged_When_BidMarginChanged()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumChangedServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumChangedService.Attach(tenorPremium);

            // ACT
            tenorPremium.BidMargin.HasChanged = true;

            // ASSERT
            Assert.That(tenorPremium.MarginChanged, Is.True);
        }

        [Test]
        public void ShouldUpdateMarginChanged_When_AskMarginChanged()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumChangedServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumChangedService.Attach(tenorPremium);

            // ACT
            tenorPremium.AskMargin.HasChanged = true;

            // ASSERT
            Assert.That(tenorPremium.MarginChanged, Is.True);
        }

        [Test]
        public void ShouldDisposeOfServices_On_Dispose()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumChangedServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumChangedService.Attach(tenorPremium);

            // ACT
            testObjects.TenorPremiumChangedService.Dispose();

            // ASSERT

            Mock.Get(testObjects.BidMarginValueChangedService)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.BidMarginValueChangedService)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var tenorPremium = new TenorPremiumViewModel();

            var testObjects = new TenorPremiumChangedServiceTestObjectBuilder().Build();

            testObjects.TenorPremiumChangedService.Attach(tenorPremium);
            testObjects.TenorPremiumChangedService.Dispose();

            // ACT
            testObjects.TenorPremiumChangedService.Dispose();

            // ASSERT
            Mock.Get(testObjects.BidMarginValueChangedService)
                .Verify(c => c.Dispose(), Times.Once);
        }
    }
}
