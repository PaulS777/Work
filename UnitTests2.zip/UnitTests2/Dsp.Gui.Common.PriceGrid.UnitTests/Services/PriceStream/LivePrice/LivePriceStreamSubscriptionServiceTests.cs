﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.PriceStream.LivePrice
{
    public interface ILivePriceStreamSubscriptionServiceTestObjects
    {
        IPriceCurveService PriceCurveService { get; }
        ILivePriceStreamReadyService LivePriceStreamReadyService { get; }
        Subject<Unit> PriceStreamsReady { get; }
        LivePriceStreamSubscriptionService LivePriceStreamSubscriptionService { get; }
    }

    [TestFixture]
    public class LivePriceStreamSubscriptionServiceTests
    {
        private class LivePriceStreamSubscriptionServiceTestObjectBuilder
        {
            private readonly Mock<IPriceCurveSubscriptionManager> _priceCurveSubscriptionManager = new();
            private ILivePriceStreamService _livePriceStreamService;
            private ILivePriceStreamService _updatedLivePriceStreamService;

            public LivePriceStreamSubscriptionServiceTestObjectBuilder WithLivePriceStreamService(ILivePriceStreamService value)
            {
                _livePriceStreamService = value;
                return this;
            }

            public LivePriceStreamSubscriptionServiceTestObjectBuilder WithUpdatedLivePriceStreamService(ILivePriceStreamService value)
            {
                _updatedLivePriceStreamService = value;
                return this;
            }

            public LivePriceStreamSubscriptionServiceTestObjectBuilder WithPriceCurveSubject(int curveId, IObservable<PriceCurve> priceCurve)
            {
                _priceCurveSubscriptionManager.Setup(c => c.GetPriceCurve(curveId)).Returns(priceCurve);
                return this;
            }

            public ILivePriceStreamSubscriptionServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceStreamSubscriptionServiceTestObjects>();

                var priceCurveService = new Mock<IPriceCurveService>();

                testObjects.SetupGet(o => o.PriceCurveService)
                           .Returns(priceCurveService.Object);

                var priceStreamsReady = new Subject<Unit>();

                testObjects.SetupGet(o => o.PriceStreamsReady)
                           .Returns(priceStreamsReady);

                var livePriceStreamReadyService = new Mock<ILivePriceStreamReadyService>();

                livePriceStreamReadyService.Setup(r => r.LivePriceStreamsReady(It.IsAny<IList<ILivePriceStreamService>>()))
                                           .Returns(priceStreamsReady);

                testObjects.SetupGet(o => o.LivePriceStreamReadyService)
                           .Returns(livePriceStreamReadyService.Object);

                var factory = new Mock<IServiceFactory<ILivePriceStreamService>>();

                factory.SetupSequence(f => f.Create())
                       .Returns(_livePriceStreamService)
                       .Returns(_updatedLivePriceStreamService);

                var livePriceStreamSubscriptionService = new LivePriceStreamSubscriptionService(priceCurveService.Object,
                                                                                                livePriceStreamReadyService.Object,
                                                                                                _priceCurveSubscriptionManager.Object)
                                                         {
                                                             ServiceFactory = factory.Object
                                                         };

                testObjects.SetupGet(o => o.LivePriceStreamSubscriptionService)
                           .Returns(livePriceStreamSubscriptionService);

                return testObjects.Object;
            }
        }

        [TestCase(true)]
        [TestCase(false)]
        public void ShouldSubscribeToPriceCurves(bool refreshAllPrices)
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var liveStreamDetails = new PriceCurveDetails(PriceCurveType.Live, linkedCurve, 2);

            var livePriceStream = new Mock<ILivePriceStreamService>();

            livePriceStream.Setup(l => l.GetDetails())
                           .Returns(liveStreamDetails);

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(livePriceStream.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .Build();

            var filter = new List<PriceCurveDetails>
            {
                new(PriceCurveType.Live, linkedCurve, 2)
            };

            // ACT
            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, 
                                                                               refreshAllPrices);

            // ASSERT
            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.SubscribeToPriceCurves(It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 101)));
        }

        [Test]
        public void ShouldDispose_And_UnsubscribeDeselectedCurves_When_ManualRefresh()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var oldPriceCurve = new PriceCurveBuilder().Build();

            var oldStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1)
                                                                          .WithPriceCurveSnapshot(oldPriceCurve)
                                                                          .Build();

            var newStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve2)
                                                                          .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(oldStreamService.Object)
                                                                                       .WithUpdatedLivePriceStreamService(newStreamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .Build();

            var filter = new List<PriceCurveDetails>
                         {
                             new(PriceCurveType.Live, linkedCurve1, 2)
                         };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, false);

            // ACT
            var filterUpdate = new List<PriceCurveDetails>
                               {
                                   new(PriceCurveType.Live, linkedCurve2, 2)
                               };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filterUpdate, false);

            // ASSERT
            oldStreamService.Verify(s => s.Dispose());

            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.UnsubscribeFromPriceCurves(It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 101)));
        }

        [Test]
        public void ShouldUnsubscribeNonLoadedCurves_When_ManualRefresh()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var oldStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve)
                                                                          .WithPriceCurve(null)
                                                                          .Build();

            var newStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve)
                                                                          .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(oldStreamService.Object)
                                                                                       .WithUpdatedLivePriceStreamService(newStreamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .Build();

            var filter = new List<PriceCurveDetails>
                         {
                             new(PriceCurveType.Live, linkedCurve, 2)
                         };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, false);

            // ACT
            var filterUpdate = new List<PriceCurveDetails>
                               {
                                   new(PriceCurveType.Live, linkedCurve, 2)
                               };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filterUpdate, false);

            // ASSERT
            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.UnsubscribeFromPriceCurves(It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 101)));
        }

        [Test]
        public void ShouldRetainStreamProvider_When_ManualRefresh_ContainsSameStreamProvider()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var oldPriceCurve = new PriceCurveBuilder().Build();

            var oldStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1)
                                                                          .WithPriceCurveSnapshot(oldPriceCurve)
                                                                          .Build();

            var newPriceCurve = new PriceCurveBuilder().Build();

            var newStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve2)
                                                                          .WithPriceCurveSnapshot(newPriceCurve)
                                                                          .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(oldStreamService.Object)
                                                                                       .WithUpdatedLivePriceStreamService(newStreamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .Build();

            var filterItem1 = new PriceCurveDetails(PriceCurveType.Live, linkedCurve1, 2);
            var filterItem2 = new PriceCurveDetails(PriceCurveType.Live, linkedCurve2, 2);

            var filter = new List<PriceCurveDetails>
                         {
                             filterItem1
                         };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, false);

            // ACT
            var filterUpdate = new List<PriceCurveDetails>
                               {
                                   filterItem1, filterItem2
                               };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filterUpdate, false);

            // ASSERT
            oldStreamService.Verify(s => s.Dispose(), Times.Never);
            oldStreamService.Verify(s => s.Initialize(priceCurve), Times.Once);
        }

        [Test]
        public void ShouldInitializeNewStreamServices_When_ManualRefresh()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var oldPriceCurve = new PriceCurveBuilder().Build();

            var oldStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1)
                                                                          .WithPriceCurveSnapshot(oldPriceCurve)
                                                                          .Build();

            var newPriceCurve = new PriceCurveBuilder().Build();

            var newStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve2)
                                                                          .WithPriceCurveSnapshot(newPriceCurve)
                                                                          .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(oldStreamService.Object)
                                                                                       .WithUpdatedLivePriceStreamService(newStreamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .WithPriceCurveSubject(102, priceCurve)
                                                                                       .Build();

            var filterItem1 = new PriceCurveDetails(PriceCurveType.Live, linkedCurve1, 2);
            var filterItem2 = new PriceCurveDetails(PriceCurveType.Live, linkedCurve2, 2);

            var filter = new List<PriceCurveDetails>
                         {
                             filterItem1
                         };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, false);

            // ACT
            var filterUpdate = new List<PriceCurveDetails>
                               {
                                   filterItem1, filterItem2
                               };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filterUpdate, false);

            // ASSERT
            newStreamService.Verify(p => p.Initialize(priceCurve));
        }

        [Test]
        public void ShouldUpdatePriceCurveSubscriptions_When_ManualRefresh_WithChangedFilter()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var oldPriceCurve = new PriceCurveBuilder().Build();

            var oldStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve1)
                                                                          .WithPriceCurveSnapshot(oldPriceCurve)
                                                                          .Build();


            var newPriceCurve = new PriceCurveBuilder().Build();

            var newStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve2)
                                                                          .WithPriceCurveSnapshot(newPriceCurve)
                                                                          .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(oldStreamService.Object)
                                                                                       .WithUpdatedLivePriceStreamService(newStreamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .WithPriceCurveSubject(102, priceCurve)
                                                                                       .Build();

            var filterItem1 = new PriceCurveDetails(PriceCurveType.Live, linkedCurve1, 2);
            var filterItem2 = new PriceCurveDetails(PriceCurveType.Live, linkedCurve2, 2);

            var filter = new List<PriceCurveDetails>
                         {
                             filterItem1
                         };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, false);

            // ACT
            var filterUpdate = new List<PriceCurveDetails>
                               {
                                   filterItem1, filterItem2
                               };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filterUpdate, false);

            // ASSERT
            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.UnsubscribeFromPriceCurves(It.IsAny<IList<int>>()), Times.Never());

            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.SubscribeToPriceCurves(It.IsAny<IList<int>>()), Times.Exactly(2));

            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.SubscribeToPriceCurves(It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 101)), Times.Once);

            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.SubscribeToPriceCurves(It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 102)), Times.Once);
        }

        [Test]
        public void ShouldNotUpdatePriceCurveSubscriptions_When_ManualRefresh_WithUnchangedFilter()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var oldPriceCurve = new PriceCurveBuilder().Build();

            var oldStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve)
                                                                          .WithPriceCurveSnapshot(oldPriceCurve)
                                                                          .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(oldStreamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .WithPriceCurveSubject(102, priceCurve)
                                                                                       .Build();

            var filterItem = new PriceCurveDetails(PriceCurveType.Live, linkedCurve, 2);

            var filter = new List<PriceCurveDetails>
                         {
                             filterItem
                         };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, false);

            Mock.Get(testObjects.PriceCurveService).Reset();

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, false);

            // ASSERT
            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.UnsubscribeFromPriceCurves(It.IsAny<IList<int>>()), Times.Never());

            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.SubscribeToPriceCurves(It.IsAny<IList<int>>()), Times.Never);
        }

        [Test]
        public void ShouldInitializePriceStreamServices_When_RefreshPriceStreams_With_ResetAllStreamsTrue()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var oldStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve)
                                                                          .Build();

            var newStreamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve)
                                                                          .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(oldStreamService.Object)
                                                                                       .WithUpdatedLivePriceStreamService(newStreamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .WithPriceCurveSubject(102, priceCurve)
                                                                                       .Build();

            var filterItem = new PriceCurveDetails(PriceCurveType.Live, linkedCurve, 2);

            var filter = new List<PriceCurveDetails>
                         {
                             filterItem
                         };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, false);

            Mock.Get(testObjects.PriceCurveService).Reset();

            // ACT
            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, true);

            // ASSERT
            oldStreamService.Verify(s => s.Dispose());

            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.SubscribeToPriceCurves(It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 101)), Times.Once);

            newStreamService.Verify(s => s.Initialize(priceCurve));
        }

        [TestCase(true)]
        [TestCase(false)]
        public void ShouldPublishPriceStreamsWhenReady(bool resetAllStreams)
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var streamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve)
                                                                       .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(streamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .Build();

            IList<ILivePriceStreamService> result = null;

            var filterItem = new PriceCurveDetails(PriceCurveType.Live, linkedCurve, 2);

            var filter = new List<PriceCurveDetails>
                         {
                             filterItem
                         };

            using (testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, resetAllStreams)
                              .Subscribe(p => result = p))
            {
                // ACT
                testObjects.PriceStreamsReady.OnNext(Unit.Default);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
                Assert.That(streamService.Object, Is.SameAs(result[0]));
            }
        }

        [Test]
        public void ShouldClearSubscriptions_And_DisposePriceStreamServices_When_Dispose()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var oldPriceCurve = new PriceCurveBuilder().Build();

            var streamService = new MockLivePriceStreamServiceBuilder().WithLinkedCurve(linkedCurve)
                                                                       .WithPriceCurveSnapshot(oldPriceCurve)
                                                                       .Build();

            var priceCurve = new Subject<PriceCurve>();

            var testObjects = new LivePriceStreamSubscriptionServiceTestObjectBuilder().WithLivePriceStreamService(streamService.Object)
                                                                                       .WithPriceCurveSubject(101, priceCurve)
                                                                                       .Build();

            var filterItem = new PriceCurveDetails(PriceCurveType.Live, linkedCurve, 2);

            var filter = new List<PriceCurveDetails>
                         {
                             filterItem
                         };

            testObjects.LivePriceStreamSubscriptionService.RefreshPriceStreams(filter, true);

            // ACT
            testObjects.LivePriceStreamSubscriptionService.Dispose();

            // ASSERT
            streamService.Verify(s => s.Dispose());

            Mock.Get(testObjects.PriceCurveService)
                .Verify(p => p.UnsubscribeFromPriceCurves(It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 101)));
        }
    }
}
