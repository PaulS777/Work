﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.PriceStream.LivePrice
{
    public interface ILivePriceStreamReadyServiceTestObjects
    {
        TestScheduler TestScheduler { get; }
        LivePriceStreamReadyService LivePriceStreamReadyService { get; }
    }

    [TestFixture]
    public class LivePriceStreamReadyServiceTests
    {
        private class LivePriceStreamReadyServiceTestObjectBuilder
        {
            public ILivePriceStreamReadyServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceStreamReadyServiceTestObjects>();

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(testScheduler);

                var service = new LivePriceStreamReadyService(schedulerProvider.Object,
                                                              TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.LivePriceStreamReadyService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishAndComplete_When_Subscribe_With_NoStreams()
        {
            var testObjects = new LivePriceStreamReadyServiceTestObjectBuilder().Build();

            var observable = testObjects.LivePriceStreamReadyService.LivePriceStreamsReady([]);

            var next = false;
            var completed = false;

            // ACT
            using (observable.Subscribe(_ => next = true, () => completed = true))
            {
                // ASSERT
                Assert.That(next, Is.True);
                Assert.That(completed, Is.True);
            }
        }

        [Test]
        public void ShouldNotPublish_When_Subscribe_With_Any_PriceCurve_Null()
        {
            var priceCurve1 = new BehaviorSubject<PriceCurve>(Mock.Of<PriceCurve>());

            var stream1 = Mock.Of<ILivePriceStreamService>(s => s.PriceCurve == priceCurve1);

            var priceCurve2 = new BehaviorSubject<PriceCurve>(null);

            var stream2 = Mock.Of<ILivePriceStreamService>(s => s.PriceCurve == priceCurve2);

            var streams = new List<ILivePriceStreamService>
            {
                stream1, stream2
            };

            var testObjects = new LivePriceStreamReadyServiceTestObjectBuilder().Build();

            var observable = testObjects.LivePriceStreamReadyService.LivePriceStreamsReady(streams);

            var result = false;

            // ACT
            using (observable.Subscribe(_ => result = true))
            {
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishAndComplete_On_PriceCurve_With_All_Curves_NotNull()
        {
            var priceCurve1 = new BehaviorSubject<PriceCurve>(Mock.Of<PriceCurve>());

            var stream1 = Mock.Of<ILivePriceStreamService>(s => s.PriceCurve == priceCurve1);

            var priceCurve2 = new BehaviorSubject<PriceCurve>(null);

            var stream2 = Mock.Of<ILivePriceStreamService>(s => s.PriceCurve == priceCurve2);

            var streams = new List<ILivePriceStreamService>
                          {
                              stream1, stream2
                          };

            var testObjects = new LivePriceStreamReadyServiceTestObjectBuilder().Build();

            var observable = testObjects.LivePriceStreamReadyService.LivePriceStreamsReady(streams);

            var next = false;
            var completed = false;

            using (observable.Subscribe(_ => next = true, () => completed = true))
            {
                // ACT
                priceCurve2.OnNext(Mock.Of<PriceCurve>());

                // ASSERT
                Assert.That(next, Is.True);
                Assert.That(completed, Is.True);
            }
        }

        [Test]
        public void ShouldPublishAndComplete_OnTimeout_With_Any_PriceCurve_Null()
        {
            var priceCurve1 = new BehaviorSubject<PriceCurve>(Mock.Of<PriceCurve>());

            var stream1 = Mock.Of<ILivePriceStreamService>(s => s.PriceCurve == priceCurve1);

            var priceCurve2 = new BehaviorSubject<PriceCurve>(null);

            var stream2 = Mock.Of<ILivePriceStreamService>(s => s.PriceCurve == priceCurve2);

            var streams = new List<ILivePriceStreamService>
                          {
                              stream1, stream2
                          };

            var testObjects = new LivePriceStreamReadyServiceTestObjectBuilder().Build();

            var observable = testObjects.LivePriceStreamReadyService.LivePriceStreamsReady(streams);

            var next = false;
            var completed = false;

            using (observable.Subscribe(_ => next = true, () => completed = true))
            {
                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(6).Ticks);

                // ASSERT
                Assert.That(next, Is.True);
                Assert.That(completed, Is.True);
            }
        }

        [Test]
        public void ShouldPublishError_On_PriceCurveError()
        {
            var priceCurve1 = new BehaviorSubject<PriceCurve>(Mock.Of<PriceCurve>());

            var stream1 = Mock.Of<ILivePriceStreamService>(s => s.PriceCurve == priceCurve1);

            var priceCurve2 = new BehaviorSubject<PriceCurve>(null);

            var stream2 = Mock.Of<ILivePriceStreamService>(s => s.PriceCurve == priceCurve2);

            var streams = new List<ILivePriceStreamService>
                          {
                              stream1, stream2
                          };

            var testObjects = new LivePriceStreamReadyServiceTestObjectBuilder().Build();

            var observable = testObjects.LivePriceStreamReadyService.LivePriceStreamsReady(streams);

            Exception error = null;

            using (observable.Subscribe(_ => {}, ex => error = ex))
            {
                // ACT
                priceCurve2.OnError(new Exception());

                // ASSERT
                Assert.That(error,Is.Not.Null);
            }
        }
    }
}
