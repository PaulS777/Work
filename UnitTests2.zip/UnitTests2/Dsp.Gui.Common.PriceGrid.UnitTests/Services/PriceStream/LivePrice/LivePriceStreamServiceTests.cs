﻿using System;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.PriceStream.LivePrice
{
    public interface ILivePriceStreamServiceTestObjects
    {
        ISubject<PriceCurve> PriceCurve { get; }
        TestScheduler TestScheduler { get; }
        LivePriceStreamService LivePriceStreamService { get; }
    }

    [TestFixture]
    public class LivePriceStreamServiceTests
    {
        private class LivePriceStreamServiceTestObjectBuilder
        {
            private PriceCurveDetails _details;

            public LivePriceStreamServiceTestObjectBuilder WithDefaultDetails()
            {
                _details = new PriceCurveDetails(PriceCurveType.Live, new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),  2);
                return this;
            }

            public ILivePriceStreamServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceStreamServiceTestObjects>();

                var priceCurve = new BehaviorSubject<PriceCurve>(null);

                testObjects.SetupGet(o => o.PriceCurve)
                           .Returns(priceCurve);

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.Dispatcher)
                                 .Returns(Scheduler.Immediate);

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(testScheduler);

                schedulerProvider.SetupGet(p => p.Immediate)
                                 .Returns(Scheduler.Immediate);

                var service = new LivePriceStreamService(schedulerProvider.Object);

                if (_details != null)
                {
                    service.SetDetails(_details);
                }

                testObjects.SetupGet(o => o.LivePriceStreamService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetDetails()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var details = new PriceCurveDetails(PriceCurveType.Live, linkedCurve, 4);

            var testObjects = new LivePriceStreamServiceTestObjectBuilder().Build();

            testObjects.LivePriceStreamService.SetDetails(details);

            // ACT
            var result = testObjects.LivePriceStreamService.GetDetails();

            // ASSERT
            Assert.That(result.LinkedCurve, Is.EqualTo(linkedCurve));
            Assert.That(result.Precision, Is.EqualTo(4));
        }

        [Test]
        public void ShouldPublishPriceCurve_And_SetSnapshot_On_FirstPriceCurve()
        {
            var priceCurve = new PriceCurveBuilder().Build();

            var testObjects = new LivePriceStreamServiceTestObjectBuilder().WithDefaultDetails()
                                                                           .Build();

            var tickInterval = TimeSpan.FromMilliseconds(1000).Ticks;


            testObjects.LivePriceStreamService.Initialize(testObjects.PriceCurve);

            PriceCurve result = null;

            using (testObjects.LivePriceStreamService.PriceCurve
                              .Subscribe(pc => result = pc))
            {
                // ACT
                testObjects.PriceCurve.OnNext(priceCurve);
                testObjects.TestScheduler.AdvanceBy(tickInterval);

                // ASSERT
                Assert.That(result, Is.SameAs(priceCurve));
                Assert.That(testObjects.LivePriceStreamService.PriceCurveSnapshot, Is.SameAs(priceCurve));
            }
        }

        [Test]
        public void ShouldPublishPriceCurve_On_Subscribe_Multiple()
        {
            var priceCurve = new PriceCurveBuilder().Build();

            var testObjects = new LivePriceStreamServiceTestObjectBuilder().WithDefaultDetails()
                                                                           .Build();

            var tickInterval = TimeSpan.FromMilliseconds(1000).Ticks;


            testObjects.LivePriceStreamService.Initialize(testObjects.PriceCurve);

            PriceCurve result1 = null;
            PriceCurve result2 = null;

            testObjects.PriceCurve.OnNext(priceCurve);
            testObjects.TestScheduler.AdvanceBy(tickInterval);

            var disposable1 = testObjects.LivePriceStreamService.PriceCurve
                                         .Subscribe(pc => result1 = pc);

            var disposable2 = testObjects.LivePriceStreamService.PriceCurve
                                         .Subscribe(pc => result2 = pc);

            testObjects.PriceCurve.OnNext(priceCurve);
            testObjects.TestScheduler.AdvanceBy(tickInterval);

            Assert.That(result1, Is.Not.Null);
            Assert.That(result2, Is.Not.Null);

            disposable1.Dispose();
            disposable2.Dispose();
        }

        [Test]
        public void ShouldPublishPriceCurve_And_UpdateSnapshot_On_NextPriceCurve()
        {
            var snapshot = new PriceCurveBuilder().Build();

            var update = new PriceCurveBuilder().Build();

            var testObjects = new LivePriceStreamServiceTestObjectBuilder().WithDefaultDetails()
                                                                           .Build();

            var tickInterval = TimeSpan.FromMilliseconds(1010).Ticks;

            PriceCurve result = null;

            testObjects.LivePriceStreamService.Initialize(testObjects.PriceCurve);

            using (testObjects.LivePriceStreamService.PriceCurve
                              .Subscribe(c => result = c))
            {
                testObjects.PriceCurve.OnNext(snapshot);

                // ACT
                testObjects.PriceCurve.OnNext(update);
                testObjects.TestScheduler.AdvanceBy(tickInterval);

                // ASSERT
                Assert.That(result, Is.SameAs(update));
                Assert.That(testObjects.LivePriceStreamService.PriceCurveSnapshot, Is.SameAs(update));
            }
        }

        [Test]
        public void ShouldThrottlePriceCurveUpdates()
        {
            var snapshot = new PriceCurveBuilder().Build();

            var update1 = new PriceCurveBuilder().Build();
            var update2 = new PriceCurveBuilder().Build();
            var update3 = new PriceCurveBuilder().Build();
            var update4 = new PriceCurveBuilder().Build();

            var testObjects = new LivePriceStreamServiceTestObjectBuilder().WithDefaultDetails()
                                                                           .Build();

            var tickInterval = TimeSpan.FromMilliseconds(1010).Ticks;

            PriceCurve result = null;
            var updates = 0;

            testObjects.LivePriceStreamService.Initialize(testObjects.PriceCurve);

            using (testObjects.LivePriceStreamService.PriceCurve
                              .Where(pc => pc != null)
                              .Subscribe(c =>
                              {
                                  result = c;
                                  updates++;
                              }))
            {

                testObjects.PriceCurve.OnNext(snapshot);

                // ACT
                testObjects.PriceCurve.OnNext(update1);
                testObjects.PriceCurve.OnNext(update2);

                testObjects.TestScheduler.AdvanceBy(tickInterval);

                testObjects.PriceCurve.OnNext(update3);
                testObjects.PriceCurve.OnNext(update4);

                testObjects.TestScheduler.AdvanceBy(tickInterval);
                testObjects.TestScheduler.AdvanceBy(tickInterval);

                // ASSERT
                Assert.IsNotNull(result);
                Assert.That(result, Is.SameAs(update4));
                Assert.That(updates, Is.EqualTo(3));
            }
        }
    }
}
