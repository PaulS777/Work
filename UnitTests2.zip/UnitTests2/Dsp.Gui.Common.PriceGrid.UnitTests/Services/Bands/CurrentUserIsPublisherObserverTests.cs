﻿using System;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Bands
{
    public interface ICurrentUserIsPublisherObserverTestObjects
    {
        ISubject<User> CurrentUser { get; }
        IPriceCurveSettingObserver PriceCurveSettingObserver { get; }
        ISubject<PriceCurveSetting> PriceCurveSetting { get; }
        CurrentUserIsPublisherObserver CurrentUserIsPublisherObserver { get; }
    }

    [TestFixture]
    public class CurrentUserIsPublisherObserverTests
    {
        private class CurrentUserIsPublisherObserverTestObjectBuilder
        {
            private User _currentUser;

            public CurrentUserIsPublisherObserverTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

            public ICurrentUserIsPublisherObserverTestObjects Build()
            {
                var testObjects = new Mock<ICurrentUserIsPublisherObserverTestObjects>();

                var currentUser = new BehaviorSubject<User>(_currentUser);

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(currentUser);

                var priceCurveSetting = new Subject<PriceCurveSetting>();

                testObjects.SetupGet(o => o.PriceCurveSetting)
                           .Returns(priceCurveSetting);

                var priceCurveSettingObserver = new Mock<IPriceCurveSettingObserver>();

                priceCurveSettingObserver.Setup(p => p.Observe(It.IsAny<int>()))
                                         .Returns(priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSettingObserver)
                           .Returns(priceCurveSettingObserver.Object);

                var currentUserIsPublisherObserver = new CurrentUserIsPublisherObserver(curveControlService.Object,
                                                                                        priceCurveSettingObserver.Object);

                testObjects.SetupGet(o => o.CurrentUserIsPublisherObserver)
                           .Returns(currentUserIsPublisherObserver);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishTrue_When_CurveSettingPublisherId_Matches_CurrentUserId()
        {
            var userId = 10;
            var user = new UserBuilder().WithId(userId).User();

            var testObjects = new CurrentUserIsPublisherObserverTestObjectBuilder().WithCurrentUser(user).Build();

            bool? result = null;

            using (testObjects.CurrentUserIsPublisherObserver.Observe(101).Subscribe(value => result = value))
            {
                var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                      .WithPublisherId(userId)
                                                                      .Build();

                // ACT
                testObjects.PriceCurveSetting.OnNext(setting);

                // ASSERT
                Mock.Get(testObjects.PriceCurveSettingObserver)
                    .Verify(obs => obs.Observe(101));

                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_CurveSettingPublisherId_DoesNotMatch_CurrentUserId()
        {
            var userId = 10;
            var user = new UserBuilder().WithId(userId).User();

            var testObjects = new CurrentUserIsPublisherObserverTestObjectBuilder().WithCurrentUser(user).Build();

            bool? result = null;

            using (testObjects.CurrentUserIsPublisherObserver.Observe(101).Subscribe(value => result = value))
            {
                var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                      .WithPublisherId(11)
                                                                      .Build();

                // ACT
                testObjects.PriceCurveSetting.OnNext(setting);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
