﻿using System;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.ManualCurve;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Bands
{
    internal interface ICurveEditRegistrationServiceTestObjects
    {
        ICurveEditLookupMonitor CurveEditLookupMonitor { get; }
        CurveEditSource CurveEditSource { get; }
        ICanUndoChanges ViewModel { get; }
        CurveEditRegistrationService CurveEditRegistrationService { get; }
    }

    [TestFixture]
    public class CurveEditRegistrationServiceTests
    {
        private class CurveEditRegistrationServiceTestObjectBuilder
        {
            private bool _canUndoOverrides;

            public CurveEditRegistrationServiceTestObjectBuilder WithCanUndoOverrides(bool value)
            {
                _canUndoOverrides = value;
                return this;
            }

            public ICurveEditRegistrationServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveEditRegistrationServiceTestObjects>();

                var viewModel = new Mock<ICanUndoChanges>();

                viewModel.SetupGet(vm => vm.CanUndoChanges)
                         .Returns(_canUndoOverrides);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(viewModel.Object);

                var curveEditLookupMonitor = new Mock<ICurveEditLookupMonitor>();

                testObjects.SetupGet(o => o.CurveEditLookupMonitor)
                           .Returns(curveEditLookupMonitor.Object);

                var curveEditSource = new CurveEditSource();

                testObjects.SetupGet(o => o.CurveEditSource)
                           .Returns(curveEditSource);

                var curveEditRegistrationService = new CurveEditRegistrationService(curveEditLookupMonitor.Object, 
                                                                                    curveEditSource);
                
                testObjects.SetupGet(o => o.CurveEditRegistrationService)
                           .Returns(curveEditRegistrationService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldRegisterCurveEditSource_When_RegisterCurve()
        {
            var testObjects = new CurveEditRegistrationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.CurveEditRegistrationService.RegisterCurve(testObjects.ViewModel, 201);

            // ASSERT
            Mock.Get(testObjects.CurveEditLookupMonitor)
                .Verify(m => m.RegisterCurveEditSource(201, testObjects.CurveEditSource));
        }

        [Test]
        public void ShouldSetCurveEditSource_PublishFalse_With_CanUndoChanges_False()
        {
            var testObjects = new CurveEditRegistrationServiceTestObjectBuilder().WithCanUndoOverrides(false)
                                                                                 .Build();

            testObjects.CurveEditRegistrationService.RegisterCurve(testObjects.ViewModel, 201);

            bool? result = null;

            // ACT
            using (testObjects.CurveEditSource.ManualCurveChanged.Subscribe(value => result = value))
            {
                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldSetCurveEditSource_PublishTrue_On_CanUndoChanges_True()
        {
            var testObjects = new CurveEditRegistrationServiceTestObjectBuilder().WithCanUndoOverrides(false)
                                                                                 .Build();

            testObjects.CurveEditRegistrationService.RegisterCurve(testObjects.ViewModel, 201);

            bool? result = null;

            using (testObjects.CurveEditSource.ManualCurveChanged.Subscribe(value => result = value))
            {
                // ACT
                Mock.Get(testObjects.ViewModel).NotifyPropertyChanged(vm => vm.CanUndoChanges, true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldUnregisterCurveEditSource_When_UnregisterCurve()
        {
            var testObjects = new CurveEditRegistrationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.CurveEditRegistrationService.UnRegisterCurve(201);

            // ASSERT
            Mock.Get(testObjects.CurveEditLookupMonitor)
                .Verify(m => m.UnRegisterCurveEditSource(201, testObjects.CurveEditSource));
        }
    }
}
