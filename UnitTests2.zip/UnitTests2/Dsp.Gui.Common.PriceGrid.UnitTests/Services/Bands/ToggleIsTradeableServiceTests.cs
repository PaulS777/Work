﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.AdminActions;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Bands
{
    public interface IToggleIsTradeableServiceTestObjects
    {
        ISetCurvePublishingControlsActionService SetCurvePublishingControlsService { get; }
        ISubject<AdminApiActionCompleted> SetCurvePublishingControlsResponse { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        ToggleIsTradeableService ToggleIsTradeableService { get; }
    }

    [TestFixture]
    public class ToggleIsTradeableServiceTests
    {
        private class LivePriceToggleIsTradeableServiceTestObjectBuilder
        {
            public IToggleIsTradeableServiceTestObjects Build()
            {
                var testObjects = new Mock<IToggleIsTradeableServiceTestObjects>();

                var setCurvePublishingControlsResponse = new Subject<AdminApiActionCompleted>();

                testObjects.SetupGet(o => o.SetCurvePublishingControlsResponse)
                           .Returns(setCurvePublishingControlsResponse);

                var setCurvePublishingControlsService = new Mock<ISetCurvePublishingControlsActionService>();

                setCurvePublishingControlsService.Setup(o => o.Update(It.IsAny<IList<SetCurvePublishingControls>>(), 
                                                                      It.IsAny<IScheduler>()))
                                                 .Returns(setCurvePublishingControlsResponse);

                testObjects.SetupGet(o => o.SetCurvePublishingControlsService)
                           .Returns(setCurvePublishingControlsService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var toggleIsTradeableService = new ToggleIsTradeableService(TestMocks.GetSchedulerProvider().Object,
                                                                            TestMocks.GetLoggerFactory().Object)
                {
                    SetCurvePublishingControlsService = setCurvePublishingControlsService.Object,
                    PopupNotificationService = popupNotificationService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object
                };

                testObjects.SetupGet(o => o.ToggleIsTradeableService)
                           .Returns(toggleIsTradeableService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetCurvePublishingControls_On_ToggleIsTradeable()
        {
            var curveSetting = new PriceCurveSetting(101, 10, true, false, true, true, null);

            var mockToggle = new Mock<IToggleIsTradeable>();

            mockToggle.SetupGet(t => t.LinkedCurveId).Returns(101);
            mockToggle.Setup(t => t.PriceCurveSetting()).Returns(curveSetting);

            var testObjects = new LivePriceToggleIsTradeableServiceTestObjectBuilder().Build();

            testObjects.ToggleIsTradeableService.Attach(mockToggle.Object);
            testObjects.ToggleIsTradeableService.SubscribeUpdates();

            var expected = new[] { new SetCurvePublishingControls(ActionTargetType.PriceCurve, 101, true, true, true) };

            // ACT
            mockToggle.NotifyPropertyChanged(m => m.IsTradeable, true);

            // ASSERT
            Mock.Get(testObjects.SetCurvePublishingControlsService)
                .Verify(p => p.Update(It.Is<IList<SetCurvePublishingControls>>(s => s.SequenceEqual(expected, new SetCurvePublishingControlsComparer())),
                                      It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldSendPopupNotification_On_SetCurvePublishingControlsActionCompleted()
        {
            var curveSetting = new PriceCurveSetting(101, 10, true, false, false, true, null);

            var mockToggle = new Mock<IToggleIsTradeable>();

            mockToggle.SetupGet(t => t.LinkedCurveId).Returns(101);
            mockToggle.Setup(t => t.PriceCurveSetting()).Returns(curveSetting);

            var testObjects = new LivePriceToggleIsTradeableServiceTestObjectBuilder().Build();

            testObjects.ToggleIsTradeableService.Attach(mockToggle.Object);
            testObjects.ToggleIsTradeableService.SubscribeUpdates();

            // ACT
            mockToggle.NotifyPropertyChanged(m => m.IsTradeable, true);

            // ACT
            testObjects.SetCurvePublishingControlsResponse.OnNext(new AdminApiActionCompleted());

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldShowErrorDialog_And_ResetToggle_On_SetCurvePublishingControlsError()
        {
            var curveSetting = new PriceCurveSetting(101, 10, true, false, false,false, null);

            var mockToggle = new Mock<IToggleIsTradeable>();

            mockToggle.SetupGet(t => t.LinkedCurveId).Returns(101);
            mockToggle.Setup(t => t.PriceCurveSetting()).Returns(curveSetting);

            var testObjects = new LivePriceToggleIsTradeableServiceTestObjectBuilder().Build();

            testObjects.ToggleIsTradeableService.Attach(mockToggle.Object);
            testObjects.ToggleIsTradeableService.SubscribeUpdates();

            // ACT
            mockToggle.NotifyPropertyChanged(m => m.IsTradeable, true);

            // ACT
            testObjects.SetCurvePublishingControlsResponse.OnError(new Exception());

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Header == "Curve Settings Update Error"
                                                                                && args.ShowSendFeedback)));

            mockToggle.VerifySet(m => m.IsTradeable = false);
            mockToggle.VerifySet(m => m.CanEditIsTradeable = true);
        }
    }
}
