﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;


namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Bands
{
    public interface IPriceCurveSettingObserverTestObjects
    {
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        PriceCurveSettingObserver PriceCurveSettingObserver { get; }
    }

    [TestFixture]
    public class PriceCurveSettingObserverTests
    {
        private class PriceCurveSettingsFilterTestObjectBuilder
        {
            public IPriceCurveSettingObserverTestObjects Build()
            {
                var testObjects = new Mock<IPriceCurveSettingObserverTestObjects>();

                var curveSettings = new Subject<Dictionary<int, PriceCurveSetting>>();

                testObjects.SetupGet(o => o.PriceCurveSettings)
                           .Returns(curveSettings);

                var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();

                priceCurveSettingsProvider.SetupGet(p => p.PriceCurveSettings)
                                          .Returns(curveSettings);

                var priceCurveSettingObserver = new PriceCurveSettingObserver(priceCurveSettingsProvider.Object);

                testObjects.SetupGet(o => o.PriceCurveSettingObserver)
                           .Returns(priceCurveSettingObserver);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishPriceCurveSetting_When_CurveIdEqual()
        {
            var testObjects = new PriceCurveSettingsFilterTestObjectBuilder().Build();

            var curveSettings = new Dictionary<int, PriceCurveSetting>
                                {
                                    {
                                        101,
                                        new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build()
                                    }
                                };

            PriceCurveSetting result = null;

            using (testObjects.PriceCurveSettingObserver.Observe(101).Subscribe(s => result = s))
            {
                // ACT
                testObjects.PriceCurveSettings.OnNext(curveSettings);

                // ASSERT
                Assert.That(result is { PriceCurveDefinitionId: 101 });
            }
        }


        [Test]
        public void ShouldPublishNull_When_CurveIdNotEqual()
        {
            var testObjects = new PriceCurveSettingsFilterTestObjectBuilder().Build();

            var curveSettings = new Dictionary<int, PriceCurveSetting>
                                {
                                    {
                                        99,
                                        new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(99).Build()
                                    }
                                };

            PriceCurveSetting result = null;

            using (testObjects.PriceCurveSettingObserver.Observe(101).Subscribe(s => result = s))
            {
                // ACT
                testObjects.PriceCurveSettings.OnNext(curveSettings);

                // ASSERT
                Assert.IsNull(result);
            }
        }
    }
}
