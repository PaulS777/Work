﻿using System.Collections.Generic;
using Dsp.Gui.Common.PriceGrid.Services.Commands;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.PriceGrid.UnitTests.Services.Commands
{
    [TestFixture]
    public class CellGroupingServiceTests
    {
        [Test]
        public void ShouldClearExisting_And_SetParent_When_UpdateParent()
        {
            var cell1 = Mock.Of<IGroupedCell>(c => c.IsSelected && c.IsChild);
            var cell2 = Mock.Of<IGroupedCell>(c => c.IsParent);

            var cells = new List<IGroupedCell>
                        {
                            cell1, cell2
                        };

            var service = new CellGroupingService<IGroupedCell>();

            // ACT
            service.UpdateParent(cells);

            // ASSERT
            Assert.That(cell1.IsParent, Is.True);
            Assert.That(cell1.IsChild, Is.False);
            Assert.That(cell1.CellBorderType, Is.EqualTo(GroupedCellBorderType.Parent));

            Assert.That(cell2.IsParent, Is.False);
            Assert.That(cell2.IsChild, Is.False);
            Assert.That(cell2.CellBorderType, Is.EqualTo(GroupedCellBorderType.None));
        }

        [Test]
        public void ShouldKeepExistingChildren_When_UpdateParent()
        {
            var cell1 = Mock.Of<IGroupedCell>(c => c.IsSelected);
            var cell2 = Mock.Of<IGroupedCell>(c => c.IsChild && c.CellBorderType == GroupedCellBorderType.Child);

            var cells = new List<IGroupedCell>
                        {
                            cell1, cell2
                        };

            var service = new CellGroupingService<IGroupedCell>();

            // ACT
            service.UpdateParent(cells);

            // ASSERT
            Assert.That(cell2.IsChild, Is.True);
            Assert.That(cell2.CellBorderType, Is.EqualTo(GroupedCellBorderType.Child));
        }

        [Test]
        public void ShouldClearGroupings_When_UpdateParent_With_MultipleSelected()
        {
            var cell1 = Mock.Of<IGroupedCell>(c => c.IsSelected);
            var cell2 = Mock.Of<IGroupedCell>(c => c.IsSelected && c.IsParent && c.CellBorderType == GroupedCellBorderType.Parent);

            var cells = new List<IGroupedCell>
                        {
                            cell1, cell2
                        };

            var service = new CellGroupingService<IGroupedCell>();

            // ACT
            service.UpdateParent(cells);

            // ASSERT
            Assert.That(cell1.IsParent, Is.False);
            Assert.That(cell1.CellBorderType, Is.EqualTo(GroupedCellBorderType.None));

            Assert.That(cell2.IsParent, Is.False);
            Assert.That(cell2.CellBorderType, Is.EqualTo(GroupedCellBorderType.None));
        }

        [Test]
        public void ShouldClearGroupings_And_SetChildren_When_UpdateChildren()
        {
            var cell1 = Mock.Of<IGroupedCell>(c => c.IsChild && c.CellBorderType == GroupedCellBorderType.Child);
            var cell2 = Mock.Of<IGroupedCell>(c => c.IsParent && c.CellBorderType == GroupedCellBorderType.Parent);
            var cell3 = Mock.Of<IGroupedCell>(c => c.IsSelected && c.CellBorderType == GroupedCellBorderType.None);

            var cells = new List<IGroupedCell>
                        {
                            cell1, cell2, cell3
                        };

            var service = new CellGroupingService<IGroupedCell>();

            // ACT
            var result = service.UpdateChildren(cells);

            // ASSERT
            Assert.That(cell1.IsChild, Is.False);
            Assert.That(cell1.CellBorderType, Is.EqualTo(GroupedCellBorderType.None));

            Assert.That(cell2.IsParent, Is.True);
            Assert.That(cell2.CellBorderType, Is.EqualTo(GroupedCellBorderType.Parent));

            Assert.That(cell3.IsChild, Is.True);
            Assert.That(cell3.CellBorderType, Is.EqualTo(GroupedCellBorderType.Child));

            Assert.That(result.Count, Is.EqualTo(1));
            Assert.That(result[0], Is.SameAs(cell3));
        }

        [Test]
        public void ShouldClearGroupings_And_SetChildren_When_UpdateChildrenBelowParent()
        {
            var cell1 = Mock.Of<IGroupedCell>(c => c.IsChild && c.CellBorderType == GroupedCellBorderType.Child);
            var cell2 = Mock.Of<IGroupedCell>(c => c.IsParent && c.CellBorderType == GroupedCellBorderType.Parent);
            var cell3 = Mock.Of<IGroupedCell>(c => c.CellBorderType == GroupedCellBorderType.None);
            var cell4 = Mock.Of<IGroupedCell>(c => c.CellBorderType == GroupedCellBorderType.None);

            var cells = new List<IGroupedCell>
                        {
                            cell1, cell2, cell3, cell4
                        };

            var service = new CellGroupingService<IGroupedCell>();

            // ACT
            var result = service.UpdateChildrenBelowParent(cells);

            // ASSERT
            Assert.That(cell1.IsChild, Is.False);
            Assert.That(cell1.CellBorderType, Is.EqualTo(GroupedCellBorderType.None));

            Assert.That(cell2.IsParent, Is.True);

            Assert.That(cell3.IsChild, Is.True);
            Assert.That(cell3.CellBorderType, Is.EqualTo(GroupedCellBorderType.Child));

            Assert.That(cell4.IsChild, Is.True);
            Assert.That(cell4.CellBorderType, Is.EqualTo(GroupedCellBorderType.Child));

            Assert.That(result.Count, Is.EqualTo(2));
            Assert.That(result[0], Is.SameAs(cell3));
            Assert.That(result[1], Is.SameAs(cell4));
        }

        [Test]
        public void ShouldClearGroupings_And_SetChildren_When_UpdateChildrenBelowParent_With_Parent()
        {
            var cell1 = Mock.Of<IGroupedCell>(c => c.IsChild && c.CellBorderType == GroupedCellBorderType.Child);
            var cell2 = Mock.Of<IGroupedCell>(c => c.IsParent && c.CellBorderType == GroupedCellBorderType.Parent);
            var cell3 = Mock.Of<IGroupedCell>(c => c.CellBorderType == GroupedCellBorderType.None);
            var cell4 = Mock.Of<IGroupedCell>(c => c.CellBorderType == GroupedCellBorderType.None);

            var cells = new List<IGroupedCell>
                        {
                            cell1, cell2, cell3, cell4
                        };

            var service = new CellGroupingService<IGroupedCell>();

            // ACT
            var result = service.UpdateChildrenBelowParent(cell2, cells);

            // ASSERT
            Assert.That(cell1.IsChild, Is.False);
            Assert.That(cell1.CellBorderType, Is.EqualTo(GroupedCellBorderType.None));

            Assert.That(cell2.IsParent, Is.True);

            Assert.That(cell3.IsChild, Is.True);
            Assert.That(cell3.CellBorderType, Is.EqualTo(GroupedCellBorderType.Child));

            Assert.That(cell4.IsChild, Is.True);
            Assert.That(cell4.CellBorderType, Is.EqualTo(GroupedCellBorderType.Child));

            Assert.That(result.Count, Is.EqualTo(2));
            Assert.That(result[0], Is.SameAs(cell3));
            Assert.That(result[1], Is.SameAs(cell4));
        }


        [Test]
        public void ShouldNotSetChildren_When_UpdateChildrenBelowParent_With_MissingParent()
        {
            var cell1 = Mock.Of<IGroupedCell>(c => c.CellBorderType == GroupedCellBorderType.None);
            var cell2 = Mock.Of<IGroupedCell>(c => c.CellBorderType == GroupedCellBorderType.None);

            var cells = new List<IGroupedCell>
                        {
                            cell1, cell2
                        };

            var service = new CellGroupingService<IGroupedCell>();

            //// ACT
            service.UpdateChildrenBelowParent(cells);

            // ASSERT
            Assert.That(cell1.IsChild, Is.False);
            Assert.That(cell2.IsChild, Is.False);
        }

        [Test]
        public void ShouldClearGroupings_When_ClearDependencies()
        {
            var cell1 = Mock.Of<IGroupedCell>(c => c.IsParent && c.CellBorderType == GroupedCellBorderType.Parent);
            var cell2 = Mock.Of<IGroupedCell>(c => c.IsChild && c.CellBorderType == GroupedCellBorderType.Child);

            var cells = new List<IGroupedCell>
                        {
                            cell1, cell2
                        };

            var service = new CellGroupingService<IGroupedCell>();

            // ACT
            service.ClearDependencies(cells);

            // ASSERT
            Assert.That(cell1.IsParent, Is.False);
            Assert.That(cell1.CellBorderType, Is.EqualTo(GroupedCellBorderType.None));

            Assert.That(cell2.IsChild, Is.False);
            Assert.That(cell1.CellBorderType, Is.EqualTo(GroupedCellBorderType.None));
        }
    }
}
