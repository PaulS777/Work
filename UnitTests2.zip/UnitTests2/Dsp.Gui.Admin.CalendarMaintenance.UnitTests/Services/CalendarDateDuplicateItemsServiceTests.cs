﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Services
{
    [TestFixture]
    public class CalendarDateDuplicateItemsServiceTests
    {
        [Test]
        public void ShouldSetIsDuplicateTrue_When_MatchingCodes()
        {
            var date = new DateTime(2021, 1, 1);    

            var row1 = new CalendarDateItemViewModel(Mock.Of<IDisposable>()) { Date = date };
            var row2 = new CalendarDateItemViewModel(Mock.Of<IDisposable>());

            var rows = new List<CalendarDateItemViewModel> { row1, row2 };

            var service = new CalendarDateDuplicateItemsService();

            service.RefreshItems(rows);

            // ACT
            row2.Date = date;

            // ASSERT
            Assert.That(row1.IsDuplicate, Is.True);
            Assert.That(row2.IsDuplicate, Is.True);
        }
    }
}
