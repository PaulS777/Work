﻿using Dsp.Gui.Admin.CalendarMaintenance.Rules;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Services
{
    [TestFixture]
    public class CalendarDateItemValidationServiceTests
    {
        [Test]
        public void ShouldReturnIsDuplicateText()
        {
            var rule = new Mock<ICalendarDateRule>();

            var service = new CalendarDateItemValidationService(rule.Object);

            // ACT
            var result = service.IsDuplicateText();

            // ASSERT
            Assert.That(result, Is.EqualTo("Duplicate Date"));
        }
    }
}
