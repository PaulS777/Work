﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Services
{
    [TestFixture]
    internal class CalendarBuilderTests
    {
        [Test]
        public void ShouldGetCalendar_From_ViewModel()
        {
            var date1 = new DateTime(2021, 1, 1);
            var date2 = new DateTime(2021, 1, 2);
            var date3 = new DateTime(2021, 1, 3);

            var calendar = new Calendar(1, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false, new List<DateTime>
            {
                date1, date2
            });

            var viewModel = new CalendarViewModel(Mock.Of<IDisposable>());

            viewModel.SetCalendar(calendar);

            viewModel.CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>
            {
                new(Mock.Of<IDisposable>()) {Date = date1},
                new(Mock.Of<IDisposable>()) {Date = date2, IsDeleted = true},
                new(Mock.Of<IDisposable>()) {Date = date3},
                new(Mock.Of<IDisposable>()) {Date = null}
            };

            var builder = new CalendarBuilder();

            // ACT
            var result = builder.GetCalendar(viewModel);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(1));
            Assert.That(result.Status, Is.EqualTo(EntityStatus.Active));
            Assert.That(result.Code, Is.EqualTo("code"));
            Assert.That(result.Description, Is.EqualTo("desc"));
            Assert.That(result.Holidays.Count, Is.EqualTo(2));
            Assert.That(result.Holidays[0], Is.EqualTo(date1));
            Assert.That(result.Holidays[1], Is.EqualTo(date3));
        }
    }
}
