﻿using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Services
{
    [TestFixture]
    public class CalendarDateItemsCollectionServiceTests
    {
        [Test]
        public void ShouldDisposeDuplicationService_OnDispose()
        {
            var duplicationService = new Mock<ICalendarDateDuplicateItemsService>();

            var calendarItemCollectionService = new CalendarDateItemCollectionService(duplicationService.Object);

            calendarItemCollectionService.Dispose();

            duplicationService.Verify(d => d.Dispose());
        }
    }
}
