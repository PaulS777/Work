﻿using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Admin.CalendarMaintenance.Controllers;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Services
{
    internal interface ICalendarViewModelBuilderTestObjects
    {
        CalendarViewModelBuilder CalendarViewModelBuilder { get; }
    }

    [TestFixture]
    public class CalendarViewModelBuilderTests
    {
        private class CalendarViewModelBuilderTestObjectBuilder
        {
            private DateTime _dateNow;

            public CalendarViewModelBuilderTestObjectBuilder WithDateNow(DateTime value)
            {
                _dateNow = value;
                return this;
            }

            public ICalendarViewModelBuilderTestObjects Build()
            {
                var testObjects = new Mock<ICalendarViewModelBuilderTestObjects>();

                var itemCollectionService = new Mock<ICalendarDateItemCollectionService>();

                itemCollectionService.SetupGet(r => r.CanExecuteUpdateCommand)
                                     .Returns(Observable.Empty<bool>());

                itemCollectionService.SetupGet(r => r.CanExecuteUndoCommand)
                                     .Returns(Observable.Empty<bool>());

                itemCollectionService.SetupGet(r => r.ValidationErrors)
                                     .Returns(Observable.Empty<IList<string>>());

                var controller = new CalendarViewModelController(itemCollectionService.Object);

                var item = new CalendarDateItemViewModel(Mock.Of<IDisposable>());

                var itemController = new Mock<ICalendarDateItemViewModelController>();

                itemController.SetupGet(c => c.ViewModel)
                              .Returns(item);

                var calendarFactory = new Mock<IServiceFactory<ICalendarViewModelController>>();

                calendarFactory.Setup(f => f.Create())
                               .Returns(controller);


                var calendarDateFactory = new Mock<IServiceFactory<ICalendarDateItemViewModelController>>();

                calendarDateFactory.Setup(f => f.Create())
                                   .Returns(itemController.Object);

                var currentBusinessDateProvider = new Mock<ICurrentBusinessDateProvider>();

                currentBusinessDateProvider.Setup(p => p.CurrentDate)
                                           .Returns(_dateNow);

                var builder = new CalendarViewModelBuilder(currentBusinessDateProvider.Object)
                              {
                                  CalendarFactory = calendarFactory.Object,
                                  CalendarDateFactory = calendarDateFactory.Object
                              };

                testObjects.SetupGet(o => o.CalendarViewModelBuilder)
                           .Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCreateCalendarViewModel_With_DatesFilteredAfterToday()
        {
            var today = new DateTime(2021, 1, 2);

            var date1 = new DateTime(2021, 1, 1);
            var date2 = new DateTime(2021, 1, 2);

            var calendar = new Calendar(1, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false,
                                                      new List<DateTime>
                                                      {
                                                          date1, date2
                                                      });

            var testObjects = new CalendarViewModelBuilderTestObjectBuilder().WithDateNow(today)
                                                                             .Build();

            // ACT
            var result = testObjects.CalendarViewModelBuilder.CreateCalendar(calendar);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(1));
            Assert.That(result.Description, Is.EqualTo("desc"));

            Assert.AreSame(calendar, result.GetCalendar());

            Assert.That(result.CalendarDateItems.Count, Is.EqualTo(1));
            Assert.That(result.CalendarDateItems[0].Date, Is.EqualTo(date2));
            Assert.That(result.CalendarDateItems[0].OriginalDate, Is.EqualTo(date2));
            Assert.That(result.CalendarDateItems[0].SubscribeUpdates, Is.True);
            Assert.That(result.CalendarDateItems[0].NewRecord, Is.False);
        }

        [Test]
        public void ShouldCreateNewCalendarItem()
        {
            var testObjects = new CalendarViewModelBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.CalendarViewModelBuilder.GetNewCalendarItem();

            // ASSERT
            Assert.That(result.NewRecord, Is.True);
            Assert.IsNull(result.Date);
            Assert.IsNull(result.OriginalDate);
            Assert.That(result.SubscribeUpdates, Is.True);
        }
    }
}
