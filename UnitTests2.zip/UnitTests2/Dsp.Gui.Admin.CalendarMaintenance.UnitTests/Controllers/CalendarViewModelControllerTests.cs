﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reactive.Subjects;
using Dsp.Gui.Admin.CalendarMaintenance.Controllers;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Controllers
{
    internal interface ICalendarViewModelControllerTestObjects
    {
        ICalendarDateItemCollectionService CalendarRowService { get; }
        ISubject<bool> CanExecuteUpdateCommand { get; }
        ISubject<bool> CanExecuteUndoCommand { get; }
        ISubject<IList<string>> ValidationErrors { get; }
        CalendarViewModel ViewModel { get; }
        CalendarViewModelController Controller { get; }
    }

    [TestFixture]
    public class CalendarViewModelControllerTests
    {
        private class CalendarViewModelControllerTestObjectBuilder
        {
            private ObservableCollection<CalendarDateItemViewModel> _calendarRows;

            public CalendarViewModelControllerTestObjectBuilder WithCalendarRows(ObservableCollection<CalendarDateItemViewModel> values)
            {
                _calendarRows = values;
                return this;
            }

            public ICalendarViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<ICalendarViewModelControllerTestObjects>();

                var canExecuteUpdate = new Subject<bool>();

                testObjects.SetupGet(o => o.CanExecuteUpdateCommand)
                           .Returns(canExecuteUpdate);

                var canExecuteUndo = new Subject<bool>();

                testObjects.SetupGet(o => o.CanExecuteUndoCommand)
                           .Returns(canExecuteUndo);

                var validationErrors = new Subject<IList<string>>();

                testObjects.SetupGet(o => o.ValidationErrors)
                           .Returns(validationErrors);

                var rowService = new Mock<ICalendarDateItemCollectionService>();

                rowService.SetupGet(r => r.CanExecuteUpdateCommand)
                          .Returns(canExecuteUpdate);

                rowService.SetupGet(r => r.CanExecuteUndoCommand)
                          .Returns(canExecuteUndo);

                rowService.SetupGet(r => r.ValidationErrors)
                          .Returns(validationErrors);

                testObjects.SetupGet(o => o.CalendarRowService)
                           .Returns(rowService.Object);

                var controller = new CalendarViewModelController(rowService.Object);

                controller.ViewModel.CalendarDateItems = _calendarRows;

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInvokeRowService_On_AddRowCommand()
        {
            var rows = new ObservableCollection<CalendarDateItemViewModel>
            {
                new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            };

            var newRow = new CalendarDateItemViewModel(Mock.Of<IDisposable>());

            var testObjects = new CalendarViewModelControllerTestObjectBuilder().WithCalendarRows(rows)
                                                                                .Build();

            // ACT
            testObjects.ViewModel.AddItemCommand.Execute(newRow);

            // ASSERT
            Mock.Get(testObjects.CalendarRowService)
                .Verify(cs => cs.AddNewItem(newRow, It.Is<ObservableCollection<CalendarDateItemViewModel>>(r => r.Count == 1)));
        }

        [Test]
        public void ShouldInvokeRowService_On_AddRefreshRowsCommand()
        {
            var rows = new ObservableCollection<CalendarDateItemViewModel>
            {
                new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            };

            var testObjects = new CalendarViewModelControllerTestObjectBuilder().WithCalendarRows(rows)
                                                                                .Build();

            // ACT
            testObjects.ViewModel.RefreshItemsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.CalendarRowService)
                .Verify(cs => cs.RefreshItems(It.Is<ObservableCollection<CalendarDateItemViewModel>>(r => r.Count == 1)));
        }

        [Test]
        public void ShouldSetCanExecuteUndoCommand_On_RowService()
        {
            var rows = new ObservableCollection<CalendarDateItemViewModel>
            {
                new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            };

            var testObjects = new CalendarViewModelControllerTestObjectBuilder().WithCalendarRows(rows)
                                                                                .Build();

            // ACT
            testObjects.CanExecuteUndoCommand.OnNext(true);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.CanExecuteUndoCommand);
        }

        [Test]
        public void ShouldSetCanExecuteUpdateCommand_On_RowService()
        {
            var rows = new ObservableCollection<CalendarDateItemViewModel>
            {
                new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            };

            var testObjects = new CalendarViewModelControllerTestObjectBuilder().WithCalendarRows(rows)
                                                                                .Build();

            // ACT
            testObjects.CanExecuteUpdateCommand.OnNext(true);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.CanExecuteUpdateCommand);
        }

        [Test]
        public void ShouldSetValidationErrors_On_RowService()
        {
            var rows = new ObservableCollection<CalendarDateItemViewModel>
            {
                new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            };

            var testObjects = new CalendarViewModelControllerTestObjectBuilder().WithCalendarRows(rows)
                                                                                .Build();

            var errors = new List<string> {"error"};

            // ACT
            testObjects.ValidationErrors.OnNext(errors);

            // ASSERT
            Assert.AreEqual(1, testObjects.ViewModel.ValidationErrors.Count);
        }

        [Test]
        public void ShouldDisposeRowServiceAndCalendarRows_When_Dispose()
        {
            var controller = new Mock<IDisposable>();

            var rows = new ObservableCollection<CalendarDateItemViewModel>
            {
                new CalendarDateItemViewModel(controller.Object)
            };

            var testObjects = new CalendarViewModelControllerTestObjectBuilder().WithCalendarRows(rows)
                                                                                .Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            controller.Verify(c => c.Dispose());

            Mock.Get(testObjects.CalendarRowService)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var controller = new Mock<IDisposable>();

            var rows = new ObservableCollection<CalendarDateItemViewModel>
            {
                new CalendarDateItemViewModel(controller.Object)
            };

            var testObjects = new CalendarViewModelControllerTestObjectBuilder().WithCalendarRows(rows)
                                                                                .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            controller.Verify(c => c.Dispose(), Times.Once);
        }
    }
}
