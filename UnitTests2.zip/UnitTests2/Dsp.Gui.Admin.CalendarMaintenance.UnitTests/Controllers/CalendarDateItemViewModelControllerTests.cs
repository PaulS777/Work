﻿using System;
using Dsp.Gui.Admin.CalendarMaintenance.Controllers;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Controllers
{
    internal interface ICalendarDateItemViewModelControllerTestObjects
    {
        ICalendarDateItemValidationService ValidationService { get; }
        CalendarDateItemViewModelController Controller { get; }
        CalendarDateItemViewModel ViewModel { get; }
    }

    [TestFixture]
    public class CalendarDateItemViewModelControllerTests
    {
        private class CalendarDateItemViewModelControllerTestObjectBuilder
        {
            private DateTime? _date;
            private DateTime? _originalDate;
            private bool _newRecord;
            private bool _subscribeUpdates;

            public CalendarDateItemViewModelControllerTestObjectBuilder WithCalendarDate(DateTime value)
            {
                _date = value;
                return this;
            }

            public CalendarDateItemViewModelControllerTestObjectBuilder WithOriginalCalendarDate(DateTime value)
            {
                _originalDate = value;
                return this;
            }

            public CalendarDateItemViewModelControllerTestObjectBuilder WithNewRecord(bool value)
            {
                _newRecord = value;
                return this;
            }

            public CalendarDateItemViewModelControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public ICalendarDateItemViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<ICalendarDateItemViewModelControllerTestObjects>();

                var validationService = new Mock<ICalendarDateItemValidationService>();

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(validationService.Object);

                var controller = new CalendarDateItemViewModelController(validationService.Object);

                controller.ViewModel.Date = _date;
                controller.ViewModel.OriginalDate = _originalDate;
                controller.ViewModel.NewRecord = _newRecord;
                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetIsDeleted_OnDeleteCommand()
        {
            var testObjects = new CalendarDateItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.True);
        }

        [Test]
        public void ShouldSetIsDeletedFalse_OnUndoDeleteCommand()
        {
            var testObjects = new CalendarDateItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.DeleteCommand.Execute();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDeleted, Is.False);
            Assert.That(testObjects.ViewModel.DeleteCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldValidateNewRow_When_SubscribeUpdates()
        {
            var testObjects = new CalendarDateItemViewModelControllerTestObjectBuilder().WithNewRecord(true)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldNotValidate_When_SubscribeUpdatesFalse()
        {
            var date = new DateTime(2021, 1, 1);

            var testObjects = new CalendarDateItemViewModelControllerTestObjectBuilder().WithCalendarDate(date)
                                                                                        .WithOriginalCalendarDate(date)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Attach(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_DateChanged_With_SubscribeUpdates()
        {
            var date1 = new DateTime(2021, 1, 1);
            var date2 = new DateTime(2021, 1, 2);

            var testObjects = new CalendarDateItemViewModelControllerTestObjectBuilder().WithCalendarDate(date1)
                                                                                        .WithOriginalCalendarDate(date1)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.Date = date2;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_DateChangeReverted()
        {
            var date1 = new DateTime(2021, 1, 1);
            var date2 = new DateTime(2021, 1, 2);

            var testObjects = new CalendarDateItemViewModelControllerTestObjectBuilder().WithCalendarDate(date1)
                                                                                        .WithOriginalCalendarDate(date1)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            testObjects.ViewModel.Date = date2;

            // ACT
            testObjects.ViewModel.Date = date1;

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldDisposeRowValidationService_On_Dispose()
        {
            var testObjects = new CalendarDateItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new CalendarDateItemViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.Dispose(), Times.Once);
        }
    }
}
