﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Admin.CalendarMaintenance.Controllers;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;
using Prism.Commands;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Controllers
{
    internal interface ICalendarAdminViewModelControllerTestObjects
    {
        ICalendarAdminUpdateService CalendarAdminUpdateService { get; }
        ICurveControlService CurveControlService { get; }
        ICalendarViewModelBuilder CalendarViewModelBuilder { get; }
        ICalendarBuilder CalendarBuilder { get; }
        ICalendarViewModelCollectionProvider CalendarViewModelCollectionProvider { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        ICalendarAdminToolBarService ToolBarService { get; }
        TestScheduler TestScheduler { get; }
        ISubject<Unit> CalendarUpdateResponse { get; }
        ISubject<IList<Calendar>> Calendars { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        ISubject<Unit> ToolBarUndo { get; }
        CalendarAdminViewModel ViewModel { get; }
        CalendarAdminViewModelController Controller { get; }
    }

    [TestFixture]
    public class CalendarAdminViewModelControllerTests
    {
        private class CalendarAdminViewModelControllerTestObjectBuilder
        {
            private IList<Calendar> _calendars;
            private IList<Calendar> _calendarsSnapshot;
            private List<CalendarViewModel> _calendarCollectionProviderResult = new();
            private List<CalendarViewModel> _calendarCollectionProviderResetResult = new();
            private CalendarDateItemViewModel _newCalendarItemBuilderResult;
            private Calendar _calendarBuilderResult;

            public CalendarAdminViewModelControllerTestObjectBuilder WithCalendarCollectionProviderResult(List<CalendarViewModel> values)
            {
                _calendarCollectionProviderResult = values;
                return this;
            }

            public CalendarAdminViewModelControllerTestObjectBuilder WithCalendarCollectionProviderResetResult(List<CalendarViewModel> values)
            {
                _calendarCollectionProviderResetResult = values;
                return this;
            }

            public CalendarAdminViewModelControllerTestObjectBuilder WithNewCalendarItemBuilderResult(CalendarDateItemViewModel value)
            {
                _newCalendarItemBuilderResult = value;
                return this;
            }

            public CalendarAdminViewModelControllerTestObjectBuilder WithCalendars(IList<Calendar> values)
            {
                _calendars = values;
                return this;
            }

            public CalendarAdminViewModelControllerTestObjectBuilder WithCalendarsSnapshot(IList<Calendar> values)
            {
                _calendarsSnapshot = values;
                return this;
            }

            public CalendarAdminViewModelControllerTestObjectBuilder WithCalendarBuilderResult(Calendar value)
            {
                _calendarBuilderResult = value;
                return this;
            }

            public ICalendarAdminViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<ICalendarAdminViewModelControllerTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                var calendars = new BehaviorSubject<IList<Calendar>>(_calendars);

                testObjects.SetupGet(o => o.Calendars)
                           .Returns(calendars);

                curveControlService.SetupGet(c => c.Calendars)
                                   .Returns(calendars);

                curveControlService.Setup(c => c.GetCalendarsSnapshot())
                                   .Returns(_calendarsSnapshot);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService.Object);

                var calendarUpdateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.CalendarUpdateResponse)
                           .Returns(calendarUpdateResponse);

                var calendarBuilder = new Mock<ICalendarBuilder>();

                calendarBuilder.Setup(cb => cb.GetCalendar(It.IsAny<CalendarViewModel>()))
                               .Returns(_calendarBuilderResult);

                testObjects.SetupGet(o => o.CalendarBuilder)
                           .Returns(calendarBuilder.Object);

                var calendarAdminUpdateService = new Mock<ICalendarAdminUpdateService>();

                calendarAdminUpdateService.Setup(c => c.Update(It.IsAny<Calendar>(), 
                                                               It.IsAny<IScheduler>()))
                                          .Returns(calendarUpdateResponse);

                testObjects.SetupGet(o => o.CalendarAdminUpdateService)
                           .Returns(calendarAdminUpdateService.Object);

                var calendarViewModelBuilder = new Mock<ICalendarViewModelBuilder>();

                calendarViewModelBuilder.Setup(b => b.GetNewCalendarItem())
                                        .Returns(_newCalendarItemBuilderResult);

                testObjects.SetupGet(o => o.CalendarViewModelBuilder)
                           .Returns(calendarViewModelBuilder.Object);

                var calendarViewModelCollectionProvider = new Mock<ICalendarViewModelCollectionProvider>();

                calendarViewModelCollectionProvider.Setup(p => p.GetCollection(
                                                              It.IsAny<IList<CalendarViewModel>>(),
                                                              It.IsAny<IList<Calendar>>(),
                                                              It.IsAny<Func<CalendarViewModel, Calendar, bool>>(),
                                                              It.IsAny<Action<CalendarViewModel, Calendar>>(),
                                                              It.IsAny<Func<Calendar, CalendarViewModel>>()))
                                                   .Returns(_calendarCollectionProviderResult);


                calendarViewModelCollectionProvider.Setup(p => p.GetCollectionReset(It.IsAny<IList<Calendar>>(), 
                                                                                    It.IsAny<Func<Calendar, CalendarViewModel>>()))
                                                   .Returns(_calendarCollectionProviderResetResult);

                testObjects.SetupGet(o => o.CalendarViewModelCollectionProvider)
                           .Returns(calendarViewModelCollectionProvider.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var toolBarUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUpdate)
                           .Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUndo)
                           .Returns(toolBarUndo);

                var toolBarService = new Mock<ICalendarAdminToolBarService>();

                toolBarService.SetupGet(tb => tb.Update)
                              .Returns(toolBarUpdate);

                toolBarService.SetupGet(tb => tb.Undo)
                              .Returns(toolBarUndo);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBarService.Object);

                var controller = new CalendarAdminViewModelController(curveControlService.Object, 
                                                                      calendarViewModelCollectionProvider.Object,
                                                                      toolBarService.Object, 
                                                                      Mocks.GetSchedulerProvider().Object, 
                                                                      Mocks.GetLoggerFactory().Object)
                {
                    PopupNotificationService = popupNotificationService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    CalendarViewModelBuilder = calendarViewModelBuilder.Object,
                    CalendarBuilder = calendarBuilder.Object,
                    CalendarAdminUpdateService = calendarAdminUpdateService.Object,
                };

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowBusyIndicator_On_Loading()
        {
            // ACT
            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldPopulateCalendars_And_SetSelectedCalendar_From_ActiveCalendars()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1,
                    CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>
                    {
                        new(Mock.Of<IDisposable>())
                    }
                },
                new(Mock.Of<ICalendarDateItemViewModelController>()){Id = 2},
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .Build();

            // ACT
            testObjects.Calendars.OnNext(calendars);

            // ASSERT
            Assert.That(testObjects.ViewModel.Calendars.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.Calendars[0].Id, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.CalendarItems.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldInvokeBuilderFunctions_When_PopulatingCalendars()
        {
            var calendarViewModel = new CalendarViewModel(Mock.Of<ICalendarDateItemViewModelController>())
            {
                Id = 1
            };
            
            var calendarViewModels = new List<CalendarViewModel>
            {
                calendarViewModel
            };

            var calendars = TestData.TestCalendars();

            var calendar = calendars[0];

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .Build();

            var comparerResult = false;

            Mock.Get(testObjects.CalendarViewModelCollectionProvider)
                .Setup(p => p.GetCollection(
                           It.IsAny<IList<CalendarViewModel>>(),
                           It.IsAny<IList<Calendar>>(),
                           It.IsAny<Func<CalendarViewModel, Calendar, bool>>(),
                           It.IsAny<Action<CalendarViewModel, Calendar>>(),
                           It.IsAny<Func<Calendar, CalendarViewModel>>()))
                .Returns(calendarViewModels)
                .Callback<IList<CalendarViewModel>,
                     IList<Calendar>,
                     Func<CalendarViewModel, Calendar, bool>,
                     Action<CalendarViewModel, Calendar>,
                     Func<Calendar, CalendarViewModel>>
                 ((_, _, comparer, updater, builder) =>
                 {
                     comparerResult = comparer(calendarViewModel, calendar);
                     updater(calendarViewModel, calendar);
                     builder(calendar);
                 });

            // ACT
            testObjects.Calendars.OnNext(calendars);

            // ASSERT
            Mock.Get(testObjects.CalendarViewModelBuilder)
                .Verify(b => b.CreateCalendar(calendar));

            Mock.Get(testObjects.CalendarViewModelBuilder)
                .Verify(b => b.UpdateCalendar(calendarViewModel, calendar));

            Assert.That(comparerResult, Is.True);
        }

        [Test]
        public void ShouldEnableCalendarSelection_When_CalendarsPopulated()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1,
                    CanExecuteUndoCommand = false
                },
                new(Mock.Of<ICalendarDateItemViewModelController>()){Id = 2},
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .Build();

            // ACT
            testObjects.Calendars.OnNext(calendars);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCalendar, Is.True);
        }

        [Test]
        public void ShouldInvokeRefreshRowsCommandOnCalendarViewModels_When_Loaded()
        {
            var result = false;

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    RefreshItemsCommand = new DelegateCommand(() => result = true)
                }
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .Build();

            // ACT
            testObjects.Calendars.OnNext(calendars);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldHideBusyIndicator_When_CalendarsLoaded()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>()){Id = 1}
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .Build();

            // ACT
            testObjects.Calendars.OnNext(calendars);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldClearDialog_When_SelectedCalendarChangedToNull()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1,
                    CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>
                    {
                        new(Mock.Of<IDisposable>())
                    }
                },
                new(Mock.Of<ICalendarDateItemViewModelController>()){Id = 2}
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.SelectedCalendar = null;

            // ASSERT
            Assert.IsNull(testObjects.ViewModel.CalendarItems);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(false));
        }

        [Test]
        public void ShouldRefreshItems_On_ToolBarUndo()
        {
            var refreshResult = false;

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1,
                    CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>
                    {
                        new(Mock.Of<IDisposable>())
                    },
                    RefreshItemsCommand = new DelegateCommand(() => refreshResult = true)

                }
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendarCollectionProviderResetResult(calendarViewModels)
                                                                                     .WithCalendarsSnapshot(calendars)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();
            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.Calendars.Count, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.Calendars[0].Id, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.CalendarItems.Count, Is.EqualTo(1));
            Assert.That(refreshResult, Is.True);
        }

        [Test]
        public void ShouldSetPreviousSelectedCalendar_On_ToolBarUndo()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                },
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 2
                }
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendarCollectionProviderResetResult(calendarViewModels)
                                                                                     .WithCalendarsSnapshot(calendars)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();

            testObjects.ViewModel.SelectedCalendar = testObjects.ViewModel.Calendars[1];

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedCalendar.Id, Is.EqualTo(2));
        }

        [Test]
        public void ShouldSetSelectedItemAndInvokeAddRowCommand_On_AddHolidayCommand()
        {
            CalendarDateItemViewModel result = null;

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>()
                    {
                        new(Mock.Of<IDisposable>())
                    },
                    AddItemCommand = new DelegateCommand<CalendarDateItemViewModel>(row => result = row)
                }
            };

            var newRow = new CalendarDateItemViewModel(Mock.Of<ICalendarDateItemViewModelController>());

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .WithNewCalendarItemBuilderResult(newRow)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.AddHolidayCommand.Execute();

            // ASSERT
            Assert.AreSame(newRow, testObjects.ViewModel.SelectedItem);
            Assert.AreSame(newRow, result);
        }

        [Test]
        public void ShouldSetCanUpdateOnToolBar_When_SelectedCalendarCanExecuteUpdateCommand()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1,
                    CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>
                    {
                        new(Mock.Of<IDisposable>())
                    }
                },
                new(Mock.Of<ICalendarDateItemViewModelController>()){Id = 2},
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.SelectedCalendar.CanExecuteUpdateCommand = true;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldSetCanUndoOnToolBar_When_SelectedCalendarCanExecuteUndoCommand()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1,
                    CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>
                    {
                        new(Mock.Of<IDisposable>())
                    }
                },
                new(Mock.Of<ICalendarDateItemViewModelController>()){Id = 2},
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.SelectedCalendar.CanExecuteUndoCommand = true;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndo(true));
        }

        [Test]
        public void ShouldDisableCalendarSelection_When_SelectedCalendarCanExecuteUndoCommandTrue()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1,
                    CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>
                    {
                        new(Mock.Of<IDisposable>())
                    }
                },
                new(Mock.Of<ICalendarDateItemViewModelController>()){Id = 2},
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();
            // ACT
            testObjects.ViewModel.SelectedCalendar.CanExecuteUndoCommand = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCalendar, Is.False);
        }

        [Test]
        public void ShouldEnableCalendarSelection_When_SelectedCalendarCanExecuteUndoCommandFalse()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1,
                    CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>
                    {
                        new(Mock.Of<IDisposable>())
                    }
                },
                new(Mock.Of<ICalendarDateItemViewModelController>()){Id = 2},
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();

            testObjects.ViewModel.SelectedCalendar.CanExecuteUndoCommand = true;

            // ACT
            testObjects.ViewModel.SelectedCalendar.CanExecuteUndoCommand = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCalendar, Is.True);
        }

        [Test]
        public void ShouldSetIsBusy_On_ToolBarUpdate()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                }
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);
        }

        [Test]
        public void Should_InvokeAdminUpdateService_With_SelectedCalendar_On_ToolBarUpdate()
        {
            var calendars = TestData.TestCalendars();

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                },
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 2
                }
            };

            var calendarUpdate = new Calendar(2, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false, new List<DateTime>());

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .WithCalendarBuilderResult(calendarUpdate)
                                                                                     .Build();

            testObjects.ViewModel.SelectedCalendar = testObjects.ViewModel.Calendars[1];

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.CalendarBuilder)
                .Verify(b => b.GetCalendar(It.Is<CalendarViewModel>(vm => vm.Id == 2)));

            Mock.Get(testObjects.CalendarAdminUpdateService)
                .Verify(a => a.Update(calendarUpdate, It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldShowPopupAndSetIsBusyFalse_On_UpdateCompleted()
        {
            var calendars = TestData.TestCalendars();

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                }
            };

            var calendarUpdate = new Calendar(2, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false, new List<DateTime>());

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .WithCalendarBuilderResult(calendarUpdate)
                                                                                     .Build();
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.CalendarUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), null));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        [Test]
        public void ShouldSetPreviousSelectedCalendar_On_CalendarsAfterUpdate()
        {
            var calendars = TestData.TestCalendars();

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                },
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 2
                }
            };

            var calendarUpdate = new Calendar(2, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false, new List<DateTime>());

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .WithCalendarBuilderResult(calendarUpdate)
                                                                                     .Build();

            testObjects.ViewModel.SelectedCalendar = testObjects.ViewModel.Calendars[1];

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.Calendars.OnNext(calendars);

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedCalendar.Id, Is.EqualTo(2));
        }

        [Test]
        public void ShouldSetIsBusyFalse_And_ShowDialog_On_UpdateFailed()
        {
            var calendars = TestData.TestCalendars();

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                }
            };

            var calendarUpdate = new Calendar(2, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false, new List<DateTime>());

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .WithCalendarBuilderResult(calendarUpdate)
                                                                                     .Build();
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.CalendarUpdateResponse.OnError(new Exception("failed"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(md => md.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "failed" && args.ShowSendFeedback)));

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), null), Times.Never);
        }

        [Test]
        public void ShouldSetToolBarValidationErrors_On_SelectedCalendarErrors()
        {
            var calendars = TestData.TestCalendars();

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                }
            };

            var calendarUpdate = new Calendar(2, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false, new List<DateTime>());

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .WithCalendarBuilderResult(calendarUpdate)
                                                                                     .Build();

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            var errors = new List<string>{"error"};

            // ACT
            testObjects.ViewModel.SelectedCalendar.ValidationErrors = errors;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetValidationErrors(errors));
        }

        [Test]
        public void ShouldClearToolBarValidationErrors_On_SelectedCalendarNoErrors()
        {
            var calendars = TestData.TestCalendars();

            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                }
            };

            var calendarUpdate = new Calendar(2, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false, new List<DateTime>());

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .WithCalendarBuilderResult(calendarUpdate)
                                                                                     .Build();

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.SelectedCalendar.ValidationErrors = null;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.ClearValidation());
        }

        [Test]
        public void ShouldNotInvokeUpdate_When_Disposed()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                }
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var calendarViewModels = new List<CalendarViewModel>
            {
                new(Mock.Of<ICalendarDateItemViewModelController>())
                {
                    Id = 1
                }
            };

            var calendars = TestData.TestCalendars();

            var testObjects = new CalendarAdminViewModelControllerTestObjectBuilder().WithCalendarCollectionProviderResult(calendarViewModels)
                                                                                     .WithCalendars(calendars)
                                                                                     .Build();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }
    }
}
