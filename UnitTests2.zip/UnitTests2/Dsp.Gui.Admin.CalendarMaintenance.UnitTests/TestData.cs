﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests
{
    public static class TestData
    {
        public static IList<Calendar> TestCalendars()
        {
            return new Calendar[]
            {
                new(1, EntityStatus.Active, "CODE1", "Description 1",  string.Empty, string.Empty, string.Empty, false,new List<DateTime> {DateTime.Today.AddDays(1), DateTime.Today.AddMonths(1), DateTime.Today.AddYears(1)}),
                new(2, EntityStatus.Deleted, "CODE2", "Description 2", string.Empty, string.Empty, string.Empty, false, new List<DateTime> {DateTime.Today.AddDays(2), DateTime.Today.AddMonths(2), DateTime.Today.AddYears(2)}),
                new(3, EntityStatus.Active, "CODE3", "Description 3", string.Empty, string.Empty, string.Empty, false, new List<DateTime> {DateTime.Today.AddDays(3), DateTime.Today.AddMonths(3), DateTime.Today.AddYears(3)}),
            };
        }
    }
}