﻿using System;
using Dsp.Gui.Admin.CalendarMaintenance.Rules;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.Rules
{
    public interface ICalendarDateValidationRuleTestObjects
    {
        CalendarDateRule ValidationRule { get; }
    }

    [TestFixture]
    public class CalendarDateValidationRuleTests
    {
        private class CalendarDateValidationRuleTestObjectBuilder
        {
            private DateTime _dateNow;

            public CalendarDateValidationRuleTestObjectBuilder WithDateNow(DateTime value)
            {
                _dateNow = value;
                return this;
            }

            public ICalendarDateValidationRuleTestObjects Build()
            {
                var testObjects = new Mock<ICalendarDateValidationRuleTestObjects>();

                var currentBusinessDateProvider = new Mock<ICurrentBusinessDateProvider>();

                currentBusinessDateProvider.SetupGet(p => p.CurrentDate)
                                           .Returns(_dateNow);

                var rule= new CalendarDateRule(currentBusinessDateProvider.Object);

                testObjects.SetupGet(o => o.ValidationRule)
                           .Returns(rule);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldReturnPropertyChangedObservable()
        {
            var viewModel = new CalendarDateItemViewModel(Mock.Of<IDisposable>());

            var testObjects = new CalendarDateValidationRuleTestObjectBuilder().Build();

            var observable = testObjects.ValidationRule.ObservePropertyChanged(viewModel);

            CalendarDateItemViewModel result = null;

            using (observable.Subscribe(vm => result = vm))
            {
                // ACT
                viewModel.Date = new DateTime(2021, 1, 1);

                // ASSERT
                Assert.AreSame(viewModel, result);
            }
        }

        [Test]
        public void ShouldReturnValidationError_When_Validate_With_MissingDate()
        {
            var viewModel = new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            {
                Date = null
            };

            var testObjects = new CalendarDateValidationRuleTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ValidationRule.Validate(viewModel);

            // ASSERT
            Assert.That(result, Is.EqualTo("Missing Date"));
        }

        [Test]
        public void ShouldReturnValidationError_When_Validate_With_CalendarDateBeforeToday()
        {
            var calendarDate = new DateTime(2021, 1, 1);
            var today = new DateTime(2021, 1, 2);

            var viewModel = new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            {
                Date = calendarDate
            };

            var testObjects = new CalendarDateValidationRuleTestObjectBuilder().WithDateNow(today)
                                                                               .Build();

            // ACT
            var result = testObjects.ValidationRule.Validate(viewModel);

            // ASSERT
            Assert.That(result, Is.EqualTo("Date Cannot be Past"));
        }

        [Test]
        public void ShouldReturnNoValidationError_When_Validate_With_CalendarDateEqualsToday()
        {
            var calendarDate = new DateTime(2021, 1, 2);
            var today = new DateTime(2021, 1, 2);

            var viewModel = new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            {
                Date = calendarDate
            };

            var testObjects = new CalendarDateValidationRuleTestObjectBuilder().WithDateNow(today)
                                                                               .Build();

            // ACT
            var result = testObjects.ValidationRule.Validate(viewModel);

            // ASSERT
            Assert.That(result, Is.EqualTo(string.Empty));
        }

        [Test]
        public void ShouldReturnNoValidationError_When_Validate_With_CalendarDateAfterToday()
        {
            var calendarDate = new DateTime(2021, 1, 3);
            var today = new DateTime(2021, 1, 2);

            var viewModel = new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            {
                Date = calendarDate
            };

            var testObjects = new CalendarDateValidationRuleTestObjectBuilder().WithDateNow(today)
                                                                               .Build();

            // ACT
            var result = testObjects.ValidationRule.Validate(viewModel);

            // ASSERT
            Assert.That(result, Is.EqualTo(string.Empty));
        }
    }
}
