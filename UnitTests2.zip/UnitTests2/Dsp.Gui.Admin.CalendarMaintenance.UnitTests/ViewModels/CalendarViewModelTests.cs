﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.ViewModels
{
    [TestFixture]
    public class CalendarViewModelTests
    {
        [Test]
        public void ShouldSetProperties()
        {
            var calendar = new Calendar(10, EntityStatus.Active, "code", "desc", string.Empty, string.Empty, string.Empty, false, new List<DateTime>());

            // ACT
            var viewModel = new CalendarViewModel(Mock.Of<IDisposable>())
            {
                Id = 10, 
                NewRecord = true, 
                Description = "desc",
                ValidationErrors = new List<string> { "error"}
            };

            viewModel.SetCalendar(calendar);

            // ASSERT
            Assert.AreEqual(10, viewModel.Id);
            Assert.AreEqual("desc", viewModel.Description);
            Assert.AreEqual(1, viewModel.ValidationErrors.Count);
            Assert.IsTrue(viewModel.NewRecord);
        }

        [Test]
        public void ShouldDisposeController_When_Dispose()
        {
            var controller = new Mock<IDisposable>();

            var viewModel = new CalendarViewModel(controller.Object);

            // ACT
            viewModel.Dispose();

            // ASSERT
            controller.Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDisposeController_When_Disposed()
        {
            var controller = new Mock<IDisposable>();

            var viewModel = new CalendarViewModel(controller.Object);

            viewModel.Dispose();

            // ACT
            viewModel.Dispose();

            // ASSERT
            controller.Verify(c => c.Dispose(), Times.Once);
        }
    }
}
