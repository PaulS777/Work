﻿using System;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.CalendarMaintenance.UnitTests.ViewModels
{
    [TestFixture]
    public class CalendarItemViewModelTests
    {
        [Test]
        public void ShouldSetProperties()
        {
            var originalDate = new DateTime(2021, 1,1);
            var date = new DateTime(2021, 1, 2);

            // ACT
            var viewModel = new CalendarDateItemViewModel(Mock.Of<IDisposable>())
            {
                Date = date,
                OriginalDate = originalDate,
                SubscribeUpdates = true

            };

            // ASSERT
            Assert.AreEqual(date, viewModel.Date);
            Assert.AreEqual(originalDate, viewModel.OriginalDate);
            Assert.IsTrue(viewModel.SubscribeUpdates);
        }

        [Test]
        public void ShouldDisposeController_When_Dispose()
        {
            var controller = new Mock<IDisposable>();

            var viewModel = new CalendarDateItemViewModel(controller.Object);

            // ACT
            viewModel.Dispose();

            // ASSERT
            controller.Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDisposeController_When_Disposed()
        {
            var controller = new Mock<IDisposable>();

            var viewModel = new CalendarDateItemViewModel(controller.Object);

            viewModel.Dispose();

            // ACT
            viewModel.Dispose();

            // ASSERT
            controller.Verify(c => c.Dispose(), Times.Once);
        }
    }
}
