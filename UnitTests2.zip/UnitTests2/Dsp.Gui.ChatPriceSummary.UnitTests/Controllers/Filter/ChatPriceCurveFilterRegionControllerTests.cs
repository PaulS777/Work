﻿using Castle.Components.DictionaryAdapter;
using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.Controllers.Filter;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Controllers.Filter
{
    [TestFixture]
    public class ChatPriceCurveFilterRegionControllerTests
    {
        [Test]
        public void ShouldSetItemIsSelectedTrue_WhenRegionIsSelected()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false},
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false},
            };

            // ACT
            viewModel.RegionHeader.IsSelected = true;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.True);
            Assert.That(viewModel.Items[1].IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetItemIsSelectedFalse_WhenRegionIsSelectedFalse()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = true},
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = true},
            };

            // ACT
            viewModel.RegionHeader.IsSelected = false;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.False);
            Assert.That(viewModel.Items[1].IsSelected, Is.False);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToIntermediateState_WhenSingleItemSelected()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false},
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false}
            };

            // ACT
            viewModel.Items[0].IsSelected = true;

            // ASSERT
            Assert.IsNull(viewModel.RegionHeader.IsSelected);
        }

        [Test]
        public void ShouldInitializeRegionIsSelected_ToTrue_WhenInitializedWithCurveFilterItems()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            // ACT
            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = true},
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = true}
            };

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToTrue_WhenAllItemsSelected()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

            var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            // ACT
            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false},
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false}
            };

            // ACT
            viewModel.Items[0].IsSelected = true;
            viewModel.Items[1].IsSelected = true;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToIntermediateState_WhenItemDeSelected()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = true},
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = true}
            };

            // ACT
            viewModel.Items[0].IsSelected = false;

            // ASSERT
            Assert.IsNull(viewModel.RegionHeader.IsSelected);
            Assert.That(viewModel.Items[1].IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToFalse_WhenAllItemsDeSelected()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = true},
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = true}
            };

            // ACT
            viewModel.Items[0].IsSelected = false;
            viewModel.Items[1].IsSelected = false;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.False);
        }

        [Test]
        public void ShouldNotUpdateHeader_WhenDisposed()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false}
            };

            // ARRANGE
            controller.Dispose();

            // ACT
            viewModel.Items[0].IsSelected = true;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.False);
        }

        [Test]
        public void ShouldNotUpdateItems_WhenDisposed()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false}
            };

            // ARRANGE
            controller.Dispose();

            // ACT
            viewModel.RegionHeader.IsSelected = true;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var controller = new ChatPriceCurveFilterRegionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.ViewModel;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            viewModel.Items = new EditableList<ChatPriceCurveFilterItem>
            {
                new(1, "curve-1", "name-1", curveGroup, CurveRegion.Europe)  {IsSelected = false}
            };

            // ARRANGE
            controller.Dispose();

            // ACT
            controller.Dispose();
            viewModel.RegionHeader.IsSelected = true;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.False);
        }
    }
}
