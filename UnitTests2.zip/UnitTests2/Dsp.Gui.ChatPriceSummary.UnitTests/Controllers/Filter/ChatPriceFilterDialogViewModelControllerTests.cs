﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reactive;
using System.Reactive.Subjects;
using Dsp.Gui.ChatPriceSummary.Controllers.Filter;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Controllers.Filter
{
    public interface IChatPriceFilterDialogViewModelControllerTestObjects
    {
        ISubject<Unit> ToolBarShowCurvesFilter { get; }
        ISubject<Unit> ToolBarShowColumnsFilter { get; }
        ChatPriceFilterDialogViewModel ViewModel { get; }
        ChatPriceFilterDialogViewModelController Controller { get; }
    }

    [TestFixture]
    public class ChatPriceFilterDialogViewModelControllerTests
    {
        private class ChatPriceFilterDialogViewModelControllerTestObjectBuilder
        {
            private ObservableCollection<ChatPriceGridFiltersViewModel> _chatPriceFilters;
            private ChatPriceGridFiltersViewModel _selectedChatPriceFilter;
            private bool _isMarketsSelected;

            public ChatPriceFilterDialogViewModelControllerTestObjectBuilder WithChatPriceFilters(IList<ChatPriceGridFiltersViewModel> values)
            {
                _chatPriceFilters = new ObservableCollection<ChatPriceGridFiltersViewModel>(values);
                return this;
            }

            public ChatPriceFilterDialogViewModelControllerTestObjectBuilder WithSelectedChatPriceFilter(ChatPriceGridFiltersViewModel value)
            {
                _selectedChatPriceFilter = value;
                return this;
            }

            public ChatPriceFilterDialogViewModelControllerTestObjectBuilder WithIsMarketsSelected(bool value)
            {
                _isMarketsSelected = value;
                return this;
            }

            public IChatPriceFilterDialogViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceFilterDialogViewModelControllerTestObjects>();

                var showCurveFilter = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarShowCurvesFilter)
                           .Returns(showCurveFilter);

                var showColumnsFilter = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarShowColumnsFilter)
                           .Returns(showColumnsFilter);

                var toolBarService = new Mock<IChatPriceSummaryToolBarService>();

                toolBarService.SetupGet(t => t.ShowMarketsFilter)
                              .Returns(showCurveFilter);

                toolBarService.SetupGet(t => t.ShowColumnSettings)
                              .Returns(showColumnsFilter);

                var controller = new ChatPriceFilterDialogViewModelController(toolBarService.Object,
                                                                              TestMocks.GetSchedulerProvider().Object);

                if (_chatPriceFilters != null)
                {
                    controller.ViewModel.ChatPriceFilters = _chatPriceFilters;
                }

                controller.ViewModel.SelectedChatPriceFilterViewModel = _selectedChatPriceFilter;
                controller.ViewModel.IsMarketsSelected = _isMarketsSelected;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        private static ChatPriceGridFiltersViewModel GetChatPriceGridFiltersViewModel()
        {
            return new ChatPriceGridFiltersViewModel
            {
                CurveFilter = new ChatPriceCurveFilterViewModel
                {
                    FilterGroups = new List<ChatPriceCurveFilterGroup>(),
                    CancelFilterChangesCommand = new DelegateCommand(() => {})
                },
                ColumnFilter = new ChatPriceColumnFilterViewModel
                {
                    FilterItems = new List<ChatPriceColumnFilterItem>(),
                    CancelFilterChangesCommand = new DelegateCommand(() => { })
                }
            };
        }

        [Test]
        public void ShouldShowDialogWithCurvesFilter_On_ToolBarShowMarketsFilter_With_IsMarketsSelectedTrue()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] {filter1, filter2};

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithIsMarketsSelected(true)
                                                                                             .Build();

            // ACT
            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(filter1.CurveFilter.ShowFilter, Is.True);
            Assert.That(filter2.CurveFilter.ShowFilter, Is.True);
            Assert.That(filter1.ColumnFilter.ShowFilter, Is.False);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldNotShowDialogWithCurvesFilter_On_ToolBarShowMarketsFilter_With_IsMarketsSelectedFalse()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithIsMarketsSelected(false)
                                                                                             .Build();

            // ACT
            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
            Assert.That(filter1.CurveFilter.ShowFilter, Is.False);
            Assert.That(filter2.CurveFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldShowDialogWithColumnFilter_On_ToolBarShowColumnsFilter_With_IsMarketsSelectedTrue()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithIsMarketsSelected(true)
                                                                                             .Build();

            // ACT
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(filter1.ColumnFilter.ShowFilter, Is.True);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.True);
            Assert.That(filter1.CurveFilter.ShowFilter, Is.False);
            Assert.That(filter2.CurveFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldNotShowDialogWithColumnFilter_On_ToolBarShowColumnsFilter_With_IsMarketsSelectedFalse()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithIsMarketsSelected(false)
                                                                                             .Build();

            // ACT
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
            Assert.That(filter1.ColumnFilter.ShowFilter, Is.False);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldShowDialogWithCurvesFilter_When_SelectCurveFilter_WithShowFilterTrue()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            filter1.CurveFilter.ShowFilter = true;

            var filters = new[]
            {
                filter1, filter2
            };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .Build();

            // ACT
            testObjects.ViewModel.SelectedChatPriceFilterViewModel = filter1;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldCloseDialog_On_HideSelectedCurveFilter_With_ColumnFilterHidden()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();

            var filter2 = GetChatPriceGridFiltersViewModel();

            var cancelFilterCommand = new DelegateCommand(() => filter2.CurveFilter.ShowFilter = false);
            filter2.CurveFilter.CancelFilterChangesCommand = cancelFilterCommand;

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .Build();
            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);

            // ACT
            filter1.CurveFilter.ShowFilter = false;

            // ASSERT
            Assert.That(filter2.CurveFilter.ShowFilter, Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldCloseDialog_On_HideSelectedColumnFilter_With_CurveFilterHidden()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .Build();
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ACT
            filter1.ColumnFilter.ShowFilter = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldDisableCloseDialogCommand_On_SelectedColumnFilter_With_CanCancelCurveChangesFalse()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            filter1.CurveFilter.CanCancelFilterChanges = false;

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .Build();

            // ACT
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.CloseDialogCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableCloseDialogCommand_On_SelectedColumnFilter_With_CanCancelCurveChangesTrue()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            filter1.CurveFilter.CanCancelFilterChanges = true;

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .Build();

            // ACT
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.CloseDialogCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableCloseDialogCommand_When_SelectedColumnFilterCanCancelCurveChangesTrue()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            filter1.CurveFilter.CanCancelFilterChanges = false;

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .Build();
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ACT
            filter1.CurveFilter.CanCancelFilterChanges = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CloseDialogCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldShowDialogWithBothFilters_On_ToolBarShowCurveFilter_With_ToolBarShowColumnsFilter()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithIsMarketsSelected(true)
                                                                                             .Build();

            // ACT
            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(filter1.CurveFilter.ShowFilter, Is.True);
            Assert.That(filter2.CurveFilter.ShowFilter, Is.True);
            Assert.That(filter1.ColumnFilter.ShowFilter, Is.True);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.True);
        }

        [Test]
        public void ShouldCancelChangesAndCloseDialog_On_CloseFilterDialogCommand()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            filter1.CurveFilter.CanCancelFilterChanges = true;

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .Build();

            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ACT
            testObjects.ViewModel.CloseDialogCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
            Assert.That(filter1.CurveFilter.ShowFilter, Is.False);
            Assert.That(filter2.CurveFilter.ShowFilter, Is.False);
            Assert.That(filter1.ColumnFilter.ShowFilter, Is.False);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldShowDialogWithCurveFilter_On_HideSelectedColumnFilter_With_CurveFilterShown()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .WithIsMarketsSelected(true)
                                                                                             .Build();

            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ACT
            filter1.ColumnFilter.ShowFilter = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(filter1.CurveFilter.ShowFilter, Is.True);
            Assert.That(filter2.CurveFilter.ShowFilter, Is.True);
            Assert.That(filter1.ColumnFilter.ShowFilter, Is.False);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldShowDialogWithColumnFilter_On_HideSelectedCurveFilter_With_ColumnFilterShown()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .WithIsMarketsSelected(true)
                                                                                             .Build();

            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            // ACT
            filter1.CurveFilter.ShowFilter = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
            Assert.That(filter1.ColumnFilter.ShowFilter, Is.True);
            Assert.That(filter2.ColumnFilter.ShowFilter, Is.True);
            Assert.That(filter1.CurveFilter.ShowFilter, Is.False);
            Assert.That(filter2.CurveFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldUnsubscribeGridFilterShowFilters_On_SelectedGridFilterChanged()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            filter1.Name ="FILTER 1";
            filter2.Name = "FILTER 2";

            var filters = new[] {filter1, filter2};

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .WithIsMarketsSelected(true)
                                                                                             .Build();

            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);

            testObjects.ViewModel.SelectedChatPriceFilterViewModel = filter2;

            // ACT
            filter1.CurveFilter.ShowFilter = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldUpdateSelectedFilterItem_On_SelectNextFilterCommand()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .Build();
            // ACT
            testObjects.ViewModel.SelectNextFilterCommand.Execute();

            // ASSERT
            Assert.AreSame(filter2, testObjects.ViewModel.SelectedChatPriceFilterViewModel);
        }

        [Test]
        public void ShouldNotUpdateSelectedFilterItem_On_SelectNextFilterCommand_WithLastItemCurrentSelected()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter2)
                                                                                             .Build();
            // ACT
            testObjects.ViewModel.SelectNextFilterCommand.Execute();

            // ASSERT
            Assert.AreSame(filter2, testObjects.ViewModel.SelectedChatPriceFilterViewModel);
        }

        [Test]
        public void ShouldUpdateSelectedFilterItem_On_SelectPreviousFilterCommand()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter2)
                                                                                             .Build();
            // ACT
            testObjects.ViewModel.SelectPreviousFilterCommand.Execute();

            // ASSERT
            Assert.AreSame(filter1, testObjects.ViewModel.SelectedChatPriceFilterViewModel);
        }

        [Test]
        public void ShouldNotUpdateSelectedFilterItem_On_SelectPreviousFilterCommand_WithFirstItemCurrentSelected()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .Build();
            // ACT
            testObjects.ViewModel.SelectPreviousFilterCommand.Execute();

            // ASSERT
            Assert.AreSame(filter1, testObjects.ViewModel.SelectedChatPriceFilterViewModel);
        }

        [Test]
        public void ShouldEnableSelectNextFilter_When_CurrentSelectedIsFirstItem()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new List<ChatPriceGridFiltersViewModel> { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .Build();
            // ACT
            testObjects.ViewModel.SelectedChatPriceFilterViewModel = filter1;

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectNextFilterCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableSelectPreviousFilter_When_CurrentSelectedIsFirstItem()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new List<ChatPriceGridFiltersViewModel> { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .Build();
            // ACT
            testObjects.ViewModel.SelectedChatPriceFilterViewModel = filter1;

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectPreviousFilterCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableSelectNextFilter_When_CurrentSelectedIsLastItem()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new List<ChatPriceGridFiltersViewModel> { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .Build();
            // ACT
            testObjects.ViewModel.SelectedChatPriceFilterViewModel = filter2;

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectNextFilterCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableSelectPreviousFilter_When_CurrentSelectedIsLastItem()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new List<ChatPriceGridFiltersViewModel> { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .Build();
            // ACT
            testObjects.ViewModel.SelectedChatPriceFilterViewModel = filter2;

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectPreviousFilterCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldNotShowDialogWithColumnFilter_On_ToolBarShowColumnsFilter()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
       
            var filters = new[] { filter1};

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);
            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldCloseDialog_On_HideSelectedColumnFilter_When_Disposed()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();
            var filter2 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1, filter2 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .WithSelectedChatPriceFilter(filter1)
                                                                                             .WithIsMarketsSelected(true)
                                                                                             .Build();

            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);

            testObjects.Controller.Dispose();

            // ACT
            filter1.ColumnFilter.ShowFilter = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var filter1 = GetChatPriceGridFiltersViewModel();

            var filters = new[] { filter1 };

            var testObjects = new ChatPriceFilterDialogViewModelControllerTestObjectBuilder().WithChatPriceFilters(filters)
                                                                                             .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ToolBarShowColumnsFilter.OnNext(Unit.Default);
            testObjects.ToolBarShowCurvesFilter.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

    }
}
