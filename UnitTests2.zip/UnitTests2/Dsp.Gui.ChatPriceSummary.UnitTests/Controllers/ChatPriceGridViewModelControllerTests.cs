﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.Controllers;
using Dsp.Gui.ChatPriceSummary.Services.Filter;
using Dsp.Gui.ChatPriceSummary.Services.GridUpdate;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Controllers
{
    public interface IChatPriceGridViewModelControllerTestObjects
    {
        ICurveFilterLoadedService CurveFilterLoadedService { get; }
        ISubject<List<ChatPriceCurveFilterItem>> CurveFilterItemsLoaded { get; }
        IColumnFilterLoadedService ColumnFilterLoadedService { get; }
        ISubject<List<ChatPriceColumnFilterItem>> ColumnFilterItemsLoaded { get; }
        ICurveFilterDialogService CurveFilterDialogService { get; }
        ISubject<Unit> ApplyCurveFilterChangesCommand { get; }
        IColumnFilterDialogService ColumnFilterDialogService { get; }
        ISubject<Unit> ApplyColumnFilterChangesCommand { get; }
        IChatPriceCurveFilterCurveGroupBuilder FilterCurveGroupBuilder { get; }
        IChatPriceGridRemovalService ChatPriceGridRemovalService { get; }
        IChatPriceGridRefreshService GridRefreshService { get; }
        IChatPriceSummarySettingsService SettingsService { get; }
        IChatPriceColumnWidthService ColumnWidthService { get; }
        IDispatcherExecutionService DispatcherExecutionService { get; }
        ISubject<ChatPriceGridRefreshArgs> GridRefresh { get; }
        ChatPriceGridViewModelController Controller { get; }
        ChatPriceGridViewModel ViewModel { get; }
    }

    [TestFixture]
    public class ChatPriceGridViewModelControllerTests
    {
        private class ChatPriceGridViewModelControllerTestObjectBuilder
        {
            private List<ChatPriceCurveFilterItem> _curveFilterItemsLoaded;
            private List<ChatPriceCurveFilterItem> _curveFilterItems;
            private List<ChatPriceColumnFilterItem> _columnFilterItemsLoaded;
            private List<ChatPriceColumnFilterItem> _columnFilterItems;
            private List<ChatPriceCurveFilterGroup> _filterCurveGroupBuilderResult;
            private IList<BandInfo> _bandInfos;
            private ObservableCollection<ChatPriceRowViewModel> _chatPriceRows;
            private bool _canRemoveGrid;
            private bool _showCurveFilter;
            private bool? _isBusy;
            private string _busyText;

            public ChatPriceGridViewModelControllerTestObjectBuilder WithFilterCurveGroupBuilderResult(List<ChatPriceCurveFilterGroup> values)
            {
                _filterCurveGroupBuilderResult = values;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithCurveFilterItemsLoaded(List<ChatPriceCurveFilterItem> values)
            {
                _curveFilterItemsLoaded = values;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithCurveFilterItems(List<ChatPriceCurveFilterItem> values)
            {
                _curveFilterItems = values;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithColumnFilterItemsLoaded(List<ChatPriceColumnFilterItem> values)
            {
                _columnFilterItemsLoaded = values;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithColumnFilterItems(List<ChatPriceColumnFilterItem> values)
            {
                _columnFilterItems = values;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithBandInfos(IList<BandInfo> values)
            {
                _bandInfos = values;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithChatPriceRows(ObservableCollection<ChatPriceRowViewModel> values)
            {
                _chatPriceRows = values;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithCanRemoveGrid(bool value)
            {
                _canRemoveGrid = value;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithShowCurveFilter(bool value)
            {
                _showCurveFilter = value;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithIsBusy(bool value)
            {
                _isBusy = value;
                return this;
            }

            public ChatPriceGridViewModelControllerTestObjectBuilder WithBusyText(string value)
            {
                _busyText = value;
                return this;
            }

            public IChatPriceGridViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceGridViewModelControllerTestObjects>();

                // settings
                var settingsService = new Mock<IChatPriceSummarySettingsService>();

                testObjects.SetupGet(o => o.SettingsService)
                           .Returns(settingsService.Object);

                // curve filter load services
                var curveFilterItemsLoaded = new BehaviorSubject<List<ChatPriceCurveFilterItem>>(_curveFilterItemsLoaded);

                testObjects.SetupGet(o => o.CurveFilterItemsLoaded)
                           .Returns(curveFilterItemsLoaded);

                var curveFilterLoadedService = new Mock<ICurveFilterLoadedService>();

                curveFilterLoadedService.SetupGet(f => f.CurveFilter)
                                        .Returns(curveFilterItemsLoaded);

                testObjects.SetupGet(o => o.CurveFilterLoadedService)
                           .Returns(curveFilterLoadedService.Object);

                // column filter load services
                var columnFilterItemsLoaded = new BehaviorSubject<List<ChatPriceColumnFilterItem>>(_columnFilterItemsLoaded);

                testObjects.SetupGet(o => o.ColumnFilterItemsLoaded)
                           .Returns(columnFilterItemsLoaded);

                var columnFilterLoadedService = new Mock<IColumnFilterLoadedService>();

                columnFilterLoadedService.SetupGet(f => f.ColumnFilter)
                                         .Returns(columnFilterItemsLoaded);

                testObjects.SetupGet(o => o.ColumnFilterLoadedService)
                           .Returns(columnFilterLoadedService.Object);

                // filter dialog services
                var applyCurveFilterChanges = new Subject<Unit>();

                testObjects.SetupGet(o => o.ApplyCurveFilterChangesCommand)
                           .Returns(applyCurveFilterChanges);

                var curveFilterDialogService = new Mock<ICurveFilterDialogService>();

                curveFilterDialogService.SetupGet(d => d.ApplyFilterChangesCommand)
                                        .Returns(applyCurveFilterChanges);

                testObjects.SetupGet(o => o.CurveFilterDialogService)
                           .Returns(curveFilterDialogService.Object);

                var applyColumnFilterChanges = new Subject<Unit>();

                testObjects.SetupGet(o => o.ApplyColumnFilterChangesCommand)
                           .Returns(applyColumnFilterChanges);

                var columnFilterDialogService = new Mock<IColumnFilterDialogService>();

                columnFilterDialogService.SetupGet(d => d.ApplyFilterChangesCommand)
                                         .Returns(applyColumnFilterChanges);

                testObjects.SetupGet(o => o.ColumnFilterDialogService)
                           .Returns(columnFilterDialogService.Object);

                // dispatcher
                var dispatcherExecutionService = new Mock<IDispatcherExecutionService>();

                testObjects.SetupGet(o => o.DispatcherExecutionService)
                           .Returns(dispatcherExecutionService.Object);

                // grid refresh
                var refreshArgs = new Subject<ChatPriceGridRefreshArgs>();

                testObjects.SetupGet(o => o.GridRefresh)
                           .Returns(refreshArgs);

                var gridRefreshService = new Mock<IChatPriceGridRefreshService>();

                gridRefreshService.SetupGet(r => r.GridRefresh)
                                  .Returns(refreshArgs);

                testObjects.SetupGet(o => o.GridRefreshService)
                           .Returns(gridRefreshService.Object);

                // grid removal
                var gridRemovalService = new Mock<IChatPriceGridRemovalService>();

                testObjects.SetupGet(o => o.ChatPriceGridRemovalService)
                           .Returns(gridRemovalService.Object);

                var filterCurveGroupBuilder = new Mock<IChatPriceCurveFilterCurveGroupBuilder>();

                filterCurveGroupBuilder.Setup(b => b.GetCurveFilterGroups(It.IsAny<IList<ChatPriceCurveFilterItem>>()))
                                       .Returns(_filterCurveGroupBuilderResult);

                testObjects.SetupGet(o => o.FilterCurveGroupBuilder)
                           .Returns(filterCurveGroupBuilder.Object);

                var columnWidthService = new Mock<IChatPriceColumnWidthService>();

                testObjects.SetupGet(o => o.ColumnWidthService)
                           .Returns(columnWidthService.Object);

                var controller = new ChatPriceGridViewModelController(settingsService.Object,
                                                                      curveFilterLoadedService.Object,
                                                                      columnFilterLoadedService.Object,
                                                                      curveFilterDialogService.Object,
                                                                      columnFilterDialogService.Object,
                                                                      gridRefreshService.Object,
                                                                      columnWidthService.Object,
                                                                      dispatcherExecutionService.Object,
                                                                      TestMocks.GetSchedulerProvider().Object)
                {
                    ChatPriceCurveFilterCurveGroupBuilder = filterCurveGroupBuilder.Object
                };

                controller.ViewModel.BandInfos = _bandInfos;
                controller.ViewModel.ChatPriceRows = _chatPriceRows;
                controller.ViewModel.CanRemoveGrid = _canRemoveGrid;
                controller.ViewModel.ChatPriceCurveFilter.FilterItems = _curveFilterItems;
                controller.ViewModel.ChatPriceColumnFilter.FilterItems = _columnFilterItems;
                controller.ViewModel.ChatPriceCurveFilter.ShowFilter = _showCurveFilter;
               
                controller.ViewModel.BusyText = _busyText;

                if (_isBusy.HasValue)
                {
                    controller.ViewModel.IsBusy = _isBusy.Value;
                }

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetViewModels_From_ChatPriceGridFilters()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.IsNotNull(testObjects.ViewModel.ChatPriceColumnFilter);
            Assert.IsNotNull(testObjects.ViewModel.ChatPriceCurveFilter);
        }

        [Test]
        public void ShouldAttachDialogServices()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.CurveFilterDialogService)
                .Verify(d => d.AttachFilterDialog(testObjects.ViewModel.ChatPriceCurveFilter));

            Mock.Get(testObjects.ColumnFilterDialogService)
                .Verify(d => d.AttachFilterDialog(testObjects.ViewModel.ChatPriceColumnFilter));
        }

        [Test]
        public void ShouldSetIsBusyTrue_On_Load()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
        }

        [Test]
        public void ShouldInitializeLoadServices_When_Initialize_With_PriceGridId()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Initialize(2, 1, testObjects.ChatPriceGridRemovalService);

            // ASSERT
            Assert.That(testObjects.ViewModel.MarketsId, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.PriceGridId, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.PriceGridName, Is.EqualTo("ICE Chat Prices - 1"));

            Mock.Get(testObjects.CurveFilterLoadedService)
                .Verify(f => f.Initialize());

            Mock.Get(testObjects.ColumnFilterLoadedService)
                .Verify(f => f.Initialize());
        }

        [Test]
        public void ShouldInitializeLoadServicesWithSettings_When_Initialize_With_Settings()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            var settings = new ChatPriceGridSettings
            {
                PriceGridId = 1,
                Name = "Prices"
            };

            // ACT
            testObjects.Controller.Initialize(2, settings, testObjects.ChatPriceGridRemovalService);

            // ASSERT
            Assert.That(testObjects.ViewModel.MarketsId, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.PriceGridId, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.PriceGridName, Is.EqualTo("Prices"));

            Mock.Get(testObjects.CurveFilterLoadedService)
                .Verify(f => f.Initialize(settings));

            Mock.Get(testObjects.ColumnFilterLoadedService)
                .Verify(f => f.Initialize(settings));
        }

        [Test]
        public void ShouldNotRefreshCurveFilterItems_When_CurveFiltersLoaded_With_ColumnFiltersNotLoaded()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            var curveFilterItems = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
            };

            // ACT
            testObjects.CurveFilterItemsLoaded.OnNext(curveFilterItems);

            // ASSERT
            Mock.Get(testObjects.CurveFilterDialogService)
                .Verify(d => d.RefreshFilterItems(It.IsAny<IList<ChatPriceCurveFilterItem>>()), Times.Never);
        }

        [Test]
        public void ShouldNotRefreshColumnFilterItems_When_ColumnFiltersLoaded_With_CurveFiltersNotLoaded()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            var columnFilterItems = new List<ChatPriceColumnFilterItem>()
            {
                new(ColumnType.BidPrice, "BID", true)
            };

            // ACT
            testObjects.ColumnFilterItemsLoaded.OnNext(columnFilterItems);

            // ASSERT
            Mock.Get(testObjects.ColumnFilterDialogService)
                .Verify(b => b.RefreshFilterItems(It.IsAny<IList<ChatPriceColumnFilterItem>>()), Times.Never);
        }

        [Test]
        public void ShouldRefreshFilterItems_On_CurveAndColumnFiltersLoaded()
        {
            var curveFilterGroups = new List<ChatPriceCurveFilterGroup>
            {
                new(new CurveGroupTestObjectBuilder().Crude())
            };

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder()
                             .WithFilterCurveGroupBuilderResult(curveFilterGroups)
                             .Build();

            var curveFilterItems = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
            };

            var columnFilterItems = new List<ChatPriceColumnFilterItem>()
            {
                new(ColumnType.BidPrice, "BID", true)
            };

            // ACT
            testObjects.CurveFilterItemsLoaded.OnNext(curveFilterItems);
            testObjects.ColumnFilterItemsLoaded.OnNext(columnFilterItems);

            // ASSERT
            Mock.Get(testObjects.CurveFilterDialogService)
                .Verify(d => d.RefreshFilterItems(It.Is<IList<ChatPriceCurveFilterItem>>(i => i.Count == 1)), Times.Once);

            Mock.Get(testObjects.FilterCurveGroupBuilder)
                .Verify(b => b.GetCurveFilterGroups(It.Is<IList<ChatPriceCurveFilterItem>>(i => i.Count == 1)), Times.Once);

            Assert.That(testObjects.ViewModel.ChatPriceCurveFilter.FilterGroups.Count, Is.EqualTo(1));

            Mock.Get(testObjects.ColumnFilterDialogService)
                .Verify(b => b.RefreshFilterItems(It.Is<IList<ChatPriceColumnFilterItem>>(i => i.Count == 1)), Times.Once);

            Assert.That(testObjects.ViewModel.ChatPriceColumnFilter.FilterItems.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldRefreshCurveFiltersOnly_On_CurveFiltersUpdate_With_AllFiltersLoaded()
        {
            var curveFilterItems = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
            };

            var columnFilterItems = new List<ChatPriceColumnFilterItem>
            {
                new(ColumnType.BidPrice, "BID", true)
            };

            var curveFilterGroups = new List<ChatPriceCurveFilterGroup>
            {
                new(new CurveGroupTestObjectBuilder().Crude())
            };

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithCurveFilterItemsLoaded(curveFilterItems)
                                                                                     .WithColumnFilterItemsLoaded(columnFilterItems)
                                                                                     .WithFilterCurveGroupBuilderResult(curveFilterGroups)
                                                                                     .Build();

            Mock.Get(testObjects.ColumnFilterDialogService).Invocations.Clear();
            Mock.Get(testObjects.CurveFilterDialogService).Invocations.Clear();

            // ACT
            testObjects.CurveFilterItemsLoaded.OnNext(curveFilterItems);

            // ASSERT
            Mock.Get(testObjects.CurveFilterDialogService)
                .Verify(d => d.RefreshFilterItems(It.Is<IList<ChatPriceCurveFilterItem>>(i => i.Count == 1)), Times.Once);

            Mock.Get(testObjects.ColumnFilterDialogService)
                .Verify(b => b.RefreshFilterItems(It.IsAny<IList<ChatPriceColumnFilterItem>>()), Times.Never);
        }

        [Test]
        public void ShouldShowCurveFilter_On_CurveFilterLoaded_With_NoneSelected()
        {
            var columnFilterItems = new List<ChatPriceColumnFilterItem>();

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithColumnFilterItemsLoaded(columnFilterItems)
                                                                                     .Build();

            var filterItems = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
            };

            // ACT
            testObjects.CurveFilterItemsLoaded.OnNext(filterItems);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatPriceCurveFilter.ShowFilter, Is.True);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldLoadGridFilter_On_CurveFilterLoaded_With_ItemSelected()
        {
            var columnFilterItems = new List<ChatPriceColumnFilterItem>();
            var bandInfos = new List<BandInfo> {new(BandType.Price)};
            var rows = new ObservableCollection<ChatPriceRowViewModel> {new(Mock.Of<ITenor>())};

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithColumnFilterItemsLoaded(columnFilterItems)
                                                                                     .WithBandInfos(bandInfos)
                                                                                     .WithChatPriceRows(rows)
                                                                                     .Build();

            var filterItems = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
                {
                    IsSelected = true
                }
            };

            // ACT
            testObjects.CurveFilterItemsLoaded.OnNext(filterItems);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);
            Assert.IsNull(testObjects.ViewModel.BandInfos);
            Assert.IsNull(testObjects.ViewModel.ChatPriceRows);

            Mock.Get(testObjects.GridRefreshService)
                .Verify(r => r.BuildGrid(It.Is<IList<ChatPriceCurveFilterItem>>(i => i.Count == 1 && i[0].Id == 1),
                                         testObjects.DispatcherExecutionService));

            Mock.Get(testObjects.DispatcherExecutionService)
                .Verify(d => d.Stop());

            Assert.That(testObjects.ViewModel.ChatPriceCurveFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldSaveSettings_And_LoadGridFilter_On_ApplyCurveFilterChangesCommand()
        {
            var filterItems = new List<ChatPriceCurveFilterItem>
                              {
                                  new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
                                  {
                                      IsSelected = true
                                  }
                              };

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithCurveFilterItems(filterItems)
                                                                                     .Build();

            var settings = new ChatPriceGridSettings
            {
                PriceGridId = 2
            };

            // ACT
            testObjects.Controller.Initialize(3, settings, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ApplyCurveFilterChangesCommand.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.SaveMarketsFilter(3, 2, It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 1)));

            Mock.Get(testObjects.GridRefreshService)
                .Verify(r => r.BuildGrid(It.Is<IList<ChatPriceCurveFilterItem>>(i => i.Count == 1 && i[0].Id == 1),
                                         testObjects.DispatcherExecutionService));

            Mock.Get(testObjects.DispatcherExecutionService)
                .Verify(d => d.Stop());
        }

        [Test]
        public void ShouldSaveSettings_And_SetBandInfos_On_ApplyColumnFilterChangesCommand()
        {
            var columnInfos = new List<ColumnInfo>
            {
                new(ColumnType.AskPrice, 1, null, null, false){IsVisible = false},
                new(ColumnType.BidPrice, 1, null, null, false){IsVisible = true}
            };

            var bandInfos = new List<BandInfo>
            {
                new(BandType.Price) {ColumnInfos = columnInfos}
            };

            var columnFilterItems = new List<ChatPriceColumnFilterItem>
            {
                new(ColumnType.AskPrice, "ASK", true),
                new(ColumnType.BidPrice, "BID", false)
            };

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithBandInfos(bandInfos)
                                                                                     .WithColumnFilterItems(columnFilterItems)
                                                                                     .Build();

            var settings = new ChatPriceGridSettings
            {
                PriceGridId = 2
            };

            testObjects.Controller.Initialize(3, settings, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ApplyColumnFilterChangesCommand.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.SaveColumnsFilter(3, 2, It.Is<IList<ColumnType>>(cols => cols.Count == 1 && cols[0] == ColumnType.AskPrice)));

            Assert.That(columnInfos[0].IsVisible, Is.True);
            Assert.That(columnInfos[1].IsVisible, Is.False);
        }

        [Test]
        public void ShouldSaveSettings_And_On_ApplyColumnFilterChangesCommand_With_BandInfosNull()
        {
            var columnFilterItems = new List<ChatPriceColumnFilterItem>
            {
                new(ColumnType.AskPrice, "ASK", true),
                new(ColumnType.BidPrice, "BID", false)
            };

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithBandInfos(null)
                                                                                     .WithColumnFilterItems(columnFilterItems)
                                                                                     .Build();

            var settings = new ChatPriceGridSettings
            {
                PriceGridId = 2
            };

            testObjects.Controller.Initialize(3, settings, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ApplyColumnFilterChangesCommand.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.SaveColumnsFilter(3, 2, It.Is<IList<ColumnType>>(cols => cols.Count == 1 && cols[0] == ColumnType.AskPrice)));
        }

        [Test]
        public void ShouldSavePriceGridName_On_PriceGridNameChanged()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Initialize(2, 1, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ViewModel.PriceGridName = "price-grid";

            // ASSERT
            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.SavePriceGridName(2, 1, "price-grid"));
        }

        [Test]
        public void ShouldDisplayGridWithSettings_On_GridRefresh()
        {
            var columnFilterItems = new List<ChatPriceColumnFilterItem>
            {
                new(ColumnType.AskPrice, "ASK", true),
                new(ColumnType.BidPrice, "BID", false)
            };

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithColumnFilterItems(columnFilterItems)
                                                                                     .WithIsBusy(true)
                                                                                     .WithBusyText("busy")
                                                                                     .Build();
            var columnInfos = new List<ColumnInfo>
            {
                new(ColumnType.AskPrice, 1, null, null, false){IsVisible = false},
                new(ColumnType.BidPrice, 1, null, null, false){IsVisible = true}
            };

            var bandInfos = new List<BandInfo>
            {
                new(BandType.Tenor),
                new(BandType.Price) {ColumnInfos = columnInfos}
            };

            var rows = new[] { new ChatPriceRowViewModel(new MonthlyTenor(2021, 1)) };

            var refreshArgs = new ChatPriceGridRefreshArgs(bandInfos, rows);

            var settings = new ChatPriceGridSettings
            {
                PriceGridId = 2
            };

            testObjects.Controller.Initialize(3, settings, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.GridRefresh.OnNext(refreshArgs);

            // ASSERT
            Assert.That(testObjects.ViewModel.PriceGridLoaded, Is.True);
            Assert.That(testObjects.ViewModel.ChatPriceSummaryReady, Is.True);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);
            Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.ChatPriceRows.Count, Is.EqualTo(1));

            Mock.Get(testObjects.ColumnWidthService)
                .Verify(cws => cws.ApplyColumnWidths(3, 2, It.Is<IList<BandInfo>>(b => b.Count == 1)));

            Mock.Get(testObjects.ColumnWidthService)
                .Verify(cws => cws.MonitorColumnWidthChanges(3,
                                                             2,
                                                             It.Is<IList<BandInfo>>(b => b.Count == 1),
                                                             It.IsAny<IScheduler>()));

            Mock.Get(testObjects.DispatcherExecutionService).Verify(d => d.Start());
        }

        [Test]
        public void ShouldEnableRemoveChatPriceGrid_And_CanRemoveFilters_On_CanRemoveGridChanged()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Initialize(3, 2, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ViewModel.CanRemoveGrid = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.RemoveChatPriceGridCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.ChatPriceCurveFilter.CanRemoveFilter, Is.True);
            Assert.That(testObjects.ViewModel.ChatPriceColumnFilter.CanRemoveFilter, Is.True);
        }

        [Test]
        public void ShouldRemoveChatPriceGrid_On_RemoveChatPriceGridCommand()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Initialize(3, 2, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ViewModel.RemoveChatPriceGridCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ChatPriceGridRemovalService)
                .Verify(r => r.RemoveGrid(testObjects.ViewModel));
        }

        [Test]
        public void ShouldRemoveChatPriceGrid_When_CurveFilterClosed_With_NoItemsSelected_And_CanRemoveGridTrue()
        {
            var filterItems = new List<ChatPriceCurveFilterItem>
                              {
                                  new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
                                  {
                                      OriginalIsSelected = false
                                  }
                              };

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithCurveFilterItems(filterItems)
                                                                                     .WithCanRemoveGrid(true)
                                                                                     .WithShowCurveFilter(true)
                                                                                     .Build();

            testObjects.Controller.Initialize(3, 2, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ViewModel.ChatPriceCurveFilter.ShowFilter = false;

            // ASSERT
            Mock.Get(testObjects.ChatPriceGridRemovalService)
                .Verify(r => r.RemoveGrid(testObjects.ViewModel));
        }

        [Test]
        public void ShouldNotRemoveChatPriceGrid_When_CurveFilterClosed_With_ItemsSelected_And_CanRemoveGridTrue()
        {
            var filterItems = new List<ChatPriceCurveFilterItem>
                              {
                                  new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
                                  {
                                      OriginalIsSelected = true
                                  }
                              };
            
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithCurveFilterItems(filterItems)
                                                                                     .WithCanRemoveGrid(true)
                                                                                     .WithShowCurveFilter(true)
                                                                                     .Build();

            testObjects.Controller.Initialize(3, 2, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ViewModel.ChatPriceCurveFilter.ShowFilter = false;

            // ASSERT
            Mock.Get(testObjects.ChatPriceGridRemovalService)
                .Verify(r => r.RemoveGrid(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldNotRemoveChatPriceGrid_When_CurveFilterClosed_With_NoItemsSelected_And_CanRemoveGridFalse()
        {
            var filterItems = new List<ChatPriceCurveFilterItem>
                              {
                                  new(1, "curve", "name", new CurveGroupTestObjectBuilder().Crude(), CurveRegion.Europe)
                                  {
                                      OriginalIsSelected = true
                                  }
                              };

            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().WithCurveFilterItems(filterItems)
                                                                                     .WithCanRemoveGrid(false)
                                                                                     .WithShowCurveFilter(true)
                                                                                     .Build();

            testObjects.Controller.Initialize(3, 2, testObjects.ChatPriceGridRemovalService);

            // ACT
            testObjects.ViewModel.ChatPriceCurveFilter.ShowFilter = false;

            // ASSERT
            Mock.Get(testObjects.ChatPriceGridRemovalService)
                .Verify(r => r.RemoveGrid(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldDisposeServices_On_Dispose()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.CurveFilterLoadedService).Verify(f => f.Dispose());
            Mock.Get(testObjects.CurveFilterDialogService).Verify(f => f.Dispose());
            Mock.Get(testObjects.ColumnFilterDialogService).Verify(f => f.Dispose());
            Mock.Get(testObjects.ColumnWidthService).Verify(c => c.Dispose());
            Mock.Get(testObjects.GridRefreshService).Verify(r => r.Dispose());
            Mock.Get(testObjects.ColumnFilterLoadedService).Verify(f => f.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new ChatPriceGridViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.CurveFilterLoadedService).Verify(f => f.Dispose(), Times.Once);
        }
    }
}
