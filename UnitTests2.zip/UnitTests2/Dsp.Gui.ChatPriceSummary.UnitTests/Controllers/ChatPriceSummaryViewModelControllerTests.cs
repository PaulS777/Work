﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Subjects;
using Dsp.Gui.ChatPriceSummary.Controllers;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Controllers
{
    public interface IChatPriceSummaryViewModelControllerTestObjects
    {
        IChatPriceMarketsViewModelController ChatPriceMarketsViewModelController { get; }
        ChatPriceMarketsViewModel ChatPriceMarketsViewModel { get; }
        IChatPriceSummaryToolBarService ToolBarService { get; }
        IChatPriceMarketsRemovalService ChatPriceMarketsRemovalService { get; }
        ISubject<Unit> ToolBarAddPriceGrid { get; }
        IChatPriceSummarySettingsService ChatPriceSummarySettingsService { get; }
        IChatPriceMarketsBuilder ChatPriceMarketsBuilder { get; }
        ISubject<SystemRunConnectState> ConnectState { get; }
        ISubject<ChatPriceSummarySettings> ChatPriceSummarySettings { get; }
        ChatPriceSummaryViewModel ViewModel { get; }
        ChatPriceSummaryViewModelController Controller { get; }
    }

    public class ChatPriceSummaryViewModelControllerTests
    {
        private class ChatPriceSummaryViewModelControllerTestObjectBuilder
        {
            private SystemRunConnectState _connectState;
            private ChatPriceSummarySettings _chatPriceSummarySettings;
            private ChatPriceMarketsViewModel _chatPriceMarketsViewModel;
            private List<ChatPriceMarketsViewModel> _chatPriceMarketsViewModels;
            private ChatPriceGridSettings _newChatPriceGridSettings;
            private ChatPriceMarketsSettings _newChatPriceMarketsSettings;

            public ChatPriceSummaryViewModelControllerTestObjectBuilder WithConnectState(SystemRunConnectState value)
            {
                _connectState = value;
                return this;
            }

            public ChatPriceSummaryViewModelControllerTestObjectBuilder WithChatPriceSummarySettings(ChatPriceSummarySettings value)
            {
                _chatPriceSummarySettings = value;
                return this;
            }

            public ChatPriceSummaryViewModelControllerTestObjectBuilder WithChatPriceMarketsBuilderResult(ChatPriceMarketsViewModel value)
            {
                _chatPriceMarketsViewModel = value;
                return this;
            }

            public ChatPriceSummaryViewModelControllerTestObjectBuilder WithChatPriceMarketsBuilderResults(List<ChatPriceMarketsViewModel> values)
            {
                _chatPriceMarketsViewModels = values;
                return this;
            }

            public ChatPriceSummaryViewModelControllerTestObjectBuilder WithNewChatPriceGridSettings(ChatPriceGridSettings value)
            {
                _newChatPriceGridSettings = value;
                return this;
            }

            public ChatPriceSummaryViewModelControllerTestObjectBuilder WithNewChatPriceMarketsSettings(ChatPriceMarketsSettings value)
            {
                _newChatPriceMarketsSettings = value;
                return this;
            }

            public IChatPriceSummaryViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceSummaryViewModelControllerTestObjects>();

                var connectState = new BehaviorSubject<SystemRunConnectState>(_connectState);

                testObjects.SetupGet(o => o.ConnectState)
                           .Returns(connectState);

                var connectionRunStateMonitor = new Mock<IConnectionRunStateMonitor>();

                connectionRunStateMonitor.SetupGet(s => s.RunState)
                                         .Returns(connectState);

                var settings = new BehaviorSubject<ChatPriceSummarySettings>(_chatPriceSummarySettings);

                testObjects.SetupGet(o => o.ChatPriceSummarySettings)
                           .Returns(settings);

                var settingsService = new Mock<IChatPriceSummarySettingsService>();

                settingsService.SetupGet(o => o.ChatPriceSummarySettings)
                               .Returns(settings);

                settingsService.Setup(o => o.CreateNewPriceGrid(It.IsAny<int>()))
                               .Returns(_newChatPriceGridSettings);

                settingsService.Setup(o => o.CreateNewChatPriceMarkets())
                               .Returns(_newChatPriceMarketsSettings);

                testObjects.SetupGet(o => o.ChatPriceSummarySettingsService)
                           .Returns(settingsService.Object);

                var chatPriceMarketsController = new Mock<IChatPriceMarketsViewModelController>();

                testObjects.SetupGet(o => o.ChatPriceMarketsViewModelController)
                           .Returns(chatPriceMarketsController.Object);

                var chatPriceMarketsViewModel = new ChatPriceMarketsViewModel(chatPriceMarketsController.Object);

                testObjects.SetupGet(o => o.ChatPriceMarketsViewModel)
                           .Returns(chatPriceMarketsViewModel);

                var chatPriceMarketsBuilder = new Mock<IChatPriceMarketsBuilder>();

                if (_chatPriceMarketsViewModel != null)
                {
                    chatPriceMarketsBuilder.Setup(b => b.GetMarketsFromSettings(It.IsAny<ChatPriceMarketsSettings>()))
                                           .Returns(_chatPriceMarketsViewModel);
                }

                if (_chatPriceMarketsViewModels != null)
                {
                    chatPriceMarketsBuilder.SetupSequence(b => b.GetMarketsFromSettings(It.IsAny<ChatPriceMarketsSettings>()))
                                           .Returns(_chatPriceMarketsViewModels[0])
                                           .Returns(_chatPriceMarketsViewModels[1]);
                }

                testObjects.SetupGet(o => o.ChatPriceMarketsBuilder)
                           .Returns(chatPriceMarketsBuilder.Object);

                var toolBarAddPriceGrid = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarAddPriceGrid)
                           .Returns(toolBarAddPriceGrid);

                var toolBar = new Mock<IChatPriceSummaryToolBarService>();

                toolBar.SetupGet(tb => tb.AddPriceGrid)
                       .Returns(toolBarAddPriceGrid);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBar.Object);

                var chatPriceMarketsRemovalService = new Mock<IChatPriceMarketsRemovalService>();

                testObjects.SetupGet(o => o.ChatPriceMarketsRemovalService)
                           .Returns(chatPriceMarketsRemovalService.Object);

                var controller = new ChatPriceSummaryViewModelController(toolBar.Object,
                                                                         settingsService.Object,
                                                                         connectionRunStateMonitor.Object,
                                                                         chatPriceMarketsBuilder.Object,
                                                                         chatPriceMarketsRemovalService.Object,
                                                                         TestMocks.GetSchedulerProvider().Object);
                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeServices()
        {
            // ACT
            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .Verify(s => s.LoadSettings());

            Mock.Get(testObjects.ChatPriceMarketsRemovalService)
                .Verify(m => m.RegisterSummary(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSubscribeSettings_On_ConnectStateConnected()
        {
            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ConnectState.OnNext(SystemRunConnectState.Connected);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .VerifyGet(cps => cps.ChatPriceSummarySettings);
        }

        [Test]
        public void ShouldSubscribeSettings_On_ConnectStateReconnected()
        {
            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ConnectState.OnNext(SystemRunConnectState.Reconnected);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .VerifyGet(cps => cps.ChatPriceSummarySettings);
        }

        [TestCase(SystemRunConnectState.NotSet)]
        [TestCase(SystemRunConnectState.FailedStartup)]
        [TestCase(SystemRunConnectState.Reconnecting)]
        public void ShouldNotSubscribeSettings_On_ConnectStateNotConnected(SystemRunConnectState state)
        {
            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ConnectState.OnNext(state);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .VerifyGet(cps => cps.ChatPriceSummarySettings, Times.Never);
        }

        [Test]
        public void ShouldCreateChatPriceMarkets_And_SetSelected_From_Settings_With_Connected()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1
                    },
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 2
                    }
                }
            };

            var chatPriceMarkets = new List<ChatPriceMarketsViewModel>
            {
                new(Mock.Of<IDisposable>()) {MarketsId = 1},
                new(Mock.Of<IDisposable>()) {MarketsId = 2}
            };

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResults(chatPriceMarkets)
                                                                                        .Build();

            // ACT
            testObjects.ChatPriceSummarySettings.OnNext(settings);

            // ASSERT
            Mock.Get(testObjects.ChatPriceMarketsBuilder)
                .Verify(b => b.GetMarketsFromSettings(It.Is<ChatPriceMarketsSettings>(s => s.MarketsId == 1)), Times.Once);

            Assert.That(testObjects.ViewModel.ChatPriceMarkets.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[0].MarketsId, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[1].MarketsId, Is.EqualTo(2));

            Assert.AreSame(testObjects.ViewModel.ChatPriceMarkets[0], testObjects.ViewModel.SelectedChatPriceMarkets);
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[0].IsSelected, Is.True);
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[1].IsSelected, Is.False);
        }

        [Test]
        public void ShouldSetSelectedChatPriceMarkets_When_MarketsIsSelectedTrue_With_LoadedFromSettings()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings(),
                        }
                    },
                    new ChatPriceMarketsSettings
                    {
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings(),
                        }
                    }
                }
            };

            var chatPriceMarkets = new List<ChatPriceMarketsViewModel>
            {
                new(Mock.Of<IDisposable>()),
                new(Mock.Of<IDisposable>())
            };

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResults(chatPriceMarkets)
                                                                                        .Build();

            testObjects.ChatPriceSummarySettings.OnNext(settings);

            // ACT
            testObjects.ViewModel.ChatPriceMarkets[1].IsSelected = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedChatPriceMarkets, Is.EqualTo(testObjects.ViewModel.ChatPriceMarkets[1]));
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[0].IsSelected, Is.False);
        }

        [Test]
        public void ShouldDisableToolBarAddPriceGrid_When_SelectedPriceGridNull()
        {
            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>());

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithChatPriceMarketsBuilderResult(chatPriceMarkets)
                                                                                        .Build();
            // ACT
            testObjects.ConnectState.OnNext(SystemRunConnectState.Connected);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanAddPriceGrid(false));

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanAddPriceGrid(true), Times.Never);
        }

        [Test]
        public void ShouldEnableToolBarAddPriceGrid_On_SelectedPriceGridNotNull()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings()
                }
            };

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>());

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResult(chatPriceMarkets)
                                                                                        .Build();
            // ACT
            testObjects.ChatPriceSummarySettings.OnNext(settings);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanAddPriceGrid(true));
        }

        [Test]
        public void ShouldAddNewChatPriceGrid_On_ToolBarAddPriceGrid()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1
                    }
                }
            };

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1
            };

            var priceGridSettings = new ChatPriceGridSettings
            {
                PriceGridId = 2
            };

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResult(chatPriceMarkets)
                                                                                        .WithNewChatPriceGridSettings(priceGridSettings)
                                                                                        .Build();

            testObjects.ChatPriceSummarySettings.OnNext(settings);

            // ACT
            testObjects.ToolBarAddPriceGrid.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ChatPriceMarketsBuilder)
                .Verify(b => b.AddChatPriceGridToMarkets(2, testObjects.ViewModel.SelectedChatPriceMarkets));
        }

        [Test]
        public void ShouldAddNewChatPriceMarkets_And_SetSelected_On_AddChatPriceMarketsCommand()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1
                    }
                }
            };

            var chatPriceMarkets = new List<ChatPriceMarketsViewModel>
            {
                new(Mock.Of < IDisposable >()) { MarketsId = 1 },
                new(Mock.Of < IDisposable >()) { MarketsId = 2 }
            };

            var marketsSettings = new ChatPriceMarketsSettings
            {
                MarketsId = 2
            };

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResults(chatPriceMarkets)
                                                                                        .WithNewChatPriceMarketsSettings(marketsSettings)
                                                                                        .Build();
            testObjects.ChatPriceSummarySettings.OnNext(settings);

            // ACT
            testObjects.ViewModel.AddChatPriceMarketsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .Verify(s => s.CreateNewChatPriceMarkets());

            Mock.Get(testObjects.ChatPriceMarketsBuilder)
                .Verify(b => b.GetMarketsFromSettings(marketsSettings));

            Assert.That(testObjects.ViewModel.ChatPriceMarkets.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[0].MarketsId, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[1].MarketsId, Is.EqualTo(2));

            Assert.AreSame(chatPriceMarkets[1], testObjects.ViewModel.SelectedChatPriceMarkets);
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[0].IsSelected, Is.False);
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[1].IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetSelectedChatPriceMarkets_When_MarketsIsSelectedTrue_With_AddedMarkets()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1
                    }
                }
            };

            var chatPriceMarkets = new List<ChatPriceMarketsViewModel>
            {
                new(Mock.Of < IDisposable >()) { MarketsId = 1 },
                new(Mock.Of < IDisposable >()) { MarketsId = 2 }
            };

            var marketsSettings = new ChatPriceMarketsSettings
            {
                MarketsId = 2
            };

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResults(chatPriceMarkets)
                                                                                        .WithNewChatPriceMarketsSettings(marketsSettings)
                                                                                        .Build();
            testObjects.ChatPriceSummarySettings.OnNext(settings);

            testObjects.ViewModel.AddChatPriceMarketsCommand.Execute();

            testObjects.ViewModel.ChatPriceMarkets[0].IsSelected = true;

            // ACT
            testObjects.ViewModel.ChatPriceMarkets[1].IsSelected = true;


            // ASSERT
            Assert.AreSame(chatPriceMarkets[1], testObjects.ViewModel.SelectedChatPriceMarkets);
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[0].IsSelected, Is.False);
            Assert.That(testObjects.ViewModel.ChatPriceMarkets[1].IsSelected, Is.True);
        }

        [Test]
        public void ShouldDisposeAndClearMarkets_On_Dispose()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings()
                }
            };

            var chatPriceMarketsController = new Mock<IDisposable>();
            var chatPriceMarkets = new ChatPriceMarketsViewModel(chatPriceMarketsController.Object);

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResult(chatPriceMarkets)
                                                                                        .WithChatPriceSummarySettings(settings)
                                                                                        .Build();
            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            chatPriceMarketsController.Verify(c => c.Dispose());

            Mock.Get(testObjects.ChatPriceMarketsRemovalService)
                .Verify(r => r.UnRegisterSummary(testObjects.ViewModel));

            Assert.That(testObjects.ViewModel.ChatPriceMarkets.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldNotAddNewChatPriceGrid_When_Disposed()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1
                    }
                }
            };

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>());

            var priceGridSettings = new ChatPriceGridSettings
            {
                PriceGridId = 2
            };

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResult(chatPriceMarkets)
                                                                                        .WithNewChatPriceGridSettings(priceGridSettings)
                                                                                        .Build();

            testObjects.ChatPriceSummarySettings.OnNext(settings);

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ToolBarAddPriceGrid.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ChatPriceMarketsBuilder)
                .Verify(b => b.AddChatPriceGridToMarkets(It.IsAny<int>(), 
                                                         testObjects.ViewModel.SelectedChatPriceMarkets), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings()
                }
            };

            var chatPriceMarketsController = new Mock<IDisposable>();
            var chatPriceMarkets = new ChatPriceMarketsViewModel(chatPriceMarketsController.Object);

            var testObjects = new ChatPriceSummaryViewModelControllerTestObjectBuilder().WithConnectState(SystemRunConnectState.Connected)
                                                                                        .WithChatPriceMarketsBuilderResult(chatPriceMarkets)
                                                                                        .WithChatPriceSummarySettings(settings)
                                                                                        .Build();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            chatPriceMarketsController.Verify(c => c.Dispose());
            Assert.That(testObjects.ViewModel.ChatPriceMarkets.Count, Is.EqualTo(0));
        }
    }
}
