﻿using System;
using Dsp.Gui.ChatPriceSummary.Controllers;
using Dsp.Gui.ChatPriceSummary.Controllers.Filter;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Controllers
{
    public interface IChatPriceMarketsViewModelControllerTestObjects
    {
        IChatPriceFilterDialogViewModelController ChatPriceFilterDialogViewModelController { get; }
        IChatPriceMarketsRemovalService ChatPriceMarketsRemovalService { get; }
        IChatPriceSummarySettingsService SettingsService { get; }
        ChatPriceMarketsViewModel ViewModel { get; }
        ChatPriceMarketsViewModelController Controller { get; }
    }

    [TestFixture]
    public class ChatPriceMarketsViewModelControllerTests
    {
        private class ChatPriceMarketsViewModelControllerTestObjectBuilder
        {
            private ChatPriceFilterDialogViewModel _chatPriceFilterDialog;
            private int _marketsId;

            public ChatPriceMarketsViewModelControllerTestObjectBuilder WithChatPriceFilterDialog(ChatPriceFilterDialogViewModel value)
            {
                _chatPriceFilterDialog = value;
                return this;
            }

            public ChatPriceMarketsViewModelControllerTestObjectBuilder WithMarketsId(int value)
            {
                _marketsId = value;
                return this;
            }

            public IChatPriceMarketsViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceMarketsViewModelControllerTestObjects>();

                var chatPriceFilterDialogViewModelController = new Mock<IChatPriceFilterDialogViewModelController>();

                chatPriceFilterDialogViewModelController.SetupGet(c => c.ViewModel)
                                                        .Returns(_chatPriceFilterDialog);

                testObjects.SetupGet(o => o.ChatPriceFilterDialogViewModelController)
                           .Returns(chatPriceFilterDialogViewModelController.Object);

                var chatPriceMarketsRemovalService = new Mock<IChatPriceMarketsRemovalService>();

                testObjects.SetupGet(o => o.ChatPriceMarketsRemovalService)
                           .Returns(chatPriceMarketsRemovalService.Object);

                var settingsService = new Mock<IChatPriceSummarySettingsService>();

                testObjects.SetupGet(o => o.SettingsService)
                           .Returns(settingsService.Object);

                var controller = new ChatPriceMarketsViewModelController(chatPriceFilterDialogViewModelController.Object, 
                                                                         settingsService.Object,
                                                                         chatPriceMarketsRemovalService.Object);

                controller.ViewModel.MarketsId = _marketsId;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeViewModel_And_RegisterWithGridRemovalService()
        {
            var filterDialog = new ChatPriceFilterDialogViewModel();

            var gridRemovalService = new Mock<IChatPriceGridRemovalService>();

            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().WithChatPriceFilterDialog(filterDialog)
                                                                                        .Build();

            // ACT
            testObjects.Controller.Initialize(1, "markets", gridRemovalService.Object);

            // ASSERT
            Assert.IsNotNull(testObjects.ViewModel.ChatPriceGrids);
            Assert.AreSame(filterDialog, testObjects.ViewModel.ChatPriceFilterDialog);
            Assert.AreEqual(1, testObjects.ViewModel.MarketsId);
            Assert.AreEqual("markets", testObjects.ViewModel.Name);

            gridRemovalService.Verify(g => g.RegisterMarkets(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSetIsSelectedTrue_On_SetSelectedCommand()
        {
            var filterDialog = new ChatPriceFilterDialogViewModel();

            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().WithChatPriceFilterDialog(filterDialog)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.SetSelectedCommand.Execute();

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsSelected);
        }

        [Test]
        public void ShouldSetFilterDialogIsMarketsSelected_On_IsSelected()
        {
            var filterDialog = new ChatPriceFilterDialogViewModel();

            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().WithChatPriceFilterDialog(filterDialog)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.IsSelected = true;

            // ASSERT
            Assert.IsTrue(filterDialog.IsMarketsSelected);
        }

        [Test]
        public void ShouldRemoveMarkets_On_RemoveMarketsCommand()
        {
            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.RemoveMarketsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ChatPriceMarketsRemovalService)
                .Verify(r => r.RemoveMarkets(testObjects.ViewModel));
        }

        [Test]
        public void ShouldSaveSettings_On_MarketsNameChanged()
        {
            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().WithMarketsId(1)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.Name = "markets";

            // ASSERT
            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.SaveMarketsName(1, "markets"));
        }

        [Test]
        public void ShouldEnableRemoveMarketsCommand_When_CanRemoveMarketsTrue()
        {
            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanRemoveMarkets = true;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.RemoveMarketsCommand.CanExecute());
        }

        [Test] 
        public void ShouldDisableRemoveMarketsCommand_When_CanRemoveMarketsFalse()
        {
            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanRemoveMarkets = false;

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.RemoveMarketsCommand.CanExecute());
        }

        [Test]
        public void ShouldDisposePriceGrids_And_UnRegisterMarkets_When_Dispose()
        {
            var gridController1 = new Mock<IDisposable>();
            var grid1 = new ChatPriceGridViewModel(gridController1.Object);

            var gridRemovalService = new Mock<IChatPriceGridRemovalService>();

            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Initialize(1, "markets", gridRemovalService.Object);

            testObjects.ViewModel.ChatPriceGrids.Add(grid1);

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ChatPriceFilterDialogViewModelController)
                .Verify(d => d.Dispose());

            gridController1.Verify(g => g.Dispose());
            Assert.AreEqual(0, testObjects.ViewModel.ChatPriceGrids.Count);

            gridRemovalService.Verify(g => g.UnRegisterMarkets(testObjects.ViewModel));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var gridController1 = new Mock<IDisposable>();
            var grid1 = new ChatPriceGridViewModel(gridController1.Object);

            var testObjects = new ChatPriceMarketsViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ChatPriceGrids.Add(grid1);

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ChatPriceFilterDialogViewModelController)
                .Verify(d => d.Dispose(), Times.Once);

            gridController1.Verify(g => g.Dispose(), Times.Once);
        }
    }
}
