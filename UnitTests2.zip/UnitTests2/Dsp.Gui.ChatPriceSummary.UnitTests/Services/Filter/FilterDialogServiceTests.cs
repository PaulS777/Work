﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.Services.Filter;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Filter
{
    public interface IFilterDialogServiceTestObjects
    {
        IDialogFilter<FilterDialogServiceTests.SelectableFilterItem> DialogFilter { get; }
        FilterDialogService<FilterDialogServiceTests.SelectableFilterItem> FilterDialogService { get; }
    }

    [TestFixture]
    public class FilterDialogServiceTests
    {
        public class SelectableFilterItem : BindableBase, ISelectableFilterItem
        {
            private bool _isSelected;

            public SelectableFilterItem(int id)
            {
                Id = id;
            }

            public int CompareTo(object obj)
            {
                return obj is not SelectableFilterItem item ? 1 : Id.CompareTo(item.Id);
            }

            public int Id { get; }

            public bool IsSelected
            {
                get => _isSelected;
                set
                {
                    _isSelected = value;
                    RaisePropertyChanged();
                }
            }

            public bool OriginalIsSelected { get; set; }
        }

        private class FilterDialogServiceTestObjectBuilder
        {
            private List<SelectableFilterItem> _filterItems;
            private bool _showFilter;
            private bool _canRemoveFilter;

            public FilterDialogServiceTestObjectBuilder WithFilterItems(List<SelectableFilterItem> values)
            {
                _filterItems = values;
                return this;
            }

            public FilterDialogServiceTestObjectBuilder WithShowFilter(bool value)
            {
                _showFilter = value;
                return this;
            }

            public FilterDialogServiceTestObjectBuilder WithCanRemoveFilter(bool value)
            {
                _canRemoveFilter = value;
                return this;
            }

            public IFilterDialogServiceTestObjects Build()
            {
                var testObjects = new Mock<IFilterDialogServiceTestObjects>();

                var dialogFilter = Mock.Of<IDialogFilter<SelectableFilterItem>>(d => d.ShowFilter == _showFilter
                                                                                     && d.CanRemoveFilter == _canRemoveFilter
                                                                                     && d.FilterItems == _filterItems);

                var mock = Mock.Get(dialogFilter);

                mock.SetupSet(d => d.ShowFilter = It.IsAny<bool>())
                    .Callback<bool>(value => mock.NotifyPropertyChanged(m => m.ShowFilter, value));

                mock.SetupSet(d => d.CanRemoveFilter = It.IsAny<bool>())
                    .Callback<bool>(value => mock.NotifyPropertyChanged(m => m.CanRemoveFilter, value));

                testObjects.SetupGet(o => o.DialogFilter)
                           .Returns(dialogFilter);

                var filterDialogService = new FilterDialogService<SelectableFilterItem>();

                testObjects.SetupGet(o => o.FilterDialogService)
                           .Returns(filterDialogService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetFilterCommands_When_AttachFilterDialog()
        {
            var testObjects = new FilterDialogServiceTestObjectBuilder().Build();

            // ACT
            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ASSERT
            Assert.IsNotNull(testObjects.DialogFilter.ApplyFilterChangesCommand);
            Assert.IsNotNull(testObjects.DialogFilter.CancelFilterChangesCommand);
        }

        [Test] 
        public void ShouldCalculateCommandsCanExecuteFalse_When_RefreshFilterItems_With_CanRemoveFilterFalse_And_NoneSelected()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1)
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithCanRemoveFilter(false)
                                                                        .Build();

            // ACT
            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.FilterDialogService.RefreshFilterItems(items);

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanCancelFilterChanges, Is.False);
            Assert.That(testObjects.DialogFilter.CancelFilterChangesCommand.CanExecute(), Is.False);

            Assert.That(testObjects.DialogFilter.CanApplyFilterChanges, Is.False);
            Assert.That(testObjects.DialogFilter.ApplyFilterChangesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableCancelFilterChanges_When_RefreshFilterItems_With_Selected_And_NoChanges()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = true, OriginalIsSelected = true}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithCanRemoveFilter(false)
                                                                        .Build();

            // ACT
            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.FilterDialogService.RefreshFilterItems(items);

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanCancelFilterChanges, Is.True);
            Assert.That(testObjects.DialogFilter.CancelFilterChangesCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableCancelFilterChanges_On_CanRemoveFilterTrue_With_NoItemsSelected()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = false, OriginalIsSelected = false}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithCanRemoveFilter(false)
                                                                        .WithFilterItems(items)
                                                                        .Build();

            // ACT
            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.DialogFilter.CanRemoveFilter = true;

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanCancelFilterChanges, Is.True);
            Assert.That(testObjects.DialogFilter.CancelFilterChangesCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableCancelFilterChanges_On_CanRemoveFilterFalse_With_NoItemsSelected()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = false, OriginalIsSelected = false}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithCanRemoveFilter(true)
                                                                        .WithFilterItems(items)
                                                                        .Build();

            // ACT
            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.DialogFilter.CanRemoveFilter = false;

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanCancelFilterChanges, Is.False);
            Assert.That(testObjects.DialogFilter.CancelFilterChangesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableApplyFilterChanges_When_RefreshFilterItems_With_Selected_And_NoChanges()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = true, OriginalIsSelected = true}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().Build();

            // ACT
            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.FilterDialogService.RefreshFilterItems(items);

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanApplyFilterChanges, Is.False);
            Assert.That(testObjects.DialogFilter.ApplyFilterChangesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldMaintainFilterItemsSelectedState_When_RefreshFilterItems_With_Updated()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1) {IsSelected = true, OriginalIsSelected = false},
                new(2){IsSelected = false, OriginalIsSelected = true},
                new(3){IsSelected = true, OriginalIsSelected = true}
            };

            var updated = new List<SelectableFilterItem>
            {
                new(1),
                new(2),
                new(3),
                new(4)
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithFilterItems(items)
                                                                        .Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.FilterDialogService.RefreshFilterItems(updated);

            // ASSERT
            Assert.That(updated[0].IsSelected, Is.True);
            Assert.That(updated[0].OriginalIsSelected, Is.False);

            Assert.That(updated[1].IsSelected, Is.False);
            Assert.That(updated[1].OriginalIsSelected, Is.True);

            Assert.That(updated[2].IsSelected, Is.True);
            Assert.That(updated[2].OriginalIsSelected, Is.True);
        }

        [Test]
        public void ShouldEnableApplyFilterChanges_When_ItemSelected()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1)
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            testObjects.FilterDialogService.RefreshFilterItems(items);

            // ACT
            items[0].IsSelected = true;

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanCancelFilterChanges, Is.False);
            Assert.That(testObjects.DialogFilter.CancelFilterChangesCommand.CanExecute(), Is.False);

            Assert.That(testObjects.DialogFilter.CanApplyFilterChanges, Is.True);
            Assert.That(testObjects.DialogFilter.ApplyFilterChangesCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableCancelFilterChanges_When_ItemSelected_WithNoOtherItemsSelected()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = false, OriginalIsSelected = false},
                new(2){IsSelected = false, OriginalIsSelected = false}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            testObjects.FilterDialogService.RefreshFilterItems(items);

            // ACT
            items[0].IsSelected = true;

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanCancelFilterChanges, Is.False);
            Assert.That(testObjects.DialogFilter.CancelFilterChangesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableApplyFilterChanges_When_ItemDeSelected_With_OtherItemsSelected()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = true, OriginalIsSelected = true},
                new(2){IsSelected = true, OriginalIsSelected = true}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            testObjects.FilterDialogService.RefreshFilterItems(items);

            // ACT
            items[0].IsSelected = false;

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanApplyFilterChanges, Is.True);
            Assert.That(testObjects.DialogFilter.ApplyFilterChangesCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldApplyFilterChangesAndPublish_On_ApplyFilterChangesCommand()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = true}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithFilterItems(items)
                                                                        .Build();

            var result = false;

            using (testObjects.FilterDialogService.ApplyFilterChangesCommand.Subscribe(_ => result = true))
            {
                testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

                // ACT
                testObjects.DialogFilter.ApplyFilterChangesCommand.Execute();

                // ASSERT
                Assert.That(items[0].IsSelected, Is.True);
                Assert.That(items[0].OriginalIsSelected, Is.True);
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldKeepShowFilterTrue_On_ApplyFilterChangesCommand()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = true}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithFilterItems(items)
                                                                        .WithShowFilter(true)
                                                                        .Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.DialogFilter.ApplyFilterChangesCommand.Execute();

            // ASSERT
            Assert.That(testObjects.DialogFilter.ShowFilter, Is.True);
            
        }

        [Test]
        public void ShouldCancelFilterChanges_On_CancelFilterChangesCommand()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = true, OriginalIsSelected = false}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithFilterItems(items)
                                                                        .WithShowFilter(true)
                                                                        .Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.DialogFilter.CancelFilterChangesCommand.Execute();

            // ASSERT
            Assert.That(items[0].IsSelected, Is.False);
        }

        [Test]
        public void ShouldSetShowFilterFalse_On_CancelFilterChangesCommand()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = true, OriginalIsSelected = false}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().WithFilterItems(items)
                                                                        .WithShowFilter(true)
                                                                        .Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            // ACT
            testObjects.DialogFilter.CancelFilterChangesCommand.Execute();

            // ASSERT
            Assert.That(testObjects.DialogFilter.ShowFilter, Is.False);
        }

        [Test]
        public void ShouldDisableApplyFilterChanges_When_AllItemsDeselected()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1){IsSelected = true, OriginalIsSelected = true}
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            testObjects.FilterDialogService.RefreshFilterItems(items);

            // ACT
            items[0].IsSelected = false;

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanCancelFilterChanges, Is.True);
            Assert.That(testObjects.DialogFilter.CancelFilterChangesCommand.CanExecute(), Is.True);

            Assert.That(testObjects.DialogFilter.CanApplyFilterChanges, Is.False);
            Assert.That(testObjects.DialogFilter.ApplyFilterChangesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldNotEnableApplyFilterChanges_When_Disposed()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1)
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            testObjects.FilterDialogService.RefreshFilterItems(items);

            testObjects.FilterDialogService.Dispose();

            // ACT
            items[0].IsSelected = true;

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanApplyFilterChanges, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var items = new List<SelectableFilterItem>
            {
                new(1)
            };

            var testObjects = new FilterDialogServiceTestObjectBuilder().Build();

            testObjects.FilterDialogService.AttachFilterDialog(testObjects.DialogFilter);

            testObjects.FilterDialogService.RefreshFilterItems(items);

            testObjects.FilterDialogService.Dispose();

            // ACT
            testObjects.FilterDialogService.Dispose();
            items[0].IsSelected = true;

            // ASSERT
            Assert.That(testObjects.DialogFilter.CanApplyFilterChanges, Is.False);
        }
    }
}
