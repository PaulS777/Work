﻿using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.Controllers.Filter;
using Dsp.Gui.ChatPriceSummary.Services.Filter;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Services;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Filter
{
    [TestFixture]
    public class ChatPriceCurveFilterCurveGroupBuilderTests
    {
        [Test]
        public void ShouldGetCurveFilterGroups()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var filterRegion1 = new ChatPriceCurveFilterRegion();
            var filterRegionController1 = Mock.Of<IChatPriceCurveFilterRegionController>(c => c.ViewModel == filterRegion1);

            var filterRegion2 = new ChatPriceCurveFilterRegion();
            var filterRegionController2 = Mock.Of<IChatPriceCurveFilterRegionController>(c => c.ViewModel == filterRegion2);

            var filterRegion3 = new ChatPriceCurveFilterRegion();
            var filterRegionController3 = Mock.Of<IChatPriceCurveFilterRegionController>(c => c.ViewModel == filterRegion3);

            var filterRegion4 = new ChatPriceCurveFilterRegion();
            var filterRegionController4 = Mock.Of<IChatPriceCurveFilterRegionController>(c => c.ViewModel == filterRegion4);

            var factory = new Mock<IServiceFactory<IChatPriceCurveFilterRegionController>>();

            factory.SetupSequence(f => f.Create())
                   .Returns(filterRegionController1)
                   .Returns(filterRegionController2)
                   .Returns(filterRegionController3)
                   .Returns(filterRegionController4);

            var filterItems = new[]
            {
                new ChatPriceCurveFilterItem(1, "curve-1", "name-1", crude, CurveRegion.Europe),
                new ChatPriceCurveFilterItem(2, "curve-2", "name-2", crude, CurveRegion.Europe),

                new ChatPriceCurveFilterItem(3, "curve-3", "name-3", crude, CurveRegion.Asia),

                new ChatPriceCurveFilterItem(4, "curve-4", "name-4", fuelOil, CurveRegion.Europe)
            };

            var builder = new ChatPriceCurveFilterCurveGroupBuilder
                          {
                              CurveFilterRegionFactory = factory.Object
                          };

            // ACT
            var result = builder.GetCurveFilterGroups(filterItems);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(2));

            Assert.That(result[0].CurveGroup.Id, Is.EqualTo(crude.Id));
            Assert.That(result[0].GroupHeader, Is.EqualTo(CurveGroupNames.Crude));
            
            Assert.That(result[0].CurveFilterRegions.Count, Is.EqualTo(2));

            Assert.That(result[0].CurveFilterRegions[0].RegionHeader.Region, Is.EqualTo(CurveRegion.Europe));
            Assert.That(result[0].CurveFilterRegions[0].RegionHeader.RegionName, Is.EqualTo("Europe"));
            Assert.That(result[0].CurveFilterRegions[0].Items.Count, Is.EqualTo(2));

            Assert.That(result[0].CurveFilterRegions[0].Items[0].Id, Is.EqualTo(1));
            Assert.That(result[0].CurveFilterRegions[0].Items[1].Id, Is.EqualTo(2));

            Assert.That(result[0].CurveFilterRegions[1].RegionHeader.Region, Is.EqualTo(CurveRegion.Asia));
            Assert.That(result[0].CurveFilterRegions[1].RegionHeader.RegionName, Is.EqualTo("Asia"));
            Assert.That(result[0].CurveFilterRegions[1].Items.Count, Is.EqualTo(1));
            Assert.That(result[0].CurveFilterRegions[1].Items[0].Id, Is.EqualTo(3));

            Assert.That(result[1].CurveGroup.Id, Is.EqualTo(fuelOil.Id));
            Assert.That(result[1].GroupHeader, Is.EqualTo(CurveGroupNames.FuelOil));

            Assert.That(result[1].CurveFilterRegions.Count, Is.EqualTo(1));

            Assert.That(result[1].CurveFilterRegions[0].RegionHeader.Region, Is.EqualTo(CurveRegion.Europe));
            Assert.That(result[1].CurveFilterRegions[0].RegionHeader.RegionName, Is.EqualTo("Europe"));
            Assert.That(result[1].CurveFilterRegions[0].Items.Count, Is.EqualTo(1));
            Assert.That(result[1].CurveFilterRegions[0].Items[0].Id, Is.EqualTo(4));
        }
    }
}
