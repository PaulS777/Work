﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.Services.Filter;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Filter
{
    public interface IChatPriceCurveFilterItemsProviderTestObjects
    {
        ChatPriceCurveFilterItemsProvider ChatPriceCurveFilterItemsProvider { get; }
    }

    [TestFixture]
    public class ChatPriceCurveFilterItemsProviderTests
    {
        private class ChatPriceCurveFilterItemsProviderTestObjectBuilder
        {
            private List<PriceCurveDefinition> _priceCurveDefinitions;
            private List<DataContracts.ChatScraper.ChatPriceSummary> _chatPriceSummaries;
            private List<ChatIceMap> _chatIceMaps;

            public ChatPriceCurveFilterItemsProviderTestObjectBuilder WithPriceCurveDefinitions(List<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public ChatPriceCurveFilterItemsProviderTestObjectBuilder WithChatPriceSummaries(List<DataContracts.ChatScraper.ChatPriceSummary> values)
            {
                _chatPriceSummaries = values;
                return this;
            }

            public ChatPriceCurveFilterItemsProviderTestObjectBuilder WithChatIceMaps(List<ChatIceMap> values)
            {
                _chatIceMaps = values;
                return this;
            }

            public IChatPriceCurveFilterItemsProviderTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceCurveFilterItemsProviderTestObjects>();

                var priceCurveDefinitions = new BehaviorSubject<List<PriceCurveDefinition>>(_priceCurveDefinitions);

                var chatPriceSummaries = new BehaviorSubject<List<DataContracts.ChatScraper.ChatPriceSummary>>(_chatPriceSummaries);

                var chatIceMaps = new BehaviorSubject<List<ChatIceMap>>(_chatIceMaps);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.PriceCurveDefinitions)
                                   .Returns(priceCurveDefinitions);

                curveControlService.SetupGet(c => c.ChatPriceSummarySnapshot)
                                   .Returns(chatPriceSummaries);

                curveControlService.SetupGet(c => c.ChatIceMaps)
                                   .Returns(chatIceMaps);

                var chatPriceCurveFilterItemsProvider = new ChatPriceCurveFilterItemsProvider(curveControlService.Object);

                testObjects.SetupGet(o => o.ChatPriceCurveFilterItemsProvider)
                           .Returns(chatPriceCurveFilterItemsProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishChatPriceFilterItems_With_Mappings_Ordered_By_PriceCurveName()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var moGas = new CurveGroupTestObjectBuilder().MoGas();

            var definition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithCurveRegion(CurveRegion.Europe)
                                                                         .WithProductCurveGroup(crude)
                                                                         .Build();

            var definition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithCurveRegion(CurveRegion.UnitedStates)
                                                                         .WithProductCurveGroup(moGas)
                                                                         .Build();

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new(2, "curve-B", "name", [], [], [], []),
                new(1, "curve-A", "name", [], [], [], []),
                new(3, "curve-C", "name", [], [], [], [])
            };

            var chatIceMaps = new List<ChatIceMap>
            {
                new(50 ,EntityStatus.Active, "curve-A", 10, 101, "curveA"),
                new(51, EntityStatus.Active, "curve-B", 10, 102, "curveB"),
                new(52, EntityStatus.Active, "curve-X", 10, null, "curveC")
            };

            var definitions = new List<PriceCurveDefinition> {definition1, definition2};

            var testObjects = new ChatPriceCurveFilterItemsProviderTestObjectBuilder().WithPriceCurveDefinitions(definitions)
                                                                                      .WithChatPriceSummaries(snapshot)
                                                                                      .WithChatIceMaps(chatIceMaps)
                                                                                      .Build();
            IList<ChatPriceCurveFilterItem> result = null;

            // ACT
            var filterItems = testObjects.ChatPriceCurveFilterItemsProvider.ChatPriceFilterItems();

            using (filterItems.Subscribe(items => result = items))
            {
                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
                Assert.That(result[0].Id, Is.EqualTo(1));
                Assert.That(result[0].PriceCurveName, Is.EqualTo("curve-A"));
                Assert.That(result[0].Name, Is.EqualTo("name"));
                Assert.That(result[0].CurveGroup.Id, Is.EqualTo(crude.Id));
                Assert.That(result[0].CurveRegion, Is.EqualTo(CurveRegion.Europe));
                Assert.That(result[1].Id, Is.EqualTo(2));
                Assert.That(result[1].PriceCurveName, Is.EqualTo("curve-B"));
                Assert.That(result[1].Name, Is.EqualTo("name"));
                Assert.That(result[1].CurveGroup.Id, Is.EqualTo(moGas.Id));
                Assert.That(result[1].CurveRegion, Is.EqualTo(CurveRegion.UnitedStates));
            }
        }
    }
}
