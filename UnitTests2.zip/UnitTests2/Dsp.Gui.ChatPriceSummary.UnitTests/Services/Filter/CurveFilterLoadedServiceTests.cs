﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.Services.Filter;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Filter
{
    public interface ICurveFilterLoadedServiceTestObjects
    {
        ISubject<IList<ChatPriceCurveFilterItem>> FilterItems { get; }
        CurveFilterLoadedService CurveFilterLoadedService { get; }
    }

    [TestFixture]
    public class CurveFilterLoadedServiceTests
    {
        private class CurveFilterLoadedServiceTestObjectBuilder
        {
            public ICurveFilterLoadedServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveFilterLoadedServiceTestObjects>();

                var filterItems = new BehaviorSubject<IList<ChatPriceCurveFilterItem>>(null);

                testObjects.SetupGet(o => o.FilterItems)
                           .Returns(filterItems);

                var filterItemsProvider = new Mock<IChatPriceCurveFilterItemsProvider>();

                filterItemsProvider.Setup(p => p.ChatPriceFilterItems())
                                   .Returns(filterItems);

                var curveFilterLoadedService = new CurveFilterLoadedService(filterItemsProvider.Object);

                testObjects.SetupGet(o => o.CurveFilterLoadedService)
                           .Returns(curveFilterLoadedService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishFilterItems_When_Initialize()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var filterItems = new List<ChatPriceCurveFilterItem>
            {
                new(10, "price-curve", "name", crude, CurveRegion.Europe)
            };

            var testObjects = new CurveFilterLoadedServiceTestObjectBuilder().Build();

            IList<ChatPriceCurveFilterItem> result = null;

            using (testObjects.CurveFilterLoadedService.CurveFilter.Subscribe(i => result = i))
            {
                testObjects.CurveFilterLoadedService.Initialize();

                // ACT
                testObjects.FilterItems.OnNext(filterItems);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldApplySettingsToFilterItems_When_Initialize_With_Settings()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var filterItems = new List<ChatPriceCurveFilterItem>
            {
                new(10, "price-curve-1", "name", crude, CurveRegion.Europe),
                new(11, "price-curve-2", "name", crude, CurveRegion.Europe)
            };

            var gridSettings = new ChatPriceGridSettings
            {
                MarketBands =
                [
                    new ChatPriceGridSettings.MarketBand
                    {
                        ChatPriceSummaryId = 10
                    }
                ]
            };

            var testObjects = new CurveFilterLoadedServiceTestObjectBuilder().Build();

            IList<ChatPriceCurveFilterItem> result = null;

            using (testObjects.CurveFilterLoadedService.CurveFilter.Subscribe(i => result = i))
            {
                testObjects.CurveFilterLoadedService.Initialize(gridSettings);

                // ACT
                testObjects.FilterItems.OnNext(filterItems);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
                Assert.That(result[0].IsSelected && result[0].OriginalIsSelected);
                Assert.That(!result[1].IsSelected && !result[1].OriginalIsSelected);
            }
        }

        [Test]
        public void ShouldCloneFilterItems()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var filterItems = new List<ChatPriceCurveFilterItem>
            {
                new(10, "price-curve", "name", crude, CurveRegion.Europe)
            };

            var testObjects = new CurveFilterLoadedServiceTestObjectBuilder().Build();

            IList<ChatPriceCurveFilterItem> result = null;

            using (testObjects.CurveFilterLoadedService.CurveFilter.Subscribe(i => result = i))
            {
                testObjects.CurveFilterLoadedService.Initialize();

                testObjects.FilterItems.OnNext(filterItems);

                // ACT
                filterItems[0].IsSelected = true;

                // ASSERT
                Assert.That(result[0].IsSelected, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishFilterItems_When_Disposed()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var filterItems = new List<ChatPriceCurveFilterItem>
            {
                new(10, "price-curve", "name", crude, CurveRegion.Europe)
            };

            var testObjects = new CurveFilterLoadedServiceTestObjectBuilder().Build();

            IList<ChatPriceCurveFilterItem> result = null;

            using (testObjects.CurveFilterLoadedService.CurveFilter.Subscribe(i => result = i))
            {
                testObjects.CurveFilterLoadedService.Initialize();

                testObjects.CurveFilterLoadedService.Dispose();

                // ACT
                testObjects.FilterItems.OnNext(filterItems);

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldNotDisposed_When_Disposed()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var filterItems = new List<ChatPriceCurveFilterItem>
            {
                new(10, "price-curve", "name", crude, CurveRegion.Europe)
            };

            var testObjects = new CurveFilterLoadedServiceTestObjectBuilder().Build();

            IList<ChatPriceCurveFilterItem> result = null;

            using (testObjects.CurveFilterLoadedService.CurveFilter.Subscribe(i => result = i))
            {
                testObjects.CurveFilterLoadedService.Initialize();

                testObjects.CurveFilterLoadedService.Dispose();

                // ACT
                testObjects.CurveFilterLoadedService.Dispose();
                testObjects.FilterItems.OnNext(filterItems);

                // ASSERT
                Assert.IsNull(result);
            }
        }
    }
}
