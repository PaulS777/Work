﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.Services.Filter;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Filter
{
    [TestFixture]
    public class ColumnFilterLoadedServiceTests
    {
        [Test]
        public void ShouldPublishFilterItems_When_Initialize()
        {
            IList<ChatPriceColumnFilterItem> result = null;

            var service = new ColumnFilterLoadedService();

            using (service.ColumnFilter.Subscribe(i => result = i))
            {
                // ACT
                service.Initialize();

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(6));
            }
        }

        [Test]
        public void ShouldApplySettingsToFilterItems_When_Initialize_With_Settings()
        {
            var settings = new ChatPriceGridSettings
            {
                VisibleColumns = new[]
                {
                    ColumnType.BidBroker
                }
            };

            IList<ChatPriceColumnFilterItem> result = null;

            var service = new ColumnFilterLoadedService();

            using (service.ColumnFilter.Subscribe(i => result = i))
            {
                // ACT
                service.Initialize(settings);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(6));
                Assert.That(result[0].ColumnType == ColumnType.BidBroker && result[0].IsSelected && result[0].OriginalIsSelected);
                Assert.That(!result[1].IsSelected && !result[1].OriginalIsSelected);
                Assert.That(!result[2].IsSelected && !result[2].OriginalIsSelected);
                Assert.That(!result[3].IsSelected && !result[3].OriginalIsSelected);
                Assert.That(!result[4].IsSelected && !result[4].OriginalIsSelected);
                Assert.That(!result[5].IsSelected && !result[5].OriginalIsSelected);
            }
        }

        [Test]
        public void ShouldNotPublishFilterItems_When_Disposed()
        {
            IList<ChatPriceColumnFilterItem> result = null;

            var service = new ColumnFilterLoadedService();

            using (service.ColumnFilter.Subscribe(i => result = i))
            {
                service.Dispose();

                // ACT
                service.Initialize();

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            IList<ChatPriceColumnFilterItem> result = null;

            var service = new ColumnFilterLoadedService();

            using (service.ColumnFilter.Subscribe(i => result = i))
            {
                service.Dispose();

                // ACT
                service.Dispose();
                service.Initialize();

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
