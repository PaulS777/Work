﻿using System.Linq;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using NUnit.Framework;
namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Settings
{
    [TestFixture]
    public class ChatPriceSummarySettingsBuilderTests
    {
        [Test]
        public void ShouldGetDefaultSettings()
        {
            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ASSERT
            Assert.AreEqual(1, settings.ChatPriceMarkets.Length);
            Assert.AreEqual(1, settings.ChatPriceMarkets[0].ChatPriceGrids.Length);

            Assert.AreEqual(1, settings.ChatPriceMarkets[0].MarketsId);
            Assert.AreEqual("Markets 1", settings.ChatPriceMarkets[0].MarketsName);
            Assert.AreEqual(1, settings.ChatPriceMarkets[0].ChatPriceGrids[0].PriceGridId);

            var chatPriceGrid = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual(0, chatPriceGrid.MarketBands.Length);
            Assert.AreEqual(6, chatPriceGrid.VisibleColumns.Length);

            Assert.IsTrue(chatPriceGrid.VisibleColumns.Contains(ColumnType.BidPrice));
            Assert.IsTrue(chatPriceGrid.VisibleColumns.Contains(ColumnType.BidBroker));
            Assert.IsTrue(chatPriceGrid.VisibleColumns.Contains(ColumnType.BidTime));
            Assert.IsTrue(chatPriceGrid.VisibleColumns.Contains(ColumnType.AskPrice));
            Assert.IsTrue(chatPriceGrid.VisibleColumns.Contains(ColumnType.AskBroker));
            Assert.IsTrue(chatPriceGrid.VisibleColumns.Contains(ColumnType.AskTime));
        }

        [Test]
        public void ShouldCreateNewPriceGrid()
        {
            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT
            var result = builder.CreateNewPriceGrid(1, settings);

            // ASSERT
            Assert.AreEqual(1, settings.ChatPriceMarkets.Length);
            Assert.AreEqual(2, settings.ChatPriceMarkets[0].ChatPriceGrids.Length);

            Assert.AreSame(result, settings.ChatPriceMarkets[0].ChatPriceGrids[1]);

            Assert.AreEqual(2, result.PriceGridId);
            Assert.AreEqual(0, result.MarketBands.Length);
            Assert.AreEqual(6, result.VisibleColumns.Length);
            Assert.IsTrue(result.VisibleColumns.Contains(ColumnType.BidPrice));
            Assert.IsTrue(result.VisibleColumns.Contains(ColumnType.BidBroker));
            Assert.IsTrue(result.VisibleColumns.Contains(ColumnType.BidTime));
            Assert.IsTrue(result.VisibleColumns.Contains(ColumnType.AskPrice));
            Assert.IsTrue(result.VisibleColumns.Contains(ColumnType.AskBroker));
            Assert.IsTrue(result.VisibleColumns.Contains(ColumnType.AskTime));
        }

        [Test]
        public void ShouldCreateNewChatPriceMarkets()
        {
            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT
            var result = builder.CreateNewChatPriceMarkets(settings);

            // ASSERT
            Assert.AreEqual(2, settings.ChatPriceMarkets.Length);
            Assert.AreEqual(1, settings.ChatPriceMarkets[1].ChatPriceGrids.Length);

            Assert.AreSame(result, settings.ChatPriceMarkets[1]);

            Assert.AreEqual(2, result.MarketsId);
            Assert.AreEqual("Markets 2", result.MarketsName);
            Assert.AreEqual(0, result.ChatPriceGrids[0].MarketBands.Length);
            Assert.AreEqual(6, result.ChatPriceGrids[0].VisibleColumns.Length);
            Assert.IsTrue(result.ChatPriceGrids[0].VisibleColumns.Contains(ColumnType.BidPrice));
            Assert.IsTrue(result.ChatPriceGrids[0].VisibleColumns.Contains(ColumnType.BidBroker));
            Assert.IsTrue(result.ChatPriceGrids[0].VisibleColumns.Contains(ColumnType.BidTime));
            Assert.IsTrue(result.ChatPriceGrids[0].VisibleColumns.Contains(ColumnType.AskPrice));
            Assert.IsTrue(result.ChatPriceGrids[0].VisibleColumns.Contains(ColumnType.AskBroker));
            Assert.IsTrue(result.ChatPriceGrids[0].VisibleColumns.Contains(ColumnType.AskTime));
        }

        [Test]
        public void ShouldApplyMarketsFilterToDefaultSettings()
        {
            var priceGridId = 1;
            var curveIds = new[] { 10 };

            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT
            builder.ApplyMarketsFilter(1, priceGridId, curveIds, settings);

            // ASSERT
            Assert.AreEqual(1, settings.ChatPriceMarkets.Length);
            Assert.AreEqual(1, settings.ChatPriceMarkets[0].ChatPriceGrids.Length);

            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.That(gridSettings.MarketBands.Length == 1
                        && gridSettings.MarketBands[0].ChatPriceSummaryId == 10
                        && gridSettings.MarketBands[0].ColumnWidths.Length == 0);

            Assert.AreEqual(6, gridSettings.VisibleColumns.Length);
        }

        [Test]
        public void ShouldApplyMarketsFilterToSettingsWithExistingMarkets()
        {
            var curveIds = new[] { 10, 11 };

            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1, 
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings
                            {
                                PriceGridId = 2,
                                MarketBands = new[]
                                {
                                    new ChatPriceGridSettings.MarketBand
                                    {
                                        ChatPriceSummaryId = 10,
                                        ColumnWidths = new[]
                                        {
                                            new ChatPriceGridSettings.ColumnWidth
                                            {
                                                ColumnType = ColumnType.BidPrice, Width = 55
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.ApplyMarketsFilter(1, 2, curveIds, settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual(2, gridSettings.MarketBands.Length);

            Assert.That(gridSettings.MarketBands[0].ChatPriceSummaryId == 10 
                        && gridSettings.MarketBands[0].ColumnWidths.Length == 1
                        && gridSettings.MarketBands[0].ColumnWidths[0].Width == 55);

            Assert.That(gridSettings.MarketBands[1].ChatPriceSummaryId == 11 
                        && gridSettings.MarketBands[1].ColumnWidths.Length == 0);
        }

        [Test]
        public void ShouldNotApplyMarketsFilterToSettings_When_GridSettingsNotExists()
        {
            var curveIds = new[] { 10, 11 };

            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1, 
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings
                            {
                                PriceGridId = 3,
                                MarketBands = new[]
                                {
                                    new ChatPriceGridSettings.MarketBand
                                    {
                                        ChatPriceSummaryId = 10,
                                        ColumnWidths = new[]
                                        {
                                            new ChatPriceGridSettings.ColumnWidth
                                            {
                                                ColumnType = ColumnType.BidPrice, Width = 55
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.ApplyMarketsFilter(1, 2, curveIds, settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual(1, gridSettings.MarketBands.Length);
        }

        [Test]
        public void ShouldApplyColumnsFilterToDefaultSettings()
        {
            var columns = new[] { ColumnType.BidPrice };

            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT 
            builder.ApplyColumnsFilter(1, 1, columns, settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual(0, gridSettings.MarketBands.Length);
            Assert.AreEqual(1, gridSettings.VisibleColumns.Length);
        }

        [Test]
        public void ShouldNotApplyColumnsFilterToDefaultSettings_When_GridSettingsNotExists()
        {
            var columns = new[] { ColumnType.BidPrice };

            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT 
            builder.ApplyColumnsFilter(1, 2, columns, settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual(6, gridSettings.VisibleColumns.Length);
        }

        [Test]
        public void ShouldAddColumnWidth_WhenApplyColumnWidthsToSettings_WithNoExistingColumnWidthSettings()
        {
            var columnInfos = new[]
            {
                new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 80)
                {
                    AdjustedWidth = 55d
                }
            };

            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1, 
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings
                            {
                                PriceGridId = 2,
                                MarketBands = new[]
                                {
                                    new ChatPriceGridSettings.MarketBand
                                    {
                                        ChatPriceSummaryId = 10,
                                        ColumnWidths = new ChatPriceGridSettings.ColumnWidth[]{}
                                    }
                                }
                            }
                        }
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.ApplyColumnWidths(1, 2, columnInfos, settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual(1, gridSettings.MarketBands.Length);
            Assert.AreEqual(ColumnType.BidPrice, gridSettings.MarketBands[0].ColumnWidths[0].ColumnType);
            Assert.AreEqual(55d, gridSettings.MarketBands[0].ColumnWidths[0].Width);
        }

        [Test]
        public void ShouldUpdateColumnWidth_WhenApplyColumnWidthsToSettings_WithExisting()
        {
            var columnInfos = new[]
            {
                new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 80)
                {
                    AdjustedWidth = 55d
                }
            };

            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1, 
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings
                            {
                                PriceGridId = 2,
                                MarketBands = new[]
                                {
                                    new ChatPriceGridSettings.MarketBand
                                    {
                                        ChatPriceSummaryId = 10,
                                        ColumnWidths = new[]
                                        {
                                            new ChatPriceGridSettings.ColumnWidth{ColumnType = ColumnType.AskBroker, Width = 15},
                                            new ChatPriceGridSettings.ColumnWidth{ColumnType = ColumnType.BidPrice, Width = 25}
                                        }
                                    },
                                    new ChatPriceGridSettings.MarketBand
                                    {
                                        ChatPriceSummaryId = 11,
                                        ColumnWidths = new[]
                                        {
                                            new ChatPriceGridSettings.ColumnWidth{ColumnType = ColumnType.AskTime, Width = 15}
                                        }
                                    }
                                },
                                VisibleColumns = new ColumnType[] { }
                            }
                        }
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.ApplyColumnWidths(1, 2, columnInfos, settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual(2, gridSettings.MarketBands.Length);
            Assert.AreEqual(2, gridSettings.MarketBands[0].ColumnWidths.Length);

            Assert.AreEqual(ColumnType.AskBroker, gridSettings.MarketBands[0].ColumnWidths[0].ColumnType);
            Assert.AreEqual(15d, gridSettings.MarketBands[0].ColumnWidths[0].Width);

            Assert.AreEqual(ColumnType.BidPrice, gridSettings.MarketBands[0].ColumnWidths[1].ColumnType);
            Assert.AreEqual(55d, gridSettings.MarketBands[0].ColumnWidths[1].Width);

            Assert.AreEqual(1, gridSettings.MarketBands[1].ColumnWidths.Length);
        }

        [Test]
        public void ShouldNotUpdateColumnWidth_WhenApplyColumnWidthsToSettings_When_GridSettingsNotExists()
        {
            var columnInfos = new[]
            {
                new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 80)
                {
                    AdjustedWidth = 55d
                }
            };

            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1, 
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings
                            {
                                PriceGridId = 2,
                                MarketBands = new[]
                                {
                                    new ChatPriceGridSettings.MarketBand
                                    {
                                        ChatPriceSummaryId = 10,
                                        ColumnWidths = new[]
                                        {
                                            new ChatPriceGridSettings.ColumnWidth{ColumnType = ColumnType.BidPrice, Width = 25}
                                        }
                                    }
                                },
                                VisibleColumns = new ColumnType[] { }
                            }
                        }
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.ApplyColumnWidths(1, 3, columnInfos, settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual(25, gridSettings.MarketBands[0].ColumnWidths[0].Width);
        }

        [Test]
        public void ShouldApplyPriceGridName()
        {
            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT 
            builder.ApplyPriceGridName(1, 1, "price-grid-name", settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreEqual("price-grid-name", gridSettings.Name);
        }

        [Test]
        public void ShouldNotApplyPriceGridName_When_GridSettingsNotExists()
        {
            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT 
            builder.ApplyPriceGridName(1, 2, "price-grid-name", settings);

            // ASSERT
            var gridSettings = settings.ChatPriceMarkets[0].ChatPriceGrids[0];

            Assert.AreNotEqual("price-grid-name", gridSettings.Name);
        }

        [Test]
        public void ShouldApplyMarketsName()
        {
            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT 
            builder.ApplyMarketsName(1, "test-markets", settings);

            // ASSERT
            Assert.AreEqual("test-markets", settings.ChatPriceMarkets[0].MarketsName);
        }

        [Test]
        public void ShouldNotApplyMarketsName_When_GridSettingsNotExists()
        {
            var builder = new ChatPriceSummarySettingsBuilder();

            var settings = builder.GetDefaultChatPriceSummarySettings(1, 1);

            // ACT 
            builder.ApplyMarketsName(2, "test-markets", settings);

            // ASSERT
            Assert.AreNotEqual("test-markets", settings.ChatPriceMarkets[0].MarketsName);
        }

        [Test]
        public void ShouldRemovePriceGrid()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1, 
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings {PriceGridId = 1},
                            new ChatPriceGridSettings {PriceGridId = 2}
                        }
                    },
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 2,
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings {PriceGridId = 1},
                            new ChatPriceGridSettings {PriceGridId = 2}
                        }
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.RemovePriceGrid(1, 1, settings);

            // ASSERT
            Assert.AreEqual(2, settings.ChatPriceMarkets.Length);

            Assert.AreEqual(1, settings.ChatPriceMarkets[0].ChatPriceGrids.Length);
            Assert.AreEqual(2, settings.ChatPriceMarkets[0].ChatPriceGrids[0].PriceGridId);

            Assert.AreEqual(2, settings.ChatPriceMarkets[1].ChatPriceGrids.Length);
        }

        [Test]
        public void ShouldNotRemovePriceGrid_When_GridSettingsNotExists()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1,
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings {PriceGridId = 1},
                            new ChatPriceGridSettings {PriceGridId = 2}
                        }
                    },
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 2,
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings {PriceGridId = 1},
                            new ChatPriceGridSettings {PriceGridId = 2}
                        }
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.RemovePriceGrid(1, 3, settings);

            // ASSERT
            Assert.AreEqual(2, settings.ChatPriceMarkets[0].ChatPriceGrids.Length);
        }

        [Test]
        public void ShouldRemoveMarkets()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1
                    },
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 2
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.RemoveMarkets(1, settings);

            // ASSERT
            Assert.AreEqual(1, settings.ChatPriceMarkets.Length);
            Assert.AreEqual(2, settings.ChatPriceMarkets[0].MarketsId);
        }

        [Test]
        public void ShouldRemoveMarkets_When_MarketsSettingsNotExists()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1
                    },
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 2
                    }
                }
            };

            var builder = new ChatPriceSummarySettingsBuilder();

            // ACT
            builder.RemoveMarkets(3, settings);

            // ASSERT
            Assert.AreEqual(2, settings.ChatPriceMarkets.Length);
        }
    }
}
