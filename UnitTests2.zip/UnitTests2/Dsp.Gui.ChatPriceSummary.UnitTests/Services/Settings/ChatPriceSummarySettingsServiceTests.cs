﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.ServiceContracts;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Settings
{
    public interface IChatPriceSummarySettingsServiceTestObjects
    {
        IChatPriceSummarySettingsFileProvider FileProvider { get; }
        IChatPriceSummarySettingsBuilder Builder { get; }
        TestScheduler TestScheduler { get; }
        ILogger Logger { get; }
        ChatPriceSummarySettingsService ChatPriceSummarySettingsService { get; }
    }

    [TestFixture]
    public class ChatPriceSummarySettingsServiceTests
    {
        private class ChatPriceSummarySettingsServiceTestObjectBuilder
        {
            private ChatPriceSummarySettings _loadedSettings;
            private ChatPriceSummarySettings _defaultSettings;
            private ChatPriceGridSettings _newPriceGrid;
            private ChatPriceMarketsSettings _newMarkets;
            private Exception _saveSettingsException;

            public ChatPriceSummarySettingsServiceTestObjectBuilder WithLoadedSettings(ChatPriceSummarySettings value)
            {
                _loadedSettings = value;
                return this;
            }

            public ChatPriceSummarySettingsServiceTestObjectBuilder WithDefaultSettings(ChatPriceSummarySettings value)
            {
                _defaultSettings = value;
                return this;
            }

            public ChatPriceSummarySettingsServiceTestObjectBuilder WithNewPriceGrid(ChatPriceGridSettings value)
            {
                _newPriceGrid = value;
                return this;
            }

            public ChatPriceSummarySettingsServiceTestObjectBuilder WithNewMarkets(ChatPriceMarketsSettings value)
            {
                _newMarkets = value;
                return this;
            }

            public ChatPriceSummarySettingsServiceTestObjectBuilder WithSaveSettingsException(Exception value)
            {
                _saveSettingsException = value;
                return this;
            }

            public IChatPriceSummarySettingsServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceSummarySettingsServiceTestObjects>();

                var fileProvider = new Mock<IChatPriceSummarySettingsFileProvider>();

                fileProvider.Setup(f => f.LoadChatPriceSummarySettings())
                            .Returns(_loadedSettings);

                if (_saveSettingsException != null)
                {
                    fileProvider.Setup(f => f.SaveChatPriceSummarySettings(It.IsAny<ChatPriceSummarySettings>()))
                                .Throws(_saveSettingsException);
                }

                testObjects.SetupGet(o => o.FileProvider)
                           .Returns(fileProvider.Object);

                var builder = new Mock<IChatPriceSummarySettingsBuilder>();

                builder.Setup(b => b.GetDefaultChatPriceSummarySettings(It.IsAny<int>(), It.IsAny<int>()))
                       .Returns(_defaultSettings);

                builder.Setup(b => b.CreateNewPriceGrid(It.IsAny<int>(), It.IsAny<ChatPriceSummarySettings>()))
                       .Returns(_newPriceGrid);


                builder.Setup(b => b.CreateNewChatPriceMarkets(It.IsAny<ChatPriceSummarySettings>()))
                       .Returns(_newMarkets);

                testObjects.SetupGet(o => o.Builder)
                           .Returns(builder.Object);

                var testScheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();
                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);

                var logger = new Mock<ILogger>();
                testObjects.SetupGet(o => o.Logger).Returns(logger.Object);

                var loggerFactory = new Mock<ILoggerFactory>();
                loggerFactory.Setup(f => f.Create(It.IsAny<string>())).Returns(logger.Object);

                var chatPriceSummarySettingsService = new ChatPriceSummarySettingsService(fileProvider.Object,
                                                                                          builder.Object,
                                                                                          schedulerProvider.Object,
                                                                                          loggerFactory.Object);
                testObjects.SetupGet(o => o.ChatPriceSummarySettingsService)
                           .Returns(chatPriceSummarySettingsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishSettingsOnLoad()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings(),
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            ChatPriceSummarySettings result = null;

            using (testObjects.ChatPriceSummarySettingsService.ChatPriceSummarySettings.Subscribe(s => result = s))
            {
                // ACT
                testObjects.ChatPriceSummarySettingsService.LoadSettings();
                testObjects.TestScheduler.AdvanceBy(10);

                // ASSERT
                Assert.AreSame(settings, result);
            }
        }

        [Test]
        public void ShouldPublishDefaultSettingsOnLoad_With_NoSettingsAvailable()
        {
            var loadedSettings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new ChatPriceMarketsSettings[] { }
            };

            var defaultSettings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings()
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(loadedSettings)
                                                                                    .WithDefaultSettings(defaultSettings)
                                                                                    .Build();

            ChatPriceSummarySettings result = null;

            using (testObjects.ChatPriceSummarySettingsService.ChatPriceSummarySettings.Subscribe(s => result = s))
            {
                // ACT
                testObjects.ChatPriceSummarySettingsService.LoadSettings();
                testObjects.TestScheduler.AdvanceBy(10);

                // ASSERT
                Mock.Get(testObjects.Builder)
                    .Verify(b => b.GetDefaultChatPriceSummarySettings(1, 1));

                Assert.That(result, Is.EqualTo(defaultSettings));
            }
        }

        [Test]
        public void ShouldGetPriceGridSettings()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 3,
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings{PriceGridId = 2, Name = "Price Grid 1"}
                        }
                    }
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            var result = testObjects.ChatPriceSummarySettingsService.GetChatPriceGridSettings(3, 2);

            // ASSERT
            Assert.That(result.Name, Is.EqualTo("Price Grid 1"));
        }

        [Test]
        public void ShouldCreateNewPriceGrid()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1,
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings()
                        }
                    }
                }
            };

            var priceGridSettings = new ChatPriceGridSettings
            {
                PriceGridId = 2
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithNewPriceGrid(priceGridSettings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            var result = testObjects.ChatPriceSummarySettingsService.CreateNewPriceGrid(1);

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.CreateNewPriceGrid(1, It.Is<ChatPriceSummarySettings>(s => s.ChatPriceMarkets[0].MarketsId == 1)));

            Assert.That(result.PriceGridId, Is.EqualTo(2));
        }

        [Test]
        public void ShouldCreateNewChatPriceMarkets()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = 1,
                        ChatPriceGrids = new[]
                        {
                            new ChatPriceGridSettings()
                        }
                    }
                }
            };

            var marketsSettings = new ChatPriceMarketsSettings
            {
                MarketsId = 2
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithNewMarkets(marketsSettings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            var result = testObjects.ChatPriceSummarySettingsService.CreateNewChatPriceMarkets();

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.CreateNewChatPriceMarkets(It.Is<ChatPriceSummarySettings>(s => s.ChatPriceMarkets[0].MarketsId == 1)));

            Assert.That(result.MarketsId, Is.EqualTo(2));
        }

        [Test]
        public void ShouldSaveCurveFilterSettings()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings {MarketsId = 3}
                }
            };

            var markets = new[] { 10 };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.ChatPriceSummarySettingsService.SaveMarketsFilter(3, 2, markets);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.ApplyMarketsFilter(3, 2, It.Is<IList<int>>(ids => ids.Count == 1), settings));

            Mock.Get(testObjects.FileProvider)
                .Verify(f => f.SaveChatPriceSummarySettings(settings));
        }

        [Test]
        public void ShouldSaveColumnFilterSettings()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings {MarketsId = 3}
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var columns = new[] { ColumnType.BidPrice };

            // ACT
            testObjects.ChatPriceSummarySettingsService.SaveColumnsFilter(3, 2, columns);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.ApplyColumnsFilter(3,
                                                  2,
                                                 It.Is<IList<ColumnType>>(infos => infos.Count == 1),
                                                 settings));

            Mock.Get(testObjects.FileProvider)
                .Verify(f => f.SaveChatPriceSummarySettings(settings));
        }

        [Test]
        public void ShouldSaveColumnWidthSettings()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings{MarketsId = 3}
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var columnInfos = new[] { new ColumnInfo(ColumnType.BidPrice, 0, null, null, false) };

            // ACT
            testObjects.ChatPriceSummarySettingsService.SaveColumnWidths(3, 2, columnInfos);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.ApplyColumnWidths(3,
                                                 2,
                                                 It.Is<IList<ColumnInfo>>(infos => infos.Count == 1), 
                                                 settings));

            Mock.Get(testObjects.FileProvider)
                .Verify(f => f.SaveChatPriceSummarySettings(settings));
        }

        [Test]
        public void ShouldSavePriceGridName()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings {MarketsId = 3}
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);


            // ACT
            testObjects.ChatPriceSummarySettingsService.SavePriceGridName(3, 2, "price-grid");
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.ApplyPriceGridName(3,
                                                  2,
                                                  "price-grid",
                                                  settings));

            Mock.Get(testObjects.FileProvider)
                .Verify(f => f.SaveChatPriceSummarySettings(settings));
        }

        [Test]
        public void ShouldSaveMarketsName()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings {MarketsId = 3}
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);


            // ACT
            testObjects.ChatPriceSummarySettingsService.SaveMarketsName(3, "markets");
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.ApplyMarketsName(3,
                                                "markets",
                                                settings));

            Mock.Get(testObjects.FileProvider)
                .Verify(f => f.SaveChatPriceSummarySettings(settings));
        }

        [Test]
        public void ShouldRemovePriceGrid()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings {MarketsId = 2}
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.ChatPriceSummarySettingsService.RemovePriceGrid(2, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.RemovePriceGrid(2, 1, settings));

            Mock.Get(testObjects.FileProvider)
                .Verify(f => f.SaveChatPriceSummarySettings(settings));
        }

        [Test]
        public void ShouldRemoveMarkets()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings {MarketsId = 2}
                }
            };

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.ChatPriceSummarySettingsService.RemoveMarkets(2);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Builder)
                .Verify(b => b.RemoveMarkets(2, settings));

            Mock.Get(testObjects.FileProvider)
                .Verify(f => f.SaveChatPriceSummarySettings(settings));
        }

        [Test]
        public void ShouldHandleSaveCurveFilterSettingsFailure()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings{MarketsId = 3}
                }
            };

            var markets = new[] { 10 };

            var exception = new Exception();

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithSaveSettingsException(exception)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.ChatPriceSummarySettingsService.SaveMarketsFilter(3, 2, markets);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger).
                 Verify(logger => logger.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldHandelSaveColumnFilterSettingsFailure()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings()
                }
            };

            var exception = new Exception();

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithSaveSettingsException(exception)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var columns = new[] { ColumnType.BidPrice };

            // ACT
            testObjects.ChatPriceSummarySettingsService.SaveColumnsFilter(1, 2, columns);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger).
                 Verify(logger => logger.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldHandleSaveColumnWidthSettingsFailure()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings(),
                }
            };

            var exception = new Exception();

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithSaveSettingsException(exception)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var columnInfos = new[] { new ColumnInfo(ColumnType.BidPrice, 0, null, null, false) };

            // ACT
            testObjects.ChatPriceSummarySettingsService.SaveColumnWidths(1, 2, columnInfos);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger).
                 Verify(logger => logger.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldHandleSavePriceGridNameFailure()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings(),
                }
            };

            var exception = new Exception();

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithSaveSettingsException(exception)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.ChatPriceSummarySettingsService.SavePriceGridName(1, 2, "price-grid");
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger).
                 Verify(logger => logger.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldHandleSaveMarketsNameFailure()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings(),
                }
            };

            var exception = new Exception();

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithSaveSettingsException(exception)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.ChatPriceSummarySettingsService.SaveMarketsName(3, "markets");
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger).
                 Verify(logger => logger.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldHandleRemovePriceGridFailure()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings(),
                }
            };

            var exception = new Exception();

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithSaveSettingsException(exception)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.ChatPriceSummarySettingsService.RemovePriceGrid(1, 2);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger).
                 Verify(logger => logger.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldHandleRemoveMarketsFailure()
        {
            var settings = new ChatPriceSummarySettings
            {
                ChatPriceMarkets = new[]
                {
                    new ChatPriceMarketsSettings(),
                }
            };

            var exception = new Exception();

            var testObjects = new ChatPriceSummarySettingsServiceTestObjectBuilder().WithLoadedSettings(settings)
                                                                                    .WithSaveSettingsException(exception)
                                                                                    .Build();

            testObjects.ChatPriceSummarySettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.ChatPriceSummarySettingsService.RemoveMarkets(2);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger).
                 Verify(logger => logger.Error(It.IsAny<string>()));
        }
    }
}
