﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Settings
{
    public interface IChatPriceColumnWidthServiceTestObjects
    {
        IChatPriceSummarySettingsService ChatPriceSummarySettingsService { get; }
        ChatPriceColumnWidthService ChatPriceColumnWidthService { get; }
    }

    [TestFixture]
    public class ChatPriceColumnWidthServiceTests
    {
        private class ChatPriceColumnWidthServiceTestObjectBuilder
        {
            private ChatPriceGridSettings _gridSettings;

            public ChatPriceColumnWidthServiceTestObjectBuilder WithGridSettings(ChatPriceGridSettings value)
            {
                _gridSettings = value;
                return this;
            }

            public IChatPriceColumnWidthServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceColumnWidthServiceTestObjects>();

                var settingsService = new Mock<IChatPriceSummarySettingsService>();

                settingsService.Setup(s => s.GetChatPriceGridSettings(It.IsAny<int>(), It.IsAny<int>()))
                               .Returns(_gridSettings);

                testObjects.SetupGet(o => o.ChatPriceSummarySettingsService)
                           .Returns(settingsService.Object);

                var columnWidthService = new ChatPriceColumnWidthService(settingsService.Object);

                testObjects.SetupGet(o => o.ChatPriceColumnWidthService)
                           .Returns(columnWidthService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldApplyColumnWidths()
        {

            var settings = new ChatPriceGridSettings
            {
                MarketBands = new[]
                {
                    new ChatPriceGridSettings.MarketBand
                    {
                        ChatPriceSummaryId = 10,
                        ColumnWidths = new[]
                        {
                            new ChatPriceGridSettings.ColumnWidth
                            {
                                ColumnType = ColumnType.BidPrice,
                                Width = 55
                            }
                        }
                    }
                }
            };

            var bands = new[]
            {
                new BandInfo(BandType.Price, 10, null, null, false,
                             new []
                             {
                                 new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 10),
                                 new ColumnInfo(ColumnType.AskPrice, 10, null, null, false, 10),
                             }),
            };

            var testObjects = new ChatPriceColumnWidthServiceTestObjectBuilder().WithGridSettings(settings)
                                                                                .Build();

            // ACT
            testObjects.ChatPriceColumnWidthService.ApplyColumnWidths(1, 2, bands);

            // ASSERT
            Assert.AreEqual(55, bands[0].ColumnInfos[0].Width);
            Assert.AreEqual(10, bands[0].ColumnInfos[1].Width);
        }

        [Test]
        public void ShouldHandleMissingMarketBandSetting_When_ApplyColumnWidths()
        {
            var settings = new ChatPriceGridSettings
            {
                MarketBands = new ChatPriceGridSettings.MarketBand[] {}
            };
      
            var bands = new[]
            {
                new BandInfo(BandType.Price, 10, null, null, false,
                             new []
                             {
                                 new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 10),
                                 new ColumnInfo(ColumnType.AskPrice, 10, null, null, false, 10),
                             }),
            };

            var testObjects = new ChatPriceColumnWidthServiceTestObjectBuilder().WithGridSettings(settings)
                                                                                .Build();

            // ACT
            testObjects.ChatPriceColumnWidthService.ApplyColumnWidths(1, 2, bands);

            // ASSERT
            Assert.AreEqual(10, bands[0].ColumnInfos[0].Width);
            Assert.AreEqual(10, bands[0].ColumnInfos[1].Width);
        }

        [Test]
        public void ShouldHandleNullSettings_When_ApplyColumnWidths()
        {
            var bands = new[]
            {
                new BandInfo(BandType.Price, 10, null, null, false,
                             new []
                             {
                                 new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 10),
                                 new ColumnInfo(ColumnType.AskPrice, 10, null, null, false, 10),
                             }),
            };

            var testObjects = new ChatPriceColumnWidthServiceTestObjectBuilder().WithGridSettings(null)
                                                                                .Build();

            // ACT
            testObjects.ChatPriceColumnWidthService.ApplyColumnWidths(1, 2, bands);

            // ASSERT
            Assert.AreEqual(10, bands[0].ColumnInfos[0].Width);
            Assert.AreEqual(10, bands[0].ColumnInfos[1].Width);
        }

        [Test]
        public void ShouldSaveColumnWidthChange()
        {
            var scheduler = new TestScheduler();

            var bidPriceColumn = new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 10);
            var bidTimeColumn = new ColumnInfo(ColumnType.BidTime, 10, null, null, false, 10);
            var askPriceColumn = new ColumnInfo(ColumnType.AskPrice, 10, null, null, false, 10);
            var askTimeColumn = new ColumnInfo(ColumnType.AskTime, 10, null, null, false, 10);

            var bands = new[]
            {
                new BandInfo(BandType.Price, 10, null, null, false,
                             new []
                             {
                                 bidPriceColumn,
                                 bidTimeColumn,
                                 askPriceColumn,
                                 askTimeColumn
                             }),
            };

            var testObjects = new ChatPriceColumnWidthServiceTestObjectBuilder().Build();

            testObjects.ChatPriceColumnWidthService.MonitorColumnWidthChanges(1, 2, bands, scheduler);

            // ACT
            bidPriceColumn.AdjustedWidth = 20;
            scheduler.AdvanceBy(TimeSpan.FromSeconds(1.5).Ticks);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .Verify(s => s.SaveColumnWidths(1, 2, It.Is<IList<ColumnInfo>>(cols => cols.Count == 1)), Times.Once);
        }

        [Test]
        public void ShouldBufferColumnWidthChanges()
        {
            var scheduler = new TestScheduler();

            var bidPriceColumn = new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 10);
            var bidTimeColumn = new ColumnInfo(ColumnType.BidTime, 10, null, null, false, 10);
            var askPriceColumn = new ColumnInfo(ColumnType.AskPrice, 10, null, null, false, 10);
            var askTimeColumn = new ColumnInfo(ColumnType.AskTime, 10, null, null, false, 10);

            var bands = new[]
            {
                new BandInfo(BandType.Price, 10, null, null, false,
                             new []
                             {
                                 bidPriceColumn,
                                 bidTimeColumn,
                                 askPriceColumn,
                                 askTimeColumn
                             }),
            };

            var testObjects = new ChatPriceColumnWidthServiceTestObjectBuilder().Build();

            testObjects.ChatPriceColumnWidthService.MonitorColumnWidthChanges(1, 2, bands, scheduler);

            // ACT
            bidPriceColumn.AdjustedWidth = 20;
            askPriceColumn.AdjustedWidth = 20;

            scheduler.AdvanceBy(TimeSpan.FromSeconds(1.5).Ticks);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .Verify(s => s.SaveColumnWidths(1, 2, It.Is<IList<ColumnInfo>>(cols => cols.Count == 2)), Times.Once);
        }

        [Test]
        public void ShouldNotSaveColumnWidthsWhenNoUpdatesInBufferPeriod()
        {
            var scheduler = new TestScheduler();

            var bidPriceColumn = new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 10);
            var bidTimeColumn = new ColumnInfo(ColumnType.BidTime, 10, null, null, false, 10);
            var askPriceColumn = new ColumnInfo(ColumnType.AskPrice, 10, null, null, false, 10);
            var askTimeColumn = new ColumnInfo(ColumnType.AskTime, 10, null, null, false, 10);

            var bands = new[]
            {
                new BandInfo(BandType.Price, 10, null, null, false,
                             new []
                             {
                                 bidPriceColumn,
                                 bidTimeColumn,
                                 askPriceColumn,
                                 askTimeColumn
                             }),
            };

            var testObjects = new ChatPriceColumnWidthServiceTestObjectBuilder().Build();

            testObjects.ChatPriceColumnWidthService.MonitorColumnWidthChanges(1, 2, bands, scheduler);

            // ACT
            bidPriceColumn.AdjustedWidth = 20;
            askPriceColumn.AdjustedWidth = 20;

            scheduler.AdvanceBy(TimeSpan.FromSeconds(1.5).Ticks);
            Mock.Get(testObjects.ChatPriceSummarySettingsService).Invocations.Clear();

            // ACT
            scheduler.AdvanceBy(TimeSpan.FromSeconds(1).Ticks);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .Verify(s => s.SaveColumnWidths(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<IList<ColumnInfo>>()), Times.Never);
        }

        [Test]
        public void ShouldNotSaveColumnWidthsWhenDisposed()
        {
            var scheduler = new TestScheduler();

            var bidPriceColumn = new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 10);
            var bidTimeColumn = new ColumnInfo(ColumnType.BidTime, 10, null, null, false, 10);
            var askPriceColumn = new ColumnInfo(ColumnType.AskPrice, 10, null, null, false, 10);
            var askTimeColumn = new ColumnInfo(ColumnType.AskTime, 10, null, null, false, 10);

            var bands = new[]
            {
                new BandInfo(BandType.Price, 10, null, null, false,
                             new []
                             {
                                 bidPriceColumn,
                                 bidTimeColumn,
                                 askPriceColumn,
                                 askTimeColumn
                             }),
            };

            var testObjects = new ChatPriceColumnWidthServiceTestObjectBuilder().Build();

            testObjects.ChatPriceColumnWidthService.MonitorColumnWidthChanges(1, 2, bands, scheduler);

            testObjects.ChatPriceColumnWidthService.Dispose();

            bidPriceColumn.AdjustedWidth = 20;
            askPriceColumn.AdjustedWidth = 20;

            // ACT
            scheduler.AdvanceBy(TimeSpan.FromSeconds(1.5).Ticks);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .Verify(s => s.SaveColumnWidths(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<IList<ColumnInfo>>()), Times.Never);
        }

        [Test]
        public void ShouldDisposeWhenDisposed()
        {
            var scheduler = new TestScheduler();

            var bidPriceColumn = new ColumnInfo(ColumnType.BidPrice, 10, null, null, false, 10);
            var bidTimeColumn = new ColumnInfo(ColumnType.BidTime, 10, null, null, false, 10);
            var askPriceColumn = new ColumnInfo(ColumnType.AskPrice, 10, null, null, false, 10);
            var askTimeColumn = new ColumnInfo(ColumnType.AskTime, 10, null, null, false, 10);

            var bands = new[]
            {
                new BandInfo(BandType.Price, 10, null, null, false,
                             new []
                             {
                                 bidPriceColumn,
                                 bidTimeColumn,
                                 askPriceColumn,
                                 askTimeColumn
                             }),
            };

            var testObjects = new ChatPriceColumnWidthServiceTestObjectBuilder().Build();

            testObjects.ChatPriceColumnWidthService.MonitorColumnWidthChanges(1, 2, bands, scheduler);

            testObjects.ChatPriceColumnWidthService.Dispose();
            testObjects.ChatPriceColumnWidthService.Dispose();

            bidPriceColumn.AdjustedWidth = 20;
            askPriceColumn.AdjustedWidth = 20;

            // ACT
            scheduler.AdvanceBy(TimeSpan.FromSeconds(1.5).Ticks);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummarySettingsService)
                .Verify(s => s.SaveColumnWidths(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<IList<ColumnInfo>>()), Times.Never);
        }
    }
}
