﻿using System;
using System.Collections.ObjectModel;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Markets
{
    public interface IChatPriceMarketsRemovalServiceTestObjects
    {
        IChatPriceSummarySettingsService SettingsService { get; }
        IChatPriceMarketsRemovalService ChatPriceMarketsRemovalService { get; }
    }

    [TestFixture]
    public class ChatPriceMarketsRemovalServiceTests
    {
        private class ChatPriceMarketsRemovalServiceTestObjectBuilder
        {
            public IChatPriceMarketsRemovalServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceMarketsRemovalServiceTestObjects>();

                var settingsService = new Mock<IChatPriceSummarySettingsService>();

                testObjects.SetupGet(o => o.SettingsService)
                           .Returns(settingsService.Object);

                var chatPriceMarketsRemovalService = new ChatPriceMarketsRemovalService(settingsService.Object);

                testObjects.SetupGet(o => o.ChatPriceMarketsRemovalService)
                           .Returns(chatPriceMarketsRemovalService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeMessageDialog_When_RegisterMarkets()
        {
            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>(),
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            // ASSERT
            Assert.IsNotNull(chatPriceSummary.RemoveMarketsDialogPrompt.Header);
            Assert.IsNotNull(chatPriceSummary.RemoveMarketsDialogPrompt.DialogNoCommand);
        }

        [Test]
        public void ShouldRemoveAndDisposeMarketsWithNoPrompt_When_RemoveMarkets_NoPriceGridsLoaded()
        {
            var chatPriceMarketsLoaded = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = true
                    }
                }
            };

            var controller = new Mock<IDisposable>();

            var chatPriceMarketsNotLoaded = new ChatPriceMarketsViewModel(controller.Object)
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = false
                    }
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarketsLoaded, chatPriceMarketsNotLoaded
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            // ACT
            testObjects.ChatPriceMarketsRemovalService.RemoveMarkets(chatPriceMarketsNotLoaded);

            // ASSERT
            Assert.AreEqual(1, chatPriceSummary.ChatPriceMarkets.Count);
            Assert.AreSame(chatPriceMarketsLoaded, chatPriceSummary.ChatPriceMarkets[0]);
            controller.Verify(c => c.Dispose());

            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.RemoveMarkets(2));
        }

        [Test]
        public void ShouldInvokeMessageDialogPrompt_When_RemoveMarkets_With_PriceGridLoaded()
        {
            var chatPriceMarketsLoaded = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = true
                    }
                }
            };

            var chatPriceMarketsNotLoaded = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = false
                    }
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarketsLoaded, chatPriceMarketsNotLoaded
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            // ACT
            testObjects.ChatPriceMarketsRemovalService.RemoveMarkets(chatPriceMarketsLoaded);

            // ASSERT
            Assert.IsTrue(chatPriceSummary.RemoveMarketsDialogPrompt.ShowDialog);
            Assert.AreEqual(2, chatPriceSummary.RemoveMarketsDialogPrompt.DialogMessages.Count);
            Assert.AreEqual(2, chatPriceSummary.ChatPriceMarkets.Count);
        }

        [Test]
        public void ShouldHideMessageDialogPrompt_And_RemoveMarkets_On_DialogYesCommand()
        {
            var controller = new Mock<IDisposable>();

            var chatPriceMarketsLoaded = new ChatPriceMarketsViewModel(controller.Object)
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = true
                    }
                }
            };

            var chatPriceMarketsNotLoaded = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = false
                    }
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarketsLoaded, chatPriceMarketsNotLoaded
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            testObjects.ChatPriceMarketsRemovalService.RemoveMarkets(chatPriceMarketsLoaded);

            // ACT
            chatPriceSummary.RemoveMarketsDialogPrompt.DialogYesCommand.Execute();

            // ASSERT
            Assert.IsFalse(chatPriceSummary.RemoveMarketsDialogPrompt.ShowDialog);

            Assert.AreEqual(1, chatPriceSummary.ChatPriceMarkets.Count);
            Assert.AreSame(chatPriceMarketsNotLoaded, chatPriceSummary.ChatPriceMarkets[0]);
            controller.Verify(c => c.Dispose());

            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.RemoveMarkets(1));
        }

        [Test]
        public void ShouldHideMessageDialogPrompt_And_NotRemoveMarkets_On_DialogNoCommand()
        {
            var chatPriceMarketsLoaded = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = true
                    }
                }
            };

            var chatPriceMarketsNotLoaded = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = false
                    }
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarketsLoaded, chatPriceMarketsNotLoaded
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            testObjects.ChatPriceMarketsRemovalService.RemoveMarkets(chatPriceMarketsLoaded);

            // ACT
            chatPriceSummary.RemoveMarketsDialogPrompt.DialogNoCommand.Execute();

            // ASSERT
            Assert.IsFalse(chatPriceSummary.RemoveMarketsDialogPrompt.ShowDialog);
            Assert.AreEqual(2, chatPriceSummary.ChatPriceMarkets.Count);

            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.RemoveMarkets(It.IsAny<int>()), Times.Never);
        }


        [Test]
        public void ShouldSetFirstMarketsAsSelected_When_SelectedMarketsRemoved()
        {
            var chatPriceMarkets1 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = false
                    }
                }
            };

            var controller = new Mock<IDisposable>();

            var chatPriceMarkets2 = new ChatPriceMarketsViewModel(controller.Object)
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                    {
                        PriceGridLoaded = false
                    }
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarkets1, chatPriceMarkets2
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            chatPriceMarkets2.IsSelected = true;

            // ACT
            testObjects.ChatPriceMarketsRemovalService.RemoveMarkets(chatPriceMarkets2);

            // ASSERT
            Assert.IsTrue(chatPriceMarkets1.IsSelected);
        }

        [Test]
        public void ShouldSetCanRemoveMarketsTrue_When_RegisterSummary_With_MultipleMarkets()
        {
            var chatPriceMarkets1 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceMarkets2 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarkets1, chatPriceMarkets2
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            // ASSERT
            Assert.IsTrue(chatPriceMarkets1.CanRemoveMarkets);
            Assert.IsTrue(chatPriceMarkets2.CanRemoveMarkets);
        }

        [Test]
        public void ShouldSetCanRemoveMarketsFalse_When_RegisterSummary_With_SingleMarkets()
        {
            var chatPriceMarkets1 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarkets1
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            // ASSERT
            Assert.IsFalse(chatPriceMarkets1.CanRemoveMarkets);
        }

        [Test]
        public void ShouldSetCanRemoveMarketsTrue_When_MarketsAdded()
        {
            var chatPriceMarkets1 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceMarkets2 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarkets1
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            // ACT
            chatPriceSummary.ChatPriceMarkets.Add(chatPriceMarkets2);

            // ASSERT
            Assert.IsTrue(chatPriceMarkets1.CanRemoveMarkets);
            Assert.IsTrue(chatPriceMarkets2.CanRemoveMarkets);
        }

        [Test]
        public void ShouldSetCanRemoveMarketsFalse_When_MarketsCountEqualsOne_After_MarketsRemoved()
        {
            var chatPriceMarkets1 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceMarkets2 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarkets1, chatPriceMarkets2
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);

            // ACT
            chatPriceSummary.ChatPriceMarkets.Remove(chatPriceMarkets2);

            // ASSERT
            Assert.IsFalse(chatPriceMarkets1.CanRemoveMarkets);
        }

        [Test]
        public void ShouldNotSetCanRemoveMarketsTrue_When_MarketsAdded_WithSummaryUnRegistered()
        {
            var chatPriceMarkets1 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceMarkets2 = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 2,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    new ChatPriceGridViewModel(Mock.Of<IDisposable>())
                }
            };

            var chatPriceSummary = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>
                {
                    chatPriceMarkets1
                },
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceMarketsRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceMarketsRemovalService.RegisterSummary(chatPriceSummary);
            testObjects.ChatPriceMarketsRemovalService.UnRegisterSummary(chatPriceSummary);

            // ACT
            chatPriceSummary.ChatPriceMarkets.Add(chatPriceMarkets2);

            // ASSERT
            Assert.IsFalse(chatPriceMarkets1.CanRemoveMarkets);
            Assert.IsFalse(chatPriceMarkets2.CanRemoveMarkets);
        }
    }
}
