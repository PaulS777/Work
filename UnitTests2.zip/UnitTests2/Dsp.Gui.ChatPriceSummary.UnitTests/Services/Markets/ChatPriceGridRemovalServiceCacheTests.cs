﻿using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Markets
{
    public interface IChatPriceGridRemovalServiceCacheTestObjects
    {
        ChatPriceGridRemovalServiceCache ChatPriceGridRemovalServiceCache { get; }
    }

    [TestFixture]
    public class ChatPriceGridRemovalServiceCacheTests
    {
        private class ChatPriceGridRemovalServiceCacheTestObjectBuilder
        {
            private IChatPriceGridRemovalService _chatPriceGridRemovalService;

            public ChatPriceGridRemovalServiceCacheTestObjectBuilder WithChatPriceGridRemovalService(IChatPriceGridRemovalService value)
            {
                _chatPriceGridRemovalService = value;
                return this;
            }

            public IChatPriceGridRemovalServiceCacheTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceGridRemovalServiceCacheTestObjects>();

                var factory = new Mock<IServiceFactory<IChatPriceGridRemovalService>>();

                factory.Setup(f => f.Create())
                       .Returns(_chatPriceGridRemovalService);

                var serviceCache = new ChatPriceGridRemovalServiceCache
                                   {
                                       ServiceFactory = factory.Object
                                   };

                testObjects.SetupGet(o => o.ChatPriceGridRemovalServiceCache)
                           .Returns(serviceCache);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetNewService_When_GetChatPriceGridRemovalService_WithNoExisting()
        {
            var gridRemovalService = Mock.Of<IChatPriceGridRemovalService>();

            var testObjects = new ChatPriceGridRemovalServiceCacheTestObjectBuilder().WithChatPriceGridRemovalService(gridRemovalService)
                                                                                     .Build();

            // ACT
            var result = testObjects.ChatPriceGridRemovalServiceCache.GetChatPriceGridRemovalService(1);

            // ASSERT
            Assert.AreSame(result, gridRemovalService);
        }

        [Test]
        public void ShouldGetExistingService_When_GetChatPriceGridRemovalService_WithExisting()
        {
            var gridRemovalService = Mock.Of<IChatPriceGridRemovalService>();

            var testObjects = new ChatPriceGridRemovalServiceCacheTestObjectBuilder().WithChatPriceGridRemovalService(gridRemovalService)
                                                                                     .Build();

            testObjects.ChatPriceGridRemovalServiceCache.GetChatPriceGridRemovalService(1);

            // ACT
            var result = testObjects.ChatPriceGridRemovalServiceCache.GetChatPriceGridRemovalService(1);

            // ASSERT
            Assert.AreSame(result, gridRemovalService);
        }
    }
}
