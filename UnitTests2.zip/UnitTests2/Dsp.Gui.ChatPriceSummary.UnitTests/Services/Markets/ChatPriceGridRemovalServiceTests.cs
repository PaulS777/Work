﻿using System;
using System.Collections.ObjectModel;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Markets
{
    public interface IChatPriceGridRemovalServiceTestObjects
    {
        IChatPriceSummarySettingsService SettingsService { get; }
        IChatPriceGridRemovalService ChatPriceGridRemovalService { get; }
    }

    [TestFixture]
    public class ChatPriceGridRemovalServiceTests
    {
        private class ChatPriceGridRemovalServiceTestObjectBuilder
        {
            public IChatPriceGridRemovalServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceGridRemovalServiceTestObjects>();

                var settingsService = new Mock<IChatPriceSummarySettingsService>();

                testObjects.SetupGet(o => o.SettingsService)
                           .Returns(settingsService.Object);

                var chatPriceGridRemovalService = new ChatPriceGridRemovalService(settingsService.Object);

                testObjects.SetupGet(o => o.ChatPriceGridRemovalService)
                           .Returns(chatPriceGridRemovalService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeMessageDialog_When_RegisterMarkets()
        {
            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                ChatPriceFilterDialog = new ChatPriceFilterDialogViewModel(),
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>(),
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            // ASSERT
            Assert.IsNotNull(chatPriceMarkets.MessageDialogPrompt.Header);
            Assert.IsNotNull(chatPriceMarkets.MessageDialogPrompt.DialogNoCommand);
        }

        [Test]
        public void ShouldRemoveGridWithNoPrompt_When_RemoveGrid_With_PriceGridLoadedFalse()
        {
            var controller = new Mock<IDisposable>();
            var grid1 = new ChatPriceGridViewModel(controller.Object) {PriceGridId = 1, PriceGridLoaded = false};
            var grid2 = new ChatPriceGridViewModel(Mock.Of<IDisposable>()) {PriceGridId = 2};

            var filterDialog = new ChatPriceFilterDialogViewModel
            {
                ChatPriceFilters = new ObservableCollection<ChatPriceGridFiltersViewModel>
                {
                    grid1.ChatPriceGridFilters, grid2.ChatPriceGridFilters
                }
            };

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 3,
                ChatPriceFilterDialog = filterDialog,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1, grid2
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            // ACT
            testObjects.ChatPriceGridRemovalService.RemoveGrid(grid1);

            // ASSERT
            Assert.AreEqual(1, chatPriceMarkets.ChatPriceGrids.Count);
            Assert.That(ReferenceEquals(chatPriceMarkets.ChatPriceGrids[0], grid2));
            controller.Verify(c => c.Dispose());

            Assert.AreEqual(1, filterDialog.ChatPriceFilters.Count);
            Assert.That(ReferenceEquals(filterDialog.ChatPriceFilters[0], grid2.ChatPriceGridFilters));

            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.RemovePriceGrid(3, 1));
        }

        [Test]
        public void ShouldInvokeMessageDialogPrompt_When_RemoveGrid_With_PriceGridLoaded()
        {
            var controller = new Mock<IDisposable>();

            var grid1 = new ChatPriceGridViewModel(controller.Object) { PriceGridLoaded = true };
            var grid2 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            var filterDialog = new ChatPriceFilterDialogViewModel()
            {
                ChatPriceFilters = new ObservableCollection<ChatPriceGridFiltersViewModel>
                {
                    grid1.ChatPriceGridFilters, grid2.ChatPriceGridFilters
                }
            };

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                ChatPriceFilterDialog = filterDialog,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1, grid2
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();


            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            // ACT
            testObjects.ChatPriceGridRemovalService.RemoveGrid(grid1);

            // ASSERT
            Assert.IsTrue(chatPriceMarkets.MessageDialogPrompt.ShowDialog);
            Assert.AreEqual(2, chatPriceMarkets.MessageDialogPrompt.DialogMessages.Count);
            Assert.AreEqual(2, chatPriceMarkets.ChatPriceGrids.Count);
        }

        [Test]
        public void ShouldHideMessageDialogPrompt_And_RemoveGrid_On_DialogYesCommand()
        {
            var controller = new Mock<IDisposable>();

            var grid1 = new ChatPriceGridViewModel(controller.Object) {PriceGridId = 1, PriceGridLoaded = true};
            var grid2 = new ChatPriceGridViewModel(Mock.Of<IDisposable>()){PriceGridId = 2};

            var filterDialog = new ChatPriceFilterDialogViewModel
            {
                ChatPriceFilters = new ObservableCollection<ChatPriceGridFiltersViewModel>
                {
                    grid1.ChatPriceGridFilters, grid2.ChatPriceGridFilters
                }
            };

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 3,
                ChatPriceFilterDialog = filterDialog,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1, grid2
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();


            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            testObjects.ChatPriceGridRemovalService.RemoveGrid(grid1);

            // ACT
            chatPriceMarkets.MessageDialogPrompt.DialogYesCommand.Execute();

            // ASSERT
            Assert.IsFalse(chatPriceMarkets.MessageDialogPrompt.ShowDialog);

            Assert.AreEqual(1, chatPriceMarkets.ChatPriceGrids.Count);
            Assert.That(ReferenceEquals(chatPriceMarkets.ChatPriceGrids[0], grid2));
            controller.Verify(c => c.Dispose());

            Assert.AreEqual(1, filterDialog.ChatPriceFilters.Count);
            Assert.That(ReferenceEquals(filterDialog.ChatPriceFilters[0], grid2.ChatPriceGridFilters));

            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.RemovePriceGrid(3, 1));
        }

        [Test]
        public void ShouldHideMessageDialogPrompt_And_NotRemoveGrid_On_DialogNoCommand()
        {
            var controller = new Mock<IDisposable>();

            var grid1 = new ChatPriceGridViewModel(controller.Object) { PriceGridLoaded = true };
            var grid2 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            var filterDialog = new ChatPriceFilterDialogViewModel
            {
                ChatPriceFilters = new ObservableCollection<ChatPriceGridFiltersViewModel>
                {
                    grid1.ChatPriceGridFilters, grid2.ChatPriceGridFilters
                }
            };

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                ChatPriceFilterDialog = filterDialog,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1, grid2
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };


            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();


            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            testObjects.ChatPriceGridRemovalService.RemoveGrid(grid1);

            // ACT
            chatPriceMarkets.MessageDialogPrompt.DialogNoCommand.Execute();

            // ASSERT
            Assert.IsFalse(chatPriceMarkets.MessageDialogPrompt.ShowDialog);

            Assert.AreEqual(2, chatPriceMarkets.ChatPriceGrids.Count);

            Mock.Get(testObjects.SettingsService)
                .Verify(s => s.RemovePriceGrid(It.IsAny<int>(), It.IsAny<int>()), Times.Never);
        }

        [Test]
        public void ShouldSetCanRemoveGridTrue_When_RegisterMarkets_With_MultipleGrids()
        {
            var grid1 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());
            var grid2 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                ChatPriceFilterDialog = new ChatPriceFilterDialogViewModel(),
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1, grid2
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();


            // ACT
            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            // ASSERT
            Assert.IsTrue(grid1.CanRemoveGrid);
            Assert.IsTrue(grid2.CanRemoveGrid);
        }

        [Test]
        public void ShouldSetCanRemoveGridFalse_When_RegisterMarkets_With_SingleGrid()
        {
            var grid1 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                ChatPriceFilterDialog = new ChatPriceFilterDialogViewModel(),
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();


            // ACT
            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            // ASSERT
            Assert.IsFalse(grid1.CanRemoveGrid);
        }

        [Test]
        public void ShouldSetCanRemoveGridTrue_When_GridAdded()
        {
            var grid1 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                ChatPriceFilterDialog = new ChatPriceFilterDialogViewModel(),
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            var grid2 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            // ACT
            chatPriceMarkets.ChatPriceGrids.Add(grid2);

            // ASSERT
            Assert.IsTrue(grid1.CanRemoveGrid);
            Assert.IsTrue(grid2.CanRemoveGrid);
        }

        [Test]
        public void ShouldSetCanRemoveGridFalse_When_GridCountEqualsOne_After_GridRemoved()
        {
            var grid1 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());
            var grid2 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                ChatPriceFilterDialog = new ChatPriceFilterDialogViewModel(),
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1, grid2
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);

            // ACT
            testObjects.ChatPriceGridRemovalService.RemoveGrid(grid2);

            // ASSERT
            Assert.IsFalse(grid1.CanRemoveGrid);
        }

        [Test]
        public void ShouldNotSetCanRemoveGridTrue_When_GridAdded_With_MarketsUnRegistered()
        {
            var grid1 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            var chatPriceMarkets = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                ChatPriceFilterDialog = new ChatPriceFilterDialogViewModel(),
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>
                {
                    grid1
                },
                MessageDialogPrompt = new MessageDialogPromptViewModel()
            };

            var testObjects = new ChatPriceGridRemovalServiceTestObjectBuilder().Build();

            testObjects.ChatPriceGridRemovalService.RegisterMarkets(chatPriceMarkets);
            testObjects.ChatPriceGridRemovalService.UnRegisterMarkets(chatPriceMarkets);

            var grid2 = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

            // ACT
            chatPriceMarkets.ChatPriceGrids.Add(grid2);

            // ASSERT
            Assert.IsFalse(grid1.CanRemoveGrid);
            Assert.IsFalse(grid2.CanRemoveGrid);
        }
    }
}
