﻿using System;
using System.Collections.ObjectModel;
using Dsp.Gui.ChatPriceSummary.Controllers;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.Markets
{
    [TestFixture]
    public class ChatPriceMarketsBuilderTests
    {
        public interface IChatPriceMarketsBuilderTestObjects
        {
            IChatPriceMarketsViewModelController ChatPriceMarketsViewModelController { get; }
            ChatPriceMarketsViewModel ChatPriceMarketsViewModel { get; }
            IChatPriceGridViewModelController ChatPriceGridViewModelController { get; }
            ChatPriceGridViewModel ChatPriceGridViewModel { get; }
            ChatPriceMarketsBuilder  ChatPriceMarketsBuilder { get; }
        }

        private class ChatPriceMarketsBuilderTestObjectBuilder
        {
            private IChatPriceGridRemovalService _chatPriceGridRemovalService;
            private int _marketsId;

            public ChatPriceMarketsBuilderTestObjectBuilder WithChatPriceGridRemovalService(IChatPriceGridRemovalService value)
            {
                _chatPriceGridRemovalService = value;
                return this;
            }

            public ChatPriceMarketsBuilderTestObjectBuilder WithMarketsId(int value)
            {
                _marketsId = value;
                return this;
            }

            public IChatPriceMarketsBuilderTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceMarketsBuilderTestObjects>();

                var chatPriceMarketsViewModel = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
                {
                    ChatPriceFilterDialog = new ChatPriceFilterDialogViewModel
                    {
                        ChatPriceFilters = new ObservableCollection<ChatPriceGridFiltersViewModel>()
                    },
                    ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>(),
                    MarketsId = _marketsId
                };

                testObjects.SetupGet(o => o.ChatPriceMarketsViewModel)
                           .Returns(chatPriceMarketsViewModel);

                var chatPriceMarketsViewModelController = new Mock<IChatPriceMarketsViewModelController>();

                chatPriceMarketsViewModelController.SetupGet(c => c.ViewModel)
                                                   .Returns(chatPriceMarketsViewModel);

                testObjects.SetupGet(o => o.ChatPriceMarketsViewModelController)
                           .Returns(chatPriceMarketsViewModelController.Object);

                var chatPriceGridViewModel = new ChatPriceGridViewModel(Mock.Of<IDisposable>());

                testObjects.SetupGet(o => o.ChatPriceGridViewModel)
                           .Returns(chatPriceGridViewModel);

                var chatPriceGridViewModelController = new Mock<IChatPriceGridViewModelController>();

                chatPriceGridViewModelController.SetupGet(c => c.ViewModel)
                                                .Returns(chatPriceGridViewModel);

                testObjects.SetupGet(o => o.ChatPriceGridViewModelController)
                           .Returns(chatPriceGridViewModelController.Object);

                var marketsFactory = new Mock<IServiceFactory<IChatPriceMarketsViewModelController>>();

                marketsFactory.Setup(f => f.Create())
                              .Returns(chatPriceMarketsViewModelController.Object);

                var gridFactory = new Mock<IServiceFactory<IChatPriceGridViewModelController>>();

                gridFactory.Setup(f => f.Create())
                           .Returns(chatPriceGridViewModelController.Object);

                var removalServiceCache = new Mock<IChatPriceGridRemovalServiceCache>();

                removalServiceCache.Setup(c => c.GetChatPriceGridRemovalService(It.IsAny<int>()))
                                   .Returns(_chatPriceGridRemovalService);

                var builder = new ChatPriceMarketsBuilder(removalServiceCache.Object)
                              {
                                  MarketsFactory = marketsFactory.Object,
                                  GridFactory = gridFactory.Object
                              };

                testObjects.SetupGet(o => o.ChatPriceMarketsBuilder)
                           .Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetMarketsAndInitializeFromSettings()
        {
            var gridRemovalService = new Mock<IChatPriceGridRemovalService>();

            var testObjects = new ChatPriceMarketsBuilderTestObjectBuilder().WithChatPriceGridRemovalService(gridRemovalService.Object)
                                                                            .WithMarketsId(2)
                                                                            .Build();

            var settings = new ChatPriceMarketsSettings
            {
                MarketsId = 2,
                MarketsName = "Markets",
                ChatPriceGrids = new[]
                {
                    new ChatPriceGridSettings
                    {
                        VisibleColumns = new[]
                        {
                            new ColumnType()
                        }
                    }
                }
            };

            // ACT
            var result = testObjects.ChatPriceMarketsBuilder.GetMarketsFromSettings(settings);

            // ASSERT
            Assert.IsNotNull(result);

            Mock.Get(testObjects.ChatPriceMarketsViewModelController)
                .Verify(c => c.Initialize(2, "Markets", gridRemovalService.Object));

            Assert.That(testObjects.ChatPriceMarketsViewModel.ChatPriceGrids.Count, Is.EqualTo(1));
            Assert.That(testObjects.ChatPriceMarketsViewModel.ChatPriceFilterDialog.ChatPriceFilters.Count, Is.EqualTo(1));

            Mock.Get(testObjects.ChatPriceGridViewModelController)
                .Verify(c => c.Initialize(2,
                                          It.Is<ChatPriceGridSettings>(s => s.VisibleColumns.Length == 1), 
                                          gridRemovalService.Object));
        }

        [Test]
        public void ShouldAddChatPriceGridToMarkets()
        {
            var gridRemovalService = new Mock<IChatPriceGridRemovalService>();

            var testObjects = new ChatPriceMarketsBuilderTestObjectBuilder().WithChatPriceGridRemovalService(gridRemovalService.Object)
                                                                            .Build();

            var dialog = new ChatPriceFilterDialogViewModel
            {
                ChatPriceFilters = new ObservableCollection<ChatPriceGridFiltersViewModel> { new() }
            };

            var marketsViewModel = new ChatPriceMarketsViewModel(Mock.Of<IDisposable>())
            {
                MarketsId = 1,
                ChatPriceFilterDialog = dialog,
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel> { new(Mock.Of<IDisposable>()) }
            };

            // ACT
            testObjects.ChatPriceMarketsBuilder.AddChatPriceGridToMarkets(2, marketsViewModel);

            // ASSERT
            Assert.That(marketsViewModel.ChatPriceGrids.Count, Is.EqualTo(2));
            Assert.That(marketsViewModel.ChatPriceFilterDialog.ChatPriceFilters.Count, Is.EqualTo(2));

            Mock.Get(testObjects.ChatPriceGridViewModelController)
                .Verify(c => c.Initialize(1, 
                                          2, 
                                          gridRemovalService.Object));
        }
    }
}
