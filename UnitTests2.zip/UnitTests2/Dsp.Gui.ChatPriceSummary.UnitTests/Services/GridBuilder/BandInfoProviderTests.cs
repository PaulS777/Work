﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.Services.GridBuilder;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.GridBuilder
{
    [TestFixture]
    public class BandInfoProviderTests
    {
        [Test]
        public void ShouldGetBandInfosFromChatPriceSummaryList()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

            var filter = new List<ChatPriceCurveFilterItem>
            {
                new(10, "code-1", "name-1", crude, CurveRegion.Europe),
                new(11, "code-2", "name-2", crude, CurveRegion.Europe)
            };

            var provider = new BandInfoProvider();

            // ACT
            var bands = provider.GetBandInfos(filter);

            // ASSERT
            Assert.That(bands.Count, Is.EqualTo(3));

            var band1 = bands[0];
            var band2 = bands[1];
            var band3 = bands[2];

            Assert.That(band1.BandType, Is.EqualTo(BandType.Tenor));
            Assert.That(band2.Id, Is.EqualTo(10));
            Assert.That(band2.BandType, Is.EqualTo(BandType.Price));
            Assert.That(band2.Header, Is.EqualTo("code-1"));
            Assert.That(band2.ToolTip, Is.EqualTo("name-1"));
            Assert.That(band2.IsAlternateBand, Is.False);

            Assert.That(band2.ColumnInfos.Count, Is.EqualTo(6));
            Assert.That(band2.ColumnInfos.All(ci => ci.IsAlternateBand == false));
            Assert.That(band2.ColumnInfos.All(ci => ci.BindingPath == "PriceCells[0]"));

            Assert.That(band2.ColumnInfos[0].Header, Is.EqualTo("Broker"));
            Assert.That(band2.ColumnInfos[1].Header, Is.EqualTo("Time"));
            Assert.That(band2.ColumnInfos[2].Header, Is.EqualTo("Bid"));
            Assert.That(band2.ColumnInfos[3].Header, Is.EqualTo("Offer"));
            Assert.That(band2.ColumnInfos[4].Header, Is.EqualTo("Time"));
            Assert.That(band2.ColumnInfos[5].Header, Is.EqualTo("Broker"));

            Assert.That(band2.ColumnInfos[0].ColumnType, Is.EqualTo(ColumnType.BidBroker));
            Assert.That(band2.ColumnInfos[1].ColumnType, Is.EqualTo(ColumnType.BidTime));
            Assert.That(band2.ColumnInfos[2].ColumnType, Is.EqualTo(ColumnType.BidPrice));
            Assert.That(band2.ColumnInfos[3].ColumnType, Is.EqualTo(ColumnType.AskPrice));
            Assert.That(band2.ColumnInfos[4].ColumnType, Is.EqualTo(ColumnType.AskTime));
            Assert.That(band2.ColumnInfos[5].ColumnType, Is.EqualTo(ColumnType.AskBroker));

            Assert.That(band3.Id, Is.EqualTo(11));
            Assert.That(band3.BandType, Is.EqualTo(BandType.Price));
            Assert.That(band3.Header, Is.EqualTo("code-2"));
            Assert.That(band3.ToolTip, Is.EqualTo("name-2"));
            Assert.That(band3.IsAlternateBand, Is.True);

            Assert.That(band3.ColumnInfos.Count, Is.EqualTo(6));
            Assert.That(band3.ColumnInfos.All(ci => ci.IsAlternateBand));
            Assert.That(band3.ColumnInfos.All(ci => ci.BindingPath == "PriceCells[1]"));

            Assert.That(band3.ColumnInfos[0].Header, Is.EqualTo("Broker"));
            Assert.That(band3.ColumnInfos[1].Header, Is.EqualTo("Time"));
            Assert.That(band3.ColumnInfos[2].Header, Is.EqualTo("Bid"));
            Assert.That(band3.ColumnInfos[3].Header, Is.EqualTo("Offer"));
            Assert.That(band3.ColumnInfos[4].Header, Is.EqualTo("Time"));
            Assert.That(band3.ColumnInfos[5].Header, Is.EqualTo("Broker"));

            Assert.That(band3.ColumnInfos[0].ColumnType, Is.EqualTo(ColumnType.BidBroker));
            Assert.That(band3.ColumnInfos[1].ColumnType, Is.EqualTo(ColumnType.BidTime));
            Assert.That(band3.ColumnInfos[2].ColumnType, Is.EqualTo(ColumnType.BidPrice));
            Assert.That(band3.ColumnInfos[3].ColumnType, Is.EqualTo(ColumnType.AskPrice));
            Assert.That(band3.ColumnInfos[4].ColumnType, Is.EqualTo(ColumnType.AskTime));
            Assert.That(band3.ColumnInfos[5].ColumnType, Is.EqualTo(ColumnType.AskBroker));
        }
    }
}
