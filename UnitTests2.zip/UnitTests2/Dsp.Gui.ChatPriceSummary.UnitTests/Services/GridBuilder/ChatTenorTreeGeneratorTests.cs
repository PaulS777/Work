﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.ChatPriceSummary.Services.GridBuilder;
using NUnit.Framework;

using ChatPriceTenor = Dsp.DataContracts.ChatScraper.ChatPriceSummary.ChatPriceTenor;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.GridBuilder
{
    [TestFixture]
    public class ChatTenorTreeGeneratorTests
    {
        [Test]
        public void ShouldGenerateTenorSequenceFromChatPriceSummary()
        {
            var annualTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new AnnualTenor(20200000).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new AnnualTenor(20210000).Key, null,null,null,null,null,null,null)
            };

            var quarterlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new QuarterlyTenor(2020, 4).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new QuarterlyTenor(2021, 1).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new QuarterlyTenor(2021, 2).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new QuarterlyTenor(2021, 3).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new QuarterlyTenor(2021, 4).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new QuarterlyTenor(2022, 1).Key, null,null,null,null,null,null,null),
            };

            var monthlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new MonthlyTenor(2020, 11).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new MonthlyTenor(2020, 12).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new MonthlyTenor(2021, 01).Key, null,null,null,null,null,null,null)
            };

            var summaries = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(1, null, null, monthlyTenors, quarterlyTenors, annualTenors, null)
            };

            var generator = new ChatTenorTreeGenerator();

            // ACT
            var result = generator.GetTenorSequence(summaries);

            // ASSERT
            Assert.AreEqual(24, result.Count);

            Assert.That(result[0].TenorType() == TenorType.Year && ((AnnualTenor)result[0]).Year == 2020);
            Assert.That(result[1].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[1]).Year == 2020 && ((QuarterlyTenor)result[1]).Quarter == 4);
            Assert.That(result[2].TenorType() == TenorType.Month && ((MonthlyTenor)result[2]).Year == 2020 && ((MonthlyTenor)result[2]).Month == 11);
            Assert.That(result[3].TenorType() == TenorType.Month && ((MonthlyTenor)result[3]).Year == 2020 && ((MonthlyTenor)result[3]).Month == 12);

            Assert.That(result[4].TenorType() == TenorType.Year && ((AnnualTenor)result[4]).Year == 2021);
            Assert.That(result[5].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[5]).Year == 2021 && ((QuarterlyTenor)result[5]).Quarter == 1);
            Assert.That(result[6].TenorType() == TenorType.Month && ((MonthlyTenor)result[6]).Year == 2021 && ((MonthlyTenor)result[6]).Month == 1);
            Assert.That(result[7].TenorType() == TenorType.Month && ((MonthlyTenor)result[7]).Year == 2021 && ((MonthlyTenor)result[7]).Month == 2);
            Assert.That(result[8].TenorType() == TenorType.Month && ((MonthlyTenor)result[8]).Year == 2021 && ((MonthlyTenor)result[8]).Month == 3);

            Assert.That(result[9].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[9]).Year == 2021 && ((QuarterlyTenor)result[9]).Quarter == 2);
            Assert.That(result[10].TenorType() == TenorType.Month && ((MonthlyTenor)result[10]).Year == 2021 && ((MonthlyTenor)result[10]).Month == 4);
            Assert.That(result[11].TenorType() == TenorType.Month && ((MonthlyTenor)result[11]).Year == 2021 && ((MonthlyTenor)result[11]).Month == 5);
            Assert.That(result[12].TenorType() == TenorType.Month && ((MonthlyTenor)result[12]).Year == 2021 && ((MonthlyTenor)result[12]).Month == 6);

            Assert.That(result[13].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[13]).Year == 2021 && ((QuarterlyTenor)result[13]).Quarter == 3);
            Assert.That(result[14].TenorType() == TenorType.Month && ((MonthlyTenor)result[14]).Year == 2021 && ((MonthlyTenor)result[14]).Month == 7);
            Assert.That(result[15].TenorType() == TenorType.Month && ((MonthlyTenor)result[15]).Year == 2021 && ((MonthlyTenor)result[15]).Month == 8);
            Assert.That(result[16].TenorType() == TenorType.Month && ((MonthlyTenor)result[16]).Year == 2021 && ((MonthlyTenor)result[16]).Month == 9);

            Assert.That(result[17].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[17]).Year == 2021 && ((QuarterlyTenor)result[17]).Quarter == 4);
            Assert.That(result[18].TenorType() == TenorType.Month && ((MonthlyTenor)result[18]).Year == 2021 && ((MonthlyTenor)result[18]).Month == 10);
            Assert.That(result[19].TenorType() == TenorType.Month && ((MonthlyTenor)result[19]).Year == 2021 && ((MonthlyTenor)result[19]).Month == 11);
            Assert.That(result[20].TenorType() == TenorType.Month && ((MonthlyTenor)result[20]).Year == 2021 && ((MonthlyTenor)result[20]).Month == 12);

            Assert.That(result[21].TenorType() == TenorType.Year && ((AnnualTenor)result[21]).Year == 2022);
            Assert.That(result[22].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[22]).Year == 2022 && ((QuarterlyTenor)result[22]).Quarter == 1);
            Assert.That(result[23].TenorType() == TenorType.Month && ((MonthlyTenor)result[23]).Year == 2022 && ((MonthlyTenor)result[23]).Month == 1);
        }

        [Test]
        public void ShouldGenerateTenorStartSequenceFromChatPriceSummary_WithMissingFirstYear()
        {
            var annualTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new AnnualTenor(20210000).Key, null,null,null,null,null,null,null)
            };

            var quarterlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new QuarterlyTenor(2021, 1).Key, null,null,null,null,null,null,null)
            };

            var monthlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new MonthlyTenor(2020, 11).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new MonthlyTenor(2020, 12).Key, null,null,null,null,null,null,null),
            };

            var summaries = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(1, null, null, monthlyTenors, quarterlyTenors, annualTenors, null)
            };

            var generator = new ChatTenorTreeGenerator();

            // ACT
            var result = generator.GetTenorSequence(summaries);

            // ASSERT
            Assert.That(result[0].TenorType() == TenorType.Year && ((AnnualTenor)result[0]).Year == 2020);
            Assert.That(result[1].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[1]).Year == 2020 && ((QuarterlyTenor)result[1]).Quarter == 4);
            Assert.That(result[2].TenorType() == TenorType.Month && ((MonthlyTenor)result[2]).Year == 2020 && ((MonthlyTenor)result[2]).Month == 11);
        }

        [Test]
        public void ShouldGenerateTenorStartSequenceFromChatPriceSummary_WithMissingFirstQuarter()
        {
            var annualTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new AnnualTenor(20200000).Key, null,null,null,null,null,null,null)
            };

            var quarterlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new QuarterlyTenor(2021, 1).Key, null,null,null,null,null,null,null)
            };

            var monthlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new MonthlyTenor(2020, 11).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new MonthlyTenor(2020, 12).Key, null,null,null,null,null,null,null),
            };

            var summaries = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(1, null, null, monthlyTenors, quarterlyTenors, annualTenors, null)
            };

            var generator = new ChatTenorTreeGenerator();

            // ACT
            var result = generator.GetTenorSequence(summaries);

            // ASSERT
            Assert.That(result[0].TenorType() == TenorType.Year && ((AnnualTenor)result[0]).Year == 2020);
            Assert.That(result[1].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[1]).Year == 2020 && ((QuarterlyTenor)result[1]).Quarter == 4);
            Assert.That(result[2].TenorType() == TenorType.Month && ((MonthlyTenor)result[2]).Year == 2020 && ((MonthlyTenor)result[2]).Month == 11);
        }


        [Test]
        public void ShouldGenerateTenorStartSequenceFromChatPriceSummary_WithMissingMonthsFromFirstQuarter()
        {
            var annualTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new AnnualTenor(20200000).Key, null,null,null,null,null,null,null)
            };

            var quarterlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new QuarterlyTenor(2020, 4).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new QuarterlyTenor(2021, 1).Key, null,null,null,null,null,null,null)
            };

            var monthlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new MonthlyTenor(2021, 01).Key, null,null,null,null,null,null,null),
            };

            var summaries = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(1, null, null, monthlyTenors, quarterlyTenors, annualTenors, null)
            };

            var generator = new ChatTenorTreeGenerator();

            // ACT
            var result = generator.GetTenorSequence(summaries);

            // ASSERT
            Assert.That(result[0].TenorType() == TenorType.Year && ((AnnualTenor)result[0]).Year == 2020);
            Assert.That(result[1].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[1]).Year == 2020 && ((QuarterlyTenor)result[1]).Quarter == 4);
            Assert.That(result[2].TenorType() == TenorType.Month && ((MonthlyTenor)result[2]).Year == 2020 && ((MonthlyTenor)result[2]).Month == 10);
        }

        [Test]
        public void ShouldGenerateTenorSequenceFromChatPriceSummary_With_YearTenorAsFinalTenor()
        {
            var annualTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new AnnualTenor(20200000).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new AnnualTenor(20210000).Key, null,null,null,null,null,null,null)
            };

            var quarterlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new QuarterlyTenor(2020, 4).Key, null,null,null,null,null,null,null)
            };

            var monthlyTenors = new List<ChatPriceTenor>
            {
                new ChatPriceTenor(new MonthlyTenor(2020, 11).Key, null,null,null,null,null,null,null),
                new ChatPriceTenor(new MonthlyTenor(2020, 12).Key, null,null,null,null,null,null,null)
            };

            var summaries = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(1, null, null, monthlyTenors, quarterlyTenors, annualTenors, null)
            };

            var generator = new ChatTenorTreeGenerator();

            // ACT
            var result = generator.GetTenorSequence(summaries);

            // ASSERT
            Assert.AreEqual(7, result.Count);

            Assert.That(result[0].TenorType() == TenorType.Year && ((AnnualTenor)result[0]).Year == 2020);
            Assert.That(result[1].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[1]).Year == 2020 && ((QuarterlyTenor)result[1]).Quarter == 4);
            Assert.That(result[2].TenorType() == TenorType.Month && ((MonthlyTenor)result[2]).Year == 2020 && ((MonthlyTenor)result[2]).Month == 11);
            Assert.That(result[3].TenorType() == TenorType.Month && ((MonthlyTenor)result[3]).Year == 2020 && ((MonthlyTenor)result[3]).Month == 12);

            Assert.That(result[4].TenorType() == TenorType.Year && ((AnnualTenor)result[4]).Year == 2021);
            Assert.That(result[5].TenorType() == TenorType.Quarter && ((QuarterlyTenor)result[5]).Year == 2021 && ((QuarterlyTenor)result[5]).Quarter == 1);
            Assert.That(result[6].TenorType() == TenorType.Month && ((MonthlyTenor)result[6]).Year == 2021 && ((MonthlyTenor)result[6]).Month == 1);
        }
    }
}
