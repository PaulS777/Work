﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.ChatPriceSummary.Services.GridBuilder;
using Moq;
using NUnit.Framework;
using ChatPriceTenor = Dsp.DataContracts.ChatScraper.ChatPriceSummary.ChatPriceTenor;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.GridBuilder
{
    public interface IChatPriceGridBuilderTestObjects
    {
        ChatPriceGridBuilder ChatPriceGridBuilder { get; }
    }

    [TestFixture]
    public class ChatPriceGridBuilderTests
    {
        private class ChatPriceGridBuilderTestObjectBuilder
        {
            private List<ITenor> _tenors;

            public ChatPriceGridBuilderTestObjectBuilder WithTenors(List<ITenor> values)
            {
                _tenors = values;
                return this;
            }

            public IChatPriceGridBuilderTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceGridBuilderTestObjects>();

                var tenorTreeGenerator = new Mock<IChatTenorTreeGenerator>();

                tenorTreeGenerator.Setup(g => g.GetTenorSequence(It.IsAny<IList<DataContracts.ChatScraper.ChatPriceSummary>>()))
                                  .Returns(_tenors);

                var builder = new ChatPriceGridBuilder(tenorTreeGenerator.Object);

                testObjects.SetupGet(o => o.ChatPriceGridBuilder)
                           .Returns(builder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldBuildGrid_From_ChatPriceSummaries()
        {
            var annualTenor = new AnnualTenor(20210000);
            var quarterlyTenor = new QuarterlyTenor(2021, 1);
            var monthlyTenor = new MonthlyTenor(2021, 1);

            var tenors = new List<ITenor>
            {
                annualTenor, quarterlyTenor, monthlyTenor
            };

            var chatPriceSummary1
                = new DataContracts.ChatScraper.ChatPriceSummary(10, "ice-code-1", "ice-name-1",
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(monthlyTenor.Key, null, null, null, null, null, null, null)
                                       },
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(quarterlyTenor.Key, null, null, null, null, null, null, null)
                                       },
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(annualTenor.Key, null, null, null, null, null, null, null)
                                       },
                                       null);

            var chatPriceSummary2
                = new DataContracts.ChatScraper.ChatPriceSummary(11, "ice-code-2", "ice-name-2",
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(monthlyTenor.Key, null, null, null, null, null, null, null)
                                       },
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(quarterlyTenor.Key, null, null, null, null, null, null, null)
                                       },
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(annualTenor.Key, null, null, null, null, null, null, null)
                                       },
                                       null);

            var chatPriceSummaries = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                chatPriceSummary1, chatPriceSummary2
            };

            var testObjects = new ChatPriceGridBuilderTestObjectBuilder().WithTenors(tenors)
                                                                         .Build();

            // ACT
            var result = testObjects.ChatPriceGridBuilder.GetChatPriceRows(chatPriceSummaries);

            // ASSERT
            Assert.AreEqual(3, result.Count);

            // ASSERT - ROW 1
            Assert.AreEqual(TenorType.Year, result[0].TenorType);
            Assert.AreEqual(annualTenor, result[0].Tenor);
            Assert.AreEqual(annualTenor.ToString(), result[0].TenorDisplay);
            Assert.IsNull(result[0].ParentTenorDisplay);
            Assert.AreEqual(2, result[0].PriceCells.Count);

            // ASSERT - ROW 1, COLUMN 1
            Assert.AreEqual(TenorType.Year, result[0].PriceCells[0].TenorType);
            Assert.IsFalse(result[0].PriceCells[0].AlternateBand);
            Assert.AreEqual(10, result[0].PriceCells[0].Model.Id);
            Assert.AreEqual(annualTenor, result[0].PriceCells[0].Model.Tenor);

            // ASSERT - ROW 1, COLUMN 2
            Assert.AreEqual(TenorType.Year, result[0].PriceCells[1].TenorType);
            Assert.IsTrue(result[0].PriceCells[1].AlternateBand);
            Assert.AreEqual(11, result[0].PriceCells[1].Model.Id);
            Assert.AreEqual(annualTenor, result[0].PriceCells[1].Model.Tenor);

            // ASSERT - ROW 2
            Assert.AreEqual(TenorType.Quarter, result[1].TenorType);
            Assert.AreEqual(quarterlyTenor, result[1].Tenor);
            Assert.AreEqual(quarterlyTenor.ToString(), result[1].TenorDisplay);
            Assert.AreEqual(annualTenor.ToString(), result[1].ParentTenorDisplay);
            Assert.AreEqual(2, result[1].PriceCells.Count);

            // ASSERT - ROW 2, COLUMN 1
            Assert.AreEqual(TenorType.Quarter, result[1].PriceCells[0].TenorType);
            Assert.IsFalse(result[1].PriceCells[0].AlternateBand);
            Assert.AreEqual(10, result[1].PriceCells[0].Model.Id);
            Assert.AreEqual(quarterlyTenor, result[1].PriceCells[0].Model.Tenor);

            // ASSERT - ROW 2, COLUMN 2
            Assert.AreEqual(TenorType.Quarter, result[1].PriceCells[1].TenorType);
            Assert.IsTrue(result[1].PriceCells[1].AlternateBand);
            Assert.AreEqual(11, result[1].PriceCells[1].Model.Id);
            Assert.AreEqual(quarterlyTenor, result[1].PriceCells[1].Model.Tenor);

            // ASSERT - ROW 3
            Assert.AreEqual(TenorType.Month, result[2].TenorType);
            Assert.AreEqual(monthlyTenor, result[2].Tenor);
            Assert.AreEqual(monthlyTenor.ToString(), result[2].TenorDisplay);
            Assert.AreEqual(quarterlyTenor.ToString(), result[2].ParentTenorDisplay);
            Assert.AreEqual(2, result[2].PriceCells.Count);

            // ASSERT - ROW 3, COLUMN 1
            Assert.AreEqual(TenorType.Month, result[2].PriceCells[0].TenorType);
            Assert.IsFalse(result[2].PriceCells[0].AlternateBand);
            Assert.AreEqual(10, result[2].PriceCells[0].Model.Id);
            Assert.AreEqual(monthlyTenor, result[2].PriceCells[0].Model.Tenor);

            // ASSERT - ROW 3, COLUMN 2
            Assert.AreEqual(TenorType.Month, result[2].PriceCells[1].TenorType);
            Assert.IsTrue(result[2].PriceCells[1].AlternateBand);
            Assert.AreEqual(11, result[2].PriceCells[1].Model.Id);
            Assert.AreEqual(monthlyTenor, result[2].PriceCells[1].Model.Tenor);
        }
    }
}
