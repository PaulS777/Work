﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.Gui.ChatPriceSummary.Common;
using Dsp.Gui.ChatPriceSummary.Services.GridUpdate;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.GridUpdate
{
    [TestFixture]
    public class ChatPriceDictionaryServiceTests
    {
        [Test]
        public void ShouldCreateDictionaryFromChatPriceRowViewModels()
        {
            var row1 = new ChatPriceRowViewModel(new MonthlyTenor(2020, 1))
            {
                PriceCells = new ObservableCollection<ChatPriceCellViewModel>
                {
                    new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(10, Mock.Of<ITenor>())),
                    new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(11, Mock.Of<ITenor>()))
                }
            };

            var row2 = new ChatPriceRowViewModel(new MonthlyTenor(2020, 2))
            {
                PriceCells = new ObservableCollection<ChatPriceCellViewModel>
                {
                    new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(10, Mock.Of<ITenor>())),
                    new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(11, Mock.Of<ITenor>()))
                }
            };

            var rows = new List<ChatPriceRowViewModel> { row1, row2 };

            var service = new ChatPriceDictionaryService();

            // ACT
            var result = service.CreateDictionary(rows);

            // ASSERT
            Assert.AreEqual(2, result.Count);

            Assert.AreEqual(10, result[10][0].Model.Id);
            Assert.AreEqual(10, result[10][1].Model.Id);

            Assert.AreEqual(11, result[11][0].Model.Id);
            Assert.AreEqual(11, result[11][1].Model.Id);
        }
    }
}
