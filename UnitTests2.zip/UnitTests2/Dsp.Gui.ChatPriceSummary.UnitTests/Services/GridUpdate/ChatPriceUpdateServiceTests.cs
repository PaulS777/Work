﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.ChatPriceSummary.Common;
using Dsp.Gui.ChatPriceSummary.Services.GridUpdate;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.GridUpdate
{
    public interface IChatPriceUpdateServiceTestObjects
    {
        IChatPriceSummaryStreamProvider ChatPriceSummaryStreamProvider { get; }
        ChatPriceUpdateService ChatPriceUpdateService { get; }
    }

    [TestFixture]
    public class ChatPriceUpdateServiceTests
    {
        private class ChatPriceUpdateServiceTestObjectBuilder
        {
            private IChatPriceSummaryMonitor _chatPriceSummaryMonitor;

            public ChatPriceUpdateServiceTestObjectBuilder WithChatPriceSummaryMonitor(IChatPriceSummaryMonitor value)
            {
                _chatPriceSummaryMonitor = value;
                return this;
            }

            public IChatPriceUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceUpdateServiceTestObjects>();

                var chatPriceSummaryStreamProvider = new Mock<IChatPriceSummaryStreamProvider>();

                testObjects.SetupGet(o => o.ChatPriceSummaryStreamProvider)
                           .Returns(chatPriceSummaryStreamProvider.Object);

                var factory = new Mock<IServiceFactory<IChatPriceSummaryMonitor>>();

                factory.Setup(f => f.Create())
                       .Returns(_chatPriceSummaryMonitor);

                var chatPriceUpdateService = new ChatPriceUpdateService(chatPriceSummaryStreamProvider.Object)
                                             {
                                                 MonitorFactory = factory.Object
                                             };

                testObjects.SetupGet(o => o.ChatPriceUpdateService)
                           .Returns(chatPriceUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldMonitorChatPrices_From_FilterIds()
        {
            var filter = new List<int> { 10 };

            var priceCells = new Dictionary<int, List<ChatPriceCellViewModel>>
            {
                {10, new List<ChatPriceCellViewModel>
                {
                    new(TenorType.Month, new ChatPrice(10, new MonthlyTenor(2021,1)))
                }}
            };

            var dispatcher = new Mock<IDispatcherExecutionService>();

            var monitor = new Mock<IChatPriceSummaryMonitor>();

            var testObjects = new ChatPriceUpdateServiceTestObjectBuilder().WithChatPriceSummaryMonitor(monitor.Object)
                                                                           .Build();

            // ACT
            testObjects.ChatPriceUpdateService.RefreshPriceMonitors(filter, priceCells, dispatcher.Object);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummaryStreamProvider)
                .Verify(p => p.GetPriceStream(10));

            monitor.Verify(m => m.MonitorChatPrices(It.IsAny<IObservable<DataContracts.ChatScraper.ChatPriceSummary>>(),
                                                    It.Is<List<ChatPriceCellViewModel>>(cells => cells.Count == 1),
                                                    dispatcher.Object));
        }

        [Test]
        public void ShouldRefreshMonitor_When_FilterUpdate_With_MatchingId()
        {
            var filter = new List<int> { 10 };

            var priceCells = new Dictionary<int, List<ChatPriceCellViewModel>>
            {
                {10, new List<ChatPriceCellViewModel>
                {
                    new(TenorType.Month, new ChatPrice(10, new MonthlyTenor(2021,1)))
                }}
            };

            var dispatcher = new Mock<IDispatcherExecutionService>();

            var monitor = new Mock<IChatPriceSummaryMonitor>();

            var testObjects = new ChatPriceUpdateServiceTestObjectBuilder().WithChatPriceSummaryMonitor(monitor.Object)
                                                                           .Build();

            testObjects.ChatPriceUpdateService.RefreshPriceMonitors(filter, priceCells, dispatcher.Object);

            // ACT
            testObjects.ChatPriceUpdateService.RefreshPriceMonitors(filter, priceCells, dispatcher.Object);

            // ASSERT
            Mock.Get(testObjects.ChatPriceSummaryStreamProvider)
                .Verify(p => p.GetPriceStream(10), Times.Exactly(2));

            monitor.Verify(m => m.MonitorChatPrices(It.IsAny<IObservable<DataContracts.ChatScraper.ChatPriceSummary>>(),
                                                    It.Is<List<ChatPriceCellViewModel>>(cells => cells.Count == 1),
                                                    dispatcher.Object), Times.Exactly(2));
        }

        [Test]
        public void ShouldDisposeExistingMonitor_When_FilterUpdate()
        {
            var filter = new List<int> { 10 };
            var filterUpdate = new List<int> { 10, 11 };

            var priceCells = new Dictionary<int, List<ChatPriceCellViewModel>>
            {
                {10, new List<ChatPriceCellViewModel>
                {
                    new(TenorType.Month, new ChatPrice(10, new MonthlyTenor(2021, 1)))
                }}
            };

            var dispatcher = new Mock<IDispatcherExecutionService>();

            var monitor = new Mock<IChatPriceSummaryMonitor>();

            var testObjects = new ChatPriceUpdateServiceTestObjectBuilder().WithChatPriceSummaryMonitor(monitor.Object)
                                                                           .Build();

            testObjects.ChatPriceUpdateService.RefreshPriceMonitors(filter, priceCells, dispatcher.Object);

            // ACT
            testObjects.ChatPriceUpdateService.RefreshPriceMonitors(filterUpdate, priceCells, dispatcher.Object);

            // ASSERT
            monitor.Verify(m => m.Dispose());
        }
    }
}
