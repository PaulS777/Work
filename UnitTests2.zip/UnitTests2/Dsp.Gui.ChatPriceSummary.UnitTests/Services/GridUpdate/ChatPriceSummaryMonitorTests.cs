﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.ChatPriceSummary.Common;
using Dsp.Gui.ChatPriceSummary.Services.GridUpdate;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

using ChatPriceTenor = Dsp.DataContracts.ChatScraper.ChatPriceSummary.ChatPriceTenor;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.GridUpdate
{
    [TestFixture]
    public class ChatPriceSummaryMonitorTests
    {
        [Test]
        public void ShouldUpdatePriceCellsFromPriceSummaryUpdate()
        {
            var priceCells = new List<ChatPriceCellViewModel>
            {
                new ChatPriceCellViewModel(TenorType.Year, new ChatPrice(10, new AnnualTenor(20210000))),
                new ChatPriceCellViewModel(TenorType.Quarter, new ChatPrice(10, new QuarterlyTenor(2021, 1))),
                new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(10, new MonthlyTenor(2021, 1)))
            };

            var time1 = new DateTime(2020, 12, 1, 10, 1, 0);
            var time2 = new DateTime(2020, 12, 1, 10, 2, 0);
            var time3 = new DateTime(2020, 12, 1, 10, 3, 0);
            var time4 = new DateTime(2020, 12, 1, 10, 4, 0);
            var time5 = new DateTime(2020, 12, 1, 10, 5, 0);
            var time6 = new DateTime(2020, 12, 1, 10, 6, 0);

            var chatPriceSummary
                = new DataContracts.ChatScraper.ChatPriceSummary(10,
                                       "ice-code",
                                       "ice-name",
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(new MonthlyTenor(2021, 1).Key, null, time1, 5.1, "broker-1", time2, 5.2, "broker-2")
                                       },
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(new QuarterlyTenor(2021, 1).Key, null, time3, 6.1, "broker-3", time4, 6.2, "broker-4")
                                       },
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(new AnnualTenor(20210000).Key, null, time5, 7.1, "broker-5", time6, 7.2, "broker-6")
                                       },
                                       null);

            var chatPriceSummaryStream = new Subject<DataContracts.ChatScraper.ChatPriceSummary>();

            var dispatcher = TestMocks.GetDispatcherExecutionService();

            var monitor = new ChatPriceSummaryMonitor();

            monitor.MonitorChatPrices(chatPriceSummaryStream, priceCells, dispatcher.Object);

            // ACT
            chatPriceSummaryStream.OnNext(chatPriceSummary);

            // ASSERT
            Assert.AreEqual(7.1, priceCells[0].BidPrice);
            Assert.AreEqual(7.2, priceCells[0].AskPrice);
            Assert.AreEqual("broker-5", priceCells[0].BidBroker);
            Assert.AreEqual("broker-6", priceCells[0].AskBroker);
            Assert.AreEqual(time5, priceCells[0].BidTime);
            Assert.AreEqual(time6, priceCells[0].AskTime);

            Assert.AreEqual(6.1, priceCells[1].BidPrice);
            Assert.AreEqual(6.2, priceCells[1].AskPrice);
            Assert.AreEqual("broker-3", priceCells[1].BidBroker);
            Assert.AreEqual("broker-4", priceCells[1].AskBroker);
            Assert.AreEqual(time3, priceCells[1].BidTime);
            Assert.AreEqual(time4, priceCells[1].AskTime);

            Assert.AreEqual(5.1, priceCells[2].BidPrice);
            Assert.AreEqual(5.2, priceCells[2].AskPrice);
            Assert.AreEqual("broker-1", priceCells[2].BidBroker);
            Assert.AreEqual("broker-2", priceCells[2].AskBroker);
            Assert.AreEqual(time1, priceCells[2].BidTime);
            Assert.AreEqual(time2, priceCells[2].AskTime);
        }

        [Test]
        public void ShouldNotUpdatePriceCells_When_NullChatPrices()
        {
            var priceCells = new List<ChatPriceCellViewModel>
            {
                new ChatPriceCellViewModel(TenorType.Year, new ChatPrice(10, new AnnualTenor(20210000))){BidPrice = 1.1},
                new ChatPriceCellViewModel(TenorType.Quarter, new ChatPrice(10, new QuarterlyTenor(2021, 1))){BidPrice = 2.1},
                new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(10, new MonthlyTenor(2021, 1))){BidPrice = 3.1}
            };

            var chatPriceSummary = new DataContracts.ChatScraper.ChatPriceSummary(10, "ice-code", "ice-name", null, null, null, null);

            var chatPriceSummaryStream = new Subject<DataContracts.ChatScraper.ChatPriceSummary>();

            var dispatcher = TestMocks.GetDispatcherExecutionService();

            var monitor = new ChatPriceSummaryMonitor();

            monitor.MonitorChatPrices(chatPriceSummaryStream, priceCells, dispatcher.Object);

            // ACT
            chatPriceSummaryStream.OnNext(chatPriceSummary);

            // ASSERT
            Assert.AreEqual(1.1, priceCells[0].BidPrice);
            Assert.AreEqual(2.1, priceCells[1].BidPrice);
            Assert.AreEqual(3.1, priceCells[2].BidPrice);
        }

        [Test]
        public void ShouldIgnoreChatPriceTenorWithUnmatchedTenor()
        {
            var priceCells = new List<ChatPriceCellViewModel>
            {
                new ChatPriceCellViewModel(TenorType.Year, new ChatPrice(10, new AnnualTenor(20210000))){BidPrice = 1.1},
                new ChatPriceCellViewModel(TenorType.Quarter, new ChatPrice(10, new QuarterlyTenor(2021, 1))){BidPrice = 2.1},
                new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(10, new MonthlyTenor(2021, 1))){BidPrice = 3.1}
            };

            var time1 = new DateTime(2020, 12, 1, 10, 1, 0);
            var time2 = new DateTime(2020, 12, 1, 10, 2, 0);

            var chatPriceSummary
                = new DataContracts.ChatScraper.ChatPriceSummary(10,
                                       "ice-code",
                                       "ice-name",
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(new MonthlyTenor(2021, 7).Key, null, time1, 5.1, "broker-1", time2, 5.2, "broker-2")
                                       },
                                       null,
                                       null,
                                       null);

            var chatPriceSummaryStream = new Subject<DataContracts.ChatScraper.ChatPriceSummary>();

            var dispatcher = TestMocks.GetDispatcherExecutionService();

            var monitor = new ChatPriceSummaryMonitor();

            monitor.MonitorChatPrices(chatPriceSummaryStream, priceCells, dispatcher.Object);

            // ACT
            chatPriceSummaryStream.OnNext(chatPriceSummary);

            // ASSERT
            Assert.AreEqual(1.1, priceCells[0].BidPrice);
            Assert.AreEqual(2.1, priceCells[1].BidPrice);
            Assert.AreEqual(3.1, priceCells[2].BidPrice);
        }

        [Test]
        public void ShouldNotUpdatePriceCells_When_Disposed()
        {
            var priceCells = new List<ChatPriceCellViewModel>
            {
                new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(10, new MonthlyTenor(2021, 1)))
            };

            var time1 = new DateTime(2020, 12, 1, 10, 1, 0);
            var time2 = new DateTime(2020, 12, 1, 10, 2, 0);

            var chatPriceSummary
                = new DataContracts.ChatScraper.ChatPriceSummary(10,
                                       "ice-code",
                                       "ice-name",
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(new MonthlyTenor(2021, 1).Key, null, time1, 5.1, "broker-1", time2, 5.2, "broker-2")
                                       },
                                       null,
                                       null,
                                       null);

            var chatPriceSummaryStream = new Subject<DataContracts.ChatScraper.ChatPriceSummary>();

            var dispatcher = TestMocks.GetDispatcherExecutionService();

            var monitor = new ChatPriceSummaryMonitor();

            monitor.MonitorChatPrices(chatPriceSummaryStream, priceCells, dispatcher.Object);

            monitor.Dispose();

            // ACT
            chatPriceSummaryStream.OnNext(chatPriceSummary);

            // ASSERT
            Assert.IsNull(priceCells[0].BidPrice);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var priceCells = new List<ChatPriceCellViewModel>
            {
                new ChatPriceCellViewModel(TenorType.Month, new ChatPrice(10, new MonthlyTenor(2021, 1)))
            };

            var time1 = new DateTime(2020, 12, 1, 10, 1, 0);
            var time2 = new DateTime(2020, 12, 1, 10, 2, 0);

            var chatPriceSummary
                = new DataContracts.ChatScraper.ChatPriceSummary(10,
                                       "ice-code",
                                       "ice-name",
                                       new List<ChatPriceTenor>
                                       {
                                           new ChatPriceTenor(new MonthlyTenor(2021, 1).Key, null, time1, 5.1, "broker-1", time2, 5.2, "broker-2")
                                       },
                                       null,
                                       null,
                                       null);

            var chatPriceSummaryStream = new Subject<DataContracts.ChatScraper.ChatPriceSummary>();

            var dispatcher = TestMocks.GetDispatcherExecutionService();

            var monitor = new ChatPriceSummaryMonitor();

            monitor.MonitorChatPrices(chatPriceSummaryStream, priceCells, dispatcher.Object);

            monitor.Dispose();
            monitor.Dispose();

            // ACT
            chatPriceSummaryStream.OnNext(chatPriceSummary);

            // ASSERT
            Assert.IsNull(priceCells[0].BidPrice);
        }
    }
}
