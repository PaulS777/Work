﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.Common;
using Dsp.Gui.ChatPriceSummary.Services.GridBuilder;
using Dsp.Gui.ChatPriceSummary.Services.GridUpdate;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.GridUpdate
{
    public interface IChatPriceGridRefreshServiceTestObjects
    {
        ICurveControlService CurveControlService { get; }
        IBandInfoProvider BandInfoProvider { get; }
        IChatPriceGridBuilder ChatPriceGridBuilder { get; }
        IChatPriceUpdateService ChatPriceUpdateService { get; }
        ISubject<List<DataContracts.ChatScraper.ChatPriceSummary>> ChatPriceSummarySnapshot { get; }
        ChatPriceGridRefreshService ChatPriceGridRefreshService { get; }
    }

    [TestFixture]
    public class ChatPriceGridRefreshServiceTests
    {
        private class ChatPriceGridRefreshServiceTestObjectBuilder
        {
            private List<DataContracts.ChatScraper.ChatPriceSummary> _chatPriceSummaries;
            private IList<BandInfo> _bandInfos;
            private Dictionary<int, List<ChatPriceCellViewModel>> _chatPriceDictionary;
            private List<ChatPriceRowViewModel> _chatPriceRows;

            public ChatPriceGridRefreshServiceTestObjectBuilder WithChatPriceSummaries(List<DataContracts.ChatScraper.ChatPriceSummary> values)
            {
                _chatPriceSummaries = values;
                return this;
            }

            public ChatPriceGridRefreshServiceTestObjectBuilder WithBandInfos(IList<BandInfo> values)
            {
                _bandInfos = values;
                return this;
            }

            public ChatPriceGridRefreshServiceTestObjectBuilder WithChatPriceDictionary(Dictionary<int, List<ChatPriceCellViewModel>> values)
            {
                _chatPriceDictionary = values;
                return this;
            }

            public ChatPriceGridRefreshServiceTestObjectBuilder WithGridBuilderResult(List<ChatPriceRowViewModel> values)
            {
                _chatPriceRows = values;
                return this;
            }

            public IChatPriceGridRefreshServiceTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceGridRefreshServiceTestObjects>();

                var snapshot = new BehaviorSubject<List<DataContracts.ChatScraper.ChatPriceSummary>>(_chatPriceSummaries);

                testObjects.SetupGet(o => o.ChatPriceSummarySnapshot)
                           .Returns(snapshot);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ChatPriceSummarySnapshot)
                                   .Returns(snapshot);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService.Object);

                var bandInfoProvider = new Mock<IBandInfoProvider>();

                bandInfoProvider.Setup(b => b.GetBandInfos(It.IsAny<List<ChatPriceCurveFilterItem>>()))
                                .Returns(_bandInfos);

                testObjects.SetupGet(o => o.BandInfoProvider)
                           .Returns(bandInfoProvider.Object);

                var chatPriceGridBuilder = new Mock<IChatPriceGridBuilder>();

                chatPriceGridBuilder.Setup(b => b.GetChatPriceRows(It.IsAny<IList<DataContracts.ChatScraper.ChatPriceSummary>>()))
                                    .Returns(_chatPriceRows);

                testObjects.SetupGet(o => o.ChatPriceGridBuilder)
                           .Returns(chatPriceGridBuilder.Object);

                var chatPriceDictionaryService = new Mock<IChatPriceDictionaryService>();

                chatPriceDictionaryService.Setup(d => d.CreateDictionary(It.IsAny<IList<ChatPriceRowViewModel>>()))
                                          .Returns(_chatPriceDictionary);

                var chatPriceUpdateService = new Mock<IChatPriceUpdateService>();

                testObjects.SetupGet(o => o.ChatPriceUpdateService)
                           .Returns(chatPriceUpdateService.Object);

                var chatPriceGridRefreshService
                    = new ChatPriceGridRefreshService(curveControlService.Object,
                                                      bandInfoProvider.Object,
                                                      chatPriceGridBuilder.Object,
                                                      chatPriceDictionaryService.Object,
                                                      chatPriceUpdateService.Object,
                                                      TestMocks.GetSchedulerProvider().Object,
                                                      TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.ChatPriceGridRefreshService)
                           .Returns(chatPriceGridRefreshService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetChatPriceSummarySnapshot_On_BuildGrid()
        {
            var dispatcher = new Mock<IDispatcherExecutionService>();
            var filter = new List<ChatPriceCurveFilterItem>();

            var testObjects = new ChatPriceGridRefreshServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ChatPriceGridRefreshService.BuildGrid(filter, dispatcher.Object);

            // ASSERT
            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.ChatPriceSummarySnapshot);
        }

        [Test]
        public void ShouldGenerateGrid_When_BuildGrid_With_ChatPriceSummarySnapshot()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var dispatcher = new Mock<IDispatcherExecutionService>();

            var filter = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", curveGroup, CurveRegion.Europe)
            };

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new(1, "ice-code-1", "name-1", [], [], [], [])
            };

            var testObjects = new ChatPriceGridRefreshServiceTestObjectBuilder().WithChatPriceSummaries(snapshot)
                                                                                .Build();

            // ACT
            testObjects.ChatPriceGridRefreshService.BuildGrid(filter, dispatcher.Object);

            // ASSERT
            Mock.Get(testObjects.BandInfoProvider)
                .Verify(b => b.GetBandInfos(filter));

            Mock.Get(testObjects.ChatPriceGridBuilder)
                .Verify(b => b.GetChatPriceRows(snapshot));
        }

        [Test]
        public void ShouldRefreshPriceMonitors_When_BuildGrid_With_ChatPriceSummarySnapshot()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var dispatcher = new Mock<IDispatcherExecutionService>();

            var filter = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", curveGroup, CurveRegion.Europe)
            };

			var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
                           {
                               new(1, "ice-code-1", "name-1", [], [], [], [])
                           };

			var dictionary = new Dictionary<int, List<ChatPriceCellViewModel>>
            {
                { 1, [ new(TenorType.Month, new ChatPrice(1, Mock.Of<ITenor>()))] }
            };

            var testObjects = new ChatPriceGridRefreshServiceTestObjectBuilder().WithChatPriceSummaries(snapshot)
                                                                                .WithChatPriceDictionary(dictionary)
                                                                                .Build();

            // ACT
            testObjects.ChatPriceGridRefreshService.BuildGrid(filter, dispatcher.Object);

            // ASSERT
            Mock.Get(testObjects.ChatPriceUpdateService)
                .Verify(u => u.RefreshPriceMonitors(It.Is<IList<int>>(ids => ids.Count == 1 && ids[0] == 1),
                                                    dictionary,
                                                    dispatcher.Object));
        }

        [Test]
        public void ShouldPublishBandsAndRows_When_BuildGrid_With_ChatPriceSummarySnapshot()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var dispatcher = new Mock<IDispatcherExecutionService>();

            var filter = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", curveGroup, CurveRegion.Europe)
            };

            var bandInfos = new[]
            {
                new BandInfo(BandType.Price, 10, "code", "name", false, [])
            };

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
                           {
                               new(1, "ice-code-1", "name-1", [], [], [], [])
                           };

			var chatPriceRows = new List<ChatPriceRowViewModel>
            {
                new(new MonthlyTenor(2020, 1))
            };

            var testObjects = new ChatPriceGridRefreshServiceTestObjectBuilder().WithChatPriceSummaries(snapshot)
                                                                                .WithGridBuilderResult(chatPriceRows)
                                                                                .WithBandInfos(bandInfos)
                                                                                .Build();
            ChatPriceGridRefreshArgs result = null;

            using (testObjects.ChatPriceGridRefreshService.GridRefresh.Subscribe(args => result = args))
            {
                // ACT
                testObjects.ChatPriceGridRefreshService.BuildGrid(filter, dispatcher.Object);

                // ASSERT
                Assert.AreSame(bandInfos, result.Bands);
                Assert.AreSame(chatPriceRows, result.ChatPriceRows);
            }
        }

        [Test]
        public void ShouldPublishEmptyGrid_When_BuildGrid_With_EmptyChatPriceSummarySnapshot()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var dispatcher = new Mock<IDispatcherExecutionService>();

            var filter = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", curveGroup, CurveRegion.Europe)
            };

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>();

            var testObjects = new ChatPriceGridRefreshServiceTestObjectBuilder().WithChatPriceSummaries(snapshot)
                                                                                .Build();


            ChatPriceGridRefreshArgs result = null;

            using (testObjects.ChatPriceGridRefreshService.GridRefresh.Subscribe(args => result = args))
            {
                // ACT
                testObjects.ChatPriceGridRefreshService.BuildGrid(filter, dispatcher.Object);

                // ASSERT
                Assert.That(result.Bands.Count, Is.EqualTo(0));
                Assert.That(result.ChatPriceRows.Count, Is.EqualTo(0));
            }
        }

        [Test]
        public void ShouldNotRebuildGridOnSecondSnapshotUpdate()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var dispatcher = new Mock<IDispatcherExecutionService>();

            var filter = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", curveGroup, CurveRegion.Europe)
            };

			var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
                           {
                               new(1, "ice-code-1", "name-1", [], [], [], [])
                           };

			var testObjects = new ChatPriceGridRefreshServiceTestObjectBuilder().WithChatPriceSummaries(snapshot)
                                                                                .Build();

            testObjects.ChatPriceGridRefreshService.BuildGrid(filter, dispatcher.Object);

            // ACT
            testObjects.ChatPriceSummarySnapshot.OnNext(snapshot);

            // ASSERT
            Mock.Get(testObjects.BandInfoProvider)
                .Verify(b => b.GetBandInfos(It.IsAny<List<ChatPriceCurveFilterItem>>()), Times.Once);

            Mock.Get(testObjects.ChatPriceGridBuilder)
                .Verify(b => b.GetChatPriceRows(It.IsAny<IList<DataContracts.ChatScraper.ChatPriceSummary>>()), Times.Once);
        }

        [Test]
        public void ShouldNotGenerateGrid_When_Disposed()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var dispatcher = new Mock<IDispatcherExecutionService>();

            var filter = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", curveGroup, CurveRegion.Europe)
            };

			var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
                           {
                               new(1, "ice-code-1", "name-1", [], [], [], [])
                           };

			var testObjects = new ChatPriceGridRefreshServiceTestObjectBuilder().Build();

            testObjects.ChatPriceGridRefreshService.BuildGrid(filter, dispatcher.Object);
            testObjects.ChatPriceGridRefreshService.Dispose();

            // ACT
            testObjects.ChatPriceSummarySnapshot.OnNext(snapshot);

            // ASSERT
            Mock.Get(testObjects.BandInfoProvider)
                .Verify(b => b.GetBandInfos(filter), Times.Never);

            Mock.Get(testObjects.ChatPriceGridBuilder)
                .Verify(b => b.GetChatPriceRows(snapshot), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var dispatcher = new Mock<IDispatcherExecutionService>();

            var filter = new List<ChatPriceCurveFilterItem>
            {
                new(1, "curve", "name", curveGroup, CurveRegion.Europe)
            };

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
                           {
                               new(1, "ice-code-1", "name-1", [], [], [], [])
                           };

			var testObjects = new ChatPriceGridRefreshServiceTestObjectBuilder().Build();

            testObjects.ChatPriceGridRefreshService.BuildGrid(filter, dispatcher.Object);
            testObjects.ChatPriceGridRefreshService.Dispose();

            // ACT
            testObjects.ChatPriceGridRefreshService.Dispose();
            testObjects.ChatPriceSummarySnapshot.OnNext(snapshot);

            // ASSERT
            Mock.Get(testObjects.BandInfoProvider)
                .Verify(b => b.GetBandInfos(filter), Times.Never);

            Mock.Get(testObjects.ChatPriceGridBuilder)
                .Verify(b => b.GetChatPriceRows(snapshot), Times.Never);
        }
    }
}
