﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.ChatPriceSummary.Services.GridUpdate;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.ChatPriceSummary.UnitTests.Services.GridUpdate
{
    public interface IChatPriceSummaryStreamProviderTestObjects
    {
        ISubject<List<DataContracts.ChatScraper.ChatPriceSummary>> Snapshot { get; }
        ISubject<List<DataContracts.ChatScraper.ChatPriceSummary>> Notifications { get; }
        ChatPriceSummaryStreamProvider ChatPriceSummaryStreamProvider { get; }
    }

    [TestFixture]
    public class ChatPriceSummaryStreamProviderTests
    {
        private class ChatPriceSummaryStreamProviderTestObjectBuilder
        {
            public IChatPriceSummaryStreamProviderTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceSummaryStreamProviderTestObjects>();

                var snapshot = new BehaviorSubject<List<DataContracts.ChatScraper.ChatPriceSummary>>(null);

                testObjects.SetupGet(o => o.Snapshot)
                           .Returns(snapshot);

                var notifications = new ReplaySubject<List<DataContracts.ChatScraper.ChatPriceSummary>>();

                testObjects.SetupGet(o => o.Notifications)
                           .Returns(notifications);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ChatPriceSummarySnapshot)
                                   .Returns(snapshot);

                curveControlService.SetupGet(c => c.ChatPriceSummaryNotifications)
                                   .Returns(notifications);

                var provider = new ChatPriceSummaryStreamProvider(curveControlService.Object);

                testObjects.SetupGet(o => o.ChatPriceSummaryStreamProvider)
                           .Returns(provider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldNotPublishNotificationsBeforeSnapshot()
        {
            var testObjects = new ChatPriceSummaryStreamProviderTestObjectBuilder().Build();

            var notification = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(10, null, null, null, null, null, null)
            };

            DataContracts.ChatScraper.ChatPriceSummary result = null;

            using (testObjects.ChatPriceSummaryStreamProvider.GetPriceStream(10)
                              .Subscribe(cps => result = cps))
            {
                testObjects.Notifications.OnNext(notification);

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldPublishSnapshot()
        {
            var testObjects = new ChatPriceSummaryStreamProviderTestObjectBuilder().Build();

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(10, null, null, null, null, null, null)
            };

            DataContracts.ChatScraper.ChatPriceSummary result = null;

            using (testObjects.ChatPriceSummaryStreamProvider.GetPriceStream(10)
                              .Subscribe(cps => result = cps))
            {
                testObjects.Snapshot.OnNext(snapshot);

                // ASSERT
                Assert.IsNotNull(result);
            }
        }

        [Test]
        public void ShouldPublishNotificationsAfterSnapshot()
        {
            var testObjects = new ChatPriceSummaryStreamProviderTestObjectBuilder().Build();

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(10, null, null, null, null, null, null)
            };
            var notification = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(10, null, null, null, null, null, null)
            };

            DataContracts.ChatScraper.ChatPriceSummary result = null;

            using (testObjects.ChatPriceSummaryStreamProvider.GetPriceStream(10)
                              .Subscribe(cps => result = cps))
            {
                testObjects.Notifications.OnNext(notification);
                testObjects.Snapshot.OnNext(snapshot);

                // ASSERT
                Assert.AreSame(notification[0], result);
            }
        }

        [Test]
        public void ShouldNotPublishSnapshot_WithUnMatchedId()
        {
            var testObjects = new ChatPriceSummaryStreamProviderTestObjectBuilder().Build();

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(99, null, null, null, null, null, null)
            };

            DataContracts.ChatScraper.ChatPriceSummary result = null;

            using (testObjects.ChatPriceSummaryStreamProvider.GetPriceStream(10)
                              .Subscribe(cps => result = cps))
            {
                testObjects.Snapshot.OnNext(snapshot);

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldNotPublishNotification_WithUnMatchedId()
        {
            var testObjects = new ChatPriceSummaryStreamProviderTestObjectBuilder().Build();

            var snapshot = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(10, null, null, null, null, null, null)
            };
            var notification = new List<DataContracts.ChatScraper.ChatPriceSummary>
            {
                new DataContracts.ChatScraper.ChatPriceSummary(99, null, null, null, null, null, null)
            };

            DataContracts.ChatScraper.ChatPriceSummary result = null;

            using (testObjects.ChatPriceSummaryStreamProvider.GetPriceStream(10)
                              .Subscribe(cps => result = cps))
            {
                testObjects.Snapshot.OnNext(snapshot);
                testObjects.Notifications.OnNext(notification);

                // ASSERT
                Assert.AreSame(snapshot[0], result);
            }
        }

    }
}
