﻿using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    public interface IPriceCurveServiceTestObjects
    {
        IPriceCurveSubscriptionManager PriceCurveSubscriptionManager { get; }
        ICurvePublisherConnectionService CurvePublisherConnectionService { get; }
        ICurvePublisherHubSubscriber CurvePublisherHubSubscriber { get; }
        ISubject<HubConnectionRunState> RunState { get; }
        IHubConnectionProxy HubConnectionProxy { get; }
        PriceCurveService PriceCurveService { get; }
    }

    [TestFixture]
    public class PriceCurveServiceTests
    {
        private class PriceCurveServiceTestObjectBuilder
        {
            private bool _isConnected;
            private List<int> _addPriceCurveSubscriptions;
            private List<int> _removePriceCurveSubscriptions;

            public PriceCurveServiceTestObjectBuilder WithIsConnected(bool value)
            {
                _isConnected = value;
                return this;
            }

            public PriceCurveServiceTestObjectBuilder WithAddPriceCurveSubscriptions(List<int> values)
            {
                _addPriceCurveSubscriptions = values;
                return this;
            }

            public PriceCurveServiceTestObjectBuilder WithRemovePriceCurveSubscriptions(List<int> values)
            {
                _removePriceCurveSubscriptions = values;
                return this;
            }

            public IPriceCurveServiceTestObjects Build()
            {
                var testObjects = new Mock<IPriceCurveServiceTestObjects>();

                var priceCurveSubscriptionManager = new Mock<IPriceCurveSubscriptionManager>();

                priceCurveSubscriptionManager.Setup(p => p.AddPriceCurves(It.IsAny<IList<int>>()))
                                             .Returns(_addPriceCurveSubscriptions);

                priceCurveSubscriptionManager.Setup(p => p.RemovePriceCurves(It.IsAny<IList<int>>()))
                                             .Returns(_removePriceCurveSubscriptions);

                testObjects.SetupGet(o => o.PriceCurveSubscriptionManager)
                           .Returns(priceCurveSubscriptionManager.Object);

                var runState = new Subject<HubConnectionRunState>();

                testObjects.SetupGet(o => o.RunState)
                           .Returns(runState);

                var hubConnectionProxy = new Mock<IHubConnectionProxy>();

                testObjects.SetupGet(o => o.HubConnectionProxy)
                           .Returns(hubConnectionProxy.Object);

                var curvePublisherConnectionService = new Mock<ICurvePublisherConnectionService>();

                curvePublisherConnectionService.SetupGet(c => c.HubConnectionProxy)
                                               .Returns(hubConnectionProxy.Object);

                curvePublisherConnectionService.SetupGet(c => c.RunState)
                                               .Returns(runState);

                curvePublisherConnectionService.SetupGet(c => c.IsConnected)
                                               .Returns(_isConnected);

                testObjects.SetupGet(o => o.CurvePublisherConnectionService)
                           .Returns(curvePublisherConnectionService.Object);

                var curvePublisherHubSubscriber = new Mock<ICurvePublisherHubSubscriber>();

                testObjects.SetupGet(o => o.CurvePublisherHubSubscriber)
                           .Returns(curvePublisherHubSubscriber.Object);

                var priceCurveService = new PriceCurveService(priceCurveSubscriptionManager.Object,
                                                              curvePublisherConnectionService.Object,
                                                              curvePublisherHubSubscriber.Object,
                                                              TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.PriceCurveService)
                           .Returns(priceCurveService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachHubEvents_OnConnected()
        {
            var testObjects = new PriceCurveServiceTestObjectBuilder().Build();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.Connected);

            // ASSERT
            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.AttachHubEvents(testObjects.PriceCurveService, testObjects.HubConnectionProxy));
        }

        [Test]
        public void ShouldNotAttachHubEvents_OnFailedStartup()
        {
            var testObjects = new PriceCurveServiceTestObjectBuilder().Build();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.FailedStartup);

            // ASSERT
            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.AttachHubEvents(testObjects.PriceCurveService, testObjects.HubConnectionProxy), Times.Never);
        }

        #region SubscribePriceCurves

        [Test]
        public void ShouldAddCurves_And_InvokeHubSubscriber_When_SubscribePriceCurves_With_IsConnectedTrue()
        {
            var subscriptions = new List<int>{ 102 };

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(true)
                                                                      .WithAddPriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.SubscribeToPriceCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.AddPriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.SubscribePriceCurves(subscriptions));
        }

        [Test]
        public void ShouldNotInvokeHubSubscriber_When_SubscribePriceCurves_With_AddCurvesEmpty()
        {
            var subscriptions = new List<int>();

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(true)
                                                                      .WithAddPriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.SubscribeToPriceCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.AddPriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.SubscribePriceCurves(It.IsAny<List<int>>()), Times.Never);
        }

        [Test]
        public void ShouldNotInvokeHubSubscriber_When_SubscribePriceCurves_With_IsConnectedFalse()
        {
            var subscriptions = new List<int> { 101 };

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(false)
                                                                      .WithAddPriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.SubscribeToPriceCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.AddPriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.SubscribePriceCurves(It.IsAny<List<int>>()), Times.Never);
        }

        #endregion

        #region UnsubscribePriceCurves

        [Test]
        public void ShouldRemoveCurves_And_InvokeHubSubscriber_When_UnsubscribePriceCurves_With_IsConnectedTrue()
        {
            var subscriptions = new List<int> { 102 };

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(true)
                                                                      .WithRemovePriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.UnsubscribeFromPriceCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.RemovePriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.UnsubscribePriceCurves(subscriptions));
        }

        [Test]
        public void ShouldNotInvokeHubSubscriber_When_UnsubscribePriceCurves_With_RemoveCurvesEmpty()
        {
            var subscriptions = new List<int>();

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(true)
                                                                      .WithRemovePriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.UnsubscribeFromPriceCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.RemovePriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.UnsubscribePriceCurves(It.IsAny<List<int>>()), Times.Never);
        }

        [Test]
        public void ShouldNotInvokeHubSubscriber_When_UnsubscribePriceCurves_With_IsConnectedFalse()
        {
            var subscriptions = new List<int> { 101 };

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(false)
                                                                      .WithRemovePriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.UnsubscribeFromPriceCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.RemovePriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.UnsubscribePriceCurves(It.IsAny<List<int>>()), Times.Never);
        }

        #endregion

        #region SubscribeFxCurves

        [Test]
        public void ShouldAddCurves_And_InvokeHubSubscriber_When_SubscribeFxCurves_With_Connected()
        {
            var subscriptions = new List<int> { 102 };

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(true)
                                                                      .WithAddPriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.SubscribeToFxCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.AddPriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.SubscribeFxCurves(subscriptions));
        }

        [Test]
        public void ShouldNotInvokeHubSubscriber_When_SubscribeFxCurves_With_AddCurvesEmpty()
        {
            var subscriptions = new List<int>();

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(true)
                                                                      .WithAddPriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.SubscribeToFxCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.AddPriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.SubscribeFxCurves(It.IsAny<List<int>>()), Times.Never);
        }

        [Test]
        public void ShouldNotInvokeHubSubscriber_When_SubscribeFxCurves_With_ConnectedFalse()
        {
            var subscriptions = new List<int> { 101 };

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(false)
                                                                      .WithAddPriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.SubscribeToFxCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.AddPriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.SubscribeFxCurves(It.IsAny<List<int>>()), Times.Never);
        }

        #endregion

        #region UnsubscribeFxCurves

        [Test]
        public void ShouldRemoveCurves_And_InvokeHubSubscriber_When_UnsubscribeFxCurves_With_Connected()
        {
            var subscriptions = new List<int> { 102 };

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(true)
                                                                      .WithRemovePriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.UnsubscribeFromFxCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.RemovePriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.UnsubscribeFxCurves(subscriptions));
        }

        [Test]
        public void ShouldNotInvokeHubSubscriber_When_UnsubscribeFxCurves_With_RemoveCurvesEmpty()
        {
            var subscriptions = new List<int>();

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(true)
                                                                      .WithRemovePriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.UnsubscribeFromFxCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.RemovePriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.UnsubscribeFxCurves(It.IsAny<List<int>>()), Times.Never);
        }

        [Test]
        public void ShouldNotInvokeHubSubscriber_When_UnsubscribeFxCurves_With_ConnectedFalse()
        {
            var subscriptions = new List<int> { 101 };

            var testObjects = new PriceCurveServiceTestObjectBuilder().WithIsConnected(false)
                                                                      .WithRemovePriceCurveSubscriptions(subscriptions)
                                                                      .Build();

            var curveIds = new[] { 101, 102 };

            // ACT
            testObjects.PriceCurveService.UnsubscribeFromFxCurves(curveIds);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.RemovePriceCurves(curveIds));

            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.UnsubscribeFxCurves(It.IsAny<List<int>>()), Times.Never);
        }

        #endregion

        #region Snapshots and Notifications

        [Test]
        public void ShouldInvokeSubscriptionManager_OnPriceCurveSnapshot()
        {
            var priceCurves = new[] { new PriceCurveBuilder().Build() };

            var testObjects = new PriceCurveServiceTestObjectBuilder().Build();

            // ACT
            testObjects.PriceCurveService.OnPriceCurvesSnapshot(priceCurves);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.UpdatePriceCurves(priceCurves));
        }

        [Test]
        public void ShouldInvokeSubscriptionManager_OnPriceCurveNotification()
        {
            var priceCurve = new PriceCurveBuilder().Build();

            var testObjects = new PriceCurveServiceTestObjectBuilder().Build();

            // ACT
            testObjects.PriceCurveService.OnPriceCurveNotification(priceCurve);

            var expected = new[] { priceCurve };

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.UpdatePriceCurves(It.Is<IEnumerable<PriceCurve>>(p => p.SequenceEqual(expected))));
        }

        [Test]
        public void ShouldInvokeSubscriptionManager_OnFxCurveSnapshot()
        {
            var fxCurves = new[] { new PriceCurveBuilder().BuildFx() };

            var testObjects = new PriceCurveServiceTestObjectBuilder().Build();

            // ACT
            testObjects.PriceCurveService.OnFxCurvesSnapshot(fxCurves);

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.UpdateFxCurves(fxCurves));
        }

        [Test]
        public void ShouldInvokeSubscriptionManager_OnFxCurveNotification()
        {
            var fxCurve = new PriceCurveBuilder().BuildFx();

            var testObjects = new PriceCurveServiceTestObjectBuilder().Build();

            // ACT
            testObjects.PriceCurveService.OnFxCurveNotification(fxCurve);

            var expected = new[] { fxCurve };

            // ASSERT
            Mock.Get(testObjects.PriceCurveSubscriptionManager)
                .Verify(s => s.UpdateFxCurves(It.Is<IEnumerable<FxPriceCurve>>(p => p.SequenceEqual(expected))));
        }

        #endregion

        [Test]
        public void ShouldNotAttachHubEvents_When_Dispose()
        {
            var testObjects = new PriceCurveServiceTestObjectBuilder().Build();

            testObjects.PriceCurveService.Dispose();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.Connected);

            // ASSERT
            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.AttachHubEvents(testObjects.PriceCurveService, testObjects.HubConnectionProxy), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new PriceCurveServiceTestObjectBuilder().Build();

            testObjects.PriceCurveService.Dispose();

            // ACT
            testObjects.PriceCurveService.Dispose();
            testObjects.RunState.OnNext(HubConnectionRunState.Connected);

            // ASSERT
            Mock.Get(testObjects.CurvePublisherHubSubscriber)
                .Verify(h => h.AttachHubEvents(testObjects.PriceCurveService, testObjects.HubConnectionProxy), Times.Never);
        }
    }
}
