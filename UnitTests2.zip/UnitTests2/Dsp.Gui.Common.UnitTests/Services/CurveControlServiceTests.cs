﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    public interface ICurveControlServiceTestObjects
    {
        IAdminApiConnectionService AdminApiConnectionService { get; }
        IAdminApiHubConnection AdminApiHubConnection { get; }
        ISubject<HubConnectionRunState> RunState { get; }
        ISubject<User> CurrentUser { get; }
        IHubConnectionProxy HubConnectionProxy { get; }
        CurveControlService CurveControlService { get; }
    }

    [TestFixture]
    public class CurveControlServiceTests
    {
        private class CurveControlServiceTestObjectBuilder
        {
            private HubConnectionRunState _runState;
            private User _currentUser;

            public CurveControlServiceTestObjectBuilder WithRunState(HubConnectionRunState value)
            {
                _runState = value;
                return this;
            }

            public CurveControlServiceTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

            public ICurveControlServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveControlServiceTestObjects>();


                var hubConnectionProxy = new Mock<IHubConnectionProxy>();

                testObjects.SetupGet(o => o.HubConnectionProxy)
                           .Returns(hubConnectionProxy.Object);

                var currentUser = new BehaviorSubject<User>(_currentUser);

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var runState = new BehaviorSubject<HubConnectionRunState>(_runState);

                testObjects.SetupGet(o => o.RunState)
                           .Returns(runState);

                var adminApiConnectionService = new Mock<IAdminApiConnectionService>();

                adminApiConnectionService.SetupGet(a => a.HubConnectionProxy)
                                         .Returns(hubConnectionProxy.Object);

                adminApiConnectionService.SetupGet(a => a.RunState)
                                         .Returns(runState);

                adminApiConnectionService.SetupGet(a => a.CurrentUser)
                                         .Returns(currentUser);

                testObjects.SetupGet(o => o.AdminApiConnectionService)
                           .Returns(adminApiConnectionService.Object);

                var adminApiHubConnection = new Mock<IAdminApiHubConnection>();

                testObjects.SetupGet(o => o.AdminApiHubConnection)
                           .Returns(adminApiHubConnection.Object);

                var curveControlService = new CurveControlService(Mocks.GetLoggerFactory().Object,
                                                                  adminApiConnectionService.Object,
                                                                  adminApiHubConnection.Object);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachHubEvents_OnConnected()
        {
            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.Connected);

            // ASSERT
            Mock.Get(testObjects.AdminApiHubConnection)
                .Verify(a => a.AttachHubEvents(testObjects.CurveControlService, testObjects.HubConnectionProxy));
        }

        [Test]
        public void ShouldSubscribeAll_On_Connected()
        {
            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.Connected);

            // ASSERT
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribePriceCurveDefinitions());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeDerivedCurveDefinitions());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeCurvePublishers());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeUsers());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeFxCurveDefinitions());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeChatUsers());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeChatMarkets());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeChatMessageHistory());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeChatIceMap());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeChatVariableShortcut());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeChatPriceSummary());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeServiceStatusNotification());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeCalendars());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeMonthEndRollStatus());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeConfiguration());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribeSystemDate());
        }

        [Test]
        public void ShouldNotAttachHubEvents_Or_SubscribeAll_OnFailedStartup()
        {
            var testObjects = new CurveControlServiceTestObjectBuilder().WithRunState(HubConnectionRunState.NotSet)
                                                                        .Build();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.FailedStartup);

            // ASSERT
            Mock.Get(testObjects.AdminApiHubConnection)
                .Verify(a => a.AttachHubEvents(testObjects.CurveControlService, testObjects.HubConnectionProxy), Times.Never);

            Mock.Get(testObjects.AdminApiHubConnection)
                .Verify(hp => hp.SubscribePriceCurveDefinitions(), Times.Never);
        }

        [Test]
        public void ShouldNotAttachHubEvents_Or_SubscribeAll_On_DuplicateConnected()
        {
            var testObjects = new CurveControlServiceTestObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                        .Build();

            Mock.Get(testObjects.AdminApiHubConnection).Invocations.Clear();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.Connected);

            // ASSERT
            Mock.Get(testObjects.AdminApiHubConnection)
                .Verify(a => a.AttachHubEvents(testObjects.CurveControlService, testObjects.HubConnectionProxy), Times.Never);

            Mock.Get(testObjects.AdminApiHubConnection)
                .Verify(hp => hp.SubscribePriceCurveDefinitions(), Times.Never);
        }

        [Test]
        public void ShouldNotAttachHubEvents_OnReconnected()
        {
            var testObjects = new CurveControlServiceTestObjectBuilder().WithRunState(HubConnectionRunState.NotSet)
                                                                        .Build();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Mock.Get(testObjects.AdminApiHubConnection)
                .Verify(a => a.AttachHubEvents(testObjects.CurveControlService, testObjects.HubConnectionProxy), Times.Never);
        }

        [Test]
        public void ShouldSubscribeAll_OnReconnected()
        {
            var testObjects = new CurveControlServiceTestObjectBuilder().WithRunState(HubConnectionRunState.NotSet)
                                                                        .Build();

            // ACT
            testObjects.RunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Mock.Get(testObjects.AdminApiHubConnection).Verify(hp => hp.SubscribePriceCurveDefinitions());
        }

        [Test]
        public void ShouldPublishPriceCurves_OnPriceCurveSnapshotNotification()
        {
            var curveSettings = new List<PriceCurveSetting>
                                {
                                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build()
                                };

            var priceCurvePremiums = new List<PriceCurvePremium> 
                                     {
                                         new(101, 
                                             new List<VolumePremium>
                                                  {
                                                      new(20,0.5,0.5)
                                                  },
                                             new List<ValidityPremium>
                                             {
                                                 new(20,0.5,0.5)
                                             },
                                             new PriceCurveFees(101,0.005,0,0,0,0)
                                             )
                                     };

            var publisherTenorPremiums = new List<PublisherTenorPremium>();

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            List<PriceCurveSetting> result = null;

            using (curveControlService.PriceCurveSettings.Subscribe(settings => result = settings))
            {
                // ACT
                curveControlService.OnPriceCurveSnapshotNotification(curveSettings, priceCurvePremiums, publisherTenorPremiums);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishPriceCurveSettings_OnPriceCurveSettingsUpdates()
        {
            var curveSettings = new List<PriceCurveSetting>
                                {
                                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build()
                                };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            List<PriceCurveSetting> result = null;

            using (curveControlService.PriceCurveSettings.Subscribe(settings => result = settings))
            {
                // ACT
                curveControlService.OnPriceCurveSettingsUpdates(curveSettings);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishProductDefinitions_OnProductDefinitionsSnapshot()
        {
            var priceCurveDefinitions = new List<ProductDefinition>
                                        {
                                            new ProductDefinitionTestObjectBuilder().Build()
                                        };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<ProductDefinition> result = null;

            using (curveControlService.ProductDefinitions.Subscribe(values => result = values))
            {
                // ACT
                curveControlService.OnProductDefinitionsSnapshot(priceCurveDefinitions);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishProductDefinitions_OnProductDefinitionsNotifications()
        {
            var priceCurveDefinitions = new List<ProductDefinition>
                                        {
                                            new ProductDefinitionTestObjectBuilder().Build()
                                        };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<ProductDefinition> result = null;

            using (curveControlService.ProductDefinitions.Subscribe(values => result = values))
            {
                // ACT
                curveControlService.OnProductDefinitionsNotifications(priceCurveDefinitions);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishCurrencyCodes_OnCurrencyCodesSnapshot()
        {
            var currencyCodes = new List<CurrencyCode> { new(1, "USD") };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<CurrencyCode> result = null;

            using (curveControlService.CurrencyCodes.Subscribe(values => result = values))
            {
                // ACT
                curveControlService.OnCurrencyCodesSnapshot(currencyCodes);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishCurrencyCodes_OnCurrencyCodesNotification()
        {
            var currencyCodes = new List<CurrencyCode> { new(1, "USD") };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<CurrencyCode> result = null;

            using (curveControlService.CurrencyCodes.Subscribe(values => result = values))
            {
                // ACT
                curveControlService.OnCurrencyCodesNotifications(currencyCodes);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishCurveGroups_OnCurveGroupsSnapshot()
        {
            var curveGroups = new List<CurveGroup>
                              {
                                  new CurveGroupTestObjectBuilder().Build()
                              };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<CurveGroup> result = null;

            using (curveControlService.CurveGroups.Subscribe(values => result = values))
            {
                // ACT
                curveControlService.OnCurveGroupsSnapshot(curveGroups);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishCurveGroups_OnCurveGroupsNotifications()
        {
            var curveGroups = new List<CurveGroup>
                              {
                                  new CurveGroupTestObjectBuilder().Build()
                              };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<CurveGroup> result = null;

            using (curveControlService.CurveGroups.Subscribe(values => result = values))
            {
                // ACT
                curveControlService.OnCurveGroupsNotifications(curveGroups);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

		[Test]
        public void ShouldPublishPriceCurveDefinitions_OnPriceCurveDefinitionsSnapshot()
        {
            var priceCurveDefinitions = new List<PriceCurveDefinition>
                                        {
                                            new PriceCurveDefinitionTestObjectBuilder().Build()
                                        };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<PriceCurveDefinition> result = null;

            using (curveControlService.PriceCurveDefinitions.Subscribe(values => result = values))
            {
                // ACT
                curveControlService.OnPriceCurveDefinitionsSnapshot(priceCurveDefinitions);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishPriceCurveDefinitions_OnPriceCurveDefinitionsNotification()
        {
            var priceCurveDefinitions = new List<PriceCurveDefinition>
                                        {
                                            new PriceCurveDefinitionTestObjectBuilder().Build()
                                        };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<PriceCurveDefinition> result = null;

            using (curveControlService.PriceCurveDefinitions.Subscribe(settings => result = settings))
            {
                // ACT
                curveControlService.OnPriceCurveDefinitionsNotification(priceCurveDefinitions);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishDerivedCurveDefinitions_OnDerivedCurveDefinitionsSnapshot()
        {
            var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                              .Build();

            var derivedCurves = new List<DerivedCurveDefinition>
                                {
                                    new(new DerivedCurveDefinition<MonthlyTenor>(manualCurve))
                                };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<ManualCurveDefinition<MonthlyTenor>> result = null;

            using (curveControlService.ManualCurveDefinitions.Subscribe(r => result = r))
            {
                // ACT
                curveControlService.OnDerivedCurveDefinitionsSnapshot(derivedCurves);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishDerivedCurveDefinitions_OnDerivedCurveDefinitionsNotification()
        {
            var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                              .Build();

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(manualCurve))
            };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            IList<ManualCurveDefinition<MonthlyTenor>> result = null;

            using (curveControlService.ManualCurveDefinitions.Subscribe(r => result = r))
            {
                // ACT
                curveControlService.OnDerivedCurveDefinitionsNotification(derivedCurves);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishManualOverrides_OnDerivedCurveDefinitionsSnapshot()
        {
            var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                              .Build();

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(manualCurve))
            };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            List<ManualCurveDefinition<MonthlyTenor>> result = null;

            using (curveControlService.ManualOverrides.Subscribe(r => result = r))
            {
                // ACT
                curveControlService.OnDerivedCurveDefinitionsSnapshot(derivedCurves);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishManualOverrides_OnDerivedCurveDefinitionsNotification_AfterSnapshot()
        {
            var curve1 = new DerivedCurveDefinition(new DerivedCurveDefinition<MonthlyTenor>(
                                                           new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                                                           .Build()));

            var curve2 = new DerivedCurveDefinition(new DerivedCurveDefinition<MonthlyTenor>(
                                                           new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(102)
                                                                                                           .Build()));
            var snapshot = new List<DerivedCurveDefinition>{curve1, curve2};

            var overrides = new List<CurvePoint<MonthlyTenor>> {new(new MonthlyTenor(2019, 1), 1.0)};

            var curve2Update = new DerivedCurveDefinition(new DerivedCurveDefinition<MonthlyTenor>(
                                                                 new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(102)
                                                                                                                 .WithOverrides(overrides)
                                                                                                                 .Build()));

            var notification = new List<DerivedCurveDefinition> { curve2Update };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            List<ManualCurveDefinition<MonthlyTenor>> results = null;

            using (curveControlService.ManualOverrides.Subscribe(r => results = r))
            {
                curveControlService.OnDerivedCurveDefinitionsSnapshot(snapshot);

                // ACT
                curveControlService.OnDerivedCurveDefinitionsNotification(notification);

                // ASSERT
                Assert.That(results.Count, Is.EqualTo(2));

                Assert.That(results[0].Id, Is.EqualTo(101));
                Assert.That(results[1].Id, Is.EqualTo(102));
                Assert.That(results[1].Overrides.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishSystemDate_OnSystemDateSnapshot()
        {
            var systemDate = new SystemDate(new List<BusinessDay>(), DateTime.MinValue);

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            SystemDate result = null;

            using (curveControlService.SystemDate.Subscribe(r => result = r))
            {
                // ACT
                curveControlService.OnSystemDateSnapshot(systemDate);

                // ASSERT
                Assert.That(result, Is.SameAs(systemDate));
            }
        }

        [Test]
        public void ShouldPublishSystemDate_OnSystemDateNotification()
        {
            var systemDate = new SystemDate(new List<BusinessDay>(), DateTime.MinValue);

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            SystemDate result = null;

            using (curveControlService.SystemDate.Subscribe(r => result = r))
            {
                // ACT
                curveControlService.OnSystemDateNotification(systemDate);

                // ASSERT
                Assert.That(result, Is.SameAs(systemDate));
            }
        }

        [Test]
        public void ShouldPublishUsers_OnUserSnapshot()
        {
            var users = new List<User>
            {
               new UserBuilder().WithId(10).User()
            };

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            List<User> result = null;

            using (curveControlService.Users.Subscribe(r => result = r))
            {
                // ACT
                curveControlService.OnUsersSnapshot(users);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test] 
        public void ShouldPublishAllUsers_OnUserNotification()
        {
            var user1 = new UserBuilder().WithId(10).User();
            var user2 = new UserBuilder().WithId(11).User();

            var snapshot = new List<User>{user1, user2};
            var notification = new List<User> {user1};

            var testObjects = new CurveControlServiceTestObjectBuilder().Build();

            var curveControlService = testObjects.CurveControlService;

            List<User> result = null;

            using (curveControlService.Users.Subscribe(r => result = r))
            {
                curveControlService.OnUsersSnapshot(snapshot);

                // ACT
                curveControlService.OnUsersNotification(notification);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldClearManualCurveDefinitions_And_ResubscribeToPriceCurveDefinitions_OnCurrentUserNotification()
        {
            var priceCurveDefinitions = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().Build()
            };

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                                                             .Build()))
            };

            var currentUser = new UserBuilder().WithId(10).User();

            var testObjects = new CurveControlServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                        .Build();

            var curveControlService = testObjects.CurveControlService;

            IList<PriceCurveDefinition> curveDefinitionsUpdate = null;
            IList<ManualCurveDefinition<MonthlyTenor>> manualDefinitionsUpdate = null;

            User currentUserUpdate = null;

            curveControlService.PriceCurveDefinitions.Subscribe(curves => curveDefinitionsUpdate = curves);
            curveControlService.ManualCurveDefinitions.Subscribe(curves => manualDefinitionsUpdate = curves);

            curveControlService.CurrentUser
                               .Subscribe(user => currentUserUpdate = user);

            curveControlService.OnPriceCurveDefinitionsSnapshot(priceCurveDefinitions);
            curveControlService.OnDerivedCurveDefinitionsSnapshot(derivedCurves);

  
            Mock.Get(testObjects.AdminApiHubConnection).Reset();

            var usersNotification = new List<User> { currentUser };

            // ACT
            curveControlService.OnUsersNotification(usersNotification);

            // ASSERT
            Assert.IsNull(curveDefinitionsUpdate);
            Assert.IsNull(manualDefinitionsUpdate);
            Assert.IsNotNull(currentUserUpdate);

            Mock.Get(testObjects.AdminApiHubConnection).Verify(p => p.SubscribePriceCurveDefinitions());
            Mock.Get(testObjects.AdminApiHubConnection).Verify(p => p.SubscribeDerivedCurveDefinitions());
        }

        [Test]
        public void ShouldNotClearManualCurveDefinitions_And_ResubscribeToPriceCurveDefinitions_OnOtherUserNotification()
        {
            var priceCurveDefinitions = new List<PriceCurveDefinition>
            {
                new PriceCurveDefinitionTestObjectBuilder().Build()
            };

            var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(
                                                             new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                                                             .Build()))
            };

            var currentUser = new UserBuilder().WithId(10).User();
            var otherUser = new UserBuilder().WithId(11).User();

            var testObjects = new CurveControlServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                        .Build();

            var curveControlService = testObjects.CurveControlService;

            IList<PriceCurveDefinition> curveDefinitionsUpdate = null;
            IList<ManualCurveDefinition<MonthlyTenor>> manualDefinitionsUpdate = null;

            curveControlService.PriceCurveDefinitions.Subscribe(curves => curveDefinitionsUpdate = curves);
            curveControlService.ManualCurveDefinitions.Subscribe(curves => manualDefinitionsUpdate = curves);

            curveControlService.OnPriceCurveDefinitionsSnapshot(priceCurveDefinitions);
            curveControlService.OnDerivedCurveDefinitionsSnapshot(derivedCurves);
         
            Mock.Get(testObjects.AdminApiHubConnection).Reset();

            var usersNotification = new List<User> { otherUser };

            // ACT
            curveControlService.OnUsersNotification(usersNotification);

            // ASSERT
            Assert.IsNotNull(curveDefinitionsUpdate);
            Assert.IsNotNull(manualDefinitionsUpdate);

            Mock.Get(testObjects.AdminApiHubConnection).Verify(p => p.SubscribePriceCurveDefinitions(), Times.Never);
            Mock.Get(testObjects.AdminApiHubConnection).Verify(p => p.SubscribeDerivedCurveDefinitions(), Times.Never);
        }
    }
}
