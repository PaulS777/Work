﻿using System;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    [TestFixture]
    public class MutexInstanceTests
    {
        [Test]
        public void ShouldPublishStatusTrue_WhenOnlyInstance()
        {
            var configProvider = new Mock<IConfigProvider>();
            var guiConfiguration = new Mock<ICommonConfiguration>();
            var runService = new Mock<IDspApplicationRunService>();

            guiConfiguration.SetupGet(c => c.EnvironmentName).Returns("TEST");
            configProvider.SetupGet(c => c.Configuration).Returns(guiConfiguration.Object);
            runService.SetupGet(r => r.MutexInstanceName).Returns("DSP");

            var result = new bool?();

            using (var instance = new MutexInstance(configProvider.Object, runService.Object, Mocks.GetLoggerFactory().Object)) 
            {
                instance.Status.Subscribe(s => result = s);

                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishStatusFalse_WhenOtherInstanceExists()
        {
            var configProvider = new Mock<IConfigProvider>();
            var guiConfiguration = new Mock<ICommonConfiguration>();
            var runService = new Mock<IDspApplicationRunService>();

            guiConfiguration.SetupGet(c => c.EnvironmentName).Returns("TEST");
            configProvider.SetupGet(c => c.Configuration).Returns(guiConfiguration.Object);
            runService.SetupGet(r => r.MutexInstanceName).Returns("DSP");

            var result = new bool?();

            using var _ = new MutexInstance(configProvider.Object, runService.Object, Mocks.GetLoggerFactory().Object);

            using (var instance2 = new MutexInstance(configProvider.Object, runService.Object, Mocks.GetLoggerFactory().Object))
            {
                instance2.Status.Subscribe(s => result = s);
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldDisposeMutexWhenDisposed()
        {
            var configProvider = new Mock<IConfigProvider>();
            var guiConfiguration = new Mock<ICommonConfiguration>();
            var runService = new Mock<IDspApplicationRunService>();

            guiConfiguration.SetupGet(c => c.EnvironmentName).Returns("TEST");
            configProvider.SetupGet(c => c.Configuration).Returns(guiConfiguration.Object);
            runService.SetupGet(r => r.MutexInstanceName).Returns("DSP");

            var result = new bool?();

            using (var _ = new MutexInstance(configProvider.Object, runService.Object, Mocks.GetLoggerFactory().Object))
            {      
            }

            using (var instance2 = new MutexInstance(configProvider.Object, runService.Object, Mocks.GetLoggerFactory().Object))
            {
                instance2.Status.Subscribe(s => result = s);

                Assert.That(result, Is.True);
            }
        }
    }
}
