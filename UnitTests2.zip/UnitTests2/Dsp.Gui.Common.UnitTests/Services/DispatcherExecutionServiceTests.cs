﻿using System;
using Dsp.Gui.Common.Services;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    [TestFixture]
    public class DispatcherExecutionServiceTests
    {
        [Test]
        public void ShouldProcessUpdatesAfterTickInterval()
        {
            var testScheduler = new TestScheduler();
            var schedulerProvider = new Mock<ISchedulerProvider>();
            schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
            schedulerProvider.SetupGet(p => p.Dispatcher).Returns(testScheduler);

            var tickInterval = TimeSpan.FromMilliseconds(1100).Ticks;

            var result = 0;

            var dispatcherExecutionService = new DispatcherExecutionService(schedulerProvider.Object,
                                                                            Mocks.GetLoggerFactory().Object)
                                             {
                                                 PerformanceLogger = Mock.Of<IPerformanceLogger>()
                                             };

            dispatcherExecutionService.Start();

            dispatcherExecutionService.Schedule(() => result++);

            // ACT
            testScheduler.AdvanceBy(tickInterval);

            // ASSERT
            Assert.That(result, Is.EqualTo(1));
        }

        [Test]
        public void ShouldNotProcessUpdatesBeforeTickInterval()
        {
            var testScheduler = new TestScheduler();
            var schedulerProvider = new Mock<ISchedulerProvider>();
            schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
            schedulerProvider.SetupGet(p => p.Dispatcher).Returns(testScheduler);

            var tickInterval1 = TimeSpan.FromMilliseconds(1100).Ticks;
            var tickInterval2 = TimeSpan.FromMilliseconds(100).Ticks;
            var result = 0;

            var dispatcherExecutionService = new DispatcherExecutionService(schedulerProvider.Object,
                                                                            Mocks.GetLoggerFactory().Object)
                                             {
                                                 PerformanceLogger = Mock.Of<IPerformanceLogger>()
                                             };

            dispatcherExecutionService.Start();

            dispatcherExecutionService.Schedule(() => result++);
            testScheduler.AdvanceBy(tickInterval1);

            dispatcherExecutionService.Schedule(() => result++);
            testScheduler.AdvanceBy(tickInterval2);

            // ASSERT
            Assert.That(result, Is.EqualTo(1));
        }

        [Test]
        public void ShouldProcessScheduledRepeatActionsAfterTickInterval()
        {
            var testScheduler = new TestScheduler();
            var schedulerProvider = new Mock<ISchedulerProvider>();
            schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
            schedulerProvider.SetupGet(p => p.Dispatcher).Returns(testScheduler);

            var tickInterval = TimeSpan.FromMilliseconds(1100).Ticks;

            var result = 0;

            var dispatcherExecutionService = new DispatcherExecutionService(schedulerProvider.Object,
                                                                            Mocks.GetLoggerFactory().Object)
                                             {
                                                 PerformanceLogger = Mock.Of<IPerformanceLogger>()
                                             };

            dispatcherExecutionService.Start();

            dispatcherExecutionService.ScheduleRepeat(() => result++);

            // ACT
            testScheduler.AdvanceBy(tickInterval);

            // ASSERT
            Assert.That(result, Is.EqualTo(1));
        }

        [Test]
        public void ShouldNotProcessUpdatesAfterTickInterval_WhenStopped()
        {
            var testScheduler = new TestScheduler();
            var schedulerProvider = new Mock<ISchedulerProvider>();
            schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
            schedulerProvider.SetupGet(p => p.Dispatcher).Returns(testScheduler);

            var tickInterval = TimeSpan.FromMilliseconds(1100).Ticks;

            var result = 0;

            var dispatcherExecutionService = new DispatcherExecutionService(schedulerProvider.Object,
                                                                            Mocks.GetLoggerFactory().Object)
                                             {
                                                 PerformanceLogger = Mock.Of<IPerformanceLogger>()
                                             };

            dispatcherExecutionService.Start();

            dispatcherExecutionService.Schedule(() => result++);

            // ACT
            dispatcherExecutionService.Stop();
            testScheduler.AdvanceBy(tickInterval);

            // ASSERT
            Assert.That(result, Is.EqualTo(0));
        }

        [Test]
        public void ShouldClearUpdatesWhenRestartAfterStopped()
        {
            var testScheduler = new TestScheduler();
            var schedulerProvider = new Mock<ISchedulerProvider>();
            schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
            schedulerProvider.SetupGet(p => p.Dispatcher).Returns(testScheduler);

            var tickInterval = TimeSpan.FromMilliseconds(1100).Ticks;

            var result = 0;

            var dispatcherExecutionService = new DispatcherExecutionService(
                                                                            schedulerProvider.Object,
                                                                            Mocks.GetLoggerFactory().Object)
                                             {
                                                 PerformanceLogger = Mock.Of<IPerformanceLogger>()
                                             };

            dispatcherExecutionService.Start();

            dispatcherExecutionService.Schedule(() => result++);

            dispatcherExecutionService.Stop();

            // ACT
            dispatcherExecutionService.Start();
            testScheduler.AdvanceBy(tickInterval);

            // ASSERT
            Assert.That(result, Is.EqualTo(0));
        }

        [Test]
        public void ShouldNotProcessUpdatesAfterTickInterval_WhenDisposed()
        {

            var testScheduler = new TestScheduler();
            var schedulerProvider = new Mock<ISchedulerProvider>();
            schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
            schedulerProvider.SetupGet(p => p.Dispatcher).Returns(testScheduler);

            var tickInterval = TimeSpan.FromMilliseconds(1100).Ticks;

            var result = 0;

            var dispatcherExecutionService = new DispatcherExecutionService(schedulerProvider.Object,
                                                                            Mocks.GetLoggerFactory().Object)
                                             {
                                                 PerformanceLogger = Mock.Of<IPerformanceLogger>()
                                             };

            dispatcherExecutionService.Start();

            dispatcherExecutionService.Schedule(() => result++);

            // ACT
            dispatcherExecutionService.Dispose();
            testScheduler.AdvanceBy(tickInterval);

            // ASSERT
            Assert.That(result, Is.EqualTo(0));
        }
    }
}
