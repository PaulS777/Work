﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using NUnit.Framework;
using Dsp.Gui.TestObjects;

namespace Dsp.Gui.Common.UnitTests.Services
{
    [TestFixture]
    public class PriceCurveSubscriptionManagerTests
    {
        private static PriceCurve GetPriceCurve(int id) =>
            new PriceCurve(id,
                "product",
                99,
                "publisher",
                DateTime.MinValue,
                true,
                ValidityIndicator.Valid,
                new TenorPrices<DailyTenor>(),
                new TenorPrices<WeeklyTenor>(),
                new TenorPrices<MonthlyTenor>(),
                new TenorPrices<QuarterlyTenor>(),
                new TenorPrices<HalfYearTenor>(),
                new TenorPrices<AnnualTenor>());

        [Test]
        public void ShouldAddNewPriceCurveSubscription()
        {
            var curveIds = new[] { 101 };

            var priceCurveSubscriptionManager = new PriceCurveSubscriptionManager(TestMocks.GetLoggerFactory().Object);

            // ACT
            var result = priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            // ASSERT
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(101, result[0]);
        }

        [Test]
        public void ShouldAddRefCount_WhenPriceCurveSubscription_WithExisting()
        {
            var curveIds = new[] { 101 };

            var priceCurveSubscriptionManager = new PriceCurveSubscriptionManager(TestMocks.GetLoggerFactory().Object);

            // ACT
            priceCurveSubscriptionManager.AddPriceCurves(curveIds);
            var result = priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            // ASSERT
            Assert.AreEqual(0, result.Count);

        }

        [Test]
        public void ShouldRemoveSubscription_WhenLastCurveRemoved()
        {
            var curveIds = new[] { 101 };

            var priceCurveSubscriptionManager = new PriceCurveSubscriptionManager(TestMocks.GetLoggerFactory().Object);

            priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            // ACT
            var result = priceCurveSubscriptionManager.RemovePriceCurves(curveIds);

            // ASSERT
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(101, result[0]);
        }

        [Test]
        public void ShouldNotRemoveCurve_WhenCurveRemoved_WithExisting()
        {
            var curveIds = new[] { 101 };

            var priceCurveSubscriptionManager = new PriceCurveSubscriptionManager(TestMocks.GetLoggerFactory().Object);

            // ACT
            priceCurveSubscriptionManager.AddPriceCurves(curveIds);
            priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            // ACT
            var result = priceCurveSubscriptionManager.RemovePriceCurves(curveIds);

            // ASSERT
            Assert.AreEqual(0, result.Count);
        }

        [Test]
        public void ShouldGetPriceCurveSubscriptionWhenAdded()
        {
            var curveIds = new[] { 101 };

            var priceCurveSubscriptionManager = new PriceCurveSubscriptionManager(TestMocks.GetLoggerFactory().Object);

            priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            // TEST
            var curve = priceCurveSubscriptionManager.GetPriceCurve(101);

            // ACT
            Assert.IsNotNull(curve);
        }

        [Test]
        public void ShouldUpdatePriceCurve()
        {
            var curveIds = new[] { 101 };

            var priceCurveSubscriptionManager = new PriceCurveSubscriptionManager(TestMocks.GetLoggerFactory().Object);

            priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            var curve = priceCurveSubscriptionManager.GetPriceCurve(101);

            var update = GetPriceCurve(101);

            var priceCurves = new List<PriceCurve> {update};

            PriceCurve result = null;

            using (curve.Subscribe(c => result = c))
            {
                // ACT
                priceCurveSubscriptionManager.UpdatePriceCurves(priceCurves);

                // ASSERT
               Assert.IsNotNull(result);
            }
        }

        [Test]
        public void ShouldNotUpdatePriceCurveWhenRemoved()
        {
            var curveIds = new[] { 101 };

            var priceCurveSubscriptionManager = new PriceCurveSubscriptionManager(TestMocks.GetLoggerFactory().Object);

            priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            var curve = priceCurveSubscriptionManager.GetPriceCurve(101);

            var update = GetPriceCurve(101);

            var priceCurves = new List<PriceCurve> { update };

            PriceCurve result = null;

            using (curve.Subscribe(c => result = c))
            {
                priceCurveSubscriptionManager.RemovePriceCurves(curveIds);

                // ACT
                priceCurveSubscriptionManager.UpdatePriceCurves(priceCurves);

                // ASSERT
                Assert.IsNull(result);
            }
        }
    }
}
