﻿using System;
using Dsp.DataContracts.WebApi;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services.Connection
{
    public interface IHubConnectionClientTestObjects
    {
        IHubClientRetryPolicy RetryPolicy { get; }
        IHubConnectionStartupStateHandler StartupStateHandler { get; }
        IHubConnectionRunStateHandler RunStateHandler { get; }
        IHubConnectionUserHandler UserHandler { get; }
        IHubConnectionService HubConnectionService { get; }
        IHubConnectionProxy HubConnectionProxy { get; }
        ILogger Logger { get; }
        HubConnectionClient HubConnectionClient { get; }
    }

    [TestFixture]
    public class HubConnectionClientTests
    {
        private class HubConnectionClientTestObjectBuilder
        {
            public IHubConnectionClientTestObjects Build()
            {
                var testObjects = new Mock<IHubConnectionClientTestObjects>();

                var startupStateHandler = new Mock<IHubConnectionStartupStateHandler>();

                testObjects.SetupGet(o => o.StartupStateHandler)
                           .Returns(startupStateHandler.Object);

                var runStateHandler = new Mock<IHubConnectionRunStateHandler>();

                testObjects.SetupGet(o => o.RunStateHandler)
                           .Returns(runStateHandler.Object);

                var userHandler = new Mock<IHubConnectionUserHandler>();

                testObjects.SetupGet(o => o.UserHandler)
                           .Returns(userHandler.Object);

                var hubConnectionProxy = new Mock<IHubConnectionProxy>();

                testObjects.SetupGet(o => o.HubConnectionProxy)
                           .Returns(hubConnectionProxy.Object);

                var hubConnectionService = new Mock<IHubConnectionService>();

                hubConnectionService.Setup(h => h.Initialize(It.IsAny<IAuthenticatedServiceClient>(),
                                                             It.IsAny<IHubConnectionClient>(),
                                                             It.IsAny<Uri>()))
                                    .Returns(hubConnectionProxy.Object);

                testObjects.SetupGet(o => o.HubConnectionService)
                           .Returns(hubConnectionService.Object);

                var retryPolicy = new Mock<IHubClientRetryPolicy>();

                testObjects.SetupGet(o => o.RetryPolicy)
                           .Returns(retryPolicy.Object);

                var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

                var hubConnectionClient = new HubConnectionClient(retryPolicy.Object,
                                                                  TestMocks.GetLoggerFactory(logger).Object);

                testObjects.SetupGet(o => o.HubConnectionClient)
                           .Returns(hubConnectionClient);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeService_And_RetryPolicy()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            // ACT
            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ASSERT
            Assert.That(testObjects.HubConnectionClient.Service, Is.EqualTo("service"));

            Mock.Get(testObjects.RetryPolicy)
                .Verify(r => r.Initialize(testObjects.HubConnectionClient, "service"));
        }

        [Test]
        public void ShouldInvokeStartupStateConnected_And_RunStateConnected_OnFirst_ApiConnectionStatus_Success()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnApiConnectionStatus(ApiConnectionStatus.Success);

            // ASSERT
            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnConnected());

            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnConnected());
        }

        [Test]
        public void ShouldInvokeRunStateReconnected_OnNext_ApiConnectionStatus_Success()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            testObjects.HubConnectionClient.OnApiConnectionStatus(ApiConnectionStatus.Success);

            Mock.Get(testObjects.StartupStateHandler).Invocations.Clear();

            // ACT
            testObjects.HubConnectionClient.OnApiConnectionStatus(ApiConnectionStatus.Success);

            // ASSERT
            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnReconnected());

            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnConnected(), Times.Never);
        }

        [TestCase(ApiConnectionStatus.AuthenticationFailure, FatalHubConnectionError.ApiAuthenticationFailed)]
        [TestCase(ApiConnectionStatus.ObsoleteClientFailure, FatalHubConnectionError.ObsoleteClient)]
        public void ShouldInvokeStartupStateFatalError_And_RunStateStartupFailed_OnApiConnectionStatus_Failure(ApiConnectionStatus status,
                                                                                                               FatalHubConnectionError expected)
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnApiConnectionStatus(status);

            // ASSERT
            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnFatalError(expected, null));

            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnStartupFailed());
        }

        [Test]
        public void ShouldInvokeRunStateConnectionsExceeded_OnApiConnectionStatus_ConnectionsExceededFailure()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnApiConnectionStatus(ApiConnectionStatus.ConnectionsExceededFailure);

            // ASSERT
            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnConnectionsExceeded());
        }

        [Test]
        public void ShouldInvokeUserHandler_OnUser()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            var user = new UserBuilder().User();

            // ACT
            testObjects.HubConnectionClient.OnUser(user);

            // ASSERT
            Mock.Get(testObjects.UserHandler)
                .Verify(h => h.OnCurrentUser(user));
        }

        [Test]
        public void ShouldInvokeStartupStateConnecting_OnConnecting()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnConnecting();

            // ASSERT
            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnConnecting());
        }

        [Test]
        public void ShouldInvokeStartupStateHttpFailed_And_RunStateHttpFailed_OnHttpServiceUnavailable()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnHttpServiceUnavailable();

            // ASSERT
            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnHttpFailed());

            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnHttpFailed());
        }

        [Test]
        public void ShouldInvokeStartupFatalErrorAuthorizationFailed_And_RunStartupFailed_OnHttpUnauthorized()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnHttpUnauthorized();

            // ASSERT
            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnFatalError(FatalHubConnectionError.AuthorizationFailed, null));

            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnStartupFailed());
        }

        [Test]
        public void ShouldInvokeStartupFatalErrorUnexpected_And_RunStartupFailed_OnHttpUnexpectedError()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnHttpUnexpectedError("failed");

            // ASSERT
            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnFatalError(FatalHubConnectionError.UnexpectedError, "failed"));
        }

        [Test]
        public void ShouldInvokeRunStateConnecting_OnRetryConnection()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnRetryConnection();

            // ASSERT
            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnReconnecting());
        }

        [Test]
        public void ShouldInvokeRunStateReconnecting_OnReconnecting()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnReconnecting(new Exception());

            // ASSERT
            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnReconnecting());
        }

        [Test]
        public void ShouldInvokeRunStateClosed_OnClosed()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnClosed(new Exception());

            // ASSERT
            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnClosed());
        }

        [Test]
        public void ShouldInvokeStartupStateFatalError_And_RunStateStartupFailed_OnSsoAuthenticationError()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnSsoAuthenticationError();

            // ASSERT
            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnFatalError(FatalHubConnectionError.SsoAuthenticationFailed, null));

            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnStartupFailed());
        }

        [Test]
        public void ShouldInvokeStartupStateFatalError_And_RunStateStartupFailed_OnHubInitializeFailed()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnHubInitializeFailed();

            // ASSERT
            Mock.Get(testObjects.StartupStateHandler)
                .Verify(h => h.OnFatalError(FatalHubConnectionError.HubInitializeFailed, null));

            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnStartupFailed());
        }


        [Test]
        public void ShouldInvokeRunStateConnecting_OnRestart()
        {
            var testObjects = new HubConnectionClientTestObjectBuilder().Build();

            testObjects.HubConnectionClient.Initialize("service",
                                                       testObjects.StartupStateHandler,
                                                       testObjects.RunStateHandler,
                                                       testObjects.UserHandler);

            // ACT
            testObjects.HubConnectionClient.OnRestart();

            // ASSERT
            Mock.Get(testObjects.RunStateHandler)
                .Verify(h => h.OnReconnecting());
        }
    }
}
