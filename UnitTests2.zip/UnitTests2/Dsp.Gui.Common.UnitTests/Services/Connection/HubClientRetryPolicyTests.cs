﻿using System;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.TestObjects;
using Microsoft.AspNetCore.SignalR.Client;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services.Connection
{
    public interface IHubClientRetryPolicyTestObjects
    {
        IHubConnectionClient HubConnectionClient { get; }
        HubClientRetryPolicy HubClientRetryPolicy { get; }
    }

    [TestFixture]
    public class HubClientRetryPolicyTests
    {
        private class HubClientRetryPolicyTestObjectBuilder
        {
            public IHubClientRetryPolicyTestObjects Build()
            {
                var testObjects = new Mock<IHubClientRetryPolicyTestObjects>();

                var hubConnectionClient = new Mock<IHubConnectionClient>();

                testObjects.SetupGet(o => o.HubConnectionClient)
                           .Returns(hubConnectionClient.Object);

                var hubClientRetryPolicy = new HubClientRetryPolicy(TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.HubClientRetryPolicy)
                           .Returns(hubClientRetryPolicy);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInvokeOnRetryConnection_When_NextRetryDelay_With_PreviousRetryCount_Equals_Zero()
        {
            var testObjects = new HubClientRetryPolicyTestObjectBuilder().Build();

            testObjects.HubClientRetryPolicy.Initialize(testObjects.HubConnectionClient, "service");

            // ACT
            testObjects.HubClientRetryPolicy.NextRetryDelay(new RetryContext { PreviousRetryCount = 0 });

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(c => c.OnRetryConnection());
        }

        [Test]
        public void ShouldNotInvokeOnRetryConnection_When_NextRetryDelay_With_PreviousRetryCount_NotEquals_Zero()
        {
            var testObjects = new HubClientRetryPolicyTestObjectBuilder().Build();

            testObjects.HubClientRetryPolicy.Initialize(testObjects.HubConnectionClient, "service");

            // ACT
            testObjects.HubClientRetryPolicy.NextRetryDelay(new RetryContext { PreviousRetryCount = 1 });

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(c => c.OnRetryConnection(), Times.Never);
        }

        [Test]
        public void ShouldReturnShortIntervalRetryTimespan_When_Retry_With_PreviousRetryCount_LessThanOrEqualTo_ShortIntervalRetryCount()
        {
            var testObjects = new HubClientRetryPolicyTestObjectBuilder().Build();

            testObjects.HubClientRetryPolicy.Initialize(testObjects.HubConnectionClient, "service");

            var retryCount = HubClientRetryPolicy.ShortIntervalRetryCount;

            var expected = new TimeSpan(0, 0, HubClientRetryPolicy.ShortIntervalRetryTimeSpanSeconds);

            for (var count = 0; count <= retryCount; count++)
            {
                var retryContext = new RetryContext { PreviousRetryCount = count++ };

                // ACT
                var result = testObjects.HubClientRetryPolicy.NextRetryDelay(retryContext);

                // ASSERT
                Assert.That(result, Is.EqualTo(expected));
            }
        }

        [Test]
        public void ShouldReturnLongIntervalRetryTimespan_When_Retry_With_PreviousRetryCount_Between_ShortIntervalRetryCount_And_LongIntervalRetryCount()
        {
            var testObjects = new HubClientRetryPolicyTestObjectBuilder().Build();

            testObjects.HubClientRetryPolicy.Initialize(testObjects.HubConnectionClient, "service");

            var retryCount1 = HubClientRetryPolicy.ShortIntervalRetryCount + 1;
            var retryCount2 = HubClientRetryPolicy.LongIntervalRetryCount;

            var expected = new TimeSpan(0, 0, HubClientRetryPolicy.LongIntervalRetryTimeSpanSeconds);

            for (var count = retryCount1; count <= retryCount2; count++)
            {
                var retryContext = new RetryContext { PreviousRetryCount = count++ };

                // ACT
                var result = testObjects.HubClientRetryPolicy.NextRetryDelay(retryContext);

                // ASSERT
                Assert.That(result, Is.EqualTo(expected));
            }
        }

        [Test]
        public void ShouldReturnNull_When_Retry_With_PreviousRetryCount_GreaterThan_LongIntervalRetryCount()
        {
            var testObjects = new HubClientRetryPolicyTestObjectBuilder().Build();

            testObjects.HubClientRetryPolicy.Initialize(testObjects.HubConnectionClient, "service");

            var retryCount = HubClientRetryPolicy.LongIntervalRetryCount + 1;

            var retryContext = new RetryContext { PreviousRetryCount = retryCount};

                // ACT
            var result = testObjects.HubClientRetryPolicy.NextRetryDelay(retryContext);

                // ASSERT
            Assert.That(result, Is.Null);
        }
    }
}
