﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services.Connection.Publication
{
    [TestFixture]
    public class HubConnectionUserServiceTests
    {
        [Test]
        public void ShouldPublishCurrentUser_OnCurrentUser()
        {
            var user = new UserBuilder().User();

            var service = new HubConnectionUserService();

            User result = null;

            using (service.CurrentUser.Subscribe(value => result = value))
            {
                // ACT
                service.OnCurrentUser(user);

                // ASSERT
                Assert.That(result, Is.SameAs(user));
            }
        }

        [Test]
        public void ShouldThrowObjectDisposedException_When_OnCurrentUser_With_Disposed()
        {
            var user = new UserBuilder().User();

            var service = new HubConnectionUserService();

            Exception result = null;

            service.Dispose();

            try
            {
                // ACT
                service.OnCurrentUser(user);
            }
            catch (Exception ex)
            {
                result = ex;
            }

            Assert.That(result, Is.TypeOf<ObjectDisposedException>());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var user = new UserBuilder().User();

            var service = new HubConnectionUserService();

            Exception result = null;

            service.Dispose();

            try
            {
                // ACT
                service.Dispose();
                service.OnCurrentUser(user);
            }
            catch (Exception ex)
            {
                result = ex;
            }

            Assert.That(result, Is.TypeOf<ObjectDisposedException>());
        }
    }
}
