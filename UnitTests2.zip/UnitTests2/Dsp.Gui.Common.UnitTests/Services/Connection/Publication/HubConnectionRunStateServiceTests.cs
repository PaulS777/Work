﻿using System;
using Dsp.Gui.Common.Services.Connection.Publication;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services.Connection.Publication
{
    [TestFixture]
    public class HubConnectionRunStateServiceTests
    {
        [Test]
        public void ShouldPublishFailedStartup_OnStartupFailed()
        {
            var service = new HubConnectionRunStateService();

            var result = HubConnectionRunState.NotSet;

            using (service.RunState.Subscribe(value => result = value))
            {
                // ACT
                service.OnStartupFailed();

                // ASSERT
                Assert.That(result, Is.EqualTo(HubConnectionRunState.FailedStartup));
            }
        }

        [Test]
        public void ShouldPublishConnected_OnConnected()
        {
            var service = new HubConnectionRunStateService();

            var result = HubConnectionRunState.NotSet;

            using (service.RunState.Subscribe(value => result = value))
            {
                // ACT
                service.OnConnected();

                // ASSERT
                Assert.That(result, Is.EqualTo(HubConnectionRunState.Connected));
            }
        }

        [Test]
        public void ShouldPublishReconnecting_OnReconnecting()
        {
            var service = new HubConnectionRunStateService();

            var result = HubConnectionRunState.NotSet;

            using (service.RunState.Subscribe(value => result = value))
            {
                // ACT
                service.OnReconnecting();

                // ASSERT
                Assert.That(result, Is.EqualTo(HubConnectionRunState.Reconnecting));
            }
        }

        [Test]
        public void ShouldPublishHttpFailed_OnHttpFailed()
        {
            var service = new HubConnectionRunStateService();

            var result = HubConnectionRunState.NotSet;

            using (service.RunState.Subscribe(value => result = value))
            {
                // ACT
                service.OnHttpFailed();

                // ASSERT
                Assert.That(result, Is.EqualTo(HubConnectionRunState.HttpFailed));
            }
        }

        [Test]
        public void ShouldPublishReconnected_OnReconnected()
        {
            var service = new HubConnectionRunStateService();

            var result = HubConnectionRunState.NotSet;

            using (service.RunState.Subscribe(value => result = value))
            {
                // ACT
                service.OnReconnected();

                // ASSERT
                Assert.That(result, Is.EqualTo(HubConnectionRunState.Reconnected));
            }
        }

        [Test]
        public void ShouldPublishClosed_OnClosed()
        {
            var service = new HubConnectionRunStateService();

            var result = HubConnectionRunState.NotSet;

            using (service.RunState.Subscribe(value => result = value))
            {
                // ACT
                service.OnClosed();

                // ASSERT
                Assert.That(result, Is.EqualTo(HubConnectionRunState.Closed));
            }
        }


        [Test]
        public void ShouldPublishConnectionsExceeded_OnConnectionsExceeded()
        {
            var service = new HubConnectionRunStateService();

            var result = HubConnectionRunState.NotSet;

            using (service.RunState.Subscribe(value => result = value))
            {
                // ACT
                service.OnConnectionsExceeded();

                // ASSERT
                Assert.That(result, Is.EqualTo(HubConnectionRunState.ConnectionsExceeded));
            }
        }

        [Test]
        public void ShouldThrowObjectDisposedException_When_OnConnected_With_Disposed()
        {
            var service = new HubConnectionRunStateService();

            Exception result = null;

            service.Dispose();

            try
            {
                // ACT
                service.OnConnected();
            }
            catch (Exception ex)
            {
                result = ex;
            }

            Assert.That(result, Is.TypeOf<ObjectDisposedException>());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var service = new HubConnectionRunStateService();

            Exception result = null;

            service.Dispose();

            try
            {
                // ACT
                service.Dispose();
                service.OnConnected();
            }
            catch (Exception ex)
            {
                result = ex;
            }

            Assert.That(result, Is.TypeOf<ObjectDisposedException>());
        }
    }
}
