﻿using System;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services.Connection.Publication
{
    [TestFixture]
    public class HubConnectionStartupStateServiceTests
    {
        [Test]
        public void ShouldPublish_HubConnectingStateConnecting_OnConnecting()
        {
            var service = new HubConnectionStartupStateService();

            HubConnectionStartupArgs result = null;

            using (service.StartupState.Subscribe(value => result = value))
            {
                // ACT
                service.OnConnecting();

                // ASSERT
                Assert.That(result.ConnectingState, Is.EqualTo(HubConnectingState.Connecting));
                Assert.That(result.IsFatalError, Is.False);
                Assert.That(result.FatalError, Is.EqualTo(FatalHubConnectionError.NotSet));
            }
        }

        [Test]
        public void ShouldPublish_HubConnectingStateConnected_OnConnected()
        {
            var service = new HubConnectionStartupStateService();

            HubConnectionStartupArgs result = null;

            using (service.StartupState.Subscribe(value => result = value))
            {
                // ACT
                service.OnConnected();

                // ASSERT
                Assert.That(result.ConnectingState, Is.EqualTo(HubConnectingState.Connected));
            }
        }

        [Test]
        public void ShouldPublish_HubConnectingStateHttpFailed_OnHttpServiceUnavailable()
        {
            var service = new HubConnectionStartupStateService();

            HubConnectionStartupArgs result = null;

            using (service.StartupState.Subscribe(value => result = value))
            {
                // ACT
                service.OnHttpFailed();

                // ASSERT
                Assert.That(result.ConnectingState, Is.EqualTo(HubConnectingState.HttpFailed));
            }
        }

        [Test]
        public void ShouldPublish_FatalHubConnectionError_OnFatalError()
        {
            var service = new HubConnectionStartupStateService();

            HubConnectionStartupArgs result = null;

            using (service.StartupState.Subscribe(value => result = value))
            {
                // ACT
                service.OnFatalError(FatalHubConnectionError.ApiAuthenticationFailed, null);

                // ASSERT
                Assert.That(result.FatalError, Is.EqualTo(FatalHubConnectionError.ApiAuthenticationFailed));
                Assert.That(result.IsFatalError, Is.True);
                Assert.That(result.ConnectingState, Is.EqualTo(HubConnectingState.NotSet));
            }
        }

        [Test]
        public void ShouldThrowObjectDisposedException_When_OnConnecting_With_Disposed()
        {
            var service = new HubConnectionStartupStateService();

            Exception result = null;

            service.Dispose();

            try
            {
                // ACT
                service.OnConnecting();
            }
            catch (Exception ex)
            {
                result = ex;
            }

            Assert.That(result, Is.TypeOf<ObjectDisposedException>());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var service = new HubConnectionStartupStateService();

            Exception result = null;

            service.Dispose();

            try
            {
                // ACT
                service.Dispose();
                service.OnConnecting();
            }
            catch (Exception ex)
            {
                result = ex;
            }

            Assert.That(result, Is.TypeOf<ObjectDisposedException>());
        }
    }
}
