﻿using System.Reactive.Subjects;
using System.Threading.Tasks;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services.Connection
{
    public interface IInitializeConnectionsServiceTestObjects
    {
        ISubject<bool?> MutexInstanceStatus { get; }
        IAdminApiConnectionService AdminApiConnectionService { get; }
        ICurvePublisherConnectionService CurvePublisherConnectionService { get; }
        IAdminApiServiceClient AdminApiServiceClient { get; }
        InitializeConnectionsService InitializeConnectionsService { get; }
    }

    [TestFixture]
    public class InitializeConnectionsServiceTests
    {
        private class InitializeConnectionsServiceTestObjectBuilder
        {
            private bool _adminApiConnected;
            private bool _adminApiConnectedNext;
            private bool _curvePublisherConnected;

            public InitializeConnectionsServiceTestObjectBuilder WithAdminApiConnected(bool value)
            {
                _adminApiConnected = value;
                return this;
            }

            public InitializeConnectionsServiceTestObjectBuilder WithAdminApiConnectedNext(bool value)
            {
                _adminApiConnectedNext = value;
                return this;
            }

            public InitializeConnectionsServiceTestObjectBuilder WithCurvePublisherConnected(bool value)
            {
                _curvePublisherConnected = value;
                return this;
            }

            public IInitializeConnectionsServiceTestObjects Build()
            {
                var testObjects = new Mock<IInitializeConnectionsServiceTestObjects>();

                var mutexInstanceStatus = new BehaviorSubject<bool?>(false);

                testObjects.SetupGet(o => o.MutexInstanceStatus)
                           .Returns(mutexInstanceStatus);

                var mutexInstance = new Mock<IMutexInstance>();

                mutexInstance.SetupGet(m => m.Status)
                             .Returns(mutexInstanceStatus);

                var httpClientProxy = new Mock<IHttpClientProxy>();

                var adminApiConnectionService = new Mock<IAdminApiConnectionService>();

                adminApiConnectionService.SetupGet(a => a.HttpClientProxy)
                                         .Returns(httpClientProxy.Object);

                adminApiConnectionService.SetupSequence(a => a.IsConnected)
                                         .Returns(_adminApiConnected)
                                         .Returns(_adminApiConnectedNext);

                testObjects.SetupGet(o => o.AdminApiConnectionService)
                           .Returns(adminApiConnectionService.Object);

                var curvePublisherConnectionService = new Mock<ICurvePublisherConnectionService>();

                curvePublisherConnectionService.SetupGet(c => c.IsConnected)
                                               .Returns(_curvePublisherConnected);

                testObjects.SetupGet(o => o.CurvePublisherConnectionService)
                           .Returns(curvePublisherConnectionService.Object);

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                testObjects.SetupGet(o => o.AdminApiServiceClient)
                           .Returns(adminApiServiceClient.Object);

                var initializeConnectionsService = new InitializeConnectionsService(mutexInstance.Object,
                                                                                    adminApiConnectionService.Object,
                                                                                    curvePublisherConnectionService.Object,
                                                                                    adminApiServiceClient.Object,
                                                                                    TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.InitializeConnectionsService)
                           .Returns(initializeConnectionsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldConnectServices_On_MutexInstanceStatusTrue()
        {
            var testObjects = new InitializeConnectionsServiceTestObjectBuilder().Build();

            testObjects.InitializeConnectionsService.InitializeConnections();
            
            // ACT
            testObjects.MutexInstanceStatus.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.AdminApiConnectionService)
                .Verify(a => a.Connect());

            Mock.Get(testObjects.CurvePublisherConnectionService)
                .Verify(c => c.Connect());
        }

        [Test]
        public void ShouldInitializeAdminApiService_On_MutexInstanceStatusTrue_With_AdminApi_IsConnected()
        {
            var testObjects = new InitializeConnectionsServiceTestObjectBuilder().WithAdminApiConnected(true)
                                                                                 .Build();

            testObjects.InitializeConnectionsService.InitializeConnections();

            // ACT
            testObjects.MutexInstanceStatus.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.AdminApiServiceClient)
                .Verify(a => a.Initialize(It.IsAny<IHttpClientProxy>()));
        }

        [Test]
        public void ShouldNotInitializeAdminApiService_On_MutexInstanceStatusTrue_With_AdminApi_IsConnectedFalse()
        {
            var testObjects = new InitializeConnectionsServiceTestObjectBuilder().WithAdminApiConnected(false)
                                                                                 .Build();

            testObjects.InitializeConnectionsService.InitializeConnections();

            // ACT
            testObjects.MutexInstanceStatus.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.AdminApiServiceClient)
                .Verify(a => a.Initialize(It.IsAny<IHttpClientProxy>()), Times.Never);
        }

        [Test]
        public void ShouldNotConnectServices_On_MutexInstanceStatusFalse()
        {
            var testObjects = new InitializeConnectionsServiceTestObjectBuilder().Build();

            testObjects.InitializeConnectionsService.InitializeConnections();

            // ACT
            testObjects.MutexInstanceStatus.OnNext(false);

            // ASSERT
            Mock.Get(testObjects.AdminApiConnectionService)
                .Verify(a => a.Connect(), Times.Never);

            Mock.Get(testObjects.CurvePublisherConnectionService)
                .Verify(c => c.Connect(), Times.Never);
        }

        [Test]
        public async Task ShouldRetryConnect_AdminApi_When_RetryConnect_With_CurvePublisherConnected()
        {
            var testObjects = new InitializeConnectionsServiceTestObjectBuilder().WithCurvePublisherConnected(true)
                                                                                 .Build();

            // ACT
            await testObjects.InitializeConnectionsService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.AdminApiConnectionService)
                .Verify(a => a.RetryConnect());

            Mock.Get(testObjects.CurvePublisherConnectionService)
                .Verify(c => c.RetryConnect(), Times.Never);
        }

        [Test]
        public async Task ShouldRetryConnect_CurvePublisher_When_RetryConnect_With_AdminApiConnected()
        {
            var testObjects = new InitializeConnectionsServiceTestObjectBuilder().WithAdminApiConnected(true)
                                                                                 .Build();

            // ACT
            await testObjects.InitializeConnectionsService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.CurvePublisherConnectionService)
                .Verify(c => c.RetryConnect());

            Mock.Get(testObjects.AdminApiConnectionService)
                .Verify(a => a.RetryConnect(), Times.Never);
        }

        [Test]
        public async Task ShouldInitializeAdminApiService_When_RetryConnect_AdminApi_With_IsConnectedTrue()
        {
            var testObjects = new InitializeConnectionsServiceTestObjectBuilder().WithCurvePublisherConnected(true)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithAdminApiConnectedNext(true)
                                                                                 .Build();

            // ACT
            await testObjects.InitializeConnectionsService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.AdminApiServiceClient)
                .Verify(a => a.Initialize(It.IsAny<IHttpClientProxy>()));
        }

        [Test]
        public async Task ShouldNotInitializeAdminApiService_When_RetryConnect_AdminApi_With_IsConnectedFalse()
        {
            var testObjects = new InitializeConnectionsServiceTestObjectBuilder().WithCurvePublisherConnected(true)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithAdminApiConnectedNext(false)
                                                                                 .Build();

            // ACT
            await testObjects.InitializeConnectionsService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.AdminApiServiceClient)
                .Verify(a => a.Initialize(It.IsAny<IHttpClientProxy>()), Times.Never);
        }
    }
}
