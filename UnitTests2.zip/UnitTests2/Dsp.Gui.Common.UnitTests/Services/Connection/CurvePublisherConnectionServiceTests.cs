﻿using System;
using System.Reactive.Subjects;
using System.Threading.Tasks;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services.Connection
{
    public interface ICurvePublisherConnectionServiceTestObjects
    {
        IAuthenticatedHubConnectionService AuthenticatedHubConnectionService { get; }
        IHubConnectionProxy HubConnection { get; }
        CurvePublisherConnectionService CurvePublisherConnectionService { get; }
    }

    [TestFixture]
    public class CurvePublisherConnectionServiceTests
    {
        private class CurvePublisherConnectionServiceTestObjectBuilder
        {
            private Uri _apiUri;
            private Uri _hubUri;
            private bool _hubConnected;

            public CurvePublisherConnectionServiceTestObjectBuilder WithApiUri(Uri value)
            {
                _apiUri = value;
                return this;
            }

            public CurvePublisherConnectionServiceTestObjectBuilder WithHubUri(Uri value)
            {
                _hubUri = value;
                return this;
            }

            public CurvePublisherConnectionServiceTestObjectBuilder WithHubConnected(bool value)
            {
                _hubConnected = value;
                return this;
            }

            public ICurvePublisherConnectionServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurvePublisherConnectionServiceTestObjects>();

                var configProvider = new Mock<IConfigProvider>();

                configProvider.Setup(c => c.GetApiUrl(It.IsAny<DataContracts.Configuration.Services>()))
                              .Returns(_apiUri);

                configProvider.Setup(c => c.GetSignalRUrl(It.IsAny<DataContracts.Configuration.Services>()))
                              .Returns(_hubUri);

                var hubConnectionProxy = new Mock<IHubConnectionProxy>();

                var startupState = new BehaviorSubject<HubConnectionStartupArgs>(null);

                var startupStatePublisher = new Mock<IHubConnectionStartupStatePublisher>();

                startupStatePublisher.SetupGet(p => p.StartupState)
                                     .Returns(startupState);

                var runState = new BehaviorSubject<HubConnectionRunState>(HubConnectionRunState.NotSet);

                var runStatePublisher = new Mock<IHubConnectionRunStatePublisher>();

                runStatePublisher.SetupGet(p => p.RunState)
                                 .Returns(runState);

                var authenticatedHubConnectionService = new Mock<IAuthenticatedHubConnectionService>();

                authenticatedHubConnectionService.SetupGet(h => h.HubConnectionProxy)
                                                 .Returns(hubConnectionProxy.Object);

                authenticatedHubConnectionService.SetupGet(h => h.StartupStatePublisher)
                                                 .Returns(startupStatePublisher.Object);

                authenticatedHubConnectionService.SetupGet(h => h.RunStatePublisher)
                                                 .Returns(runStatePublisher.Object);

                authenticatedHubConnectionService.SetupGet(h => h.IsConnected)
                                                 .Returns(_hubConnected);

                testObjects.SetupGet(o => o.AuthenticatedHubConnectionService)
                           .Returns(authenticatedHubConnectionService.Object);

                var curvePublisherConnectionService = new CurvePublisherConnectionService(authenticatedHubConnectionService.Object,
                                                                                          configProvider.Object);

                testObjects.SetupGet(o => o.CurvePublisherConnectionService)
                           .Returns(curvePublisherConnectionService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetHubConnectionProxy_From_HubConnection()
        {
            var testObjects = new CurvePublisherConnectionServiceTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.CurvePublisherConnectionService.HubConnectionProxy,
                        Is.SameAs(testObjects.AuthenticatedHubConnectionService.HubConnectionProxy));
        }

        [Test]
        public void ShouldGetStartupState_From_HubConnectionStartupStatePublisher()
        {
            var testObjects = new CurvePublisherConnectionServiceTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.CurvePublisherConnectionService.StartupState,
                        Is.SameAs(testObjects.AuthenticatedHubConnectionService.StartupStatePublisher.StartupState));
        }

        [Test]
        public void ShouldGetRunState_From_HubConnectionRunStatePublisher()
        {
            var testObjects = new CurvePublisherConnectionServiceTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.CurvePublisherConnectionService.RunState,
                        Is.SameAs(testObjects.AuthenticatedHubConnectionService.RunStatePublisher.RunState));
        }

        [Test]
        public void ShouldReturnIsConnectedTrue_When_HubConnectionProxyIsConnected()
        {
            var testObjects = new CurvePublisherConnectionServiceTestObjectBuilder().WithHubConnected(true)
                                                                                    .Build();

            // ASSERT
            Assert.That(testObjects.CurvePublisherConnectionService.IsConnected, Is.True);
        }

        [Test]
        public async Task ShouldConnectService()
        {
            var apiUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var testObjects = new CurvePublisherConnectionServiceTestObjectBuilder().WithApiUri(apiUri)
                                                                                    .WithHubUri(hubUri)
                                                                                    .Build();

            // ACT
            await testObjects.CurvePublisherConnectionService.Connect();

            // ASSERT
            Mock.Get(testObjects.AuthenticatedHubConnectionService)
                .Verify(a => a.Connect("Curve Publisher", apiUri, hubUri));
        }

        [Test]
        public async Task ShouldRetryConnectHub_When_RetryConnect()
        {
            var testObjects = new CurvePublisherConnectionServiceTestObjectBuilder().Build();

            // ACT
            await testObjects.CurvePublisherConnectionService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.AuthenticatedHubConnectionService)
                .Verify(a => a.RetryConnect());
        }

        [Test]
        public async Task ShouldRestartConnectHub_When_RestartConnect()
        {
            var testObjects = new CurvePublisherConnectionServiceTestObjectBuilder().Build();

            // ACT
            await testObjects.CurvePublisherConnectionService.RestartConnect();

            // ASSERT
            Mock.Get(testObjects.AuthenticatedHubConnectionService)
                .Verify(a => a.RestartConnect());
        }

        [Test]
        public async Task ShouldDisposeAsyncHubConnection_When_DisposeAsync()
        {
            var testObjects = new CurvePublisherConnectionServiceTestObjectBuilder().Build();

            // ACT
            await testObjects.CurvePublisherConnectionService.DisposeAsync();

            // ASSERT
            Mock.Get(testObjects.AuthenticatedHubConnectionService)
                .Verify(a => a.DisposeAsync());
        }
    }
}
