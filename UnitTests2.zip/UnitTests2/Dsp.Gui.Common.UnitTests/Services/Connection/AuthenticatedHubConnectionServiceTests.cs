﻿using System;
using System.Net;
using System.Net.Http;
using System.Security.Authentication;
using System.Threading.Tasks;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services.Connection
{
    public interface IAuthenticatedHubConnectionServiceTestObjects
    {
        IHubConnectionStartupStateService StartupStateService { get; }
        IHubConnectionRunStateService RunStateService { get; }
        IHubConnectionUserService UserService { get; }
        IHubConnectionService HubConnectionService { get; }
        IAuthenticatedServiceClient AuthenticatedServiceClient { get; }
        IHubConnectionClient HubConnectionClient { get; }
        AuthenticatedHubConnectionService AuthenticatedHubConnectionService { get; }
    }

    [TestFixture]
    public class AuthenticatedHubConnectionServiceTests
    {
        private class AuthenticatedHubConnectionServiceTestObjectBuilder
        {
            private bool _hubConnectionIsConnected;
            private AuthenticationException _authenticationConnectAuthenticationException;
            private HttpRequestException _authenticationConnectHttpRequestException;
            private Exception _authenticationConnectUnexpectedException;
            private HttpRequestException _hubConnectHttpRequestException;
            private InvalidOperationException _hubInitializeInvalidOperationException;
            private Exception _hubConnectUnexpectedException;

            public AuthenticatedHubConnectionServiceTestObjectBuilder WithHubConnectionIsConnected(bool value)
            {
                _hubConnectionIsConnected = value;
                return this;
            }

            public AuthenticatedHubConnectionServiceTestObjectBuilder WithAuthenticationConnectAuthenticationException(AuthenticationException value)
            {
                _authenticationConnectAuthenticationException = value;
                return this;
            }

            public AuthenticatedHubConnectionServiceTestObjectBuilder WithAuthenticationConnectHttpRequestException(HttpRequestException value)
            {
                _authenticationConnectHttpRequestException = value;
                return this;
            }

            public AuthenticatedHubConnectionServiceTestObjectBuilder WithAuthenticationConnectUnexpectedException(Exception value)
            {
                _authenticationConnectUnexpectedException = value;
                return this;
            }

            public AuthenticatedHubConnectionServiceTestObjectBuilder WithHubInitializeInvalidOperationException(InvalidOperationException value)
            {
                _hubInitializeInvalidOperationException = value;
                return this;
            }

            public AuthenticatedHubConnectionServiceTestObjectBuilder WithHubConnectHttpRequestException(HttpRequestException value)
            {
                _hubConnectHttpRequestException = value;
                return this;
            }

            public AuthenticatedHubConnectionServiceTestObjectBuilder WithHubConnectUnexpectedException(Exception value)
            {
                _hubConnectUnexpectedException = value;
                return this;
            }

            public IAuthenticatedHubConnectionServiceTestObjects Build()
            {
                var testObjects = new Mock<IAuthenticatedHubConnectionServiceTestObjects>();

                var startupStateService = new Mock<IHubConnectionStartupStateService>();

                testObjects.SetupGet(o => o.StartupStateService)
                           .Returns(startupStateService.Object);

                var runStateService = new Mock<IHubConnectionRunStateService>();

                testObjects.SetupGet(o => o.RunStateService)
                           .Returns(runStateService.Object);

                var userService = new Mock<IHubConnectionUserService>();

                testObjects.SetupGet(o => o.UserService)
                           .Returns(userService.Object);

                var hubConnectionClient = new Mock<IHubConnectionClient>();

                testObjects.SetupGet(o => o.HubConnectionClient)
                           .Returns(hubConnectionClient.Object);


                #region authenticatedServiceClient

                var authenticatedServiceClient = new Mock<IAuthenticatedServiceClient>();

                var httpClientProxy = new Mock<IHttpClientProxy>();

                authenticatedServiceClient.SetupGet(a => a.HttpClient)
                                          .Returns(httpClientProxy.Object);

                if (_authenticationConnectAuthenticationException != null)
                {
                    authenticatedServiceClient.Setup(a => a.Connect(It.IsAny<Uri>()))
                                              .Throws(_authenticationConnectAuthenticationException);
                }
                else if (_authenticationConnectHttpRequestException != null)
                {
                    authenticatedServiceClient.SetupSequence(a => a.Connect(It.IsAny<Uri>()))
                                              .Throws(_authenticationConnectHttpRequestException);
                }
                else if (_authenticationConnectUnexpectedException != null)
                {
                    authenticatedServiceClient.SetupSequence(a => a.Connect(It.IsAny<Uri>()))
                                              .Throws(_authenticationConnectUnexpectedException);
                }

                testObjects.SetupGet(o => o.AuthenticatedServiceClient)
                           .Returns(authenticatedServiceClient.Object);

                #endregion

                #region hubConnectionService

                var hubConnectionProxy = new Mock<IHubConnectionProxy>();

                hubConnectionProxy.SetupGet(p => p.IsConnected)
                                  .Returns(_hubConnectionIsConnected);

                var hubConnectionService = new Mock<IHubConnectionService>();

                if (_hubConnectHttpRequestException != null)
                {
                    hubConnectionService.SetupSequence(h => h.Connect())
                                        .Throws(_hubConnectHttpRequestException);
                }
                else if (_hubConnectUnexpectedException != null)
                {
                    hubConnectionService.SetupSequence(h => h.Connect())
                                        .Throws(_hubConnectUnexpectedException);
                }

                if (_hubInitializeInvalidOperationException != null)
                {
                    hubConnectionService.SetupSequence(h => h.Initialize(It.IsAny<IAuthenticatedServiceClient>(), 
                                                                         It.IsAny<IHubConnectionClient>(),
                                                                         It.IsAny<Uri>()))
                                        .Throws(_hubInitializeInvalidOperationException);
                }
                else
                {
                    hubConnectionService.Setup(h => h.Initialize(It.IsAny<IAuthenticatedServiceClient>(),
                                                                 It.IsAny<IHubConnectionClient>(),
                                                                 It.IsAny<Uri>()))
                                        .Returns(hubConnectionProxy.Object);
                }

                testObjects.SetupGet(o => o.HubConnectionService)
                           .Returns(hubConnectionService.Object);

                #endregion

                var authenticatedHubConnectionService = new AuthenticatedHubConnectionService(authenticatedServiceClient.Object,
                                                                                              hubConnectionService.Object,
                                                                                              startupStateService.Object,
                                                                                              runStateService.Object,
                                                                                              userService.Object,
                                                                                              hubConnectionClient.Object,
                                                                                              TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.AuthenticatedHubConnectionService)
                           .Returns(authenticatedHubConnectionService);

                return testObjects.Object;
            }
        }

        #region state publishers and current user

        [Test]
        public void ShouldGetStartupStatePublisher_From_StartupStateService()
        {
            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.AuthenticatedHubConnectionService.StartupStatePublisher,
                        Is.SameAs(testObjects.StartupStateService));
        }

        [Test]
        public void ShouldGetRunStatePublisher_From_RunStateService()
        {
            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.AuthenticatedHubConnectionService.RunStatePublisher,
                        Is.SameAs(testObjects.RunStateService));
        }

        [Test]
        public void ShouldGetUserPublisher_From_UserService()
        {
            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.AuthenticatedHubConnectionService.UserPublisher,
                        Is.SameAs(testObjects.UserService));
        }

        [Test]
        public async Task ShouldReturnIsConnectedTrue_With_HubConnectedIsConnectedTrue()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithHubConnectionIsConnected(true)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Assert.That(testObjects.AuthenticatedHubConnectionService.IsConnected);
        }

        #endregion

        #region authenticate and connect with no errors

        [Test]
        public async Task ShouldInitializeHubConnectionClient_And_ConnectAuthentication_When_Connect()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.Initialize("service",
                                          testObjects.StartupStateService,
                                          testObjects.RunStateService,
                                          testObjects.UserService));

            Mock.Get(testObjects.HubConnectionClient)
                .Verify(c => c.OnConnecting());

            Mock.Get(testObjects.AuthenticatedServiceClient)
                .Verify(a => a.Connect(authenticationUri));
        }

        [Test]
        public async Task ShouldInitializeHubConnectionService_And_Connect_When_ConnectAuthenticationSuccess()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Assert.That(testObjects.AuthenticatedHubConnectionService.HttpClientProxy, Is.Not.Null);

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Initialize(testObjects.AuthenticatedServiceClient,
                                          testObjects.HubConnectionClient,
                                          hubUri));

            Assert.That(testObjects.AuthenticatedHubConnectionService.HubConnectionProxy, Is.Not.Null);

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Connect());
        }

        #endregion authenticate and connect with no errors

        #region authentication errors

        [Test]
        public async Task ShouldOnSsoAuthenticationError_When_ConnectAuthentication_With_AuthenticationException()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new AuthenticationException("sso");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectAuthenticationException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnSsoAuthenticationError());

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Initialize(testObjects.AuthenticatedServiceClient,
                                          testObjects.HubConnectionClient,
                                          hubUri), Times.Never);
        }

        [Test]
        public async Task ShouldInvokeOnHttpServiceUnavailable_When_ConnectAuthentication_With_HttpRequestException_ServiceUnavailable()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new HttpRequestException("http", null, HttpStatusCode.ServiceUnavailable);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectHttpRequestException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnHttpServiceUnavailable());

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Initialize(testObjects.AuthenticatedServiceClient,
                                          testObjects.HubConnectionClient,
                                          hubUri), Times.Never);
        }

        [Test]
        public async Task ShouldInvokeOnHttpUnauthorized_When_ConnectAuthentication_With_HttpRequestException_Unauthorized()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new HttpRequestException("http", null, HttpStatusCode.Unauthorized);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectHttpRequestException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnHttpUnauthorized());

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Initialize(testObjects.AuthenticatedServiceClient,
                                          testObjects.HubConnectionClient,
                                          hubUri), Times.Never);
        }

        [Test]
        public async Task ShouldInvokeOnHttpUnexpectedError_When_ConnectAuthentication_With_HttpRequestException_Unexpected()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new HttpRequestException("error", null);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectHttpRequestException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnHttpUnexpectedError("error"));

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Initialize(testObjects.AuthenticatedServiceClient,
                                          testObjects.HubConnectionClient,
                                          hubUri), Times.Never);
        }

        [Test]
        public async Task ShouldOnHttpUnexpectedError_When_ConnectAuthentication_With_AuthenticationUnexpectedError()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new Exception("error");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectUnexpectedException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnHttpUnexpectedError("error"));
        }

        #endregion

        #region hub connection after authentication with no errors

        [Test]
        public async Task ShouldInitializeHubAndConnect_After_Authentication_With_NoErrors()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Initialize(testObjects.AuthenticatedServiceClient, testObjects.HubConnectionClient, hubUri));

            Assert.That(testObjects.AuthenticatedHubConnectionService.HubConnectionProxy, Is.Not.Null);

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Connect());
        }

        #endregion

        #region hub connection errors

        [Test]
        public async Task ShouldInvokeOnHubInitializeFailed_When_Connect_With_HubInitializeException()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new InvalidOperationException("error");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithHubInitializeInvalidOperationException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnHubInitializeFailed());

            Assert.That(testObjects.AuthenticatedHubConnectionService.HubConnectionProxy, Is.Null);

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Connect(), Times.Never);
        }

        [Test]
        public async Task ShouldInvokeOnHttpServiceUnavailable_When_ConnectHub_With_HttpRequestException_ServiceUnavailable()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new HttpRequestException("http", null, HttpStatusCode.ServiceUnavailable);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithHubConnectHttpRequestException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnHttpServiceUnavailable());

            Assert.That(testObjects.AuthenticatedHubConnectionService.HubConnectionProxy, Is.Not.Null);
        }

        [Test]
        public async Task ShouldInvokeOnHttpUnauthorized_When_ConnectHub_With_HttpRequestException_Unauthorized()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new HttpRequestException("http", null, HttpStatusCode.Unauthorized);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithHubConnectHttpRequestException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnHttpUnauthorized());

            Assert.That(testObjects.AuthenticatedHubConnectionService.HubConnectionProxy, Is.Not.Null);
        }

        [Test]
        public async Task ShouldInvokeOnHttpUnexpectedError_When_ConnectHub_With_HubConnectUnexpectedException()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new Exception("error");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithHubConnectUnexpectedException(error)
                                                                                      .Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnHttpUnexpectedError("error"));
        }

        #endregion

        #region retry after authentication errors

        [Test]
        public async Task ShouldThrowInvalidOperationException_When_RetryConnect_After_FatalAuthenticationError()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new AuthenticationException("error");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectAuthenticationException(error)
                                                                                      .Build();

            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            Exception result = null;

            try
            {
                // ACT
                await testObjects.AuthenticatedHubConnectionService.RetryConnect();
            }
            catch (Exception ex)
            {
                result = ex;
            }

            // ASSERT
            Assert.That(result, Is.TypeOf<InvalidOperationException>());
        }

        [Test]
        public async Task ShouldThrowInvalidOperationException_When_RetryConnect_After_FatalAuthenticationUnexpectedError()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new Exception("error");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectUnexpectedException(error)
                                                                                      .Build();

            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            Exception result = null;

            try
            {
                // ACT
                await testObjects.AuthenticatedHubConnectionService.RetryConnect();
            }
            catch (Exception ex)
            {
                result = ex;
            }

            // ASSERT
            Assert.That(result, Is.TypeOf<InvalidOperationException>());
        }

        [Test]
        public async Task ShouldNotInitializeClient_When_RetryConnect_After_AuthenticationNonFatalError()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var exception = new HttpRequestException("http", null, HttpStatusCode.ServiceUnavailable);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectHttpRequestException(exception)
                                                                                      .Build();

            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            Mock.Get(testObjects.HubConnectionClient).Invocations.Clear();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.Initialize("service",
                                          testObjects.StartupStateService,
                                          testObjects.RunStateService,
                                          testObjects.UserService), Times.Never);
        }

        [Test]
        public async Task ShouldReattemptAuthentication_When_RetryConnect_After_HubConnectNonFatalError()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var exception = new HttpRequestException("http", null, HttpStatusCode.ServiceUnavailable);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithAuthenticationConnectHttpRequestException(exception)
                                                                                      .Build();

            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            Mock.Get(testObjects.HubConnectionClient).Invocations.Clear();
            Mock.Get(testObjects.AuthenticatedServiceClient).Invocations.Clear();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(c => c.OnConnecting());

            Mock.Get(testObjects.AuthenticatedServiceClient)
                .Verify(a => a.Connect(authenticationUri));
        }

        #endregion

        #region retry after hub connection errors

        [Test]
        public async Task ShouldThrowInvalidOperationException_When_RetryConnect_After_HubInitializeException()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new InvalidOperationException("error");

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithHubInitializeInvalidOperationException(error)
                                                                                      .Build();

            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            Exception result = null;

            try
            {
                // ACT
                await testObjects.AuthenticatedHubConnectionService.RetryConnect();
            }
            catch (Exception ex)
            {
                result = ex;
            }

            // ASSERT
            Assert.That(result, Is.TypeOf<InvalidOperationException>());
        }

        [Test]
        public async Task ShouldNotReattemptAuthentication_When_RetryConnect_After_HubConnectNonFatalError()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new HttpRequestException("http", null, HttpStatusCode.ServiceUnavailable);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithHubConnectHttpRequestException(error)
                                                                                      .Build();

            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            Mock.Get(testObjects.HubConnectionClient).Invocations.Clear();
            Mock.Get(testObjects.AuthenticatedServiceClient).Invocations.Clear();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.AuthenticatedServiceClient)
                .Verify(a => a.Connect(authenticationUri), Times.Never);
        }

        [Test]
        public async Task ShouldInitializeHubAndConnect_When_RetryConnect_After_HubConnectNonFatalError()
        {
            var authenticationUri = new Uri("http://gui.dsp-dev.shell.com");
            var hubUri = new Uri("http://gui.dsp-dev.shell.com/signalr");

            var error = new HttpRequestException("http", null, HttpStatusCode.ServiceUnavailable);

            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().WithHubConnectHttpRequestException(error)
                                                                                      .Build();

            await testObjects.AuthenticatedHubConnectionService.Connect("service", authenticationUri, hubUri);

            Mock.Get(testObjects.HubConnectionClient).Invocations.Clear();
            Mock.Get(testObjects.AuthenticatedServiceClient).Invocations.Clear();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.RetryConnect();

            // ASSERT
            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Initialize(testObjects.AuthenticatedServiceClient, testObjects.HubConnectionClient, hubUri));

            Assert.That(testObjects.AuthenticatedHubConnectionService.HubConnectionProxy, Is.Not.Null);

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Connect());
        }

        #endregion

        #region restart hub connection

        [Test]
        public async Task ShouldConnect_When_RestartConnect()
        {
            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.RestartConnect();

            // ASSERT
            Mock.Get(testObjects.HubConnectionClient)
                .Verify(h => h.OnRestart());

            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.Connect());
        }

        #endregion

        #region dispose

        [Test]
        public async Task ShouldDisposeAsyncHubConnectionService_When_DisposeAsync()
        {
            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ACT
            await testObjects.AuthenticatedHubConnectionService.DisposeAsync();

            // ASSERT
            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.DisposeAsync());

            Mock.Get(testObjects.AuthenticatedServiceClient)
                .Verify(a => a.Dispose());
        }

        [Test]
        public async Task ShouldNotDisposeAsync_When_DisposeAsync_With_Dispose()
        {
            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            await testObjects.AuthenticatedHubConnectionService.DisposeAsync();

            Mock.Get(testObjects.HubConnectionService).Invocations.Clear();
            // ACT
            await testObjects.AuthenticatedHubConnectionService.DisposeAsync();

            // ASSERT
            Mock.Get(testObjects.HubConnectionService)
                .Verify(h => h.DisposeAsync(), Times.Never);
        }

        [Test]
        public void ShouldDisposeAuthenticatedServiceClient_When_Dispose()
        {
            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            // ACT
            testObjects.AuthenticatedHubConnectionService.Dispose();

            // ASSERT
            Mock.Get(testObjects.AuthenticatedServiceClient)
                .Verify(a => a.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new AuthenticatedHubConnectionServiceTestObjectBuilder().Build();

            testObjects.AuthenticatedHubConnectionService.Dispose();

            Mock.Get(testObjects.AuthenticatedServiceClient).Invocations.Clear();

            // ACT
            testObjects.AuthenticatedHubConnectionService.Dispose();

            // ASSERT
            Mock.Get(testObjects.AuthenticatedServiceClient)
                .Verify(a => a.Dispose(), Times.Never);

        }

        #endregion
    }
}
