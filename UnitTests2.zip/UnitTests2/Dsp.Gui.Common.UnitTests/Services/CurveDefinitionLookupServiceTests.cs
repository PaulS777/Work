﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    public interface ICurveDefinitionLookupServiceTestObjects
    {
        ISubject<List<DerivedCurveDefinition>> DerivedCurves { get; }
        ISubject<List<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        CurveDefinitionLookupService CurveDefinitionLookupService { get; }
    }

    [TestFixture]
    public class CurveDefinitionLookupServiceTests
    {
        private class CurveLookupServiceTestObjectBuilder
        {
            public ICurveDefinitionLookupServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveDefinitionLookupServiceTestObjects>();

                var derivedCurves = new BehaviorSubject<List<DerivedCurveDefinition>>(null);

                testObjects.SetupGet(o => o.DerivedCurves)
                           .Returns(derivedCurves);

                var priceCurves = new BehaviorSubject<List<PriceCurveDefinition>>(null);

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurves);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.DerivedCurveDefinitions)
                                   .Returns(derivedCurves);

                curveControlService.SetupGet(c => c.PriceCurveDefinitions)
                                   .Returns(priceCurves);

                var provider = new CurveDefinitionLookupService(curveControlService.Object,
                                                                Mocks.GetSchedulerProvider().Object,
                                                                Mocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.CurveDefinitionLookupService)
                           .Returns(provider);

                return testObjects.Object;
            }

        }

        [Test]
        public void ShouldPublishOnCurvesLoaded()
        {
            var priceCurve = new PriceCurveDefinitionTestObjectBuilder().Build();
            var derivedCurve = new DerivedCurveDefinition(new DerivedCurveDefinition<MonthlyTenor>());

            var testObjects = new CurveLookupServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveDefinitionLookupService.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext([priceCurve]);
                testObjects.DerivedCurves.OnNext([derivedCurve]);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotPublishCuresLoaded_WhenPriceCurvesNull()
        {
            var derivedCurve = new DerivedCurveDefinition(new DerivedCurveDefinition<MonthlyTenor>());

			var testObjects = new CurveLookupServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveDefinitionLookupService.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext(null);
                testObjects.DerivedCurves.OnNext([derivedCurve]);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishCurvesLoaded_WhenDerivedCurvesNull()
        {
			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().Build();

			var testObjects = new CurveLookupServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveDefinitionLookupService.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext([priceCurve]);
                testObjects.DerivedCurves.OnNext(null);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldGetFlatPriceCurveDefinitions()
        {
			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().Build();

			var derivedCurves = new List<DerivedCurveDefinition>
            {
                new( new DerivedCurveDefinition<MonthlyTenor>(new FlatPriceCurveDefinition<MonthlyTenor>
                                                                  (
                                                                   201, "flat-price","desc",101, 10, new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve), null
                                                                  )))
            };

            var testObjects = new CurveLookupServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveDefinitionLookupService.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext([priceCurve]);
                testObjects.DerivedCurves.OnNext(derivedCurves);

                // ASSERT
                Assert.That(result, Is.True);
                Assert.That(testObjects.CurveDefinitionLookupService.FlatPriceCurveDefinitions.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldGetPartitionCurveDefinitions()
        {
			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().Build();

			var derivedCurves = new List<DerivedCurveDefinition>
            {
                new(new DerivedCurveDefinition<MonthlyTenor>(new PartitionedCurveDefinition<MonthlyTenor>
                                                                 (201, "partition", "desc", 101, 10, [])))
            };

            var testObjects = new CurveLookupServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveDefinitionLookupService.CurvesLoaded.Subscribe(r => result = r))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext([priceCurve]);
                testObjects.DerivedCurves.OnNext(derivedCurves);

                // ASSERT
                Assert.That(result, Is.True);
                Assert.That(testObjects.CurveDefinitionLookupService.PartitionedCurveDefinitions.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotPublishWhenDisposed()
        {
			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().Build();
            var derivedCurve = new DerivedCurveDefinition(new DerivedCurveDefinition<MonthlyTenor>());

			var testObjects = new CurveLookupServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.CurveDefinitionLookupService.CurvesLoaded.Subscribe(r => result = r))
            {

                testObjects.CurveDefinitionLookupService.Dispose();

                // ACT
                testObjects.PriceCurveDefinitions.OnNext([priceCurve]);
                testObjects.DerivedCurves.OnNext([derivedCurve]);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
