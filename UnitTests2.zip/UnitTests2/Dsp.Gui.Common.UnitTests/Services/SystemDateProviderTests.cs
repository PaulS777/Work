﻿using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    public interface ISystemDateProviderTestObjects
    {
        ISubject<SystemDate> SystemDate { get; }
        SystemDateProvider SystemDateProvider { get; }
    }

    [TestFixture]
    public class SystemDateProviderTests
    {
        private class SystemDateProviderTestObjectBuilder
        {
            private IList<Calendar> _calendars;

            public SystemDateProviderTestObjectBuilder WithCalendars(IList<Calendar> values)
            {
                _calendars = values;
                return this;
            }

            public ISystemDateProviderTestObjects Build()
            {
                var testObjects = new Mock<ISystemDateProviderTestObjects>();

                var systemDate = new BehaviorSubject<SystemDate>(null);
              
                testObjects.SetupGet(o => o.SystemDate)
                           .Returns(systemDate);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.SystemDate)
                                   .Returns(systemDate);

                curveControlService.SetupGet(c => c.Calendars)
                                   .Returns(Observable.Return(_calendars));

                var systemDateProvider = new SystemDateProvider(curveControlService.Object);

                testObjects.SetupGet(o => o.SystemDateProvider)
                           .Returns(systemDateProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishSystemDate_When_MatchingUkCalendar()
        {
            var date1 = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var date2 = new DateTime(2023, 1, 2, 0, 0, 0, DateTimeKind.Utc);

            var calendars = new List<Calendar>
                            {
                                new(10, EntityStatus.Active, "UKB", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>()),
                                new(11, EntityStatus.Active, "OTHER", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>())
                            };

            var testObjects = new SystemDateProviderTestObjectBuilder().WithCalendars(calendars).Build();

            var systemDate = new SystemDate(new List<BusinessDay>
                                            {
                                                new(10, date1, DateTime.MinValue, true),
                                                new(11, date2, DateTime.MinValue, true)
                                            }, DateTime.MinValue);

            DateTime? result = null;

            using (testObjects.SystemDateProvider.SystemDate.Subscribe(value => result = value))
            {
                // ACT
                testObjects.SystemDate.OnNext(systemDate);

                // ASSERT
                Assert.That(result, Is.EqualTo(date1));
            }
        }

        [Test]
        public void ShouldPublishSystemDate_When_NextSubscribe()
        {
            var date1 = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var date2 = new DateTime(2023, 1, 2, 0, 0, 0, DateTimeKind.Utc);

            var calendars = new List<Calendar>
                            {
                                new(10, EntityStatus.Active, "UKB", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>()),
                                new(11, EntityStatus.Active, "OTHER", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>())
                            };

            var testObjects = new SystemDateProviderTestObjectBuilder().WithCalendars(calendars).Build();

            var systemDate = new SystemDate(new List<BusinessDay>
                                            {
                                                new(10, date1, DateTime.MinValue, true),
                                                new(11, date2, DateTime.MinValue, true)
                                            }, DateTime.MinValue);

            DateTime? result = null;

            // ACT
            testObjects.SystemDate.OnNext(systemDate);

            testObjects.SystemDateProvider.SystemDate.Subscribe(_ => { });

            testObjects.SystemDateProvider.SystemDate.Subscribe(value => { result = value; });

            // ASSERT
            Assert.That(result, Is.EqualTo(date1));

            testObjects.SystemDate.OnNext(systemDate);
        }


        [Test]
        public void ShouldPublish_When_SystemDateUpdate_With_Different_UkCalendarCurrentBusinessDate()
        {
            var date1 = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var date2 = new DateTime(2023, 1, 2, 0, 0, 0, DateTimeKind.Utc);

            var calendars = new List<Calendar>
                            {
                                new(10, EntityStatus.Active, "UKB", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>()),
                                new(11, EntityStatus.Active, "OTHER", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>())
                            };

            var testObjects = new SystemDateProviderTestObjectBuilder().WithCalendars(calendars).Build();

            var systemDate = new SystemDate(new List<BusinessDay>
                                            {
                                                new(10, date1, DateTime.MinValue, true),
                                                new(11, date2, DateTime.MinValue, true)
                                            }, DateTime.MinValue);

            var systemDateUpdate = new SystemDate(new List<BusinessDay>
                                                  {
                                                      new(10, date2, DateTime.MinValue, true),
                                                      new(11, date2, DateTime.MinValue, true)
                                                  }, DateTime.MinValue);

            DateTime? result = null;

            using (testObjects.SystemDateProvider.SystemDate.Subscribe(value => result = value))
            {
                testObjects.SystemDate.OnNext(systemDate);

                // ACT
                testObjects.SystemDate.OnNext(systemDateUpdate);

                // ASSERT
                Assert.That(result, Is.EqualTo(date2));
            }
        }

        [Test]
        public void ShouldNotPublishUpdate_When_SystemDateUpdate_With_Same_UkCalendarCurrentBusinessDate()
        {
            var date1 = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var date2 = new DateTime(2023, 1, 2, 0, 0, 0, DateTimeKind.Utc);
            var date3 = new DateTime(2023, 1, 3, 0, 0, 0, DateTimeKind.Utc);

            var calendars = new List<Calendar>
                            {
                                new(10, EntityStatus.Active, "UKB", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>()),
                                new(11, EntityStatus.Active, "OTHER", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>())
                            };

            var testObjects = new SystemDateProviderTestObjectBuilder().WithCalendars(calendars).Build();

            var systemDate = new SystemDate(new List<BusinessDay>
                                            {
                                                new(10, date1, DateTime.MinValue, true),
                                                new(11, date2, DateTime.MinValue, true)
                                            }, DateTime.MinValue);

            var systemDateUpdate = new SystemDate(new List<BusinessDay>
                                            {
                                                new(10, date1, DateTime.MinValue, true),
                                                new(11, date3, DateTime.MinValue, true)
                                            }, DateTime.MinValue);

            DateTime? result = null;
            var count = 0;

            using (testObjects.SystemDateProvider.SystemDate.Where(date => date != null).Subscribe(value =>
                   {
                       result = value;
                       count++;
                   }))
            {
                testObjects.SystemDate.OnNext(systemDate);

                // ACT
                testObjects.SystemDate.OnNext(systemDateUpdate);

                // ASSERT
                Assert.That(result, Is.EqualTo(date1));
                Assert.That(count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotPublish_When_NonMatchingUkCalendar()
        {
            var date2 = new DateTime(2023, 1, 2, 0, 0, 0, DateTimeKind.Utc);

            var calendars = new List<Calendar>
                            {
                                new(10, EntityStatus.Active, "UKB", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>()),
                                new(11, EntityStatus.Active, "OTHER", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>())
                            };

            var testObjects = new SystemDateProviderTestObjectBuilder().WithCalendars(calendars).Build();

            var systemDate = new SystemDate(new List<BusinessDay>
                                            {
                                                new(11, date2, DateTime.MinValue, true)
                                            }, DateTime.MinValue);

            DateTime? result = null;

            using (testObjects.SystemDateProvider.SystemDate.Subscribe(value => result = value))
            {
                // ACT
                testObjects.SystemDate.OnNext(systemDate);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }

        [Test]
        public void ShouldNotPublishSystemDate_When_Disposed()
        {
            var date1 = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var date2 = new DateTime(2023, 1, 2, 0, 0, 0, DateTimeKind.Utc);

            var calendars = new List<Calendar>
                            {
                                new(10, EntityStatus.Active, "UKB", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>())
                            };

            var testObjects = new SystemDateProviderTestObjectBuilder().WithCalendars(calendars).Build();

            var systemDate = new SystemDate(new List<BusinessDay>
                                            {
                                                new(10, date1, DateTime.MinValue, true),
                                                new(11, date2, DateTime.MinValue, true)
                                            }, DateTime.MinValue);

            DateTime? result = null;

            using (testObjects.SystemDateProvider.SystemDate.Subscribe(value => result = value))
            {
                testObjects.SystemDateProvider.Dispose();

                // ACT
                testObjects.SystemDate.OnNext(systemDate);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var date1 = new DateTime(2023, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var date2 = new DateTime(2023, 1, 2, 0, 0, 0, DateTimeKind.Utc);

            var calendars = new List<Calendar>
                            {
                                new(10, EntityStatus.Active, "UKB", string.Empty, string.Empty, string.Empty, string.Empty, true, new List<DateTime>())
                            };

            var testObjects = new SystemDateProviderTestObjectBuilder().WithCalendars(calendars).Build();

            var systemDate = new SystemDate(new List<BusinessDay>
                                            {
                                                new(10, date1, DateTime.MinValue, true),
                                                new(11, date2, DateTime.MinValue, true)
                                            }, DateTime.MinValue);

            DateTime? result = null;

            using (testObjects.SystemDateProvider.SystemDate.Subscribe(value => result = value))
            {
                testObjects.SystemDateProvider.Dispose();

                // ACT
                testObjects.SystemDateProvider.Dispose();
                testObjects.SystemDate.OnNext(systemDate);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
