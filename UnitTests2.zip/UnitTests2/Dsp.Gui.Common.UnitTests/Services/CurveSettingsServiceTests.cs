﻿using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    [TestFixture]
    public class CurveSettingsServiceTests
    {
        [Test]
        public void ShouldSubscribeToPriceCurveSettings_OnCurveDefinitionsLoaded()
        {
            var curveControlService = new Mock<ICurveControlService>();

            var priceCurveDefinitionsSubject = new Subject<List<PriceCurveDefinition>>();

            curveControlService.SetupGet(c => c.PriceCurveDefinitions)
                               .Returns(priceCurveDefinitionsSubject);

            var fxCurveDefinitionsSubject = new Subject<List<FxCurveDefinition>>();

            curveControlService.SetupGet(c => c.FxCurveDefinitions)
                               .Returns(fxCurveDefinitionsSubject);

            var curveSettingsService = new CurveSettingsService(curveControlService.Object, 
                Mocks.GetSchedulerProvider().Object,
                Mocks.GetLoggerFactory().Object);

            curveSettingsService.Initialize();

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

            var priceCurveDefinitions = new List<PriceCurveDefinition> { priceCurveDefinition };

            var fxCurveDefinition = new FxCurveDefinitionTestObjectBuilder().WithId(102).Build();

            var fxCurveDefinitions = new List<FxCurveDefinition> { fxCurveDefinition };

            var expectedPriceCurveIds = new[] { 101 };
            var expectedFxCurveIds = new[] { 102 };

            // ACT
            priceCurveDefinitionsSubject.OnNext(priceCurveDefinitions);
            fxCurveDefinitionsSubject.OnNext(fxCurveDefinitions);

            // ASSERT
            curveControlService.Verify(c => c.SubscribePriceCurves(It.Is<IEnumerable<int>>(ids => ids.SequenceEqual(expectedPriceCurveIds))));

            curveControlService.Verify(c => c.SubscribeFxCurves(It.Is<IEnumerable<int>>(ids => ids.SequenceEqual(expectedFxCurveIds))));
        }

        [Test]
        public void ShouldUnsubscribeCurveDefinitions_WhenDisposed()
        {
            var curveControlService = new Mock<ICurveControlService>();

            var priceCurveDefinitionsSubject = new Subject<List<PriceCurveDefinition>>();
            curveControlService.SetupGet(c => c.PriceCurveDefinitions).Returns(priceCurveDefinitionsSubject);

            var fxCurveDefinitionsSubject = new Subject<List<FxCurveDefinition>>();
            curveControlService.SetupGet(c => c.FxCurveDefinitions).Returns(fxCurveDefinitionsSubject);

            var curveSettingsService = new CurveSettingsService(curveControlService.Object,
                Mocks.GetSchedulerProvider().Object,
                Mocks.GetLoggerFactory().Object);

            curveSettingsService.Initialize();

			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var priceCurveDefinitions = new List<PriceCurveDefinition> { priceCurveDefinition };


			curveSettingsService.Dispose();

            // ACT
            priceCurveDefinitionsSubject.OnNext(priceCurveDefinitions);


            // ASSERT
            curveControlService.Verify(c => c.SubscribePriceCurves(It.IsAny<IEnumerable<int>>()), Times.Never());
        }
    }
}
