﻿using System;
using System.Reactive.Subjects;
using Dsp.Gui.Common.Services;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
	[TestFixture]
	public class CompositeDisposableEnvelopeTests
	{
        [Test]
        public void ShouldAddSubscription_With_Disposable()
        {
            var subject = new Subject<int>();

            var envelope = new CompositeDisposableEnvelope();

            var result = 0;

            var disposable = subject.Subscribe(i => result = i);

            // ARRANGE
            envelope.AddSubscription(disposable);

            // ACT
            subject.OnNext(1);

            // ASSERT
            Assert.That(result, Is.EqualTo(1));
        }

        [Test]
        public void ShouldResetSubscriptions()
        {
            var subject = new Subject<int>();

            var envelope = new CompositeDisposableEnvelope();

            var result = 0;

            var disposable = subject.Subscribe(i => result = i);

            // ARRANGE
            envelope.AddSubscription(disposable);

            envelope.ResetSubscriptions();

            // ACT
            subject.OnNext(1);

            // ASSERT
            Assert.That(result, Is.EqualTo(0));
		}

        [Test]
        public void ShouldDisposeSubscriptions()
        {
            var subject = new Subject<int>();

            var envelope = new CompositeDisposableEnvelope();

            var result = 0;

            var disposable = subject.Subscribe(i => result = i);

            // ARRANGE
            envelope.AddSubscription(disposable);

            envelope.Dispose();

            // ACT
            subject.OnNext(1);

            // ASSERT
            Assert.That(result, Is.EqualTo(0));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var subject = new Subject<int>();

            var envelope = new CompositeDisposableEnvelope();

            var result = 0;

            var disposable = subject.Subscribe(i => result = i);

            // ARRANGE
            envelope.AddSubscription(disposable);

            envelope.Dispose();

			// ACT
			envelope.Dispose();
			subject.OnNext(1);

            // ASSERT
            Assert.That(result, Is.EqualTo(0));
        }
	}
}
