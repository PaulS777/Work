﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    public interface IPriceCurveSettingsProviderTestObjects
    {
        TestScheduler TestScheduler { get; }
        ISubject<List<PriceCurveSetting>> PriceCurveSettings { get; }
        PriceCurveSettingsProvider PriceCurveSettingsProvider { get; }
    }

    [TestFixture]
    public class PriceCurveSettingsProviderTests
    {
        private class PriceCurveSettingsProviderTestObjectBuilder
        {
            private List<PriceCurveSetting> _priceCurveSettings;

            public PriceCurveSettingsProviderTestObjectBuilder WithPriceCurveSettings(List<PriceCurveSetting> values)
            {
                _priceCurveSettings = values;
                return this;
            }

            public IPriceCurveSettingsProviderTestObjects Build()
            {
                var testObjects = new Mock<IPriceCurveSettingsProviderTestObjects>();

                var scheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(scheduler);               

                var priceCurveSettings = new BehaviorSubject<List<PriceCurveSetting>>(_priceCurveSettings);

                testObjects.SetupGet(o => o.PriceCurveSettings)
                           .Returns(priceCurveSettings);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.PriceCurveSettings)
                                   .Returns(priceCurveSettings);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(scheduler);

                var priceCurveSettingsProvider = new PriceCurveSettingsProvider(curveControlService.Object, 
                                                                                schedulerProvider.Object,
                                                                                Mocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.PriceCurveSettingsProvider).Returns(priceCurveSettingsProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishPriceCurveSettings_OnTickInterval()
        {
            var priceCurveSettings = new List<PriceCurveSetting>
            {
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build(),
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).Build()
            };

            var testObjects = new PriceCurveSettingsProviderTestObjectBuilder().WithPriceCurveSettings(priceCurveSettings)
                                                                               .Build();

            Dictionary<int, PriceCurveSetting> result = null;

            using (testObjects.PriceCurveSettingsProvider.PriceCurveSettings.Subscribe(r => result = r))
            {
                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
                Assert.That(result[101].PriceCurveDefinitionId, Is.EqualTo(101));
                Assert.That(result[102].PriceCurveDefinitionId, Is.EqualTo(102));
            }
        }

        [Test]
        public void ShouldNotPublishPriceCurveSettingsUpdate_BeforeTickInterval()
        {
            var priceCurveSettings = new List<PriceCurveSetting>
            {
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build(),
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).WithPublisherId(10).Build()
            };

            var testObjects = new PriceCurveSettingsProviderTestObjectBuilder().WithPriceCurveSettings(priceCurveSettings)
                                                                               .Build();

            Dictionary<int, PriceCurveSetting> result = null;

            using (testObjects.PriceCurveSettingsProvider.PriceCurveSettings.Subscribe(r => result = r))
            {
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

                var update = new List<PriceCurveSetting>
                {
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(11).Build()
                };
                // ACT
                testObjects.PriceCurveSettings.OnNext(update);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
                Assert.That(result[101].PublisherId, Is.EqualTo(10));
            }
        }

        [Test]
        public void ShouldPublishPriceCurveSettingsUpdate_AfterTickInterval()
        {
            var priceCurveSettings = new List<PriceCurveSetting>
            {
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build(),
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).WithPublisherId(10).Build()
            };

            var testObjects = new PriceCurveSettingsProviderTestObjectBuilder().WithPriceCurveSettings(priceCurveSettings)
                                                                               .Build();

            Dictionary<int, PriceCurveSetting> result = null;

            using (testObjects.PriceCurveSettingsProvider.PriceCurveSettings.Subscribe(r => result = r))
            {
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

                var update = new List<PriceCurveSetting>
                {
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(11).Build()
                };
                
                testObjects.PriceCurveSettings.OnNext(update);

                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
                Assert.That(result[101].PublisherId, Is.EqualTo(11));
            }
        }

        [Test]
        public void ShouldBufferPriceCurveSettingsUpdates_ByTickInterval()
        {
            var priceCurveSettings = new List<PriceCurveSetting>
            {
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build(),
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).WithPublisherId(10).Build()
            };

            var testObjects = new PriceCurveSettingsProviderTestObjectBuilder().WithPriceCurveSettings(priceCurveSettings)
                                                                               .Build();

            Dictionary<int, PriceCurveSetting> result = null;

            var count = 0;

            using (testObjects.PriceCurveSettingsProvider.PriceCurveSettings.Subscribe(r =>
            {
                result = r;
                count++;
            }))
            {
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

                var update1 = new List<PriceCurveSetting>
                {
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(11).Build()
                };

                var update2 = new List<PriceCurveSetting>
                {
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(103).WithPublisherId(12).Build()
                };

                testObjects.PriceCurveSettings.OnNext(update1);
                testObjects.PriceCurveSettings.OnNext(update2);

                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(3));
                Assert.That(result[101].PublisherId, Is.EqualTo(11));
                Assert.That(result[103].PublisherId, Is.EqualTo(12));
                Assert.That(count, Is.EqualTo(3));
            }
        }
    }
}
