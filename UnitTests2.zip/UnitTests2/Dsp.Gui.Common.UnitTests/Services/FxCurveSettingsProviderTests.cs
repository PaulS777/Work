﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    public interface IFxCurveSettingsProviderTestObjects
    {
        TestScheduler TestScheduler { get; }
        ISubject<IList<FxCurveSetting>> FxCurveSettings { get; }
        FxCurveSettingsProvider FxCurveSettingsProvider { get; }
    }

    [TestFixture]
    public class FxCurveSettingsProviderTests
    {
        private class FxCurveSettingsProviderTestObjectBuilder
        {
            private IList<FxCurveSetting> _fxCurveSettings;

            public FxCurveSettingsProviderTestObjectBuilder WithFxCurveSettings(IList<FxCurveSetting> values)
            {
                _fxCurveSettings = values;
                return this;
            }

            public IFxCurveSettingsProviderTestObjects Build()
            {
                var testObjects = new Mock<IFxCurveSettingsProviderTestObjects>();

                var scheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(scheduler);

                var fxCurveSettings = new BehaviorSubject<IList<FxCurveSetting>>(_fxCurveSettings);

                testObjects.SetupGet(o => o.FxCurveSettings).Returns(fxCurveSettings);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.FxCurveSettings)
                                   .Returns(fxCurveSettings);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(scheduler);

                var fxCurveSettingsProvider = new FxCurveSettingsProvider(curveControlService.Object,
                                                                          schedulerProvider.Object,
                                                                          Mocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.FxCurveSettingsProvider)
                           .Returns(fxCurveSettingsProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishFxCurveSettings_OnTickInterval()
        {
            var fxCurveSettings = new FxCurveSetting[]
            {
                new(101, 10, 1.0, true, true),
                new(102, 10, 1.0, true, true)
            };

            var testObjects = new FxCurveSettingsProviderTestObjectBuilder().WithFxCurveSettings(fxCurveSettings)
                                                                            .Build();

            IList<FxCurveSetting> result = null;

            using (testObjects.FxCurveSettingsProvider.FxCurveSettings.Subscribe(r => result = r))
            {
                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldNotPublishFxCurveSettings_BeforeTickInterval()
        {
            var fxCurveSettings = new FxCurveSetting[]
            {
                new(101, 10, 1.0, true, true),
                new(102, 10, 1.0, true, true)
            };

            var testObjects = new FxCurveSettingsProviderTestObjectBuilder().WithFxCurveSettings(fxCurveSettings)
                                                                            .Build();

            IList<FxCurveSetting> result = null;

            using (testObjects.FxCurveSettingsProvider.FxCurveSettings.Subscribe(r => result = r))
            {
                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(10).Ticks);

                // ASSERT
                Assert.IsNull(result);
            }
        }
    }
}
