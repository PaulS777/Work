﻿using System;
using System.Reactive.Subjects;
using Dsp.Gui.Common.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    public interface ICurrentBusinessDateProviderTestObjects
    {
        ISubject<DateTime?> SystemDate { get; }
        CurrentBusinessDateProvider CurrentBusinessDateProvider { get; }
    }

    [TestFixture]
    public class CurrentBusinessDateProviderTests
    {
        private class CurrentBusinessDateProviderTestObjectBuilder
        {
            private DateTime? _systemDate;

            public CurrentBusinessDateProviderTestObjectBuilder WithSystemDate(DateTime? value)
            {
                _systemDate = value;
                return this;
            }

            public ICurrentBusinessDateProviderTestObjects Build()
            {
                var testObjects = new Mock<ICurrentBusinessDateProviderTestObjects>();

                var systemDate = new BehaviorSubject<DateTime?>(_systemDate);

                testObjects.SetupGet(o => o.SystemDate)
                           .Returns(systemDate);

                var systemDateProvider = new Mock<ISystemDateProvider>();

                systemDateProvider.SetupGet(p => p.SystemDate)
                                  .Returns(systemDate);

                var currentBusinessDateProvider = new CurrentBusinessDateProvider(systemDateProvider.Object);

                testObjects.SetupGet(o => o.CurrentBusinessDateProvider)
                           .Returns(currentBusinessDateProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateCurrentBusinessDate_From_SystemDate()
        {
            var date = new DateTime(2023, 1, 1);

            var testObjects = new CurrentBusinessDateProviderTestObjectBuilder().Build();

            // ACT
            testObjects.SystemDate.OnNext(date);

            // ASSERT
            Assert.That(testObjects.CurrentBusinessDateProvider.CurrentDate, Is.EqualTo(date));
        }

        [Test]
        public void ShouldNotUpdateCurrentBusinessDate_When_Disposed()
        {
            var date = new DateTime(2023, 1, 1);

            var testObjects = new CurrentBusinessDateProviderTestObjectBuilder().Build();

            testObjects.CurrentBusinessDateProvider.Dispose();

            // ACT
            testObjects.SystemDate.OnNext(date);

            // ASSERT
            Assert.That(testObjects.CurrentBusinessDateProvider.CurrentDate, Is.EqualTo(DateTime.MinValue));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var date = new DateTime(2023, 1, 1);

            var testObjects = new CurrentBusinessDateProviderTestObjectBuilder().Build();

            testObjects.CurrentBusinessDateProvider.Dispose();

            // ACT
            testObjects.CurrentBusinessDateProvider.Dispose();
            testObjects.SystemDate.OnNext(date);

            // ASSERT
            Assert.That(testObjects.CurrentBusinessDateProvider.CurrentDate, Is.EqualTo(DateTime.MinValue));
        }
    }
}
