﻿using System.Collections.Generic;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Services
{
    [TestFixture]
    public class PricingFailureParserTests
    {
        [Test]
        public void ShouldParseAnchorPointPricingFailures()
        {
            var curveLookup = new Dictionary<LinkedCurve, string>();

            var reason = "failed";

            var anchorPointFailure = new PricingFailure(0, 0, PricingFailureReason.AnchorPointTenorReferenceNotFound,
                new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve), reason);

            var gapBetweenTenorsFailure = new PricingFailure(0, 0, PricingFailureReason.GapBetweenTenors,
                new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve), reason);

            var duplicateTenorsFailure = new PricingFailure(0, 0, PricingFailureReason.DuplicateTenors,
                new LinkedCurve(103, PriceCurveDefinitionType.DerivedCurve), reason);

            var dependencyFailure = new PricingFailure(0, 0, PricingFailureReason.DependencyFailure,
                new LinkedCurve(102, PriceCurveDefinitionType.DerivedCurve), reason);

            var pricingFailures = new List<PricingFailure>
            {
                anchorPointFailure, gapBetweenTenorsFailure, duplicateTenorsFailure, dependencyFailure
            };

            var parser = new PricingFailureParser();

            // ACT
            var result = parser.TryParsePricingFailures(curveLookup, pricingFailures, out var messages);

            // ASSERT
            Assert.IsTrue(result);
            Assert.AreEqual(3, messages.Length);
        }

        [Test]
        public void ShouldReturnFalse_WhenPricingFailuresNull()
        {
            var curveLookup = new Dictionary<LinkedCurve, string>();

            var parser = new PricingFailureParser();

            // ACT
            var result = parser.TryParsePricingFailures(curveLookup, null, out var messages);

            // ASSERT
            Assert.IsFalse(result);
            Assert.AreEqual(0, messages.Length);
        }
    }
}
