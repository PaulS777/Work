﻿using System;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests
{
    [TestFixture]
    public class TransactionContextStateManagerTests
    {
        [Test]
        public void ShouldTakeStateOwnership_With_IsUpdatingTrue_When_HasOwnerFalse()
        {
            var state = new TransactionContextState();

            // ACT
            using (new TransactionContextStateManager(state))
            {
                // ASSERT
                Assert.IsTrue(state.IsUpdating);
                Assert.IsTrue(state.HasOwner);
            }
        }

        [Test]
        public void ShouldReleaseState_With_IsUpdatingFalse_When_Disposed()
        {
            var state = new TransactionContextState();

            using (new TransactionContextStateManager(state))
            {
                // ACT
            }

            // ASSERT
            Assert.IsFalse(state.IsUpdating);
            Assert.IsFalse(state.HasOwner);
        }

        [Test]
        public void ShouldThrowException_When_HasOwnerTrue()
        {
            var result = false;

            var state = new TransactionContextState();

            try
            {
                using (new TransactionContextStateManager(state))
                {
                    // ACT
                    using (new TransactionContextStateManager(state))
                    {

                    }
                }
            }
            catch (InvalidOperationException)
            {
                result = true;
            }

            // ASSERT
            Assert.IsTrue(result);
        }
    }
}
