﻿using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests
{
    [TestFixture]
    public class CollectionEqualityComparerUnitTests
    {
        [Test]
        public void ShouldReturnTrue_When_Matching_ValuesInSequence()
        {
            var array1 = new[] { 1, 2, 3 };
            var array2 = new[] { 1, 2, 3 };

            var comparer = new CollectionEqualityComparer<int>();

            // ACT
            var result = comparer.Equals(array1, array2);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_SameCollection()
        {
            var array1 = new[] { 1, 2, 3 };

            var comparer = new CollectionEqualityComparer<int>();

            // ACT
            var result = comparer.Equals(array1, array1);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_Matching_ValuesNotInSequence()
        {
            var array1 = new[] { 1, 2, 3 };
            var array2 = new[] { 1, 3, 2 };

            var comparer = new CollectionEqualityComparer<int>();

            // ACT
            var result = comparer.Equals(array1, array2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_FirstCollectionNull()
        {
            var array1 = new[] { 1, 2, 3 };

            var comparer = new CollectionEqualityComparer<int>();

            // ACT
            var result = comparer.Equals(null, array1);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_SecondCollectionNull()
        {
            var array1 = new[] { 1, 2, 3 };

            var comparer = new CollectionEqualityComparer<int>();

            // ACT
            var result = comparer.Equals(array1, null);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnDifferentHash_When_ItemsSameValueValuesDifferentSequence()
        {
            var array1 = new[] { 1, 2, 3 };
            var array2 = new[] { 1, 3, 2 };


            var comparer = new CollectionEqualityComparer<int>();

            // ACT
            var result1 = comparer.GetHashCode(array1);
            var result2 = comparer.GetHashCode(array2);


            // ASSERT
            Assert.That(result1, Is.Not.EqualTo(result2));
        }
    }
}
