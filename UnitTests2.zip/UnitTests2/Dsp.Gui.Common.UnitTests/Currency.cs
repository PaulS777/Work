﻿using System;

namespace Dsp.Gui.Common.UnitTests
{
    public static class Currency
    {
        public const int USD = 1;
        public const int EUR = 2;
        public const int GBP = 3;
        public const int CHF = 4;
        public const int CAD = 5;
        public const int ZAR = 6;

        public static string AsString(int currency)
        {
            switch (currency)
            {
                case USD: return nameof(USD);
                case EUR: return nameof(EUR);
                case GBP: return nameof(GBP);
                case CHF: return nameof(CHF);
                case CAD: return nameof(CAD);
                case ZAR: return nameof(ZAR);
                default: throw new Exception("Invalid currency id");
            }
        }
    }

    public static class FxCurveIds
    {
        public const int EurUsd = 21;
        public const int GbpUsd = 22;
        public const int UsdChf = 23;
        public const int UsdCad = 24;
        public const int ChfUsd = 9023;
        public const int CadUsd = 9024;
        public const int UsdZar = 9025;
        public const int ZarUsd = 9026;
    }
}