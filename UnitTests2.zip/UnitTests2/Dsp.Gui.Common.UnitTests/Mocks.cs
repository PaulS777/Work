﻿using System;
using System.Reactive.Concurrency;
using Dsp.Gui.Common.Services;
using Dsp.ServiceContracts;
using Moq;

namespace Dsp.Gui.Common.UnitTests
{
    public static class Mocks
    {
        public static Mock<ILoggerFactory> GetLoggerFactory()
        {
            var logger = new Mock<ILogger>();

            var loggerFactory = new Mock<ILoggerFactory>();
            loggerFactory.Setup(f => f.Create(It.IsAny<Type>())).Returns(logger.Object);
            loggerFactory.Setup(f => f.Create(It.IsAny<string>())).Returns(logger.Object);

            return loggerFactory;
        }

        public static Mock<ILoggerFactory> GetLoggerFactory(Mock<ILogger> logger)
        {
            var loggerFactory = new Mock<ILoggerFactory>();
            loggerFactory.Setup(f => f.Create(It.IsAny<Type>())).Returns(logger.Object);
            loggerFactory.Setup(f => f.Create(It.IsAny<string>())).Returns(logger.Object);

            return loggerFactory;
        }

        public static Mock<ISchedulerProvider> GetSchedulerProvider()
        {
            var schedulerProvider = new Mock<ISchedulerProvider>();
            schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
            schedulerProvider.SetupGet(p => p.TaskPool).Returns(Scheduler.Immediate);
            schedulerProvider.SetupGet(p => p.Immediate).Returns(Scheduler.Immediate);

            return schedulerProvider;
        }
    }
}
