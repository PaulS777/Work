﻿using Dsp.DataContracts;
using Dsp.Gui.Common.Extensions;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Extensions
{
    [TestFixture]
    public class TenorExtensionsTests
    {
        [Test]
        public void ShouldGetTenorValue_From_AnnualTenor()
        {
            var tenor = new AnnualTenor("2020");

            var value = tenor.GetTenorValue();

            Assert.AreEqual(20200000, value);
        }

        [Test]
        public void ShouldGetTenorValue_From_QuarterlyTenor()
        {
            var tenor = new QuarterlyTenor(2020, 3);

            var value = tenor.GetTenorValue();

            Assert.AreEqual(20200300, value);
        }

        [Test]
        public void ShouldGetTenorValue_From_MonthlyTenor()
        {
            var tenor = new MonthlyTenor(2020, 9);

            var value = tenor.GetTenorValue();

            Assert.AreEqual(20200309, value);
        }

        [TestCase(1, 1)]
        [TestCase(2, 1)]
        [TestCase(3, 1)]
        [TestCase(4, 2)]
        [TestCase(5, 2)]
        [TestCase(6, 2)]
        [TestCase(7, 3)]
        [TestCase(8, 3)]
        [TestCase(9, 3)]
        [TestCase(10, 4)]
        [TestCase(11, 4)]
        [TestCase(12, 4)]
        public void ShouldGetQuarter_ForMonthlyTenor(int month, int expected)
        {
            var tenor = new MonthlyTenor(2020, month);

            var quarter = tenor.GetQuarter();

            Assert.AreEqual(expected, quarter);
        }
    }
}