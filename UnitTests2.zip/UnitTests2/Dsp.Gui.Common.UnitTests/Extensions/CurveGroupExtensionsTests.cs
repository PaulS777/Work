﻿using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Extensions;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Extensions
{
	[TestFixture]
	public class CurveGroupExtensionsTests
	{
        [Test]
        public void ShouldReturnTrue_When_IsCrude_With_CurveGroupNameCrude()
        {
            var curveGroup = new CurveGroup(1, CurveGroupNames.Crude, string.Empty, false);

            // ACT
            var result = curveGroup.IsCrude();

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_IsCrude_With_CurveGroupNameNotCrude()
        {
            var curveGroup = new CurveGroup(1, CurveGroupNames.FuelOil, string.Empty, false);

            // ACT
            var result = curveGroup.IsCrude();

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnTrue_When_IsFx_With_CurveGroupNameFx()
        {
            var curveGroup = new CurveGroup(1, CurveGroupNames.Fx, string.Empty, false);

            // ACT
            var result = curveGroup.IsFx();

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_IsFx_With_CurveGroupNameNotFx()
        {
            var curveGroup = new CurveGroup(1, CurveGroupNames.FuelOil, string.Empty, false);

            // ACT
            var result = curveGroup.IsFx();

            // ASSERT
            Assert.That(result, Is.False);
        }
	}
}
