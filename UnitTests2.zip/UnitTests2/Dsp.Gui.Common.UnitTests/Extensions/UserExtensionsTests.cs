﻿using Dsp.DataContracts;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Extensions
{
    [TestFixture]
	public class UserExtensionsTests
	{
        [Test]
        public void ShouldReturnTrue_When_IsEomRoll_With_EomRollPermission()
        {
			var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.EomRoll.ToString(), 0, true)])
                                        .User();

			// ACT
            var result = user.IsEomRoll();

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_IsBetaUser_With_BetaUserPermission()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.BetaUser.ToString(), 0, true)])
                                        .User();

            // ACT
            var result = user.IsBetaUser();

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_IsCurveAdmin_With_CurveAdminPermission()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 0, true)])
                                        .User();

            // ACT
            var result = user.IsCurveAdmin();

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_IsCurveAdminApprover_With_CurveAdminApproverPermission()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 0, true)])
                                        .User();

            // ACT
            var result = user.IsCurveAdminApprover();

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_IsFxPublisher_With_FxCurveUpdatePermission()
        {
			var fxCurvePermissions = new[] { new AuthorisationFxCurve(99, true, true) };

            var user = new UserBuilder().WithAuthorizationFxCurve(fxCurvePermissions)
                                        .User();

			// ACT
			var result = user.IsFxPublisher();

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_IsFxPublisher_With_FxCurveReadOnlyPermission()
        {
            var fxCurvePermissions = new[] { new AuthorisationFxCurve(99, true, false) };

            var user = new UserBuilder().WithAuthorizationFxCurve(fxCurvePermissions)
                                        .User();

            // ACT
            var result = user.IsFxPublisher();

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnTrue_When_IsCrudeReader_With_CrudeReadPermission()
        {
            var curveGroups = new[] { new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), true, false) };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();
            
            // ACT
            var result = user.IsCrudeReader();

            // ASSERT
            Assert.That(result, Is.True);
        }


        [Test]
        public void ShouldReturnFalse_When_IsCrudeReader_With_MissingCrudeReadPermission()
        {
            var curveGroups = new[] { new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().MoGas(), true, true) };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

            // ACT
            var result = user.IsCrudeReader();

            // ASSERT
            Assert.That(result, Is.False);
        }
	}
}
