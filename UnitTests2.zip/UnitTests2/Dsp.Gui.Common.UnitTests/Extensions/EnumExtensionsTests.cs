﻿using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests.Extensions
{
    [TestFixture]
    public class EnumExtensionsTests
    {
        [Test]
        public void ShouldReturnTrueWhenEnumIsInCurveGroups()
        {
            var state = SystemRunConnectState.Connected;

            // ACT
            var result = state.In(SystemRunConnectState.Reconnected, SystemRunConnectState.Connected);

            // ASSERT
            Assert.That(result, Is.True);
        }
        [Test]
        public void ShouldReturnFalseWhenEnumIsNotCurveGroups()
        {
            var state = SystemRunConnectState.FailedStartup;

			// ACT
			var result = state.In(SystemRunConnectState.Reconnected, SystemRunConnectState.Connected);

			// ASSERT
			Assert.That(result, Is.False);
        }
    }
}
