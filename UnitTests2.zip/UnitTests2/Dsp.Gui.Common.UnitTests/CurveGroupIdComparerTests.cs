﻿using Dsp.DataContracts.Curve;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests
{
	[TestFixture]
	public class CurveGroupIdComparerTests
	{
        [Test]
        public void ShouldReturnTrue_When_Matching_GroupId()
        {
            var curveGroup1 = new CurveGroup(1, "name", string.Empty, false);
            var curveGroup2 = new CurveGroup(1, "name", string.Empty, false);

            var comparer = new CurveGroupIdComparer();

            // ACT
            var result = comparer.Equals(curveGroup1, curveGroup2);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_SameReference()
        {
            var curveGroup = new CurveGroup(1, "name", string.Empty, false);

            var comparer = new CurveGroupIdComparer();

            // ACT
            var result = comparer.Equals(curveGroup, curveGroup);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnTrue_When_NonMatching_GroupId()
        {
            var curveGroup1 = new CurveGroup(1, "name", string.Empty, false);
            var curveGroup2 = new CurveGroup(2, "name", string.Empty, false);

            var comparer = new CurveGroupIdComparer();

            // ACT
            var result = comparer.Equals(curveGroup1, curveGroup2);

            // ASSERT
            Assert.That(result, Is.False);
        }

		[Test]
        public void ShouldReturnFalse_When_SecondCurveIsNull()
        {
            var curveGroup = new CurveGroup(1, "name", string.Empty, false);

            var comparer = new CurveGroupIdComparer();

            // ACT
            var result = comparer.Equals(curveGroup, null);

            // ASSERT
            Assert.That(result, Is.False);
		}

		[Test]
        public void ShouldReturnFalse_When_FirstCurveIsNull()
        {
            var curveGroup = new CurveGroup(1, "name", string.Empty, false);

            var comparer = new CurveGroupIdComparer();

            // ACT
            var result = comparer.Equals(null, curveGroup);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnSameHashCodes_When_Matching_GroupId()
        {
            var curveGroup1 = new CurveGroup(5, "name", string.Empty, false);
            var curveGroup2 = new CurveGroup(5, "name", string.Empty, false);

            var comparer = new CurveGroupIdComparer();

            // ACT
            var result1 = comparer.GetHashCode(curveGroup1);
            var result2 = comparer.GetHashCode(curveGroup2);

			// ASSERT
			Assert.That(result1, Is.EqualTo(result2));
        }
	}
}
