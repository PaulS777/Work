﻿using System.Collections.Generic;
using NUnit.Framework;

namespace Dsp.Gui.Common.UnitTests
{
    [TestFixture]
    public class DictionaryEqualityComparerTests
    {
        [Test]
        public void ShouldReturnTrue_When_Matching_Keys_And_Values()
        {
            var dictionary1 = new Dictionary<int, string>
                              {
                                  { 1, "AAA" }, { 2, "BBB" }, { 3, "CCC" }
                              };

            var dictionary2 = new Dictionary<int, string>
                              {
                                  { 1, "AAA" }, { 2, "BBB" }, { 3, "CCC" }
                              };

            var comparer = new DictionaryEqualityComparer<int, string>();

            // ACT
            var result = comparer.Equals(dictionary1, dictionary2);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Matching_Keys_And_NonMatching_Values()
        {
            var dictionary1 = new Dictionary<int, string>
                              {
                                  { 1, "AAA" }, { 2, "BBB" }, { 3, "CCC" }
                              };

            var dictionary2 = new Dictionary<int, string>
                              {
                                  { 1, "AAA" }, { 2, "BBB" }, { 3, "XXX" }
                              };

            var comparer = new DictionaryEqualityComparer<int, string>();

            // ACT
            var result = comparer.Equals(dictionary1, dictionary2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_NonMatching_Keys()
        {
            var dictionary1 = new Dictionary<int, string>
                              {
                                  { 1, "AAA" }, { 2, "BBB" }, { 3, "CCC" }
                              };

            var dictionary2 = new Dictionary<int, string>
                              {
                                  { 1, "AAA" }, { 2, "BBB" }, { 99, "CCC" }
                              };

            var comparer = new DictionaryEqualityComparer<int, string>();

            // ACT
            var result = comparer.Equals(dictionary1, dictionary2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_NonMatching_Count()
        {
            var dictionary1 = new Dictionary<int, string>
                              {
                                  { 1, "AAA" }, { 2, "BBB" }, { 3, "CCC" }
                              };

            var dictionary2 = new Dictionary<int, string>
                              {
                                  { 1, "AAA" }, { 2, "BBB" }
                              };

            var comparer = new DictionaryEqualityComparer<int, string>();

            // ACT
            var result = comparer.Equals(dictionary1, dictionary2);

            // ASSERT
            Assert.That(result, Is.False);
        }
    }
}
