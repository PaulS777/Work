﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Dashboard.Common.Settings;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests
{
    [ExcludeFromCodeCoverage]
    internal class BindingListItemSettingComparer : IEqualityComparer<BindingListItemSetting>
    {
        public bool Equals(BindingListItemSetting x, BindingListItemSetting y)
        {
            if (ReferenceEquals(x, y)) 
                return true;
            if (ReferenceEquals(x, null))
                return false;
            if (ReferenceEquals(y, null)) 
                return false;
            if (x.GetType() != y.GetType())
                return false;

            return x.CurveId == y.CurveId && x.Tenor == y.Tenor;
        }

        public int GetHashCode(BindingListItemSetting obj)
        {
            return HashCode.Combine(obj.CurveId, obj.Tenor);
        }
    }
}
