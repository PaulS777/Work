﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Dsp.Gui.Markets.Common.ViewModels.Price;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests
{
    [ExcludeFromCodeCoverage]
    internal class PriceValueBindingListComparer : IEqualityComparer<BindingList<PriceValue>>
    {
        public bool Equals(BindingList<PriceValue> x, BindingList<PriceValue> y)
        {
            if (ReferenceEquals(x, y))
                return true;
            
            if (ReferenceEquals(x, null))
                return false;
            
            if (ReferenceEquals(y, null))
                return false;

            return x.SequenceEqual(y, new PriceValueReferenceComparer());

        }

        public int GetHashCode(BindingList<PriceValue> obj)
        {
            throw new NotSupportedException();
        }

        private class PriceValueReferenceComparer : IEqualityComparer<PriceValue>
        {
            public bool Equals(PriceValue x, PriceValue y)
            {
                if (ReferenceEquals(x, null))
                {
                    return false;
                }

                if (ReferenceEquals(y, null))
                {
                    return false;
                }

                return ReferenceEquals(x, y);
            }

            public int GetHashCode(PriceValue obj)
            {
                throw new NotSupportedException();
            }
        }
    }
}
