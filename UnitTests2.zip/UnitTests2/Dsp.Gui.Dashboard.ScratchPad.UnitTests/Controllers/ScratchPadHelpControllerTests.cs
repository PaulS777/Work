﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using System.Windows;
using DevExpress.Spreadsheet;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Dashboard.ScratchPad.Controllers;
using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Services.ScratchPad;
using Moq;
using NUnit.Framework;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.ScratchPad.ViewModels;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid.Model;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using Dsp.Gui.UnitTest.Helpers.Extensions;
using Dsp.Gui.Dashboard.ToolBar.Info.Services;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Controllers
{
    internal interface IScratchPadHelpControllerTestObjects
    {
        ScratchPadHelpViewModel ViewModel { get; }
        IScratchPadHelpController Controller { get; }
    }

    [TestFixture]
    public class ScratchPadHelpControllerTests
    {
        private class ScratchPadHelpControllerTestObjectBuilder
        {
            private Uri _helpUrl;

            public ScratchPadHelpControllerTestObjectBuilder WithHelpUrl(string value)
            {
                _helpUrl = string.IsNullOrWhiteSpace(value) ? null : new Uri(value);
                return this;
            }

            public IScratchPadHelpControllerTestObjects Build()
            {
                var testObjects = new Mock<IScratchPadHelpControllerTestObjects>();

                var releaseNotesUriProvider = new Mock<IReleaseNotesUriProvider>();

                releaseNotesUriProvider.SetupGet(p => p.ScratchPadHelpUri)
                                       .Returns(_helpUrl);

                var controller = new ScratchPadHelpController(releaseNotesUriProvider.Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetDisplayUri_On_ShowHelpTrue()
        {
            var testObjects = new ScratchPadHelpControllerTestObjectBuilder().WithHelpUrl("http://info/help.html")
                                                                             .Build();

            // ACT
            testObjects.ViewModel.ShowHelp = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.DisplayUri.AbsoluteUri, Is.EqualTo("http://info/help.html"));
        }

        [Test]
        public void ShouldNotSetDisplayUri_On_ShowHelpTrue_With_HelpUriNull()
        {
            var testObjects = new ScratchPadHelpControllerTestObjectBuilder().WithHelpUrl(null)
                                                                             .Build();

            // ACT
            testObjects.ViewModel.ShowHelp = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.DisplayUri, Is.Null);
        }

        [Test]
        public void ShouldSetShowHelpFalse_On_CloseHelpCommand()
        {
            var testObjects = new ScratchPadHelpControllerTestObjectBuilder().WithHelpUrl("http://info/help.html")
                                                                             .Build();

            // ARRANGE
            testObjects.ViewModel.ShowHelp = true;

            // ACT
            testObjects.ViewModel.CloseHelpCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowHelp, Is.False);
        }

        [Test]
        public void ShouldNotSetDisplayUri_When_Disposed()
        {
            var testObjects = new ScratchPadHelpControllerTestObjectBuilder().WithHelpUrl("http://info/help.html")
                                                                             .Build();
        
            // ARRANGE
            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.ShowHelp = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.DisplayUri, Is.Null);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ScratchPadHelpControllerTestObjectBuilder().WithHelpUrl("http://info/help.html")
                                                                             .Build();

            // ARRANGE
            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.ShowHelp = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.DisplayUri, Is.Null);
        }
    }
}
