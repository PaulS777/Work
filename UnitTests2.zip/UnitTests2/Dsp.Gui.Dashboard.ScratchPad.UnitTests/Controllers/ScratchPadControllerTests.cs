﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using System.Windows;
using DevExpress.Spreadsheet;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Dashboard.ScratchPad.Controllers;
using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Services.ScratchPad;
using Moq;
using NUnit.Framework;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.ScratchPad.ViewModels;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid.Model;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using Dsp.Gui.UnitTest.Helpers.Extensions;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Controllers
{
    internal interface IScratchPadControllerTestObjects
    {
        ITenorPriceRowDataSource DataSource { get; }
        IScratchPadPriceCurvesService ScratchPadPriceCurvesService { get; }
        IScratchPadClipboard ScratchPadClipboard { get; }
        IScratchPadBindingsCache ScratchPadBindingsCache { get; }
        IDashboardSettingsReader DashboardSettingsReader { get; }
        ISubject<bool> DashboardSettingsLoaded { get; }
        IBoundPriceCellsColumnLookupReader BoundPriceCellsColumnLookup { get; }
        IImportPriceCellsService ImportPriceCellsService { get; }
        IImportTenorCellsService ImportTenorCellsService { get; }
        IScratchPadSettingsRestorationService ScratchPadSettingsRestorationService { get; }
        IRemovePriceCurveBindingsService RemovePriceCurveBindingsService { get; }
        IWorksheetBindingUpdateService WorksheetBindingUpdateService { get; }
        IWorksheetClearCellsUpdateService WorksheetClearCellsUpdateService { get; }
        IScratchPadFormatSettingsService ScratchPadFormatSettingsService { get; }
        IPasteImportPriceCellsService PasteImportPriceCellsService { get; }
        IPasteExtendTenorsService PasteExtendTenorsService { get; }
        IColumnShiftService ColumnShiftService { get; }
        IInsertRowsService InsertRowsService { get; }
        IRemoveRowsService RemoveRowsService { get; }
        IMergeColumnCellRangesService MergeColumnCellRangesService { get; }
        IClearBindingsService ClearBindingsService { get; }
        IRemoveColumnsBindingUpdateService RemoveColumnsBindingUpdateService { get; }
        ISubject<Dictionary<LinkedCurve, List<TenorPriceCell>>> PriceCurves { get; }
        ISubject<bool> IsLoading { get; }
        ISubject<Unit> ClearBindings { get; }
        ISubject<Unit> RestoreBindings { get; }
        Dictionary<LinkedCurve, List<TenorPriceCell>> DefaultPriceCurves { get; }
        ISubject<bool> ClipboardHasPrices { get; }
        IScratchPadMessageDialogService MessageDialogService { get; }
        ScratchPadViewModel ViewModel { get; }
        ScratchPadController Controller { get; }
    }

    [TestFixture]
    public class ScratchPadControllerTests
    {
        private delegate void MockCallback(IList<int> curveIds,
                                           Dictionary<ColumnCellRange, IList<TenorPriceCell>> boundPriceCells,
                                           out PriceCellRangeBindingsUpdate priceCellRangeBindingsUpdate);

        private class ScratchPadControllerTestObjectBuilder
        {
            private int? _pageNumber;
            private bool _hasFormatSettings;
            private string _formatSettingsPath;
            private IList<TenorPriceRowViewModel> _dataSourceItems = new List<TenorPriceRowViewModel>();
            private IList<List<TenorPriceCell>> _clipboardPriceCells;
            private List<IList<TenorPriceCell>> _pasteImportPriceCells;
            private IList<ITenor> _clipboardTenors;
            private IList<string> _clipboardHeaders;
            private Dictionary<ColumnCellRange, IList<TenorPriceCell>> _boundPriceCellColumns;
            private Dictionary<CellPoint, IList<TenorPriceCell>> _boundPriceCells;
            private Dictionary<ColumnCellRange, IList<TenorPriceCell>> _bindingsCacheUpdate;
            private WorksheetTenorsUpdate _importWorksheetTenorsUpdate;
            private WorksheetTenorsUpdate _pasteWorksheetTenorsUpdate;
            private PriceCellRangeBindingsUpdate _importPriceCellsBindingsUpdate;
            private PriceCellRangeBindingsUpdate _shiftColumnsBindingsUpdate;
            private PriceCellRangeBindingsUpdate _shiftedRowsResult;
            private PriceCellRangeBindingsUpdate _splitRowsResult;
            private PriceCellRangeBindingsUpdate _removeRowsResult;
            private PriceCellRangeBindingsUpdate _mergeColumnCellRangesResult;
            private bool _dashboardSettingsLoaded;
            private DashboardSettings _dashboardSettings = new();
            private Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>> _restoredPriceCells = new();
            private PriceCellRangeBindingsUpdate _clearBindingsUpdate;
            private Dictionary<int, List<WorksheetDataBinding>> _worksheetDataBindings;
            private Dictionary<LinkedCurve, List<TenorPriceCell>> _priceCurves;
            private WorksheetDataBindingsUpdate _worksheetBindingsUpdate;
            private WorksheetDataBindingsUpdate _removeColumnBindingsUpdate;
            private bool _tryGetRemovePriceCurveBindingUpdate;
            private PriceCellRangeBindingsUpdate _removePriceCurveBindingUpdate;
            private WorksheetClearCellsUpdate _worksheetClearCellsUpdate;
            private Exception _dashboardSettingsException;
            private Exception _importPriceCellsException;
            private Exception _columnShiftException;
            private Exception _insertRowsException;
            private Exception _removeRowsException;
            private Exception _removeWorksheetException;
            private Exception _removeColumnsException;
            private Exception _clearBindingsException;
            private Exception _pasteExtendTenorsException;

            public ScratchPadControllerTestObjectBuilder WithInitialized(int? value)
            {
                _pageNumber = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithHasFormatSettings(bool value)
            {
                _hasFormatSettings = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithFormatSettingsPath(string value)
            {
                _formatSettingsPath = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithDataSourceItems(IList<TenorPriceRowViewModel> values)
            {
                _dataSourceItems = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithClipboardPriceCells(IList<List<TenorPriceCell>> values)
            {
                _clipboardPriceCells = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithPasteImportPriceCells(List<IList<TenorPriceCell>> values)
            {
                _pasteImportPriceCells = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithClipboardTenors(IList<ITenor> values)
            {
                _clipboardTenors = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithClipboardHeaders(IList<string> values)
            {
                _clipboardHeaders = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithBoundPriceCellColumns(Dictionary<ColumnCellRange, IList<TenorPriceCell>> values)
            {
                _boundPriceCellColumns = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithBoundPriceCells(Dictionary<CellPoint, IList<TenorPriceCell>> values)
            {
                _boundPriceCells = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithBindingsCacheUpdate(Dictionary<ColumnCellRange, IList<TenorPriceCell>> values)
            {
                _bindingsCacheUpdate = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithImportWorksheetTenorsUpdate(WorksheetTenorsUpdate value)
            {
                _importWorksheetTenorsUpdate = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithPasteWorksheetTenorsUpdate(WorksheetTenorsUpdate value)
            {
                _pasteWorksheetTenorsUpdate = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithImportPriceCellsBindingsUpdate(PriceCellRangeBindingsUpdate value)
            {
                _importPriceCellsBindingsUpdate = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithShiftColumnsBindingsUpdate(PriceCellRangeBindingsUpdate value)
            {
                _shiftColumnsBindingsUpdate = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithShiftedRowsResult(PriceCellRangeBindingsUpdate value)
            {
                _shiftedRowsResult = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithSplitRowsResult(PriceCellRangeBindingsUpdate value)
            {
                _splitRowsResult = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithRemoveRowsResult(PriceCellRangeBindingsUpdate value)
            {
                _removeRowsResult = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithMergeColumnCellRangesResult(PriceCellRangeBindingsUpdate value)
            {
                _mergeColumnCellRangesResult = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithClearBindingsUpdate(PriceCellRangeBindingsUpdate value)
            {
                _clearBindingsUpdate = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithDashboardSettingsLoaded(bool value)
            {
                _dashboardSettingsLoaded = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithDashboardSettings(DashboardSettings value)
            {
                _dashboardSettings = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithRestoredPriceCells(Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>> values)
            {
                _restoredPriceCells = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithWorksheetDataBindings(Dictionary<int, List<WorksheetDataBinding>> values)
            {
                _worksheetDataBindings = values;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithPriceCurves(Dictionary<LinkedCurve, List<TenorPriceCell>> value)
            {
                _priceCurves = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithWorksheetBindingUpdate(WorksheetDataBindingsUpdate value)
            {
                _worksheetBindingsUpdate = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithRemoveColumnBindingUpdate(WorksheetDataBindingsUpdate value)
            {
                _removeColumnBindingsUpdate = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithTryGetRemovePriceCurveBindingUpdate(bool value,
                                                                                                 PriceCellRangeBindingsUpdate update)
            {
                _tryGetRemovePriceCurveBindingUpdate = value;
                _removePriceCurveBindingUpdate = update;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithWorksheetClearCellsUpdate(WorksheetClearCellsUpdate value)
            {
                _worksheetClearCellsUpdate = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithDashboardSettingsException(Exception value)
            {
                _dashboardSettingsException = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithImportPriceCellsException(Exception value)
            {
                _importPriceCellsException = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithColumnShiftException(Exception value)
            {
                _columnShiftException = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithInsertRowsException(Exception value)
            {
                _insertRowsException = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithRemoveRowsException(Exception value)
            {
                _removeRowsException = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithRemoveWorksheetException(Exception value)
            {
                _removeWorksheetException = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithRemoveColumnsException(Exception value)
            {
                _removeColumnsException = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithClearBindingsException(Exception value)
            {
                _clearBindingsException = value;
                return this;
            }

            public ScratchPadControllerTestObjectBuilder WithPasteExtendTenorsException(Exception value)
            {
                _pasteExtendTenorsException = value;
                return this;
            }

            public IScratchPadControllerTestObjects Build()
            {
                var testObjects = new Mock<IScratchPadControllerTestObjects>();

                var dataSource = new Mock<ITenorPriceRowDataSource>();

                dataSource.Setup(d => d.Items())
                          .Returns(_dataSourceItems);

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var isLoading = new Subject<bool>();

                testObjects.SetupGet(o => o.IsLoading)
                           .Returns(isLoading);

                var clearBindings = new Subject<Unit>();

                testObjects.SetupGet(o => o.ClearBindings)
                           .Returns(clearBindings);

                var restoreBindings = new Subject<Unit>();

                testObjects.SetupGet(o => o.RestoreBindings)
                           .Returns(restoreBindings);

                var defaultPriceCurves = new Dictionary<LinkedCurve, List<TenorPriceCell>>();

                testObjects.SetupGet(o => o.DefaultPriceCurves)
                           .Returns(defaultPriceCurves);

                var priceCurves = new BehaviorSubject<Dictionary<LinkedCurve, List<TenorPriceCell>>>(_priceCurves);

                testObjects.SetupGet(o => o.PriceCurves)
                           .Returns(priceCurves);

                var priceCurvesService = new Mock<IScratchPadPriceCurvesService>();

                priceCurvesService.SetupGet(p => p.IsLoading)
                                  .Returns(isLoading);

                priceCurvesService.SetupGet(p => p.ClearBindings)
                                  .Returns(clearBindings);

                priceCurvesService.SetupGet(p => p.RestoreBindings)
                                  .Returns(restoreBindings);

                priceCurvesService.SetupGet(p => p.PriceCurves)
                                  .Returns(priceCurves);

                testObjects.SetupGet(o => o.ScratchPadPriceCurvesService)
                           .Returns(priceCurvesService.Object);

                var clipboardHasPrices = new Subject<bool>();

                testObjects.SetupGet(o => o.ClipboardHasPrices)
                           .Returns(clipboardHasPrices);

                var clipboard = new Mock<IScratchPadClipboard>();

                clipboard.SetupGet(c => c.HasPrices)
                         .Returns(clipboardHasPrices);

                clipboard.Setup(c => c.GetClipboardPrices())
                         .Returns(_clipboardPriceCells);

                clipboard.Setup(c => c.GetClipboardTenors())
                         .Returns(_clipboardTenors);

                clipboard.Setup(c => c.GetClipboardHeaders())
                         .Returns(_clipboardHeaders);

                testObjects.SetupGet(o => o.ScratchPadClipboard)
                           .Returns(clipboard.Object);

                var worksheetBindingUpdateService = new Mock<IWorksheetBindingUpdateService>();

                worksheetBindingUpdateService.Setup(b => b.GetWorksheetBindingUpdate(It.IsAny<int>(),
                                                                                     It.IsAny<PriceCellRangeBindingsUpdate>(),
                                                                                     It.IsAny<IEnumerable<WorksheetDataBinding>>()))
                                             .Returns(_worksheetBindingsUpdate);

                testObjects.SetupGet(o => o.WorksheetBindingUpdateService)
                           .Returns(worksheetBindingUpdateService.Object);

                var worksheetClearCellsUpdateService = new Mock<IWorksheetClearCellsUpdateService>();

                worksheetClearCellsUpdateService.Setup(c => c.GetWorksheetClearCellsUpdate(It.IsAny<int>(),
                                                                                           It.IsAny<int>(),
                                                                                           It.IsAny<int>(),
                                                                                           It.IsAny<Dictionary<CellPoint, IList<TenorPriceCell>>>()))
                                                .Returns(_worksheetClearCellsUpdate);

                testObjects.SetupGet(o => o.WorksheetClearCellsUpdateService)
                           .Returns(worksheetClearCellsUpdateService.Object);

                var boundPriceCellsColumnLookup = new Mock<IBoundPriceCellsColumnLookupReader>();

                boundPriceCellsColumnLookup.Setup(b => b.GetWorksheetBoundPriceCellsByColumnCellRange(It.IsAny<int>()))
                                           .Returns(_boundPriceCellColumns);

                boundPriceCellsColumnLookup.Setup(b => b.GetWorksheetBoundPriceCells(It.IsAny<int>()))
                                           .Returns(_boundPriceCells);

                testObjects.SetupGet(o => o.BoundPriceCellsColumnLookup)
                           .Returns(boundPriceCellsColumnLookup.Object);

                var dashboardSettingsLoaded = new BehaviorSubject<bool>(_dashboardSettingsLoaded);

                testObjects.SetupGet(o => o.DashboardSettingsLoaded)
                           .Returns(dashboardSettingsLoaded);

                var dashboardSettingsReader = new Mock<IDashboardSettingsReader>();

                dashboardSettingsReader.SetupGet(d => d.DashboardSettingsLoaded)
                                        .Returns(dashboardSettingsLoaded);

                if (_dashboardSettingsException == null)
                {
                    dashboardSettingsReader.Setup(d => d.GetDashboardSettingsForPage(It.IsAny<int>()))
                                            .Returns(_dashboardSettings);
                }
                else
                {
                    dashboardSettingsReader.Setup(d => d.GetDashboardSettingsForPage(It.IsAny<int>()))
                                            .Throws(_dashboardSettingsException);
                }

                testObjects.SetupGet(o => o.DashboardSettingsReader)
                           .Returns(dashboardSettingsReader.Object);

                var bindingsCache = new Mock<IScratchPadBindingsCache>();

                bindingsCache.Setup(c => c.LookupReader())
                             .Returns(boundPriceCellsColumnLookup.Object);

                bindingsCache.Setup(c => c.DashboardSettingsReader())
                             .Returns(dashboardSettingsReader.Object);

                bindingsCache.Setup(c => c.UpdateBindingsCacheAndDashboardSettings(It.IsAny<int>(),
                                                                                   It.IsAny<int>(),
                                                                                   It.IsAny<Dictionary<CellPoint, IList<TenorPriceCell>>>(),
                                                                                   It.IsAny<IList<CellPoint>>()))
                             .Returns(_bindingsCacheUpdate);

                if (_removeWorksheetException != null)
                {
                    bindingsCache.Setup(b => b.RemoveWorksheet(It.IsAny<int>(), It.IsAny<int>()))
                                 .Throws(_removeWorksheetException);
                }

                testObjects.SetupGet(o => o.ScratchPadBindingsCache)
                           .Returns(bindingsCache.Object);

                var importPriceCellsService = new Mock<IImportPriceCellsService>();

                if (_importPriceCellsException == null)
                {
                    importPriceCellsService.Setup(b => b.GetImportBindingsUpdate(It.IsAny<CellPoint>(), 
                                                                                 It.IsAny<bool>(),
                                                                                 It.IsAny<IEnumerable<IList<TenorPriceCell>>>(), 
                                                                                 It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                           .Returns(_importPriceCellsBindingsUpdate);
                }
                else
                {
                    importPriceCellsService.Setup(b => b.GetImportBindingsUpdate(It.IsAny<CellPoint>(),
                                                                                 It.IsAny<bool>(),
                                                                                 It.IsAny<IEnumerable<IList<TenorPriceCell>>>(),
                                                                                 It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                           .Throws(_importPriceCellsException);
                }

                testObjects.SetupGet(o => o.ImportPriceCellsService)
                           .Returns(importPriceCellsService.Object);

                var scratchPadSettingsRestorationService = new Mock<IScratchPadSettingsRestorationService>();

                scratchPadSettingsRestorationService.Setup(s => s.GetPriceCellsFromSettings(It.IsAny<DashboardScratchPadSettings>(),
                                                                                            It.IsAny<Dictionary<LinkedCurve, List<TenorPriceCell>>>()))
                                                    .Returns(_restoredPriceCells);

                testObjects.SetupGet(o => o.ScratchPadSettingsRestorationService)
                           .Returns(scratchPadSettingsRestorationService.Object);

                var removePriceCurveBindingsService = new Mock<IRemovePriceCurveBindingsService>();

                PriceCellRangeBindingsUpdate removePriceCurveBindingsUpdate;

                removePriceCurveBindingsService.Setup(b => b.TryGetRemovePriceCurveBindingUpdate(It.IsAny<IList<int>>(),
                                                                                                 It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>(),
                                                                                                 out removePriceCurveBindingsUpdate))
                                               .Callback(new MockCallback((IList<int> _,
                                                                           Dictionary<ColumnCellRange, IList<TenorPriceCell>> _,
                                                                           out PriceCellRangeBindingsUpdate update) => update = _removePriceCurveBindingUpdate))
                                               .Returns(_tryGetRemovePriceCurveBindingUpdate);

                testObjects.SetupGet(o => o.RemovePriceCurveBindingsService)
                           .Returns(removePriceCurveBindingsService.Object);

                var formatSettingsService = new Mock<IScratchPadFormatSettingsService>();

                formatSettingsService.Setup(f => f.HasSettings())
                                     .Returns(_hasFormatSettings);

                formatSettingsService.SetupGet(f => f.SettingsPath)
                                     .Returns(_formatSettingsPath);

                testObjects.SetupGet(o => o.ScratchPadFormatSettingsService)
                           .Returns(formatSettingsService.Object);

                var pasteExtendTenorsService = new Mock<IPasteExtendTenorsService>();

                if (_pasteExtendTenorsException == null)
                {
                    pasteExtendTenorsService.Setup(t => t.GetTenorsUpdate(It.IsAny<int>(),
                                                                          It.IsAny<CellRange>(),
                                                                          It.IsAny<CellRange>()))
                                            .Returns(_pasteWorksheetTenorsUpdate);
                }
                else
                {
                    pasteExtendTenorsService.Setup(t => t.GetTenorsUpdate(It.IsAny<int>(),
                                                                          It.IsAny<CellRange>(),
                                                                          It.IsAny<CellRange>()))
                                            .Throws(_pasteExtendTenorsException);
                }

                testObjects.SetupGet(o => o.PasteExtendTenorsService)
                           .Returns(pasteExtendTenorsService.Object);

                var pasteImportPriceCellsService = new Mock<IPasteImportPriceCellsService>();

                pasteImportPriceCellsService.Setup(i => i.GetImportPriceCells(It.IsAny<CellRange>(), 
                                                                              It.IsAny<CellRange>(), 
                                                                              It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>(), 
                                                                              It.IsAny<IList<TenorPriceRowViewModel>>()))
                                         .Returns(_pasteImportPriceCells);

                testObjects.SetupGet(o => o.PasteImportPriceCellsService)
                           .Returns(pasteImportPriceCellsService.Object);

                var columnShiftService = new Mock<IColumnShiftService>();

                if (_columnShiftException == null)
                {
                    columnShiftService.Setup(i => i.GetShiftedColumnsBindingsUpdate(It.IsAny<int>(),
                                                                                    It.IsAny<int>(),
                                                                                    It.IsAny<Dictionary<CellPoint, IList<TenorPriceCell>>>()))
                                      .Returns(_shiftColumnsBindingsUpdate);
                }
                else
                {
                    columnShiftService.Setup(i => i.GetShiftedColumnsBindingsUpdate(It.IsAny<int>(),
                                                                                    It.IsAny<int>(),
                                                                                    It.IsAny<Dictionary<CellPoint, IList<TenorPriceCell>>>()))
                                      .Throws(_columnShiftException);
                }

                testObjects.SetupGet(o => o.ColumnShiftService)
                           .Returns(columnShiftService.Object);

                var insertRowsService = new Mock<IInsertRowsService>();

                if (_insertRowsException == null)
                {
                    insertRowsService.Setup(i => i.GetShiftedBoundPriceCells(It.IsAny<int>(),
                                                                             It.IsAny<int>(),
                                                                             It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                     .Returns(_shiftedRowsResult);
                }
                else
                {
                    insertRowsService.Setup(i => i.GetShiftedBoundPriceCells(It.IsAny<int>(),
                                                                             It.IsAny<int>(),
                                                                             It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                     .Throws(_insertRowsException);
                }

                insertRowsService.Setup(i => i.GetSplitRangeBoundPriceCells(It.IsAny<int>(),
                                                                            It.IsAny<int>(),
                                                                            It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                 .Returns(_splitRowsResult);

                testObjects.SetupGet(o => o.InsertRowsService)
                           .Returns(insertRowsService.Object);

                var removeRowsService = new Mock<IRemoveRowsService>();

                if (_removeRowsException == null)
                { 
                    removeRowsService.Setup(r => r.GetShiftedOrModifiedPriceCells(It.IsAny<int>(),
                                                                                  It.IsAny<int>(),
                                                                                  It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                     .Returns(_removeRowsResult);
                }
                else
                {
                    removeRowsService.Setup(r => r.GetShiftedOrModifiedPriceCells(It.IsAny<int>(),
                                                                                  It.IsAny<int>(),
                                                                                  It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                     .Throws(_removeRowsException);
                }

                testObjects.SetupGet(o => o.RemoveRowsService)
                           .Returns(removeRowsService.Object);

                var mergeColumnCellRangesService = new Mock<IMergeColumnCellRangesService>();

                mergeColumnCellRangesService.Setup(m => m.MergeAdjacentColumnCellRanges(It.IsAny<int>(),
                                                                                        It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                            .Returns(_mergeColumnCellRangesResult);

                testObjects.SetupGet(o => o.MergeColumnCellRangesService)
                           .Returns(mergeColumnCellRangesService.Object);

                var removeColumnsBindingUpdateService = new Mock<IRemoveColumnsBindingUpdateService>();

                if (_removeColumnsException == null)
                {
                    removeColumnsBindingUpdateService.Setup(r => r.GetRemoveColumnsBindingUpdate(It.IsAny<PreRemoveColumnsArgs>()))
                                                     .Returns(_removeColumnBindingsUpdate);
                }
                else
                {
                    removeColumnsBindingUpdateService.Setup(r => r.GetRemoveColumnsBindingUpdate(It.IsAny<PreRemoveColumnsArgs>()))
                                                     .Throws(_removeColumnsException);
                }

                testObjects.SetupGet(o => o.RemoveColumnsBindingUpdateService)
                           .Returns(removeColumnsBindingUpdateService.Object);

                var clearBindingsService = new Mock<IClearBindingsService>();

                if (_clearBindingsException == null)
                {
                    clearBindingsService.Setup(c => c.GetClearBindingsUpdate(It.IsAny<CellPoint>(),
                                                                             It.IsAny<CellPoint>(),
                                                                             It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                        .Returns(_clearBindingsUpdate);
                }
                else
                {
                    clearBindingsService.Setup(c => c.GetClearBindingsUpdate(It.IsAny<CellPoint>(),
                                                                             It.IsAny<CellPoint>(),
                                                                             It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                        .Throws(_clearBindingsException);
                }

                testObjects.SetupGet(o => o.ClearBindingsService)
                           .Returns(clearBindingsService.Object);

                var importTenorCellsService = new Mock<IImportTenorCellsService>();

                importTenorCellsService.Setup(t => t.GetTenorsUpdate(It.IsAny<int>(),
                                                                     It.IsAny<CellPoint>(),
                                                                     It.IsAny<IList<ITenor>>()))
                                       .Returns(_importWorksheetTenorsUpdate);
                
                testObjects.SetupGet(o => o.ImportTenorCellsService)
                           .Returns(importTenorCellsService.Object);

                var messageDialogService = new Mock<IScratchPadMessageDialogService>();

                testObjects.SetupGet(o => o.MessageDialogService)
                           .Returns(messageDialogService.Object);



                var controller = new ScratchPadController(bindingsCache.Object,
                                                          scratchPadSettingsRestorationService.Object,
                                                          removePriceCurveBindingsService.Object,
                                                          TestMocks.GetSchedulerProvider().Object,
                                                          TestMocks.GetLoggerFactory().Object)
                                 {
                                     ImportPriceCellsService = importPriceCellsService.Object,
                                     ImportTenorCellsService = importTenorCellsService.Object,
                                     WorksheetBindingUpdateService = worksheetBindingUpdateService.Object,
                                     WorksheetClearCellsUpdateService = worksheetClearCellsUpdateService.Object,
                                     PasteImportPriceCellsService = pasteImportPriceCellsService.Object,
                                     PasteExtendTenorsService = pasteExtendTenorsService.Object,
                                     ColumnShiftService = columnShiftService.Object,
                                     RemoveColumnsBindingUpdateService = removeColumnsBindingUpdateService.Object,
                                     InsertRowsService = insertRowsService.Object,
                                     RemoveRowsService = removeRowsService.Object,
                                     MergeColumnCellRangesService = mergeColumnCellRangesService.Object,
                                     ClearBindingsService = clearBindingsService.Object,
                                     MessageDialogService = messageDialogService.Object
                                 };

                controller.ViewModel.WorksheetDataBindings = _worksheetDataBindings;

                if (_pageNumber.HasValue)
                {
                    controller.Initialize(_pageNumber.Value, 
                                          dataSource.Object,
                                          formatSettingsService.Object, 
                                          priceCurvesService.Object, 
                                          clipboard.Object);
                }

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region LoadedCommand

        [Test]
        public void ShouldSetSpreadsheet_OnLoadedCommand()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1).Build();

            var sender = new object();

            // ACT
            testObjects.ViewModel.OnLoadedCommand.Execute(sender);

            // ASSERT
            Assert.That(testObjects.ViewModel.Spreadsheet, Is.SameAs(sender));
        }

        #endregion

        #region Dashboard Settings Loaded

        [Test]
        public void ShouldSubscribeDashboardSettingsLoaded_When_Initialize()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Initialize(1,
                                              testObjects.DataSource,
                                              testObjects.ScratchPadFormatSettingsService,
                                              testObjects.ScratchPadPriceCurvesService,
                                              testObjects.ScratchPadClipboard);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsReader)
                .VerifyGet(d => d.DashboardSettingsLoaded);
        }

        [Test]
        public void ShouldSubscribePriceCurves_On_DashboardSettingsLoaded()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .Build();

            // ACT
            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .VerifyGet(s => s.ClearBindings);

            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .VerifyGet(s => s.RestoreBindings);

            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .VerifyGet(s => s.PriceCurves);
        }

        #endregion

        #region Price Curves Loaded

        [Test]
        public void ShouldDisableScratchPad_On_IsLoadingTrue()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .Build();

            // ACT
            testObjects.IsLoading.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.False);
        }

        [Test]
        public void ShouldEnableScratchPad_On_IsLoadingFalse()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .Build();

            // ACT
            testObjects.IsLoading.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.True);
        }

        [Test]
        public void ShouldSetDocumentPath_OnPriceCurvesFirstLoad_With_HasFormatSettingsTrue()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithHasFormatSettings(true)
                                                                         .WithFormatSettingsPath("settings.xml")
                                                                         .Build();

            // ACT
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ASSERT
            Assert.That(testObjects.ViewModel.DocumentSourcePath, Is.EqualTo("settings.xml"));
        }

        [Test]
        public void ShouldNotSetDocumentPath_OnPriceCurvesFirstLoad_With_HasFormatSettingsFalse()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithHasFormatSettings(false)
                                                                         .WithFormatSettingsPath("settings.xml")
                                                                         .Build();

            // ACT
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ASSERT
            Assert.That(testObjects.ViewModel.DocumentSourcePath, Is.Null);
        }

        [Test]
        public void ShouldStartAutoSave_FirstPriceCurvesLoaded_With_SpreadsheetLoaded()
        {
            var sender = new object();

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .Build();

            testObjects.ViewModel.OnLoadedCommand.Execute(sender);

            // ACT
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ASSERT
            Mock.Get(testObjects.ScratchPadFormatSettingsService)
                .Verify(f => f.StartAutoSave(sender, It.IsAny<IScheduler>(), It.IsAny<TimeSpan>()));
        }

        [Test]
        public void ShouldNotGetBoundPriceCells_OnPriceCurvesFirstLoad_With_NoExistingBindingSettings()
        {
            var settings = new DashboardSettings();

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .Build();

            // ACT
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ASSERT
            Mock.Get(testObjects.ScratchPadSettingsRestorationService)
                .Verify(s => s.GetPriceCellsFromSettings(It.IsAny<DashboardScratchPadSettings>(),
                                                         It.IsAny<Dictionary<LinkedCurve, List<TenorPriceCell>>>()), Times.Never);
        }

        [Test]
        public void ShouldRestoreCacheAndViewModelBindings_OnPriceCurvesFirstLoad_With_BindingSettings()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var cellPoint = new CellPoint(1, 2);
            var tenorPriceCell = Defaults.TenorPriceCell();

            var boundPriceCells = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>>
                                  {
                                      {
                                          1,
                                          new Dictionary<CellPoint, IList<TenorPriceCell>>
                                          {
                                              {
                                                  cellPoint, new List<TenorPriceCell> { tenorPriceCell }
                                              }
                                          }
                                      }
                                  };

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .WithRestoredPriceCells(boundPriceCells)
                                                                         .Build();

            var expectedCellPoints = new[] { cellPoint };
            var expectedPriceValues = new[] { tenorPriceCell.Value };

            // ACT
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ASSERT
            Mock.Get(testObjects.ScratchPadSettingsRestorationService)
                .Verify(s => s.GetPriceCellsFromSettings(It.IsAny<DashboardScratchPadSettings>(), testObjects.DefaultPriceCurves));

            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(c => c.RestoreBindingsCacheAndDashboardSettings(1, boundPriceCells));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.Not.Null);
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.BindingsToRemove, Is.Null);
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.WorksheetId, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.BindingsToCreate.Keys.SequenceEqual(expectedCellPoints));
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.BindingsToCreate[cellPoint].SequenceEqual(expectedPriceValues));
        }

        [Test]
        public void ShouldShowDialog_On_PriceCurvesLoadedException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettingsException(error)
                                                                         .Build();

            // ACT
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region Price Curves Update

        [Test]
        public void ShouldCheckBoundPriceCellOrphans_On_PriceCurvesUpdate_With_CurveRemoved()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var priceCurves = new Dictionary<LinkedCurve, List<TenorPriceCell>>();

            var cellRange = new ColumnCellRange(1, 1, 2);

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                {
                                    { cellRange, new List<TenorPriceCell>() }
                                };

            var worksheetDataBindings = new Dictionary<int, List<WorksheetDataBinding>>
                                        {
                                            { 1, new List<WorksheetDataBinding>() }
                                        };

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .WithPriceCurves(priceCurves)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithWorksheetDataBindings(worksheetDataBindings)
                                                                         .Build();

            var update = new Dictionary<LinkedCurve, List<TenorPriceCell>>
                         {
                             { new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), new List<TenorPriceCell>() }
                         };

            PriceCellRangeBindingsUpdate bindingsUpdate;

            // ACT
            testObjects.PriceCurves.OnNext(update);

            var expectedCurveIds = new[] { 101 };

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(b => b.GetWorksheetBoundPriceCellsByColumnCellRange(1));

            Mock.Get(testObjects.RemovePriceCurveBindingsService)
                .Verify(b => b.TryGetRemovePriceCurveBindingUpdate(It.Is<IList<int>>(ids => ids.SequenceEqual(expectedCurveIds)),
                                                                   boundPriceCells, 
                                                                   out bindingsUpdate));
        }

        [Test]
        public void ShouldRemoveBoundPriceCellOrphans_On_PriceCurvesUpdate_When_CurveRemoved_Contains_BoundPriceCells()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var priceCurves = new Dictionary<LinkedCurve, List<TenorPriceCell>>();

            var cellRange = new ColumnCellRange(1, 1, 2);

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                {
                                    { cellRange, new List<TenorPriceCell>() }
                                };

            var worksheetDataBindings = new Dictionary<int, List<WorksheetDataBinding>>
                                        {
                                            { 2, new List<WorksheetDataBinding>() }
                                        };

            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>();
            var bindingsToRemove = new List<CellPoint>();

            var removeCurveBindings = new PriceCellRangeBindingsUpdate(bindingsToAdd, bindingsToRemove);

            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(1);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .WithPriceCurves(priceCurves)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithWorksheetDataBindings(worksheetDataBindings)
                                                                         .WithTryGetRemovePriceCurveBindingUpdate(true, removeCurveBindings)
                                                                         .WithWorksheetBindingUpdate(worksheetBindingUpdate)
                                                                         .Build();

            var update = new Dictionary<LinkedCurve, List<TenorPriceCell>> 
                         {
                             { new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), new List<TenorPriceCell>() }
                         };

            // ACT
            testObjects.PriceCurves.OnNext(update);

            // ASSERT
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(c => c.UpdateBindingsCacheAndDashboardSettings(1,
                                                                       2,
                                                                       removeCurveBindings.CellRangesToAdd, 
                                                                       removeCurveBindings.CellRangesToRemove));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.SameAs(worksheetBindingUpdate));
        }

        [Test]
        public void ShouldNotRemoveBoundPriceCells_On_PriceCurvesUpdate_With_NoBoundPriceCellOrphans()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var priceCurves = new Dictionary<LinkedCurve, List<TenorPriceCell>>();

            var cellRange = new ColumnCellRange(1, 1, 2);

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>> 
                                  {
                                      { cellRange, new List<TenorPriceCell>() }
                                  };

            var worksheetDataBindings = new Dictionary<int, List<WorksheetDataBinding>>
                                        {
                                            { 1, new List<WorksheetDataBinding>() }
                                        };

            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>();
            var bindingsToRemove = new List<CellPoint>();

            var bindings = new PriceCellRangeBindingsUpdate(bindingsToAdd, bindingsToRemove);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .WithPriceCurves(priceCurves)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithWorksheetDataBindings(worksheetDataBindings)
                                                                         .WithTryGetRemovePriceCurveBindingUpdate(false, null)
                                                                         .WithClearBindingsUpdate(bindings)
                                                                         .Build();

            var update = new Dictionary<LinkedCurve, List<TenorPriceCell>>
                         {
                             { new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), new List<TenorPriceCell>() }
                         };

            // ACT
            testObjects.PriceCurves.OnNext(update);

            // ASSERT
            Mock.Get(testObjects.ClearBindingsService)
                .Verify(b => b.GetClearBindingsUpdate(It.IsAny<CellPoint>(), 
                                                      It.IsAny<CellPoint>(),
                                                      It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()), 
                        Times.Never);
        }

        [Test]
        public void ShouldNotRemoveUnboundPriceCells_On_PriceCurvesUpdate_With_NoWorksheetBindings()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var priceCurves = new Dictionary<LinkedCurve, List<TenorPriceCell>>();

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .WithWorksheetDataBindings(null)
                                                                         .WithPriceCurves(priceCurves)
                                                                         .Build();

            var update = new Dictionary<LinkedCurve, List<TenorPriceCell>> 
                         {
                             { new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), new List<TenorPriceCell>() }
                         };

            // ACT
            testObjects.PriceCurves.OnNext(update);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(b => b.GetWorksheetBoundPriceCellsByColumnCellRange(It.IsAny<int>()), Times.Never());
        }

        #endregion

        #region Clear and Restore Bindings

        [Test]
        public void ShouldClearBindingsAndStopAutoSave_On_ClearBindings()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithHasFormatSettings(true)
                                                                         .WithFormatSettingsPath("settings.xml")
                                                                         .Build();

            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ACT
            testObjects.ClearBindings.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.DocumentSourcePath, Is.Null);
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.UpdateAction, Is.EqualTo(WorksheetDataBindingsUpdateAction.Clear));

            Mock.Get(testObjects.ScratchPadFormatSettingsService)
                .Verify(f => f.StopAutoSave());
        }

        [Test]
        public void ShouldRestoreBindingsAndDocumentSource_On_RestoreBindings()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var cellPoint = new CellPoint(1, 2);
            var tenorPriceCell = Defaults.TenorPriceCell();

            var boundPriceCells = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>>
                                  {
                                      {
                                          1,
                                          new Dictionary<CellPoint, IList<TenorPriceCell>>
                                          {
                                              {
                                                  cellPoint, new List<TenorPriceCell> { tenorPriceCell }
                                              }
                                          }
                                      }
                                  };

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithHasFormatSettings(true)
                                                                         .WithFormatSettingsPath("settings.xml")
                                                                         .WithDashboardSettings(settings)
                                                                         .WithRestoredPriceCells(boundPriceCells)
                                                                         .Build();

            var expectedCellPoints = new[] { cellPoint };
            var expectedPriceValues = new[] { tenorPriceCell.Value };

            // ARRANGE - load and clear
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);
            testObjects.ClearBindings.OnNext(Unit.Default);

            // ACT
            testObjects.RestoreBindings.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ScratchPadSettingsRestorationService)
                .Verify(s => s.GetPriceCellsFromSettings(It.IsAny<DashboardScratchPadSettings>(), testObjects.DefaultPriceCurves));

            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(c => c.RestoreBindingsCacheAndDashboardSettings(1, boundPriceCells));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.Not.Null);
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.BindingsToRemove, Is.Null);
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.WorksheetId, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.BindingsToCreate.Keys.SequenceEqual(expectedCellPoints));
            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate.BindingsToCreate[cellPoint].SequenceEqual(expectedPriceValues));
        }

        [Test]
        public void ShouldStartAutoSave_On_RestoreBindings()
        {
            var sender = new object();

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .Build();

            testObjects.ViewModel.OnLoadedCommand.Execute(sender);

            // ARRANGE - load and clear
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);
            testObjects.ClearBindings.OnNext(Unit.Default);

            Mock.Get(testObjects.ScratchPadFormatSettingsService).Invocations.Clear();

            // ACT
            testObjects.RestoreBindings.OnNext(Unit.Default);

            Mock.Get(testObjects.ScratchPadFormatSettingsService)
                .Verify(f => f.StartAutoSave(sender, It.IsAny<IScheduler>(), It.IsAny<TimeSpan>()));
        }

        #endregion

        #region CellValueChangedCommand

        [Test]
        public void ShouldRemovePriceCellBindings_On_CellValueChanged()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>();
            var bindingsToRemove = new List<CellPoint>();

            var bindings = new PriceCellRangeBindingsUpdate(bindingsToAdd, bindingsToRemove);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithClearBindingsUpdate(bindings)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var args = new CellEndEditArgs(2, 3, 1, worksheetDataBindings);

            var cellPoint = new CellPoint(3, 2);

            // ACT
            testObjects.ViewModel.CellValueChangedCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(b => b.GetWorksheetBoundPriceCellsByColumnCellRange(1));

            Mock.Get(testObjects.ClearBindingsService)
                .Verify(r => r.GetClearBindingsUpdate (It.Is<CellPoint>(cp => cp.Equals(cellPoint)),
                                                       It.Is<CellPoint>(cp => cp.Equals(cellPoint)),
                                                       boundPriceCells));
        }

        [Test]
        public void ShouldShowDialog_On_CellValueChanged_Exception()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithClearBindingsException(error)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var args = new CellEndEditArgs(2, 3, 1, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.CellValueChangedCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region ImportPriceGridCommand

        [Test]
        public void ShouldEnableImportPricesCommand_On_ClipboardHasPricesTrue()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1).Build();

            // ACT
            testObjects.ClipboardHasPrices.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ImportPriceGridCommand.CanExecute(null), Is.True);
        }

        [Test]
        public void ShouldApplySpreadsheetBindings_And_UpdateSettings_On_ImportPricesCommand_With_ClipboardPrices()
        {
            var cellPoint = new CellPoint(1, 2);

            var cell1 = new TenorPriceCell(1, 20230101, new PriceValue());
            var cell2 = new TenorPriceCell(1, 20230201, new PriceValue());

            var clipboardCells = new List<List<TenorPriceCell>>
                                 {
                                     new() { cell1, cell2 }
                                 };

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                {
                                    {
                                        cellPoint,
                                        new List<TenorPriceCell> { cell1, cell2 }
                                    }
                                };

            var bindingsToRemove = Array.Empty<CellPoint>();

            var importPriceCellsBindingsUpdate = new PriceCellRangeBindingsUpdate(bindingsToAdd,
                                                                                  bindingsToRemove);

            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(1);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithClipboardPriceCells(clipboardCells)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithImportPriceCellsBindingsUpdate(importPriceCellsBindingsUpdate)
                                                                         .WithWorksheetBindingUpdate(worksheetBindingUpdate)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();
            var importTarget = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1 && r.TopRowIndex == 1);

            var worksheetDataBindingArgs = new ImportPriceGridArgs(2, worksheetDataBindings, importTarget);

            // ACT
            testObjects.ViewModel.ImportPriceGridCommand.Execute(worksheetDataBindingArgs);

            // ASSERT
            Mock.Get(testObjects.ScratchPadClipboard)
                .Verify(c => c.GetClipboardPrices());

            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCellsByColumnCellRange(2));

            Mock.Get(testObjects.ImportPriceCellsService)
                .Verify(b => b.GetImportBindingsUpdate(It.Is<CellPoint>(cp => cp.ColumnIndex == 1 && cp.RowIndex == 1),
                                                       false,
                                                       clipboardCells,
                                                       boundPriceCells));

            Mock.Get(testObjects.WorksheetBindingUpdateService)
                .Verify(w => w.GetWorksheetBindingUpdate(2,
                                                         importPriceCellsBindingsUpdate,
                                                         worksheetDataBindings));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.SameAs(worksheetBindingUpdate));

            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 2, bindingsToAdd, bindingsToRemove));
        }

        [Test]
        public void ShouldApplyTenorsUpdate_On_ImportPricesCommand_With_ClipboardTenors()
        {
            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var tenors = new[] { Mock.Of<ITenor>(), Mock.Of<ITenor>() };

            var tenorCellRanges = new SortedList<ColumnCellRange, IList<DateTime>>
                                  {
                                      { new ColumnCellRange(0, 1, 2), Array.Empty<DateTime>() }
                                  };

            var tenorsUpdate = new WorksheetTenorsUpdate(1, tenorCellRanges);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithClipboardTenors(tenors)
                                                                         .WithImportWorksheetTenorsUpdate(tenorsUpdate)
                                                                         .WithClearBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var importTarget = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0 && r.TopRowIndex == 1);

            var worksheetDataBindingArgs = new ImportPriceGridArgs(1, worksheetDataBindings, importTarget);

            // ACT
            testObjects.ViewModel.ImportPriceGridCommand.Execute(worksheetDataBindingArgs);

            // ASSERT
            Mock.Get(testObjects.ImportTenorCellsService)
                .Verify(t => t.GetTenorsUpdate(1, 
                                               It.Is<CellPoint>(cp => cp.ColumnIndex == 0 && cp.RowIndex == 1), 
                                               It.Is<IList<ITenor>>(ts => ts.SequenceEqual(tenors))));

            Mock.Get(testObjects.ClearBindingsService)
                .Verify(c => c.GetClearBindingsUpdate(It.Is<CellPoint>(cp => cp.ColumnIndex == 0 && cp.RowIndex == 1),
                                                      It.Is<CellPoint>(cp => cp.ColumnIndex == 0 && cp.RowIndex == 2),
                                                      boundPriceCells));

            Assert.That(testObjects.ViewModel.WorksheetTenorsUpdate, Is.SameAs(tenorsUpdate));
        }

        [Test]
        public void ShouldRemoveBindings_On_ImportPricesCommand_With_ClipboardTenors_OverlapsExistingBoundPriceCells()
        {
            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var tenors = new[] { Mock.Of<ITenor>(), Mock.Of<ITenor>() };

            
            var tenorCellRanges = new SortedList<ColumnCellRange, IList<DateTime>>
                                  {
                                      { new ColumnCellRange(0, 1, 2), Array.Empty<DateTime>() }
                                  };

            var tenorsUpdate = new WorksheetTenorsUpdate(1, tenorCellRanges);

            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>();
            var bindingsToRemove = new[] { new CellPoint(0, 1) };

            var clearBindings = new PriceCellRangeBindingsUpdate(bindingsToAdd, bindingsToRemove);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithClipboardTenors(tenors)
                                                                         .WithImportWorksheetTenorsUpdate(tenorsUpdate)
                                                                         .WithClearBindingsUpdate(clearBindings)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var importTarget = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0 && r.TopRowIndex == 1);

            var worksheetDataBindingArgs = new ImportPriceGridArgs(2, worksheetDataBindings, importTarget);

            // ACT
            testObjects.ViewModel.ImportPriceGridCommand.Execute(worksheetDataBindingArgs);

            // ASSERT
            Mock.Get(testObjects.ClearBindingsService)
                .Verify(c => c.GetClearBindingsUpdate(It.Is<CellPoint>(cp => cp.ColumnIndex == 0 && cp.RowIndex == 1),
                                                      It.Is<CellPoint>(cp => cp.ColumnIndex == 0 && cp.RowIndex == 2),
                                                      boundPriceCells));

            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 2, bindingsToAdd, bindingsToRemove));

            Assert.That(testObjects.ViewModel.WorksheetTenorsUpdate, Is.SameAs(tenorsUpdate));
        }

        [Test]
        public void ShouldCombineBindingUpdates_OnImportPricesCommand_With_ClipboardPrices_And_Tenors()
        {
            // ARRANGE - Bound Price Cells
            var columnCellRange1 = new ColumnCellRange(0, 0, 2);

            var cell1 = Defaults.TenorPriceCell(1.1m);
            var cell2 = Defaults.TenorPriceCell(1.2m);

            var columnCellRange2 = new ColumnCellRange(1, 0, 2);

            var cell3 = Defaults.TenorPriceCell(2.1m);
            var cell4 = Defaults.TenorPriceCell(2.2m);

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { columnCellRange1, new[] { cell1, cell2 } },
                                      { columnCellRange2, new[] { cell3, cell4 } }
                                  };


            // ARRANGE - Clipboard
            var clipboardTenors = new[] { Mock.Of<ITenor>(), Mock.Of<ITenor>() };

            var cell5 = Defaults.TenorPriceCell(2.3m);

            var clipboardPriceCells = new List<List<TenorPriceCell>>
                                      {
                                          new() { cell4, cell5 }
                                      };

            var tenorCellRanges = new SortedList<ColumnCellRange, IList<DateTime>>
                                  {
                                      { new ColumnCellRange(0, 1, 2), Array.Empty<DateTime>() }
                                  };

            var tenorsUpdate = new WorksheetTenorsUpdate(2, tenorCellRanges);

            // ARRANGE - Binding Updates
            var cellPoint1 = new CellPoint(0, 0);

            var tenorBindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                     {
                                         { cellPoint1, new List<TenorPriceCell>{cell1} }
                                     };

            var tenorBindingsToRemove = new[] { cellPoint1 };

            var clearBindingsUpdate = new PriceCellRangeBindingsUpdate(tenorBindingsToAdd, 
                                                                       tenorBindingsToRemove);


            var cellPoint2 = new CellPoint(1, 0);

            var priceCellBindingsToRemove = new[] { cellPoint2 };

            var priceCellBindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>> 
                                         {
                                             { cellPoint2, new List<TenorPriceCell> { cell3, cell4, cell5 } }
                                         };

            var priceCellsBindingUpdate = new PriceCellRangeBindingsUpdate(priceCellBindingsToAdd, 
                                                                           priceCellBindingsToRemove);

            // ARRANGE - Test Objects
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithClipboardPriceCells(clipboardPriceCells)
                                                                         .WithClipboardTenors(clipboardTenors)
                                                                         .WithImportPriceCellsBindingsUpdate(priceCellsBindingUpdate)
                                                                         .WithImportWorksheetTenorsUpdate(tenorsUpdate)
                                                                         .WithClearBindingsUpdate(clearBindingsUpdate)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var importTarget = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0 && r.TopRowIndex == 1);

            var worksheetDataBindingArgs = new ImportPriceGridArgs(2, worksheetDataBindings, importTarget);

            var expectedBindingsToRemove = new[] { cellPoint1, cellPoint2 };

            var expectedBindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                        {
                                            { cellPoint1, new[]{ cell1 } },
                                            { cellPoint2, new[]{ cell3, cell4, cell5 } }
                                        };

            // ACT
            testObjects.ViewModel.ImportPriceGridCommand.Execute(worksheetDataBindingArgs);

            // ASSERT
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(c => c.UpdateBindingsCacheAndDashboardSettings(1,
                                                                       2,
                                                                       It.Is<Dictionary<CellPoint, IList<TenorPriceCell>>>(d => d.Compare(expectedBindingsToAdd)),
                                                                       It.Is<IList<CellPoint>>(cp => cp.SequenceEqual(expectedBindingsToRemove, new CellPointEqualityComparer()))));
        }

        [Test]
        public void ShouldUpdateHeaders_And_ShiftBindingsUpdate_OnImportPricesCommand_With_Prices_And_Headers()
        {
            // ARRANGE
            var clipboardTenors = new[] { Mock.Of<ITenor>() };
            var clipboardPriceCells = new List<List<TenorPriceCell>> { new() { Defaults.TenorPriceCell() } };
            var clipboardHeaders = new[] { "header-1", "header-2" };

            // ARRANGE 
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithClipboardPriceCells(clipboardPriceCells)
                                                                         .WithClipboardTenors(clipboardTenors)
                                                                         .WithClipboardHeaders(clipboardHeaders)
                                                                         .WithImportPriceCellsBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .WithImportWorksheetTenorsUpdate(Defaults.WorksheetTenorsUpdate(2))
                                                                         .WithClearBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var importTarget = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0 && r.TopRowIndex == 1);

            var worksheetDataBindingArgs = new ImportPriceGridArgs(2, worksheetDataBindings, importTarget);

            // ACT
            testObjects.ViewModel.ImportPriceGridCommand.Execute(worksheetDataBindingArgs);

            // ASSERT
            Assert.That(testObjects.ViewModel.WorksheetHeadersUpdate, Is.Not.Null);
            Assert.That(testObjects.ViewModel.WorksheetHeadersUpdate.Headers.SequenceEqual(clipboardHeaders));
            Assert.That(testObjects.ViewModel.WorksheetHeadersUpdate.TopLeft.ColumnIndex, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.WorksheetHeadersUpdate.TopLeft.RowIndex, Is.EqualTo(1));

            Mock.Get(testObjects.ImportTenorCellsService)
                .Verify(t => t.GetTenorsUpdate(2, 
                                               It.Is<CellPoint>(cp => cp.ColumnIndex == 0 && cp.RowIndex == 2), 
                                               It.IsAny<IList<ITenor>>()));

            Mock.Get(testObjects.ImportPriceCellsService)
                .Verify(p => p.GetImportBindingsUpdate(It.Is<CellPoint>(cp => cp.ColumnIndex == 1 && cp.RowIndex == 1), 
                                                       true, 
                                                       It.IsAny<List<List<TenorPriceCell>>>(), 
                                                       It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()));
        }

        [Test]
        public void ShouldUpdateHeaders_And_ClearBindings_OnImportPricesCommand_With_Headers_NoPrices()
        {
            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var clipboardHeaders = new[] { "header-1", "header-2" };

            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(2);


            // ARRANGE 
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithClipboardHeaders(clipboardHeaders)
                                                                         .WithClearBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .WithWorksheetBindingUpdate(worksheetBindingUpdate)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var importTarget = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0 && r.TopRowIndex == 1);

            var worksheetDataBindingArgs = new ImportPriceGridArgs(2, worksheetDataBindings, importTarget);

            // ACT
            testObjects.ViewModel.ImportPriceGridCommand.Execute(worksheetDataBindingArgs);

            // ASSERT
            Assert.That(testObjects.ViewModel.WorksheetHeadersUpdate, Is.Not.Null);
            Assert.That(testObjects.ViewModel.WorksheetHeadersUpdate.Headers.SequenceEqual(clipboardHeaders));
            Assert.That(testObjects.ViewModel.WorksheetHeadersUpdate.TopLeft.ColumnIndex, Is.EqualTo(0));
            Assert.That(testObjects.ViewModel.WorksheetHeadersUpdate.TopLeft.RowIndex, Is.EqualTo(1));

            Mock.Get(testObjects.ClearBindingsService)
                .Verify(r => r.GetClearBindingsUpdate(It.Is<CellPoint>(cp => cp.ColumnIndex == 0 && cp.RowIndex == 1),
                                                      It.Is<CellPoint>(cp => cp.ColumnIndex == 2 && cp.RowIndex == 1),
                                                      boundPriceCells));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.SameAs(worksheetBindingUpdate));
        }

        [Test]
        public void ShouldNotApplySpreadsheetBindings_On_ImportPricesCommand_With_EmptyClipboard()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithClipboardPriceCells(new List<List<TenorPriceCell>>())
                                                                         .Build();

            var args = new ImportPriceGridArgs(1, new List<WorksheetDataBinding>(), Mock.Of<CellRange>());

            // ACT
            testObjects.ViewModel.ImportPriceGridCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.ImportPriceCellsService)
                .Verify(c => c.GetImportBindingsUpdate(It.IsAny<CellPoint>(), 
                                                       It.IsAny<bool>(),
                                                       It.IsAny<IEnumerable<IList<TenorPriceCell>>>(), 
                                                       It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()), 
                        Times.Never);
        }

        [Test]
        public void ShouldShowDialog_On_ImportPricesException()
        {
            var cell1 = new TenorPriceCell(1, 20230101, new PriceValue());
            var cell2 = new TenorPriceCell(1, 20230201, new PriceValue());

            var clipboardCells = new List<List<TenorPriceCell>>
                                 {
                                     new() { cell1, cell2 }
                                 };

            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithClipboardPriceCells(clipboardCells)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithImportPriceCellsException(error)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();
            var importTarget = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1 && r.TopRowIndex == 1);

            var worksheetDataBindingArgs = new ImportPriceGridArgs(1, worksheetDataBindings, importTarget);

            // ACT
            testObjects.ViewModel.ImportPriceGridCommand.Execute(worksheetDataBindingArgs);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region ClearContentsCommand

        [Test]
        public void ShouldRemoveBindings_And_ClearContents_And_UpdateSettings_On_ClearContentsCommand()
        {
            var cellPointCol1 = new CellPoint(1, 1);
            var cellPointCol2 = new CellPoint(2, 1);

            var cell1 = Defaults.TenorPriceCell();
            var cell2 = Defaults.TenorPriceCell();
            var cell3 = Defaults.TenorPriceCell();
            var cell4 = Defaults.TenorPriceCell();
            var cell5 = Defaults.TenorPriceCell();
            var cell6 = Defaults.TenorPriceCell();

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>> 
                                  {
                                      { new ColumnCellRange(1, 1, 3), new List<TenorPriceCell> { cell1, cell2, cell3 } },
                                      { new ColumnCellRange(2, 1, 3), new List<TenorPriceCell> { cell4, cell5, cell6 } }
                                  };

            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                {
                                    { cellPointCol1, new List<TenorPriceCell> { cell1 } },
                                    { cellPointCol2, new List<TenorPriceCell> { cell4 } }
                                };

            var bindingsToRemove = new[] { cellPointCol1, cellPointCol2 };

            var priceCellRangeBindingsUpdate = new PriceCellRangeBindingsUpdate(bindingsToAdd,
                                                                                bindingsToRemove);

            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(2);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithClearBindingsUpdate(priceCellRangeBindingsUpdate)
                                                                         .WithWorksheetBindingUpdate(worksheetBindingUpdate)
                                                                         .Build();

            var worksheetDataBindingRangeCol1 = Mock.Of<WorksheetDataBinding>(b => b.Range == Mock.Of<CellRange>(r => r.LeftColumnIndex == 1
                                                                                                                   && r.TopRowIndex == 1));

            var worksheetDataBindingRangeCol2 = Mock.Of<WorksheetDataBinding>(b => b.Range == Mock.Of<CellRange>(r => r.LeftColumnIndex == 2
                                                                                                                      && r.TopRowIndex == 1));

            var worksheetDataBindings = new List<WorksheetDataBinding>
                                        {
                                            worksheetDataBindingRangeCol1,
                                            worksheetDataBindingRangeCol2
                                        };

            var clearTarget = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1
                                                      && r.RightColumnIndex == 2
                                                      && r.TopRowIndex == 2
                                                      && r.BottomRowIndex == 3);

            var clearContentsArgs = new ClearContentsArgs(2, worksheetDataBindings, clearTarget);

            // ACT
            testObjects.ViewModel.ClearContentsCommand.Execute(clearContentsArgs);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCellsByColumnCellRange(2));

            Mock.Get(testObjects.ClearBindingsService)
                .Verify(b => b.GetClearBindingsUpdate(new CellPoint(1, 2), new CellPoint(2, 3), boundPriceCells));

            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 2, bindingsToAdd, bindingsToRemove));

            Mock.Get(testObjects.WorksheetBindingUpdateService)
                .Verify(w => w.GetWorksheetBindingUpdate(2,
                                                         priceCellRangeBindingsUpdate,
                                                         worksheetDataBindings));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.SameAs(worksheetBindingUpdate));
        }

        [Test]
        public void ShouldShowDialog_On_ClearContentsException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithClearBindingsException(error)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();
            var clearTarget = Mock.Of<CellRange>();

            var clearContentsArgs = new ClearContentsArgs(1, worksheetDataBindings, clearTarget);

            // ACT
            testObjects.ViewModel.ClearContentsCommand.Execute(clearContentsArgs);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region CopyPasteCommand

        [Test]
        public void ShouldExtendTenors_On_PasteCellRange_With_CopyTenors()
        {
            var tenorCellRanges = new SortedList<ColumnCellRange, IList<DateTime>>
                                  {
                                      { new ColumnCellRange(1, 1, 1), new[] { DateTime.MinValue } }
                                  };

            var tenorsUpdate = new WorksheetTenorsUpdate(1, tenorCellRanges);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithPasteWorksheetTenorsUpdate(tenorsUpdate)
                                                                         .WithClearBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .WithImportPriceCellsBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .Build();

            var copyArea = Mock.Of<CellRange>();
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1 && r.TopRowIndex == 2 && r.RowCount == 3);

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var copyPasteArgs = new CopyPasteArgs(1, copyArea, pasteArea, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.CopyPasteCommand.Execute(copyPasteArgs);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCellsByColumnCellRange(1));

            Mock.Get(testObjects.PasteExtendTenorsService)
                .Verify(t => t.GetTenorsUpdate(1, copyArea, pasteArea));

            Assert.That(testObjects.ViewModel.WorksheetTenorsUpdate, Is.SameAs(tenorsUpdate));
        }

        [Test]
        public void ShouldUpdateBindings_When_ExtendTenors_With_BindingsToRemove()
        {
            var tenorCellRanges = new SortedList<ColumnCellRange, IList<DateTime>>
                                  {
                                      { new ColumnCellRange(1, 1, 1), new[] { DateTime.MinValue } }
                                  };

            var tenorsUpdate = new WorksheetTenorsUpdate(1, tenorCellRanges);

            var tenorBindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>();
            var tenorBindingsToRemove = new[] { new CellPoint(0, 0) };

            var tenorBindingsUpdate = new PriceCellRangeBindingsUpdate(tenorBindingsToAdd,
                                                                       tenorBindingsToRemove);

            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(1);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithPasteWorksheetTenorsUpdate(tenorsUpdate)
                                                                         .WithClearBindingsUpdate(tenorBindingsUpdate)
                                                                         .WithImportPriceCellsBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .WithWorksheetBindingUpdate(worksheetBindingUpdate)
                                                                         .Build();
            var copyArea = Mock.Of<CellRange>();
            var pasteArea = Mock.Of<CellRange>();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var copyPasteArgs = new CopyPasteArgs(2, copyArea, pasteArea, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.CopyPasteCommand.Execute(copyPasteArgs);

            // ASSERT
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 2, tenorBindingsToAdd, tenorBindingsToRemove));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.SameAs(worksheetBindingUpdate));
        }

        [Test]
        public void ShouldImportPriceCells_On_PasteCellRange_Below_CopyArea()
        {
            var cellRange = new ColumnCellRange(1, 1, 2);

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>> 
                                  {
                                      { cellRange, new List<TenorPriceCell>() }
                                  };

            var tenorPriceRow = new TenorPriceRowViewModel(new TenorEnvelope(new MonthlyTenor(2024, 1)));

            var tenorPriceRows = new[] { tenorPriceRow };

            var import = new List<IList<TenorPriceCell>> { new[] { Defaults.TenorPriceCell() } };

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithDataSourceItems(tenorPriceRows)
                                                                         .WithPasteWorksheetTenorsUpdate(Defaults.WorksheetTenorsUpdate(1))
                                                                         .WithPasteImportPriceCells(import)
                                                                         .WithImportPriceCellsBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .Build();

            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1
                                                && r.TopRowIndex == 1
                                                && r.RightColumnIndex == 1
                                                && r.BottomRowIndex == 2);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1
                                                 && r.TopRowIndex == 2
                                                 && r.RowCount == 5);

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var copyPasteArgs = new CopyPasteArgs(1, copyArea, pasteArea, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.CopyPasteCommand.Execute(copyPasteArgs);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCellsByColumnCellRange(1));

            Mock.Get(testObjects.PasteImportPriceCellsService)
                .Verify(i => i.GetImportPriceCells(copyArea, 
                                                   pasteArea, 
                                                   boundPriceCells, 
                                                   It.Is<IList<TenorPriceRowViewModel>>(items => items.SequenceEqual(tenorPriceRows))));

            Mock.Get(testObjects.ImportPriceCellsService)
                .Verify(i => i.GetImportBindingsUpdate(It.Is<CellPoint>(p => p.ColumnIndex == 1 && p.RowIndex == 2),
                                                       false,
                                                       import, 
                                                       boundPriceCells));
        }

        [Test]
        public void ShouldUpdateBindings_When_ImportPriceCells_With_BindingsToAdd()
        {
            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                {
                                    { new CellPoint(1, 2), new[]{Defaults.TenorPriceCell()} }
                                };

            var bindingsToRemove = Array.Empty<CellPoint>();

            var bindingsUpdate = new PriceCellRangeBindingsUpdate(bindingsToAdd,
                                                                  bindingsToRemove);

            var cellRange = new ColumnCellRange(1, 1, 2);

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { cellRange, new List<TenorPriceCell>() }
                                  };

            var tenorPriceRow = new TenorPriceRowViewModel(new TenorEnvelope(new MonthlyTenor(2024, 1)));

            var tenorPriceRows = new[] { tenorPriceRow };

            var import = new List<IList<TenorPriceCell>> { new[] { Defaults.TenorPriceCell() } };

            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(1);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceCells)
                                                                         .WithDataSourceItems(tenorPriceRows)
                                                                         .WithPasteWorksheetTenorsUpdate(Defaults.WorksheetTenorsUpdate(1))
                                                                         .WithPasteImportPriceCells(import)
                                                                         .WithImportPriceCellsBindingsUpdate(bindingsUpdate)
                                                                         .WithWorksheetBindingUpdate(worksheetBindingUpdate)
                                                                         .Build();


            var copyArea = Mock.Of<CellRange>();
            var pasteArea = Mock.Of<CellRange>();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var copyPasteArgs = new CopyPasteArgs(2, copyArea, pasteArea, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.CopyPasteCommand.Execute(copyPasteArgs);

            // ASSERT
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 2, bindingsToAdd, bindingsToRemove));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.SameAs(worksheetBindingUpdate));
        }

        [Test]
        public void ShouldClearCells_When_ImportPriceCells_With_BindingsToAdd()
        {
            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                {
                                    { new CellPoint(1, 4), new[]{Defaults.TenorPriceCell()} }
                                };

            var bindingsToRemove = Array.Empty<CellPoint>();

            var bindingsUpdate = new PriceCellRangeBindingsUpdate(bindingsToAdd,
                                                                  bindingsToRemove);

            var cellRangesToClear = new List<ColumnCellRange> { new(1, 1, 3) };

            var clearCellsUpdate = new WorksheetClearCellsUpdate(1, cellRangesToClear);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithImportPriceCellsBindingsUpdate(bindingsUpdate)
                                                                         .WithWorksheetClearCellsUpdate(clearCellsUpdate)
                                                                         .Build();


            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var pasteArea = Mock.Of<CellRange>(r => r.TopRowIndex == 1 && r.BottomRowIndex == 3);

            var copyPasteArgs = new CopyPasteArgs(2, Mock.Of<CellRange>(), pasteArea, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.CopyPasteCommand.Execute(copyPasteArgs);

            // ASSERT
            Mock.Get(testObjects.WorksheetClearCellsUpdateService)
                .Verify(c => c.GetWorksheetClearCellsUpdate(2, 1, 3, bindingsToAdd));

            Assert.That(testObjects.ViewModel.WorksheetClearCellsUpdate, Is.SameAs(clearCellsUpdate));
        }

        [Test]
        public void ShouldShowDialog_On_CopyException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithPasteExtendTenorsException(error)
                                                                         .Build();

            var copyArea = Mock.Of<CellRange>();
            var pasteArea = Mock.Of<CellRange>();

            var copyPasteArgs = new CopyPasteArgs(1, copyArea, pasteArea, new List<WorksheetDataBinding>());

            // ACT
            testObjects.ViewModel.CopyPasteCommand.Execute(copyPasteArgs);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region DragFillRangeCommand

        [Test]
        public void ShouldExtendTenors_On_DragFillRange_With_CopyTenors()
        {
            var tenorCellRanges = new SortedList<ColumnCellRange, IList<DateTime>>
                                  {
                                      { new ColumnCellRange(1, 1, 1), new[] { DateTime.MinValue } }
                                  };

            var tenorsUpdate = new WorksheetTenorsUpdate(1, tenorCellRanges);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithPasteWorksheetTenorsUpdate(tenorsUpdate)
                                                                         .WithClearBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .WithImportPriceCellsBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .Build();

            var copyArea = Mock.Of<CellRange>();
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1 && r.TopRowIndex == 2 && r.RowCount == 3);

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var dragFillRangeArgs = new DragFillRangeArgs(1, copyArea, pasteArea, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.DragFillRangeCommand.Execute(dragFillRangeArgs);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCellsByColumnCellRange(1));

            Mock.Get(testObjects.PasteExtendTenorsService)
                .Verify(t => t.GetTenorsUpdate(1, copyArea, pasteArea));

            Assert.That(testObjects.ViewModel.WorksheetTenorsUpdate, Is.SameAs(tenorsUpdate));
        }

        [Test]
        public void ShouldShowDialog_On_DragFillRangeException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithPasteExtendTenorsException(error)
                                                                         .Build();

            var copyArea = Mock.Of<CellRange>();
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1 && r.TopRowIndex == 2 && r.RowCount == 3);

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var dragFillRangeArgs = new DragFillRangeArgs(1, copyArea, pasteArea, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.DragFillRangeCommand.Execute(dragFillRangeArgs);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region InsertColumnsCommand

        [Test]
        public void ShouldUpdateCache_On_InsertColumns()
        {
            var cellPoint = new CellPoint(1, 1);

            var boundPriceCells = new Dictionary<CellPoint, IList<TenorPriceCell>> 
                                  {
                                      { cellPoint, new List<TenorPriceCell>() }
                                  };

            var shiftBindingsUpdate = Defaults.PriceCellRangeBindingsUpdate();

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCells(boundPriceCells)
                                                                         .WithShiftColumnsBindingsUpdate(shiftBindingsUpdate)
                                                                         .Build();

            var args = new InsertColumnsArgs(2, 1, 2);

            // ACT
            testObjects.ViewModel.InsertColumnsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCells(2));

            Mock.Get(testObjects.ColumnShiftService)
                .Verify(c => c.GetShiftedColumnsBindingsUpdate(1, 2, boundPriceCells));
            
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 
                                                                       2,
                                                                       shiftBindingsUpdate.CellRangesToAdd, 
                                                                       shiftBindingsUpdate.CellRangesToRemove));
        }

        [Test]
        public void ShouldShowDialog_On_InsertColumnsException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCells(new Dictionary<CellPoint, IList<TenorPriceCell>>())
                                                                         .WithColumnShiftException(error)
                                                                         .Build();

            var args = new InsertColumnsArgs(1, 1, 3);

            // ACT
            testObjects.ViewModel.InsertColumnsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region PreRemoveColumnsCommand

        [Test]
        public void ShouldGetRemoveColumnsBindingUpdate_On_PreRemoveColumnsCommand_With_WorksheetDataBindings()
        {
            var cellPoint = new CellPoint(1, 1);

            var boundPriceCells = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                  {
                                      { cellPoint, new List<TenorPriceCell>() }
                                  };

            var bindingUpdateArgs = new WorksheetDataBindingsUpdate(WorksheetDataBindingsUpdateAction.Update, 1, null, null);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithRemoveColumnBindingUpdate(bindingUpdateArgs)
                                                                         .WithBoundPriceCells(boundPriceCells)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding> { Mock.Of<WorksheetDataBinding>() };

            var args = new PreRemoveColumnsArgs(1, 2, 3, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.PreRemoveColumnsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.RemoveColumnsBindingUpdateService)
                .Verify(r => r.GetRemoveColumnsBindingUpdate(args));

            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCells(1));
        }

        [Test]
        public void ShouldNotGetBindingsUpdate_On_PreRemoveColumnsCommand_With_WorksheetDataBindingsEmpty()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var removeColumnArgs = new PreRemoveColumnsArgs(1, 2, 3, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.PreRemoveColumnsCommand.Execute(removeColumnArgs);

            // ASSERT
            Mock.Get(testObjects.RemoveColumnsBindingUpdateService)
                .Verify(r => r.GetRemoveColumnsBindingUpdate(removeColumnArgs), Times.Never);
        }

        [Test]
        public void ShouldRemoveExistingColumnBindings_On_PreRemoveColumnsCommand_With_WorksheetDataBindings()
        {
            var cellPoint = new CellPoint(2, 9);

            var columnPriceCells = new List<TenorPriceCell> { Defaults.TenorPriceCell() };

            var boundPriceCells = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                  {
                                      { cellPoint, columnPriceCells }
                                  };

            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(2);

            var worksheetDataBindings = new List<WorksheetDataBinding> { Mock.Of<WorksheetDataBinding>() };

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithRemoveColumnBindingUpdate(worksheetBindingUpdate)
                                                                         .WithBoundPriceCells(boundPriceCells)
                                                                         .Build();

            var removeColumnArgs = new PreRemoveColumnsArgs(2, 2, 3, worksheetDataBindings);

            var expectedCellPoints = new[] { cellPoint };

            // ACT
            testObjects.ViewModel.PreRemoveColumnsCommand.Execute(removeColumnArgs);

            // ASSERT
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 
                                                                       2,
                                                                       It.Is<Dictionary<CellPoint, IList<TenorPriceCell>>>(l => l.Count == 0), 
                                                                       It.Is<IList<CellPoint>>(cp => cp.SequenceEqual(expectedCellPoints))));
        }

        [Test]
        public void ShouldShowDialog_On_PreRemoveColumnException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithRemoveColumnsException(error)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding> { Mock.Of<WorksheetDataBinding>() };

            var args = new PreRemoveColumnsArgs(1, 2, 3, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.PreRemoveColumnsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region PostRemoveColumnsCommand

        [Test]
        public void ShouldCheckForShiftedColumns_On_PostRemoveColumnsCommand()
        {
            var cellPoint = new CellPoint(2, 9);

            var columnPriceCells = new List<TenorPriceCell> { Defaults.TenorPriceCell() };

            var boundPriceCells = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                  {
                                      { cellPoint, columnPriceCells }
                                  };

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCells(boundPriceCells)
                                                                         .WithShiftColumnsBindingsUpdate(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .Build();

            var args = new PostRemoveColumnsArgs(1, 2, 3);

            // ACT
            testObjects.ViewModel.PostRemoveColumnsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.ColumnShiftService)
                .Verify(c => c.GetShiftedColumnsBindingsUpdate(2, -2, boundPriceCells));
        }

        [Test]
        public void ShouldUpdateShiftedColumns_On_PostRemoveColumnsCommand()
        {
            var cellPoint = new CellPoint(4, 1);

            var columnPriceCells = new List<TenorPriceCell> { Defaults.TenorPriceCell() };

            var boundPriceCells = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                  {
                                      { cellPoint, columnPriceCells }
                                  };

            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                {
                                    { new CellPoint(1, 1), new []{Defaults.TenorPriceCell()} }
                                };

            var bindingsToRemove = new[] { new CellPoint(4, 1) };

            var bindingsUpdate = new PriceCellRangeBindingsUpdate(bindingsToAdd,
                                                                  bindingsToRemove);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCells(boundPriceCells)
                                                                         .WithShiftColumnsBindingsUpdate(bindingsUpdate)
                                                                         .Build();

            var args = new PostRemoveColumnsArgs(2, 2, 3);

            // ACT
            testObjects.ViewModel.PostRemoveColumnsCommand.Execute(args);

            //// ASSERT
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 2, bindingsToAdd, bindingsToRemove));
        }

        [Test]
        public void ShouldShowDialog_On_PostRemoveColumnsException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCells(new Dictionary<CellPoint, IList<TenorPriceCell>>())
                                                                         .WithColumnShiftException(error)
                                                                         .Build();

            var args = new PostRemoveColumnsArgs(1, 2, 3);

            // ACT
            testObjects.ViewModel.PostRemoveColumnsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region InsertRowsCommand

        [Test]
        public void ShouldUpdateCacheOnly_On_InsertRows_With_ShiftedRows()
        {
            var shiftedRowsBindingsUpdate = new PriceCellRangeBindingsUpdate(new Dictionary<CellPoint, IList<TenorPriceCell>>(),
                                                                             new[] { new CellPoint(0, 1) });

            var columnCellRange = new ColumnCellRange(0, 1, 1);

            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { columnCellRange, new List<TenorPriceCell>() }
                                    };

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceColumns)
                                                                         .WithShiftedRowsResult(shiftedRowsBindingsUpdate)
                                                                         .WithSplitRowsResult(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var args = new InsertRowsArgs(2, 1, 2, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.InsertRowsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCellsByColumnCellRange(2));

            Mock.Get(testObjects.InsertRowsService)
                .Verify(c => c.GetShiftedBoundPriceCells(1, 2, boundPriceColumns));

            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1,
                                                                       2,
                                                                       shiftedRowsBindingsUpdate.CellRangesToAdd, 
                                                                       shiftedRowsBindingsUpdate.CellRangesToRemove));

            Mock.Get(testObjects.WorksheetBindingUpdateService)
                .Verify(w => w.GetWorksheetBindingUpdate(2,
                                                         It.IsAny<PriceCellRangeBindingsUpdate>(),
                                                         It.IsAny<IEnumerable<WorksheetDataBinding>>()), Times.Never);
        }

        [Test]
        public void ShouldUpdateCacheAndWorksheetBindings_On_InsertRows_With_SplitRows()
        {
            var splitRowsBindingsUpdate = new PriceCellRangeBindingsUpdate(new Dictionary<CellPoint, IList<TenorPriceCell>>(),
                                                                           new[] { new CellPoint(0, 1) });

            var columnCellRange = new ColumnCellRange(0, 1, 1);

            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { columnCellRange, new List<TenorPriceCell>() }
                                    };

            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(2);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceColumns)
                                                                         .WithShiftedRowsResult(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .WithSplitRowsResult(splitRowsBindingsUpdate)
                                                                         .WithWorksheetBindingUpdate(worksheetBindingUpdate)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var args = new InsertRowsArgs(2, 1, 2, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.InsertRowsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCellsByColumnCellRange(2));

            Mock.Get(testObjects.InsertRowsService)
                .Verify(c => c.GetSplitRangeBoundPriceCells(1, 2, boundPriceColumns));

            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1,
                                                                       2,
                                                                       splitRowsBindingsUpdate.CellRangesToAdd,
                                                                       splitRowsBindingsUpdate.CellRangesToRemove));

            Mock.Get(testObjects.WorksheetBindingUpdateService)
                .Verify(w => w.GetWorksheetBindingUpdate(2,
                                                         splitRowsBindingsUpdate,
                                                         worksheetDataBindings));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.SameAs(worksheetBindingUpdate));
        }

        [Test]
        public void ShouldNotUpdateCache_On_InsertRows_With_NoChanges()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithShiftedRowsResult(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .WithSplitRowsResult(Defaults.PriceCellRangeBindingsUpdate())
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var args = new InsertRowsArgs(2, 1, 2, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.InsertRowsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1,
                                                                       2,
                                                                       It.IsAny<Dictionary<CellPoint, IList<TenorPriceCell>>>(),
                                                                       It.IsAny<IList<CellPoint>>()), Times.Never);
        }

        [Test]
        public void ShouldShowDialog_On_InsertRowsException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithInsertRowsException(error)
                                                                         .Build();

            var args = new InsertRowsArgs(1, 1, 3, new List<WorksheetDataBinding>());

            // ACT
            testObjects.ViewModel.InsertRowsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region RemoveRowsCommand

        [Test]
        public void ShouldUpdateCacheOnly_On_RemoveRows_With_ShiftedOrModified()
        {
            var removeRowsBindingsUpdate = Defaults.PriceCellRangeBindingsUpdate();

            var columnCellRange = new ColumnCellRange(0, 1, 1);

            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { columnCellRange, new List<TenorPriceCell>() }
                                    };

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(boundPriceColumns)
                                                                         .WithRemoveRowsResult(removeRowsBindingsUpdate)
                                                                         .Build();

            var args = new RemoveRowsArgs(2, 1, 2, new List<WorksheetDataBinding>());

            // ACT
            testObjects.ViewModel.RemoveRowsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(c => c.GetWorksheetBoundPriceCellsByColumnCellRange(2));

            Mock.Get(testObjects.RemoveRowsService)
                .Verify(c => c.GetShiftedOrModifiedPriceCells(1, 2, boundPriceColumns));

            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.UpdateBindingsCacheAndDashboardSettings(1, 
                                                                       2,
                                                                       removeRowsBindingsUpdate.CellRangesToAdd, 
                                                                       removeRowsBindingsUpdate.CellRangesToRemove));

            Mock.Get(testObjects.WorksheetBindingUpdateService)
                .Verify(w => w.GetWorksheetBindingUpdate(It.IsAny<int>(),
                                                         It.IsAny<PriceCellRangeBindingsUpdate>(),
                                                         It.IsAny<IEnumerable<WorksheetDataBinding>>()), Times.Never);
        }

        [Test]
        public void ShouldUpdateCacheAndWorksheetBindings_On_RemoveRows_With_MergeAdjacent()
        {
            var removeRowsBindingsUpdate = Defaults.PriceCellRangeBindingsUpdate();

            var mergeRowsBindingsUpdate = new PriceCellRangeBindingsUpdate(new Dictionary<CellPoint, IList<TenorPriceCell>>(),
                                                                           new CellPoint[] { new (0, 1) });

            var cacheUpdate = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();
            
            var worksheetBindingUpdate = Defaults.WorksheetDataBindingsUpdate(2);

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithBindingsCacheUpdate(cacheUpdate)
                                                                         .WithRemoveRowsResult(removeRowsBindingsUpdate)
                                                                         .WithMergeColumnCellRangesResult(mergeRowsBindingsUpdate)
                                                                         .WithWorksheetBindingUpdate(worksheetBindingUpdate)
                                                                         .Build();

            var worksheetDataBindings = new List<WorksheetDataBinding>();

            var args = new RemoveRowsArgs(2, 1, 2, worksheetDataBindings);

            // ACT
            testObjects.ViewModel.RemoveRowsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.MergeColumnCellRangesService)
                .Verify(m => m.MergeAdjacentColumnCellRanges(1, cacheUpdate));

            Mock.Get(testObjects.WorksheetBindingUpdateService)
                .Verify(w => w.GetWorksheetBindingUpdate(2,
                                                         mergeRowsBindingsUpdate,
                                                         worksheetDataBindings));

            Assert.That(testObjects.ViewModel.WorksheetDataBindingsUpdate, Is.SameAs(worksheetBindingUpdate));
        }

        [Test]
        public void ShouldShowDialog_On_RemoveRowsException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithBoundPriceCellColumns(new Dictionary<ColumnCellRange, IList<TenorPriceCell>>())
                                                                         .WithRemoveRowsException(error)
                                                                         .Build();

            var args = new RemoveRowsArgs(1, 1, 2, new List<WorksheetDataBinding>());

            // ACT
            testObjects.ViewModel.RemoveRowsCommand.Execute(args);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region RemoveWorksheetCommand

        [Test]
        public void ShouldRemoveWorksheet_On_RemoveWorksheetCommand()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .Build();

            // ACT
            testObjects.ViewModel.RemoveWorksheetCommand.Execute(2);

            // ASSERT
            Mock.Get(testObjects.ScratchPadBindingsCache)
                .Verify(b => b.RemoveWorksheet(1, 2));
        }

        [Test]
        public void ShouldHandleInvalidWorksheetId_On_RemoveWorksheetCommand()
        {
            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .Build();

            // ACT
            testObjects.ViewModel.RemoveWorksheetCommand.Execute(null);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error), Times.Never);
        }

        [Test]
        public void ShouldShowDialog_On_RemoveWorksheetException()
        {
            var error = new Exception("error");

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithRemoveWorksheetException(error)
                                                                         .Build();
            // ACT
            testObjects.ViewModel.RemoveWorksheetCommand.Execute(2);

            // ASSERT
            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowMessageDialog(It.IsAny<string>(), MessageBoxImage.Error));
        }

        #endregion

        #region Disposed

        [Test]
        public void ShouldNotGetBoundPriceCells_OnPriceCurves_When_Disposed()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ASSERT
            Mock.Get(testObjects.ScratchPadSettingsRestorationService)
                .Verify(s => s.GetPriceCellsFromSettings(It.IsAny<DashboardScratchPadSettings>(),
                                                         It.IsAny<Dictionary<LinkedCurve, List<TenorPriceCell>>>()), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var settings = new DashboardSettings();

            settings.ScratchPadSettings.WorksheetSettingsList.Add(new WorksheetSettings());

            var testObjects = new ScratchPadControllerTestObjectBuilder().WithInitialized(1)
                                                                         .WithDashboardSettingsLoaded(true)
                                                                         .WithDashboardSettings(settings)
                                                                         .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.PriceCurves.OnNext(testObjects.DefaultPriceCurves);

            // ASSERT
            Mock.Get(testObjects.ScratchPadSettingsRestorationService)
                .Verify(s => s.GetPriceCellsFromSettings(It.IsAny<DashboardScratchPadSettings>(),
                                                         It.IsAny<Dictionary<LinkedCurve, List<TenorPriceCell>>>()), Times.Never);
        }

        #endregion
    }
}
