﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Dsp.Gui.Dashboard.Common.Settings;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests
{
    [ExcludeFromCodeCoverage]
    internal class WorksheetBindingListComparer : IEqualityComparer<WorksheetBindingList>
    {
        public bool Equals(WorksheetBindingList x, WorksheetBindingList y)
        {
            if (ReferenceEquals(x, y))
                return true;

            if (ReferenceEquals(x, null))
                return false;

            if (ReferenceEquals(y, null))
                return false;

            if (x.GetType() != y.GetType()) 
                return false;

            return x.ColumnIndex == y.ColumnIndex
                   && x.RowIndex == y.RowIndex 
                   && x.BindingListItems.SequenceEqual(y.BindingListItems, new BindingListItemSettingComparer());
        }

        public int GetHashCode(WorksheetBindingList obj)
        {
            return HashCode.Combine(obj.ColumnIndex, obj.RowIndex, obj.BindingListItems);
        }
    }
}
