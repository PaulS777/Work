﻿using System;
using System.Linq;
using DevExpress.Spreadsheet;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Dashboard.ScratchPad.Services;
using NUnit.Framework;
using Moq;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class RemoveColumnsBindingUpdateServiceTests
    {
        [Test]
        public void ShouldGetDefaults_Where_NoBindings()
        {
            var bindings = Array.Empty<WorksheetDataBinding>();
            
            var args = new PreRemoveColumnsArgs(1, 2, 3, bindings);

            var service = new RemoveColumnsBindingUpdateService();

            // ACT
            var result = service.GetRemoveColumnsBindingUpdate(args);

            // ASSERT
            Assert.That(result.WorksheetId, Is.EqualTo(1));
            Assert.That(result.UpdateAction, Is.EqualTo(WorksheetDataBindingsUpdateAction.Update));
            Assert.That(result.BindingsToRemove, Is.Empty);
            Assert.That(result.BindingsToCreate, Is.Null);
        }

        [TestCase(2, 2, TestName = "Single Column Inside")]
        [TestCase(1, 2, TestName = "Multi Column Overlaps Start")]
        [TestCase(3, 4, TestName = "Multi Column Overlaps End")]
        [TestCase(1, 4, TestName = "Multi Column Starts Before Ends After")]
        [TestCase(2, 3, TestName = "Multi Column Matches Exact")]
        [TestCase(2, 4, TestName = "Multi Column Matches Starts Ends After")]
        [TestCase(2, 4, TestName = "Multi Column Starts After Matches End")]
        public void ShouldGetBindingsToRemove_Where_BindingColumns_Within_RemoveRange(int leftColumnIndex, int rightColumnIndex)
        {
            var removeRange = Mock.Of<CellRange>(r => r.LeftColumnIndex == leftColumnIndex 
                                                   && r.RightColumnIndex == rightColumnIndex);

            var bindings = new[] { Mock.Of<WorksheetDataBinding>(b => b.Range == removeRange) };

            var args = new PreRemoveColumnsArgs(1, 2, 3, bindings);

            var service = new RemoveColumnsBindingUpdateService();

            // ACT
            var result = service.GetRemoveColumnsBindingUpdate(args);

            // ASSERT
            Assert.That(result.BindingsToRemove.SequenceEqual(bindings));
        }

        [TestCase(1, 1, TestName = "Single Column Before Start")]
        [TestCase(4, 4, TestName = "Single Column After End")]
        public void ShouldGetEmptyBindingsToRemove_Where_BindingColumns_Outside_RemoveRange(int leftColumnIndex, int rightColumnIndex)
        {
            var removeRange = Mock.Of<CellRange>(r => r.LeftColumnIndex == leftColumnIndex
                                                   && r.RightColumnIndex == rightColumnIndex);

            var bindings = new[] { Mock.Of<WorksheetDataBinding>(b => b.Range == removeRange) };

            var args = new PreRemoveColumnsArgs(1, 2, 3, bindings);

            var service = new RemoveColumnsBindingUpdateService();

            // ACT
            var result = service.GetRemoveColumnsBindingUpdate(args);

            // ASSERT
            Assert.That(result.BindingsToRemove, Is.Empty);
        }
    }
}
