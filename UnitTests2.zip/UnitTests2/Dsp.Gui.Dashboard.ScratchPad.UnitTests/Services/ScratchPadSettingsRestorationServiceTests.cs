﻿using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.UnitTest.Helpers.Comparers;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class ScratchPadSettingsRestorationServiceTests
    {
        [Test]
        public void ShouldGetPriceCellsByWorksheetId_From_Settings()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve3 = new LinkedCurve(103, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = 20230101;
            var tenor2 = 20230102;

            var priceCell1 = new TenorPriceCell(101, tenor1, new PriceValue());
            var priceCell2 = new TenorPriceCell(101, tenor2, new PriceValue());

            var priceCell3 = new TenorPriceCell(102, tenor1, new PriceValue());
            var priceCell4 = new TenorPriceCell(102, tenor2, new PriceValue());

            var priceCell5 = new TenorPriceCell(103, tenor1, new PriceValue());
            var priceCell6 = new TenorPriceCell(103, tenor2, new PriceValue());

            var curveLookup = new Dictionary<LinkedCurve, List<TenorPriceCell>>
                              {
                                  { linkedCurve1, new List<TenorPriceCell>{priceCell1, priceCell2, Defaults.TenorPriceCell() }},
                                  { linkedCurve2, new List<TenorPriceCell>{priceCell3, priceCell4, Defaults.TenorPriceCell() }},
                                  { linkedCurve3, new List<TenorPriceCell>{priceCell5, priceCell6, Defaults.TenorPriceCell() }}
                              };

            var scratchPadSettings = new DashboardScratchPadSettings();

            var worksheet1 = new WorksheetSettings
            {
                WorksheetId = 1,
                WorksheetBindingListCollection = new List<WorksheetBindingList>
                                                                  {
                                                                      new()
                                                                      {
                                                                          ColumnIndex = 1,
                                                                          RowIndex = 1,
                                                                          BindingListItems = new List<BindingListItemSetting>
                                                                                             {
                                                                                                 new() { CurveId = 101, Tenor = tenor1 },
                                                                                                 new() { CurveId = 101, Tenor = tenor2 }
                                                                                             }
                                                                      },
                                                                      new()
                                                                      {
                                                                          ColumnIndex = 2,
                                                                          RowIndex = 1,
                                                                          BindingListItems = new List<BindingListItemSetting>
                                                                                             {
                                                                                                 new() { CurveId = 102, Tenor = tenor1 },
                                                                                                 new() { CurveId = 102, Tenor = tenor2 }
                                                                                             }
                                                                      }
                                                                  }
            };

            var worksheet2 = new WorksheetSettings
                             {
                                 WorksheetId = 2,
                                 WorksheetBindingListCollection = new List<WorksheetBindingList>
                                                                  {
                                                                      new()
                                                                      {
                                                                          ColumnIndex = 3,
                                                                          RowIndex = 1,
                                                                          BindingListItems = new List<BindingListItemSetting>
                                                                                             {
                                                                                                 new() { CurveId = 103, Tenor = tenor1 },
                                                                                                 new() { CurveId = 103, Tenor = tenor2 }
                                                                                             }
                                                                      }
                                                                  }
                             };

            scratchPadSettings.WorksheetSettingsList = new List<WorksheetSettings>
                                                     {
                                                         worksheet1, worksheet2
                                                     };

            var expectedWorksheetIds = new[] { 1, 2 };

            var expectedWorksheet1CellPoints = new[] { new CellPoint(1, 1), new CellPoint(2, 1) };
            var expectedWorksheet1PriceCells1 = new[] { priceCell1, priceCell2 };
            var expectedWorksheet1PriceCells2 = new[] { priceCell3, priceCell4 };

            var expectedWorksheet2CellPoints = new[] { new CellPoint(3, 1) };
            var expectedWorksheet2PriceCells1 = new[] { priceCell5, priceCell6 };

            var service = new ScratchPadSettingsRestorationService();

            // ACT
            var result = service.GetPriceCellsFromSettings(scratchPadSettings, curveLookup);

            // ASSERT
            Assert.That(result.Keys.SequenceEqual(expectedWorksheetIds));

            Assert.That(result[1].Keys.SequenceEqual(expectedWorksheet1CellPoints, new CellPointEqualityComparer()));
            Assert.That(result[1][new CellPoint(1, 1)].SequenceEqual(expectedWorksheet1PriceCells1));
            Assert.That(result[1][new CellPoint(2, 1)].SequenceEqual(expectedWorksheet1PriceCells2));

            Assert.That(result[2].Keys.SequenceEqual(expectedWorksheet2CellPoints, new CellPointEqualityComparer()));
            Assert.That(result[2][new CellPoint(3, 1)].SequenceEqual(expectedWorksheet2PriceCells1));
        }

        [Test]
        public void ShouldExcludePriceCells_When_CurveId_NotInSettings()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = 20230101;
            var tenor2 = 20230102;

            var priceCell1 = new TenorPriceCell(101, tenor1, new PriceValue());
            var priceCell2 = new TenorPriceCell(101, tenor2, new PriceValue());

            var curveLookup = new Dictionary<LinkedCurve, List<TenorPriceCell>>
                              {
                                  { linkedCurve1, new List<TenorPriceCell>{priceCell1, priceCell2, Defaults.TenorPriceCell() }}
                              };

            var scratchPadSettings = new DashboardScratchPadSettings();

            var worksheet1 = new WorksheetSettings
            {
                WorksheetId = 1,
                WorksheetBindingListCollection = new List<WorksheetBindingList>
                                                                  {
                                                                      new()
                                                                      {
                                                                          ColumnIndex = 1,
                                                                          RowIndex = 1,
                                                                          BindingListItems = new List<BindingListItemSetting>
                                                                                             {
                                                                                                 new() { CurveId = 101, Tenor = tenor1 },
                                                                                                 new() { CurveId = 101, Tenor = tenor2 }
                                                                                             }
                                                                      },
                                                                      new()
                                                                      {
                                                                          ColumnIndex = 2,
                                                                          RowIndex = 1,
                                                                          BindingListItems = new List<BindingListItemSetting>
                                                                                             {
                                                                                                 new() { CurveId = 99, Tenor = tenor1 },
                                                                                                 new() { CurveId = 99, Tenor = tenor2 }
                                                                                             }
                                                                      }
                                                                  }
            };

            scratchPadSettings.WorksheetSettingsList = new List<WorksheetSettings>
                                                       {
                                                           worksheet1
                                                       };

            var expectedWorksheetIds = new[] { 1 };

            var expectedWorksheet1CellPoints = new[] { new CellPoint(1, 1) };
            var expectedWorksheet1PriceCells1 = new[] { priceCell1, priceCell2 };

            var service = new ScratchPadSettingsRestorationService();

            // ACT
            var result = service.GetPriceCellsFromSettings(scratchPadSettings, curveLookup);

            // ASSERT
            Assert.That(result.Keys.SequenceEqual(expectedWorksheetIds));

            Assert.That(result[1].Keys.SequenceEqual(expectedWorksheet1CellPoints, new CellPointEqualityComparer()));
            Assert.That(result[1][new CellPoint(1, 1)].SequenceEqual(expectedWorksheet1PriceCells1));
        }

        [Test]
        public void ShouldExcludePriceCells_When_Tenor_NotInLookup()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = 20230101;
            var tenor2 = 20230102;

            var priceCell1 = new TenorPriceCell(101, tenor1, new PriceValue());

            var curveLookup = new Dictionary<LinkedCurve, List<TenorPriceCell>>
                              {
                                  { linkedCurve1, new List<TenorPriceCell>{priceCell1, Defaults.TenorPriceCell() }}
                              };

            var scratchPadSettings = new DashboardScratchPadSettings();

            var worksheet1 = new WorksheetSettings
            {
                WorksheetId = 1,
                WorksheetBindingListCollection = new List<WorksheetBindingList>
                                                                  {
                                                                      new()
                                                                      {
                                                                          ColumnIndex = 1,
                                                                          RowIndex = 1,
                                                                          BindingListItems = new List<BindingListItemSetting>
                                                                                             {
                                                                                                 new() { CurveId = 101, Tenor = tenor1 },
                                                                                                 new() { CurveId = 101, Tenor = tenor2 }
                                                                                             }
                                                                      }
                                                                  }
            };

            scratchPadSettings.WorksheetSettingsList = new List<WorksheetSettings>
                                                       {
                                                           worksheet1
                                                       };

            var expectedWorksheetIds = new[] { 1 };

            var expectedWorksheet1CellPoints = new[] { new CellPoint(1, 1) };
            var expectedWorksheet1PriceCells1 = new[] { priceCell1 }; 

            var service = new ScratchPadSettingsRestorationService();

            // ACT
            var result = service.GetPriceCellsFromSettings(scratchPadSettings, curveLookup);

            // ASSERT
            Assert.That(result.Keys.SequenceEqual(expectedWorksheetIds));

            Assert.That(result[1].Keys.SequenceEqual(expectedWorksheet1CellPoints, new CellPointEqualityComparer()));
            Assert.That(result[1][new CellPoint(1, 1)].SequenceEqual(expectedWorksheet1PriceCells1));
        }

        [Test]
        public void ShouldReturnEmpty_When_AllPriceCellCurveIds_NotExistsInSettings()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = 20230101;
            
            var priceCell1 = new TenorPriceCell(101, tenor1, new PriceValue());

            var curveLookup = new Dictionary<LinkedCurve, List<TenorPriceCell>>
                              {
                                  { linkedCurve1, new List<TenorPriceCell>{priceCell1}}
                              };

            var scratchPadSettings = new DashboardScratchPadSettings();

            var worksheet1 = new WorksheetSettings
            {
                WorksheetId = 1,
                WorksheetBindingListCollection = new List<WorksheetBindingList>
                                                                  {
                                                                      new()
                                                                      {
                                                                          ColumnIndex = 1,
                                                                          RowIndex = 1,
                                                                          BindingListItems = new List<BindingListItemSetting>
                                                                                             {
                                                                                                 new() { CurveId = 99, Tenor = tenor1 }
                                                                                             }
                                                                      }
                                                                  }
            };


            scratchPadSettings.WorksheetSettingsList = new List<WorksheetSettings> { worksheet1 };

            var service = new ScratchPadSettingsRestorationService();

            // ACT
            var result = service.GetPriceCellsFromSettings(scratchPadSettings, curveLookup);

            // ASSERT
            Assert.That(result, Is.Empty);
        }
    }
}
