﻿using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.UnitTest.Helpers.Comparers;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class ClearBindingsServiceTests
    {
        [Test]
        public void ShouldTruncatePrices_When_ClearPricesFromEndOfRange_SingleColumn()
        {
            var boundPrice1 = Defaults.TenorPriceCell();
            var boundPrice2 = Defaults.TenorPriceCell();
            var boundPrice3 = Defaults.TenorPriceCell();
            var boundPrice4 = Defaults.TenorPriceCell();

            var boundRange = new ColumnCellRange(0, 0, 3);

            var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                              {
                                  {
                                      boundRange, new[]
                                                  {
                                                      boundPrice1, boundPrice2, boundPrice3, boundPrice4
                                                  }
                                  }
                              };

            var clearTopLeft = new CellPoint(0, 2);
            var clearBottomRight = new CellPoint(0, 3);

            var service = new ClearBindingsService();

            // ACT
            var result = service.GetClearBindingsUpdate(clearTopLeft,
                                                        clearBottomRight,
                                                        boundPrices);

            // ASSERT
            var cellPoint = new CellPoint(0, 0);

            var expectedRemovals = new[] { cellPoint };
            var expectedCellPointsAdd = new[] { cellPoint };
            var expectedPriceCellsAdd = new[] { boundPrice1, boundPrice2 };

            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemovals, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCellsAdd));
        }
    }
}
