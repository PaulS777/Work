﻿using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Comparers;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class WorksheetClearCellsUpdateServiceTests 
    {
        [Test]
        public void ShouldReturnCellRangesToClear_When_PasteArea_Exceeds_BindingsTopRowIndex()
        {
            var bindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                           {
                               {
                                   new CellPoint(1, 3),   
                                   new List<TenorPriceCell>{Defaults.TenorPriceCell(), Defaults.TenorPriceCell() }
                               }
                           };

            var service = new WorksheetClearCellsUpdateService();

            var expected = new[] { new ColumnCellRange(1, 1, 2) };

            // ACT
            var result = service.GetWorksheetClearCellsUpdate(2, 1, 2, bindings);

            // ASSERT
            Assert.That(result.WorksheetId , Is.EqualTo(2));
            Assert.That(result.CellRangesToClear.SequenceEqual(expected, new ColumnCellRangeEqualityComparer()));
        }

        [Test]
        public void ShouldReturnCellRangesToClear_When_PasteArea_Exceeds_BindingsBottomRowIndex()
        {
            var bindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                           {
                               {
                                   new CellPoint(1, 3),
                                   new List<TenorPriceCell>{Defaults.TenorPriceCell(), Defaults.TenorPriceCell() }
                               }
                           };

            var service = new WorksheetClearCellsUpdateService();

            var expected = new[] { new ColumnCellRange(1, 5, 6) };

            // ACT
            var result = service.GetWorksheetClearCellsUpdate(2, 4, 6, bindings);

            // ASSERT
            Assert.That(result.CellRangesToClear.SequenceEqual(expected, new ColumnCellRangeEqualityComparer()));
        }

        [Test]
        public void ShouldReturnEmpty_When_PasteArea_Matches_BindingsArea()
        {
            var bindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                           {
                               {
                                   new CellPoint(1, 3),
                                   new List<TenorPriceCell>{Defaults.TenorPriceCell(), Defaults.TenorPriceCell() }
                               }
                           };

            var service = new WorksheetClearCellsUpdateService();

            // ACT
            var result = service.GetWorksheetClearCellsUpdate(2, 3, 4, bindings);

            // ASSERT
            Assert.That(result.CellRangesToClear, Is.Empty);
        }
    }
}
