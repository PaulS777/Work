﻿using System;
using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using DevExpress.Spreadsheet;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Moq;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class WorksheetBindingUpdateServiceTests
    {
        [Test]
        public void ShouldCreateBindingsToCreate_From_CellRanges()
        {
            var cellPoint = new CellPoint(1, 2);
           
            var cell1 = new TenorPriceCell(1, 20230101, new PriceValue());
            var cell2 = new TenorPriceCell(1, 20230201, new PriceValue());

            var cellRangesToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>> 
                                  {
                                      { cellPoint, new List<TenorPriceCell> { cell1, cell2 } }
                                  };

            var priceCellRangeBindingsUpdate = new PriceCellRangeBindingsUpdate(cellRangesToAdd,
                                                                                Array.Empty<CellPoint>());

            var service = new WorksheetBindingUpdateService();

            // ACT
            var result = service.GetWorksheetBindingUpdate(1, 
                                                           priceCellRangeBindingsUpdate, 
                                                           new List<WorksheetDataBinding>());

            var expectedBindings = new Dictionary<CellPoint, System.ComponentModel.BindingList<PriceValue>>
                                   {
                                       {
                                           cellPoint,
                                           new System.ComponentModel.BindingList<PriceValue>{cell1.Value, cell2.Value }
                                       }
                                   };
            // ASSERT
            Assert.That(result.BindingsToRemove, Is.Empty);
            Assert.That(result.BindingsToCreate.Keys.SequenceEqual(expectedBindings.Keys));
            Assert.That(result.BindingsToCreate.Values.SequenceEqual(expectedBindings.Values, new PriceValueBindingListComparer()));
        }

        [Test]
        public void ShouldCreateBindingsToRemove_When_CellRangesToRemove_Overlaps_Existing_Bindings()
        {
            var cellPointCol1 = new CellPoint(1, 1);
            var cellPointCol2 = new CellPoint(2, 1);

            var bindingsToRemove = new[] { cellPointCol1, cellPointCol2 };

            var priceCellRangeBindingsUpdate = new PriceCellRangeBindingsUpdate(new Dictionary<CellPoint, IList<TenorPriceCell>>(),
                                                                                bindingsToRemove);


            var cellRange1 = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1
                                                  && r.TopRowIndex == 1);

            var cellRange2 = Mock.Of<CellRange>(r => r.LeftColumnIndex == 2
                                                  && r.TopRowIndex == 1);

            var cellRange3 = Mock.Of<CellRange>(r => r.LeftColumnIndex == 3
                                                  && r.TopRowIndex == 1);

            var dataBinding1 = Mock.Of<WorksheetDataBinding>(b => b.Range == cellRange1);
            var dataBinding2 = Mock.Of<WorksheetDataBinding>(b => b.Range == cellRange2);

            var worksheetDataBindings = new List<WorksheetDataBinding>
                                        {
                                            dataBinding1,
                                            dataBinding2,
                                            Mock.Of<WorksheetDataBinding>(b => b.Range == cellRange3)
                                        };

            var service = new WorksheetBindingUpdateService();

            var expectedBindingsToRemove = new[]
                                           {
                                               dataBinding1,
                                               dataBinding2
                                           };

            // ACT
            var result = service.GetWorksheetBindingUpdate(1,
                                                           priceCellRangeBindingsUpdate,
                                                           worksheetDataBindings);

            // ASSERT
            Assert.That(result.WorksheetId, Is.EqualTo(1));
            Assert.That(result.BindingsToRemove.SequenceEqual(expectedBindingsToRemove));
        }
    }
}
