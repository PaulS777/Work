﻿using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.ScratchPad.Services;
using Moq;
using NUnit.Framework;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Comparers;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    internal interface IScratchPadBindingsCacheTestObjects
    {
        IBoundPriceCellsColumnLookup BoundPriceCellsColumnLookup { get; }
        IWorksheetSettingsFactory WorksheetSettingsFactory { get; }
        IDashboardSettingsService DashboardSettingsService { get; }
        ScratchPadBindingsCache ScratchPadBindingsCache { get; }
    }

    [TestFixture]
    public class ScratchPadBindingsCacheTests
    {
        private class ScratchPadBindingsCacheTestObjectBuilder
        {
            private WorksheetSettings _worksheetSettingsFactoryResult1;
            private WorksheetSettings _worksheetSettingsFactoryResult2;
            private Dictionary<CellPoint, IList<TenorPriceCell>> _applyPriceCellRangeBindingsResult;
            private Dictionary<ColumnCellRange, IList<TenorPriceCell>> _boundPriceCellsLookup;

            public ScratchPadBindingsCacheTestObjectBuilder WithWorksheetSettingsFactoryResult1(WorksheetSettings value)
            {
                _worksheetSettingsFactoryResult1 = value;
                return this;
            }

            public ScratchPadBindingsCacheTestObjectBuilder WithWorksheetSettingsFactoryResult2(WorksheetSettings value)
            {
                _worksheetSettingsFactoryResult2 = value;
                return this;
            }

            public ScratchPadBindingsCacheTestObjectBuilder WithApplyPriceCellRangeBindingsResult(Dictionary<CellPoint, IList<TenorPriceCell>> values)
            {
                _applyPriceCellRangeBindingsResult = values;
                return this;
            }

            public ScratchPadBindingsCacheTestObjectBuilder WithBoundPriceCellsLookup(Dictionary<ColumnCellRange, IList<TenorPriceCell>> values)
            {
                _boundPriceCellsLookup = values;
                return this;
            }

            public IScratchPadBindingsCacheTestObjects Build()
            {
                var testObjects = new Mock<IScratchPadBindingsCacheTestObjects>();

                var worksheetSettingsFactory = new Mock<IWorksheetSettingsFactory>();

                worksheetSettingsFactory.SetupSequence(f => f.CreateWorksheetSettings(It.IsAny<int>(), 
                                                                                      It.IsAny<Dictionary<CellPoint, IList<TenorPriceCell>>>()))
                                        .Returns(_worksheetSettingsFactoryResult1)
                                        .Returns(_worksheetSettingsFactoryResult2);

                testObjects.SetupGet(o => o.WorksheetSettingsFactory)
                           .Returns(worksheetSettingsFactory.Object);

                var boundPriceCellsColumnLookup = new Mock<IBoundPriceCellsColumnLookup>();

                boundPriceCellsColumnLookup.Setup(b => b.ApplyWorksheetBoundPriceCells(It.IsAny<int>(),
                                                                                       It.IsAny<Dictionary<CellPoint, IList<TenorPriceCell>>>(),
                                                                                       It.IsAny<IList<CellPoint>>()))
                                           .Returns(_applyPriceCellRangeBindingsResult);

                boundPriceCellsColumnLookup.Setup(b => b.GetWorksheetBoundPriceCellsByColumnCellRange(It.IsAny<int>()))
                                           .Returns(_boundPriceCellsLookup);

                testObjects.SetupGet(o => o.BoundPriceCellsColumnLookup)
                           .Returns(boundPriceCellsColumnLookup.Object);

                var dashboardSettingsService = new Mock<IDashboardSettingsService>();

                testObjects.SetupGet(o => o.DashboardSettingsService)
                           .Returns(dashboardSettingsService.Object);

                var scratchPadBindingsCache = new ScratchPadBindingsCache(boundPriceCellsColumnLookup.Object,
                                                                          worksheetSettingsFactory.Object,
                                                                          dashboardSettingsService.Object);

                testObjects.SetupGet(o => o.ScratchPadBindingsCache)
                           .Returns(scratchPadBindingsCache);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldReturnLookupReader()
        {
            var testObjects = new ScratchPadBindingsCacheTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ScratchPadBindingsCache.LookupReader();

            // ASSERT
            Assert.That(result, Is.SameAs(testObjects.BoundPriceCellsColumnLookup));
        }

        [Test]
        public void ShouldReturnDashboardSettingsReader()
        {
            var testObjects = new ScratchPadBindingsCacheTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ScratchPadBindingsCache.DashboardSettingsReader();

            // ASSERT
            Assert.That(result, Is.SameAs(testObjects.DashboardSettingsService));
        }

        [Test]
        public void ShouldRestoreLookup_And_UpdateSettings_When_RestoreBindingsCacheAndDashboardSettings()
        {
            var bindingsResult = new Dictionary<CellPoint, IList<TenorPriceCell>>();
            var worksheetSettings1 = new WorksheetSettings { WorksheetId = 1 };
            var worksheetSettings2 = new WorksheetSettings { WorksheetId = 2 };
            
            var boundPriceCells1 = new[] { Defaults.TenorPriceCell() };

            var boundPriceCellLookup1 = new Dictionary<CellPoint, IList<TenorPriceCell>> { { new CellPoint(0, 0), boundPriceCells1 } };


            var boundPriceCells2 = new[] { Defaults.TenorPriceCell() };

            var boundPriceCellLookup2 = new Dictionary<CellPoint, IList<TenorPriceCell>> { { new CellPoint(0, 0), boundPriceCells2 } };

            var boundPriceCells = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>>
                                  {
                                      {1, boundPriceCellLookup1},
                                      {2, boundPriceCellLookup2}
                                  };

            var testObjects = new ScratchPadBindingsCacheTestObjectBuilder().WithApplyPriceCellRangeBindingsResult(bindingsResult)
                                                                            .WithWorksheetSettingsFactoryResult1(worksheetSettings1)
                                                                            .WithWorksheetSettingsFactoryResult2(worksheetSettings2)
                                                                            .Build();

            var expectedWorksheetSettings = new[]
                                            {
                                                worksheetSettings1, worksheetSettings2
                                            };

            // ACT
            testObjects.ScratchPadBindingsCache.RestoreBindingsCacheAndDashboardSettings(1, boundPriceCells);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(b => b.RestoreBoundPriceCells(boundPriceCells));

            Mock.Get(testObjects.WorksheetSettingsFactory)
                .Verify(f => f.CreateWorksheetSettings(1, boundPriceCellLookup1), Times.Once);

            Mock.Get(testObjects.WorksheetSettingsFactory)
                .Verify(f => f.CreateWorksheetSettings(2, boundPriceCellLookup2), Times.Once);

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.UpdateScratchPadBindings(It.Is<IEnumerable<WorksheetSettings>>(w => w.SequenceEqual(expectedWorksheetSettings,
                                                                                                                   new WorksheetSettingsEqualityComparer())), 1));
        }

        [Test]
        public void ShouldUpdateLookupAndSettings_When_UpdateBindingsCacheAndDashboardSettings()
        {
            var bindingsResult = new Dictionary<CellPoint, IList<TenorPriceCell>>();
            var worksheetSettings = new WorksheetSettings { WorksheetId = 1 };
            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>();
            var bindingsToRemove = new List<CellPoint>();
            var boundPriceCellsLookup = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var testObjects = new ScratchPadBindingsCacheTestObjectBuilder().WithApplyPriceCellRangeBindingsResult(bindingsResult)
                                                                            .WithWorksheetSettingsFactoryResult1(worksheetSettings)
                                                                            .WithBoundPriceCellsLookup(boundPriceCellsLookup)
                                                                            .Build();

            // ACT
            var result =  testObjects.ScratchPadBindingsCache.UpdateBindingsCacheAndDashboardSettings(1, 
                                                                                                      2, 
                                                                                                      bindingsToAdd, 
                                                                                                      bindingsToRemove);

            // ASSERT
            Assert.That(result, Is.SameAs(boundPriceCellsLookup));

            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(b => b.ApplyWorksheetBoundPriceCells(2, bindingsToAdd, bindingsToRemove));

            Mock.Get(testObjects.WorksheetSettingsFactory)
                .Verify(f => f.CreateWorksheetSettings(2, bindingsResult));

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.UpdateScratchPadBindings(It.Is<IEnumerable<WorksheetSettings>>(w => w.SequenceEqual(new []{worksheetSettings},
                                                                                                                   new WorksheetSettingsEqualityComparer())), 1));
        }

        [Test]
        public void ShouldRestoreLookup_And_UpdateSettings_When_RemoveWorksheet()
        {
            var testObjects = new ScratchPadBindingsCacheTestObjectBuilder().Build();

            // ACT
            testObjects.ScratchPadBindingsCache.RemoveWorksheet(1, 2);

            // ASSERT
            Mock.Get(testObjects.BoundPriceCellsColumnLookup)
                .Verify(b => b.RemoveWorksheet(2));

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.RemoveWorksheetBindings(2, 1));
        }

    }
}
