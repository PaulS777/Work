﻿using Dsp.Gui.Dashboard.ScratchPad.Services;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.UnitTest.Helpers.Comparers;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class SelectUnboundPriceCellRangesServiceTests
    {
        [Test]
        public void ShouldGetPriceCellRange_With_Missing_CurveId_AllCellsInColumn()
        {
            var cellRange1 = new ColumnCellRange(1, 1, 2);

            var priceCell1 = new TenorPriceCell(101, 20240101, new PriceValue());
            var priceCell2 = new TenorPriceCell(101, 20240102, new PriceValue());

            var cellRange2 = new ColumnCellRange(3, 1, 2);

            var priceCell3 = new TenorPriceCell(102, 20240101, new PriceValue());
            var priceCell4 = new TenorPriceCell(102, 20240102, new PriceValue());

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { cellRange1, new[]{priceCell1, priceCell2} },
                                      { cellRange2, new[]{priceCell3, priceCell4} }
                                  };

            var curveIds = new[] { 101 };

            var service = new SelectUnboundPriceCellRangesService();

            var expected = new[] { cellRange2 };

            // ACT
            var result = service.GetUnboundPriceCellRanges(curveIds, boundPriceCells);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new ColumnCellRangeEqualityComparer()));
        }

        [Test]
        public void ShouldGetPriceCellRange_With_UnboundCellsStartOfColumnRange()
        {
            var cellRange1 = new ColumnCellRange(1, 1, 4);

            var priceCell1 = new TenorPriceCell(102, 20240101, new PriceValue()); // unbound
            var priceCell2 = new TenorPriceCell(102, 20240102, new PriceValue()); // unbound
            var priceCell3 = new TenorPriceCell(101, 20240103, new PriceValue());
            var priceCell4 = new TenorPriceCell(101, 20240104, new PriceValue());

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { 
                                          cellRange1, 
                                          new[]
                                          {
                                              priceCell1, priceCell2, priceCell3, priceCell4
                                          } },
                                  };

            var curveIds = new[] { 101 };

            var service = new SelectUnboundPriceCellRangesService();

            var expected = new[] { new ColumnCellRange(1, 1, 2) };

            // ACT
            var result = service.GetUnboundPriceCellRanges(curveIds, boundPriceCells);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new ColumnCellRangeEqualityComparer()));
        }

        [Test]
        public void ShouldGetPriceCellRange_With_UnboundCellsEndOfColumnRange()
        {
            var cellRange1 = new ColumnCellRange(1, 1, 4);

            var priceCell1 = new TenorPriceCell(101, 20240101, new PriceValue()); 
            var priceCell2 = new TenorPriceCell(101, 20240102, new PriceValue()); 
            var priceCell3 = new TenorPriceCell(102, 20240103, new PriceValue()); // unbound
            var priceCell4 = new TenorPriceCell(102, 20240104, new PriceValue()); // unbound

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      {
                                          cellRange1,
                                          new[]
                                          {
                                              priceCell1, priceCell2, priceCell3, priceCell4
                                          } },
                                  };

            var curveIds = new[] { 101 };

            var service = new SelectUnboundPriceCellRangesService();

            var expected = new[] { new ColumnCellRange(1, 3, 4) };

            // ACT
            var result = service.GetUnboundPriceCellRanges(curveIds, boundPriceCells);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new ColumnCellRangeEqualityComparer()));
        }

        [Test]
        public void ShouldGetPriceCellRange_With_UnboundCellsMidColumnRange()
        {
            var cellRange1 = new ColumnCellRange(1, 1, 4);

            var priceCell1 = new TenorPriceCell(101, 20240101, new PriceValue());
            var priceCell2 = new TenorPriceCell(102, 20240102, new PriceValue()); // unbound
            var priceCell3 = new TenorPriceCell(102, 20240103, new PriceValue()); // unbound
            var priceCell4 = new TenorPriceCell(101, 20240104, new PriceValue()); 

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      {
                                          cellRange1,
                                          new[]
                                          {
                                              priceCell1, priceCell2, priceCell3, priceCell4
                                          }
                                      }
                                  };

            var curveIds = new[] { 101 };

            var service = new SelectUnboundPriceCellRangesService();

            var expected = new[] { new ColumnCellRange(1, 2, 3) };

            // ACT
            var result = service.GetUnboundPriceCellRanges(curveIds, boundPriceCells);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new ColumnCellRangeEqualityComparer()));
        }

        [Test]
        public void ShouldGetPriceCellRanges_With_MultipleUnboundCellRanges_Within_ColumnRange()
        {
            var cellRange1 = new ColumnCellRange(1, 1, 4);

            var priceCell1 = new TenorPriceCell(102, 20240101, new PriceValue()); // unbound
            var priceCell2 = new TenorPriceCell(101, 20240102, new PriceValue()); 
            var priceCell3 = new TenorPriceCell(102, 20240103, new PriceValue()); // unbound
            var priceCell4 = new TenorPriceCell(102, 20240104, new PriceValue()); // unbound
            var priceCell5 = new TenorPriceCell(101, 20240105, new PriceValue());
            var priceCell6 = new TenorPriceCell(102, 20240106, new PriceValue()); // unbound

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      {
                                          cellRange1,
                                          new[]
                                          {
                                              priceCell1, priceCell2, priceCell3, priceCell4, priceCell5, priceCell6
                                          } },
                                  };

            var curveIds = new[] { 101 };

            var service = new SelectUnboundPriceCellRangesService();

            var expected = new[]
                           {
                               new ColumnCellRange(1, 1, 1),
                               new ColumnCellRange(1, 3, 4),
                               new ColumnCellRange(1, 6, 6)
                           };

            // ACT
            var result = service.GetUnboundPriceCellRanges(curveIds, boundPriceCells);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new ColumnCellRangeEqualityComparer()));
        }
    }
}
