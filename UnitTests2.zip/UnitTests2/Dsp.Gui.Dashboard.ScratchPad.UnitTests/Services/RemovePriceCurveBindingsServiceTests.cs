﻿using System.Collections.Generic;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Dashboard.ScratchPad.Services;
using Moq;
using NUnit.Framework;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.ViewModels.Price;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    internal interface IRemovePriceCurveBindingsServiceTestObjects
    {
        ISelectUnboundPriceCellRangesService SelectUnboundPriceCellRangesService { get; }
        IClearBindingsService ClearBindingsService { get; }
        RemovePriceCurveBindingsService RemovePriceCurveBindingsService { get; }
    }

    [TestFixture]
    public class RemovePriceCurveBindingsServiceTests
    {
        private class RemovePriceCurveBindingsServiceTestObjectBuilder
        {
            private List<ColumnCellRange> _unboundCellRanges;
            private PriceCellRangeBindingsUpdate _clearBindingsUpdate;
           
            public RemovePriceCurveBindingsServiceTestObjectBuilder WithUnboundCellRanges(List<ColumnCellRange> values)
            {
                _unboundCellRanges = values;
                return this;
            }

            public RemovePriceCurveBindingsServiceTestObjectBuilder WithClearBindingsUpdate(PriceCellRangeBindingsUpdate value)
            {
                _clearBindingsUpdate = value;
                return this;
            }

            public IRemovePriceCurveBindingsServiceTestObjects Build()
            {
                var testObjects = new Mock<IRemovePriceCurveBindingsServiceTestObjects>();

                var selectUnboundPriceCellRangesService = new Mock<ISelectUnboundPriceCellRangesService>();

                selectUnboundPriceCellRangesService.Setup(u => u.GetUnboundPriceCellRanges(It.IsAny<IList<int>>(),
                                                                                           It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                                   .Returns(_unboundCellRanges);

                testObjects.SetupGet(o => o.SelectUnboundPriceCellRangesService)
                           .Returns(selectUnboundPriceCellRangesService.Object);

                var clearBindingsService = new Mock<IClearBindingsService>();

                clearBindingsService.Setup(c => c.GetClearBindingsUpdate(It.IsAny<CellPoint>(),
                                                                         It.IsAny<CellPoint>(),
                                                                         It.IsAny<Dictionary<ColumnCellRange, IList<TenorPriceCell>>>()))
                                    .Returns(_clearBindingsUpdate);

                testObjects.SetupGet(o => o.ClearBindingsService)
                           .Returns(clearBindingsService.Object);

                var removePriceCurveBindingsService = new RemovePriceCurveBindingsService(selectUnboundPriceCellRangesService.Object,
                                                                                          clearBindingsService.Object);

                testObjects.SetupGet(o => o.RemovePriceCurveBindingsService)
                           .Returns(removePriceCurveBindingsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCheckUnboundPriceCells_And_ReturnFalse_If_Empty()
        {
            var curveIds = new[] { 101 };
            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var testObjects = new RemovePriceCurveBindingsServiceTestObjectBuilder().WithUnboundCellRanges(new List<ColumnCellRange>())
                                                                                    .Build();

            // ACT
            var result = testObjects.RemovePriceCurveBindingsService.TryGetRemovePriceCurveBindingUpdate(curveIds,
                                                                                                         boundPriceCells,
                                                                                                         out var priceCellRangeBindingsUpdate);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(priceCellRangeBindingsUpdate, Is.Null);
        }

        [Test]
        public void ShouldGetBindingsUpdate_When_UnboundPriceCells_SingleColumn()
        {
            var curveIds = new[] { 101 };
        
            var cellRange = new ColumnCellRange(1, 1, 2);

            var boundPriceCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { cellRange, new List<TenorPriceCell>() }
                                  };

            var unboundCellRanges = new List<ColumnCellRange>
                                    {
                                        cellRange
                                    };

            var bindingsToAdd = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                {
                                    { new CellPoint(1, 1), new List<TenorPriceCell>() }
                                };

            var bindingsToRemove = new[] { new CellPoint(1, 1) };

            var clearBindingsUpdate = new PriceCellRangeBindingsUpdate(bindingsToAdd, bindingsToRemove);


            var testObjects = new RemovePriceCurveBindingsServiceTestObjectBuilder().WithUnboundCellRanges(unboundCellRanges)
                                                                                    .WithClearBindingsUpdate(clearBindingsUpdate)
                                                                                    .Build();

            // ACT
            var result = testObjects.RemovePriceCurveBindingsService.TryGetRemovePriceCurveBindingUpdate(curveIds,
                                                                                                         boundPriceCells,
                                                                                                         out var priceCellRangeBindingsUpdate);

            // ASSERT
            Mock.Get(testObjects.ClearBindingsService)
                .Verify(b => b.GetClearBindingsUpdate(It.Is<CellPoint>(cp => cp.ColumnIndex == 1 && cp.RowIndex == 1),
                                                      It.Is<CellPoint>(cp => cp.ColumnIndex == 1 && cp.RowIndex == 2),
                                                      boundPriceCells));

            Assert.That(result, Is.True);

            Assert.That(priceCellRangeBindingsUpdate, Is.Not.Null);
            Assert.That(priceCellRangeBindingsUpdate.CellRangesToAdd.Count, Is.EqualTo(1));
            Assert.That(priceCellRangeBindingsUpdate.CellRangesToRemove.Count, Is.EqualTo(1));
        }
    }
}
