﻿using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.UnitTest.Helpers.Comparers;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class PriceCellRangeBindingUpdateServiceTests
    {
        [Test]
        public void ShouldReplaceTargetRangeBindings_When_PasteRangeMatchesTargetBindingRange()
        {
            const int col = 1;

            var targetColumnCellRange = new ColumnCellRange(col, 1, 2);

            var targetPrice1 = Defaults.TenorPriceCell(1.1m);
            var targetPrice2 = Defaults.TenorPriceCell(1.2m);

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                               {
                                   { targetColumnCellRange, new[] { targetPrice1, targetPrice2} }
                               };

            var pasteColumnCellRange = new ColumnCellRange(col, 1, 2);

            var priceCell1 = Defaults.TenorPriceCell(2.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.2m);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                             {
                                 { pasteColumnCellRange, new []{ priceCell1, priceCell2 } }
                             };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint = new CellPoint(col, 1);

            var expectedCellPointsToRemove = new[] { expectedCellPoint};

            var expectedCellPointsToAdd = new[] { expectedCellPoint };
            var expectedPriceCellsToAdd = new[] { priceCell1, priceCell2 };

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPointsToRemove, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint].SequenceEqual(expectedPriceCellsToAdd));
        }

        [Test]
        public void ShouldAddPasteBindings_When_PasteRangeNotMatchesTargetBindingRange()
        {
            const int col = 1;

            var targetColumnCellRange = new ColumnCellRange(col, 8, 9);

            var targetPrice1 = Defaults.TenorPriceCell(1.1m);
            var targetPrice2 = Defaults.TenorPriceCell(1.2m);

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                   {
                                       { targetColumnCellRange, new[] { targetPrice1, targetPrice2} }
                                   };

            var pasteColumnCellRange = new ColumnCellRange(col, 1, 2);

            var priceCell1 = Defaults.TenorPriceCell(2.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.2m);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new []{ priceCell1, priceCell2 } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint = new CellPoint(col, 1);

            var expectedCellPointsToAdd = new[] { expectedCellPoint };
            var expectedPriceCellsToAdd = new[] { priceCell1, priceCell2 };

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint].SequenceEqual(expectedPriceCellsToAdd));
        }

        [Test]
        public void ShouldMergeWithTargetRangeBindings_When_TargetBindingRangeEndsAfterPasteRange()
        {
            const int col = 1;

            var targetColumnCellRange = new ColumnCellRange(col, 1, 3);

            var targetPrice1 = Defaults.TenorPriceCell(1.1m);
            var targetPrice2 = Defaults.TenorPriceCell(1.2m);
            var targetPrice3 = Defaults.TenorPriceCell(1.3m);

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                   {
                                       { targetColumnCellRange, new[] { targetPrice1, targetPrice2, targetPrice3} }
                                   };

            var pasteColumnCellRange = new ColumnCellRange(col, 1, 2);

            var priceCell1 = Defaults.TenorPriceCell(2.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.2m);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new []{ priceCell1, priceCell2 } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint = new CellPoint(col, 1);

            var expectedCellPointsToRemove = new[] { expectedCellPoint };

            var expectedCellPointsToAdd = new[] { expectedCellPoint };
            var expectedPriceCellsToAdd = new[] { priceCell1, priceCell2, targetPrice3 };

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPointsToRemove, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint].SequenceEqual(expectedPriceCellsToAdd));
        }

        [Test]
        public void ShouldMergeWithTargetRangeBindings_When_TargetBindingRangeStartsBeforePasteRange()
        {
            const int col = 1;

            var targetColumnCellRange = new ColumnCellRange(col, 1, 3);

            var targetPrice1 = Defaults.TenorPriceCell(1.1m);
            var targetPrice2 = Defaults.TenorPriceCell(1.2m);
            var targetPrice3 = Defaults.TenorPriceCell(1.3m);

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                   {
                                       { targetColumnCellRange, new[] { targetPrice1, targetPrice2, targetPrice3} }
                                   };

            var pasteColumnCellRange = new ColumnCellRange(col, 2, 3);

            var priceCell1 = Defaults.TenorPriceCell(2.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.2m);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new []{ priceCell1, priceCell2 } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint = new CellPoint(col, 1);

            var expectedCellPointsToRemove = new[] { expectedCellPoint };

            var expectedCellPointsToAdd = new[] { expectedCellPoint};
            var expectedPriceCellsToAdd = new[] { targetPrice1, priceCell1, priceCell2 };

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPointsToRemove, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint].SequenceEqual(expectedPriceCellsToAdd));
        }

        [Test]
        public void ShouldTruncateStartOfTargetRangeBindings_When_TargetBindingsEndsAfterPasteRange_With_NullPasteValues()
        {
            const int col = 1;

            var targetColumnCellRange = new ColumnCellRange(col, 1, 3);

            var targetPrice1 = Defaults.TenorPriceCell(1.1m);
            var targetPrice2 = Defaults.TenorPriceCell(1.2m);
            var targetPrice3 = Defaults.TenorPriceCell(1.3m);

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                   {
                                       { targetColumnCellRange, new[] { targetPrice1, targetPrice2, targetPrice3} }
                                   };

            var pasteColumnCellRange = new ColumnCellRange(col, 1, 2);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new TenorPriceCell[]{ null, null } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint1 = new CellPoint(col, 1);
            var expectedCellPoint2 = new CellPoint(col, 3);

            var expectedCellPointsToRemove = new[] { expectedCellPoint1 };

            var expectedCellPointsToAdd = new[] { expectedCellPoint2 };
            var expectedPriceCellsToAdd = new[] { targetPrice3 };

            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPointsToRemove, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint2].SequenceEqual(expectedPriceCellsToAdd));
        }

        [Test]
        public void ShouldTruncateEndOfTargetRangeBindings_When_TargetBindingsStartsBeforePasteRange_With_NullPasteValues()
        {
            const int col = 1;

            var targetColumnCellRange = new ColumnCellRange(col, 1, 3);

            var targetPrice1 = Defaults.TenorPriceCell(1.1m);
            var targetPrice2 = Defaults.TenorPriceCell(1.2m);
            var targetPrice3 = Defaults.TenorPriceCell(1.3m);

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                   {
                                       { targetColumnCellRange, new[] { targetPrice1, targetPrice2, targetPrice3} }
                                   };

            var pasteColumnCellRange = new ColumnCellRange(col, 2, 3);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new TenorPriceCell[]{ null, null } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint = new CellPoint(col, 1);

            var expectedCellPointsToRemove = new[] { expectedCellPoint };

            var expectedCellPointsToAdd = new[] { expectedCellPoint };
            var expectedPriceCellsToAdd = new[] { targetPrice1 };

            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPointsToRemove, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint].SequenceEqual(expectedPriceCellsToAdd));
        }

        [Test]
        public void ShouldRemoveAllTargetRangeBindings_When_PasteRangeOverlapsMultipleTargetBindingRanges_With_NullPasteValues()
        {
            const int col = 1;

            var targetColumnCellRange1 = new ColumnCellRange(col, 1, 1);
            var targetPrice1 = Defaults.TenorPriceCell(1.1m);

            var targetColumnCellRange2 = new ColumnCellRange(col, 3, 3);
            var targetPrice2 = Defaults.TenorPriceCell(1.2m);

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                   {
                                       { targetColumnCellRange1, new[] { targetPrice1 } },
                                       { targetColumnCellRange2, new[] { targetPrice2 } },
                                   };

            var pasteColumnCellRange = new ColumnCellRange(col, 1, 3);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new TenorPriceCell[]{ null, null, null } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint1 = new CellPoint(col, 1);
            var expectedCellPoint2 = new CellPoint(col, 3);

            var expectedCellPointsToRemove = new[] { expectedCellPoint1, expectedCellPoint2 };

            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPointsToRemove, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd, Is.Empty);
        }

        [Test]
        public void ShouldAddMultipleBindings_When_PasteRangeContainsNullPriceBreaks()
        {
            const int col = 1;

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();
            
            var pasteColumnCellRange = new ColumnCellRange(col, 1, 6);

            var priceCell1 = Defaults.TenorPriceCell(2.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.2m);
            var priceCell3 = Defaults.TenorPriceCell(2.3m);
            var priceCell4 = Defaults.TenorPriceCell(2.4m);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new []{ priceCell1, priceCell2, null, null, priceCell3, priceCell4 } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint1 = new CellPoint(col, 1);
            var expectedCellPoint2 = new CellPoint(col, 5);

            var expectedCellPointsToAdd = new[] { expectedCellPoint1, expectedCellPoint2 };
            var expectedPriceCellsToAdd1 = new[] { priceCell1, priceCell2 };
            var expectedPriceCellsToAdd2 = new[] { priceCell3, priceCell4 };

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint1].SequenceEqual(expectedPriceCellsToAdd1));
            Assert.That(result.CellRangesToAdd[expectedCellPoint2].SequenceEqual(expectedPriceCellsToAdd2));
        }

        [Test]
        public void ShouldAddMultipleBindings_When_PasteRangeContainsNullPriceBreaks_StartsWithNull()
        {
            const int col = 1;

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var pasteColumnCellRange = new ColumnCellRange(col, 0, 6);

            var priceCell1 = Defaults.TenorPriceCell(2.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.2m);
            var priceCell3 = Defaults.TenorPriceCell(2.3m);
            var priceCell4 = Defaults.TenorPriceCell(2.4m);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new []{ null, priceCell1, priceCell2, null, null, priceCell3, priceCell4 } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint1 = new CellPoint(col, 1);
            var expectedCellPoint2 = new CellPoint(col, 5);

            var expectedCellPointsToAdd = new[] { expectedCellPoint1, expectedCellPoint2 };
            var expectedPriceCellsToAdd1 = new[] { priceCell1, priceCell2 };
            var expectedPriceCellsToAdd2 = new[] { priceCell3, priceCell4 };

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint1].SequenceEqual(expectedPriceCellsToAdd1));
            Assert.That(result.CellRangesToAdd[expectedCellPoint2].SequenceEqual(expectedPriceCellsToAdd2));
        }

        [Test]
        public void ShouldAddMultipleBindings_When_PasteRangeContainsNullPriceBreaks_EndsWithNull()
        {
            const int col = 1;

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var pasteColumnCellRange = new ColumnCellRange(col, 1, 7);

            var priceCell1 = Defaults.TenorPriceCell(2.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.2m);
            var priceCell3 = Defaults.TenorPriceCell(2.3m);
            var priceCell4 = Defaults.TenorPriceCell(2.4m);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new []{ priceCell1, priceCell2, null, null, priceCell3, priceCell4, null } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint1 = new CellPoint(col, 1);
            var expectedCellPoint2 = new CellPoint(col, 5);

            var expectedCellPointsToAdd = new[] { expectedCellPoint1, expectedCellPoint2 };
            var expectedPriceCellsToAdd1 = new[] { priceCell1, priceCell2 };
            var expectedPriceCellsToAdd2 = new[] { priceCell3, priceCell4 };

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));
            Assert.That(result.CellRangesToAdd[expectedCellPoint1].SequenceEqual(expectedPriceCellsToAdd1));
            Assert.That(result.CellRangesToAdd[expectedCellPoint2].SequenceEqual(expectedPriceCellsToAdd2));
        }

        [Test]
        public void ShouldSetAddBindingsEmpty_When_PasteRangeContainsAllNullPrices()
        {
            const int col = 1;

            var targetRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

            var pasteColumnCellRange = new ColumnCellRange(col, 1, 3);

            var pasteRangeCells = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { pasteColumnCellRange, new TenorPriceCell []{ null, null } }
                                  };

            var service = new PriceCellRangeBindingUpdateService();

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(pasteRangeCells, targetRangeCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);
            Assert.That(result.CellRangesToAdd, Is.Empty);
        }

        [Test]
        public void ShouldPasteMultipleColumns_With_MergeTargetRangeBindings_And_NullPrices()
        {
            var targetColumnCellRange1 = new ColumnCellRange(2, 0, 3);

            var targetPrice1 = Defaults.TenorPriceCell(1.1m);
            var targetPrice2 = Defaults.TenorPriceCell(1.2m);
            var targetPrice3 = Defaults.TenorPriceCell(1.3m);
            var targetPrice4 = Defaults.TenorPriceCell(1.4m);

            var targetColumnCellRange2 = new ColumnCellRange(3, 0, 3);

            var targetPrice5 = Defaults.TenorPriceCell(1.5m);
            var targetPrice6 = Defaults.TenorPriceCell(1.6m);
            var targetPrice7 = Defaults.TenorPriceCell(1.7m);
            var targetPrice8 = Defaults.TenorPriceCell(1.8m);

            var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                {
                    { targetColumnCellRange1, new[] { targetPrice1, targetPrice2, targetPrice3, targetPrice4 } },
                    { targetColumnCellRange2, new[] { targetPrice5, targetPrice6, targetPrice7, targetPrice8 } }
                };

            var pasteColumnCellRange1 = new ColumnCellRange(2, 0, 1);

            var priceCell1 = Defaults.TenorPriceCell(2.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.2m);

            var pasteColumnCellRange2 = new ColumnCellRange(3, 0, 1);

            var priceCellsForTarget = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                      {
                                          { pasteColumnCellRange1, new []{priceCell1, priceCell2} },
                                          { pasteColumnCellRange2, new TenorPriceCell[]{null, null} }
                                      };

            var service = new PriceCellRangeBindingUpdateService();

            var expectedCellPoint1 = new CellPoint(2, 0);
            var expectedCellPoint2 = new CellPoint(3, 0);
            var expectedCellPoint3 = new CellPoint(3, 2);

            var expectedCellPointsToRemove = new[] { expectedCellPoint1, expectedCellPoint2 };

            var expectedCellPointsToAdd = new[] { expectedCellPoint1, expectedCellPoint3 };

            var expectedPriceCellsToAdd1 = new[] { priceCell1, priceCell2, targetPrice3, targetPrice4 };
            var expectedPriceCellsToAdd2 = new[] { targetPrice7, targetPrice8 };

            // ACT
            var result = service.GetPriceCellRangeBindingsUpdate(priceCellsForTarget, boundPrices);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPointsToRemove, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPointsToAdd, new CellPointEqualityComparer()));

            Assert.That(result.CellRangesToAdd[expectedCellPoint1].SequenceEqual(expectedPriceCellsToAdd1));
            Assert.That(result.CellRangesToAdd[expectedCellPoint3].SequenceEqual(expectedPriceCellsToAdd2));
        }
    }
}
