﻿using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services.Commands
{
    [TestFixture]
    public class InsertRowsServiceTests
    {
        [Test]
        public void ShouldShiftBoundPriceCells_When_InsertRow_Before_StartOfBoundRange()
        {
            var columnCellRange = new ColumnCellRange(0, 0, 2);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(1.2m);
            var priceCell3 = Defaults.TenorPriceCell(1.3m);

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        {
                                            columnCellRange, new List<TenorPriceCell>{ priceCell1, priceCell2, priceCell3 }
                                        }
                                    };

            // expected results
            var cellPoint1 = new CellPoint(0, 0);
            var cellPoint2 = new CellPoint(0, 3);

            var expectedRemoves = new[] { cellPoint1 };
            var expectedAdds = new[] { cellPoint2 };

            var service = new InsertRowsService();

            // ACT - Insert at Row 0
            var result = service.GetShiftedBoundPriceCells(0, 2, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedAdds));
            Assert.That(result.CellRangesToAdd[cellPoint2].Count, Is.EqualTo(3));
        }

        [Test]
        public void ShouldSplitBoundPriceCellRanges_When_InsertRows_Intersects_BoundRange()
        {
            var columnCellRange = new ColumnCellRange(0, 0, 2);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(1.2m);
            var priceCell3 = Defaults.TenorPriceCell(1.3m);

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        {
                                            columnCellRange, new List<TenorPriceCell>{ priceCell1, priceCell2, priceCell3 }
                                        }
                                    };

            // expected results
            var cellPoint1 = new CellPoint(0, 0);
            var cellPoint2 = new CellPoint(0, 3);

            var expectedRemoves = new[] { cellPoint1 };
            var expectedAdds = new[] { cellPoint1, cellPoint2 };
            var expectedPriceCells1 = new[] { priceCell1 };
            var expectedPriceCells2 = new[] { priceCell2, priceCell3 };

            var service = new InsertRowsService();

            // ACT - Insert at Row 1
            var result = service.GetSplitRangeBoundPriceCells(1, 2, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedAdds));
            Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(expectedPriceCells1));
            Assert.That(result.CellRangesToAdd[cellPoint2].SequenceEqual(expectedPriceCells2));
        }

        [Test]
        public void ShouldNotShiftBoundPriceCells_When_InsertRows_After_BoundRange()
        {
            var columnCellRange = new ColumnCellRange(0, 0, 1);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(1.2m);
            var priceCell3 = Defaults.TenorPriceCell(1.3m);

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        {
                                            columnCellRange, new List<TenorPriceCell>{ priceCell1, priceCell2, priceCell3 }
                                        }
                                    };

            var service = new InsertRowsService();

            // ACT - Insert at Row 2
            var result = service.GetShiftedBoundPriceCells(3, 5, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);
            Assert.That(result.CellRangesToAdd, Is.Empty);
        }

        [Test]
        public void ShouldNotSplitBoundPriceCells_When_InsertRows_After_BoundRange()
        {
            var columnCellRange = new ColumnCellRange(0, 0, 1);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(1.2m);
            var priceCell3 = Defaults.TenorPriceCell(1.3m);

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        {
                                            columnCellRange, new List<TenorPriceCell>{ priceCell1, priceCell2, priceCell3 }
                                        }
                                    };

            var service = new InsertRowsService();

            // ACT - Insert at Row 2
            var result = service.GetSplitRangeBoundPriceCells(3, 5, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);
            Assert.That(result.CellRangesToAdd, Is.Empty);
        }
    }
}
