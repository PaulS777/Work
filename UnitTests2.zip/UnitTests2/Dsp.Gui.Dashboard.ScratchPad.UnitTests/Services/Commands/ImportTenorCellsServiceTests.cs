﻿using System;
using System.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using Moq;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services.Commands
{
    [TestFixture]
    public class ImportTenorCellsServiceTests
    {
        [Test]
        public void ShouldGetTenorsUpdate()
        {
            var cellPoint = new CellPoint(1, 2);

            var date1 = new DateTime(2024, 1, 2);
            var tenor1 = new Mock<ITenor>();

            tenor1.Setup(t => t.StartDate()).Returns(date1);

            var date2 = new DateTime(2024, 2, 2);
            var tenor2 = new Mock<ITenor>();

            tenor2.Setup(t => t.StartDate()).Returns(date2);

            var tenors = new[] { tenor1.Object, tenor2.Object };

            var service = new ImportTenorCellsService();

            var expectedColumnRanges = new[] { new ColumnCellRange(1, 2, 3) };
            var expectedDates = new[] { date1, date2 };

            // ACT
            var result = service.GetTenorsUpdate(1, cellPoint, tenors);

            // ASSERT
            Assert.That(result.WorksheetId, Is.EqualTo(1));
            Assert.That(result.TenorCellRanges.Keys.SequenceEqual(expectedColumnRanges, new ColumnCellRangeEqualityComparer()));
            Assert.That(result.TenorCellRanges.GetValueAtIndex(0).SequenceEqual(expectedDates));
        }
    }
}
