﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using DevExpress.Spreadsheet;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using NUnit.Framework;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid.Model;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using Moq;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services.Commands
{
    [TestFixture]
    public class PasteImportPriceCellsServiceTests
    {
        [Test]
        public void ShouldReturnCell_When_PasteBelowNextRow_SinglePriceCellCopy()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);
            var tenor3 = new MonthlyTenor(2024, 3);
            var tenor4 = new MonthlyTenor(2024, 4);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var row3 = new TenorPriceRowViewModel(new TenorEnvelope(tenor3))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell3 }
            };

            var row4 = new TenorPriceRowViewModel(new TenorEnvelope(tenor4))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell4 }
            };

            var rows = new[] { row1, row2, row3, row4 };

            var boundCellRange = new ColumnCellRange(0, 1, 2);

            var boundCell1 = new TenorPriceCell(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice);
            var boundCell2 = new TenorPriceCell(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice);

            var boundCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundCellRange, new[] { boundCell1, boundCell2 } }
                                  };

            // copy area unchanged since 1st paste
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.RightColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            // paste below
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 3
                                                 && r.RightColumnIndex == 0
                                                 && r.BottomRowIndex == 3
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                            {
                                new TenorPriceCell[]
                                {
                                    new(101, tenor3.GetTenorValue(), priceCell3.LivePrice.MidPrice)
                                }
                            };

            // ACT
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundCellRanges,
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnNextCellRange_MatchedOnLinkedCurve_When_PasteBelowMultipleRows_SinglePriceCellCopy()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);
            var tenor3 = new MonthlyTenor(2024, 3);
            var tenor4 = new MonthlyTenor(2024, 4);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var priceCell5 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell6 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell7 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell8 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
                       {
                           PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1, priceCell5 }
                       };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
                       {
                           PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2, priceCell6 }
                       };

            var row3 = new TenorPriceRowViewModel(new TenorEnvelope(tenor3))
                       {
                           PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell3, priceCell7 }
                       };

            var row4 = new TenorPriceRowViewModel(new TenorEnvelope(tenor4))
                       {
                           PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell4, priceCell8 }
                       };

            var rows = new[] { row1, row2, row3, row4 };

            var boundCellRange1 = new ColumnCellRange(0, 2, 3);

            var boundCell1 = new TenorPriceCell(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice);
            var boundCell2 = new TenorPriceCell(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice);

            var boundCellRange2 = new ColumnCellRange(1, 2, 3);

            var boundCell4 = new TenorPriceCell(102, tenor1.GetTenorValue(), priceCell4.LivePrice.MidPrice);
            var boundCell5 = new TenorPriceCell(102, tenor2.GetTenorValue(), priceCell5.LivePrice.MidPrice);

            var boundCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>> 
                                  {
                                      { boundCellRange1, new[] { boundCell1, boundCell2 } },
                                      { boundCellRange2, new[] { boundCell4, boundCell5 } }
                                  };

            // single column
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.RightColumnIndex == 0
                                                && r.TopRowIndex == 3
                                                && r.BottomRowIndex == 3
                                                && r.RowCount == 1);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0 
                                                 && r.TopRowIndex == 4
                                                 && r.RightColumnIndex == 0
                                                 && r.BottomRowIndex == 5
                                                 && r.RowCount == 2);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   new(101, tenor3.GetTenorValue(), priceCell3.LivePrice.MidPrice),
                                   new(101, tenor4.GetTenorValue(), priceCell4.LivePrice.MidPrice)
                               }
                           };

            // ACT : Import 2 prices
            var result = service.GetImportPriceCells(copyArea, 
                                                     pasteArea,
                                                     boundCellRanges, 
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnNextCell_When_PasteBelowNextRow_PasteBelow_SinglePriceCellCopy()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);
            var tenor3 = new MonthlyTenor(2024, 3);
            var tenor4 = new MonthlyTenor(2024, 4);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var row3 = new TenorPriceRowViewModel(new TenorEnvelope(tenor3))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell3 }
            };

            var row4 = new TenorPriceRowViewModel(new TenorEnvelope(tenor4))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell4 }
            };

            var rows = new[] { row1, row2, row3, row4 };

            var boundCellRange = new ColumnCellRange(0, 2, 4);

            var boundCell1 = new TenorPriceCell(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice);
            var boundCell2 = new TenorPriceCell(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice);
            // boundCell3 is result after 1st paste from the copy area
            var boundCell3 = new TenorPriceCell(101, tenor3.GetTenorValue(), priceCell2.LivePrice.MidPrice);

            var boundCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundCellRange, new[] { boundCell1, boundCell2, boundCell3 } }
                                  };

            // copy area unchanged since 1st paste
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.RightColumnIndex == 0
                                                && r.TopRowIndex == 3
                                                && r.BottomRowIndex == 3
                                                && r.RowCount == 1);

            // paste next row after paste to row 4
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 5
                                                 && r.RightColumnIndex == 0
                                                 && r.BottomRowIndex == 5
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                            {
                                new TenorPriceCell[]
                                {
                                    new(101, tenor4.GetTenorValue(), priceCell4.LivePrice.MidPrice)
                                }
                            };

            // ACT : Import 2 prices
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundCellRanges,
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnCellRangeSize_Equals_CopyArea_When_CopyRowSize_GreaterThan_PasteBelowRowSize()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);
            var tenor3 = new MonthlyTenor(2024, 3);
            var tenor4 = new MonthlyTenor(2024, 4);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var row3 = new TenorPriceRowViewModel(new TenorEnvelope(tenor3))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell3 }
            };

            var row4 = new TenorPriceRowViewModel(new TenorEnvelope(tenor4))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell4 }
            };

            var rows = new[] { row1, row2, row3, row4 };

            var boundCellRange1 = new ColumnCellRange(0, 0, 1);

            var boundCell1 = new TenorPriceCell(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice);
            var boundCell2 = new TenorPriceCell(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice);

            var boundPriceCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                       {
                                           { boundCellRange1, new[] { boundCell1, boundCell2 } }
                                       };

            // Copy 2 rows
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.RightColumnIndex == 0
                                                && r.TopRowIndex == 0
                                                && r.BottomRowIndex == 1
                                                && r.RowCount == 2);

            // Paste single row
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 2
                                                 && r.BottomRowIndex == 2
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   new(101, tenor3.GetTenorValue(), priceCell3.LivePrice.MidPrice),
                                   new(101, tenor4.GetTenorValue(), priceCell4.LivePrice.MidPrice)
                               }
                           };

            // ACT : Paste Area 1 row
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundPriceCellRanges, 
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnMultiplesPriceCellsArrays_When_Paste_BelowMultipleColumns()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();

            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithTenorValue(tenor2.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1, priceCell3 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2, priceCell4 }
            };

            var rows = new[] { row1, row2 };

            var boundCellRange1 = new ColumnCellRange(0, 2, 2);
            var boundCell1 = new TenorPriceCell(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice);

            var boundCellRange2 = new ColumnCellRange(1, 2, 2);
            var boundCell3 = new TenorPriceCell(102, tenor1.GetTenorValue(), priceCell3.LivePrice.MidPrice);

            var boundPriceCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                       {
                                           { boundCellRange1, new[] { boundCell1 } },
                                           { boundCellRange2, new[] { boundCell3 } }
                                       };

            // 2 columns
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.RightColumnIndex == 1
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 3
                                                 && r.BottomRowIndex == 3
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   new(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice)
                               },
                               new TenorPriceCell[]
                               {
                                   new(102, tenor2.GetTenorValue(), priceCell4.LivePrice.MidPrice)
                               }
                           };

            // ACT
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundPriceCellRanges, 
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnEmpty_When_PasteBelow_UnboundCell()
        {
            var boundCellRange = new ColumnCellRange(0, 1, 1);

            var boundPriceCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                       {
                                           { boundCellRange, new[] { Defaults.TenorPriceCell() } }
                                       };

            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.RightColumnIndex == 0
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 3
                                                 && r.BottomRowIndex == 3
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>> { Array.Empty<TenorPriceCell>() };

            // ACT
            var result = service.GetImportPriceCells(copyArea, 
                                                     pasteArea, 
                                                     boundPriceCellRanges, 
                                                     new List<TenorPriceRowViewModel>());

           // ASSERT
           Assert.That(result.SequenceEqual(expected));
        }

        [Test]
        public void ShouldReturnEmpty_When_PasteBelow_UnboundCell_With_ColumnContainsBoundCells()
        {
            var columnCellRange = new ColumnCellRange(1, 0, 0);

            var boundPriceCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                       {
                                           { columnCellRange, new[] { Defaults.TenorPriceCell() } }
                                       };

            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 1 
                                                && r.TopRowIndex == 2
                                                && r.RightColumnIndex == 1
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 3
                                                 && r.BottomRowIndex == 3
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>> { Array.Empty<TenorPriceCell>() };

            // ACT
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundPriceCellRanges,
                                                     new List<TenorPriceRowViewModel>());

            // ASSERT
            Assert.That(result.SequenceEqual(expected));
        }

        [Test]
        public void ShouldReturnCells_When_PasteBelow_GreaterThan_AvailablePriceCells()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var rows = new[] { row1, row2 };

            var boundCellRange = new ColumnCellRange(0, 1, 1);
            var boundCell1 = new TenorPriceCell(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice);

            var boundPriceCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                       {
                                           { boundCellRange, new[] { boundCell1 } }
                                       };

            // 2 columns
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.TopRowIndex == 1
                                                && r.RightColumnIndex == 0
                                                && r.BottomRowIndex == 1
                                                && r.RowCount == 1);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 2
                                                 && r.BottomRowIndex == 5
                                                 && r.RowCount == 4);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   new(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice)
                               }
                           };

            // ACT
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea, 
                                                     boundPriceCellRanges,
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnEmpty_When_Paste_With_NoBoundPrices()
        {
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.RightColumnIndex == 0
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 3
                                                 && r.BottomRowIndex == 3
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            // ACT
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     new Dictionary<ColumnCellRange, IList<TenorPriceCell>>(),
                                                     new List<TenorPriceRowViewModel>());

            // ASSERT
            Assert.That(result, Is.Empty);
        }

        #region paste above - reverse copy direction

        [Test]
        public void ShouldReturnPreviousCell_When_PasteAboveSingleRow_With_SinglePriceCellCopy()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);
            var tenor3 = new MonthlyTenor(2024, 3);
            var tenor4 = new MonthlyTenor(2024, 4);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var row3 = new TenorPriceRowViewModel(new TenorEnvelope(tenor3))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell3 }
            };

            var row4 = new TenorPriceRowViewModel(new TenorEnvelope(tenor4))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell4 }
            };

            var rows = new[] { row1, row2, row3, row4 };

            var boundCellRange = new ColumnCellRange(0, 2, 3);

            var boundCell3 = new TenorPriceCell(101, tenor3.GetTenorValue(), priceCell3.LivePrice.MidPrice);
            var boundCell4 = new TenorPriceCell(101, tenor4.GetTenorValue(), priceCell4.LivePrice.MidPrice);

            var boundCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundCellRange, new[] { boundCell3, boundCell4 } }
                                  };

            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.RightColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            // 1 row above copy area
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 1
                                                 && r.BottomRowIndex == 1
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   new(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice)
                               }
                           };

            // ACT 
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundCellRanges,
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnPreviousCellRange_When_PasteAboveMultipleRows_With_SinglePriceCellCopy()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);
            var tenor3 = new MonthlyTenor(2024, 3);
            var tenor4 = new MonthlyTenor(2024, 4);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var row3 = new TenorPriceRowViewModel(new TenorEnvelope(tenor3))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell3 }
            };

            var row4 = new TenorPriceRowViewModel(new TenorEnvelope(tenor4))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell4 }
            };

            var rows = new[] { row1, row2, row3, row4 };

            var boundCellRange = new ColumnCellRange(0, 2, 3);

            var boundCell3 = new TenorPriceCell(101, tenor3.GetTenorValue(), priceCell3.LivePrice.MidPrice);
            var boundCell4 = new TenorPriceCell(101, tenor4.GetTenorValue(), priceCell4.LivePrice.MidPrice);

            var boundCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundCellRange, new[] { boundCell3, boundCell4 } }
                                  };

            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.RightColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            // 1 row above copy area
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 0
                                                 && r.BottomRowIndex == 1
                                                 && r.RowCount == 2);
           
            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   new(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice),
                                   new(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice)
                               }
                           };

            // ACT 
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundCellRanges,
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnNextPreviousCell_When_PasteAbove_After_PasteAbove_SinglePriceCellCopy()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);
            var tenor3 = new MonthlyTenor(2024, 3);
            var tenor4 = new MonthlyTenor(2024, 4);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var row3 = new TenorPriceRowViewModel(new TenorEnvelope(tenor3))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell3 }
            };

            var row4 = new TenorPriceRowViewModel(new TenorEnvelope(tenor4))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell4 }
            };

            var rows = new[] { row1, row2, row3, row4 };

            var boundCellRange = new ColumnCellRange(0, 1, 3);

            var boundCell1 = new TenorPriceCell(101, tenor2.GetTenorValue(), priceCell3.LivePrice.MidPrice);
            var boundCell2 = new TenorPriceCell(101, tenor3.GetTenorValue(), priceCell4.LivePrice.MidPrice);
            var boundCell3 = new TenorPriceCell(101, tenor4.GetTenorValue(), priceCell4.LivePrice.MidPrice);

            var boundCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundCellRange, new[] { boundCell1, boundCell2, boundCell3 } }
                                  };

            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.RightColumnIndex == 0
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            // 1 row above copy area
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 0
                                                 && r.BottomRowIndex == 0
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   new(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice)
                               }
                           };

            // ACT 
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundCellRanges,
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldUseSingleCellCopy_When_PasteAbove_MultiplePriceCellRowsCopy()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);
            var tenor3 = new MonthlyTenor(2024, 3);
            var tenor4 = new MonthlyTenor(2024, 4);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor3.GetTenorValue()).PriceCell();
            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor4.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var row3 = new TenorPriceRowViewModel(new TenorEnvelope(tenor3))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell3 }
            };

            var row4 = new TenorPriceRowViewModel(new TenorEnvelope(tenor4))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell4 }
            };

            var rows = new[] { row1, row2, row3, row4 };

            var boundCellRange = new ColumnCellRange(0, 2, 3);

            var boundCell3 = new TenorPriceCell(101, tenor3.GetTenorValue(), priceCell3.LivePrice.MidPrice);
            var boundCell4 = new TenorPriceCell(101, tenor4.GetTenorValue(), priceCell4.LivePrice.MidPrice);

            var boundPriceCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                       {
                                           { boundCellRange, new[] { boundCell3, boundCell4 } }
                                       };

            // Copy 2 rows
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.RightColumnIndex == 0
                                                && r.BottomRowIndex == 3
                                                && r.RowCount == 2);

            // Paste single row
            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 1
                                                 && r.BottomRowIndex == 1
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   new(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice)
                               }
                           };

            // ACT : Paste Area 1 row
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundPriceCellRanges,
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldReturnEmpty_When_PasteAbove_UnboundCell()
        {
            var boundCellRange = new ColumnCellRange(0, 3, 3);

            var boundPriceCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                       {
                                           { boundCellRange, new[] { Defaults.TenorPriceCell() } }
                                       };

            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.TopRowIndex == 2
                                                && r.RightColumnIndex == 0
                                                && r.BottomRowIndex == 2
                                                && r.RowCount == 1);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 1
                                                 && r.BottomRowIndex == 1
                                                 && r.RowCount == 1);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>> { Array.Empty<TenorPriceCell>() };

            // ACT
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundPriceCellRanges,
                                                     new List<TenorPriceRowViewModel>());

            // ASSERT
            Assert.That(result.SequenceEqual(expected));
        }

        [Test]
        public void ShouldReturnNullsBeforePriceCell_When_PasteAboveRange_GreaterThan_AvailablePriceCells()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2024, 1);
            var tenor2 = new MonthlyTenor(2024, 2);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor1.GetTenorValue()).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithTenorValue(tenor2.GetTenorValue()).PriceCell();

            var row1 = new TenorPriceRowViewModel(new TenorEnvelope(tenor1))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell1 }
            };

            var row2 = new TenorPriceRowViewModel(new TenorEnvelope(tenor2))
            {
                PriceCells = new ObservableCollection<PriceCellViewModel> { priceCell2 }
            };

            var rows = new[] { row1, row2 };

            var boundCellRange = new ColumnCellRange(0, 3, 3);
            var boundCell2 = new TenorPriceCell(101, tenor2.GetTenorValue(), priceCell2.LivePrice.MidPrice);

            var boundPriceCellRanges = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                       {
                                           { boundCellRange, new[] { boundCell2 } }
                                       };

            // 2 columns
            var copyArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                && r.TopRowIndex == 3
                                                && r.RightColumnIndex == 0
                                                && r.BottomRowIndex == 3
                                                && r.RowCount == 1);

            var pasteArea = Mock.Of<CellRange>(r => r.LeftColumnIndex == 0
                                                 && r.TopRowIndex == 0
                                                 && r.BottomRowIndex == 2
                                                 && r.RowCount == 3);

            var service = new PasteImportPriceCellsService();

            var expected = new List<IList<TenorPriceCell>>
                           {
                               new TenorPriceCell[]
                               {
                                   null, null, new(101, tenor1.GetTenorValue(), priceCell1.LivePrice.MidPrice)
                               }
                           };

            // ACT
            var result = service.GetImportPriceCells(copyArea,
                                                     pasteArea,
                                                     boundPriceCellRanges,
                                                     rows);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        #endregion
    }
}
