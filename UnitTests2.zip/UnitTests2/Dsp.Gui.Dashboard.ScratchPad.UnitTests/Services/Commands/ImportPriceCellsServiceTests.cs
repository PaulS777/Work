﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services.Commands
{

    namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services.Commands
    {
        [TestFixture]
        public class ImportPriceCellsServiceTests
        {
            [Test] // 1
            public void ShouldGetBindingsUpdate_When_ImportRange_With_NoBoundCellRanges()
            {
                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCurves = new[]
                                  {
                                      new[] { priceCell1, priceCell2 }
                                  };

                var service = new ImportPriceCellsService();

                var cellPoint = new CellPoint(0, 0);

                var expectedCellPoints = new[] { cellPoint };
                var expectedPriceCells = new[] { priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCurves,
                                                             new Dictionary<ColumnCellRange, IList<TenorPriceCell>>());

                // ASSERT
                Assert.That(result.CellRangesToRemove, Is.Empty);
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCells));
            }

            [Test] 
            public void ShouldGetBindingsUpdate_When_ImportRange_With_MultipleColumns()
            {
                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCell3 = Defaults.TenorPriceCell(1.6m);
                var priceCell4 = Defaults.TenorPriceCell(1.7m);

                var priceCells1 = new[] { priceCell1, priceCell2 };
                var priceCells2 = new[] { priceCell3, priceCell4 };

                var priceCurves = new[] { priceCells1, priceCells2 };

                var service = new ImportPriceCellsService();

                var cellPoint1 = new CellPoint(0, 0);
                var cellPoint2 = new CellPoint(1, 0);

                var expectedCellPoints = new[] { cellPoint1, cellPoint2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCurves,
                                                             new Dictionary<ColumnCellRange, IList<TenorPriceCell>>());

                // ASSERT
                Assert.That(result.CellRangesToRemove, Is.Empty);
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(priceCells1));
                Assert.That(result.CellRangesToAdd[cellPoint2].SequenceEqual(priceCells2));
            }

            [Test]
            public void ShouldGetBindingsUpdate_When_ImportRange_With_MultipleColumns_With_Gap()
            {
                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCell3 = Defaults.TenorPriceCell(1.6m);
                var priceCell4 = Defaults.TenorPriceCell(1.7m);

                var priceCells1 = new[] { priceCell1, priceCell2 };
                var gap = Array.Empty<TenorPriceCell>();
                var priceCells2 = new[] { priceCell3, priceCell4 };

                var priceCurves = new[] { priceCells1, gap, priceCells2 };

                var service = new ImportPriceCellsService();

                var cellPoint1 = new CellPoint(0, 0);
                var cellPoint2 = new CellPoint(2, 0);

                var expectedCellPoints = new[] { cellPoint1, cellPoint2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCurves,
                                                             new Dictionary<ColumnCellRange, IList<TenorPriceCell>>());

                // ASSERT
                Assert.That(result.CellRangesToRemove, Is.Empty);
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(priceCells1));
                Assert.That(result.CellRangesToAdd[cellPoint2].SequenceEqual(priceCells2));
            }

            [Test] // 2
            public void ShouldShiftBindingsUpdateRange_When_ImportRange_With_Header()
            {
                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>();

                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCells = new[] { new[] { priceCell1, priceCell2 } };

                var service = new ImportPriceCellsService();

                var cellPoint = new CellPoint(0, 1);

                var expectedCellPoints = new[] { cellPoint };
                var expectedPriceCells = new[] { priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             true,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove, Is.Empty);
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCells));
            }

            [Test] // 3
            public void ShouldMergeCellRanges_When_ImportTop_Touches_BoundRangeBottom()
            {
                var boundPrice1 = Defaults.TenorPriceCell(1.1m);
                var boundRange = new ColumnCellRange(0, 0, 0);

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      {  boundRange, new[] { boundPrice1 } }
                                  };

                var importCell = new CellPoint(0, 1);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCells = new[] { new[] { priceCell1, priceCell2 } };

                var service = new ImportPriceCellsService();

                var cellPoint = new CellPoint(0, 0);

                var expectedRemovals = new[] { cellPoint };
                var expectedCellPoints = new[] { cellPoint };
                var expectedPriceCells = new[] { boundPrice1, priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemovals));
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCells));
            }

            [Test] // 4
            public void ShouldNotMerge_When_ImportTop_Touches_BoundRangeBottom_With_Header()
            {
                var boundPrice1 = Defaults.TenorPriceCell(1.1m);
                var boundRange = new ColumnCellRange(0, 0, 0);

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      {  boundRange, new[] { boundPrice1 } }
                                  };

                var importCell = new CellPoint(0, 1);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCells = new[] { new[] { priceCell1, priceCell2 } };

                var service = new ImportPriceCellsService();

                var cellPoint = new CellPoint(0, 2);
                var expectedCellPoints = new[] { cellPoint };
                var expectedPriceCells = new[] { priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             true,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove, Is.Empty);
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCells));
            }

            [Test] // 5
            public void ShouldMergeCellRanges_When_ImportTop_Overlaps_BoundRangeBottom()
            {
                var boundPrice1 = Defaults.TenorPriceCell(1.1m);
                var boundPrice2 = Defaults.TenorPriceCell(1.2m);

                var boundRange = new ColumnCellRange(0, 0, 2);

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  { 
                                      { boundRange, new[] { boundPrice1, boundPrice2 } }
                                  };

                var importCell = new CellPoint(0, 1);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCells = new[] { new[] { priceCell1, priceCell2 } };

                var service = new ImportPriceCellsService();

                var cellPoint = new CellPoint(0, 0);

                var expectedRemovals = new[] { cellPoint };
                var expectedCellPoints = new[] { cellPoint };
                var expectedPriceCells = new[] { boundPrice1, priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemovals));
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCells));
            }

            [Test] // 6
            public void ShouldTrimBoundRange_When_ImportTop_Overlaps_BoundRangeBottom_With_Header()
            {
                var boundPrice1 = Defaults.TenorPriceCell(1.1m);
                var boundPrice2 = Defaults.TenorPriceCell(1.2m);
                var boundPrice3 = Defaults.TenorPriceCell(1.3m);

                var boundRange = new ColumnCellRange(0, 0, 2);

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundRange, new[] { boundPrice1, boundPrice2, boundPrice3 } }
                                  };

                var importCell = new CellPoint(0, 1);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCells = new[] { new[] { priceCell1, priceCell2 } };

                var service = new ImportPriceCellsService();

                var cellPoint = new CellPoint(0, 0);
                var cellPoint2 = new CellPoint(0, 2);

                var expectedRemovals = new[] { cellPoint };
                var expectedCellPoints = new[] { cellPoint, cellPoint2 };
                var expectedPriceCells1 = new[] { boundPrice1 };
                var expectedPriceCells2 = new[] { priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             true,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemovals));
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCells1));
                Assert.That(result.CellRangesToAdd[cellPoint2].SequenceEqual(expectedPriceCells2));
            }

            [Test] // 7
            public void ShouldMergeCell_And_MergeSecond_When_ImportTop_Overlaps_FirstBoundRangeBottom_SecondBoundRangeTop()
            {
                var boundRange1 = new ColumnCellRange(0, 0, 2);

                var boundPrice1 = Defaults.TenorPriceCell(1.1m);
                var boundPrice2 = Defaults.TenorPriceCell(1.2m);

                var boundRange2 = new ColumnCellRange(0, 3, 4);

                var boundPrice3 = Defaults.TenorPriceCell(1.7m);
                var boundPrice4 = Defaults.TenorPriceCell(1.8m);

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundRange1, new[] { boundPrice1, boundPrice2 } },
                                      { boundRange2, new[] { boundPrice3, boundPrice4 } }
                                  };

                var importCell = new CellPoint(0, 1);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);
                var priceCell3 = Defaults.TenorPriceCell(1.6m);

                var priceCells = new[] { new[] { priceCell1, priceCell2, priceCell3 } };

                var service = new ImportPriceCellsService();

                var cellPoint1 = new CellPoint(0, 0);
                var cellPoint2 = new CellPoint(0, 3);

                var expectedRemovals = new[] { cellPoint1, cellPoint2 };
                var expectedCellPoints = new[] { cellPoint1 };
                var expectedPriceCells = new[] { boundPrice1, priceCell1, priceCell2, priceCell3, boundPrice4 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemovals));
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(expectedPriceCells));
            }

            [Test] // 8
            public void ShouldTrimFirstBoundRange_And_MergeSecond_When_ImportTop_Overlaps_FirstBoundRangeBottom_With_Header()
            {
                var boundRange1 = new ColumnCellRange(0, 0, 2);

                var boundPrice1 = Defaults.TenorPriceCell(1.1m);
                var boundPrice2 = Defaults.TenorPriceCell(1.2m);
                var boundPrice3 = Defaults.TenorPriceCell(1.3m);

                var boundRange2 = new ColumnCellRange(0, 4, 5);

                var boundPrice4 = Defaults.TenorPriceCell(1.7m);
                var boundPrice5 = Defaults.TenorPriceCell(1.8m);

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundRange1, new[] { boundPrice1, boundPrice2, boundPrice3 } },
                                      { boundRange2, new[] { boundPrice4, boundPrice5 } }
                                  };

                var importCell = new CellPoint(0, 1);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);
                var priceCell3 = Defaults.TenorPriceCell(1.6m);

                var priceCurves = new[]
                                  {
                                      new[] { priceCell1, priceCell2, priceCell3 }
                                  };

                var service = new ImportPriceCellsService();

                var cellPoint1 = new CellPoint(0, 0);
                var cellPoint2 = new CellPoint(0, 2);
                var cellPoint3 = new CellPoint(0, 4);

                var expectedRemovals = new[] { cellPoint1, cellPoint3 };
                var expectedCellPoints = new[] { cellPoint1, cellPoint2 };
                var expectedPriceCells1 = new[] { boundPrice1 };
                var expectedPriceCells2 = new[] { priceCell1, priceCell2, priceCell3, boundPrice5 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             true,
                                                             priceCurves,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemovals));
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(expectedPriceCells1));
                Assert.That(result.CellRangesToAdd[cellPoint2].SequenceEqual(expectedPriceCells2));
            }

            [Test] // 9
            public void ShouldRemoveFirstBoundRange_When_ImportTop_StartsAt_FirstBoundRangeTop_With_Header()
            {
                var boundRange = new ColumnCellRange(0, 0, 1);

                var boundPrice1 = Defaults.TenorPriceCell(1.1m);
                var boundPrice2 = Defaults.TenorPriceCell(1.2m);
                

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundRange, new[] { boundPrice1, boundPrice2 } }
                                  };

                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m); 

                var priceCells = new[] { new[] { priceCell1, priceCell2 } };

                var service = new ImportPriceCellsService();

                var cellPoint1 = new CellPoint(0, 0);
                var cellPoint2 = new CellPoint(0, 1);

                var expectedRemovals = new[] { cellPoint1 };
                var expectedCellPoints = new[] { cellPoint2 };
                var expectedPriceCells = new[] { priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             true,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemovals));
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint2].SequenceEqual(expectedPriceCells));
            }

            [Test] // 10
            public void ShouldMergeCellRanges_When_ImportBottom_Touches_BoundRangeTop()
            {
                var boundRange = new ColumnCellRange(0, 2, 2);

                var boundPrice1 = Defaults.TenorPriceCell(1.7m);

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundRange, new[] { boundPrice1 } }
                                  };

                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCells = new[] { new[] { priceCell1, priceCell2 } };

                var service = new ImportPriceCellsService();

                var cellPoint1 = new CellPoint(0, 0);
                var cellPoint2 = new CellPoint(0, 2);

                var expectedRemovals = new[] { cellPoint2 };
                var expectedCellPoints = new[] { cellPoint1 };
                var expectedPriceCells = new[] { priceCell1, priceCell2, boundPrice1 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemovals));
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(expectedPriceCells));
            }

            [Test] // 11
            public void ShouldNotMergeCellRanges_When_Import_ApartFrom_BoundRanges()
            {
                var boundRange = new ColumnCellRange(0, 3, 3);

                var boundPrice1 = Defaults.TenorPriceCell(1.7m);

                var boundPrices = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                  {
                                      { boundRange, new[] { boundPrice1 } }
                                  };

                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCells = new[] { new[] { priceCell1, priceCell2 } };

                var service = new ImportPriceCellsService();

                var cellPoint1 = new CellPoint(0, 0);

                var expectedCellPoints = new[] { cellPoint1 };
                var expectedPriceCells = new[] { priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCells,
                                                             boundPrices);

                // ASSERT
                Assert.That(result.CellRangesToRemove, Is.Empty);
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(expectedPriceCells));
            }

            [Test] // 12
            public void ShouldShiftBindingsUpdateRange_When_Import_HasMissingPrices_At_Start()
            {
                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCurves = new[]
                                  {
                                      new[] { null, null, priceCell1, priceCell2 }
                                  };

                var service = new ImportPriceCellsService();

                var cellPoint = new CellPoint(0, 2);

                var expectedCellPoints = new[] { cellPoint };
                var expectedPriceCells = new[] { priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             false,
                                                             priceCurves,
                                                             new Dictionary<ColumnCellRange, IList<TenorPriceCell>>());

                // ASSERT
                Assert.That(result.CellRangesToRemove, Is.Empty);
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCells));
            }

            [Test] // 13
            public void ShouldShiftBindingsUpdateRange_When_Import__With_Header_And_HasMissingPrices_At_Start()
            {
                var importCell = new CellPoint(0, 0);

                var priceCell1 = Defaults.TenorPriceCell(1.4m);
                var priceCell2 = Defaults.TenorPriceCell(1.5m);

                var priceCurves = new[]
                                  {
                                      new[] { null, null, priceCell1, priceCell2 }
                                  };

                var service = new ImportPriceCellsService();

                var cellPoint = new CellPoint(0, 3);

                var expectedCellPoints = new[] { cellPoint };
                var expectedPriceCells = new[] { priceCell1, priceCell2 };

                // ACT
                var result = service.GetImportBindingsUpdate(importCell,
                                                             true,
                                                             priceCurves,
                                                             new Dictionary<ColumnCellRange, IList<TenorPriceCell>>());

                // ASSERT
                Assert.That(result.CellRangesToRemove, Is.Empty);
                Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedCellPoints));
                Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedPriceCells));
            }
        }
    }
}
