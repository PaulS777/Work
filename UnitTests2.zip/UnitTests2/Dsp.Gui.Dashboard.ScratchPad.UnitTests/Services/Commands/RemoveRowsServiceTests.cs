﻿using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using System.Collections.Generic;
using System.Linq;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services.Commands
{
    [TestFixture]
    public class RemoveRowsServiceTests
    {
        [Test]
        public void ShouldShiftBoundCells_When_RemoveRows_Before_StartOfBoundCells()
        {
            var boundCellRange = new ColumnCellRange(0, 2, 4);

            var priceCell1 = Defaults.TenorPriceCell();
            var priceCell2 = Defaults.TenorPriceCell();
            var priceCell3 = Defaults.TenorPriceCell();

            var priceCells = new[] { priceCell1, priceCell2, priceCell3 };

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { boundCellRange, priceCells }
                                    };

            // expected results
            var cellPoint1 = new CellPoint(0, 2);
            var cellPoint2 = new CellPoint(0, 0);

            var expectedRemoves = new[] { cellPoint1 };

            var service = new RemoveRowsService();

            // ACT 
            var result = service.GetShiftedOrModifiedPriceCells(0, 1, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd.Count, Is.EqualTo(1));
            Assert.That(result.CellRangesToAdd[cellPoint2].SequenceEqual(priceCells));
        }

        [Test]
        public void ShouldExtractRange_And_Shift_When_RemoveRows_Overlaps_StartOfBoundCells()
        {
            var boundCellRange = new ColumnCellRange(0, 2, 4);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(1.2m);
            var priceCell3 = Defaults.TenorPriceCell(1.3m);

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { boundCellRange, new[] { priceCell1, priceCell2, priceCell3 } }
                                    };

            var service = new RemoveRowsService();

            // expected results
            var cellPoint1 = new CellPoint(0, 2);
            var cellPoint2 = new CellPoint(0, 1);

            var expectedRemoves = new[] { cellPoint1 };
            var expectedCells = new[] { priceCell2, priceCell3 };

            // ACT
            var result = service.GetShiftedOrModifiedPriceCells(1, 2, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd.Count, Is.EqualTo(1));
            Assert.That(result.CellRangesToAdd[cellPoint2].SequenceEqual(expectedCells));
        }

        [Test]
        public void ShouldTrimEndOfBoundCells_When_RemoveRows_Overlaps_EndOfBoundCells()
        {
            var boundCellRange = new ColumnCellRange(0, 1, 3);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(1.2m);
            var priceCell3 = Defaults.TenorPriceCell(1.3m);

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { boundCellRange, new[] { priceCell1, priceCell2, priceCell3 } }
                                    };

            var service = new RemoveRowsService();

            // expected results
            var cellPoint = new CellPoint(0, 1);

            var expectedRemoves = new[] { cellPoint };
            var expectedCells = new[] { priceCell1, priceCell2 };

            // ACT
            var result = service.GetShiftedOrModifiedPriceCells(3, 4, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd.Count, Is.EqualTo(1));
            Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedCells));
        }

        [Test]
        public void ShouldRemoveBoundCellsFromMiddle_When_RemoveRows_Within_BoundCells()
        {
            var boundCellRange = new ColumnCellRange(0, 1, 4);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(1.2m);
            var priceCell3 = Defaults.TenorPriceCell(1.3m);
            var priceCell4 = Defaults.TenorPriceCell(1.4m);

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { boundCellRange, new[] { priceCell1, priceCell2, priceCell3, priceCell4 }}
                                    };

            var service = new RemoveRowsService();

            // expected results
            var cellPoint = new CellPoint(0, 1);

            var expectedRemoves = new[] { cellPoint };
            var expectedCells = new[] { priceCell1, priceCell4 };

            // ACT
            var result = service.GetShiftedOrModifiedPriceCells(2, 3, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd.Count, Is.EqualTo(1));
            Assert.That(result.CellRangesToAdd[cellPoint].SequenceEqual(expectedCells));
        }

        [Test]
        public void ShouldClearAllBoundCells_When_RemoveRows_Matches_BoundCells()
        {
            var boundCellRange = new ColumnCellRange(0, 1, 2);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(1.2m);

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { boundCellRange, new[] { priceCell1, priceCell2 } }
                                    };

            var service = new RemoveRowsService();

            // expected results
            var cellPoint = new CellPoint(0, 1);

            var expectedRemoves = new[] { cellPoint };

            // ACT
            var result = service.GetShiftedOrModifiedPriceCells(1, 2, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd, Is.Empty);
        }
    }
}
