﻿using System;
using System.Collections.Generic;
using System.Linq;
using DevExpress.Spreadsheet;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using NUnit.Framework;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using Moq;
using Cell = DevExpress.Spreadsheet.Cell;
using CellRange = DevExpress.Spreadsheet.CellRange;
// ReSharper disable NotDisposedResourceIsReturned

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services.Commands
{
    [TestFixture]
    public class PasteExtendTenorsServiceTests
    {
        [Test]
        public void ShouldReturnAscendingColumnTenors_When_PasteMultipleCells_Below_CopySingleTenor()
        {
            var copyArea = new Mock<CellRange>();

            copyArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            copyArea.SetupGet(a => a.RowCount).Returns(2);

            var cellValue1 = CellValue.FromDateTime(new DateTime(2024, 1, 1), false);
            var cell1 = Mock.Of<Cell>(c => c.Value == cellValue1 && c.ColumnIndex == 0);

            var cellValue2 = CellValue.FromDateTime(new DateTime(2024, 2, 1), false);
            var cell2 = Mock.Of<Cell>(c => c.Value == cellValue2 && c.ColumnIndex == 0);

            var list = new List<Cell> { cell1, cell2 };

            copyArea.Setup(a => a.GetEnumerator())
                    .Returns(() => list.GetEnumerator());

            var pasteArea = new Mock<CellRange>();

            pasteArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            pasteArea.SetupGet(a => a.TopRowIndex).Returns(2);
            pasteArea.SetupGet(a => a.RowCount).Returns(2);

            var service = new PasteExtendTenorsService();

            var expectedRange = new ColumnCellRange(0, 2, 3);
            var expectedRanges = new[] { expectedRange };

            var expectedTenors = new[] { new DateTime(2024, 3, 1), new DateTime(2024, 4, 1) };

            // ACT
            var result = service.GetTenorsUpdate(1, copyArea.Object, pasteArea.Object);

            // ASSERT
            Assert.That(result.WorksheetId, Is.EqualTo(1));

            Assert.That(result.TenorCellRanges.Keys.SequenceEqual(expectedRanges, new ColumnCellRangeEqualityComparer()));
            Assert.That(result.TenorCellRanges[expectedRange].SequenceEqual(expectedTenors));
        }

        [Test]
        public void ShouldReturnDescendingColumnTenors_When_PasteMultipleCells_Above_CopySingleTenor()
        {
            var copyArea = new Mock<CellRange>();

            copyArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            copyArea.SetupGet(a => a.RowCount).Returns(1);

            var cellValue1 = CellValue.FromDateTime(new DateTime(2024, 3, 1), false);
            var cell1 = Mock.Of<Cell>(c => c.Value == cellValue1 && c.ColumnIndex == 0);

            var cellValue2 = CellValue.FromDateTime(new DateTime(2024, 4, 1), false);
            var cell2 = Mock.Of<Cell>(c => c.Value == cellValue2 && c.ColumnIndex == 0);

            var list = new List<Cell> { cell1, cell2 };

            copyArea.Setup(a => a.GetEnumerator())
                    .Returns(() => list.GetEnumerator());

            var pasteArea = new Mock<CellRange>();

            pasteArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            pasteArea.SetupGet(a => a.TopRowIndex).Returns(0);
            pasteArea.SetupGet(a => a.BottomRowIndex).Returns(1);
            pasteArea.SetupGet(a => a.RowCount).Returns(2);

            var service = new PasteExtendTenorsService();

            var expectedRange = new ColumnCellRange(0, 0, 1);
            var expectedRanges = new[] { expectedRange };

            var expectedTenors = new[] { new DateTime(2024, 1, 1), new DateTime(2024, 2, 1) };

            // ACT
            var result = service.GetTenorsUpdate(1, copyArea.Object, pasteArea.Object);

            // ASSERT
            Assert.That(result.WorksheetId, Is.EqualTo(1));

            Assert.That(result.TenorCellRanges.Keys.SequenceEqual(expectedRanges, new ColumnCellRangeEqualityComparer()));
            Assert.That(result.TenorCellRanges[expectedRange].SequenceEqual(expectedTenors));
        }

        [Test]
        public void ShouldReturnEmpty_When_Paste_Below_CopyNonTenorCell()
        {
            var copyArea = new Mock<CellRange>();

            copyArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            copyArea.SetupGet(a => a.RowCount).Returns(2);

            var cell1 = Mock.Of<Cell>(c => c.Value == CellValue.Empty && c.ColumnIndex == 0);

            var cellValue2 = CellValue.FromDateTime(new DateTime(2024, 1, 1), false);
            var cell2 = Mock.Of<Cell>(c => c.Value == cellValue2 && c.ColumnIndex == 0);

            var list = new List<Cell> {  cell1, cell2 };

            copyArea.Setup(a => a.GetEnumerator())
                    .Returns(() => list.GetEnumerator());

            var pasteArea = new Mock<CellRange>();

            pasteArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            pasteArea.SetupGet(a => a.TopRowIndex).Returns(2);
            pasteArea.SetupGet(a => a.RowCount).Returns(2);

            var service = new PasteExtendTenorsService();

            // ACT
            var result = service.GetTenorsUpdate(1, copyArea.Object, pasteArea.Object);

            // ASSERT
            Assert.That(result.TenorCellRanges, Is.Empty);
        }

        [Test]
        public void ShouldReturnTenorRange_Equals_CopyArea_When_PasteSingleCell_Below_CopyMultipleTenors()
        {
            var copyArea = new Mock<CellRange>();

            copyArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            copyArea.SetupGet(a => a.RowCount).Returns(2);

            var cellValue1 = CellValue.FromDateTime(new DateTime(2024, 1, 1), false);
            var cell1 = Mock.Of<Cell>(c => c.Value == cellValue1 && c.ColumnIndex == 0);

            var cellValue2 = CellValue.FromDateTime(new DateTime(2024, 2, 1), false);
            var cell2 = Mock.Of<Cell>(c => c.Value == cellValue2 && c.ColumnIndex == 0);

            var list = new List<Cell> { cell1, cell2 };

            copyArea.Setup(a => a.GetEnumerator())
                    .Returns(() => list.GetEnumerator());

            var pasteArea = new Mock<CellRange>();

            pasteArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            pasteArea.SetupGet(a => a.TopRowIndex).Returns(2);
            pasteArea.SetupGet(a => a.RowCount).Returns(1);

            var service = new PasteExtendTenorsService();

            var expectedRange = new ColumnCellRange(0, 2, 3);
            var expectedRanges = new[] { expectedRange };

            var expectedTenors = new[] { new DateTime(2024, 3, 1), new DateTime(2024, 4, 1) };

            // ACT
            var result = service.GetTenorsUpdate(1, copyArea.Object, pasteArea.Object);

            // ASSERT
            Assert.That(result.TenorCellRanges.Keys.SequenceEqual(expectedRanges, new ColumnCellRangeEqualityComparer()));
            Assert.That(result.TenorCellRanges[expectedRange].SequenceEqual(expectedTenors));
        }

        [Test]
        public void ShouldReturnMultipleTenorColumns_When_PasteBelow_With_CopyMultipleTenorColumns()
        {
            var copyArea = new Mock<CellRange>();

            copyArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            copyArea.SetupGet(a => a.RowCount).Returns(1);

            var cellValue1 = CellValue.FromDateTime(new DateTime(2024, 1, 1), false);
            var cell1 = Mock.Of<Cell>(c => c.Value == cellValue1 && c.ColumnIndex == 0);

            var cellValue2 = CellValue.FromDateTime(new DateTime(2024, 4, 1), false);
            var cell2 = Mock.Of<Cell>(c => c.Value == cellValue2 && c.ColumnIndex == 1);

            var list = new List<Cell> { cell1, cell2 };

            copyArea.Setup(a => a.GetEnumerator())
                    .Returns(() => list.GetEnumerator());

            var pasteArea = new Mock<CellRange>();

            pasteArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            pasteArea.SetupGet(a => a.TopRowIndex).Returns(2);
            pasteArea.SetupGet(a => a.RowCount).Returns(2);

            var service = new PasteExtendTenorsService();

            var expectedRange1 = new ColumnCellRange(0, 2, 3);
            var expectedRange2 = new ColumnCellRange(1, 2, 3);
            var expectedRanges = new[] { expectedRange1, expectedRange2 };

            var expectedTenors1 = new[] { new DateTime(2024, 2, 1), new DateTime(2024, 3, 1) };
            var expectedTenors2 = new[] { new DateTime(2024, 5, 1), new DateTime(2024, 6, 1) };

            // ACT
            var result = service.GetTenorsUpdate(1, copyArea.Object, pasteArea.Object);

            // ASSERT
            Assert.That(result.TenorCellRanges.Keys.SequenceEqual(expectedRanges, new ColumnCellRangeEqualityComparer()));
            Assert.That(result.TenorCellRanges[expectedRange1].SequenceEqual(expectedTenors1));
            Assert.That(result.TenorCellRanges[expectedRange2].SequenceEqual(expectedTenors2));
        }

        // todo : check
        [Test]
        public void ShouldGenerateMultipleColumnTenors_From_PasteMultipleColumns_With_CopyMultipleColumns_ContainsNonDateColumn()
        {
            var copyArea = new Mock<CellRange>();

            copyArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            copyArea.SetupGet(a => a.RowCount).Returns(1);

            var cellValue1 = CellValue.FromDateTime(new DateTime(2024, 1, 1), false);
            var cell1 = Mock.Of<Cell>(c => c.Value == cellValue1 && c.ColumnIndex == 0);

            var cell2 = Mock.Of<Cell>(c => c.Value == CellValue.Empty && c.ColumnIndex == 1);

            var cellValue3 = CellValue.FromDateTime(new DateTime(2024, 4, 1), false);
            var cell3 = Mock.Of<Cell>(c => c.Value == cellValue3 && c.ColumnIndex == 2);

            var list = new List<Cell> { cell1, cell2, cell3 };

            copyArea.Setup(a => a.GetEnumerator())
                    .Returns(() => list.GetEnumerator());

            var pasteArea = new Mock<CellRange>();

            pasteArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            pasteArea.SetupGet(a => a.TopRowIndex).Returns(2);
            pasteArea.SetupGet(a => a.RowCount).Returns(2);

            var service = new PasteExtendTenorsService();

            var expectedRange1 = new ColumnCellRange(0, 2, 3);
            var expectedRange2 = new ColumnCellRange(2, 2, 3);
            var expectedRanges = new[] { expectedRange1, expectedRange2 };

            var expectedTenors1 = new[] { new DateTime(2024, 2, 1), new DateTime(2024, 3, 1) };
            var expectedTenors2 = new[] { new DateTime(2024, 5, 1), new DateTime(2024, 6, 1) };

            // ACT
            var result = service.GetTenorsUpdate(1, copyArea.Object, pasteArea.Object);

            // ASSERT
            Assert.That(result.TenorCellRanges.Keys.SequenceEqual(expectedRanges, new ColumnCellRangeEqualityComparer()));
            Assert.That(result.TenorCellRanges[expectedRange1].SequenceEqual(expectedTenors1));
            Assert.That(result.TenorCellRanges[expectedRange2].SequenceEqual(expectedTenors2));
        }

        [Test]
        public void ShouldReturnSingleTenorColumnTenor_When_PasteMultipleColumns_Below_CopySingleTenorColumn()
        {
            var copyArea = new Mock<CellRange>();

            copyArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            copyArea.SetupGet(a => a.RowCount).Returns(1);

            var cellValue1 = CellValue.FromDateTime(new DateTime(2024, 1, 1), false);
            var cell1 = Mock.Of<Cell>(c => c.Value == cellValue1 && c.ColumnIndex == 0);

            var list = new List<Cell> { cell1 };

            copyArea.Setup(a => a.GetEnumerator())
                    .Returns(() => list.GetEnumerator());

            var pasteArea = new Mock<CellRange>();

            pasteArea.SetupGet(a => a.LeftColumnIndex).Returns(0);
            pasteArea.SetupGet(a => a.TopRowIndex).Returns(2);
            pasteArea.SetupGet(a => a.RowCount).Returns(2);

            var service = new PasteExtendTenorsService();

            var expectedRange1 = new ColumnCellRange(0, 2, 3);
            var expectedRanges = new[] { expectedRange1 };

            var expectedTenors1 = new[] { new DateTime(2024, 2, 1), new DateTime(2024, 3, 1) };

            // ACT
            var result = service.GetTenorsUpdate(1, copyArea.Object, pasteArea.Object);

            // ASSERT
            Assert.That(result.TenorCellRanges.Keys.SequenceEqual(expectedRanges, new ColumnCellRangeEqualityComparer()));
            Assert.That(result.TenorCellRanges[expectedRange1].SequenceEqual(expectedTenors1));
        }
    }
}
