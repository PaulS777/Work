﻿using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Dashboard.ScratchPad.Services.Commands;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services.Commands
{
    [TestFixture]
    public class ColumnShiftServiceTests
    {
        [Test]
        public void ShouldShiftBoundPriceCells_After_InsertedColumns()
        {
            var cellPoint1 = new CellPoint(1, 1);
            var cellPoint2 = new CellPoint(2, 1);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.1m);

            var boundPriceCells = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                  {
                                      { cellPoint1, new List<TenorPriceCell>{ priceCell1 }},
                                      { cellPoint2, new List<TenorPriceCell>{ priceCell2 }}
                                  };

            var service = new ColumnShiftService();

            var cellPoint3 = new CellPoint(4, 1);

            var expectedRemoves = new[] { cellPoint2 };
            var expectedAdds = new[] { cellPoint3 };
            var expectedPriceCells = new[] { priceCell2 };

            // ACT
            var result = service.GetShiftedColumnsBindingsUpdate(2, 2, boundPriceCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedAdds));
            Assert.That(result.CellRangesToAdd[cellPoint3].SequenceEqual(expectedPriceCells));
        }

        [Test]
        public void ShouldShiftBoundPriceCells_After_RemovedColumns()
        {
            var cellPoint1 = new CellPoint(1, 1);
            var cellPoint2 = new CellPoint(4, 1);

            var priceCell1 = Defaults.TenorPriceCell(1.1m);
            var priceCell2 = Defaults.TenorPriceCell(2.1m);

            var boundPriceCells = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                  {
                                      { cellPoint1, new List<TenorPriceCell>{ priceCell1 }},
                                      { cellPoint2, new List<TenorPriceCell>{ priceCell2 }}
                                  };

            var service = new ColumnShiftService();

            var cellPoint3 = new CellPoint(2, 1);

            var expectedRemoves = new[] { cellPoint2 };
            var expectedAdds = new[] { cellPoint3 };
            var expectedPriceCells = new[] { priceCell2 };

            // ACT
            var result = service.GetShiftedColumnsBindingsUpdate(2, -2, boundPriceCells);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedRemoves));
            Assert.That(result.CellRangesToAdd.Keys.SequenceEqual(expectedAdds));
            Assert.That(result.CellRangesToAdd[cellPoint3].SequenceEqual(expectedPriceCells));
        }
    }
}
