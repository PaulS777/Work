﻿using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class MergeColumnCellRangeServiceTests
    {
        [Test]
        public void ShouldMergeAdjacentCellRanges()
        {
            var range1 = new ColumnCellRange(0, 1, 2);

            var priceCell1 = Defaults.TenorPriceCell();
            var priceCell2 = Defaults.TenorPriceCell();

            var range2 = new ColumnCellRange(0, 3, 4);

            var priceCell3 = Defaults.TenorPriceCell();
            var priceCell4 = Defaults.TenorPriceCell();

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { range1, new []{ priceCell1, priceCell2 }},
                                        { range2, new []{ priceCell3, priceCell4 }}
                                    };

            var service = new MergeColumnCellRangesService();

            var cellPoint1 = new CellPoint(0, 1);
            var cellPoint2 = new CellPoint(0, 3);

            var expectedCellPoints = new[] { cellPoint1, cellPoint2 };
            var expectedPriceCells = new[] { priceCell1, priceCell2, priceCell3, priceCell4 };


            // ACT
            var result = service.MergeAdjacentColumnCellRanges(3, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPoints));

            Assert.That(result.CellRangesToAdd.Count, Is.EqualTo(1));
            Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(expectedPriceCells));
        }

        [Test]
        public void ShouldReturnEmpty_When_CellRangesNotAdjacent_MissingLowerRange()
        {
            var range1 = new ColumnCellRange(0, 0, 1);

            var priceCell1 = Defaults.TenorPriceCell();
            var priceCell2 = Defaults.TenorPriceCell();

            var range2 = new ColumnCellRange(0, 3, 4);

            var priceCell3 = Defaults.TenorPriceCell();
            var priceCell4 = Defaults.TenorPriceCell();

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { range1, new []{ priceCell1, priceCell2 }},
                                        { range2, new []{ priceCell3, priceCell4 }}
                                    };

            var service = new MergeColumnCellRangesService();

            // ACT
            var result = service.MergeAdjacentColumnCellRanges(3, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);
            Assert.That(result.CellRangesToAdd, Is.Empty);
        }

        [Test]
        public void ShouldReturnEmpty_When_CellRangesNotAdjacent_MissingUpperRange()
        {
            var range1 = new ColumnCellRange(0, 1, 2);

            var priceCell1 = Defaults.TenorPriceCell();
            var priceCell2 = Defaults.TenorPriceCell();

            var range2 = new ColumnCellRange(0, 4, 5);

            var priceCell3 = Defaults.TenorPriceCell();
            var priceCell4 = Defaults.TenorPriceCell();

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { range1, new []{ priceCell1, priceCell2 }},
                                        { range2, new []{ priceCell3, priceCell4 }}
                                    };

            var service = new MergeColumnCellRangesService();

            // ACT
            var result = service.MergeAdjacentColumnCellRanges(3, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove, Is.Empty);
            Assert.That(result.CellRangesToAdd, Is.Empty);
        }

        [Test]
        public void ShouldMergeAdjacentCellRanges_With_MultipleColumns()
        {
            var range1 = new ColumnCellRange(0, 1, 2);

            var priceCell1 = Defaults.TenorPriceCell();
            var priceCell2 = Defaults.TenorPriceCell();

            var range2 = new ColumnCellRange(0, 3, 4);

            var priceCell3 = Defaults.TenorPriceCell();
            var priceCell4 = Defaults.TenorPriceCell();

            var range3 = new ColumnCellRange(2, 1, 2);

            var priceCell5 = Defaults.TenorPriceCell();
            var priceCell6 = Defaults.TenorPriceCell();

            var range4 = new ColumnCellRange(2, 3, 4);

            var priceCell7 = Defaults.TenorPriceCell();
            var priceCell8 = Defaults.TenorPriceCell();

            // single column
            var boundPriceColumns = new Dictionary<ColumnCellRange, IList<TenorPriceCell>>
                                    {
                                        { range1, new []{ priceCell1, priceCell2 }},
                                        { range2, new []{ priceCell3, priceCell4 }},
                                        { range3, new []{ priceCell5, priceCell6 }},
                                        { range4, new []{ priceCell7, priceCell8 }}
                                    };

            var service = new MergeColumnCellRangesService();

            var cellPoint1 = new CellPoint(0, 1);
            var cellPoint2 = new CellPoint(0, 3);
            var cellPoint3 = new CellPoint(2, 1);
            var cellPoint4 = new CellPoint(2, 3);

            var expectedCellPoints = new[] { cellPoint1, cellPoint2, cellPoint3, cellPoint4 };
            var expectedPriceCells1 = new[] { priceCell1, priceCell2, priceCell3, priceCell4 };
            var expectedPriceCells2 = new[] { priceCell5, priceCell6, priceCell7, priceCell8 };

            // ACT
            var result = service.MergeAdjacentColumnCellRanges(3, boundPriceColumns);

            // ASSERT
            Assert.That(result.CellRangesToRemove.SequenceEqual(expectedCellPoints));

            Assert.That(result.CellRangesToAdd.Count, Is.EqualTo(2));
            Assert.That(result.CellRangesToAdd[cellPoint1].SequenceEqual(expectedPriceCells1));
            Assert.That(result.CellRangesToAdd[cellPoint3].SequenceEqual(expectedPriceCells2));
        }
    }
}
