﻿using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Markets.Common.ViewModels.Price;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class WorksheetSettingsFactoryTests
    {
        [Test] 
        public void ShouldCreateWorksheetSettings_From_PriceCellRanges()
        {
            var cellPoint1 = new CellPoint(1, 2);

            var priceCell1 = new TenorPriceCell(101, 20230102, new PriceValue());
            var priceCell2 = new TenorPriceCell(101, 20230103, new PriceValue());

            var priceCellRanges = new Dictionary<CellPoint, IList<TenorPriceCell>>
                                  {
                                      {
                                          cellPoint1, new[]{priceCell1, priceCell2}
                                      }
                                  };

            var expectedWorksheetBindingLists = new[]
                                                {
                                                    new WorksheetBindingList
                                                    {
                                                        ColumnIndex = 1,
                                                        RowIndex = 2,
                                                        BindingListItems = new List<BindingListItemSetting>
                                                                           {
                                                                               new() { CurveId = 101, Tenor = 20230102 },
                                                                               new() { CurveId = 101, Tenor = 20230103 }
                                                                           }
                                                    }
                                                };

            var factory = new WorksheetSettingsFactory();

            // ACT
            var result = factory.CreateWorksheetSettings(1, priceCellRanges);

            // ASSERT
            Assert.That(result.WorksheetId, Is.EqualTo(1));

            Assert.That(result.WorksheetBindingListCollection.SequenceEqual(expectedWorksheetBindingLists,
                                                                            new WorksheetBindingListComparer()));
        }
    }
}
