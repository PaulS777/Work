﻿using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Models;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.UnitTest.Helpers.Comparers;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Services
{
    [TestFixture]
    public class BoundPriceCellsColumnLookupTests
    {
        [Test]
        public void GetBindingsCellRange_With_CacheInitialized_For_Worksheet()
        {
            var worksheetId = 1;

            var cellPoint1 = new CellPoint(0, 0);

            var priceCurve1 = new[]
                              {
                                  new TenorPriceCell(1, 1000, new PriceValue()),
                                  new TenorPriceCell(1, 1000, new PriceValue()),
                                  new TenorPriceCell(1, 1000, new PriceValue())
                              };

            var cellPoint2 = new CellPoint(1, 0);

            var priceCurve2 = new[] { new TenorPriceCell(1, 1000, new PriceValue()) };

            var bindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                           {
                               { cellPoint1, priceCurve1 },
                               { cellPoint2, priceCurve2 }
                           };

            var worksheets = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>> { { worksheetId, bindings } };

            var boundPriceCellsColumnLookup = new BoundPriceCellsColumnLookup();

            boundPriceCellsColumnLookup.RestoreBoundPriceCells(worksheets);

            var cellRange1 = new ColumnCellRange(0, 0, 2);
            var cellRange2 = new ColumnCellRange(1, 0, 0);

            var expectedCellRanges = new[] { cellRange1, cellRange2 };

            // ACT
            var result = boundPriceCellsColumnLookup.GetWorksheetBoundPriceCellsByColumnCellRange(worksheetId);

            // ASSERT
            Assert.That(result.Keys.SequenceEqual(expectedCellRanges, new ColumnCellRangeEqualityComparer()));

            Assert.That(result[cellRange1].SequenceEqual(priceCurve1));
            Assert.That(result[cellRange2].SequenceEqual(priceCurve2));
        }

        [Test]
        public void GetBindingsPriceCells_With_CacheInitialized_For_Worksheet()
        {
            var worksheetId = 1;

            var cellPoint1 = new CellPoint(0, 0);

            var priceCurve1 = new[]
                              {
                                  new TenorPriceCell(1, 1000, new PriceValue()),
                                  new TenorPriceCell(1, 1000, new PriceValue()),
                                  new TenorPriceCell(1, 1000, new PriceValue())
                              };

            var cellPoint2 = new CellPoint(1, 0);

            var priceCurve2 = new[] { new TenorPriceCell(1, 1000, new PriceValue()) };

            var bindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                           {
                               { cellPoint1, priceCurve1 },
                               { cellPoint2, priceCurve2 }
                           };

            var worksheets = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>> { { worksheetId, bindings } };

            var boundPriceCellsColumnLookup = new BoundPriceCellsColumnLookup();

            boundPriceCellsColumnLookup.RestoreBoundPriceCells(worksheets);

            var expectedCellPoints = new[] { cellPoint1, cellPoint2};

            // ACT
            var result = boundPriceCellsColumnLookup.GetWorksheetBoundPriceCells(worksheetId);

            // ASSERT
            Assert.That(result.Keys.SequenceEqual(expectedCellPoints, new CellPointEqualityComparer()));

            Assert.That(result[cellPoint1].SequenceEqual(priceCurve1));
            Assert.That(result[cellPoint2].SequenceEqual(priceCurve2));
        }

        [Test]
        public void ShouldAddBindings_When_ApplyToExistingWorksheet()
        {
            var worksheetId = 1;

            var cellPoint1 = new CellPoint(0, 0);

            var priceCurve1 = new[]
                              {
                                  new TenorPriceCell(1, 1000, new PriceValue()),
                                  new TenorPriceCell(1, 1000, new PriceValue()),
                                  new TenorPriceCell(1, 1000, new PriceValue())
                              };

            var bindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                           {
                               { cellPoint1, priceCurve1 }
                           };

            var worksheets = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>> { { worksheetId, bindings } };

            var boundPriceCellsColumnLookup = new BoundPriceCellsColumnLookup();

            boundPriceCellsColumnLookup.RestoreBoundPriceCells(worksheets);

            var cellPoint2 = new CellPoint(1, 0);

            var priceCurve2 = new[] { new TenorPriceCell(1, 1000, new PriceValue()) };

            var addBindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                         {
                             { cellPoint2, priceCurve2 }
                         };

            var cellRange1 = new ColumnCellRange(0, 0, 2);
            var cellRange2 = new ColumnCellRange(1, 0, 0);

            var expectedCellRanges = new[] { cellRange1, cellRange2 };

            // ACT
            boundPriceCellsColumnLookup.ApplyWorksheetBoundPriceCells(worksheetId, 
                                        addBindings, 
                                        new List<CellPoint>());

            var result = boundPriceCellsColumnLookup.GetWorksheetBoundPriceCellsByColumnCellRange(worksheetId);

            // ASSERT
            Assert.That(result.Keys.SequenceEqual(expectedCellRanges, new ColumnCellRangeEqualityComparer()));

            Assert.That(result[cellRange1].SequenceEqual(priceCurve1));
            Assert.That(result[cellRange2].SequenceEqual(priceCurve2));
        }

        [Test]
        public void ShouldRemoveBindings_When_ApplyToExistingWorksheet()
        {
            var worksheetId = 1;

            var cellPoint1 = new CellPoint(0, 0);

            var priceCurve1 = new[]
                              {
                                  new TenorPriceCell(1, 1000, new PriceValue()),
                                  new TenorPriceCell(1, 1000, new PriceValue()),
                                  new TenorPriceCell(1, 1000, new PriceValue())
                              };

            var bindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                           {
                               { cellPoint1, priceCurve1 }
                           };

            var worksheets = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>> { { worksheetId, bindings } };

            var boundPriceCellsColumnLookup = new BoundPriceCellsColumnLookup();

            boundPriceCellsColumnLookup.RestoreBoundPriceCells(worksheets);

            var cellPoint2 = new CellPoint(1, 0);

            var priceCurve2 = new[] { new TenorPriceCell(1, 1000, new PriceValue()) };

            var bindingsToCreate = new Dictionary<CellPoint, IList<TenorPriceCell>>
                         {
                             { cellPoint2, priceCurve2 }
                         };

            var bindingsToRemove = new[] { cellPoint1 };

            var cellRange2 = new ColumnCellRange(1, 0, 0);

            var expectedCellRanges = new[] { cellRange2 };

            // ACT
            boundPriceCellsColumnLookup.ApplyWorksheetBoundPriceCells(worksheetId,
                                        bindingsToCreate, 
                                        bindingsToRemove);

            var result = boundPriceCellsColumnLookup.GetWorksheetBoundPriceCellsByColumnCellRange(worksheetId);

            // ASSERT
            Assert.That(result.Keys.SequenceEqual(expectedCellRanges, new ColumnCellRangeEqualityComparer()));

            Assert.That(result[cellRange2].SequenceEqual(priceCurve2));
        }

        [Test]
        public void ShouldAddBindings_When_ApplyToNewWorksheet()
        {
            var worksheetId = 2;

            var worksheets = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>>();

            var boundPriceCellsColumnLookup = new BoundPriceCellsColumnLookup();

            boundPriceCellsColumnLookup.RestoreBoundPriceCells(worksheets);

            var cellPoint = new CellPoint(1, 0);

            var priceCurve = new[] { new TenorPriceCell(1, 1000, new PriceValue()) };

            var addBindings = new Dictionary<CellPoint, IList<TenorPriceCell>>
                              {
                                  { cellPoint, priceCurve }
                              };

            var cellRange = new ColumnCellRange(1, 0, 0);

            var expectedCellRanges = new[] { cellRange };

            // ACT
            boundPriceCellsColumnLookup.ApplyWorksheetBoundPriceCells(worksheetId,
                                        addBindings,
                                        new List<CellPoint>());

            var result = boundPriceCellsColumnLookup.GetWorksheetBoundPriceCellsByColumnCellRange(worksheetId);

            // ASSERT
            Assert.That(result.Keys.SequenceEqual(expectedCellRanges, new ColumnCellRangeEqualityComparer()));

            Assert.That(result[cellRange].SequenceEqual(priceCurve));
        }

        [Test]
        public void ShouldGetEmptyBindingsList_GetBindings_With_NoWorksheetBindings()
        {
            var worksheetId = 2;

            var worksheets = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>>();

            var boundPriceCellsColumnLookup = new BoundPriceCellsColumnLookup();

            boundPriceCellsColumnLookup.RestoreBoundPriceCells(worksheets);

            // ACT
            var result = boundPriceCellsColumnLookup.GetWorksheetBoundPriceCellsByColumnCellRange(worksheetId);

            // ASSERT
            Assert.That(result, Is.Empty);
        }

        [Test]
        public void ShouldRemoveWorksheetBindings()
        {
            var worksheets = new Dictionary<int, Dictionary<CellPoint, IList<TenorPriceCell>>>
                             {
                                 { 1, new Dictionary<CellPoint, IList<TenorPriceCell>>() }

                             };

            var boundPriceCellsColumnLookup = new BoundPriceCellsColumnLookup();

            boundPriceCellsColumnLookup.RestoreBoundPriceCells(worksheets);

            // ACT
            boundPriceCellsColumnLookup.RemoveWorksheet(1);

            // ASSERT
            var result = boundPriceCellsColumnLookup.GetWorksheetBoundPriceCells(1);

            // ASSERT
            Assert.That(result, Is.Null);
        }
    }
}
