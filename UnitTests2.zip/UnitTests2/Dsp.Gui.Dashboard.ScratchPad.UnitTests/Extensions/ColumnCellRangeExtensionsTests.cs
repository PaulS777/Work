﻿using NUnit.Framework;
using Dsp.Gui.Dashboard.ScratchPad.Common;
using Dsp.Gui.Dashboard.ScratchPad.Extensions;

namespace Dsp.Gui.Dashboard.ScratchPad.UnitTests.Extensions
{
    public class CellRangeExtensionTests
    {
        [TestCase(1, 3, 0, 2, TestName = "End Inside")]
        [TestCase(0, 1, 1, 2, TestName = "Start Inside")]
        [TestCase(1, 2, 1, 1, TestName = "Inside Start Touching")]
        [TestCase(1, 1, 1, 2, TestName = "Enclosing Start Touching")]
        [TestCase(1, 1, 0, 2, TestName = "Enclosing")]
        [TestCase(1, 1, 0, 1, TestName = "Enclosing End Touching")]
        [TestCase(1, 2, 1, 2, TestName = "Exact Match")]
        [TestCase(1, 1, 1, 1, TestName = "Exact Match With Single Item")]
        [TestCase(0, 2, 1, 1, TestName = "Inside")]
        [TestCase(0, 1, 1, 1, TestName = "Inside End Touching")]
        public void OverlapsCellRange_ShouldReturnTrue(int top1, int bottom1, int top2, int bottom2)
        {
            var range1 = new ColumnCellRange(1, top1, bottom1);
            var range2 = new ColumnCellRange(1, top2, bottom2);

            // ACT
            var result = range1.OverlapsCellRange(range2);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [TestCase(0, 1, 2, 2, TestName = "Start Touching")]
        [TestCase(1, 2, 0, 0, TestName = "End Touching")]
        public void OverlapsCellRange_ShouldReturnFalse(int top1, int bottom1, int top2, int bottom2)
        {
            var range1 = new ColumnCellRange(1, top1, bottom1);
            var range2 = new ColumnCellRange(1, top2, bottom2);

            // ACT
            var result = range1.OverlapsCellRange(range2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void OverlapsCellRange_ShouldReturnFalse_With_DifferentColumns()
        {
            var range1 = new ColumnCellRange(1, 1, 2);
            var range2 = new ColumnCellRange(3, 1, 2);

            // ACT
            var result = range1.OverlapsCellRange(range2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [TestCase(0, 1, 2, 2, TestName = "Start Touching")]
        [TestCase(1, 2, 0, 0, TestName = "End Touching")]
        public void TouchesCellRange_ShouldReturnTrue(int top1, int bottom1, int top2, int bottom2)
        {
            var range1 = new ColumnCellRange(1, top1, bottom1);
            var range2 = new ColumnCellRange(1, top2, bottom2);

            // ACT
            var result = range1.TouchesCellRange(range2);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [TestCase(0, 1, 3, 3, TestName = "Before")]
        [TestCase(2, 3, 0, 0, TestName = "After")]
        public void TouchesCellRange_ShouldReturnFalse(int top1, int bottom1, int top2, int bottom2)
        {
            var range1 = new ColumnCellRange(1, top1, bottom1);
            var range2 = new ColumnCellRange(1, top2, bottom2);

            // ACT
            var result = range1.TouchesCellRange(range2);

            // ASSERT
            Assert.That(result, Is.False);
        }


        [TestCase(1, 3, 0, 2, TestName = "End Inside")]
        [TestCase(0, 1, 1, 2, TestName = "Start Inside")]
        [TestCase(1, 2, 1, 1, TestName = "Inside Start Touching")]
        [TestCase(1, 1, 1, 2, TestName = "Enclosing Start Touching")]
        [TestCase(1, 1, 0, 2, TestName = "Enclosing")]
        [TestCase(1, 1, 0, 1, TestName = "Enclosing End Touching")]
        [TestCase(1, 2, 1, 2, TestName = "Exact Match")]
        [TestCase(1, 1, 1, 1, TestName = "Exact Match With Single Item")]
        [TestCase(0, 2, 1, 1, TestName = "Inside")]
        [TestCase(0, 1, 1, 1, TestName = "Inside End Touching")]
        [TestCase(0, 1, 2, 2, TestName = "Start Touching")]
        [TestCase(1, 2, 0, 0, TestName = "End Touching")]
        public void IntersectsCellRange_ShouldReturnTrue(int top1, int bottom1, int top2, int bottom2)
        {
            var range1 = new ColumnCellRange(1, top1, bottom1);
            var range2 = new ColumnCellRange(1, top2, bottom2);

            // ACT
            var result = range1.IntersectsCellRange(range2);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [TestCase(0, 1, 3, 3, TestName = "Before")]
        [TestCase(2, 3, 0, 0, TestName = "After")]
        public void IntersectsCellRange_ShouldReturnFalse(int top1, int bottom1, int top2, int bottom2)
        {
            var range1 = new ColumnCellRange(1, top1, bottom1);
            var range2 = new ColumnCellRange(1, top2, bottom2);

            // ACT
            var result = range1.IntersectsCellRange(range2);

            // ASSERT
            Assert.That(result, Is.False);
        }
    }
}
