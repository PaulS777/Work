﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.ToolBar.IndicativePricing.Controllers;
using Dsp.Gui.Dashboard.ToolBar.IndicativePricing.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.IndicativePricing.Controllers
{
    internal interface IIndicativePricingViewModelControllerTestObjects
    {
        IPriceCurveSettingsUpdateService UpdateService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        ILogger Logger { get; } 
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        ISubject<List<FxCurveSetting>> FxCurveSettings { get; }
        ISubject<Unit> UpdateResponse { get; }
        IndicativePricingViewModelController Controller { get; }
        IndicativePricingViewModel ViewModel { get; }
    }

    [TestFixture]
    public class IndicativePricingViewModelControllerTests
    {
        private class IndicativePricingViewModelControllerTestObjectBuilder
        {
            private User _currentUser;
            private Dictionary<int, PriceCurveSetting> _priceCurveSettings;
            private List<FxCurveSetting> _fxCurveSettings;

            public IndicativePricingViewModelControllerTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }
            public IndicativePricingViewModelControllerTestObjectBuilder WithPriceCurveSettings(Dictionary<int, PriceCurveSetting> values)
            {
                _priceCurveSettings = values;
                return this;
            }
            public IndicativePricingViewModelControllerTestObjectBuilder WithFxCurveSettings(List<FxCurveSetting> values)
            {
                _fxCurveSettings = values;
                return this;
            }

            public IIndicativePricingViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IIndicativePricingViewModelControllerTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(Observable.Return(_currentUser));

                curveControlService.SetupGet(c => c.CurrentUserSnapshot)
                                   .Returns(_currentUser);

                var settingsList = _priceCurveSettings != null ? 
                    _priceCurveSettings.Select(kvp => kvp.Value).ToList() : new List<PriceCurveSetting>();

                curveControlService.Setup(c => c.GetPriceCurveSettingsSnapshot())
                                   .Returns(settingsList);

                var priceCurveSettings = new BehaviorSubject<Dictionary<int, PriceCurveSetting>>(_priceCurveSettings);

                testObjects.SetupGet(o => o.PriceCurveSettings)
                           .Returns(priceCurveSettings);

                curveControlService.Setup(c => c.GetFxCurveSettingsSnapshot())
                                   .Returns(_fxCurveSettings);

                var fxCurveSettings = new BehaviorSubject<List<FxCurveSetting>>(_fxCurveSettings);

                testObjects.SetupGet(o => o.FxCurveSettings)
                           .Returns(fxCurveSettings);

                var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();

                priceCurveSettingsProvider.SetupGet(p => p.PriceCurveSettings)
                                          .Returns(priceCurveSettings);

                var fxCurveSettingsProvider = new Mock<IFxCurveSettingsProvider>();

                fxCurveSettingsProvider.SetupGet(p => p.FxCurveSettings)
                                       .Returns(fxCurveSettings);

                var updateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.UpdateResponse)
                           .Returns(updateResponse);

                var updateService = new Mock<IPriceCurveSettingsUpdateService>();

                updateService.Setup(u => u.UpdateSettings(It.IsAny<IScheduler>(), 
                                                          It.IsAny<List<PriceCurveSetting>>(), 
                                                          It.IsAny<List<FxCurveSetting>>(), 
                                                          null))
                             .Returns(updateResponse);

                testObjects.SetupGet(o => o.UpdateService)
                           .Returns(updateService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var controller = new IndicativePricingViewModelController(curveControlService.Object,
                                                                          priceCurveSettingsProvider.Object,
                                                                          fxCurveSettingsProvider.Object,
                                                                          updateService.Object,
                                                                          TestMocks.GetSchedulerProvider().Object,
                                                                          TestMocks.GetLoggerFactory().Object)
                {
                    PopupNotificationService = popupNotificationService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object
                };

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeLivePricingTrue_And_ToggleDisabled()
        {
            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsLivePricing, Is.True);
            Assert.That(testObjects.ViewModel.IsEnabled, Is.False);
        }

        [Test]
        public void ShouldEnableToggleSwitch_When_UserIsPublishingPriceCurves()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101, 
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 11, 1.0, true, false)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithFxCurveSettings(fxSettings)
                                                                                         .WithCurrentUser(user)
                                                                                         .Build();

            // ACT
            testObjects.PriceCurveSettings.OnNext(settings);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.True);
        }

        [Test]
        public void ShouldEnableToggleSwitch_When_UserIsPublishingFxCurves()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(11).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 10, 1.0, true, true)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithPriceCurveSettings(settings)
                                                                                         .WithCurrentUser(user)
                                                                                         .Build();

            // ACT
            testObjects.FxCurveSettings.OnNext(fxSettings);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.True);
        }

        [Test]
        public void ShouldDisableToggleSwitch_When_UserIsNotPublishing()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 11, 1.0, true, false)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                         .WithFxCurveSettings(fxSettings)
                                                                                         .WithPriceCurveSettings(settings)
                                                                                         .Build();

            var settingsUpdate = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(99).Build()
                }
            };

            // ACT
            testObjects.PriceCurveSettings.OnNext(settingsUpdate);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.False);
        }

        [Test]
        public void ShouldSetUpdateTradeableCurvesToNonTradeable_On_ToggleIndicativePricing()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithIsTradeable(true).WithPublisherId(10).Build()
                },
                {
                    102,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).WithIsTradeable(true).WithPublisherId(10).Build()
                },
                {
                    103,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(103).WithIsTradeable(false).WithPublisherId(10).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 10, 1.0, true, true)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                         .WithPriceCurveSettings(settings)
                                                                                         .WithFxCurveSettings(fxSettings)
                                                                                         .Build();
            // ACT
            testObjects.ViewModel.IsLivePricing = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.False);

            Mock.Get(testObjects.UpdateService)
                .Verify(u => u.UpdateSettings(It.IsAny<IScheduler>(), 
                                              It.Is<List<PriceCurveSetting>>(s => s.Count == 2
                                                                                  && s[0].IsTradeable == false 
                                                                                  && s[1].IsTradeable == false), 
                                              It.Is<List<FxCurveSetting>>(s => s.Count == 1
                                                                               && s[0].IsTradeable == false), 
                                              null));
        }

        [Test]
        public void ShouldEnableToggle_And_ShowPopup_OnUpdateResponseSuccess()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithIsTradeable(true).WithPublisherId(10).Build()
                },
                {
                    102,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).WithIsTradeable(true).WithPublisherId(10).Build()
                },
                {
                    103,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(103).WithIsTradeable(false).WithPublisherId(10).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 10, 1.0, true, true)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                         .WithPriceCurveSettings(settings)
                                                                                         .WithFxCurveSettings(fxSettings)
                                                                                         .Build();

            testObjects.ViewModel.IsLivePricing = false;

            // ACT
            testObjects.UpdateResponse.OnCompleted();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.True);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }


        [Test]
        public void ShouldEnableToggle_And_ShowErrorDialog_OnUpdateResponseFailed()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).WithIsTradeable(true).Build()
                },
                {
                    102,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).WithPublisherId(10).WithIsTradeable(true).Build()
                },
                {
                    103,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(103).WithPublisherId(10).WithIsTradeable(false).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 10, 1.0, true, true)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                         .WithPriceCurveSettings(settings)
                                                                                         .WithFxCurveSettings(fxSettings)
                                                                                         .Build();

            testObjects.ViewModel.IsLivePricing = false;

            // ACT
            testObjects.UpdateResponse.OnError(new Exception("failed"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.True);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "failed"
                                                                                && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldRevertTradeableStatus_On_ToggleBackToLivePricing()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).WithIsTradeable(true).Build()
                },
                {
                    102,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(103).WithPublisherId(10).WithIsTradeable(true).Build()
                },
                {
                    103,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(103).WithPublisherId(10).WithIsTradeable(false).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 10, 1.0, true, true)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                         .WithPriceCurveSettings(settings)
                                                                                         .WithFxCurveSettings(fxSettings)
                                                                                         .Build();
            testObjects.ViewModel.IsLivePricing = false;

            // ACT
            testObjects.ViewModel.IsLivePricing = true;

            // ASSERT
            Mock.Get(testObjects.UpdateService)
                .Verify(u => u.UpdateSettings(It.IsAny<IScheduler>(), 
                                              It.Is<List<PriceCurveSetting>>(s => s.Count == 2
                                                                                  && s[0].IsTradeable
                                                                                  && s[1].IsTradeable),
                                              It.Is<List<FxCurveSetting>>(s => s.Count == 1
                                                                               && s[0].IsTradeable),
                                              null));
        }

        [Test]
        public void ShouldNotEnableToggleSwitch_When_Disposed()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithIsTradeable(true).WithPublisherId(10).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 10, 1.0, true, true)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                         .WithFxCurveSettings(fxSettings)
                                                                                         .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.PriceCurveSettings.OnNext(settings);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var user = new UserBuilder().WithId(10)
                                        .User();

            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithIsTradeable(true).WithPublisherId(10).Build()
                }
            };

            var fxSettings = new List<FxCurveSetting>
            {
                new(201, 10, 1.0, true, true)
            };

            var testObjects = new IndicativePricingViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                         .WithFxCurveSettings(fxSettings)
                                                                                         .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.PriceCurveSettings.OnNext(settings);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsEnabled, Is.False);
        }
    }
}
