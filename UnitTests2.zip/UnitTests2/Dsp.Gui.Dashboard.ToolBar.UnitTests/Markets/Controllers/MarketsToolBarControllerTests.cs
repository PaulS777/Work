﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.ToolBar.Markets.Controllers;
using Dsp.Gui.Dashboard.ToolBar.Markets.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.Markets.Controllers
{
    internal interface IMarketsToolBarControllerTestObjects
    {
        ISubject<int> CurrentMarketsPageNumber { get; }
        ISubject<bool> ShowCurrentMarketsToolBar { get; }
        MarketsToolBarViewModel ViewModel { get; }
        MarketsToolBarController Controller { get; }
    }

    [TestFixture]
    public class MarketsToolBarControllerTests
    {
        private class MarketsToolBarControllerTestObjectBuilder
        {
            private List<PriceGridToolBarViewModel> _priceGridToolBars;

            public MarketsToolBarControllerTestObjectBuilder WithPriceGridToolBars(List<PriceGridToolBarViewModel> values)
            {
                _priceGridToolBars = values;
                return this;
            }

            public IMarketsToolBarControllerTestObjects Build()
            {
                var testObjects = new Mock<IMarketsToolBarControllerTestObjects>();

                var currentMarketsPageNumber = new Subject<int>();

                testObjects.SetupGet(o => o.CurrentMarketsPageNumber)
                           .Returns(currentMarketsPageNumber);

                var showMarketsToolBar = new Subject<bool>();

                testObjects.SetupGet(o => o.ShowCurrentMarketsToolBar)
                           .Returns(showMarketsToolBar);

                var toolBarUpdateService = new Mock<IToolBarUpdateService>();

                toolBarUpdateService.SetupGet(tb => tb.OnSetCurrentMarketsPageNumber)
                                    .Returns(currentMarketsPageNumber);

                toolBarUpdateService.SetupGet(tb => tb.OnShowMarketsToolBar)
                                    .Returns(showMarketsToolBar);

                var controller = new MarketsToolBarController(toolBarUpdateService.Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                controller.ViewModel.PriceGridToolBars = _priceGridToolBars;

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetSelectedToolBar_On_CurrentMarketsPageNumber()
        {
            var toolBar1 = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 1 };
            var toolBar2 = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 2 };
            var toolBar3 = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 3 };

            var toolBars = new List<PriceGridToolBarViewModel> { toolBar1, toolBar2, toolBar3 };

            var testObjects = new MarketsToolBarControllerTestObjectBuilder().WithPriceGridToolBars(toolBars)
                                                                             .Build();

            // ACT
            testObjects.CurrentMarketsPageNumber.OnNext(2);

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedToolBar, Is.SameAs(toolBar2));
        }

        [Test]
        public void ShouldShowToolBar_On_ShowMarketsToolBar()
        {
            var testObjects = new MarketsToolBarControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowCurrentMarketsToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldNotShowToolBar_When_Disposed()
        {
            var testObjects = new MarketsToolBarControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ShowCurrentMarketsToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new MarketsToolBarControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ShowCurrentMarketsToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowToolBar, Is.False);
        }
    }
}
