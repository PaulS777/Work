﻿using System;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.ToolBar.Markets.Controllers;
using Dsp.Gui.Dashboard.ToolBar.Markets.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.Markets.Controllers
{
    internal interface IPriceGridToolBarControllerTestObjects
    {
        ISubject<DashboardSettingsCollection> DashboardSettings { get; }
        PriceGridToolBarViewModel ViewModel { get; } 
        IPriceGridToolBarController Controller { get; }
    }

    [TestFixture]
    public class PriceGridToolBarControllerTests
    {
        private class PriceGridToolBarControllerTestObjectBuilder
        {
            private bool _priceGridIsBusy;
            private bool _showMarketsFilter;
            private DashboardSettingsCollection _dashboardSettings;

            public PriceGridToolBarControllerTestObjectBuilder WithPriceGridIsBusy(bool value)
            {
                _priceGridIsBusy = value;
                return this;
            }
            public PriceGridToolBarControllerTestObjectBuilder WithShowMarketsFilter(bool value)
            {
                _showMarketsFilter = value;
                return this;
            }

            public PriceGridToolBarControllerTestObjectBuilder WithDashboardSettings(DashboardSettingsCollection values)
            {
                _dashboardSettings = values;
                return this;
            }

            public IPriceGridToolBarControllerTestObjects Build()
            {
                var testObjects = new Mock<IPriceGridToolBarControllerTestObjects>();

                var settings = new BehaviorSubject<DashboardSettingsCollection>(_dashboardSettings);

                testObjects.SetupGet(o => o.DashboardSettings)
                           .Returns(settings);

                var settingsService = new Mock<IDashboardSettingsService>();

                settingsService.SetupGet(d => d.DashboardSettings)
                               .Returns(settings);

                var controller = new PriceGridToolBarController(settingsService.Object);

                controller.ViewModel.PriceGridIsBusy = _priceGridIsBusy;
                controller.ViewModel.ShowMarketsFilter = _showMarketsFilter;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region Enable/Disable Remove Dashboard

        [Test]
        public void ShouldEnableRemoveDashboardCommand_When_RemoveDashboardEnabledTrue()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.RemoveDashboardEnabled = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.RemoveDashboardCommand.CanExecute, Is.True);
        }

        [Test]
        public void ShouldEnableRemoveDashboard_OnSettings_With_MultipleDashboards()
        {
            var settings = new DashboardSettingsCollection
                           { 
                               DashboardSettings = [new(), new()]
                           };

            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ACT
            testObjects.DashboardSettings.OnNext(settings);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.RemoveDashboardEnabled, Is.True);
        }

        [Test]
        public void ShouldDisableRemoveDashboard_OnSettings_With_SingleDashboard()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings = [new()]
                           };

            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ACT
            testObjects.DashboardSettings.OnNext(settings);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.RemoveDashboardEnabled, Is.False);
        }

        [Test]
        public void ShouldDisableRemoveDashboard_When_PriceGridIsBusy()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings = [new(), new()]
                           };

            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                               .WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ACT
            testObjects.ViewModel.PriceGridIsBusy = true;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.RemoveDashboardEnabled, Is.False);
        }

        [Test]
        public void ShouldEnableRemoveDashboard_When_PriceGridIsBusyFalse()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings = [new(), new()]
                           };

            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                               .WithPriceGridIsBusy(true)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ACT
            testObjects.ViewModel.PriceGridIsBusy = false;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.RemoveDashboardEnabled, Is.True);
        }

        [Test]
        public void ShouldNotDisableRemoveDashboard_When_ShowMarketsFilter()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings = [new(), new()]
                           };

            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(false)
                                                                               .WithDashboardSettings(settings)
                                                                               .Build();
            // ACT
            testObjects.ViewModel.ShowMarketsFilter = true;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.RemoveDashboardEnabled, Is.True);
        }

        #endregion

        #region Remove Dashboard Command

        [Test]
        public void ShouldRaiseRemoveDashboard_On_RemoveDashboardCommand()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().Build();

            var result = false;

            using (testObjects.Controller.ViewModel.OnRemoveDashboard().Subscribe(_ => result = true))
            {
                // ACT
                testObjects.Controller.ViewModel.RemoveDashboardCommand.Execute();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        #endregion

        #region Enable/Disable Filter Settings 

        [Test]
        public void ShouldEnableFilterMarkets_And_PriceGridSettings_Commands_When_EnableFilterSettingsTrue()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().Build();
            // ACT
            testObjects.ViewModel.FilterSettingsEnabled = true;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.FilterMarketsCommand.CanExecute, Is.True);
            Assert.That(testObjects.Controller.ViewModel.PriceGridSettingsCommand.CanExecute, Is.True);
        }

        [Test]
        public void ShouldDisableFilterSettings_When_PriceGridIsBusy()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ACT
            testObjects.ViewModel.PriceGridIsBusy = true;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.FilterSettingsEnabled, Is.False);
        }

        [Test]
        public void ShouldDisableFilterSettings_When_ShowMarketsFilter()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ACT
            testObjects.ViewModel.ShowMarketsFilter = true;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.FilterSettingsEnabled, Is.False);
        }

        [Test]
        public void ShouldEnableFilterSettings_When_PriceGridIsBusyFalse()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithPriceGridIsBusy(true)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ACT
            testObjects.ViewModel.PriceGridIsBusy = false;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.FilterSettingsEnabled, Is.True);
        }

        [Test]
        public void ShouldEnableFilterSettings_When_CloseMarketsFilter()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(true)
                                                                               .Build();
            // ACT
            testObjects.ViewModel.ShowMarketsFilter = false;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.FilterSettingsEnabled, Is.True);
        }

        #endregion

        #region Filter Markets and Price Grid Settings Commands

        [Test]
        public void ShouldShowMarketsFilter_On_FilterMarketsCommand()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.FilterMarketsCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowMarketsFilter, Is.True);
        }

        [Test]
        public void ShouldShowPriceGridSettings_On_PriceGridSettingsCommand()
        {
            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.PriceGridSettingsCommand.Execute();

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.ShowPriceGridSettings, Is.True);
        }

        #endregion

        #region Dispose

        [Test]
        public void ShouldNotEnableRemoveDashboardCommand_When_Disposed()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings = [new(), new()]
                           };

            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                               .WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ARRANGE
            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.PriceGridIsBusy = true;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.RemoveDashboardEnabled, Is.True);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings = [new(), new()]
                           };

            var testObjects = new PriceGridToolBarControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                               .WithPriceGridIsBusy(false)
                                                                               .WithShowMarketsFilter(false)
                                                                               .Build();
            // ARRANGE
            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.PriceGridIsBusy = true;

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.RemoveDashboardEnabled, Is.True);
        }

        #endregion
    }
}
