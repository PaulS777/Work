﻿using System;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services.Application;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.ToolBar.Info.Controllers;
using Dsp.Gui.Dashboard.ToolBar.Info.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;
using Windows.ApplicationModel;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.ToolBar.Info.Services;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.Info.Controllers
{
    internal interface IReleaseNotesViewModelControllerTestObjects
    {
        IInfoToolBarService InfoToolBarService { get; }
        IDashboardSettingsService DashboardSettingsService { get; }
        IClickOnceUninstallService ClickOnceUninstallService { get; }
        ISubject<bool> DashboardSettingsLoaded { get; }
        ISubject<bool> ClickOnceUninstallResult { get; }
        ISubject<Unit> ShowInfo { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        ILogger Logger { get; }
        ReleaseNotesViewModel ViewModel { get; }
        ReleaseNotesViewModelController Controller { get; }
    }

    [TestFixture]
    public class ReleaseNotesViewModelControllerTests
    {
        private class ReleaseNotesViewModelControllerTestBuilder
        {
            private bool _isNetworkDeployment;
            private PackageVersion _packageVersion;
            private Uri _infoHomeUrl;
            private Uri _releaseNotesUrl;
            private DashboardVersion _settingsVersion;
            private bool _clickOnceInstalled1;
            private bool _clickOnceInstalled2;

            public ReleaseNotesViewModelControllerTestBuilder WithIsNetworkDeployment(bool value)
            {
                _isNetworkDeployment = value;
                return this;
            }

            public ReleaseNotesViewModelControllerTestBuilder WithPackageVersion(PackageVersion value)
            {
                _packageVersion = value;
                return this;
            }

            public ReleaseNotesViewModelControllerTestBuilder WithInfoHomeUrl(string value)
            {
                _infoHomeUrl = string.IsNullOrWhiteSpace(value) ? null : new Uri(value);
                return this;
            }

            public ReleaseNotesViewModelControllerTestBuilder WithReleaseNotesUrl(string value)
            {
                _releaseNotesUrl = string.IsNullOrWhiteSpace(value) ? null : new Uri(value);
                return this;
            }

            public ReleaseNotesViewModelControllerTestBuilder WithSettingsVersion(DashboardVersion value)
            {
                _settingsVersion = value;
                return this;
            }

            public ReleaseNotesViewModelControllerTestBuilder WithClickOnceInstalledFirst(bool value)
            {
                _clickOnceInstalled1 = value;
                return this;
            }


            public ReleaseNotesViewModelControllerTestBuilder WithClickOnceInstalledSecond(bool value)
            {
                _clickOnceInstalled2 = value;
                return this;
            }

            public IReleaseNotesViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IReleaseNotesViewModelControllerTestObjects>();

                var showInfo = new Subject<Unit>();

                testObjects.SetupGet(o => o.ShowInfo)
                           .Returns(showInfo);

                var toolBarService = new Mock<IInfoToolBarService>();

                toolBarService.SetupGet(o => o.ShowInfo)
                              .Returns(showInfo);

                testObjects.SetupGet(o => o.InfoToolBarService)
                           .Returns(toolBarService.Object);

                var dashboardSettingsLoaded = new Subject<bool>();

                testObjects.SetupGet(o => o.DashboardSettingsLoaded)
                           .Returns(dashboardSettingsLoaded);

                var dashboardSettingsService = new Mock<IDashboardSettingsService>();

                dashboardSettingsService.SetupGet(d => d.DashboardSettingsLoaded)
                                        .Returns(dashboardSettingsLoaded);

                dashboardSettingsService.Setup(d => d.GetVersion())
                                        .Returns(_settingsVersion);

                testObjects.SetupGet(o => o.DashboardSettingsService)
                           .Returns(dashboardSettingsService.Object);

                var releaseNotesUriProvider = new Mock<IReleaseNotesUriProvider>();

                releaseNotesUriProvider.SetupGet(p => p.InfoHomeUri)
                                       .Returns(_infoHomeUrl);

                releaseNotesUriProvider.SetupGet(p => p.ReleaseNotesUri)
                                       .Returns(_releaseNotesUrl);
                
                var packageInfoProvider = new Mock<IPackageInfoProvider>();

                packageInfoProvider.SetupGet(p => p.IsNetworkDeployment)
                                   .Returns(_isNetworkDeployment);

                packageInfoProvider.SetupGet(p => p.PackageVersion)
                                   .Returns(_packageVersion);

                var clickOnceUninstallResult = new Subject<bool>();

                testObjects.SetupGet(o => o.ClickOnceUninstallResult)
                           .Returns(clickOnceUninstallResult);

                var clickOnceUninstallService = new Mock<IClickOnceUninstallService>();

                clickOnceUninstallService.SetupSequence(c => c.CheckIfClickOnceInstalled())
                                         .Returns(_clickOnceInstalled1)
                                         .Returns(_clickOnceInstalled2);

                clickOnceUninstallService.Setup(c => c.Uninstall(It.IsAny<IScheduler>()))
                                         .Returns(clickOnceUninstallResult);

                testObjects.SetupGet(o => o.ClickOnceUninstallService)
                           .Returns(clickOnceUninstallService.Object);

                var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

                var loggerFactory = TestMocks.GetLoggerFactory(logger);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var controller = new ReleaseNotesViewModelController(toolBarService.Object,
                                                                     releaseNotesUriProvider.Object,
                                                                     packageInfoProvider.Object,
                                                                     dashboardSettingsService.Object,
                                                                     clickOnceUninstallService.Object,
                                                                     TestMocks.GetSchedulerProvider().Object,
                                                                     loggerFactory.Object)
                {
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    PopupNotificationService = popupNotificationService.Object
                };

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowReleaseNotes_And_UpdateSettings_When_IsNetworkDeployed_And_VersionsEqual()
        {
            var currentVersion = new DashboardVersion(1, 1, 0, 0);
            var packageVersion = new PackageVersion(1,2,0,0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .WithReleaseNotesUrl("http://info/releaseNotes.html")
                                                                              .Build();

            // ACT
            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.True);
            Assert.That(testObjects.ViewModel.DisplayUri.AbsoluteUri, Is.EqualTo("http://info/releaseNotes.html"));

            Mock.Get(testObjects.InfoToolBarService)
                .Verify(i => i.SetInfoOpenState(true));

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(u => u.UpdateVersion(packageVersion));
        }

        [Test]
        public void ShouldShowReleaseNotes_And_UpdateSettings_When_IsNetworkDeployed_And_SettingsVersionNull()
        {
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(null)
                                                                              .WithReleaseNotesUrl("http://info/releaseNotes.html")
                                                                              .Build();

            // ACT
            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.True);
            Assert.That(testObjects.ViewModel.DisplayUri.AbsoluteUri, Is.EqualTo("http://info/releaseNotes.html"));

            Mock.Get(testObjects.InfoToolBarService)
                .Verify(i => i.SetInfoOpenState(true));

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(u => u.UpdateVersion(packageVersion));
        }

        [Test]
        public void ShouldNotShowReleaseNotes_When_IsNetworkDeployed_And_VersionsEqual()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .WithReleaseNotesUrl("http://info/releaseNotes.html")
                                                                              .Build();

            // ACT
            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.False);

            Mock.Get(testObjects.InfoToolBarService)
                .Verify(i => i.SetInfoOpenState(true), Times.Never);

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(u => u.UpdateVersion(It.IsAny<PackageVersion>()), Times.Never);
        }

        [Test]
        public void ShouldNotShowReleaseNotes_When_IsNetworkDeployedFalse()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
           
            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(false)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .WithReleaseNotesUrl("http://info/releaseNotes.html")
                                                                              .Build();

            // ACT
            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.False);

            Mock.Get(testObjects.InfoToolBarService)
                .Verify(i => i.SetInfoOpenState(true), Times.Never);

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(u => u.UpdateVersion(It.IsAny<PackageVersion>()), Times.Never);
        }


        [Test]
        public void ShouldShowInfo_On_ShowInfoCommand()
        {
            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithInfoHomeUrl("http://info/infoHome.html")
                                                                              .Build();

            // ACT
            testObjects.ShowInfo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.True);
            Assert.That(testObjects.ViewModel.DisplayUri.AbsoluteUri, Is.EqualTo("http://info/infoHome.html"));

            Mock.Get(testObjects.InfoToolBarService)
                .Verify(i => i.SetInfoOpenState(true));
        }

        [Test]
        public void ShouldCloseInfo_On_CloseReleaseNotesCommand()
        {
            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithInfoHomeUrl("http://info/infoHome.html")
                                                                              .Build();

            testObjects.ShowInfo.OnNext(Unit.Default);

            // ACT
            testObjects.ViewModel.CloseInfoCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.False);

            Mock.Get(testObjects.InfoToolBarService)
                .Verify(i => i.SetInfoOpenState(false));
        }

        [Test]
        public void ShouldNotShowInfo_When_InfoHomeUrlIsNull()
        {
            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithInfoHomeUrl(null)
                                                                              .Build();

            // ACT
            testObjects.ShowInfo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.False);
        }

        [Test]
        public void ShouldUninstallClickOnce_When_VersionsEqual_And_ClickOnceInstalled()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            // ACT
            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ClickOnceUninstallService)
                .Verify(c => c.Uninstall(It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldNotUninstallClickOnce_When_VersionsEqual_And_ClickOnceNotInstalled()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(false)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            // ACT
            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ClickOnceUninstallService)
                .Verify(c => c.Uninstall(It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldShowPopup_When_UninstallClickOnceSuccess_With_VersionsEqual()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(true)
                                                                              .WithClickOnceInstalledSecond(false)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ACT
            testObjects.ClickOnceUninstallResult.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldNotShowPopup_When_UninstallClickOnceCanceled_With_VersionsEqual()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(true)
                                                                              .WithClickOnceInstalledSecond(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ACT
            testObjects.ClickOnceUninstallResult.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Test]
        public void ShouldShowErrorMessage_When_UninstallClickOnceFailed_With_VersionsEqual()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(true)
                                                                              .WithClickOnceInstalledSecond(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ACT
            testObjects.ClickOnceUninstallResult.OnNext(false);

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldShowErrorMessage_When_UninstallClickOnceError_With_VersionsEqual()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(true)
                                                                              .WithClickOnceInstalledSecond(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ACT
            testObjects.ClickOnceUninstallResult.OnError(new Exception());

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldNotUninstallClickOnce_When_CloseReleaseNotes_With_VersionsEqual()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 2, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(true)
                                                                              .WithClickOnceInstalledSecond(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ACT
            testObjects.ViewModel.CloseInfoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Test]
        public void ShouldNotUninstallClickOnce_On_ShowReleaseNotes_With_NewVersionInstalled_And_ClickOnceInstalled()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 3, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            // ACT
            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ClickOnceUninstallService)
                .Verify(c => c.Uninstall(It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldUninstallClickOnce_When_CloseReleaseNotes_With_NewVersionInstalled_And_ClickOnceInstalled()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 3, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(true)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ACT
            testObjects.ViewModel.CloseInfoCommand.Execute();
    
            // ASSERT
            Mock.Get(testObjects.ClickOnceUninstallService)
                .Verify(c => c.Uninstall(It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldNotUninstallClickOnce_When_CloseReleaseNotes_With_NewVersionInstalled_And_ClickOnceNotInstalled()
        {
            var currentVersion = new DashboardVersion(1, 2, 0, 0);
            var packageVersion = new PackageVersion(1, 3, 0, 0);

            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithIsNetworkDeployment(true)
                                                                              .WithClickOnceInstalledFirst(false)
                                                                              .WithPackageVersion(packageVersion)
                                                                              .WithSettingsVersion(currentVersion)
                                                                              .Build();

            testObjects.DashboardSettingsLoaded.OnNext(true);

            // ACT
            testObjects.ViewModel.CloseInfoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ClickOnceUninstallService)
                .Verify(c => c.Uninstall(It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldNotShowInfo_When_Disposed()
        {
            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithInfoHomeUrl(null)
                                                                              .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ShowInfo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ReleaseNotesViewModelControllerTestBuilder().WithInfoHomeUrl(null)
                                                                              .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ShowInfo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInfo, Is.False);
        }
    }
}
