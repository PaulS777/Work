﻿using System.Reactive;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Controllers;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Controllers
{
    internal interface IMonthEndResetPromptDialogViewModelControllerTestObjects
    {
        IMonthEndResetDialogConfirmationService DialogConfirmationService { get; }
        ISubject<Unit> ShowDialog { get; }
        MonthEndResetPromptDialogViewModel ViewModel { get; }
        MonthEndResetPromptDialogViewModelController Controller { get; }
    }

    [TestFixture]
    public class MonthEndResetPromptDialogViewModelControllerTests
    {
        private class MonthEndResetPromptDialogViewModelControllerTestObjectBuilder
        {
            private bool _showDialog;

            public MonthEndResetPromptDialogViewModelControllerTestObjectBuilder WithShowDialog(bool value)
            {
                _showDialog = value;
                return this;
            }

            public IMonthEndResetPromptDialogViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IMonthEndResetPromptDialogViewModelControllerTestObjects>();

                var showDialog = new Subject<Unit>();

                testObjects.SetupGet(o => o.ShowDialog)
                           .Returns(showDialog);

                var dialogConfirmationService = new Mock<IMonthEndResetDialogConfirmationService>();

                dialogConfirmationService.SetupGet(d => d.ShowDialog)
                                         .Returns(showDialog);

                testObjects.SetupGet(o => o.DialogConfirmationService)
                           .Returns(dialogConfirmationService.Object);

                var controller = new MonthEndResetPromptDialogViewModelController(dialogConfirmationService.Object);

                controller.ViewModel.ShowDialog = _showDialog;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowDialog_On_ConfirmationServiceShowDialog()
        {
            var testObjects = new MonthEndResetPromptDialogViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowDialog.OnNext(Unit.Default);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.ShowDialog);
        }

        [Test]
        public void ShouldCloseDialog_And_SetConfirmReset_On_DialogYesCommand()
        {
            var testObjects = new MonthEndResetPromptDialogViewModelControllerTestObjectBuilder().WithShowDialog(true)
                                                                                              .Build();

            // ACT
            testObjects.ViewModel.DialogYesCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);

            Mock.Get(testObjects.DialogConfirmationService)
                .Verify(d => d.SetConfirmReset());
        }

        [Test]
        public void ShouldCloseDialog_And_SetCancelReset_On_DialogNoCommand()
        {
            var testObjects = new MonthEndResetPromptDialogViewModelControllerTestObjectBuilder().WithShowDialog(true)
                                                                                              .Build();

            // ACT
            testObjects.ViewModel.DialogNoCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);

            Mock.Get(testObjects.DialogConfirmationService)
                .Verify(d => d.SetCancelReset());
        }

        [Test]
        public void ShouldNotShowDialog_When_Disposed()
        {
            var testObjects = new MonthEndResetPromptDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ShowDialog.OnNext(Unit.Default);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new MonthEndResetPromptDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ShowDialog.OnNext(Unit.Default);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }
    }
}
