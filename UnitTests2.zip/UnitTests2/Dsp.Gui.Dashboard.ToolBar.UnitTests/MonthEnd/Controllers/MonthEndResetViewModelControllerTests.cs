﻿using System;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Controllers;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Controllers
{
    internal interface IMonthEndResetViewModelControllerTestObjects
    {
        IMonthEndResetDialogConfirmationService DialogConfirmationService { get; }
        ISubject<Unit> DialogConfirmMonthEndRollReset { get; }
        ISubject<Unit> DialogCancelMonthEndRollReset { get; }
        ISubject<Unit> UpdateMonthEndRollResetResult { get; }
        ISubject<MonthEndRollPricesStatus> RollPricesStatus { get; }
        IRollPricesUpdateService RollPricesUpdateService { get; }
        IMonthEndResetProgressUpdateService MonthEndResetProgressUpdateService { get; }
        MonthEndResetViewModelController Controller { get; }
        MonthEndResetViewModel ViewModel { get; }
    }

    [TestFixture]
    public class MonthEndResetViewModelControllerTests
    {
        private class MonthEndResetViewModelControllerTestObjectBuilder
        {
            private User _user;
            private Exception _monthEndResetException;

            public MonthEndResetViewModelControllerTestObjectBuilder WithCurrentUser(User value)
            {
                _user = value;
                return this;
            }

            public MonthEndResetViewModelControllerTestObjectBuilder WithMonthEndResetException(Exception value)
            {
                _monthEndResetException = value;
                return this;
            }

            public IMonthEndResetViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IMonthEndResetViewModelControllerTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(Observable.Return(_user));

                var rollPricesStatus = new Subject<MonthEndRollPricesStatus>();

                testObjects.SetupGet(o => o.RollPricesStatus)
                           .Returns(rollPricesStatus);

                var rollPricesStatusProvider = new Mock<IRollPricesStatusProvider>();

                rollPricesStatusProvider.SetupGet(p => p.RollPricesStatus)
                                        .Returns(rollPricesStatus);

                var confirmMonthEndRollReset = new Subject<Unit>();

                testObjects.SetupGet(o => o.DialogConfirmMonthEndRollReset)
                           .Returns(confirmMonthEndRollReset);

                var cancelMonthEndRollReset = new Subject<Unit>();

                testObjects.SetupGet(o => o.DialogCancelMonthEndRollReset)
                           .Returns(cancelMonthEndRollReset);

                var dialogConfirmationService = new Mock<IMonthEndResetDialogConfirmationService>();

                dialogConfirmationService.SetupGet(d => d.ConfirmReset)
                                         .Returns(confirmMonthEndRollReset);

                dialogConfirmationService.SetupGet(d => d.CancelReset)
                                         .Returns(cancelMonthEndRollReset);

                testObjects.SetupGet(o => o.DialogConfirmationService)
                           .Returns(dialogConfirmationService.Object);

                var updateMonthEndRollResetResult = new Subject<Unit>();

                testObjects.SetupGet(o => o.UpdateMonthEndRollResetResult)
                           .Returns(updateMonthEndRollResetResult);

                var rollPricesUpdateService = new Mock<IRollPricesUpdateService>();

                rollPricesUpdateService.Setup(rp => rp.UpdateMonthEndRoll(It.IsAny<IScheduler>(), It.IsAny<bool>()))
                                       .Returns(updateMonthEndRollResetResult);

                if (_monthEndResetException != null)
                {
                    rollPricesUpdateService.Setup(rp => rp.UpdateMonthEndRoll(It.IsAny<IScheduler>(), It.IsAny<bool>()))
                                           .Throws(_monthEndResetException);
                }

                testObjects.SetupGet(o => o.RollPricesUpdateService)
                           .Returns(rollPricesUpdateService.Object);

                var progressUpdateService = new Mock<IMonthEndResetProgressUpdateService>();

                testObjects.SetupGet(o => o.MonthEndResetProgressUpdateService)
                           .Returns(progressUpdateService.Object);

                var controller = new MonthEndResetViewModelController(curveControlService.Object,
                                                                      rollPricesStatusProvider.Object,
                                                                      dialogConfirmationService.Object,
                                                                      rollPricesUpdateService.Object,
                                                                      progressUpdateService.Object,
                                                                      TestMocks.GetSchedulerProvider().Object,
                                                                      TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowRestButton_When_UserIsAdmin()
        {
            var user = new UserBuilder().WithIsAdmin(true)
                                        .User();

            // ACT
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                     .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowMonthEndResetButton, Is.True);
        }

        [Test]
        public void ShouldHideRestButton_When_UserIsAdminFalse()
        {
            var user = new UserBuilder().WithIsAdmin(false)
                                        .User();

            // ACT
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                     .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowMonthEndResetButton, Is.False);
        }

        [TestCase(MonthEndRollPricesStatus.AutoRollFailed)]
        [TestCase(MonthEndRollPricesStatus.ManualRollFailed)]
        public void ShouldEnableMonthEndReset_When_RollPricesStatusFailed(MonthEndRollPricesStatus status)
        {
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.RollPricesStatus.OnNext(status);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndResetCommand.CanExecute(), Is.True);
        }

        [TestCase(MonthEndRollPricesStatus.Completed)]
        [TestCase(MonthEndRollPricesStatus.NotRolled)]
        [TestCase(MonthEndRollPricesStatus.Rolling)]
        public void ShouldDisableMonthEndReset_When_RollPricesStatusNotFailed(MonthEndRollPricesStatus status)
        {
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.RollPricesStatus.OnNext(status);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndResetCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldShowConfirmationDialog_On_MonthEndResetCommand()
        {
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.MonthEndResetCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.DialogConfirmationService)
                .Verify(d => d.SetShowDialog());
        }

        [Test]
        public void ShouldShowDialog_And_UpdateMonthEndRollReset_When_DialogConfirmReset()
        {
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.DialogConfirmMonthEndRollReset.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.MonthEndResetProgressUpdateService)
                .Verify(p => p.SetInProgress());

            Mock.Get(testObjects.RollPricesUpdateService)
                .Verify(rp => rp.UpdateMonthEndRoll(It.IsAny<IScheduler>(), true));
        }

        [Test]
        public void ShouldUpdateDialogToCompleted_On_MonthEndRollResetComplete()
        {
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().Build();

 
            testObjects.DialogConfirmMonthEndRollReset.OnNext(Unit.Default);

            // ACT
            testObjects.UpdateMonthEndRollResetResult.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.MonthEndResetProgressUpdateService)
                .Verify(d => d.SetCompleted());
        }


        [Test]
        public void ShouldUpdateDialogToFailed_On_MonthEndRollResetFailed()
        {
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().Build();


            testObjects.DialogConfirmMonthEndRollReset.OnNext(Unit.Default);

            // ACT
            var error = new Exception();
            testObjects.UpdateMonthEndRollResetResult.OnError(error);

            // ASSERT
            Mock.Get(testObjects.MonthEndResetProgressUpdateService)
                .Verify(d => d.SetFailed());
        }

        [Test]
        public void ShouldUpdateDialogToFailed_On_MonthEndRollResetException()
        {
            var error = new Exception();

            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().WithMonthEndResetException(error)
                                                                                     .Build();

            // ACT
            testObjects.DialogConfirmMonthEndRollReset.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.MonthEndResetProgressUpdateService)
                .Verify(d => d.SetFailed());
        }

        [Test]
        public void ShouldNotEnableMonthEndReset_When_Disposed()
        {
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.RollPricesStatus.OnNext(MonthEndRollPricesStatus.ManualRollFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndResetCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new MonthEndResetViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.RollPricesStatus.OnNext(MonthEndRollPricesStatus.ManualRollFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndResetCommand.CanExecute(), Is.False);
        }
    }
}
