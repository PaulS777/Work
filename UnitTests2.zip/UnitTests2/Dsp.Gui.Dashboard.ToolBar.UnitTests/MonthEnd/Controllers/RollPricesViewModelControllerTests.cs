﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Controllers;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Controllers
{
    internal interface IRollPricesViewModelControllerTestObjects
    {
        IRollPricesDialogConfirmationService RollPricesDialogConfirmationService { get; }
        ISubject<Unit> DialogConfirmRollPrices { get; }
        ISubject<Unit> DialogCancelRollPrices { get; }
        IRollPricesUpdateService RollPricesUpdateService { get; }
        IRollPricesProgressUpdateService RollPricesProgressUpdateService { get; }
        ISubject<MonthEndRollPricesStatus> MonthEndRollPricesStatus { get; }
        ISubject<List<DynamicConfiguration>> AutoRollConfig { get; }
        ISubject<Unit> UpdateMonthEndRollResult { get; }
        RollPricesViewModel ViewModel { get; }
        RollPricesViewModelController Controller { get; }
    }

    public class RollPricesViewModelControllerTests
    {
        private class RollPricesViewModelControllerTestObjectBuilder
        {
            private MonthEndRollStatus _latestMonthEndRollStatus;
            private MonthEndRollPricesStatus _monthEndRollPricesStatus;
            private List<string> _flatPriceValidationErrors = new();
            private List<string> _curveLengthValidationErrors = new();
            private List<User> _users;
            private Exception _monthEndRollUpdateException;
            private List<DynamicConfiguration> _autoRollConfiguration = new();

            public RollPricesViewModelControllerTestObjectBuilder WithLatestMonthEndRollStatus(MonthEndRollStatus value)
            {
                _latestMonthEndRollStatus = value;
                return this;
            }

            public RollPricesViewModelControllerTestObjectBuilder WithMonthEndRollPricesStatus(MonthEndRollPricesStatus value)
            {
                _monthEndRollPricesStatus = value;
                return this;
            }

            public RollPricesViewModelControllerTestObjectBuilder WithUsers(List<User> values)
            {
                _users = values;
                return this;
            }

            public RollPricesViewModelControllerTestObjectBuilder WithMonthEndRollUpdateException(Exception value)
            {
                _monthEndRollUpdateException = value;
                return this;
            }

            public RollPricesViewModelControllerTestObjectBuilder WithFlatPriceValidationErrors(List<string> values)
            {
                _flatPriceValidationErrors = values;
                return this;
            }

            public RollPricesViewModelControllerTestObjectBuilder WithCurveLengthValidationErrors(List<string> values)
            {
                _curveLengthValidationErrors = values;
                return this;
            }

            public RollPricesViewModelControllerTestObjectBuilder WithAutoRollConfig(List<DynamicConfiguration> values)
            {
                _autoRollConfiguration = values;
                return this;
            }

            public IRollPricesViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IRollPricesViewModelControllerTestObjects>();

                var autoRollConfig = new BehaviorSubject<List<DynamicConfiguration>>(_autoRollConfiguration);

                testObjects.SetupGet(o => o.AutoRollConfig)
                           .Returns(autoRollConfig);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.Setup(c => c.GetUsersSnapshot())
                                   .Returns(_users);

                curveControlService.SetupGet(c => c.ConfigurationOnUpdate)
                                   .Returns(autoRollConfig);

                var monthEndRollPricesStatus = new BehaviorSubject<MonthEndRollPricesStatus>(_monthEndRollPricesStatus);

                testObjects.SetupGet(o => o.MonthEndRollPricesStatus)
                           .Returns(monthEndRollPricesStatus);

                var rollPricesStatusProvider = new Mock<IRollPricesStatusProvider>();

                rollPricesStatusProvider.SetupGet(p => p.RollPricesStatus)
                                        .Returns(monthEndRollPricesStatus);

                rollPricesStatusProvider.Setup(p => p.GetLatestMonthEndRollStatus())
                                        .Returns(_latestMonthEndRollStatus);

                rollPricesStatusProvider.Setup(p => p.GetFlatPriceValidationErrors())
                                        .Returns(_flatPriceValidationErrors);

                rollPricesStatusProvider.Setup(p => p.GetCurveLengthValidationErrors())
                                        .Returns(_curveLengthValidationErrors);

                var updateMonthEndRollResult = new Subject<Unit>();

                testObjects.SetupGet(o => o.UpdateMonthEndRollResult)
                           .Returns(updateMonthEndRollResult);

                var rollPricesUpdateService = new Mock<IRollPricesUpdateService>();

                rollPricesUpdateService.Setup(u => u.UpdateMonthEndRoll(It.IsAny<IScheduler>(), It.IsAny<bool>()))
                                       .Returns(updateMonthEndRollResult);

                if (_monthEndRollUpdateException != null)
                {
                    rollPricesUpdateService.Setup(u => u.UpdateMonthEndRoll(It.IsAny<IScheduler>(), It.IsAny<bool>()))
                                           .Throws(_monthEndRollUpdateException);
                }

                testObjects.SetupGet(o => o.RollPricesUpdateService)
                           .Returns(rollPricesUpdateService.Object);

                var progressUpdateService = new Mock<IRollPricesProgressUpdateService>();

                testObjects.SetupGet(o => o.RollPricesProgressUpdateService)
                           .Returns(progressUpdateService.Object);

                var dialogConfirmRollPrices = new Subject<Unit>();

                testObjects.SetupGet(o => o.DialogConfirmRollPrices)
                           .Returns(dialogConfirmRollPrices);

                var dialogCancelRollPrices = new Subject<Unit>();

                testObjects.SetupGet(o => o.DialogCancelRollPrices)
                           .Returns(dialogCancelRollPrices);

                var dialogConfirmationService = new Mock<IRollPricesDialogConfirmationService>();

                testObjects.SetupGet(o => o.RollPricesDialogConfirmationService)
                           .Returns(dialogConfirmationService.Object);

                dialogConfirmationService.SetupGet(d => d.ConfirmRollPrices)
                                         .Returns(dialogConfirmRollPrices);

                dialogConfirmationService.SetupGet(d => d.CancelRollPrices)
                                         .Returns(dialogCancelRollPrices);

                var controller = new RollPricesViewModelController(curveControlService.Object, 
                                                                   dialogConfirmationService.Object,
                                                                   rollPricesUpdateService.Object, 
                                                                   rollPricesStatusProvider.Object, 
                                                                   progressUpdateService.Object,
                                                                   TestMocks.GetSchedulerProvider().Object, 
                                                                   TestMocks.GetLoggerFactory().Object);
                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldEnableMonthEndRollCommand_On_StatusNotRolled_With_MissingAutoRollConfig()
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.NotRolled);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableMonthEndRollCommand_On_StatusNotRolled_With_AutoRollOff()
        {
            var config = new List<DynamicConfiguration>
            {
                new(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithAutoRollConfig(config)
                                                                                  .Build();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.NotRolled);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableMonthEndRollCommand_On_StatusNotRolled_With_AutoRollOn()
        {
            var config = new List<DynamicConfiguration>
            {
                new(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "Y")
            };

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithAutoRollConfig(config)
                                                                                  .Build();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.NotRolled);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableMonthEndRollCommand_On_StatusNotRolled_When_AutoRoll_Updated_ToOff()
        {
            var config1 = new List<DynamicConfiguration>
            {
                new(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "Y")
            };

            var config2 = new List<DynamicConfiguration>
            {
                new(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithAutoRollConfig(config1)
                                                                                  .Build();

            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.NotRolled);

            // ACT
            testObjects.AutoRollConfig.OnNext(config2);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.True);
        }

        [TestCase(MonthEndRollPricesStatus.Completed)]
        [TestCase(MonthEndRollPricesStatus.Rolling)]
        [TestCase(MonthEndRollPricesStatus.WindowClosed)]
        [TestCase(MonthEndRollPricesStatus.ManualRollFailed)]
        [TestCase(MonthEndRollPricesStatus.AutoRollFailed)]
        [TestCase(MonthEndRollPricesStatus.ValidationFailed)]
        public void ShouldDisableMonthEndRollCommand_On_StatusNotEqualsNotRolled(MonthEndRollPricesStatus status)
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(status);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldShowValidationIconWithText_On_StatusValidationFailed()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithUserName("user-1")
                                        .User();

            var users = new List<User> { user };

            var flatPriceErrors = new List<string> {"flat-price"};
            var curveLengthErrors = new List<string> {"curve-length"};

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithUsers(users)
                                                                                  .WithFlatPriceValidationErrors(flatPriceErrors)
                                                                                  .WithCurveLengthValidationErrors(curveLengthErrors)
                                                                                  .Build();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.ValidationFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowValidationFailed, Is.True);
            Assert.That(testObjects.ViewModel.ValidationText.Contains("flat-price"));
            Assert.That(testObjects.ViewModel.ValidationText.Contains("curve-length"));
        }

        [Test]
        public void ShouldClearValidationIconWithText_On_StatusNotRolled_After_ValidationFailed()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithUserName("user-1")
                                        .User();

            var users = new List<User> { user };

            var flatPriceErrors = new List<string> { "flat-price" };
            var curveLengthErrors = new List<string> { "curve-length" };

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithUsers(users)
                                                                                  .WithFlatPriceValidationErrors(flatPriceErrors)
                                                                                  .WithCurveLengthValidationErrors(curveLengthErrors)
                                                                                  .Build();

            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.ValidationFailed);

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.NotRolled);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowValidationFailed, Is.False);
            Assert.IsNull(testObjects.ViewModel.ValidationText);
        }

        [Test]
        public void ShouldShowCompletedIconWithText_On_StatusCompleted()
        {
            var date1 = new DateTime(2021, 1,2, 8,30, 25);
            var history = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.Completed, date1);

            var user = new UserBuilder().WithId(10)
                                        .WithUserName("user-1")
                                        .User();

            var users = new List<User> {user};

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithLatestMonthEndRollStatus(history)
                                                                                  .WithUsers(users)
                                                                                  .Build();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.Completed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowLastRollCompleted, Is.True);
            Assert.That(testObjects.ViewModel.LastRollText, Is.EqualTo("Rolled on 02-Jan-2021 08:30:25"));
        }

        [Test]
        public void ShouldShowFailedIconWithText_On_StatusManualRollFailed()
        {
            var date1 = new DateTime(2021, 1, 2, 8, 30, 25);
            var history = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.Failed, date1);

            var user = new UserBuilder().WithId(10)
                                        .WithUserName("user-1")
                                        .User();

            var users = new List<User> { user };

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithLatestMonthEndRollStatus(history)
                                                                                  .WithUsers(users)
                                                                                  .Build();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.ManualRollFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowLastRollFailed, Is.True);
            Assert.That(testObjects.ViewModel.LastRollText, Is.EqualTo("Rolled on 02-Jan-2021 08:30:25"));
        }

        [Test]
        public void ShouldShowFailedIconWithText_On_StatusAutoRollFailed()
        {
            var date1 = new DateTime(2021, 1, 2, 8, 30, 25);
            var history = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.AutoRollFailed, date1);

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithLatestMonthEndRollStatus(history)
                                                                                  .Build();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.AutoRollFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowLastRollFailed, Is.True);
            Assert.That(testObjects.ViewModel.LastRollText, Is.EqualTo("Auto Roll on 02-Jan-2021 08:30:25"));
        }

        [Test]
        public void ShouldClearIconWithText_On_StatusWindowClosed()
        {
            var date1 = new DateTime(2021, 1, 1, 8, 30, 25);
            var history = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.Completed, date1);

            var user = new UserBuilder().WithId(10)
                                        .WithUserName("user-1")
                                        .User();

            var users = new List<User> { user };

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithLatestMonthEndRollStatus(history)
                                                                                  .WithUsers(users)
                                                                                  .Build();

            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.Completed);

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.WindowClosed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowLastRollCompleted, Is.False);
            Assert.IsNull(testObjects.ViewModel.LastRollText);
        }

        [Test]
        public void ShouldShowRollPricesPromptDialog_And_DisableMonthEndRoll_On_MonthEndRollCommand()
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithMonthEndRollPricesStatus(MonthEndRollPricesStatus.NotRolled)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.MonthEndRollCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.RollPricesDialogConfirmationService)
                .Verify(d => d.SetShowDialog());

            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldShowProgressDialog_And_InvokeUpdateMonthEndRoll_On_DialogConfirmRollPrices()
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithMonthEndRollPricesStatus(MonthEndRollPricesStatus.NotRolled)
                                                                                  .Build();

            testObjects.ViewModel.MonthEndRollCommand.Execute();

            // ACT
            testObjects.DialogConfirmRollPrices.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.RollPricesProgressUpdateService)
                .Verify(d => d.SetInProgress());

            Mock.Get(testObjects.RollPricesUpdateService)
                .Verify(u => u.UpdateMonthEndRoll(It.IsAny<IScheduler>(), false));
        }

        [Test]
        public void ShouldEnableMonthEndRollCommand_On_DialogCancelRollPrices()
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithMonthEndRollPricesStatus(MonthEndRollPricesStatus.NotRolled)
                                                                                  .Build();

            testObjects.ViewModel.MonthEndRollCommand.Execute();

            // ACT
            testObjects.DialogCancelRollPrices.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldUpdateDialogToCompleted_On_MonthEndRollUpdateCompleted()
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithMonthEndRollPricesStatus(MonthEndRollPricesStatus.NotRolled)
                                                                                  .Build();

            testObjects.ViewModel.MonthEndRollCommand.Execute();
            testObjects.DialogConfirmRollPrices.OnNext(Unit.Default);

            // ACT
            testObjects.UpdateMonthEndRollResult.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.RollPricesProgressUpdateService)
                .Verify(d => d.SetCompleted());
        }

        [Test]
        public void ShouldUpdateDialogToFailed_On_MonthEndRollUpdateFailed()
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithMonthEndRollPricesStatus(MonthEndRollPricesStatus.NotRolled)
                                                                                  .Build();

            testObjects.ViewModel.MonthEndRollCommand.Execute();
            testObjects.DialogConfirmRollPrices.OnNext(Unit.Default);

            // ACT
            var error = new Exception();
            testObjects.UpdateMonthEndRollResult.OnError(error);

            // ASSERT
            Mock.Get(testObjects.RollPricesProgressUpdateService)
                .Verify(d => d.SetFailed());
        }

        [Test]
        public void ShouldUpdateDialogToFailed_On_MonthEndRollUpdateException()
        {
            var error = new Exception();

            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().WithMonthEndRollPricesStatus(MonthEndRollPricesStatus.NotRolled)
                                                                                  .WithMonthEndRollUpdateException(error)
                                                                                  .Build();
            testObjects.ViewModel.MonthEndRollCommand.Execute();

            // ACT
            testObjects.DialogConfirmRollPrices.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.RollPricesProgressUpdateService)
                .Verify(d => d.SetFailed());
        }

        [Test]
        public void ShouldNotEnableMonthEndRollCommand_When_Disposed()
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.NotRolled);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new RollPricesViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.MonthEndRollPricesStatus.OnNext(MonthEndRollPricesStatus.NotRolled);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollCommand.CanExecute(), Is.False);
        }
    }
}
