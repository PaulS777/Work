﻿using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Controllers;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Controllers
{
    internal interface IEomRollToolBarViewModelControllerTestObjects
    {
        IAutoRollConfigViewModelController AutoRollConfig { get; }
        IRollPricesViewModelController RollPrices { get; }
        IMonthEndResetViewModelController MonthEndReset { get; }
        EomRollToolBarViewModelController Controller { get; }
    }

    [TestFixture]
    public class EomRollToolBarViewModelControllerTests
    {
        private class EomRollToolBarViewModelControllerTestObjectBuilder
        {
            public IEomRollToolBarViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IEomRollToolBarViewModelControllerTestObjects>();

                var autoRollConfigViewModel = new AutoRollConfigViewModel();

                var autoRollConfigController = new Mock<IAutoRollConfigViewModelController>();

                autoRollConfigController.SetupGet(c => c.ViewModel)
                                        .Returns(autoRollConfigViewModel);

                testObjects.SetupGet(o => o.AutoRollConfig)
                           .Returns(autoRollConfigController.Object);

                var rollPricesViewModel = new RollPricesViewModel();

                var rollPricesController = new Mock<IRollPricesViewModelController>();

                rollPricesController.SetupGet(c => c.ViewModel)
                                    .Returns(rollPricesViewModel);

                testObjects.SetupGet(o => o.RollPrices)
                           .Returns(rollPricesController.Object);

                var monthEndResetViewModel = new MonthEndResetViewModel();

                var monthEndResetController = new Mock<IMonthEndResetViewModelController>();

                monthEndResetController.SetupGet(c => c.ViewModel)
                                       .Returns(monthEndResetViewModel);

                testObjects.SetupGet(o => o.MonthEndReset)
                           .Returns(monthEndResetController.Object);

                var controller = new EomRollToolBarViewModelController(autoRollConfigController.Object, 
                                                                       rollPricesController.Object, 
                                                                       monthEndResetController.Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCreateViewModels()
        {
            // ACT
            var testObjects = new EomRollToolBarViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.IsNotNull(testObjects.Controller.ViewModel);
            Assert.AreSame(testObjects.AutoRollConfig.ViewModel, testObjects.Controller.ViewModel.AutoRollConfig);
            Assert.AreSame(testObjects.RollPrices.ViewModel, testObjects.Controller.ViewModel.RollPrices);
            Assert.AreSame(testObjects.MonthEndReset.ViewModel, testObjects.Controller.ViewModel.MonthEndReset);
        }

        [Test]
        public void ShouldDisposeControllers_On_Dispose()
        {
            var testObjects = new EomRollToolBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.AutoRollConfig)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.RollPrices)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.MonthEndReset)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDisposeControllers_When_Disposed()
        {
            var testObjects = new EomRollToolBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.AutoRollConfig)
                .Verify(c => c.Dispose(), Times.Once);

            Mock.Get(testObjects.RollPrices)
                .Verify(c => c.Dispose(), Times.Once);

            Mock.Get(testObjects.MonthEndReset)
                .Verify(c => c.Dispose(), Times.Once);
        }
    }
}
