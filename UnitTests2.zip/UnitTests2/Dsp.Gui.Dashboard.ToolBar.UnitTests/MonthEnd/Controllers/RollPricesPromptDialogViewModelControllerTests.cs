﻿using System.Reactive;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Controllers;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Controllers
{
    internal interface IRollPricesPromptDialogViewModelControllerTestObjects
    {
        IRollPricesDialogConfirmationService DialogConfirmationService { get; }
        ISubject<Unit> ShowDialog { get; }
        RollPricesPromptDialogViewModel ViewModel { get; }
        RollPricesPromptDialogViewModelController Controller { get; }
    }

    [TestFixture]
    public class RollPricesPromptDialogViewModelControllerTests
    {
        private class RollPricesPromptDialogViewModelControllerTestObjectBuilder
        {
            private bool _showDialog;

            public RollPricesPromptDialogViewModelControllerTestObjectBuilder WithShowDialog(bool value)
            {
                _showDialog = value;
                return this;
            }

            public IRollPricesPromptDialogViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IRollPricesPromptDialogViewModelControllerTestObjects>();

                var showDialog = new Subject<Unit>();

                testObjects.SetupGet(o => o.ShowDialog)
                           .Returns(showDialog);

                var dialogConfirmationService = new Mock<IRollPricesDialogConfirmationService>();

                dialogConfirmationService.SetupGet(d => d.ShowDialog)
                                         .Returns(showDialog);

                testObjects.SetupGet(o => o.DialogConfirmationService)
                           .Returns(dialogConfirmationService.Object);

                var controller = new RollPricesPromptDialogViewModelController(dialogConfirmationService.Object);

                controller.ViewModel.ShowDialog = _showDialog;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowDialog_On_ConfirmationServiceShowDialog()
        {
            var testObjects = new RollPricesPromptDialogViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowDialog.OnNext(Unit.Default);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.ShowDialog);
        }

        [Test]
        public void ShouldCloseDialog_And_SetConfirmRollPrices_On_DialogYesCommand()
        {
            var testObjects = new RollPricesPromptDialogViewModelControllerTestObjectBuilder().WithShowDialog(true)
                                                                                              .Build();

            // ACT
            testObjects.ViewModel.DialogYesCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);

            Mock.Get(testObjects.DialogConfirmationService)
                .Verify(d => d.SetConfirmRollPrices());
        }

        [Test]
        public void ShouldCloseDialog_And_SetCancelRollPrices_On_DialogNoCommand()
        {
            var testObjects = new RollPricesPromptDialogViewModelControllerTestObjectBuilder().WithShowDialog(true)
                                                                                              .Build();

            // ACT
            testObjects.ViewModel.DialogNoCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);

            Mock.Get(testObjects.DialogConfirmationService)
                .Verify(d => d.SetCancelRollPrices());
        }

        [Test]
        public void ShouldNotShowDialog_When_Disposed()
        {
            var testObjects = new RollPricesPromptDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ShowDialog.OnNext(Unit.Default);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new RollPricesPromptDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ShowDialog.OnNext(Unit.Default);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }
    }
}
