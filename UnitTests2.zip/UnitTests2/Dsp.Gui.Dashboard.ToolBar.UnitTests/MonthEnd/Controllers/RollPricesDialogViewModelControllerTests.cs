﻿using System.Reactive;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Controllers;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Controllers
{
    internal interface IRollPricesDialogViewModelControllerTestObjects
    {
        ISubject<Unit> InProgress { get; }
        ISubject<Unit> Completed { get; }
        ISubject<Unit> Failed { get; }
        RollPricesDialogViewModel ViewModel { get; }
        RollPricesDialogViewModelController Controller { get; }
    }

    [TestFixture]
    public class RollPricesDialogViewModelControllerTests
    {
        private class RollPricesDialogViewModelControllerTestObjectBuilder
        {
            public IRollPricesDialogViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IRollPricesDialogViewModelControllerTestObjects>();

                var inProgress = new Subject<Unit>();

                testObjects.SetupGet(o => o.InProgress)
                           .Returns(inProgress);

                var completed = new Subject<Unit>();

                testObjects.SetupGet(o => o.Completed)
                           .Returns(completed);

                var failed = new Subject<Unit>();

                testObjects.SetupGet(o => o.Failed)
                           .Returns(failed);

                var progressUpdateService = new Mock<IRollPricesProgressUpdateService>();

                progressUpdateService.SetupGet(p => p.InProgress)
                                     .Returns(inProgress);

                progressUpdateService.SetupGet(p => p.Completed)
                                     .Returns(completed);

                progressUpdateService.SetupGet(p => p.Failed)
                                     .Returns(failed);

                var controller = new RollPricesDialogViewModelController(progressUpdateService.Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowDialogWithProgress_On_InProgress()
        {
            var testObjects = new RollPricesDialogViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.InProgress.OnNext(Unit.Default);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.ShowDialog);
            Assert.IsTrue(testObjects.ViewModel.ShowProgress);
            Assert.IsFalse(testObjects.ViewModel.ShowOkButton);
        }

        [Test]
        public void ShouldShowCompletedWithOkButton_On_Completed()
        {
            var testObjects = new RollPricesDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.InProgress.OnNext(Unit.Default);

            // ACT
            testObjects.Completed.OnNext(Unit.Default);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowProgress);
            Assert.IsTrue(testObjects.ViewModel.ShowCompleted);
            Assert.IsTrue(testObjects.ViewModel.ShowOkButton);
        }

        [Test]
        public void ShouldShowFailedWithOkButton_On_Failed()
        {
            var testObjects = new RollPricesDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.InProgress.OnNext(Unit.Default);

            // ACT
            testObjects.Failed.OnNext(Unit.Default);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowProgress);
            Assert.IsTrue(testObjects.ViewModel.ShowFailed);
            Assert.IsTrue(testObjects.ViewModel.ShowOkButton);
        }

        [Test]
        public void ShouldCloseDialog_On_OkButton()
        {
            var testObjects = new RollPricesDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.InProgress.OnNext(Unit.Default);
            testObjects.Completed.OnNext(Unit.Default);

            // ACT
            testObjects.ViewModel.DialogOkCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowCompleted);
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }

        [Test]
        public void ShouldNotShowDialog_When_Disposed()
        {
            var testObjects = new RollPricesDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.InProgress.OnNext(Unit.Default);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new RollPricesDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.InProgress.OnNext(Unit.Default);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }
    }
}
