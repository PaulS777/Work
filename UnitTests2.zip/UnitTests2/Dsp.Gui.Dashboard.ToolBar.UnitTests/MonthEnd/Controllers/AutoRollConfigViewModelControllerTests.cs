﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Controllers;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;


namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Controllers
{
    internal interface IAutoRollConfigViewModelControllerTestObjects
    {
        IDynamicConfigurationUpdateService ConfigurationUpdateService { get; }
        ISubject<Unit> ConfigurationUpdateResponse { get; }
        ISubject<List<MonthEndRollStatus>> MonthEndRollStatus { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        AutoRollConfigViewModel ViewModel { get; }
        AutoRollConfigViewModelController Controller { get; }
    }

    [TestFixture]
    public class AutoRollConfigViewModelControllerTests
    {
        private class AutoRollConfigViewModelControllerTestObjectBuilder
        {
            private List<DynamicConfiguration> _configuration;
            private Exception _updateResponseException;
            private List<MonthEndRollStatus> _monthEndRollStatuses;

            public AutoRollConfigViewModelControllerTestObjectBuilder WithConfiguration(List<DynamicConfiguration> values)
            {
                _configuration = values;
                return this;
            }

            public AutoRollConfigViewModelControllerTestObjectBuilder WithUpdateResponseException(Exception value)
            {
                _updateResponseException = value;
                return this;
            }

            public AutoRollConfigViewModelControllerTestObjectBuilder WithMonthEndRollStatuses(List<MonthEndRollStatus> values)
            {
                _monthEndRollStatuses = values;
                return this;
            }

            public IAutoRollConfigViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IAutoRollConfigViewModelControllerTestObjects>();

                var monthEndRollStatus = new BehaviorSubject<List<MonthEndRollStatus>>(_monthEndRollStatuses);

                testObjects.SetupGet(o => o.MonthEndRollStatus)
                           .Returns(monthEndRollStatus);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.MonthEndRollStatusOnUpdate)
                                   .Returns(monthEndRollStatus);

                curveControlService.SetupGet(c => c.ConfigurationOnUpdate)
                                   .Returns(Observable.Return(_configuration));

                var updateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.ConfigurationUpdateResponse)
                           .Returns(updateResponse);

                var configurationUpdateService = new Mock<IDynamicConfigurationUpdateService>();

                if (_updateResponseException == null)
                {
                    configurationUpdateService.Setup(u => u.Update(It.IsAny<DynamicConfiguration>(), It.IsAny<IScheduler>()))
                                              .Returns(updateResponse);
                }
                else
                {
                    configurationUpdateService.Setup(u => u.Update(It.IsAny<DynamicConfiguration>(), It.IsAny<IScheduler>()))
                                              .Throws(_updateResponseException);
                }

                testObjects.SetupGet(o => o.ConfigurationUpdateService)
                           .Returns(configurationUpdateService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var controller = new AutoRollConfigViewModelController(curveControlService.Object,
                                                                       configurationUpdateService.Object,
                                                                       TestMocks.GetSchedulerProvider().Object,
                                                                       TestMocks.GetLoggerFactory().Object)
                {
                    PopupNotificationService = popupNotificationService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object
                };

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldEnableAutoSwitchButton_And__On_ConfigLoaded_With_EomRoll()
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .Build();

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.AutoRollSwitchEnabled);
        }

        [TestCase("Y", true)]
        [TestCase("N", false)]
        public void ShouldSetAutoRollOn_From_AutoRollEnabledConfigValue(string value, bool result)
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), value)
            };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .Build();

            // ASSERT
            Assert.AreEqual(result, testObjects.ViewModel.AutoRollOn);
        }

        [Test]
        public void ShouldDisableAutoSwitchButton_On_ConfigLoaded_With_NoEomRoll()
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, "category", "config", "value")
            };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .Build();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.AutoRollSwitchEnabled);
            Assert.IsFalse(testObjects.ViewModel.AutoRollOn);
        }

        [Test]
        public void ShouldDisableSwitch_And_UpdateConfiguration_On_AutoRollSwitch()
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.AutoRollOn = true;

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.AutoRollSwitchEnabled);

            Mock.Get(testObjects.ConfigurationUpdateService)
                .Verify(service => service.Update(It.Is<DynamicConfiguration>(c => c.Id == 1 
                                                                                   && c.CategoryName == PermissionCategory.EomRoll.ToString() 
                                                                                   && c.ConfigName == ConfigurationName.AutoRollEnabled.ToString() 
                                                                                   && c.ConfigValue == "Y"), It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldEnableSwitch_And_ShowPopup_OnUpdateConfigurationResponse_Success()
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .Build();

            testObjects.ViewModel.AutoRollOn = true;

            // ACT
            testObjects.ConfigurationUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.AutoRollSwitchEnabled);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldEnableSwitch_And_ShowMessageDialog_OnUpdateConfigurationResponse_Error()
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .Build();

            testObjects.ViewModel.AutoRollOn = true;

            var error = new Exception("error");

            // ACT
            testObjects.ConfigurationUpdateResponse.OnError(error);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.AutoRollSwitchEnabled);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "error" 
                                                                                && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldEnableSwitch_And_ShowMessageDialog_OnUpdateConfigurationResponse_Exception()
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var exception = new Exception("exception");

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .WithUpdateResponseException(exception)
                                                                                      .Build();
            // ACT
            testObjects.ViewModel.AutoRollOn = true;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.AutoRollSwitchEnabled);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldShowAutoRollFailed_When_LastRollHistory_AutoFailed()
        {
            var timestamp1 = new DateTime(2021, 1, 2, 8, 30, 25);
            var timestamp2 = new DateTime(2021, 1, 30, 8, 30, 25);

            var completed = new MonthEndRollStatus(new DateOnly(2021,1,1), RollStatus.Completed, timestamp1);
            var failed = new MonthEndRollStatus(new DateOnly(2021,1,1), RollStatus.AutoRollFailed, timestamp2);

            var history = new List<MonthEndRollStatus> {completed, failed};

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MonthEndRollStatus.OnNext(history);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.ShowAutoRollFailed);
        }

        [Test]
        public void ShouldHideAutoRollFailed_When_LastRollHistory_Completed_After_AutoFailed()
        {
            var timestamp1 = new DateTime(2021, 1, 2, 8, 30, 25);
            var timestamp2 = new DateTime(2021, 1, 30, 8, 30, 25);

            var failed = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.AutoRollFailed, timestamp1);
            var completed = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.Completed, timestamp2);
  

            var history = new List<MonthEndRollStatus> { failed, completed };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MonthEndRollStatus.OnNext(history);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowAutoRollFailed);
        }

        [Test]
        public void ShouldHideAutoRollFailed_When_RollHistory_DoesNotContainAutoFailed()
        {
            var timestamp1 = new DateTime(2021, 1, 2, 8, 30, 25);
            var timestamp2 = new DateTime(2021, 1, 30, 8, 30, 25);

            var manualFailed = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.Failed, timestamp1);
            var completed = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.Completed, timestamp2);


            var history = new List<MonthEndRollStatus> { manualFailed, completed };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MonthEndRollStatus.OnNext(history);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowAutoRollFailed);
        }

        [Test]
        public void ShouldHideAutoRollFailed_When_RollHistory_Empty()
        {
            var history = new List<MonthEndRollStatus>();

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MonthEndRollStatus.OnNext(history);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowAutoRollFailed);
        }

        [Test]
        public void ShouldShowAutoRollFailed_When_RollHistory_ManualFailedAfterAutoFailed()
        {
            var timestamp1 = new DateTime(2021, 1, 2, 8, 30, 25);
            var timestamp2 = new DateTime(2021, 1, 30, 8, 30, 25);
            var timestamp3 = new DateTime(2021, 1, 30, 8, 45, 25);

            var completed = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.Completed, timestamp1);
            var failed = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.AutoRollFailed, timestamp2);
            var manualFailed = new MonthEndRollStatus(new DateOnly(2021, 1, 1), RollStatus.AutoRollFailed, timestamp3);

            var history = new List<MonthEndRollStatus> { completed, failed, manualFailed };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MonthEndRollStatus.OnNext(history);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.ShowAutoRollFailed);
        }

        [Test]
        public void ShouldNotDisableSwitch_And_UpdateConfiguration_When_Disposed()
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .Build();
            
            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.AutoRollOn = true;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.AutoRollSwitchEnabled);

            Mock.Get(testObjects.ConfigurationUpdateService)
                .Verify(service => service.Update(It.IsAny<DynamicConfiguration>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_And_Disposed()
        {
            var configurations = new List<DynamicConfiguration>
            {
                new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.AutoRollEnabled.ToString(), "N")
            };

            var testObjects = new AutoRollConfigViewModelControllerTestObjectBuilder().WithConfiguration(configurations)
                                                                                      .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.AutoRollOn = true;

            // ASSERT
            testObjects.Controller.Dispose();
            Assert.IsTrue(testObjects.ViewModel.AutoRollSwitchEnabled);

            Mock.Get(testObjects.ConfigurationUpdateService)
                .Verify(service => service.Update(It.IsAny<DynamicConfiguration>(), It.IsAny<IScheduler>()), Times.Never);
        }
    }
}
