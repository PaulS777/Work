﻿using System;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Services
{
    [TestFixture]
    public class MonthEndResetDialogConfirmationServiceTests
    {
        [Test]
        public void ShouldPublishShowDialog_When_SetShowDialog()
        {
            var result = false;

            var service = new MonthEndResetDialogConfirmationService();

            using (service.ShowDialog.Subscribe(_ => result = true))
            {
                // ACT
                service.SetShowDialog();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishConfirmReset_When_SetConfirmReset()
        {
            var result = false;

            var service = new MonthEndResetDialogConfirmationService();

            using (service.ConfirmReset.Subscribe(_ => result = true))
            {
                // ACT
                service.SetConfirmReset();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishCancelReset_When_SetCancelReset()
        {
            var result = false;

            var service = new MonthEndResetDialogConfirmationService();

            using (service.CancelReset.Subscribe(_ => result = true))
            {
                // ACT
                service.SetCancelReset();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotPublishShowDialog_When_Disposed()
        {
            var result = false;

            var service = new MonthEndResetDialogConfirmationService();

            using (service.ShowDialog.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetShowDialog();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishConfirmReset_When_Disposed()
        {
            var result = false;

            var service = new MonthEndResetDialogConfirmationService();

            using (service.ConfirmReset.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetConfirmReset();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishCancelReset_When_Disposed()
        {
            var result = false;

            var service = new MonthEndResetDialogConfirmationService();

            using (service.CancelReset.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetCancelReset();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var result = false;

            var service = new MonthEndResetDialogConfirmationService();

            using (service.ShowDialog.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.Dispose();
                service.SetShowDialog();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
