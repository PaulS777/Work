﻿using System;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Services
{
    [TestFixture]
    public class MonthEndResetProgressUpdateServiceTests
    {
        [Test]
        public void ShouldPublishInProgress_When_SetInProgress()
        {
            var result = false;

            var service = new MonthEndResetProgressUpdateService();

            using (service.InProgress.Subscribe(_ => result = true))
            {
                // ACT
                service.SetInProgress();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishCompleted_When_SetCompleted()
        {
            var result = false;

            var service = new MonthEndResetProgressUpdateService();

            using (service.Completed.Subscribe(_ => result = true))
            {
                // ACT
                service.SetCompleted();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFailed_When_SetFailed()
        {
            var result = false;

            var service = new MonthEndResetProgressUpdateService();

            using (service.Failed.Subscribe(_ => result = true))
            {
                // ACT
                service.SetFailed();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotPublishInProgress_When_Disposed()
        {
            var result = false;

            var service = new MonthEndResetProgressUpdateService();

            using (service.InProgress.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetInProgress();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishCompleted_When_Disposed()
        {
            var result = false;

            var service = new MonthEndResetProgressUpdateService();

            using (service.Completed.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetCompleted();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishFailed_When_Disposed()
        {
            var result = false;

            var service = new MonthEndResetProgressUpdateService();

            using (service.Failed.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetFailed();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDisposed_When_Disposed()
        {
            var result = false;

            var service = new MonthEndResetProgressUpdateService();

            using (service.InProgress.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.Dispose();
                service.SetInProgress();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}