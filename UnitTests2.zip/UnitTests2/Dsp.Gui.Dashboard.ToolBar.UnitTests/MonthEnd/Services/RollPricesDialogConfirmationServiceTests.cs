﻿using System;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Services
{
    [TestFixture]
    public class RollPricesDialogConfirmationServiceTests
    {
        [Test]
        public void ShouldPublishShowDialog_When_SetShowDialog()
        {
            var result = false;

            var service = new RollPricesDialogConfirmationService();

            using (service.ShowDialog.Subscribe(_ => result = true))
            {
                // ACT
                service.SetShowDialog();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishConfirmRollPrices_When_SetConfirmRollPrices()
        {
            var result = false;

            var service = new RollPricesDialogConfirmationService();

            using (service.ConfirmRollPrices.Subscribe(_ => result = true))
            {
                // ACT
                service.SetConfirmRollPrices();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishCancelRollPrices_When_SetCancelRollPrices()
        {
            var result = false;

            var service = new RollPricesDialogConfirmationService();

            using (service.CancelRollPrices.Subscribe(_ => result = true))
            {
                // ACT
                service.SetCancelRollPrices();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotPublishShowDialog_When_Disposed()
        {
            var result = false;

            var service = new RollPricesDialogConfirmationService();

            using (service.ShowDialog.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetShowDialog();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishConfirmRollPrices_When_Disposed()
        {
            var result = false;

            var service = new RollPricesDialogConfirmationService();

            using (service.ConfirmRollPrices.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetConfirmRollPrices();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishCancelRollPrices_When_Disposed()
        {
            var result = false;

            var service = new RollPricesDialogConfirmationService();

            using (service.CancelRollPrices.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetCancelRollPrices();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var result = false;

            var service = new RollPricesDialogConfirmationService();

            using (service.ShowDialog.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.Dispose();
                service.SetShowDialog();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
