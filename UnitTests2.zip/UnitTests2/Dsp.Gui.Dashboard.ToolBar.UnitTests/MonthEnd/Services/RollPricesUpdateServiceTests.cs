﻿using System;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.ToolBar.MonthEnd.Services;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.MonthEnd.Services
{
    internal interface IRollPricesUpdateServiceTestObjects
    {
        IAdminApiServiceClient AdminApiServiceClient { get; }
        RollPricesUpdateService RollPricesUpdateService { get; }
    }

    [TestFixture]
    public class RollPricesUpdateServiceTests
    {
        private class RollPricesUpdateServiceTestObjectBuilder
        {
            private bool _updateResponse;
            private Exception _exception;

            public RollPricesUpdateServiceTestObjectBuilder WithUpdateResponse(bool value)
            {
                _updateResponse = value;
                return this;
            }

            public RollPricesUpdateServiceTestObjectBuilder WithUpdateException(Exception value)
            {
                _exception = value;
                return this;
            }

            public IRollPricesUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IRollPricesUpdateServiceTestObjects>();

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                if (_exception == null)
                {
                    adminApiServiceClient.Setup(a => a.UpdateMonthEndRoll(It.IsAny<MonthEndRoll>()))
                                         .Returns(Task.FromResult(new AdminApiServiceResponse(_updateResponse)));
                }
                else
                {
                    adminApiServiceClient.Setup(a => a.UpdateMonthEndRoll(It.IsAny<MonthEndRoll>()))
                                         .Throws(_exception);
                }

                testObjects.SetupGet(o => o.AdminApiServiceClient)
                           .Returns(adminApiServiceClient.Object);

                var rollPricesUpdateService = new RollPricesUpdateService(adminApiServiceClient.Object,
                                                                          TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.RollPricesUpdateService).Returns(rollPricesUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateMonthEndRoll()
        {
            var testScheduler = new TestScheduler();

            var testObjects = new RollPricesUpdateServiceTestObjectBuilder().WithUpdateResponse(true)
                                                                            .Build();

            var result = false;

            using (testObjects.RollPricesUpdateService
                              .UpdateMonthEndRoll(testScheduler, false)
                              .Subscribe(_ => result = true))
            {
                // ACT
                testScheduler.AdvanceBy(10);

                // ASSERT
                Mock.Get(testObjects.AdminApiServiceClient)
                    .Verify(c => c.UpdateMonthEndRoll(It.Is<MonthEndRoll>(p => p.Id == 1)));

                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldHandleRollPricesUpdateCompleted()
        {
            var testScheduler = new TestScheduler();

            var testObjects = new RollPricesUpdateServiceTestObjectBuilder().Build();

            var result = true;

            using (testObjects.RollPricesUpdateService
                              .UpdateMonthEndRoll(testScheduler, false)
                              .Subscribe(_ =>result = true))
            {
                // ACT
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldHandleRollPricesUpdateFailed()
        {
            var testScheduler = new TestScheduler();

            var testObjects = new RollPricesUpdateServiceTestObjectBuilder().WithUpdateResponse(false)
                                                                            .Build();
            Exception exception = null;

            using (testObjects.RollPricesUpdateService
                              .UpdateMonthEndRoll(testScheduler, false)
                              .Subscribe(_ => { },
                                         ex => exception = ex))
            {
                // ACT
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.IsNotNull(exception);
            }
        }

        [Test]
        public void ShouldHandleRollPricesUpdateException()
        {
            var testScheduler = new TestScheduler();

            var updateException = new Exception();

            var testObjects = new RollPricesUpdateServiceTestObjectBuilder().WithUpdateException(updateException)
                                                                            .Build();
            Exception exception = null;

            using (testObjects.RollPricesUpdateService
                              .UpdateMonthEndRoll(testScheduler, false)
                              .Subscribe(_ => {}, 
                                         ex => exception = ex))
            {
                // ACT
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.IsNotNull(exception);
            }
        }
    }
}
