﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.Dashboard.ToolBar.SpreadAdjustment.Controllers;
using Dsp.Gui.Dashboard.ToolBar.SpreadAdjustment.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.ToolBar.UnitTests.SpreadAdjustment.Controllers
{
    public interface ISpreadAdjustmentViewModelControllerTestObjects
    {
        ISetSpreadMultiplierActionService SetSpreadMultiplierActionService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        ILogger Logger { get; }
        ISubject<User> CurrentUser { get; }
        ISubject<AdminApiActionCompleted> UpdateServiceResponse { get; }
        SpreadAdjustmentViewModelController Controller { get; }
        SpreadAdjustmentViewModel ViewModel { get; }
    }

    [TestFixture]
    public class SpreadAdjustmentViewModelControllerTests
    {
        private class SpreadAdjustmentViewModelControllerTestObjectBuilder
        {
            private User _currentUser;
          
            public SpreadAdjustmentViewModelControllerTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }
            
            public ISpreadAdjustmentViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<ISpreadAdjustmentViewModelControllerTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                var currentUser = new BehaviorSubject<User>(_currentUser);

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(currentUser);

                var updateServiceResponse = new Subject<AdminApiActionCompleted>();

                testObjects.SetupGet(o => o.UpdateServiceResponse)
                           .Returns(updateServiceResponse);

                var service = new Mock<ISetSpreadMultiplierActionService>();

                service.Setup(u => u.Update(It.IsAny<List<SetSpreadMultiplier>>(), It.IsAny<IScheduler>()))
                       .Returns(updateServiceResponse);

                testObjects.SetupGet(o => o.SetSpreadMultiplierActionService)
                           .Returns(service.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var controller = new SpreadAdjustmentViewModelController(curveControlService.Object,
                                                                         TestMocks.GetSchedulerProvider().Object,
                                                                         TestMocks.GetLoggerFactory().Object)
                                 {
                                     SetSpreadMultiplierService = service.Object,
                                     PopupNotificationService = popupNotificationService.Object,
                                     ErrorMessageDialogService = errorMessageDialogService.Object
                                 };

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPopulateSpreadMultiplier_When_CurrentUserLoaded()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(1.0M));
            Assert.That(testObjects.ViewModel.User(), Is.SameAs(user));
        }

        [Test]
        public void ShouldEnableIncrementAndDecrement_When_SpreadMultiplier_BetweenMinimumAndMaximum()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.25)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(testObjects.ViewModel.IncrementSpreadMultiplierCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.DecrementSpreadMultiplierCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableIncrement_When_SpreadMultiplierEqualsMaximumValue()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(2.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(testObjects.ViewModel.IncrementSpreadMultiplierCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.DecrementSpreadMultiplierCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableDecrementCommand_When_PublisherSpreadMultiplierEqualsMinimumValue()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(testObjects.ViewModel.IncrementSpreadMultiplierCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.DecrementSpreadMultiplierCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldIncrementSpreadMultiplier_On_IncrementCommand()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.05)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.IncrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(1.25));

            // ACT
            testObjects.ViewModel.IncrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(1.50));

            // ACT
            testObjects.ViewModel.IncrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(1.75));

            // ACT
            testObjects.ViewModel.IncrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(2.0));
        }

        [Test]
        public void ShouldDecrementSpreadMultiplier_On_DecrementCommand()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.95)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.DecrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(1.75));

            // ACT
            testObjects.ViewModel.DecrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(1.50));

            // ACT
            testObjects.ViewModel.DecrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(1.25));

            // ACT
            testObjects.ViewModel.DecrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(1.0));
        }

        [Test]
        public void ShouldDisableCommandsAndInvokeUpdateService_On_IncrementCommand()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.IncrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IncrementSpreadMultiplierCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.DecrementSpreadMultiplierCommand.CanExecute(), Is.False);

            Mock.Get(testObjects.SetSpreadMultiplierActionService)
                .Verify(s => s.Update(It.Is<IList<SetSpreadMultiplier>>(m => m.Count == 1
                                                                             && m[0].UserId == 10 
                                                                             && m[0].SpreadMultiplier.Equals(1.25)),
                                                                       It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldDisableCommandsAndInvokeUpdateService_On_DecrementCommand()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.25)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.DecrementSpreadMultiplierCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IncrementSpreadMultiplierCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.DecrementSpreadMultiplierCommand.CanExecute(), Is.False);

            Mock.Get(testObjects.SetSpreadMultiplierActionService)
                .Verify(s => s.Update(It.Is<IList<SetSpreadMultiplier>>(m => m.Count == 1
                                                                             && m[0].UserId == 10
                                                                             && m[0].SpreadMultiplier.Equals(1.0)),
                                      It.IsAny<IScheduler>()));
        }


        [Test]
        public void ShouldEnableCommandsAndDisplayPopup_On_UpdateResponseCompleted()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.IncrementSpreadMultiplierCommand.Execute();

            // ACT
            testObjects.UpdateServiceResponse.OnNext(new AdminApiActionCompleted());

            // ASSERT
            Assert.That(testObjects.ViewModel.IncrementSpreadMultiplierCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.DecrementSpreadMultiplierCommand.CanExecute(), Is.True);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldEnableCommandsAndShowErrorDialog_On_UpdateResponseCompletedWithWarning()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.IncrementSpreadMultiplierCommand.Execute();

            // ACT
            testObjects.UpdateServiceResponse.OnNext(new AdminApiActionCompleted("warning"));

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "warning" && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldEnableCommandsAndShowErrorDialog_On_UpdateResponseError()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.IncrementSpreadMultiplierCommand.Execute();

            // ACT
            testObjects.UpdateServiceResponse.OnError(new Exception("error"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IncrementSpreadMultiplierCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.DecrementSpreadMultiplierCommand.CanExecute(), Is.True);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "error" && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldUnsubscribeCurrentUser_When_Disposed()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(0));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithSpreadMultiplier(1.0)
                                        .User();

            var testObjects = new SpreadAdjustmentViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(testObjects.ViewModel.SpreadMultiplier, Is.EqualTo(0));
        }
    }
}
