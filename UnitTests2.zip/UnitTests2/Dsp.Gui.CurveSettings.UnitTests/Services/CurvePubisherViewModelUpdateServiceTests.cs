﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services
{
    internal interface ICurvePublisherViewModelUpdateServiceTestObjects
    {
        CurvePublisherViewModelUpdateService ViewModelUpdateService { get; }
    }

    [TestFixture]
    public class CurvePublisherViewModelUpdateServiceTests
    {
        private class CurvePublisherViewModelUpdateServiceTestObjectBuilder
        {
            public ICurvePublisherViewModelUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurvePublisherViewModelUpdateServiceTestObjects>();

                var updateService = new CurvePublisherViewModelUpdateService();

                testObjects.SetupGet(o => o.ViewModelUpdateService)
                           .Returns(updateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateViewModelFromPriceCurve_With_CurrentUserIsPublisher()
        {
            var currentUser = new UserBuilder().WithId(10).WithUserName("user").User();

            var users = new List<User> { currentUser };

            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
                            {
                                PublisherChanged = true,
                                IsExcelSourceChanged = true,
                                IsPublishableChanged = true,
                                IsTradeableChanged = true
                            };
            
            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                            .WithPublisherId(10)
                                                                            .WithIsPublishable(true)
                                                                            .WithIsTradeable(true)
                                                                            .WithIsExcelSource(true)
                                                                            .WithUseInactivityTimeout(true)
                                                                            .Build();

            var testObjects = new CurvePublisherViewModelUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModelUpdateService.UpdateViewModelFromPriceCurve(viewModel, 10, priceCurveSetting, users);

            // ASSERT
            Assert.That(viewModel.PublicationDetails().PriceCurveSetting, Is.SameAs(priceCurveSetting));
            Assert.That(viewModel.PublicationDetails().CurrentPublisherId, Is.EqualTo(10));
            Assert.That(viewModel.PublicationDetails().IsOwnedByCurrentUser, Is.True);
            Assert.That(viewModel.PublisherName, Is.EqualTo("user"));
            Assert.That(viewModel.IsExcelSource, Is.True);
            Assert.That(viewModel.PublisherChanged, Is.False);
            Assert.That(viewModel.IsPublishable, Is.True);
            Assert.That(viewModel.PublisherChanged, Is.False);
            Assert.That(viewModel.IsExcelSourceChanged, Is.False);
            Assert.That(viewModel.IsPublishableChanged, Is.False);
            Assert.That(viewModel.IsTradeable, Is.True);
            Assert.That(viewModel.IsTradeableChanged, Is.False);
            Assert.That(viewModel.HasChanged, Is.False);
            Assert.That(viewModel.CanEditIsExcelSource, Is.True);
            Assert.That(viewModel.CanEditIsPublishable, Is.True);
            Assert.That(viewModel.CanEditIsTradeable, Is.True);
        }

        [Test]
        public void ShouldDisableEdit_When_UpdatePriceCurve_With_CurrentUserIsNotPublisher()
        {
            var currentUser = new UserBuilder().WithId(10).WithUserName("user").User();
            var otherUser = new UserBuilder().WithId(99).WithUserName("other").User();

            var users = new List<User> { currentUser, otherUser };

            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>());

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                            .WithPublisherId(otherUser.Id)
                                                                            .Build();

            var testObjects = new CurvePublisherViewModelUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModelUpdateService.UpdateViewModelFromPriceCurve(viewModel, 10, priceCurveSetting, users);

            // ASSERT
            Assert.That(viewModel.CanEditIsExcelSource, Is.False);
            Assert.That(viewModel.CanEditIsPublishable, Is.False);
            Assert.That(viewModel.CanEditIsTradeable, Is.False);
        }

        [Test]
        public void ShouldUpdateViewModelFromFxCurve_With_CurrentUserIsPublisher()
        {
            var currentUser = new UserBuilder().WithId(10).WithUserName("user").User();

            var users = new List<User> { currentUser };

            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>());

            var fxCurveSetting = new FxCurveSetting(101, 
                                                    currentUser.Id,
                                                    1.0, 
                                                    true, 
                                                    true);

            var testObjects = new CurvePublisherViewModelUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModelUpdateService.UpdateViewModelFromFxCurve(viewModel, 10, fxCurveSetting, users);

            // ASSERT
            Assert.AreSame(fxCurveSetting, viewModel.PublicationDetails().FxCurveSetting);
            Assert.That(viewModel.PublicationDetails().CurrentPublisherId, Is.EqualTo(10));
            Assert.That(viewModel.PublicationDetails().IsOwnedByCurrentUser, Is.True);
            Assert.That(viewModel.PublisherName, Is.EqualTo("user"));

            Assert.That(viewModel.IsPublishable, Is.True);
            Assert.That(viewModel.PublisherChanged, Is.False);
            Assert.That(viewModel.IsPublishableChanged, Is.False);

            Assert.That(viewModel.IsTradeable, Is.True);
            Assert.That(viewModel.IsTradeableChanged, Is.False);
            Assert.That(viewModel.HasChanged, Is.False);
            Assert.That(viewModel.CanEditIsPublishable, Is.True);
            Assert.That(viewModel.CanEditIsTradeable, Is.True);
        }

        [Test]
        public void ShouldDisableEditIsExcelSource_When_UpdateFxCurve_With_CurrentUserIsPublisher()
        {
            var currentUser = new UserBuilder().WithId(10).WithUserName("user").User();
            var otherUser = new UserBuilder().WithId(99).WithUserName("other").User();

            var users = new List<User> { currentUser, otherUser };

            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>());


            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, true);

            var testObjects = new CurvePublisherViewModelUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModelUpdateService.UpdateViewModelFromFxCurve(viewModel, 
                                                                          currentUser.Id, 
                                                                          fxCurveSetting, 
                                                                          users);

            // ASSERT
            Assert.That(viewModel.CanEditIsExcelSource, Is.False);
        }

        [Test]
        public void ShouldDisableEdit_When_UpdateFxCurve_With_CurrentUserIsNotPublisher()
        {
            var currentUser = new UserBuilder().WithId(10).WithUserName("user").User();
            var otherUser = new UserBuilder().WithId(99).WithUserName("other").User();

            var users = new List<User> { currentUser, otherUser };

            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>());


            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, true);

            var testObjects = new CurvePublisherViewModelUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModelUpdateService.UpdateViewModelFromFxCurve(viewModel,
                                                                          otherUser.Id, 
                                                                          fxCurveSetting, 
                                                                          users);

            // ASSERT
            Assert.That(viewModel.CanEditIsExcelSource, Is.False);
            Assert.That(viewModel.CanEditIsPublishable, Is.False);
            Assert.That(viewModel.CanEditIsTradeable, Is.False);
        }
    }
}
