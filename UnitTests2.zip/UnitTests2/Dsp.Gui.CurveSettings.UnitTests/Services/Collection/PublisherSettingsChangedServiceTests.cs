﻿using System.Reactive.Subjects;
using Dsp.Gui.CurveSettings.Services.Collection;
using Dsp.Gui.CurveSettings.ViewModels;
using DynamicData;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Collection
{
    [TestFixture]
    public class PublisherSettingsChangedServiceTests
    {
        [Test]
        public void ShouldSetHasChangesFalse_When_SubscribeUpdates_With_NoChanges()
        {
            var curveSettings = new CurveSettingsViewModel();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>([
																	   new Change<CurvePublisherViewModel>(ListChangeReason.AddRange, 
																										   [curvePublisher1, curvePublisher2])
																   ]);

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var service = new PublisherSettingsChangedService();

            service.Attach(curveSettings);

            // ACT
            service.SubscribeUpdates(curvePublishers);

            // ASSERT
            Assert.That(curveSettings.HasChanges, Is.False);
        }

        [Test]
        public void ShouldSetHasChangesTrue_When_SubscribeUpdates_With_Changes()
        {
            var curveSettings = new CurveSettingsViewModel();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithHasChanged(true).Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>([
																	   new Change<CurvePublisherViewModel>(ListChangeReason.AddRange,
																										   [curvePublisher1, curvePublisher2])
																   ]);

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var service = new PublisherSettingsChangedService();

            service.Attach(curveSettings);

            // ACT
            service.SubscribeUpdates(curvePublishers);

            // ASSERT
            Assert.That(curveSettings.HasChanges, Is.True);
        }

        [Test]
        public void ShouldSetHasChangesTrue_When_CurvePublisherChanged()
        {
            var curveSettings = new CurveSettingsViewModel();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>([
																	   new Change<CurvePublisherViewModel>(ListChangeReason.AddRange,
																										   [curvePublisher1, curvePublisher2])]);

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var service = new PublisherSettingsChangedService();

            service.Attach(curveSettings);
            service.SubscribeUpdates(curvePublishers);

            // ACT
            curvePublisher1.HasChanged = true;

            // ASSERT
            Assert.That(curveSettings.HasChanges, Is.True);
        }

        [Test]
        public void ShouldNotSetHasChanges_When_UnsubscribeUpdates()
        {
            var curveSettings = new CurveSettingsViewModel();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>([
																	   new Change<CurvePublisherViewModel>(ListChangeReason.AddRange,
																										   [curvePublisher1, curvePublisher2])
																   ]);

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var service = new PublisherSettingsChangedService();

            service.Attach(curveSettings);
            service.SubscribeUpdates(curvePublishers);

            service.UnsubscribeUpdates();

            // ACT
            curvePublisher1.HasChanged = true;

            // ASSERT
            Assert.That(curveSettings.HasChanges, Is.False);
        }

        [Test]
        public void ShouldNotSetHasChanges_When_Disposed()
        {
            var curveSettings = new CurveSettingsViewModel();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>([
																	   new Change<CurvePublisherViewModel>(ListChangeReason.AddRange,
																										   [curvePublisher1, curvePublisher2])
																   ]);

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var service = new PublisherSettingsChangedService();

            service.Attach(curveSettings);
            service.SubscribeUpdates(curvePublishers);

            service.Dispose();

            // ACT
            curvePublisher1.HasChanged = true;

            // ASSERT
            Assert.That(curveSettings.HasChanges, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var curveSettings = new CurveSettingsViewModel();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>([
																	   new Change<CurvePublisherViewModel>(ListChangeReason.AddRange, 
																										   [curvePublisher1, curvePublisher2])
																   ]);

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var service = new PublisherSettingsChangedService();

            service.Attach(curveSettings);
            service.SubscribeUpdates(curvePublishers);

            service.Dispose();

            // ACT
            service.Dispose();
            curvePublisher1.HasChanged = true;

            // ASSERT
            Assert.That(curveSettings.HasChanges, Is.False);
        }
    }
}
