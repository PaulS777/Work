﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.Services.Collection;
using Dsp.Gui.CurveSettings.ViewModels;
using DynamicData;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Collection
{
    [TestFixture]
    public class PublisherBorderBrushServiceTests
    {
        [Test]
        public void ShouldSetParentAndChildBorders_When_SubscribeUpdates_With_Parent_CanAssumeTrue()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .WithCanAssume(true)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            // ACT
            borderService.SubscribeUpdates(curvePublishers);

            // ASSERT
            Assert.That(parent.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.Parent));
            Assert.That(child.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.Child));
        }

        [Test]
        public void ShouldSetParentAndChildBorders_When_SubscribeUpdates_With_Parent_CanAssumeFalse()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .WithCanAssume(false)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            // ACT
            borderService.SubscribeUpdates(curvePublishers);

            // ASSERT
            Assert.That(parent.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
            Assert.That(child.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }


        [Test]
        public void ShouldSetParentAndChildBorders_When_Parent_CanAssumeTrue()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            parent.CanAssume = true;

            // ASSERT
            Assert.That(parent.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.Parent));
            Assert.That(child.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.Child));
        }

        [Test]
        public void ShouldSetParentAndChildBorders_When_Parent_PublisherChanged_With_CanAssumeDisabled()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .WithCanAssume(true)
                                                                       .Build();


            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            parent.PublisherChanged = true;
            parent.CanAssume = false;

            // ASSERT
            Assert.That(parent.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
            Assert.That(child.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldSetParentAndChildBorders_When_CanAssumeDisabled()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .WithCanAssume(true)
                                                                       .Build();


            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            parent.CanAssume = false;

            // ASSERT
            Assert.That(parent.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
            Assert.That(child.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldSetNonParentChild_When_PublisherChangedTrue()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();


            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
            {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            curvePublisher.PublisherChanged = true;

            // ASSERT
            Assert.That(curvePublisher.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldSetNonParentChild_When_PublisherChangedFalse()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            curvePublisher.PublisherChanged = true;

            // ACT
            curvePublisher.PublisherChanged = false;

            // ASSERT
            Assert.That(curvePublisher.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldNotSetBorder_When_UnsubscribeUpdates()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();


            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.UnsubscribeUpdates();

            // ACT
            curvePublisher.PublisherChanged = true;

            // ASSERT
            Assert.That(curvePublisher.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldNotSetBorder_When_Disposed()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();


            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.Dispose();

            // ACT
            curvePublisher.PublisherChanged = true;

            // ASSERT
            Assert.That(curvePublisher.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();


            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new PublisherBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.Dispose();

            // ACT
            borderService.Dispose();
            curvePublisher.PublisherChanged = true;

            // ASSERT
            Assert.That(curvePublisher.PublisherBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }
    }
}
