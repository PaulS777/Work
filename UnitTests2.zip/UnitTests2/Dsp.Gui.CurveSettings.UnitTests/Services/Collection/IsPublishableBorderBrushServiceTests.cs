﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.Services.Collection;
using Dsp.Gui.CurveSettings.ViewModels;
using DynamicData;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Collection
{
    [TestFixture]
    public class IsPublishableBorderBrushServiceTests
    {
        [Test]
        public void ShouldSetParentAndChildBorders_When_CanEditIsPublishable_With_PublisherChanged()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            parent.PublisherChanged = true;

            // ACT
            parent.CanEditIsPublishable = true;

            // ASSERT
            Assert.That(parent.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Parent));
            Assert.That(child.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Child));
        }

        [Test]
        public void ShouldSetParentAndChildBorders_When_IsPublishableChanged_With_PublisherChanged()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            parent.PublisherChanged = true;
            parent.CanEditIsPublishable = true;

            // ACT
            parent.IsPublishableChanged = true;

            // ASSERT
            Assert.That(parent.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
            Assert.That(child.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldSetParentAndChildBordersNone_When_Undo_PublisherChanges()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            parent.PublisherChanged = true;
            parent.CanEditIsPublishable = true;
            parent.IsPublishableChanged = true;

            // ACT
            parent.IsPublishableChanged = false;
            parent.PublisherChanged = false;
            parent.CanEditIsPublishable = false;

            // ASSERT
            Assert.That(parent.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
            Assert.That(child.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldSetParentBorderOnly_When_IsPublishableChanged_With_PublisherChangedFalse()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            parent.IsPublishableChanged = true;

            // ASSERT
            Assert.That(parent.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
            Assert.That(child.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldSetChildBorder_When_IsPublishableChanged_With_PublisherChangedFalse()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true)
                                                                      .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            child.IsPublishableChanged = true;

            // ASSERT
            Assert.That(child.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldSetNonParentChildBorder_When_IsPublishableChanged_With_PublisherChanged()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            curvePublisher.PublisherChanged = true;

            // ACT
            curvePublisher.IsPublishableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldSetNonParentChildBorder_When_IsPublishableChanged()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            curvePublisher.IsPublishableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldNotSetBorder_When_UnsubscribeUpdates()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.UnsubscribeUpdates();

            // ACT
            curvePublisher.IsPublishableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldNotSetBorder_When_Disposed()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.Dispose();
        
            // ACT
            curvePublisher.IsPublishableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsPublishableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.Dispose();

            // ACT
            borderService.Dispose();
            curvePublisher.IsPublishableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsPublishableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }
    }
}
