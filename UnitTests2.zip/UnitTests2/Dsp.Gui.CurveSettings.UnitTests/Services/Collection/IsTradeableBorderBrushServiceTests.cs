﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.Services.Collection;
using Dsp.Gui.CurveSettings.ViewModels;
using DynamicData;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Collection
{
    [TestFixture]
    public class IsTradeableBorderBrushServiceTests
    {
        [Test]
        public void ShouldSetParentAndChildBorders_When_CanEditIsTradeable_With_PublisherChanged()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            parent.PublisherChanged = true;

            // ACT
            parent.CanEditIsTradeable = true;

            // ASSERT
            Assert.That(parent.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Parent));
            Assert.That(child.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Child));
        }

        [Test]
        public void ShouldSetParentAndChildBorders_When_IsTradeableChanged_With_PublisherChanged()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            parent.PublisherChanged = true;
            parent.CanEditIsTradeable = true;

            // ACT
            parent.IsTradeableChanged = true;

            // ASSERT
            Assert.That(parent.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
            Assert.That(child.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldSetParentAndChildBordersNone_When_Undo_Changes()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            parent.PublisherChanged = true;
            parent.CanEditIsTradeable = true;
            parent.IsTradeableChanged= true;

            // ACT
            parent.IsTradeableChanged = false;
            parent.PublisherChanged = false;
            parent.CanEditIsTradeable = false;

            // ASSERT
            Assert.That(parent.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
            Assert.That(child.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldSetParentBorderOnly_When_IsTradeableChanged_With_PublisherChangedFalse()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true).Build();

            var children = new List<CurvePublisherViewModel> { child };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithChildren(children)
                                                                       .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { parent, child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            parent.IsTradeableChanged = true;

            // ASSERT
            Assert.That(parent.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
            Assert.That(child.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldSetChildBorder_When_IsTradeableChanged_With_PublisherChangedFalse()
        {
            var child = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true)
                                                                      .Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { child })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            child.IsTradeableChanged = true;

            // ASSERT
            Assert.That(child.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldSetNonParentChildBorder_When_IsTradeableChanged_With_PublisherChanged()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            curvePublisher.PublisherChanged = true;

            // ACT
            curvePublisher.IsTradeableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldSetNonParentChildBorder_When_IsTradeableChanged()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            // ACT
            curvePublisher.IsTradeableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.Changed));
        }

        [Test]
        public void ShouldNotSetBorder_When_UnsubscribeUpdates()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.UnsubscribeUpdates();

            // ACT
            curvePublisher.IsTradeableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldNotSetBorder_When_Disposed()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.Dispose();

            // ACT
            curvePublisher.IsTradeableChanged= true;

            // ASSERT
            Assert.That(curvePublisher.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().Build();

            var changeSet = new ChangeSet<CurvePublisherViewModel>(new Change<CurvePublisherViewModel>[]
                                                                   {
                                                                       new(ListChangeReason.AddRange, new[] { curvePublisher })
                                                                   });

            var curvePublishers = new BehaviorSubject<IChangeSet<CurvePublisherViewModel>>(changeSet);

            var borderService = new IsTradeableBorderBrushService();

            borderService.SubscribeUpdates(curvePublishers);

            borderService.Dispose();

            // ACT
            borderService.Dispose();
            curvePublisher.IsTradeableChanged = true;

            // ASSERT
            Assert.That(curvePublisher.IsTradeableBorderBrush, Is.EqualTo(ParentChildBorderBrush.None));
        }
    }
}
