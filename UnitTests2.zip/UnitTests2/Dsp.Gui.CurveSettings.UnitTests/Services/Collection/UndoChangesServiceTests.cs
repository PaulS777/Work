﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.Services.Collection;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Collection
{
    internal interface IUndoChangesServiceTestObjects
    {
        ICurvePublisherViewModelUpdateService CurvePublisherViewModelUpdateService { get; }
        UndoChangesService UndoChangesService { get; }
    }

    [TestFixture]
    public class UndoChangesServiceTests
    {
        private class UndoChangesServiceTestObjectBuilder
        {
            public IUndoChangesServiceTestObjects Build()
            {
                var testObjects = new Mock<IUndoChangesServiceTestObjects>();

                var updateService = new Mock<ICurvePublisherViewModelUpdateService>();

                testObjects.SetupGet(o => o.CurvePublisherViewModelUpdateService)
                           .Returns(updateService.Object);

                var undoChangesService = new UndoChangesService(updateService.Object);

                testObjects.SetupGet(o => o.UndoChangesService)
                           .Returns(undoChangesService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateViewModels_When_UndoChanges()
        {
            var users = new List<User> { new UserBuilder().User() };

            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().Build();

            var priceCurvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                                    .WithPriceCurveSetting(priceCurveSetting)
                                                                                    .Build();

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().Build();

            var fxCurvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.FxCurve)
                                                                                 .WithFxCurveSetting(fxCurveSetting)
                                                                                 .Build();

            var curvePublishers = new[] { priceCurvePublisher, fxCurvePublisher };

            var testObjects = new UndoChangesServiceTestObjectBuilder().Build();

            // ACT
            testObjects.UndoChangesService.UndoChanges(curvePublishers, 10, users);

            // ASSERT
            Mock.Get(testObjects.CurvePublisherViewModelUpdateService)
                .Verify(p => p.UpdateViewModelFromPriceCurve(priceCurvePublisher, 10, priceCurveSetting, It.Is<IList<User>>(u => u.Count == 1)));

            Mock.Get(testObjects.CurvePublisherViewModelUpdateService)
                .Verify(p => p.UpdateViewModelFromFxCurve(fxCurvePublisher, 10, fxCurveSetting, It.Is<IList<User>>(u => u.Count == 1)));
        }
    }
}
