﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.Services.Filter;
using Dsp.Gui.CurveSettings.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Filter
{
    internal interface IFilterSubscriptionsServiceTestObjects
    {
        CurveSettingsViewModel ViewModel { get; }
		IPublisherFilterService PublisherFilterService { get; }
		ICurveGroupFilterSelectionService CurveGroupFilterService { get; }
		ICurvePublisherRowsFilterService CurvePublisherRowsFilterService { get; }
		ISubject<PublisherFilterArgs> PublisherFilter { get; }
        ISubject<CurveGroupFilterArgs> CurveGroupFilter { get; }
        FilterSubscriptionsService FilterSubscriptionsService { get; }
	}

	public class FilterSubscriptionsServiceTests
	{
        private class FilterSubscriptionServiceTestObjectBuilder
        {
            private PublisherFilterArgs _publisherFilter;
            private CurveGroupFilterArgs _curveGroupFilter;

			public FilterSubscriptionServiceTestObjectBuilder WithPublisherFilter(PublisherFilterArgs values)
            {
                _publisherFilter = values;
                return this;
            }

            public FilterSubscriptionServiceTestObjectBuilder WithCurveGroupFilter(CurveGroupFilterArgs values)
            {
                _curveGroupFilter = values;
                return this;
            }

			public IFilterSubscriptionsServiceTestObjects Build()
            {
                var testObjects = new Mock<IFilterSubscriptionsServiceTestObjects>();

                var viewModel = new CurveSettingsViewModel();

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(viewModel);

                var publisherFilter = new BehaviorSubject<PublisherFilterArgs>(_publisherFilter);

                testObjects.SetupGet(o => o.PublisherFilter)
                           .Returns(publisherFilter);

                var publisherFilterService = new Mock<IPublisherFilterService>();

                publisherFilterService.SetupGet(f => f.Filter)
                                      .Returns(publisherFilter);

                testObjects.SetupGet(o => o.PublisherFilterService)
                           .Returns(publisherFilterService.Object);

                var curveGroupFilter = new BehaviorSubject<CurveGroupFilterArgs>(_curveGroupFilter);

                testObjects.SetupGet(o => o.CurveGroupFilter)
                           .Returns(curveGroupFilter);

                var curveGroupFilterSelectionService = new Mock<ICurveGroupFilterSelectionService>();

                curveGroupFilterSelectionService.SetupGet(f => f.Filter)
                                                .Returns(curveGroupFilter);

                testObjects.SetupGet(o => o.CurveGroupFilterService)
                           .Returns(curveGroupFilterSelectionService.Object);


				var rowsFilterService = new Mock<ICurvePublisherRowsFilterService>();

                testObjects.SetupGet(o => o.CurvePublisherRowsFilterService)
                           .Returns(rowsFilterService.Object);

                var filterSubscriptionService = new FilterSubscriptionsService(rowsFilterService.Object)
                                                {
                                                    PublisherFilter = publisherFilterService.Object,
                                                    CurveGroupFilter = curveGroupFilterSelectionService.Object
                                                };

                testObjects.SetupGet(o => o.FilterSubscriptionsService)
                           .Returns(filterSubscriptionService);

                return testObjects.Object;
            }
		}

        [Test]
        public void ShouldFilterRows_On_CurveGroupFilter()
        {
            var publisherFilterArgs = new PublisherFilterArgs(string.Empty, []);

            var curveGroupIds = new[] { 2 };
            var curveGroupFilterArgs = new CurveGroupFilterArgs("groups", curveGroupIds);

            var curvePublishers = new[] { new CurvePublisherViewModel(Mock.Of<IDisposable>()) };

			var testObjects = new FilterSubscriptionServiceTestObjectBuilder().WithPublisherFilter(publisherFilterArgs)
                                                                              .Build();
            
            testObjects.FilterSubscriptionsService.Attach(testObjects.ViewModel);

            // ARRANGE
            using (testObjects.FilterSubscriptionsService.SubscribeFilters(curvePublishers))
            {
                // ACT
                testObjects.CurveGroupFilter.OnNext(curveGroupFilterArgs);

                // ASSERT
                Mock.Get(testObjects.CurvePublisherRowsFilterService)
                    .Verify(f => f.FilterCurvePublisherRows(It.Is<IList<CurvePublisherViewModel>>(p => p.Count == 1),
                                                            It.Is<ICollection<int>>(cg => cg.SequenceEqual(curveGroupIds)),
                                                            It.Is<ICollection<int>>(i => i.Count == 0),
                                                            It.Is<string>(text => text == null)));

                Assert.That(testObjects.ViewModel.CurveGroupFilterText, Is.EqualTo("groups"));
			}
        }

        [Test]
        public void ShouldFilterRows_On_PublisherFilter()
        {
            var curveGroupFilterArgs = new CurveGroupFilterArgs(string.Empty, []);

            var publisherIds = new[] { 10 };
            var publisherFilterArgs = new PublisherFilterArgs("publishers", publisherIds);

			var curvePublishers = new[] { new CurvePublisherViewModel(Mock.Of<IDisposable>()) };

            var testObjects = new FilterSubscriptionServiceTestObjectBuilder().WithCurveGroupFilter(curveGroupFilterArgs)
                                                                              .Build();

            testObjects.FilterSubscriptionsService.Attach(testObjects.ViewModel);

            // ARRANGE
            using (testObjects.FilterSubscriptionsService.SubscribeFilters(curvePublishers))
            {
                // ACT
                testObjects.PublisherFilter.OnNext(publisherFilterArgs);

                // ASSERT
                Mock.Get(testObjects.CurvePublisherRowsFilterService)
                    .Verify(f => f.FilterCurvePublisherRows(It.Is<IList<CurvePublisherViewModel>>(p => p.Count == 1),
                                                            It.Is<ICollection<int>>(cg => cg.Count == 0),
                                                            It.Is<ICollection<int>>(i => i.SequenceEqual(publisherIds)),
                                                            It.Is<string>(text => text == null)));

                Assert.That(testObjects.ViewModel.PublisherFilterText, Is.EqualTo("publishers"));
			}
        }

		[Test]
        public void ShouldFilterRows_On_SearchText()
        {
            var publisherFilterArgs = new PublisherFilterArgs(string.Empty, []);
            var curveGroupFilterArgs = new CurveGroupFilterArgs(string.Empty, []);

            var curvePublishers = new[] { new CurvePublisherViewModel(Mock.Of<IDisposable>()) };

            var testObjects = new FilterSubscriptionServiceTestObjectBuilder().WithPublisherFilter(publisherFilterArgs)
                                                                              .WithCurveGroupFilter(curveGroupFilterArgs)
                                                                              .Build();

            testObjects.FilterSubscriptionsService.Attach(testObjects.ViewModel);

            // ARRANGE
            using (testObjects.FilterSubscriptionsService.SubscribeFilters(curvePublishers))
            {
                // ACT
                testObjects.ViewModel.SearchText = "curve";

                // ASSERT
                Mock.Get(testObjects.CurvePublisherRowsFilterService)
                    .Verify(f => f.FilterCurvePublisherRows(It.Is<IList<CurvePublisherViewModel>>(p => p.Count == 1),
                                                            It.Is<ICollection<int>>(cg => cg.Count == 0),
                                                            It.Is<ICollection<int>>(i => i.Count == 0),
                                                            It.Is<string>(text => text == "curve")));
            }
		}

        [Test]
        public void ShouldDisposeFilters_When_Dispose()
        { 
            var testObjects = new FilterSubscriptionServiceTestObjectBuilder().Build();

            // ACT
            testObjects.FilterSubscriptionsService.Dispose();

            // ASSERT
            Mock.Get(testObjects.PublisherFilterService)
                .Verify(p => p.Dispose());

            Mock.Get(testObjects.CurveGroupFilterService)
                .Verify(c => c.Dispose());
		}

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new FilterSubscriptionServiceTestObjectBuilder().Build();

            // ARRANGE
            testObjects.FilterSubscriptionsService.Dispose();

			// ACT
			testObjects.FilterSubscriptionsService.Dispose();

            // ASSERT
            Mock.Get(testObjects.PublisherFilterService)
                .Verify(p => p.Dispose(), Times.Once);
        }
	}
}
