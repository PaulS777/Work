﻿using System;
using System.Collections.Generic;
using Dsp.Gui.CurveSettings.Services.Filter;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Filter
{
    [TestFixture]
    public class CurvePublisherRowsFilterServiceTests
    {
        [Test]
        public void ShouldFilterRowsByCurveGroups_And_Publishers_With_SearchTextEmpty()
        {
            var crudeId = 20;
            var fuelOilId = 21;
            var moGasId = 22;

            var curveGroupIds = new [] { crudeId, fuelOilId };
            var publisherIds = new [] {10, 11 };

            var curvePublisher1 = new CurvePublisherViewModel(Mock.Of<IDisposable>());

            curvePublisher1.PublicationDetails().CurveGroupId = crudeId;
            curvePublisher1.PublicationDetails().CurrentPublisherId = 10;

            var curvePublisher2 = new CurvePublisherViewModel(Mock.Of<IDisposable>());

            curvePublisher2.PublicationDetails().CurveGroupId = crudeId;
			curvePublisher2.PublicationDetails().CurrentPublisherId = 12;

            var curvePublisher3 = new CurvePublisherViewModel(Mock.Of<IDisposable>());

            curvePublisher3.PublicationDetails().CurveGroupId = moGasId;
			curvePublisher3.PublicationDetails().CurrentPublisherId = 10;

            var curvePublishers = new List<CurvePublisherViewModel>
            {
                curvePublisher1, curvePublisher2, curvePublisher3
            };

            var filterService = new CurvePublisherRowsFilterService();

            // ACT
            filterService.FilterCurvePublisherRows(curvePublishers, 
                                                   curveGroupIds, 
                                                   publisherIds, 
                                                   null);

            // ASSERT
            Assert.That(curvePublisher1.IsInFilter, Is.True);
            Assert.That(curvePublisher2.IsInFilter, Is.False);
            Assert.That(curvePublisher3.IsInFilter, Is.False);
        }

        [Test]
        public void ShouldFilterRowsBySearchText_With_SearchTextSet_And_OtherFiltersMatch()
        {
            var crudeId = 20;
            var fuelOilId = 21;

            var curveGroupIds = new[] { crudeId, fuelOilId };
            var publisherIds = new[] { 10, 11 };

			var curvePublisher1 = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveName = "curve-A"
            };

            curvePublisher1.PublicationDetails().CurveGroupId = crudeId;
            curvePublisher1.PublicationDetails().CurrentPublisherId = 10;

            var curvePublisher2 = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                PriceCurveName = "curve-B"
            };

            curvePublisher2.PublicationDetails().CurveGroupId = crudeId;
            curvePublisher2.PublicationDetails().CurrentPublisherId = 10;

            var curvePublishers = new List<CurvePublisherViewModel>
            {
                curvePublisher1, curvePublisher2
            };

            var filterService = new CurvePublisherRowsFilterService();

            var searchText = "rve-A";

            // ACT
            filterService.FilterCurvePublisherRows(curvePublishers, 
                                                   curveGroupIds, 
                                                   publisherIds, 
                                                   searchText);

            // ASSERT
            Assert.That(curvePublisher1.IsInFilter, Is.True);
            Assert.That(curvePublisher2.IsInFilter, Is.False);
        }

        [Test]
        public void ShouldIncludeParentAndSiblings_When_ChildIsInFilter()
        {
            var crudeId = 20;
            var fuelOilId = 21;

            var curveGroupIds = new[] { crudeId, fuelOilId };
            var publisherIds = new[] { 10, 11 };

			var curveSetting1 = new PriceCurveSettingTestObjectBuilder().WithPublisherId(10).Build();
            var curveSetting2 = new PriceCurveSettingTestObjectBuilder().WithPublisherId(10).Build();
            var curveSetting3 = new PriceCurveSettingTestObjectBuilder().WithPublisherId(10).Build();

            var child1 = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true)
                                                                       .WithPriceCurveName("child-A")
                                                                       .WithCurrentPublisherId(10)
                                                                       .WithPriceCurveSetting(curveSetting1)
                                                                       .WithCurveGroupId(crudeId)
                                                                       .Build();

            var child2 = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true)
                                                                       .WithPriceCurveName("child-B")
                                                                       .WithCurrentPublisherId(10)
                                                                       .WithPriceCurveSetting(curveSetting2)
                                                                       .WithCurveGroupId(crudeId)
                                                                       .Build();

            var children = new List<CurvePublisherViewModel> { child1, child2 };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithPriceCurveName("parent")
                                                                       .WithCurrentPublisherId(10)
                                                                       .WithPriceCurveSetting(curveSetting3)
                                                                       .WithCurveGroupId(crudeId)
                                                                       .WithChildren(children)
                                                                       .Build();

            var curvePublishers = new[] { parent, child1, child2 };

            var filterService = new CurvePublisherRowsFilterService();

            var searchText = "ild-A";

            // ACT
            filterService.FilterCurvePublisherRows(curvePublishers,
                                                   curveGroupIds,
                                                   publisherIds,
                                                   searchText);

            // ASSERT
            Assert.That(parent.IsInFilter, Is.True);
            Assert.That(child2.IsInFilter, Is.True);
        }

        [Test]
        public void ShouldIncludeChildren_When_ParentIsInFilter()
        {
            var crudeId = 20;
            var fuelOilId = 21;

            var curveGroupIds = new[] { crudeId, fuelOilId };
            var publisherIds = new[] { 10, 11 };

			var curveSetting1 = new PriceCurveSettingTestObjectBuilder().WithPublisherId(10).Build();
            var curveSetting2 = new PriceCurveSettingTestObjectBuilder().WithPublisherId(10).Build();
            var curveSetting3 = new PriceCurveSettingTestObjectBuilder().WithPublisherId(10).Build();

            var child1 = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true)
                                                                       .WithPriceCurveName("child-A")
                                                                       .WithCurrentPublisherId(10)
                                                                       .WithPriceCurveSetting(curveSetting1)
                                                                       .WithCurveGroupId(crudeId)
                                                                       .Build();

            var child2 = new CurvePublisherViewModelTestObjectBuilder().WithIsChild(true)
                                                                       .WithPriceCurveName("child-B")
                                                                       .WithCurrentPublisherId(10)
                                                                       .WithPriceCurveSetting(curveSetting2)
                                                                       .WithCurveGroupId(crudeId)
                                                                       .Build();

            var children = new List<CurvePublisherViewModel> { child1, child2 };

            var parent = new CurvePublisherViewModelTestObjectBuilder().WithIsParent(true)
                                                                       .WithPriceCurveName("parent")
                                                                       .WithCurrentPublisherId(10)
                                                                       .WithPriceCurveSetting(curveSetting3)
                                                                       .WithCurveGroupId(crudeId)
                                                                       .WithChildren(children)
                                                                       .Build();

            var curvePublishers = new[] { parent, child1, child2 };

            var filterService = new CurvePublisherRowsFilterService();

            var searchText = "paren";

            // ACT
            filterService.FilterCurvePublisherRows(curvePublishers,
                                                   curveGroupIds,
                                                   publisherIds,
                                                   searchText);

            // ASSERT
            Assert.That(child1.IsInFilter, Is.True);
            Assert.That(child2.IsInFilter, Is.True);
        }
    }
}
