﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.CurveSettings.Services.Premiums;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Premiums
{
    [TestFixture]
    public class TenorPremiumsLookupServiceTests
    {
        [Test]
        public void ShouldPublishTenorPremiums()
        {
            var premium1 = new PublisherTenorPremiumTestObjectBuilder().WithId(50)
                                                                       .WithPriceCurveId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premium2 = new PublisherTenorPremiumTestObjectBuilder().WithId(51)
                                                                       .WithPriceCurveId(102)
                                                                       .WithPublisherId(10)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premium3 = new PublisherTenorPremiumTestObjectBuilder().WithId(52)
                                                                       .WithPriceCurveId(102)
                                                                       .WithPublisherId(11)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premiums = new List<PublisherTenorPremium>
                           {
                               premium1, premium2, premium3
                           };

            var publisherTenorPremiums = new Subject<List<PublisherTenorPremium>>();

            var curveControlService = new Mock<ICurveControlService>();

            curveControlService.SetupGet(c => c.PublisherTenorPremiums)
                               .Returns(publisherTenorPremiums);

            var lookupService = new TenorPremiumsLookupService(curveControlService.Object);

            ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>> result = null;

            using (lookupService.CurvePremiums.Subscribe(r => result = r))
            {
                // ACT
                publisherTenorPremiums.OnNext(premiums);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
                Assert.That(result[101].Count, Is.EqualTo(1));
                Assert.That(result[102].Count, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldNotPublishTenorPremiums_When_Disposed()
        {
            var premium1 = new PublisherTenorPremiumTestObjectBuilder().WithId(50)
                                                                       .WithPriceCurveId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premium2 = new PublisherTenorPremiumTestObjectBuilder().WithId(51)
                                                                       .WithPriceCurveId(102)
                                                                       .WithPublisherId(10)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premium3 = new PublisherTenorPremiumTestObjectBuilder().WithId(52)
                                                                       .WithPriceCurveId(102)
                                                                       .WithPublisherId(11)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premiums = new List<PublisherTenorPremium>
                           {
                               premium1, premium2, premium3
                           };

            var publisherTenorPremiums = new Subject<List<PublisherTenorPremium>>();

            var curveControlService = new Mock<ICurveControlService>();

            curveControlService.SetupGet(c => c.PublisherTenorPremiums)
                               .Returns(publisherTenorPremiums);

            var lookupService = new TenorPremiumsLookupService(curveControlService.Object);

            ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>> result = null;

            using (lookupService.CurvePremiums.Subscribe(r => result = r))
            {
                lookupService.Dispose();

                // ACT
                publisherTenorPremiums.OnNext(premiums);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(0));
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var premium1 = new PublisherTenorPremiumTestObjectBuilder().WithId(50)
                                                                       .WithPriceCurveId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premium2 = new PublisherTenorPremiumTestObjectBuilder().WithId(51)
                                                                       .WithPriceCurveId(102)
                                                                       .WithPublisherId(10)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premium3 = new PublisherTenorPremiumTestObjectBuilder().WithId(52)
                                                                       .WithPriceCurveId(102)
                                                                       .WithPublisherId(11)
                                                                       .WithTenorPremiums(new[]
                                                                                          {
                                                                                              new TenorPremium(new MonthlyTenor(2019, 12), 1.0, 1.0)
                                                                                          })
                                                                       .Build();

            var premiums = new List<PublisherTenorPremium>
                           {
                               premium1, premium2, premium3
                           };

            var publisherTenorPremiums = new Subject<List<PublisherTenorPremium>>();

            var curveControlService = new Mock<ICurveControlService>();

            curveControlService.SetupGet(c => c.PublisherTenorPremiums)
                               .Returns(publisherTenorPremiums);

            var lookupService = new TenorPremiumsLookupService(curveControlService.Object);

            ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>> result = null;

            using (lookupService.CurvePremiums.Subscribe(r => result = r))
            {
                lookupService.Dispose();

                // ACT
                lookupService.Dispose();
                publisherTenorPremiums.OnNext(premiums);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(0));
            }
        }
    }
}
