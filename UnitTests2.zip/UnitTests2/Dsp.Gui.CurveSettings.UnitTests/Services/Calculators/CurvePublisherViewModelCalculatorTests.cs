﻿using System;
using Dsp.DataContracts.Curve;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.Services.Calculators;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.Calculators
{
    [TestFixture]
    public class CurvePublisherViewModelCalculatorTests
    {
        #region CalculateOnIsPublishableChanged

        [TestCase(CurvePublisherType.PriceCurve)]
        [TestCase(CurvePublisherType.FxCurve)]
        public void ShouldCalculateOnIsPublishableChanged_With_IsPublishableTrue(CurvePublisherType publisherType)
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                IsTradeable = false,
                IsPublishable = true,
                IsPublishableChanged = false,
                PublisherType = publisherType
            };

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnIsPublishableChanged(viewModel, false);

            // ASSERT
            Assert.That(viewModel.IsPublishableChanged, Is.True);
            Assert.That(viewModel.IsTradeable, Is.False);
        }

        [TestCase(CurvePublisherType.PriceCurve)]
        [TestCase(CurvePublisherType.FxCurve)]
        public void ShouldNotSetIsTradeable_When_CalculateOnIsPublishableChanged_With_IsPublishableTrue(CurvePublisherType publisherType)
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                IsTradeable = true, 
                IsPublishable = true, 
                PublisherType = publisherType
            };

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnIsPublishableChanged(viewModel, false);

            // ASSERT
            Assert.That(viewModel.IsTradeable, Is.True);
        }

		[TestCase(CurvePublisherType.PriceCurve)]
        [TestCase(CurvePublisherType.FxCurve)]
        public void ShouldSetIsTradeableFalse_When_CalculateOnIsPublishableChanged_With_IsPublishableFalse(CurvePublisherType publisherType)
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                IsTradeable = true,
                IsPublishable = false,
                IsPublishableChanged = false,
                PublisherType = publisherType
            };

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnIsPublishableChanged(viewModel, true);

            // ASSERT
            Assert.That(viewModel.IsPublishableChanged, Is.True);
            Assert.That(viewModel.IsTradeable, Is.False);
        }

        #endregion

        #region CalculateOnIsTradeableChanged

        [TestCase(CurvePublisherType.PriceCurve)]
        [TestCase(CurvePublisherType.FxCurve)]
        public void ShouldCalculateOnIsTradeableChanged_With_IsTradeableTrue(CurvePublisherType publisherType)
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                IsTradeable = true, IsTradeableChanged = false, PublisherType = publisherType
            };

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnIsTradeableChanged(viewModel, false);

            // ASSERT
            Assert.That(viewModel.IsTradeableChanged, Is.True);
        }

        [TestCase(CurvePublisherType.PriceCurve)]
        [TestCase(CurvePublisherType.FxCurve)]
        public void ShouldSetIsPublishableTrue_When_CalculateOnIsTradeableChanged_With_IsTradeableTrue(CurvePublisherType publisherType)
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                IsTradeable = true, 
                IsPublishable = false, 
                PublisherType = publisherType
            };

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnIsTradeableChanged(viewModel, false);

            // ASSERT
            Assert.That(viewModel.IsPublishable, Is.True);
        }

        #endregion

        #region CalculateOnAssume - Price Curve

        [Test]
        public void ShouldDisableAssume_And_SetToCurrentUser_And_EnablePublishable_When_AssumePriceCurve()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                PublisherChanged = false,
                IsTradeableChanged = false,
                IsPublishableChanged = false
            };
          
            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            viewModel.PublisherType = CurvePublisherType.PriceCurve;
            viewModel.PublicationDetails().PriceCurveSetting = setting;

            var user = new UserBuilder().WithId(10)
                                        .WithName("user")
                                        .User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumePriceCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.PublicationDetails().CurrentPublisherId, Is.EqualTo(10));
            Assert.That(viewModel.PublicationDetails().IsOwnedByCurrentUser, Is.True);
            Assert.That(viewModel.PublisherName, Is.EqualTo("user"));
            Assert.That(viewModel.CanEditIsPublishable, Is.True);
            Assert.That(viewModel.CanAssume, Is.False);
        }

        [Test]
        public void ShouldSetIsTradeableFalse_When_AssumePriceCurve_With_InheritMarginsFalse()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                InheritMargins = false,
                IsTradeable = true
            };
       
            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            viewModel.PublisherType = CurvePublisherType.PriceCurve;
            viewModel.PublicationDetails().PriceCurveSetting = setting;

            var user = new UserBuilder().WithId(10)
                                        .WithName("user")
                                        .User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumePriceCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.IsTradeable, Is.False);
        }

        [Test]
        public void ShouldNotSetIsTradeableTrue_When_AssumePriceCurve_With_IsTradeableAndInheritMargins()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                InheritMargins = true,
                IsTradeable = false
            };
     
            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            viewModel.PublisherType = CurvePublisherType.PriceCurve;
            viewModel.PublicationDetails().PriceCurveSetting = setting;

            var user = new UserBuilder().WithId(10)
                                        .WithName("user")
                                        .User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumePriceCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.IsTradeable, Is.False);
        }

        [Test]
        public void ShouldKeepTradeableTrue_When_AssumePriceCurve_With_IsTradeableAndInheritMargins()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                InheritMargins = true,
                IsTradeable = true
            };

            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            viewModel.PublisherType = CurvePublisherType.PriceCurve;
            viewModel.PublicationDetails().PriceCurveSetting = setting;

            var user = new UserBuilder().WithId(10)
                                        .WithName("user")
                                        .User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumePriceCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.IsTradeable, Is.True);
        }

        [Test]
        public void ShouldSetCanEditIsTradeableTrue_When_AssumePriceCurve_With_CurrentUserHasPremiums()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                PublisherChanged = false,
                IsTradeableChanged = false,
                IsPublishableChanged = false,
                PublisherType = CurvePublisherType.PriceCurve
            };
   
            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            viewModel.PublicationDetails().PriceCurveSetting = setting;
            viewModel.PublicationDetails().UserHasPremiums = true;

            var user = new UserBuilder().WithId(10)
                                        .WithName("user")
                                        .User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumePriceCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.CanEditIsTradeable, Is.True);
        }

        [Test]
        public void ShouldSetCanEditIsTradeableFalse_When_AssumePriceCurve_With_CurrentUserHasNoPremiums()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                PublisherChanged = false,
                IsTradeableChanged = false,
                IsPublishableChanged = false,
                PublisherType = CurvePublisherType.PriceCurve
            };
        
            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            viewModel.PublicationDetails().PriceCurveSetting = setting;
            viewModel.PublicationDetails().UserHasPremiums = false;

            var user = new UserBuilder().WithId(10)
                                        .WithName("user")
                                        .User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumePriceCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.CanEditIsTradeable, Is.False);
        }

        [Test]
        public void ShouldNotEnablePublishableAndTradeable_When_AssumedByParent()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
                            {
                                PublisherChanged = false,
                                IsTradeableChanged = false,
                                IsPublishableChanged = false,
                                PublisherType = CurvePublisherType.PriceCurve,
                                //AssumedByParent = true,
                                IsChild = true
                            };

            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            viewModel.PublicationDetails().PriceCurveSetting = setting;
            viewModel.PublicationDetails().UserHasPremiums = true;

            var user = new UserBuilder().WithId(10)
                                        .WithName("user")
                                        .User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumePriceCurve(viewModel, user);

			// ASSERT
			Assert.That(viewModel.CanEditIsPublishable, Is.False);
            Assert.That(viewModel.CanEditIsTradeable, Is.False);
        }

        // todo : TASK-2994158 Set IsExcelSource
        [Test]
        public void ShouldEnableIsExcelSource_And_SetFalse_When_AssumePriceCurve()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
                            {
                                PublisherType = CurvePublisherType.PriceCurve,
                            };

            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            viewModel.PublisherType = CurvePublisherType.PriceCurve;
            viewModel.PublicationDetails().PriceCurveSetting = setting;

            var user = new UserBuilder().WithId(10).WithName("user").User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumePriceCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.CanEditIsExcelSource, Is.True);
            Assert.That(viewModel.IsExcelSource, Is.False);
        }

        #endregion

        #region CalculateOnAssume - FxCurve

        [Test]
        public void ShouldSetCanEditIsTradeableTrue_When_AssumeFxCurve()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
            {
                PublisherChanged = false,
                IsTradeableChanged = false,
                IsPublishableChanged = false,
                PublisherType = CurvePublisherType.FxCurve
            };
            var setting = new FxCurveSetting(301, 11, 1.0, true, true);

            viewModel.PublicationDetails().FxCurveSetting = setting;

            var user = new UserBuilder().WithId(10)
                                        .WithName("user")
                                        .User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumeFxCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.CanEditIsTradeable, Is.True);
        }

        [Test]
        public void ShouldNotEnableIsExcelSource_When_AssumeFxCurve()
        {
            var viewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>())
                            {
                                PublisherType = CurvePublisherType.FxCurve
                            };

            var setting = new FxCurveSetting(301, 11, 1.0, true, true);

            viewModel.PublicationDetails().FxCurveSetting = setting;

            var user = new UserBuilder().WithId(10).WithName("user").User();

            var calculator = new CurvePublisherViewModelCalculator();

            // ACT
            calculator.CalculateOnAssumeFxCurve(viewModel, user);

            // ASSERT
            Assert.That(viewModel.CanEditIsExcelSource, Is.False);
            Assert.That(viewModel.IsExcelSource, Is.False);
        }

        #endregion
    }
}
