﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services
{
    [TestFixture]
    internal class PublisherFilterServiceTests
    {
        [Test]
        public void ShouldGetPublishers()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new [] {101, 102};

            // ACT
            var items = filterService.GetPublishers(settings, users, currentUser);

            // ASSERT
            Assert.That(items.Count, Is.EqualTo(4));

            var item1 = items[0];
            Assert.That(item1.DisplayText, Is.EqualTo("ALL"));
            Assert.That(item1.IsGroupingItem, Is.True);
            Assert.That(item1.IsSelected, Is.False);

            var item2 = items[1];
            Assert.That(item2.DisplayText, Is.EqualTo("MINE"));
            Assert.That(item2.IsGroupingItem, Is.True);
            Assert.That(item2.Id, Is.EqualTo(101));
            Assert.That(item2.IsSelected, Is.True);

            var item3 = items[2];
            Assert.That(item3.DisplayText, Is.EqualTo("user-1"));
            Assert.That(item3.IsGroupingItem, Is.False);
            Assert.That(item3.Id, Is.EqualTo(101));
            Assert.That(item3.IsSelected, Is.True);

            var item4 = items[3];
            Assert.That(item4.DisplayText, Is.EqualTo("user-2"));
            Assert.That(item4.IsGroupingItem, Is.False);
            Assert.That(item4.Id, Is.EqualTo(102));
            Assert.That(item4.IsSelected, Is.False);
        }

        [Test]
        public void ShouldGetPublishers_WhenNotPublisher()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] {  102 };

            // ACT
            var items = filterService.GetPublishers(settings, users, currentUser);

            // ASSERT
            Assert.That(items.Count, Is.EqualTo(3));

            var item1 = items[0];
            Assert.That(item1.DisplayText, Is.EqualTo("ALL"));
            Assert.That(item1.IsGroupingItem, Is.True);
            Assert.That(item1.IsSelected, Is.True);
           
            var item2 = items[1];
            Assert.That(item2.DisplayText, Is.EqualTo("MINE"));
            Assert.That(item2.IsGroupingItem, Is.True);
            Assert.That(item2.Id, Is.EqualTo(101));
            Assert.That(item2.IsSelected, Is.False);

            var item3 = items[2];
            Assert.That(item3.DisplayText, Is.EqualTo("user-2"));
            Assert.That(item3.IsGroupingItem, Is.False);
            Assert.That(item3.Id, Is.EqualTo(102));
            Assert.That(item3.IsSelected, Is.True);
        }

        [Test]
        public void ShouldGetNewPublishersOnlyOnNextUpdate()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] {101, 102};

            filterService.GetPublishers(settings, users, currentUser);

            var update = new[] { 101, 102, 103 };

            var items = filterService.GetPublishers(update, users, currentUser);

            // ASSERT
            Assert.That(items.Count, Is.EqualTo(1));

            var item = items[0];
            Assert.That(item.DisplayText, Is.EqualTo("user-3"));
            Assert.That(item.Id, Is.EqualTo(103));
            Assert.That(item.IsGroupingItem, Is.False);
            Assert.That(item.IsSelected, Is.False);
        }

        [Test]
        public void ShouldGetNewPublishersOnlyOnNextUpdate_WhenNotPublisher()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] {  102 };

            filterService.GetPublishers(settings, users, currentUser);

            var update = new[] {  102, 103 };

            var items = filterService.GetPublishers(update, users, currentUser);

            // ASSERT
            Assert.That(items.Count, Is.EqualTo(1));

            var item = items[0];
            Assert.That(item.DisplayText, Is.EqualTo("user-3"));
            Assert.That(item.Id, Is.EqualTo(103));
            Assert.That(item.IsGroupingItem, Is.False);
            Assert.That(item.IsSelected, Is.True);
        }

        [Test]
        public void ShouldPublishFilterOnGetPublishers()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] { 101, 102 };

            PublisherFilterArgs result = null;

            var expectedIds = new[] { 101 };

            using (filterService.Filter.Subscribe(args => result = args))
            {
                // ACT
                filterService.GetPublishers(settings, users, currentUser);

                // ASSERT
                Assert.That(result.PublisherIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("user-1"));
            }
        }

        [Test]
        public void ShouldUpdateFilter_WhenItemUnselected()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] { 101, 102, 103 };

            PublisherFilterArgs result = null;

            var expectedIds = new[] { 101 };

			using (filterService.Filter.Subscribe(args => result = args))

            {
                var items = filterService.GetPublishers(settings, users, currentUser);

                // ACT
                items[3].IsSelected = false;

				// ASSERT
				Assert.That(result.PublisherIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("user-1"));
			}
        }

        [Test]
        public void ShouldUpdateFilter_WhenItemUnSelected_AndSingleSelectedItemRemains()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] { 101, 102, 103 };

			PublisherFilterArgs result = null;

            var expectedIds = new[] { 101, 102, 103 };

			using (filterService.Filter.Subscribe(args => result = args))
            {
                var items = filterService.GetPublishers(settings, users, currentUser);
                items[3].IsSelected = false;

                // ACT
                items[2].IsSelected = false;

				// ASSERT
				Assert.That(result.PublisherIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("ALL PUBLISHERS"));
            }
        }

        [Test]
        public void ShouldUpdateItemsAndPublishFilter_WhenAllPublishersItemUnSelected()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] { 101, 102, 103 };

            PublisherFilterArgs result = null;

            var expectedIds = new[] { 101, 102, 103 };

			using (filterService.Filter.Subscribe(args => result = args))
            {
                var items = filterService.GetPublishers(settings, users, currentUser);

                // ACT
                items[0].IsSelected = false;

                // ASSERT
                Assert.That(items[1].IsSelected, Is.False);
                Assert.That(items[2].IsSelected, Is.False);
                Assert.That(items[3].IsSelected, Is.False);
                Assert.That(items[4].IsSelected, Is.False);

				Assert.That(result.PublisherIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("ALL PUBLISHERS"));
			}
        }

        [Test]
        public void ShouldUpdateItemsAndPublishFilter_WhenItemSelected_WithAllUnselected()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] { 101, 102, 103 };

			PublisherFilterArgs result = null;

            var expectedIds = new[] { 102 };

			using (filterService.Filter.Subscribe(args => result = args))
            {
                var items = filterService.GetPublishers(settings, users, currentUser);

                // ARRANGE - UNSELECT "ALL"
                items[0].IsSelected = false;

                // ACT
                items[3].IsSelected = true;

                // ASSERT
                Assert.That(items[0].IsSelected, Is.False);
                Assert.That(items[1].IsSelected, Is.False);
                Assert.That(items[2].IsSelected, Is.False);
                Assert.That(items[4].IsSelected, Is.False);

                Assert.That(result.PublisherIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("user-2"));
			}
        }

        [Test]
        public void ShouldUpdateItemsAndPublishFilter_WhenAllPublishersItemSelected()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] { 101, 102, 103 };

            PublisherFilterArgs result = null;

            var expectedIds = new[] { 101, 102, 103 };

			filterService.Filter.Subscribe(args => result = args);

            var items = filterService.GetPublishers(settings, users, currentUser);

            // ARRANGE - UNSELECT "ALL"
            items[0].IsSelected = false;
            items[3].IsSelected = true;

            // ACT
            items[0].IsSelected = true;

            // ASSERT
            Assert.That(items[2].IsSelected, Is.True);
            Assert.That(items[3].IsSelected, Is.True);
            Assert.That(items[4].IsSelected, Is.True);

            Assert.That(result.PublisherIds.SequenceEqual(expectedIds));
            Assert.That(result.FilterText, Is.EqualTo("ALL PUBLISHERS"));
		}

        [Test]
        public void ShouldUpdateItemsAndPublishFilter_WhenMineSelected()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] { 101, 102, 103 };

			PublisherFilterArgs result = null;

            var expectedIds = new[] { 101 };

			using (filterService.Filter.Subscribe(args => result = args))
            {
                var items = filterService.GetPublishers(settings, users, currentUser);

                // ACT
                items[1].IsSelected = true;

                // ASSERT
                Assert.That(items[0].IsSelected, Is.False);
                Assert.That(items[2].IsSelected, Is.True);
                Assert.That(items[3].IsSelected, Is.False);
                Assert.That(items[4].IsSelected, Is.False);

                Assert.That(result.PublisherIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("user-1"));
            }
        }

        [Test]
        public void ShouldNotUpdateFilterAfterDispose()
        {
            var currentUser = new UserBuilder().WithId(101).WithName("user-1").User();

            var users = new List<User>
            {
                currentUser,
                new UserBuilder().WithId(102).WithName("user-2").User(),
                new UserBuilder().WithId(103).WithName("user-3").User()
            };

            var filterService = new PublisherFilterService();

            var settings = new[] { 101, 102, 103 };

			PublisherFilterArgs result = null;

			using (filterService.Filter.Subscribe(args => result = args))
            {
                var items = filterService.GetPublishers(settings, users, currentUser);

                result = null;
                filterService.Dispose();

                // ACT
                items[3].IsSelected = false;

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
