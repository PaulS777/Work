﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.Services.GridUpdate;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.GridUpdate
{
    internal interface IFxCurveSettingsGridUpdateServiceTestObjects
    {
        ICurvePublisherViewModelUpdateService CurvePublisherViewModelUpdateService { get; }
        ILogger Logger { get; }
        FxCurveSettingsGridUpdateService FxCurveSettingsGridUpdateService { get; }
    }

    [TestFixture]
    public class FxCurveSettingsGridUpdateServiceTests
    {
        private class FxCurveSettingsGridUpdateServiceTestObjectBuilder
        {
            private IEnumerable<User> _usersSnapshot;

            public FxCurveSettingsGridUpdateServiceTestObjectBuilder WithUsersSnapshot(IEnumerable<User> values)
            {
                _usersSnapshot = values;
                return this;
            }

            public IFxCurveSettingsGridUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IFxCurveSettingsGridUpdateServiceTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.Setup(c => c.GetUsersSnapshot())
                                   .Returns(_usersSnapshot);

                var viewModelUpdateService = new Mock<ICurvePublisherViewModelUpdateService>();

                testObjects.SetupGet(o => o.CurvePublisherViewModelUpdateService)
                           .Returns(viewModelUpdateService.Object);

                var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

                var fxCurveSettingsGridUpdateService = new FxCurveSettingsGridUpdateService(curveControlService.Object, 
                                                                                            viewModelUpdateService.Object, 
                                                                                            TestMocks.GetLoggerFactory(logger).Object);

                testObjects.SetupGet(o => o.FxCurveSettingsGridUpdateService)
                           .Returns(fxCurveSettingsGridUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateViewModel_On_MatchingFxPriceCurveSetting()
        {
            var user = new UserBuilder().WithId(10).User();

            var setting1 = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(101).Build();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithFxCurveId(101).Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithFxCurveId(102).Build();

            var curvePublishers = new[] { curvePublisher1, curvePublisher2 };

            var users = new[] { new UserBuilder().User() };

            var testObjects = new FxCurveSettingsGridUpdateServiceTestObjectBuilder().WithUsersSnapshot(users).Build();

            var settingUpdate = new[]
                                {
                                    setting1,
                                    new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(99).Build()
                                };

            // ACT
            testObjects.FxCurveSettingsGridUpdateService.UpdateFxCurveSettings(curvePublishers,
                                                                               settingUpdate,
                                                                               user);

            // ASSERT
            Mock.Get(testObjects.CurvePublisherViewModelUpdateService)
                .Verify(c => c.UpdateViewModelFromFxCurve(curvePublisher1, 10, setting1, It.Is<List<User>>(u => u.Count == 1)));
        }

        [Test]
        public void ShouldLogInfo_On_NonMatchingFxCurveSettings()
        {
            var user = new UserBuilder().WithId(10).User();

            var setting1 = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(101).Build();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithFxCurveSetting(setting1).Build();

            var setting2 = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(102).Build();

            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithFxCurveSetting(setting2).Build();

            var curvePublishers = new[] { curvePublisher1, curvePublisher2 };

            var users = new[] { new UserBuilder().User() };

            var testObjects = new FxCurveSettingsGridUpdateServiceTestObjectBuilder().WithUsersSnapshot(users).Build();

            var settingUpdate = new[]
                                {
                                    new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(99).Build()
                                };

            // ACT
            testObjects.FxCurveSettingsGridUpdateService.UpdateFxCurveSettings(curvePublishers,
                                                                               settingUpdate,
                                                                               user);

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(log => log.Info(It.IsAny<string>()));

            Mock.Get(testObjects.CurvePublisherViewModelUpdateService)
                .Verify(c => c.UpdateViewModelFromFxCurve(It.IsAny<CurvePublisherViewModel>(),
                                                          It.IsAny<int>(),
                                                          It.IsAny<FxCurveSetting>(),
                                                          It.IsAny<List<User>>()), Times.Never);
        }
    }
}
