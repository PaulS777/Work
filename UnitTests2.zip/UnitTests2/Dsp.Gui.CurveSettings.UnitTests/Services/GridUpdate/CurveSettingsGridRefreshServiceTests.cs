﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.CurveSettings.Services.GridUpdate;
using Dsp.Gui.CurveSettings.Services.Premiums;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using Microsoft.Reactive.Testing;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.GridUpdate
{
    internal interface ICurveSettingsGridRefreshServiceTestObjects
    {
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        ISubject<List<FxCurveSetting>> FxCurveSettings { get; }
        ISubject<ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>> CurvePremiums { get; }
        TestScheduler TestScheduler { get; }
        CurveSettingsGridRefreshService CurveSettingsGridRefreshService { get; }
    }

    [TestFixture]
    public class CurveSettingsGridRefreshServiceTests
    {
        private class CurveSettingsGridRefreshServiceTestObjectBuilder
        {
            public ICurveSettingsGridRefreshServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveSettingsGridRefreshServiceTestObjects>();

                var scheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(scheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(scheduler);

                var priceCurveSettings = new BehaviorSubject<Dictionary<int, PriceCurveSetting>>(null);

                testObjects.SetupGet(o => o.PriceCurveSettings)
                           .Returns(priceCurveSettings);

                var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();

                priceCurveSettingsProvider.SetupGet(p => p.PriceCurveSettings)
                                          .Returns(priceCurveSettings);

                var fxCurveSettings = new BehaviorSubject<List<FxCurveSetting>>(null);

                testObjects.SetupGet(o => o.FxCurveSettings)
                           .Returns(fxCurveSettings);

                var fxCurveSettingsProvider = new Mock<IFxCurveSettingsProvider>();

                fxCurveSettingsProvider.SetupGet(p => p.FxCurveSettings)
                                       .Returns(fxCurveSettings);

                var curvePremiums = new BehaviorSubject<ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>>(null);

                testObjects.SetupGet(o => o.CurvePremiums)
                           .Returns(curvePremiums);

                var tenorPremiumsLookupService = new Mock<ITenorPremiumsLookupService>();

                tenorPremiumsLookupService.SetupGet(o => o.CurvePremiums)
                                          .Returns(curvePremiums);

                var gridRefreshService = new CurveSettingsGridRefreshService(priceCurveSettingsProvider.Object,
                                                                             fxCurveSettingsProvider.Object,
                                                                             tenorPremiumsLookupService.Object,
                                                                             schedulerProvider.Object);

                testObjects.SetupGet(o => o.CurveSettingsGridRefreshService)
                           .Returns(gridRefreshService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublish_On_FirstSettingsAndPremiums_With_BufferIntervalComplete()
        {
            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
                                     {
                                         { 101, new PriceCurveSettingTestObjectBuilder().Build() }
                                     };

            var fxCurveSettings = new List<FxCurveSetting>
                                  {
                                      new FxCurveSettingTestObjectBuilder().Build()
                                  };

            var premiums = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiums.TryAdd(101, new Dictionary<int, PublisherTenorPremium>
                                 {
                                     { 10, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                 });

            var testObjects = new CurveSettingsGridRefreshServiceTestObjectBuilder().Build();

            CurveSettingsGridRefreshArgs result = null;

            var gridRefresh = testObjects.CurveSettingsGridRefreshService.CurveSettingsGridRefresh();

            using (gridRefresh.Subscribe(args => result = args))
            {   
                // ARRANGE
                testObjects.PriceCurveSettings.OnNext(priceCurveSettings);
                testObjects.FxCurveSettings.OnNext(fxCurveSettings);
                testObjects.CurvePremiums.OnNext(premiums);

                // ACT
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(510).Ticks);

				// ASSERT
				Assert.That(result, Is.Not.Null);
                Assert.That(result.PriceCurveSettings.SequenceEqual(priceCurveSettings.Values));
                Assert.That(result.FxCurveSettings.SequenceEqual(fxCurveSettings));
                Assert.That(result.PublisherTenorPremiums.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishNextUpdate_When_CurveSettingsChanged_After_NextBufferPeriod()
        {
            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
                                     {
                                         { 101, new PriceCurveSettingTestObjectBuilder().Build() }
                                     };

            var fxCurveSettings = new List<FxCurveSetting>
                                  {
                                      new FxCurveSettingTestObjectBuilder().Build()
                                  };

            var premiums = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiums.TryAdd(101, new Dictionary<int, PublisherTenorPremium>
                                 {
                                     { 10, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                 });

            var testObjects = new CurveSettingsGridRefreshServiceTestObjectBuilder().Build();

            CurveSettingsGridRefreshArgs result = null;

            var settingsUpdate1 = new Dictionary<int, PriceCurveSetting>
                                  {
                                      { 101, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() },
                                      { 102, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).Build() }
                                  };

            var settingsUpdate2 = new Dictionary<int, PriceCurveSetting>
                                  {
                                      { 101, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() },
                                      { 102, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).Build() },
                                      { 103, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() }
                                  };

            var settingsUpdate3 = new Dictionary<int, PriceCurveSetting>
                                  {
                                      { 101, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() },
                                      { 102, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).Build() },
                                      { 103, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() },
                                      { 104, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() }
                                  };

            var fxSettingsUpdate = new List<FxCurveSetting>
                                   {
                                       new FxCurveSettingTestObjectBuilder().Build(),
                                       new FxCurveSettingTestObjectBuilder().Build()
                                   };

            var premiumsUpdate = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiumsUpdate.TryAdd(101, new Dictionary<int, PublisherTenorPremium>
                                       {
                                           { 10, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                       });

            premiumsUpdate.TryAdd(102, new Dictionary<int, PublisherTenorPremium>
                                       {
                                           { 10, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                       });

            var gridRefresh = testObjects.CurveSettingsGridRefreshService.CurveSettingsGridRefresh();

            using (gridRefresh.Subscribe(args => result = args))
            {
                // ARRANGE - Snapshot
                testObjects.PriceCurveSettings.OnNext(priceCurveSettings);
                testObjects.FxCurveSettings.OnNext(fxCurveSettings);
                testObjects.CurvePremiums.OnNext(premiums);

                // ARRANGE - First Update
                testObjects.PriceCurveSettings.OnNext(settingsUpdate1);
                testObjects.PriceCurveSettings.OnNext(settingsUpdate2);
                testObjects.CurvePremiums.OnNext(premiumsUpdate);
                testObjects.FxCurveSettings.OnNext(fxSettingsUpdate);

                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(510).Ticks);

                // ACT
                testObjects.PriceCurveSettings.OnNext(settingsUpdate3);

                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(510).Ticks);

                // ASSERT
                Assert.That(result.PriceCurveSettings.Count, Is.EqualTo(4));
                Assert.That(result.FxCurveSettings.Count, Is.EqualTo(2));
                Assert.That(result.PublisherTenorPremiums.Count, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldNotPublish_When_NoUpdatesDuringBufferUpdatePeriod()
        {
            var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
                                     {
                                         { 101, new PriceCurveSettingTestObjectBuilder().Build() }
                                     };

            var fxCurveSettings = new List<FxCurveSetting>
                                  {
                                      new FxCurveSettingTestObjectBuilder().Build()
                                  };

            var premiums = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiums.TryAdd(101, new Dictionary<int, PublisherTenorPremium>
                                 {
                                     { 10, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                 });

            var testObjects = new CurveSettingsGridRefreshServiceTestObjectBuilder().Build();

            CurveSettingsGridRefreshArgs result = null;

            var settingsUpdate1 = new Dictionary<int, PriceCurveSetting>
                                  {
                                      { 101, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() },
                                      { 102, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).Build() }
                                  };

            var settingsUpdate2 = new Dictionary<int, PriceCurveSetting>
                                  {
                                      { 101, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() },
                                      { 102, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102).Build() },
                                      { 103, new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build() }
                                  };

            var fxSettingsUpdate = new List<FxCurveSetting>
                                   {
                                       new FxCurveSettingTestObjectBuilder().Build(),
                                       new FxCurveSettingTestObjectBuilder().Build()
                                   };

            var premiumsUpdate = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiumsUpdate.TryAdd(101, new Dictionary<int, PublisherTenorPremium>
                                       {
                                           { 10, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                       });

            premiumsUpdate.TryAdd(102, new Dictionary<int, PublisherTenorPremium>
                                       {
                                           { 10, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                       });

            var gridRefresh = testObjects.CurveSettingsGridRefreshService.CurveSettingsGridRefresh();

            using (gridRefresh.Subscribe(args => result = args))
            {
                // ARRANGE - Snapshot
                testObjects.PriceCurveSettings.OnNext(priceCurveSettings);
                testObjects.FxCurveSettings.OnNext(fxCurveSettings);
                testObjects.CurvePremiums.OnNext(premiums);

                // ARRANGE - First Update
                testObjects.PriceCurveSettings.OnNext(settingsUpdate1);
                testObjects.PriceCurveSettings.OnNext(settingsUpdate2);
                testObjects.CurvePremiums.OnNext(premiumsUpdate);
                testObjects.FxCurveSettings.OnNext(fxSettingsUpdate);

                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(510).Ticks);

                result = null;

                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(510).Ticks);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
