﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.Gui.CurveSettings.Services.GridUpdate;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.GridUpdate
{
    internal interface ITenorPremiumsGridUpdateServiceTestObjects
    {
        ILogger Logger { get; }
        TenorPremiumsGridUpdateService TenorPremiumsGridUpdateService { get; }
    }

    [TestFixture]
    public class TenorPremiumsGridUpdateServiceTests
    {
        private class TenorPremiumsGridUpdateServiceTestObjectBuilder
        {
            public ITenorPremiumsGridUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<ITenorPremiumsGridUpdateServiceTestObjects>();

                var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

                var tenorPremiumsGridUpdateService = new TenorPremiumsGridUpdateService(TestMocks.GetLoggerFactory(logger).Object);

                testObjects.SetupGet(o => o.TenorPremiumsGridUpdateService)
                           .Returns(tenorPremiumsGridUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldEnableInheritMarginsAndSetTrue_When_Premiums_Exist_For_CurrentUser_And_CurvePublisher()
        {
            var currentUserId = 10;

            var setting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                  .WithPublisherId(11)
                                                                  .Build();

            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveId(101)
                                                                               .WithPriceCurveSetting(setting)
                                                                               .Build();

            var curvePublishers = new[] { curvePublisher };

            var premiums = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiums.TryAdd(101, new Dictionary<int, PublisherTenorPremium>
                                 {
                                     { currentUserId, new PublisherTenorPremiumTestObjectBuilder().Build() },
                                     { 11, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                 });

            var testObjects = new TenorPremiumsGridUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorPremiumsGridUpdateService.UpdateTenorPremiums(curvePublishers, premiums, currentUserId);

            // ASSERT
            Assert.That(curvePublisher.PublicationDetails().UserHasPremiums, Is.True);
            Assert.That(curvePublisher.PublicationDetails().PublisherHasPremiums, Is.True);
            Assert.That(curvePublisher.InheritMargins, Is.True);
            Assert.That(curvePublisher.CanEditInheritMargins, Is.True);
        }

        [Test]
        public void ShouldDisableInheritMarginsAndSetTrue_When_Premiums_Exist_OnlyFor_CurvePublisher()
        {
            var currentUserId = 10;

            var setting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(11)
                                                                  .Build();

            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveId(101)
                                                                               .WithPriceCurveSetting(setting)
                                                                               .Build();

            var curvePublishers = new[] { curvePublisher };

            var premiums = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiums.TryAdd(101, new Dictionary<int, PublisherTenorPremium>
                                 {
                                     { 11, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                 });

            var testObjects = new TenorPremiumsGridUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorPremiumsGridUpdateService.UpdateTenorPremiums(curvePublishers, premiums, currentUserId);

            // ASSERT
            Assert.That(curvePublisher.PublicationDetails().UserHasPremiums, Is.False);
            Assert.That(curvePublisher.PublicationDetails().PublisherHasPremiums, Is.True);
            Assert.That(curvePublisher.InheritMargins, Is.True);
            Assert.That(curvePublisher.CanEditInheritMargins, Is.False);
        }

        [Test]
        public void ShouldDisableInheritMarginsAndSetFalse_When_Premiums_NotExist_For_CurvePublisher_Or_CurrentUser()
        {
            var currentUserId = 10;

            var setting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(11)
                                                                  .Build();

            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveId(101)
                                                                               .WithPriceCurveSetting(setting)
                                                                               .Build();

            var curvePublishers = new[] { curvePublisher };

            var premiums = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiums.TryAdd(101, new Dictionary<int, PublisherTenorPremium>
                                 {
                                     { 99, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                 });

            var testObjects = new TenorPremiumsGridUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorPremiumsGridUpdateService.UpdateTenorPremiums(curvePublishers, premiums, currentUserId);

            // ASSERT
            Assert.That(curvePublisher.PublicationDetails().UserHasPremiums, Is.False);
            Assert.That(curvePublisher.PublicationDetails().PublisherHasPremiums, Is.False);
            Assert.That(curvePublisher.InheritMargins, Is.False);
            Assert.That(curvePublisher.CanEditInheritMargins, Is.False);
        }

        [Test]
        public void ShouldLogWarning_On_NonMatchingPublisherTenorPremiums()
        {
            var currentUserId = 10;

            var setting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(11)
                                                                  .Build();

            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveId(101)
                                                                               .WithPriceCurveSetting(setting)
                                                                               .Build();

            var curvePublishers = new[] { curvePublisher };

            var premiums = new ConcurrentDictionary<int, Dictionary<int, PublisherTenorPremium>>();

            premiums.TryAdd(99, new Dictionary<int, PublisherTenorPremium>
                                 {
                                     { 11, new PublisherTenorPremiumTestObjectBuilder().Build() }
                                 });

            var testObjects = new TenorPremiumsGridUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.TenorPremiumsGridUpdateService.UpdateTenorPremiums(curvePublishers, premiums, currentUserId);

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(log => log.Warn(It.IsAny<string>()));

            Assert.That(curvePublisher.PublicationDetails().UserHasPremiums, Is.False);
            Assert.That(curvePublisher.PublicationDetails().PublisherHasPremiums, Is.False);
            Assert.That(curvePublisher.InheritMargins, Is.False);
            Assert.That(curvePublisher.CanEditInheritMargins, Is.False);
        }
    }
}
