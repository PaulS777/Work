﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.Services.GridUpdate;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.GridUpdate
{
    internal interface ICurveSettingsGridUpdateServiceTestObjects
    {
        ICurvePublisherViewModelUpdateService CurvePublisherViewModelUpdateService { get; }
        ILogger Logger { get; }
        CurveSettingsGridUpdateService CurveSettingsGridUpdateService { get; }
    }

    [TestFixture]
    public class CurveSettingsGridUpdateServiceTests
    {
        private class CurveSettingsGridUpdateServiceTestObjectBuilder
        {
            private IEnumerable<User> _usersSnapshot;

            public CurveSettingsGridUpdateServiceTestObjectBuilder WithUsersSnapshot(IEnumerable<User> values)
            {
                _usersSnapshot = values;
                return this;
            }

            public ICurveSettingsGridUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveSettingsGridUpdateServiceTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.Setup(c => c.GetUsersSnapshot())
                                   .Returns(_usersSnapshot);

                var viewModelUpdateService = new Mock<ICurvePublisherViewModelUpdateService>();

                testObjects.SetupGet(o => o.CurvePublisherViewModelUpdateService)
                           .Returns(viewModelUpdateService.Object);

                var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

                var curveSettingsGridUpdateService = new CurveSettingsGridUpdateService(curveControlService.Object,
                                                                                        viewModelUpdateService.Object,
                                                                                        TestMocks.GetLoggerFactory(logger).Object);

                testObjects.SetupGet(o => o.CurveSettingsGridUpdateService)
                           .Returns(curveSettingsGridUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateViewModel_On_MatchingPriceCurveSetting()
        {
            var user = new UserBuilder().WithId(10).User();

            var setting1 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveId(101).Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveId(102).Build();

            var curvePublishers = new[] { curvePublisher1, curvePublisher2 };

            var users = new[] { new UserBuilder().User() };

            var testObjects = new CurveSettingsGridUpdateServiceTestObjectBuilder().WithUsersSnapshot(users).Build();

            var settingUpdate = new[]
                                {
                                    setting1,
                                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(99).Build()
                                };

            // ACT
            testObjects.CurveSettingsGridUpdateService.UpdateCurveSettings(curvePublishers,
                                                                           settingUpdate,
                                                                           user);

            // ASSERT
            Mock.Get(testObjects.CurvePublisherViewModelUpdateService)
                .Verify(c => c.UpdateViewModelFromPriceCurve(curvePublisher1, 10, setting1, It.Is<IList<User>>(u => u.Count == 1)));
        }

        [Test]
        public void ShouldLogWarning_On_NonMatchingPriceCurveSettings()
        {
            var user = new UserBuilder().WithId(10).User();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveId(101).Build();
            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveId(102).Build();

            var curvePublishers = new[] { curvePublisher1, curvePublisher2 };

            var users = new[] { new UserBuilder().User() };

            var testObjects = new CurveSettingsGridUpdateServiceTestObjectBuilder().WithUsersSnapshot(users).Build();


            var settingUpdate = new[]
                                {
                                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(99).Build()
                                };

            // ACT
            testObjects.CurveSettingsGridUpdateService.UpdateCurveSettings(curvePublishers,
                                                                           settingUpdate,
                                                                           user);

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(log => log.Warn(It.IsAny<string>()));

            Mock.Get(testObjects.CurvePublisherViewModelUpdateService)
                .Verify(c => c.UpdateViewModelFromPriceCurve(It.IsAny<CurvePublisherViewModel>(), 
                                                             It.IsAny<int>(), 
                                                             It.IsAny<PriceCurveSetting>(), 
                                                             It.IsAny<IList<User>>()), Times.Never);
        }
    }
}
