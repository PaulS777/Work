﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.AdminActions;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services
{
    internal interface ICurveSettingsUpdateServiceTestObjects
    {
        IAssumeCurveOwnershipActionService AssumeCurveOwnershipActionService { get; }
        ISubject<AdminApiActionCompleted> AssumeCurveOwnershipResponse { get; }
        ISetCurvePublishingControlsActionService SetCurvePublishingControlsActionService { get; }
        ISubject<AdminApiActionCompleted> SetCurvePublishingControlsResponse { get; }
        CurveSettingsUpdateService CurveSettingsUpdateService { get; }
    }

    [TestFixture]
    public class CurveSettingsUpdateServiceTests
    {
        private class CurveSettingsUpdateServiceTestObjectBuilder
        {
            public ICurveSettingsUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveSettingsUpdateServiceTestObjects>();

                var assumeCurveOwnershipResponse = new Subject<AdminApiActionCompleted>();

                testObjects.SetupGet(o => o.AssumeCurveOwnershipResponse)
                           .Returns(assumeCurveOwnershipResponse);

                var assumeCurveOwnershipActionService = new Mock<IAssumeCurveOwnershipActionService>();

                assumeCurveOwnershipActionService.Setup(a => a.Update(It.IsAny<IList<AssumeCurveOwnership>>(), 
                                                                      It.IsAny<IScheduler>()))
                                                 .Returns(assumeCurveOwnershipResponse);

                testObjects.SetupGet(o => o.AssumeCurveOwnershipActionService)
                           .Returns(assumeCurveOwnershipActionService.Object);

                var setCurvePublishingControlsResponse = new Subject<AdminApiActionCompleted>();

                testObjects.SetupGet(o => o.SetCurvePublishingControlsResponse)
                           .Returns(setCurvePublishingControlsResponse);

                var setCurvePublishingControlsActionService = new Mock<ISetCurvePublishingControlsActionService>();

                setCurvePublishingControlsActionService.Setup(a => a.Update(It.IsAny<IList<SetCurvePublishingControls>>(),
                                                                            It.IsAny<IScheduler>()))
                                                       .Returns(setCurvePublishingControlsResponse);

                testObjects.SetupGet(o => o.SetCurvePublishingControlsActionService)
                           .Returns(setCurvePublishingControlsActionService.Object);

                var curveSettingsUpdateService = new CurveSettingsUpdateService(assumeCurveOwnershipActionService.Object,
                                                                                setCurvePublishingControlsActionService.Object,
																				TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.CurveSettingsUpdateService)
                           .Returns(curveSettingsUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAssumeOwnership_When_Update_With_PriceCurvePublisherChanged()
        {
            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(99).Build();

            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                               .WithPriceCurveId(101)
                                                                               .WithPriceCurveSetting(curveSetting)
                                                                               .WithCurrentPublisherId(10)
                                                                               .WithHasChanged(true)
                                                                               .WithPublisherChanged(true)
                                                                               .WithIsExcelSource(true)
                                                                               .WithInheritMargins(true)
                                                                               .WithIsPublishable(true)
                                                                               .WithIsTradeable(true)
                                                                               .Build();

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

            var expected = new [] {new AssumeCurveOwnership(ActionTargetType.PriceCurve, 101, 10, true, true, true, true)};
            
            // ACT
            testObjects.CurveSettingsUpdateService.Update([curvePublisher], Mock.Of<IScheduler>());

            // ASSERT
            Mock.Get(testObjects.AssumeCurveOwnershipActionService)
                .Verify(a => a.Update(It.Is<IList<AssumeCurveOwnership>>(c => c.SequenceEqual(expected, new AssumeCurveOwnershipComparer())),
                                      It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldAssumeOwnership_When_Update_With_FxCurvePublisherChanged()
        {
            var fxCurveSetting1 = new FxCurveSettingTestObjectBuilder().WithPublisherId(99).Build();

            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.FxCurve)
                                                                               .WithFxCurveId(201)
                                                                               .WithFxCurveSetting(fxCurveSetting1)
                                                                               .WithCurrentPublisherId(10)
                                                                               .WithHasChanged(true)
                                                                               .WithPublisherChanged(true)
                                                                               .WithInheritMargins(true)
                                                                               .WithIsPublishable(true)
                                                                               .WithIsTradeable(true)
                                                                               .Build();

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

            var expected = new[] { new AssumeCurveOwnership(ActionTargetType.FxCurve, 201, 10, true, true, true, false) };

            // ACT
            testObjects.CurveSettingsUpdateService.Update([curvePublisher], Mock.Of<IScheduler>());

            // ASSERT
            Mock.Get(testObjects.AssumeCurveOwnershipActionService)
                .Verify(a => a.Update(It.Is<IList<AssumeCurveOwnership>>(c => c.SequenceEqual(expected, new AssumeCurveOwnershipComparer())),
                                      It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldSetCurvePublishingControls_When_Update_With_HasChanged_And_SamePriceCurvePublisher()
        {

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPublisherId(10).Build();

            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                               .WithPriceCurveId(102)
                                                                               .WithPriceCurveSetting(curveSetting)
                                                                               .WithCurrentPublisherId(10)
                                                                               .WithHasChanged(true)
                                                                               .WithPublisherChanged(false)
                                                                               .WithIsExcelSource(true)
                                                                               .WithInheritMargins(true)
                                                                               .WithIsPublishable(true)
                                                                               .WithIsTradeable(true)
                                                                               .Build();

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

            var expected = new[] {new SetCurvePublishingControls(ActionTargetType.PriceCurve, 102, true, true, true)};

            // ACT
            testObjects.CurveSettingsUpdateService.Update([curvePublisher], Mock.Of<IScheduler>());

            // ASSERT
            Mock.Get(testObjects.SetCurvePublishingControlsActionService)
                .Verify(a => a.Update(It.Is<List<SetCurvePublishingControls>>(c => c.SequenceEqual(expected, new SetCurvePublishingControlsComparer())),
                                      It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldSetCurvePublishingControls_When_Update_With_HasChanged_And_SameFxCurvePublisher()
        {
            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithPublisherId(10).Build();

            var curvePublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.FxCurve)
                                                                               .WithFxCurveId(202)
                                                                               .WithFxCurveSetting(fxCurveSetting)
                                                                               .WithCurrentPublisherId(10)
                                                                               .WithHasChanged(true)
                                                                               .WithPublisherChanged(false)
                                                                               .WithInheritMargins(true)
                                                                               .WithIsPublishable(true)
                                                                               .WithIsTradeable(true)
                                                                               .Build();

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

      
            var expected = new[]{ new SetCurvePublishingControls(ActionTargetType.FxCurve, 202, true, true, false)};

            // ACT
            testObjects.CurveSettingsUpdateService.Update([curvePublisher], Mock.Of<IScheduler>());

            // ASSERT
            Mock.Get(testObjects.SetCurvePublishingControlsActionService)
                .Verify(a => a.Update(It.Is<List<SetCurvePublishingControls>>(c => c.SequenceEqual(expected, new SetCurvePublishingControlsComparer())),
                                      It.IsAny<IScheduler>()));
        }

        #region No Changes

        [Test]
        public void ShouldNotSetPublisherControlsAction_When_Update_With_NoSettingsChanged()
        {
            var curveSetting = new PriceCurveSettingTestObjectBuilder().Build();

            var assumeOwner = new CurvePublisherViewModelTestObjectBuilder().WithPriceCurveSetting(curveSetting)
                                                                            .WithCurrentPublisherId(10)
                                                                            .WithHasChanged(true)
                                                                            .WithPublisherChanged(true)
                                                                            .Build();

            var publishers = new[] { assumeOwner };

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.CurveSettingsUpdateService.Update(publishers, Mock.Of<IScheduler>());

            // ASSERT
            Mock.Get(testObjects.AssumeCurveOwnershipActionService)
                .Verify(a => a.Update(It.Is<IList<AssumeCurveOwnership>>(c => c.Count == 1),
                                      It.IsAny<IScheduler>()));

            Mock.Get(testObjects.SetCurvePublishingControlsActionService)
                .Verify(a => a.Update(It.IsAny<IList<SetCurvePublishingControls>>(),
                                      It.IsAny<IScheduler>()), Times.Never);
        }

        #endregion

        #region Assume Parent/Child

        [Test]
        public void ShouldOnlyAssumeOwnershipActionOnParent_When_ParentPublisherChanged()
        {
            var parent = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                       .WithPriceCurveId(101)
                                                                       .WithPublisherChanged(true)
                                                                       .WithHasChanged(true)
                                                                       .Build();

            var child = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                      .WithPriceCurveId(102)
                                                                      .WithIsChild(true)
                                                                      .WithPublisherChanged(true)
                                                                      .WithHasChanged(true)
                                                                      .Build();

            var publishers = new[] { parent, child };

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();
            
            // ACT
            testObjects.CurveSettingsUpdateService.Update(publishers, Mock.Of<IScheduler>());

            // ASSERT
            Mock.Get(testObjects.AssumeCurveOwnershipActionService)
                .Verify(a => a.Update(It.Is<IList<AssumeCurveOwnership>>(c => c.Count == 1 && c[0].PriceCurveId == 101),
                                      It.IsAny<IScheduler>()));

            Mock.Get(testObjects.SetCurvePublishingControlsActionService)
                .Verify(a => a.Update(It.IsAny<IList<SetCurvePublishingControls>>(),
                                      It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldSetCurvePublishingControlsActionOnChildren_When_Update_With_PublisherChangedFalse()
        {
            var parent = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                       .WithPriceCurveId(101)
                                                                       .WithHasChanged(true)
                                                                       .Build();

            var child = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                      .WithPriceCurveId(102)
                                                                      .WithIsChild(true)
                                                                      .WithHasChanged(true)
                                                                      .Build();

            var publishers = new[] { parent, child };

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

            // ACT
            testObjects.CurveSettingsUpdateService.Update(publishers, Mock.Of<IScheduler>());

            // ASSERT
            Mock.Get(testObjects.SetCurvePublishingControlsActionService)
                .Verify(a => a.Update(It.Is<IList<SetCurvePublishingControls>>(c => c.Count == 2),
                                      It.IsAny<IScheduler>()));

            Mock.Get(testObjects.AssumeCurveOwnershipActionService)
                .Verify(a => a.Update(It.IsAny<IList<AssumeCurveOwnership>>(),
                                      It.IsAny<IScheduler>()), Times.Never);
        }

        #endregion

        #region Action Completed

        [Test]
        public void ShouldPublishActionCompleted_On_AssumeOwner_And_PublishingControlsActionCompleted()
        {
            var assumeCurve = new CurvePublisherViewModelTestObjectBuilder().WithCurrentPublisherId(10)
                                                                            .WithHasChanged(true)
                                                                            .WithPublisherChanged(true)
                                                                            .Build();

            var publishingControls = new CurvePublisherViewModelTestObjectBuilder().WithCurrentPublisherId(10)
                                                                                   .WithHasChanged(true)
                                                                                   .WithPublisherChanged(false)
                                                                                   .Build();

            var publishers = new[] { assumeCurve, publishingControls };

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

            AdminApiActionCompleted actionCompleted = null;
            var completed = false;

            using (testObjects.CurveSettingsUpdateService.Update(publishers, Mock.Of<IScheduler>())
                              .Subscribe(value => actionCompleted = value, () => completed = true))
            {
                // ACT
                testObjects.AssumeCurveOwnershipResponse.OnNext(new AdminApiActionCompleted());

                // ASSERT
                Assert.That(actionCompleted, Is.Null);

                // ACT
                testObjects.SetCurvePublishingControlsResponse.OnNext(new AdminApiActionCompleted());

                // ASSERT
                Assert.That(actionCompleted, Is.Not.Null);
                Assert.That(actionCompleted.CompletedWithWarnings, Is.False);
                Assert.That(completed, Is.True);
            }
        }

        [Test]
        public void ShouldPublishUpdateCompleted_When_AssumeOwnerActionCompleted_With_NoPublishingControls()
        {
            var assumeCurve = new CurvePublisherViewModelTestObjectBuilder().WithCurrentPublisherId(10)
                                                                            .WithHasChanged(true)
                                                                            .WithPublisherChanged(true)
                                                                            .Build();

            var publishers = new[] { assumeCurve };

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

			AdminApiActionCompleted actionCompleted = null;
            var completed = false;

			using (testObjects.CurveSettingsUpdateService.Update(publishers, Mock.Of<IScheduler>())
                              .Subscribe(value => actionCompleted = value, () => completed = true))
            {
                // ACT
                testObjects.AssumeCurveOwnershipResponse.OnNext(new AdminApiActionCompleted());

				// ASSERT
				Assert.That(actionCompleted, Is.Not.Null);
                Assert.That(actionCompleted.CompletedWithWarnings, Is.False);
				Assert.That(completed, Is.True);
            }
        }

        [Test]
        public void ShouldPublishUpdateActionCompleted_When_PublishingControlsCompleted_With_No_AssumeOwner()
        {
            var publishingControls = new CurvePublisherViewModelTestObjectBuilder().WithCurrentPublisherId(10)
                                                                                   .WithHasChanged(true)
                                                                                   .WithPublisherChanged(false)
                                                                                   .Build();

            var publishers = new[] { publishingControls };

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

            AdminApiActionCompleted actionCompleted = null;
            var completed = false;

			using (testObjects.CurveSettingsUpdateService.Update(publishers, Mock.Of<IScheduler>())
                              .Subscribe(value => actionCompleted = value, () => completed = true))
            {
                // ACT
                testObjects.SetCurvePublishingControlsResponse.OnNext(new AdminApiActionCompleted());

				// ASSERT
				Assert.That(actionCompleted, Is.Not.Null);
                Assert.That(actionCompleted.CompletedWithWarnings, Is.False);
                Assert.That(completed, Is.True);
			}
        }

		#endregion

		#region Action Completed

		[Test]
		public void ShouldPublishActionCompletedWithWarning_On_UpdatesCompleted_With_CurveOwnershipWaring()
		{
			var assumeCurve = new CurvePublisherViewModelTestObjectBuilder().WithCurrentPublisherId(10)
																			.WithHasChanged(true)
																			.WithPublisherChanged(true)
																			.Build();

			var publishingControls = new CurvePublisherViewModelTestObjectBuilder().WithCurrentPublisherId(10)
																				   .WithHasChanged(true)
																				   .WithPublisherChanged(false)
																				   .Build();

			var publishers = new[] { assumeCurve, publishingControls };

			var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

			AdminApiActionCompleted actionCompleted = null;

			using (testObjects.CurveSettingsUpdateService.Update(publishers, Mock.Of<IScheduler>())
							  .Subscribe(value => actionCompleted = value))
			{
				// ACT
				testObjects.AssumeCurveOwnershipResponse.OnNext(new AdminApiActionCompleted("warning"));

				// ASSERT
				Assert.That(actionCompleted, Is.Null);

				// ACT
				testObjects.SetCurvePublishingControlsResponse.OnNext(new AdminApiActionCompleted());

				// ASSERT
				Assert.That(actionCompleted, Is.Not.Null);
				Assert.That(actionCompleted.CompletedWithWarnings, Is.True);
                Assert.That(actionCompleted.WarningMessage, Is.EqualTo("warning"));
			}
		}


        [Test]
        public void ShouldPublishActionCompletedWithWarning_On_UpdatesCompleted_With_SetCurvePublishingWaring()
        {
            var assumeCurve = new CurvePublisherViewModelTestObjectBuilder().WithCurrentPublisherId(10)
                                                                            .WithHasChanged(true)
                                                                            .WithPublisherChanged(true)
                                                                            .Build();

            var publishingControls = new CurvePublisherViewModelTestObjectBuilder().WithCurrentPublisherId(10)
                                                                                   .WithHasChanged(true)
                                                                                   .WithPublisherChanged(false)
                                                                                   .Build();

            var publishers = new[] { assumeCurve, publishingControls };

            var testObjects = new CurveSettingsUpdateServiceTestObjectBuilder().Build();

            AdminApiActionCompleted actionCompleted = null;

            using (testObjects.CurveSettingsUpdateService.Update(publishers, Mock.Of<IScheduler>())
                              .Subscribe(value => actionCompleted = value))
            {
                // ACT
                testObjects.AssumeCurveOwnershipResponse.OnNext(new AdminApiActionCompleted());

                // ASSERT
                Assert.That(actionCompleted, Is.Null);

                // ACT
                testObjects.SetCurvePublishingControlsResponse.OnNext(new AdminApiActionCompleted("warning"));

                // ASSERT
                Assert.That(actionCompleted, Is.Not.Null);
                Assert.That(actionCompleted.CompletedWithWarnings, Is.True);
                Assert.That(actionCompleted.WarningMessage, Is.EqualTo("warning"));
            }
        }

		#endregion
	}
}
