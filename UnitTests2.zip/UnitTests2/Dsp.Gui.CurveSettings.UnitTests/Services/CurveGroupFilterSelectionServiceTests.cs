﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services
{
    [TestFixture]
    public class CurveGroupFilterSelectionServiceTests
    {
        [Test]
        public void ShouldPublishFilter_When_RefreshFilterItems()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();
            var moGas = new CurveGroupTestObjectBuilder().MoGas();

			var viewModel = Mock.Of<ICurveGroupSelector>();

            var filterItem1 = new SelectableCurveGroupItem(moGas.Name, false, moGas.Id)
            {
                IsSelected = true
            };

            var filterItem2 = new SelectableCurveGroupItem(crude.Name, false, crude.Id)
            {
                IsSelected = true
            };

            var filterItem3 = new SelectableCurveGroupItem(fuelOil.Name, false, fuelOil.Id);

            var filterItems = new List<SelectableCurveGroupItem>
            {
                filterItem1, filterItem2, filterItem3
            };

            var service = new CurveGroupFilterSelectionService();

            var expectedIds = new[] { moGas.Id, crude.Id };

            CurveGroupFilterArgs result = null;

            using (service.Filter.Subscribe(args => result = args))
            {
                // ACT
                service.RefreshFilterItems(viewModel, filterItems);

                // ASSERT
                Assert.That(result.CurveGroupIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("MULTIPLE"));
            }
        }

        [Test]
        public void ShouldSelectAllItems_And_Publish_When_AllCurveGroupsSelected()
        {
            var moGas = new CurveGroupTestObjectBuilder().MoGas();
			var crude = new CurveGroupTestObjectBuilder().Crude();
            
			var viewModel = Mock.Of<ICurveGroupSelector>();

            var filterItem1 = new SelectableCurveGroupItem(moGas.Name, false, moGas.Id);
            var filterItem2 = new SelectableCurveGroupItem(crude.Name, false, crude.Id);

            var filterItems = new List<SelectableCurveGroupItem>
            {
                filterItem1, filterItem2
            };

            var service = new CurveGroupFilterSelectionService();

            var expectedIds = new[] { moGas.Id, crude.Id };

			CurveGroupFilterArgs result = null;

            using (service.Filter.Subscribe(args => result = args))
            {
                service.RefreshFilterItems(viewModel, filterItems);

                // ACT
                Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.AllCurveGroupsSelected, true);

                // ASSERT
                Assert.That(filterItem1.IsSelected, Is.True);
                Assert.That(filterItem2.IsSelected, Is.True);
                Assert.That(result.CurveGroupIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("ALL CURVE GROUPS"));
            }
        }

        [Test]
        public void ShouldDeselectAllItems_And_PublishAllCurveGroups_When_AllCurveGroupsSelectedFalse()
        {
            var moGas = new CurveGroupTestObjectBuilder().MoGas();
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var viewModel = Mock.Of<ICurveGroupSelector>(vm => vm.AllCurveGroupsSelected == true);

            var filterItem1 = new SelectableCurveGroupItem(moGas.Name, false, moGas.Id)
            {
                IsSelected = true
            };

            var filterItem2 = new SelectableCurveGroupItem(crude.Name, false, crude.Id)
            {
                IsSelected = true
            };

            var filterItems = new List<SelectableCurveGroupItem>
            {
                filterItem1, filterItem2
            };

            var service = new CurveGroupFilterSelectionService();

            var expectedIds = new[] { moGas.Id, crude.Id };

			CurveGroupFilterArgs result = null;

            using (service.Filter.Subscribe(args => result = args))
            {
                service.RefreshFilterItems(viewModel, filterItems);

                // ACT
                Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.AllCurveGroupsSelected, false);

                // ASSERT
                Assert.That(filterItem1.IsSelected, Is.False);
                Assert.That(filterItem2.IsSelected, Is.False);
                Assert.That(result.CurveGroupIds.SequenceEqual(expectedIds));
                Assert.That(result.FilterText, Is.EqualTo("ALL CURVE GROUPS"));
            }
        }

        [Test]
        public void ShouldSetAllCurveGroupsSelectedToNull_And_Publish_When_ItemDeselected_With_AllCurveGroupsSelected()
        {
            var moGas = new CurveGroupTestObjectBuilder().MoGas();
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var viewModel = Mock.Of<ICurveGroupSelector>(vm => vm.AllCurveGroupsSelected == true);

            var filterItem1 = new SelectableCurveGroupItem(moGas.Name, false, moGas.Id);
            var filterItem2 = new SelectableCurveGroupItem(crude.Name, false, crude.Id);

            var filterItems = new List<SelectableCurveGroupItem>
            {
                filterItem1, filterItem2
            };

            var service = new CurveGroupFilterSelectionService();

            var expectedIds = new[] { crude.Id };

			CurveGroupFilterArgs result = null;

            using (service.Filter.Subscribe(args => result = args))
            {
                service.RefreshFilterItems(viewModel, filterItems);

                Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.AllCurveGroupsSelected, true);

                // ACT
                filterItem1.IsSelected = false;

                // ASSERT
                Assert.That(filterItem1.IsSelected, Is.False);
                Assert.That(filterItem2.IsSelected, Is.True);
				Assert.That(result.CurveGroupIds.SequenceEqual(expectedIds));
				Assert.That(result.FilterText, Is.EqualTo("Crude"));
            }
        }

        [Test]
        public void ShouldSetAllCurveGroupsSelectedToNull_And_Publish_When_ItemSelected_With_AllCurveGroupsSelectedFalse()
        {
            var moGas = new CurveGroupTestObjectBuilder().MoGas();
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var viewModel = Mock.Of<ICurveGroupSelector>(vm => vm.AllCurveGroupsSelected == false);

            var filterItem1 = new SelectableCurveGroupItem(moGas.Name, false, moGas.Id);
            var filterItem2 = new SelectableCurveGroupItem(crude.Name, false, crude.Id);

            var filterItems = new List<SelectableCurveGroupItem>
            {
                filterItem1, filterItem2
            };

            var service = new CurveGroupFilterSelectionService();

            var expectedIds = new[] { moGas.Id };

			CurveGroupFilterArgs result = null;

            using (service.Filter.Subscribe(args => result = args))
            {
                service.RefreshFilterItems(viewModel, filterItems);

                // ACT
                filterItem1.IsSelected = true;

                // ASSERT
                Assert.That(filterItem1.IsSelected, Is.True);
                Assert.That(filterItem2.IsSelected, Is.False);
				Assert.That(result.CurveGroupIds.SequenceEqual(expectedIds));
				Assert.That(result.FilterText, Is.EqualTo("MOGAS"));
            }
        }
    }
}
