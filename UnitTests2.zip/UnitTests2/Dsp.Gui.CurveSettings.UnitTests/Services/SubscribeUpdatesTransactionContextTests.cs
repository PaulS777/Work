﻿using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services
{
	[TestFixture]
	public class SubscribeUpdatesTransactionContextTests
	{
		[Test]
		public void ShouldSetSubscribeUpdatesFalse_During_TransactionScope_Then_True()
		{
			var viewModel = Mock.Of<ISubscribeUpdates>(vm => vm.SubscribeUpdates == true);

			// ACT
			using (new SubscribeUpdatesTransactionContext(viewModel))
			{
				// ASSERT
				Assert.That(viewModel.SubscribeUpdates, Is.False);
			}

			// ASSERT
			Assert.That(viewModel.SubscribeUpdates, Is.True);
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var viewModel = Mock.Of<ISubscribeUpdates>(vm => vm.SubscribeUpdates == true);

			var context = new SubscribeUpdatesTransactionContext(viewModel);
		
			context.Dispose();
			context.Dispose();

			// ASSERT
			Assert.That(viewModel.SubscribeUpdates, Is.True);
		}
	}
}
