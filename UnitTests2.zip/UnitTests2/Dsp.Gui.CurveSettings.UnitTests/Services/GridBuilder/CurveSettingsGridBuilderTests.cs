﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.Services.GridBuilder;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services.GridBuilder
{
    internal interface ICurveSettingsGridBuilderTestObjects
    {
        ICurvePublisherViewModelProvider CurvePublisherViewModelProvider { get; }
        CurveSettingsGridBuilder CurveSettingsGridBuilderService { get; }
    }

    [TestFixture]
    public class CurveSettingsGridBuilderTests
    {
        private class CurveSettingsGridBuilderTestObjectBuilder
        {
            private IList<CurvePublisherViewModel> _curvePublisherProviderResult = Array.Empty<CurvePublisherViewModel>();
            
            public CurveSettingsGridBuilderTestObjectBuilder WithCurvePublisherProviderResult(IList<CurvePublisherViewModel> values)
            {
                _curvePublisherProviderResult = values;
                return this;
            }

            public ICurveSettingsGridBuilderTestObjects Build()
            {
                var testObjects = new Mock<ICurveSettingsGridBuilderTestObjects>();

                var curvePublisherProvider = new Mock<ICurvePublisherViewModelProvider>();

                curvePublisherProvider.Setup(p => p.GenerateCurvePublisherViewModels(It.IsAny<IList<PriceCurveSetting>>(),
                                                                                     It.IsAny<IList<FxCurveSetting>>(),
                                                                                     It.IsAny<IList<PriceCurveDefinition>>(),
                                                                                     It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>(),
                                                                                     It.IsAny<IList<ManualCurveDefinition<DailyTenor>>>(),
																					 It.IsAny<IList<FxCurveDefinition>>(),
                                                                                     It.IsAny<int>(),
                                                                                     It.IsAny<bool>()))
                                      .Returns(_curvePublisherProviderResult);

                testObjects.SetupGet(o => o.CurvePublisherViewModelProvider)
                           .Returns(curvePublisherProvider.Object);

                var curveSettingsGridBuilder = new CurveSettingsGridBuilder(curvePublisherProvider.Object);

                testObjects.SetupGet(o => o.CurveSettingsGridBuilderService)
                           .Returns(curveSettingsGridBuilder);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInvokeViewModelProvider_When_GetCurvePublishers()
        {
            var fxCurveSettings = new List<FxCurveSetting> { new FxCurveSettingTestObjectBuilder().Build() };
            var priceCurveDefinitions = new List<PriceCurveDefinition> {new PriceCurveDefinitionTestObjectBuilder().Build()};
            var monthlyCurveDefinitions = new List<ManualCurveDefinition<MonthlyTenor>> { new ManualCurveDefinitionBuilder<MonthlyTenor>().Build() };
            var dailyCurveDefinitions = new List<ManualCurveDefinition<DailyTenor>> { new ManualCurveDefinitionBuilder<DailyTenor>().Build() };
			var fxCurveDefinitions = new List<FxCurveDefinition> {new FxCurveDefinitionTestObjectBuilder().Build()};
            var curvePublishers = new List<CurvePublisherViewModel> { new CurvePublisherViewModelTestObjectBuilder().Build() };

            var priceCurveSettings = new List<PriceCurveSetting> { new PriceCurveSettingTestObjectBuilder().Build() };

            var fxCurveGroup = new CurveGroupTestObjectBuilder().FxCurveGroup();

			var testObjects = new CurveSettingsGridBuilderTestObjectBuilder().WithCurvePublisherProviderResult(curvePublishers)
                                                                             .Build();

            var result = testObjects.CurveSettingsGridBuilderService.GetCurvePublishers(priceCurveSettings,
                                                                                        fxCurveSettings,
                                                                                        priceCurveDefinitions,
                                                                                        monthlyCurveDefinitions,
                                                                                        dailyCurveDefinitions,
                                                                                        fxCurveDefinitions,
                                                                                        fxCurveGroup,
                                                                                        true);

            // ASSERT
            Mock.Get(testObjects.CurvePublisherViewModelProvider)
                .Verify(p => p.GenerateCurvePublisherViewModels(priceCurveSettings,
                                                                fxCurveSettings,
                                                                priceCurveDefinitions,
                                                                monthlyCurveDefinitions,
                                                                dailyCurveDefinitions,
                                                                fxCurveDefinitions,
																fxCurveGroup.Id,
                                                                true));
            Assert.That(result.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldSetParentChildCurvePublishers()
        {
            var priceCurveSettings = new List<PriceCurveSetting>{ new PriceCurveSettingTestObjectBuilder().Build() };
			var fxCurveSettings = new List<FxCurveSetting> { new FxCurveSettingTestObjectBuilder().Build() };
            var priceCurveDefinitions = new List<PriceCurveDefinition> { new PriceCurveDefinitionTestObjectBuilder().Build() };
            var fxCurveDefinitions = new List<FxCurveDefinition> { new FxCurveDefinitionTestObjectBuilder().WithQuoteCurrencyId(1).Build() };

            var parentPublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                                .WithPriceCurveId(101)
                                                                                .Build();

            var childPublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                                .WithPriceCurveId(102)
                                                                                .WithParentCurveDefinitionId(101)
                                                                                .Build();

            var childPublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                                .WithPriceCurveId(103)
                                                                                .WithParentCurveDefinitionId(101)
                                                                                .Build();

            var curveSetting4 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(104)
                                                                        .Build();

            var otherPublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                               .WithPriceCurveSetting(curveSetting4)
                                                                               .Build();

            var curvePublishers = new List<CurvePublisherViewModel>
                                  {
                                      parentPublisher,
                                      childPublisher1,
                                      childPublisher2,
                                      otherPublisher
                                  };

			var fxCurveGroup = new CurveGroupTestObjectBuilder().FxCurveGroup();

            var testObjects = new CurveSettingsGridBuilderTestObjectBuilder().WithCurvePublisherProviderResult(curvePublishers)
                                                                             .Build();

			var expectedChildren = new[] { childPublisher1, childPublisher2 };

            // ACT
            var result = testObjects.CurveSettingsGridBuilderService.GetCurvePublishers(priceCurveSettings, 
                                                                                        fxCurveSettings,
                                                                                        priceCurveDefinitions,
                                                                                        [],
                                                                                        [],
                                                                                        fxCurveDefinitions,
                                                                                        fxCurveGroup,
                                                                                        true);

            // ASSERT
            Assert.That(result[0].IsParent, Is.True);
            Assert.That(result[0].IsChild, Is.False);
            Assert.That(result[0].PublicationDetails().Children.SequenceEqual(expectedChildren));

            Assert.That(result[1].IsParent, Is.False);
            Assert.That(result[1].IsChild, Is.True);

            Assert.That(result[2].IsParent, Is.False);
            Assert.That(result[2].IsChild, Is.True);

            Assert.That(result[3].IsParent, Is.False);
            Assert.That(result[3].IsChild, Is.False);
        }

        [Test]
        public void ShouldOrderCurvePublishersByParentChildGroups_FollowedBy_FxCurvePublishers()
        {
            var priceCurveSettings = new List<PriceCurveSetting> { new PriceCurveSettingTestObjectBuilder().Build() };
			var fxCurveSettings = new List<FxCurveSetting> { new FxCurveSettingTestObjectBuilder().Build() };
            var priceCurveDefinitions = new List<PriceCurveDefinition> { new PriceCurveDefinitionTestObjectBuilder().Build() };
            var fxCurveDefinitions = new List<FxCurveDefinition> { new FxCurveDefinitionTestObjectBuilder().WithQuoteCurrencyId(1).Build() };

            var parentPublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                                .WithPriceCurveId(101)
                                                                                .Build();

            var childPublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                                .WithPriceCurveId(102)
                                                                                .WithParentCurveDefinitionId(101)
                                                                                .Build();

            var childPublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                                .WithPriceCurveId(103)
                                                                                .WithParentCurveDefinitionId(101)
                                                                                .Build();

            var curveSetting4 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(104)
                                                                        .Build();

            var otherPublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.PriceCurve)
                                                                               .WithPriceCurveSetting(curveSetting4)
                                                                               .Build();

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().Build();

            var fxPublisher = new CurvePublisherViewModelTestObjectBuilder().WithPublisherType(CurvePublisherType.FxCurve)
                                                                            .WithFxCurveSetting(fxCurveSetting)
                                                                            .Build();

            var curvePublishers = new List<CurvePublisherViewModel>
                                  {
                                      fxPublisher,
                                      childPublisher1,
                                      otherPublisher,
                                      childPublisher2,
                                      parentPublisher
                                  };

            var fxCurveGroup = new CurveGroupTestObjectBuilder().FxCurveGroup();

			var testObjects = new CurveSettingsGridBuilderTestObjectBuilder().WithCurvePublisherProviderResult(curvePublishers)
                                                                             .Build();

            // ACT
            var result = testObjects.CurveSettingsGridBuilderService.GetCurvePublishers(priceCurveSettings,
                                                                                        fxCurveSettings,
                                                                                        priceCurveDefinitions,
                                                                                        [],
                                                                                        [],
                                                                                        fxCurveDefinitions,
                                                                                        fxCurveGroup,
                                                                                        true);
            // ASSERT
            Assert.That(result[0], Is.SameAs(otherPublisher));
            Assert.That(result[1], Is.SameAs(parentPublisher));
            Assert.That(result[2], Is.SameAs(childPublisher1));
            Assert.That(result[3], Is.SameAs(childPublisher2));
            Assert.That(result[4], Is.SameAs(fxPublisher));
        }
    }
}
