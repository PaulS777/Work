﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.Controllers;
using Dsp.Gui.CurveSettings.Services.GridBuilder;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;


namespace Dsp.Gui.CurveSettings.UnitTests.Services.GridBuilder
{
    internal interface ICurvePublisherViewModelProviderTestObjects
    {
        CurvePublisherViewModelProvider CurvePublisherViewModelProvider { get; }
    }

    [TestFixture]
    public class CurvePublisherViewModelProviderTests
    {
        private class CurvePublisherViewModelProviderTestObjectBuilder
        {
            private IPriceCurvePublisherViewModelController _priceCurvePublisherController;
            private IFxCurvePublisherViewModelController _fxCurvePublisherController;

            public CurvePublisherViewModelProviderTestObjectBuilder WithPriceCurvePublisherController(IPriceCurvePublisherViewModelController value)
            {
                _priceCurvePublisherController = value;
                return this;
            }

            public CurvePublisherViewModelProviderTestObjectBuilder WithFxCurvePublisherController(IFxCurvePublisherViewModelController value)
            {
                _fxCurvePublisherController = value;
                return this;
            }

            public ICurvePublisherViewModelProviderTestObjects Build()
            {
                var testObjects = new Mock<ICurvePublisherViewModelProviderTestObjects>();

                var priceCurveViewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>());

                Mock.Get(_priceCurvePublisherController).SetupGet(c => c.ViewModel)
                    .Returns(priceCurveViewModel);

                var fxCurveViewModel = new CurvePublisherViewModel(Mock.Of<IDisposable>());

                Mock.Get(_fxCurvePublisherController).SetupGet(c => c.ViewModel)
                    .Returns(fxCurveViewModel);

                var curvePublisherFactory = new Mock<IServiceFactory<IPriceCurvePublisherViewModelController>>();

                curvePublisherFactory.Setup(f => f.Create())
                                     .Returns(_priceCurvePublisherController);

                var fxCurvePublisherFactory = new Mock<IServiceFactory<IFxCurvePublisherViewModelController>>();

                fxCurvePublisherFactory.Setup(f => f.Create())
                                       .Returns(_fxCurvePublisherController);

                var viewModelProvider = new CurvePublisherViewModelProvider
                {
                    CurvePublisherFactory = curvePublisherFactory.Object,
                    FxCurvePublisherFactory = fxCurvePublisherFactory.Object
                };

                testObjects.SetupGet(o => o.CurvePublisherViewModelProvider)
                           .Returns(viewModelProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGenerateCurvePublisherViewModels_With_PriceCurves_And_FxCurves_With_IsBetaUserTrue()
        {
            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                            .WithParentCurveDefinitionId(100)
                                                                            .Build();

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(201).Build();

            var priceCurveViewModelController = new Mock<IPriceCurvePublisherViewModelController>();
            var fxCurveViewModelController = new Mock<IFxCurvePublisherViewModelController>();

            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fxCurveGroup = new CurveGroupTestObjectBuilder().FxCurveGroup();

            var testObjects = new CurvePublisherViewModelProviderTestObjectBuilder().WithPriceCurvePublisherController(priceCurveViewModelController.Object)
                                                                                    .WithFxCurvePublisherController(fxCurveViewModelController.Object)
                                                                                    .Build();

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("price")
                                                                                  .WithProductCurveGroup(crude)
                                                                                  .Build();

            var fxCurveDefinition = new FxCurveDefinitionTestObjectBuilder().WithId(201)
                                                                            .WithName("fx")
                                                                            .Build();


            // ACT
            var viewModels = testObjects.CurvePublisherViewModelProvider.GenerateCurvePublisherViewModels([priceCurveSetting],
                                                                                                          [fxCurveSetting],
                                                                                                          [priceCurveDefinition],
                                                                                                          [], 
                                                                                                          [], 
                                                                                                          [fxCurveDefinition],
                                                                                                          fxCurveGroup.Id,
                                                                                                          true);

            // ASSERT
            Assert.That(viewModels.Count, Is.EqualTo(2));

            Assert.That(viewModels[0].PublisherType, Is.EqualTo(CurvePublisherType.PriceCurve));
            Assert.That(viewModels[0].PublicationDetails().PriceCurveId, Is.EqualTo(101));
            Assert.That(viewModels[0].PublicationDetails().ParentCurveDefinitionId, Is.EqualTo(100));
            Assert.That(viewModels[0].PublicationDetails().CurveGroupId, Is.EqualTo(crude.Id));
            Assert.That(viewModels[0].PriceCurveName, Is.EqualTo("price"));
            Assert.That(viewModels[0].HasManualInputCurve, Is.False);
            Assert.That(viewModels[0].ShowIsExcelSource, Is.False);

            Assert.That(viewModels[1].PublisherType, Is.EqualTo(CurvePublisherType.FxCurve));
            Assert.That(viewModels[1].PublicationDetails().FxCurveId, Is.EqualTo(201));
            Assert.That(viewModels[1].PublicationDetails().CurveGroupId, Is.EqualTo(fxCurveGroup.Id));
            Assert.That(viewModels[1].PriceCurveName, Is.EqualTo("fx"));
            Assert.That(viewModels[1].HasManualInputCurve, Is.False);
            Assert.That(viewModels[1].ShowIsExcelSource, Is.False);
        }

        [Test]
        public void ShouldShowIsExcelSource_When_PriceCurveDefinition_Matches_MonthlyCurveDefinition_With_IsBetaUserTrue()
        {
            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build();

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(201).Build();

            var priceCurveViewModelController = new Mock<IPriceCurvePublisherViewModelController>();
            var fxCurveViewModelController = new Mock<IFxCurvePublisherViewModelController>();

            var curveGroup = new CurveGroupTestObjectBuilder().Crude();
            var fxCurveGroup = new CurveGroupTestObjectBuilder().FxCurveGroup();

			var testObjects = new CurvePublisherViewModelProviderTestObjectBuilder().WithPriceCurvePublisherController(priceCurveViewModelController.Object)
                                                                                    .WithFxCurvePublisherController(fxCurveViewModelController.Object)
                                                                                    .Build();

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                                  .WithName("price")
                                                                                  .WithProductCurveGroup(curveGroup)
                                                                                  .Build();

            var monthlyCurveDefinition = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(301)
                                                                                         .WithCurveId(101)
                                                                                         .Build();
			// ACT
			var viewModels = testObjects.CurvePublisherViewModelProvider.GenerateCurvePublisherViewModels([priceCurveSetting],
                                                                                                          [fxCurveSetting],
                                                                                                          [priceCurveDefinition],
                                                                                                          [monthlyCurveDefinition],
                                                                                                          [],
                                                                                                          [],
                                                                                                          fxCurveGroup.Id,
                                                                                                          true);

            // ASSERT
            Assert.That(viewModels[0].PublicationDetails().ManualCurveDefinitionId, Is.EqualTo(301));
            Assert.That(viewModels[0].HasManualInputCurve, Is.True);
            Assert.That(viewModels[0].ShowIsExcelSource, Is.True);
        }

		[Test]
		public void ShouldShowIsExcelSource_When_PriceCurveDefinition_Matches_DailyCurveDefinition_With_IsBetaUserTrue()
		{
			var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build();

			var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(201).Build();

			var priceCurveViewModelController = new Mock<IPriceCurvePublisherViewModelController>();
			var fxCurveViewModelController = new Mock<IFxCurvePublisherViewModelController>();

			var curveGroup = new CurveGroupTestObjectBuilder().Crude();
			var fxCurveGroup = new CurveGroupTestObjectBuilder().FxCurveGroup();

			var testObjects = new CurvePublisherViewModelProviderTestObjectBuilder().WithPriceCurvePublisherController(priceCurveViewModelController.Object)
																					.WithFxCurvePublisherController(fxCurveViewModelController.Object)
																					.Build();

			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																				  .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
																				  .WithName("price")
																				  .WithProductCurveGroup(curveGroup)
																				  .Build();

			var dailyCurveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().WithId(302)
                                                                                     .WithCurveId(101)
                                                                                     .Build();

            var dailyCurveDefinitions = new List<ManualCurveDefinition<DailyTenor>> { dailyCurveDefinition };

			// ACT
			var viewModels = testObjects.CurvePublisherViewModelProvider.GenerateCurvePublisherViewModels([priceCurveSetting],
																										  [fxCurveSetting],
																										  [priceCurveDefinition],
                                                                                                          [],
																										  dailyCurveDefinitions,
																										  [],
																										  fxCurveGroup.Id,
																										  true);

			// ASSERT
			Assert.That(viewModels[0].PublicationDetails().ManualCurveDefinitionId, Is.EqualTo(302));
			Assert.That(viewModels[0].HasManualInputCurve, Is.True);
			Assert.That(viewModels[0].ShowIsExcelSource, Is.True);
		}

		[Test]
        public void ShouldHideIsExcelSource_When_PriceCurveDefinition_Matches_ManualCurveDefinition_With_IsBetaUserFalse()
        {
            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build();

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(201).Build();

            var priceCurveViewModelController = new Mock<IPriceCurvePublisherViewModelController>();
            var fxCurveViewModelController = new Mock<IFxCurvePublisherViewModelController>();

			var curveGroup = new CurveGroupTestObjectBuilder().Crude();
            var fxCurveGroup = new CurveGroupTestObjectBuilder().FxCurveGroup();

			var testObjects = new CurvePublisherViewModelProviderTestObjectBuilder().WithPriceCurvePublisherController(priceCurveViewModelController.Object)
                                                                                    .WithFxCurvePublisherController(fxCurveViewModelController.Object)
                                                                                    .Build();

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .WithName("price")
                                                                                  .WithProductCurveGroup(curveGroup)
                                                                                  .Build();

            var manualCurveDefinition = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(301)
                                                                                        .WithCurveId(101)
                                                                                        .Build();


			// ACT
			var viewModels = testObjects.CurvePublisherViewModelProvider.GenerateCurvePublisherViewModels([priceCurveSetting],
                                                                                                          [fxCurveSetting],
                                                                                                          [priceCurveDefinition],
                                                                                                          [manualCurveDefinition],
                                                                                                          [],
                                                                                                          [],
                                                                                                          fxCurveGroup.Id,
                                                                                                          false);

            // ASSERT
            Assert.That(viewModels[0].HasManualInputCurve, Is.True);
            Assert.That(viewModels[0].ShowIsExcelSource, Is.False);
        }

        [Test]
        public void ShouldSkip_Missing_PriceCurveDefinition()
        {
            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).Build();

            var priceCurveViewModelController = new Mock<IPriceCurvePublisherViewModelController>();
            var fxCurveViewModelController = new Mock<IFxCurvePublisherViewModelController>();

            var testObjects = new CurvePublisherViewModelProviderTestObjectBuilder().WithPriceCurvePublisherController(priceCurveViewModelController.Object)
                                                                                    .WithFxCurvePublisherController(fxCurveViewModelController.Object)
                                                                                    .Build();

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(99).Build();

            var fxCurveGroup = new CurveGroupTestObjectBuilder().FxCurveGroup();

			// ACT
			var viewModels = testObjects.CurvePublisherViewModelProvider.GenerateCurvePublisherViewModels([priceCurveSetting],
                                                                                                          [],
                                                                                                          [priceCurveDefinition],
                                                                                                          [],
                                                                                                          [],
                                                                                                          [],
                                                                                                          fxCurveGroup.Id,
                                                                                                          false);

            // ASSERT
            Assert.That(viewModels, Is.Empty);
        }
    }
}
