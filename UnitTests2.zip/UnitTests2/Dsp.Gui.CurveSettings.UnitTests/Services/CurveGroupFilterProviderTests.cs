﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Services
{
    [TestFixture]
    public class CurveGroupFilterProviderTests
    {
        [Test]
        public void ShouldGetGroupFilterItems_From_DistinctProductCurveGroups_And_FxCurveDefinitions()
        {
            var moGas = new CurveGroupTestObjectBuilder().MoGas();
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(moGas)
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(crude)
                                                                         .Build();

            var priceCurve3 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(crude)
                                                                         .Build();

            var fxCurve = new FxCurveDefinitionTestObjectBuilder().Build();

            var priceCurves = new List<PriceCurveDefinition>
            {
                priceCurve1, priceCurve2, priceCurve3
            };

            var fxCurves = new List<FxCurveDefinition> { fxCurve };

            var provider = new CurveGroupFilterProvider();

            // ACT
            var items = provider.GetCurveGroups(priceCurves, 
                                                fxCurves, 
                                                [],
                                                fuelOil);

            // ASSERT
            Assert.That(items.Count, Is.EqualTo(3));

            var item1 = items[0];
            Assert.That(item1.DisplayText, Is.EqualTo(CurveGroupNames.MOGAS));
            Assert.That(item1.IsGroupingItem, Is.False);
            Assert.That(item1.Id, Is.EqualTo(moGas.Id));

            var item2 = items[1];
            Assert.That(item2.DisplayText, Is.EqualTo(CurveGroupNames.Crude));
            Assert.That(item2.IsGroupingItem, Is.False);
            Assert.That(item2.Id, Is.EqualTo(crude.Id));

            var item3 = items[2];
            Assert.That(item3.DisplayText, Is.EqualTo(CurveGroupNames.FuelOil));
            Assert.That(item3.IsGroupingItem, Is.False);
            Assert.That(item3.Id, Is.EqualTo(fuelOil.Id));
        }

        [Test]
        public void ShouldSetIsSelected_On_ExistingSelectedFilterItems()
        {
            var moGas = new CurveGroupTestObjectBuilder().MoGas();
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();
            var fx = new CurveGroupTestObjectBuilder().FxCurveGroup();

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(moGas)
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(crude)
                                                                         .Build();

            var priceCurve3 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(crude)
                                                                         .Build();

            var fxCurve = new FxCurveDefinitionTestObjectBuilder().Build();

            var priceCurves = new List<PriceCurveDefinition>
            {
                priceCurve1, priceCurve2, priceCurve3
            };

            var fxCurves = new List<FxCurveDefinition> { fxCurve };

            var selectedCurveGroupIds = new[] { moGas.Id, fuelOil.Id, fx.Id };

            var provider = new CurveGroupFilterProvider();

            // ACT
            var items = provider.GetCurveGroups(priceCurves,
                                                fxCurves,
                                                selectedCurveGroupIds,
                                                fuelOil);

            // ASSERT
            Assert.That(items[0].IsSelected, Is.True);
            Assert.That(items[1].IsSelected, Is.False);
            Assert.That(items[2].IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetIsSelectedTrue_On_AllFilterItems_When_NoneSelected()
        {
            var moGas = new CurveGroupTestObjectBuilder().MoGas();
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fx = new CurveGroupTestObjectBuilder().FxCurveGroup();

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(moGas)
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(crude)
                                                                         .Build();

            var priceCurve3 = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(crude)
                                                                         .Build();

            var fxCurve = new FxCurveDefinitionTestObjectBuilder().Build();

            var priceCurves = new List<PriceCurveDefinition>
            {
                priceCurve1, priceCurve2, priceCurve3
            };

            var fxCurves = new List<FxCurveDefinition> { fxCurve };

			var provider = new CurveGroupFilterProvider();

            // ACT
            var items = provider.GetCurveGroups(priceCurves,
                                                fxCurves,
                                                [],
                                                fx);

            // ASSERT
            Assert.That(items[0].IsSelected, Is.True);
            Assert.That(items[1].IsSelected, Is.True);
            Assert.That(items[2].IsSelected, Is.True);
        }
    }
}
