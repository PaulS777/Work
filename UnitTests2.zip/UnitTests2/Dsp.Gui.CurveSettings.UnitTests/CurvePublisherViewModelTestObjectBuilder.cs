﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.Gui.CurveSettings.Common;
using Dsp.Gui.CurveSettings.ViewModels;
using Moq;

namespace Dsp.Gui.CurveSettings.UnitTests
{
    public class CurvePublisherViewModelTestObjectBuilder
    {
        private IDisposable _controller;
        private CurvePublisherType _publisherType;
        private int _priceCurveId;
        private int _fxCurveId;
        private int? _parentCurveDefinitionId;
        private string _priceCurveName;
        private PriceCurveSetting _priceCurveSetting;
        private FxCurveSetting _fxCurveSetting;
        private int _curveGroupId;
        private bool _isParent;
        private bool _isChild;
        private List<CurvePublisherViewModel> _children;
        private int _currentPublisherId;
        private bool _publisherChanged;
        private bool _isPublishableChanged;
        private bool _isTradeableChanged;
        private bool _hasChanged;
        private bool _isExcelSource;
        private bool _inheritMargins;
        private bool _isPublishable;
        private bool _isTradeable;
        private bool _canAssume;
        private bool _canEditIsPublishable;
        private bool _canEditIsTradeable;
        private bool _isInFilter;

        public CurvePublisherViewModelTestObjectBuilder WithController(IDisposable value)
        {
            _controller = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithPublisherType(CurvePublisherType value)
        {
            _publisherType = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithPriceCurveId(int value)
        {
            _priceCurveId = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithFxCurveId(int value)
        {
            _fxCurveId = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithParentCurveDefinitionId(int? value)
        {
            _parentCurveDefinitionId = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithPriceCurveName(string value)
        {
            _priceCurveName = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithPriceCurveSetting(PriceCurveSetting value)
        {
            _priceCurveSetting = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithFxCurveSetting(FxCurveSetting value)
        {
            _fxCurveSetting = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithCurveGroupId(int value)
        {
            _curveGroupId = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithIsParent(bool value)
        {
            _isParent = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithIsChild(bool value)
        {
            _isChild = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithPublisherChanged(bool value)
        {
            _publisherChanged = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithHasChanged(bool value)
        {
            _hasChanged = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithCurrentPublisherId(int value)
        {
            _currentPublisherId = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithIsExcelSource(bool value)
        {
            _isExcelSource = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithInheritMargins(bool value)
        {
            _inheritMargins = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithIsPublishable(bool value)
        {
            _isPublishable = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithIsTradeable(bool value)
        {
            _isTradeable = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithCanAssume(bool value)
        {
            _canAssume = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithCanEditIsPublishable(bool value)
        {
            _canEditIsPublishable = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithCanEditIsTradeable(bool value)
        {
            _canEditIsTradeable = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithIsPublishableChanged(bool value)
        {
            _isPublishableChanged = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithIsTradeableChanged(bool value)
        {
            _isTradeableChanged = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithIsInFilter(bool value)
        {
            _isInFilter = value;
            return this;
        }

        public CurvePublisherViewModelTestObjectBuilder WithChildren(List<CurvePublisherViewModel> values)
        {
            _children = values;
            return this;
        }

        public CurvePublisherViewModel Build()
        {
            var controller = _controller ?? Mock.Of<IDisposable>();

            var viewModel = new CurvePublisherViewModel(controller)
                            {
                                PriceCurveName = _priceCurveName,
                                PublisherType = _publisherType,
                                IsParent = _isParent,
                                IsChild = _isChild,
                                PublisherChanged = _publisherChanged,
                                HasChanged = _hasChanged,
                                IsExcelSource = _isExcelSource,
                                InheritMargins = _inheritMargins,
                                IsPublishable = _isPublishable,
                                IsTradeable = _isTradeable,
                                CanAssume = _canAssume,
                                CanEditIsPublishable = _canEditIsPublishable,
                                CanEditIsTradeable = _canEditIsTradeable,
                                IsPublishableChanged = _isPublishableChanged,
                                IsTradeableChanged = _isTradeableChanged,
                                IsInFilter = _isInFilter
            };

            viewModel.PublicationDetails().PriceCurveId = _priceCurveId;
            viewModel.PublicationDetails().FxCurveId = _fxCurveId;
            viewModel.PublicationDetails().ParentCurveDefinitionId = _parentCurveDefinitionId;
            viewModel.PublicationDetails().PriceCurveSetting = _priceCurveSetting;
            viewModel.PublicationDetails().FxCurveSetting = _fxCurveSetting;
            viewModel.PublicationDetails().CurveGroupId = _curveGroupId;
            viewModel.PublicationDetails().CurrentPublisherId = _currentPublisherId;
            viewModel.PublicationDetails().Children = _children;

            return viewModel;
        }
    }
}
