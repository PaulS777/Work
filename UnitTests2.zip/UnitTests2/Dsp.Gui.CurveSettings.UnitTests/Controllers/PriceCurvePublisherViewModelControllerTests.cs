﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.CurveSettings.Controllers;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.Services.Calculators;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.ManualCurve;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Controllers
{
    internal interface IPriceCurvePublisherViewModelControllerTestObjects
    {
        ICurveEditLookupMonitor CurveEditLookupMonitor { get; set; }
        ICurvePublisherViewModelCalculator ViewModelCalculator { get; }
        ICurvePublisherViewModelUpdateService ViewModelUpdateService { get; }
        ISubject<User> CurrentUser { get; }
        ISubject<bool> ObserveCurveEdit { get; }
        PriceCurvePublisherViewModelController Controller { get; }
        CurvePublisherViewModel ViewModel { get; }
    }

    [TestFixture]
    public class PriceCurvePublisherViewModelControllerTests
    {
        private class PriceCurvePublisherViewModelControllerTestObjectBuilder
        {
            private User _currentUser;
            private IList<User> _users;
            private PriceCurveDefinition _priceCurveDefinition;
            private PriceCurveSetting _priceCurveSetting;
            private int? _manualCurveDefinitionId;
            private bool _publisherChanged;
            private bool _isOwnedByCurrentUser;
            private bool _isExcelSource;
            private bool _showIsExcelSource;
            private bool _showInheritMargins;
            private bool _inheritMargins;
            private bool _isPublishable;
            private bool _isTradeable;
            private bool _canEditIsTradeable;
            private bool _isParent;
            private bool _isChild;
            private List<CurvePublisherViewModel> _children;
            private bool _subscribeUpdates;

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithUsers(IList<User> values)
            {
                _users = values;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithPriceCurveDefinition(PriceCurveDefinition value)
            {
                _priceCurveDefinition = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithPriceCurveSetting(PriceCurveSetting value)
            {
                _priceCurveSetting = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithManualCurveDefinitionId(int? value)
            {
                _manualCurveDefinitionId = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithIsParent(bool value)
            {
                _isParent = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithIsChild(bool value)
            {
                _isChild = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithChildren(List<CurvePublisherViewModel> values)
            {
                _children = values;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithPublisherChanged(bool value)
            {
                _publisherChanged = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithIsOwnedByCurrentUser(bool value)
            {
                _isOwnedByCurrentUser = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithIsExcelSource(bool value)
            {
                _isExcelSource = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithShowIsExcelSource(bool value)
            {
                _showIsExcelSource = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithShowInheritMargins(bool value)
            {
                _showInheritMargins = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithInheritMargins(bool value)
            {
                _inheritMargins = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithIsPublishable(bool value)
            {
                _isPublishable = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithIsTradeable(bool value)
            {
                _isTradeable = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithIsCanEditTradeable(bool value)
            {
                _canEditIsTradeable = value;
                return this;
            }

            public PriceCurvePublisherViewModelControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public IPriceCurvePublisherViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IPriceCurvePublisherViewModelControllerTestObjects>();

                var currentUser = new BehaviorSubject<User>(_currentUser);

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(currentUser);

                curveControlService.SetupGet(c => c.CurrentUserSnapshot)
                                   .Returns(_currentUser);

                curveControlService.Setup(c => c.GetUsersSnapshot())
                                   .Returns(_users);

                var observeCurveEdit = new Subject<bool>();

                testObjects.Setup(o => o.ObserveCurveEdit)
                           .Returns(observeCurveEdit);

                var curveEditLookupMonitor = new Mock<ICurveEditLookupMonitor>();

                curveEditLookupMonitor.Setup(m => m.ObserveCurveEdit(It.IsAny<int>()))
                                      .Returns(observeCurveEdit);

                testObjects.SetupGet(o => o.CurveEditLookupMonitor)
                           .Returns(curveEditLookupMonitor.Object);

                var viewModelCalculator = new Mock<ICurvePublisherViewModelCalculator>();

                testObjects.SetupGet(o => o.ViewModelCalculator)
                           .Returns(viewModelCalculator.Object);

                var viewModelUpdateService = new Mock<ICurvePublisherViewModelUpdateService>();

                testObjects.SetupGet(o => o.ViewModelUpdateService)
                           .Returns(viewModelUpdateService.Object);

                var controller = new PriceCurvePublisherViewModelController(curveControlService.Object,
                                                                            curveEditLookupMonitor.Object,
                                                                            viewModelCalculator.Object,
                                                                            Mocks.GetSchedulerProvider().Object);
                
                if (_priceCurveDefinition != null)
                {
                    controller.ViewModel.PublicationDetails().CurveGroupId = _priceCurveDefinition.ProductDefinition.CurveGroup.Id;
                }


                controller.ViewModel.PublicationDetails().PriceCurveSetting = _priceCurveSetting;
                controller.ViewModel.PublicationDetails().IsOwnedByCurrentUser = _isOwnedByCurrentUser;
                controller.ViewModel.PublicationDetails().Children = _children;
                controller.ViewModel.PublicationDetails().ManualCurveDefinitionId = _manualCurveDefinitionId;
                controller.ViewModel.IsParent = _isParent;
                controller.ViewModel.IsChild = _isChild;
                controller.ViewModel.PublisherChanged = _publisherChanged;
                controller.ViewModel.InheritMargins = _inheritMargins;
                controller.ViewModel.ShowInheritMargins = _showInheritMargins;
                controller.ViewModel.IsExcelSource = _isExcelSource;
                controller.ViewModel.ShowIsExcelSource = _showIsExcelSource;
                controller.ViewModel.IsPublishable = _isPublishable;
                controller.ViewModel.IsTradeable = _isTradeable;
                controller.ViewModel.CanEditIsTradeable = _canEditIsTradeable;
                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;
                
                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region SubscribeUpdates

        [Test]
        public void ShouldSetCanUpdateCurveTrue_When_SubscribeUpdates_With_UpdatePermissions()
        {
            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(),
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var users = new List<User> { currentUser };

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .Build();

            var curveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                             .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithUsers(users)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPriceCurveDefinition(curveDefinition)
                                                                                           .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.True);
        }

        [Test]
        public void ShouldSetCanAssumeTrue_When_SubscribeUpdates_With_IsChildFalse_And_OtherUserAsPublisher_And_UpdatePermissions()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), 
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var users = new List<User> { currentUser };

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .Build();

            var curveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                             .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithIsChild(false)
                                                                                           .WithUsers(users)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPriceCurveDefinition(curveDefinition)
                                                                                           .WithIsOwnedByCurrentUser(false)
                                                                                           .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanAssume, Is.True);
        }

        [Test]
        public void ShouldSetCanAssumeTrue_When_SubscribeUpdates_With_IsChildTrue()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), 
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var users = new List<User> { currentUser };

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .Build();

            var curveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                             .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithIsChild(true)
                                                                                           .WithUsers(users)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPriceCurveDefinition(curveDefinition)
                                                                                           .WithIsOwnedByCurrentUser(false)
                                                                                           .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanAssume, Is.False);
        }

        [Test]
        public void ShouldSetCanAssumeFalse_When_SubscribeUpdates_With_CurrentUserAsPublisher()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(),
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var users = new List<User> { currentUser };

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .Build();

            var curveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                             .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithIsChild(false)
                                                                                           .WithUsers(users)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPriceCurveDefinition(curveDefinition)
                                                                                           .WithIsOwnedByCurrentUser(true)
                                                                                           .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanAssume, Is.False);
        }

        [Test]
        public void ShouldObserveCurveEdit_When_SubscribeUpdates_With_ShowIsExcelSourceTrue()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(),
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithUsers([currentUser])
                                                                                           .WithShowIsExcelSource(true)
                                                                                           .WithManualCurveDefinitionId(201)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.CurveEditLookupMonitor)
                .Verify(m => m.ObserveCurveEdit(201));
        }

        [Test]
        public void ShouldNotObserveCurveEdit_When_SubscribeUpdates_With_ShowIsExcelSourceFalse()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(),
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithUsers([currentUser])
                                                                                           .WithShowIsExcelSource(false)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.CurveEditLookupMonitor)
                .Verify(m => m.ObserveCurveEdit(It.IsAny<int>()), Times.Never);
        }

        #endregion

        [Test]
        public void ShouldSetIsManualEditTrue_On_CurveEditTrue()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), 
                                                                                                          true,
                                                                                                          true)])
                                               .User();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithUsers([currentUser])
                                                                                           .WithShowIsExcelSource(true)
                                                                                           .WithManualCurveDefinitionId(201)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ACT
            testObjects.ObserveCurveEdit.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsManualCurveEdit, Is.True);
        }

        [Test]
        public void ShouldDisableEditIsExcelSource_On_CurveEditTrue_With_UserIsPublisher()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(),
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithUsers([currentUser])
                                                                                           .WithShowIsExcelSource(true)
                                                                                           .WithManualCurveDefinitionId(201)
                                                                                           .WithIsOwnedByCurrentUser(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ACT
            testObjects.ObserveCurveEdit.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditIsExcelSource, Is.False);
        }

        [Test]
        public void ShouldEnableEditIsExcelSource_On_CurveEditFalse_With_UserIsPublisher()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(),
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithUsers([currentUser])
                                                                                           .WithShowIsExcelSource(true)
                                                                                           .WithManualCurveDefinitionId(201)
                                                                                           .WithIsOwnedByCurrentUser(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ARRANGE
            testObjects.ObserveCurveEdit.OnNext(true);

            // ACT
            testObjects.ObserveCurveEdit.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditIsExcelSource, Is.True);
        }

        [Test]
        public void ShouldNotEnableEditIsExcelSource_On_CurveEditFalse_With_UserIsNotPublisher()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), 
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithUsers([currentUser])
                                                                                           .WithShowIsExcelSource(true)
                                                                                           .WithManualCurveDefinitionId(201)
                                                                                           .WithIsOwnedByCurrentUser(false)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ACT
            testObjects.ObserveCurveEdit.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditIsExcelSource, Is.False);
        }

        [Test]
        public void ShouldEnableAssumeCommand_When_CanAssumeTrue()
        {
            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.CanAssume = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.AssumeCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldNotCalculate_When_SubscribeUpdatesFalse()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .WithIsPublishable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            testObjects.ViewModel.SubscribeUpdates = false;
            Mock.Get(testObjects.ViewModelCalculator).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsPublishable = true;

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnIsPublishableChanged(testObjects.ViewModel, It.IsAny<bool>()), Times.Never);
        }

        [Test]
        public void ShouldDisableAssumeCommand_When_CanAssumeFalse()
        {
            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.CanAssume = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.AssumeCommand.CanExecute(), Is.False);
        }


        [Test]
        public void ShouldSetCanUpdateCurveFalse_On_UserUpdate_With_ReadonlyPermissions()
        {
			var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), 
                                                                                                          true, 
                                                                                                          true)])
                                               .User();

            var userUpdate = new UserBuilder().WithId(10)
                                              .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(),
                                                                                                         true,
                                                                                                         false)])
                                              .User();

            var users = new List<User> { currentUser };

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .Build();

            var curveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                             .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithUsers(users)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPriceCurveDefinition(curveDefinition)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ACT
            testObjects.CurrentUser.OnNext(userUpdate);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.False);
        }

        [Test]
        public void ShouldAssumeChildren_And_InheritIsPublishableIsTradeable_On_AssumeParent()
        {
			var user = new UserBuilder().User();

			var child = new CurvePublisherViewModelTestObjectBuilder().Build();

            var children = new List<CurvePublisherViewModel> { child };

            var curveSettings = new PriceCurveSettingTestObjectBuilder().Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(user)
																						   .WithIsParent(true)
                                                                                           .WithIsPublishable(true)
                                                                                           .WithIsTradeable(true)
                                                                                           .WithChildren(children)
                                                                                           .WithPriceCurveSetting(curveSettings)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ACT
            testObjects.ViewModel.AssumeCommand.Execute();

			// ASSERT
			Mock.Get(testObjects.ViewModelCalculator)
				.Verify(c => c.CalculateOnAssumePriceCurve(testObjects.ViewModel, user));

			Assert.That(testObjects.ViewModel.ShowInheritMargins, Is.False);
			Assert.That(child.IsPublishable, Is.True);
            Assert.That(child.IsTradeable, Is.True);
        }

        [Test]
        public void ShouldUpdateChildren_When_ParentIsPublishableChanged_With_PublisherChangedTrue()
        {
            var curveSetting = new PriceCurveSettingTestObjectBuilder().Build();

            var child = new CurvePublisherViewModelTestObjectBuilder().Build();

            var children = new List<CurvePublisherViewModel> { child };

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithIsParent(true)
                                                                                           .WithChildren(children)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPublisherChanged(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.IsPublishable = true;

            // ASSERT
            Assert.That(child.IsPublishable, Is.True);
        }

        [Test]
        public void ShouldNotUpdateChildren_When_ParentIsPublishableChanged_With_PublisherChangedFalse()
        {
            var curveSetting = new PriceCurveSettingTestObjectBuilder().Build();

            var child = new CurvePublisherViewModelTestObjectBuilder().Build();

            var children = new List<CurvePublisherViewModel> { child };

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithIsParent(true)
                                                                                           .WithChildren(children)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPublisherChanged(false)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.IsPublishable = true;

            // ASSERT
            Assert.That(child.IsPublishable, Is.False);
        }

        [Test]
        public void ShouldUpdateChildren_When_ParentIsTradeableChanged_With_PublisherChangedTrue()
        {
            var curveSetting = new PriceCurveSettingTestObjectBuilder().Build();

            var child = new CurvePublisherViewModelTestObjectBuilder().Build();

            var children = new List<CurvePublisherViewModel> { child };

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithIsParent(true)
                                                                                           .WithChildren(children)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPublisherChanged(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.IsTradeable = true;

            // ASSERT
            Assert.That(child.IsTradeable, Is.True);
        }

        [Test]
        public void ShouldNotUpdateChildren_When_ParentIsTradeableChanged_With_PublisherChangedFalse()
        {
            var curveSetting = new PriceCurveSettingTestObjectBuilder().Build();

            var child = new CurvePublisherViewModelTestObjectBuilder().Build();

            var children = new List<CurvePublisherViewModel> { child };

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithIsParent(true)
                                                                                           .WithChildren(children)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithPublisherChanged(false)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.IsTradeable = true;

            // ASSERT
            Assert.That(child.IsTradeable, Is.False);
        }

        #region Inherit Margins

        [Test]
        public void ShouldCalculate_And_ShowInheritMargins_On_Assume()
        {
            var currentUser = new UserBuilder().User();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithIsOwnedByCurrentUser(true)
                                                                                           .WithPublisherChanged(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.AssumeCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnAssumePriceCurve(testObjects.ViewModel, currentUser));

            Assert.That(testObjects.ViewModel.ShowInheritMargins, Is.True);
        }

        [Test]
        public void Should_HideInheritMargins_On_PublisherChangedFalse()
        {
            var currentUser = new UserBuilder().User();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithIsOwnedByCurrentUser(true)
                                                                                           .WithPublisherChanged(true)
                                                                                           .WithShowInheritMargins(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.PublisherChanged = false;

            // ASSERT

            Assert.That(testObjects.ViewModel.ShowInheritMargins, Is.False);
        }

        #endregion

        #region Inherit Margins - IsTradeable Toggle

        [Test]
        public void ShouldSetIsTradeableFalse_And_DisableToggle_When_InheritMarginsFalse()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsTradeable(true)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithShowInheritMargins(true)
                                                                                           .WithInheritMargins(true)
                                                                                           .WithIsTradeable(true)
                                                                                           .WithIsCanEditTradeable(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ACT
            testObjects.ViewModel.InheritMargins = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsTradeable, Is.False);
            Assert.That(testObjects.ViewModel.CanEditIsTradeable, Is.False);
        }

        [Test]
        public void ShouldEnableIsTradeableToggle_And_Not_ResetIsTradeableTrue_When_InheritMarginsTrue()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsTradeable(true)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithShowInheritMargins(true)
                                                                                           .WithInheritMargins(true)
                                                                                           .WithIsTradeable(true)
                                                                                           .WithIsCanEditTradeable(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            testObjects.ViewModel.InheritMargins = false;

            // ACT
            testObjects.ViewModel.InheritMargins = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsTradeable, Is.False);
            Assert.That(testObjects.ViewModel.CanEditIsTradeable, Is.True);
        }

        #endregion

        #region Calculate Changes

        [Test]
        public void ShouldSetIsExcelSourceChangedFalse_On_IsExcelSourceFalse()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsExcelSource(true)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithIsExcelSource(true)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.IsExcelSource = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsExcelSourceChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedTrue_On_IsPublisherChanged()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsTradeable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.PublisherChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedTrue_On_IsExcelSourceChanged()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsTradeable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.IsExcelSourceChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldCalculate_When_IsPublishableChanged()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .WithIsPublishable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ACT
            testObjects.ViewModel.IsPublishable = true;

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnIsPublishableChanged(testObjects.ViewModel, false));
        }

        [Test]
        public void ShouldCalculate_When_IsTradeableChanged()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsTradeable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();
            // ACT
            testObjects.ViewModel.IsTradeable = true;

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnIsTradeableChanged(testObjects.ViewModel, false));
        }

        [Test]
        public void ShouldSetHasChangedTrue_On_IsTradeableChanged()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsTradeable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.IsTradeableChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedTrue_On_IsPublishableChanged()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsTradeable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            // ACT
            testObjects.ViewModel.IsPublishableChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedFalse_On_IsTradeableChangedFalse()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .WithIsTradeable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            testObjects.ViewModel.IsTradeableChanged = true;

            // ACT
            testObjects.ViewModel.IsTradeableChanged = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
        }

        #endregion

        [Test]
        public void ShouldNotCalculate_When_Disposed()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .WithIsPublishable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            testObjects.Controller.Dispose();
            Mock.Get(testObjects.ViewModelCalculator).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsPublishable = true;

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnIsPublishableChanged(testObjects.ViewModel, It.IsAny<bool>()), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var currentUser = new UserBuilder().User();

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(11)
                                                                       .WithIsPublishable(false)
                                                                       .Build();

            var testObjects = new PriceCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                           .WithPriceCurveSetting(curveSetting)
                                                                                           .WithSubscribeUpdates(true)
                                                                                           .Build();

            testObjects.Controller.Dispose();
            Mock.Get(testObjects.ViewModelCalculator).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.IsPublishable = true;

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnIsPublishableChanged(testObjects.ViewModel, It.IsAny<bool>()), Times.Never);
        }
    }
}
