﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.CurveSettings.Controllers;
using Dsp.Gui.CurveSettings.Services;
using Dsp.Gui.CurveSettings.Services.Collection;
using Dsp.Gui.CurveSettings.Services.DataSource;
using Dsp.Gui.CurveSettings.Services.Filter;
using Dsp.Gui.CurveSettings.Services.GridBuilder;
using Dsp.Gui.CurveSettings.Services.GridUpdate;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using DynamicData;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Controllers
{
    internal interface ICurveSettingsViewModelControllerTestObjects
    {
        ICurvePublisherDataSource DataSource { get; }
        ISubject<IChangeSet<CurvePublisherViewModel>> DataSourceConnect { get; }
        ISubject<IList<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        ISubject<IList<ManualCurveDefinition<MonthlyTenor>>> ManualCurveDefinitions { get; }
        ISubject<IList<FxCurveDefinition>> FxCurveDefinitions { get; }
        ISubject<List<CurveGroup>> CurveGroups { get; }
		ICurveSettingsGridBuilder CurveSettingsGridBuilder { get; }
        ICurveSettingsGridRefreshService CurveSettingsGridRefreshService { get; }
        ISubject<CurveSettingsGridRefreshArgs> CurveSettingsGridRefresh { get; }
        ICurveSettingsGridUpdateService CurveSettingsGridUpdateService { get; }
        IFxCurveSettingsGridUpdateService FxCurveSettingsGridUpdateService { get; }
        ITenorPremiumsGridUpdateService TenorPremiumsGridUpdateService { get; }
        IPublisherSettingsChangedService PublisherSettingsChangedService { get; }
        IPublisherBorderBrushService PublisherBorderBrushService { get; }
        IIsPublishableBorderBrushService IsPublishableBorderBrushService { get; }
        IIsTradeableBorderBrushService IsTradeableBorderBrushService { get; }
        ICurveControlService CurveControlService { get; }
        IPriceCurveSettingsProvider PriceCurveSettingsProvider { get; }
        ICurveGroupFilterProvider CurveGroupFilterProvider { get; }
        ICurveGroupFilterSelectionService CurveGroupFilterSelectionService { get; }
        ICurveSettingsUpdateService CurveSettingsUpdateService { get; }
        ISubject<AdminApiActionCompleted> CurveSettingsUpdateResponse { get; }
		IPublisherFilterService PublisherFilterService { get; }
		IFilterSubscriptionsService FilterSubscriptionsService { get; }
        IDisposable FilterSubscriptions { get; }
		ICompositeDisposableEnvelope GridRefreshSubscriptions { get; }
		IPublicationControlsToolBarService ToolBarService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        ISubject<List<FxCurveSetting>> FxCurveSettings { get; }
        ISubject<Unit> UndoPublicationControlChanges { get; }
        ISubject<Unit> UpdatePublicationControlChanges { get; }
        IUndoChangesService UndoChangesService { get; }
        CurveSettingsViewModelController Controller { get; }
        CurveSettingsViewModel ViewModel { get; }
    }

    [TestFixture]
    public class CurveSettingsViewModelControllerTests
    {
        private class CurveSettingsViewModelControllerTestObjectBuilder
        {
            private Dictionary<int, PriceCurveSetting> _priceCurveSettings;
            private IList<PriceCurveDefinition> _priceCurveDefinitions;
            private IList<ManualCurveDefinition<MonthlyTenor>> _monthlyCurveDefinitions;
            private List<ManualCurveDefinition<DailyTenor>> _dailyCurveDefinitions;
			private IList<FxCurveDefinition> _fxCurveDefinitions;
            private List<CurveGroup> _curveGroups;
            private List<FxCurveSetting> _fxCurveSettings;
            private List<User> _users;
            private User _currentUser;
            private List<CurvePublisherViewModel> _curvePublisherViewModels;
            private List<SelectableCurveGroupItem>  _curveGroupFilterProviderResult = [];
            private List<SelectableCurveGroupItem> _viewModelCurveGroups = [];
            private List<ISelectableUserItem> _filteredPublishers = [];
            private List<CurvePublisherViewModel> _dataSourceItems = [];
			private bool? _allCurveGroupsSelected;
            private bool _hasChanged;
            private bool _canEditFilter;
            private bool _isBetaUser;

			public CurveSettingsViewModelControllerTestObjectBuilder WithHasChanged(bool value)
            {
                _hasChanged = value;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithCanEditFilter(bool value)
            {
                _canEditFilter = value;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithPriceCurveSettings(Dictionary<int, PriceCurveSetting> values)
            {
                _priceCurveSettings = values;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithPriceCurveDefinitions(IList<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithMonthlyCurveDefinitions(IList<ManualCurveDefinition<MonthlyTenor>> values)
            {
                _monthlyCurveDefinitions = values;
                return this;
            }

			public CurveSettingsViewModelControllerTestObjectBuilder WithDailyCurveDefinitions(List<ManualCurveDefinition<DailyTenor>> values)
            {
                _dailyCurveDefinitions = values;
                return this;
            }

			public CurveSettingsViewModelControllerTestObjectBuilder WithCurveGroups(List<CurveGroup> values)
            {
                _curveGroups = values;
                return this;
            }

			public CurveSettingsViewModelControllerTestObjectBuilder WithFxCurveDefinitions(IList<FxCurveDefinition> values)
            {
                _fxCurveDefinitions = values;
                return this;
            }

			public CurveSettingsViewModelControllerTestObjectBuilder WithFxCurveSettings(List<FxCurveSetting> values)
            {
                _fxCurveSettings = values;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithUsers(List<User> values)
            {
                _users = values;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithCurvePublisherViewModels(List<CurvePublisherViewModel> values)
            {
                _curvePublisherViewModels = values;
                return this;
            }
			public CurveSettingsViewModelControllerTestObjectBuilder WithFilteredPublishers(IEnumerable<ISelectableUserItem> values)
            {
                _filteredPublishers = values.ToList();
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithCurveGroupFilterProviderResult(List<SelectableCurveGroupItem> values)
            {
                _curveGroupFilterProviderResult = values;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithViewModelCurveGroups(List<SelectableCurveGroupItem> values)
            {
                _viewModelCurveGroups = values;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithDataSourceItems(IList<CurvePublisherViewModel> values)
            {
                _dataSourceItems = [..values];
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithAllCurveGroupsSelected(bool? value)
            {
                _allCurveGroupsSelected = value;
                return this;
            }

            public CurveSettingsViewModelControllerTestObjectBuilder WithIsBetaUser(bool value)
            {
                _isBetaUser = value;
                return this;
            }

            public ICurveSettingsViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<ICurveSettingsViewModelControllerTestObjects>();

                var curveGroups = new BehaviorSubject<List<CurveGroup>>(_curveGroups);

                testObjects.SetupGet(o => o.CurveGroups)
                           .Returns(curveGroups);

                var priceCurveDefinitions = new BehaviorSubject<IList<PriceCurveDefinition>>(_priceCurveDefinitions);

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurveDefinitions);

                var manualCurveDefinitions = new BehaviorSubject<IList<ManualCurveDefinition<MonthlyTenor>>>(_monthlyCurveDefinitions);

                testObjects.SetupGet(o => o.ManualCurveDefinitions)
                           .Returns(manualCurveDefinitions);

                var dailyCurveDefinitions = new BehaviorSubject<List<ManualCurveDefinition<DailyTenor>>>(_dailyCurveDefinitions);

				var fxCurveDefinitions = new BehaviorSubject<IList<FxCurveDefinition>>(_fxCurveDefinitions);

                testObjects.SetupGet(o => o.FxCurveDefinitions)
                           .Returns(fxCurveDefinitions);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.PriceCurveDefinitions)
                                   .Returns(priceCurveDefinitions);

                curveControlService.SetupGet(c => c.PriceCurveDefinitions)
                                   .Returns(priceCurveDefinitions);

                curveControlService.SetupGet(c => c.ManualCurveDefinitions)
                                   .Returns(manualCurveDefinitions);

                curveControlService.SetupGet(c => c.DailyOverrides)
                                   .Returns(dailyCurveDefinitions);

                curveControlService.SetupGet(c => c.FxCurveDefinitions)
                                   .Returns(fxCurveDefinitions);

                curveControlService.SetupGet(c => c.CurveGroups)
                                   .Returns(curveGroups);

                curveControlService.SetupGet(c => c.Users)
                                   .Returns(Observable.Return(_users));

                curveControlService.Setup(c => c.GetUsersSnapshot())
                                   .Returns(_users);

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(Observable.Return(_currentUser));

                curveControlService.SetupGet(c => c.CurrentUserSnapshot)
                                   .Returns(_currentUser);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService.Object);

				var curveSettingsGridBuilder = new Mock<ICurveSettingsGridBuilder>();

                curveSettingsGridBuilder.Setup(b => b.GetCurvePublishers(It.IsAny<IList<PriceCurveSetting>>(),
                                                                         It.IsAny<IList<FxCurveSetting>>(),
                                                                         It.IsAny<IList<PriceCurveDefinition>>(),
                                                                         It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>(),
                                                                         It.IsAny<IList<ManualCurveDefinition<DailyTenor>>>(),
																		 It.IsAny<IList<FxCurveDefinition>>(),
                                                                         It.IsAny<CurveGroup>(),
                                                                         It.IsAny<bool>()))
                                        .Returns(_curvePublisherViewModels);

                testObjects.SetupGet(o => o.CurveSettingsGridBuilder)
                           .Returns(curveSettingsGridBuilder.Object);

                var dataSourceConnect = new Subject<IChangeSet<CurvePublisherViewModel>>();

                testObjects.SetupGet(o => o.DataSourceConnect)
                           .Returns(dataSourceConnect);

                var dataSource = new Mock<ICurvePublisherDataSource>();

                dataSource.Setup(d => d.Connect(It.IsAny<Func<CurvePublisherViewModel, bool>>()))
                          .Returns(dataSourceConnect);

                dataSource.Setup(d => d.Items())
                          .Returns(_dataSourceItems);

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var publisherSettingsChangedService = new Mock<IPublisherSettingsChangedService>();

                testObjects.SetupGet(o => o.PublisherSettingsChangedService)
                           .Returns(publisherSettingsChangedService.Object);

                var publisherBorderBrushService = new Mock<IPublisherBorderBrushService>();

                testObjects.SetupGet(o => o.PublisherBorderBrushService)
                           .Returns(publisherBorderBrushService.Object);

                var isPublishableBorderBrushService = new Mock<IIsPublishableBorderBrushService>();

                testObjects.SetupGet(o => o.IsPublishableBorderBrushService)
                           .Returns(isPublishableBorderBrushService.Object);

                var isTradeableBorderBrushService = new Mock<IIsTradeableBorderBrushService>();

                testObjects.SetupGet(o => o.IsTradeableBorderBrushService)
                           .Returns(isTradeableBorderBrushService.Object);

                var priceCurveSettings = new BehaviorSubject<Dictionary<int, PriceCurveSetting>>(_priceCurveSettings);

                testObjects.SetupGet(o => o.PriceCurveSettings)
                           .Returns(priceCurveSettings);

                var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();

                priceCurveSettingsProvider.SetupGet(p => p.PriceCurveSettings)
                                          .Returns(priceCurveSettings);

                testObjects.SetupGet(o => o.PriceCurveSettingsProvider)
                           .Returns(priceCurveSettingsProvider.Object);

                var fxCurveSettings = new BehaviorSubject<List<FxCurveSetting>>(_fxCurveSettings);

                testObjects.SetupGet(o => o.FxCurveSettings)
                           .Returns(fxCurveSettings);

                var fxCurveSettingsProvider = new Mock<IFxCurveSettingsProvider>();

                fxCurveSettingsProvider.SetupGet(fx => fx.FxCurveSettings)
                                       .Returns(fxCurveSettings);

                var updateResponse = new Subject<AdminApiActionCompleted>();

                testObjects.SetupGet(o => o.CurveSettingsUpdateResponse)
                           .Returns(updateResponse);

                var curveSettingsUpdateService = new Mock<ICurveSettingsUpdateService>();

                curveSettingsUpdateService.Setup(u => u.Update(It.IsAny<IList<CurvePublisherViewModel>>(), It.IsAny<IScheduler>()))
                                          .Returns(updateResponse);

                testObjects.SetupGet(o => o.CurveSettingsUpdateService)
                           .Returns(curveSettingsUpdateService.Object);

                var curveGroupFilterProvider = new Mock<ICurveGroupFilterProvider>();

                curveGroupFilterProvider.Setup(p => p.GetCurveGroups(It.IsAny<IList<PriceCurveDefinition>>(),
                                                                     It.IsAny<IList<FxCurveDefinition>>(), 
                                                                     It.IsAny<IList<int>>(),
                                                                     It.IsAny<CurveGroup>()))
                                        .Returns(_curveGroupFilterProviderResult);

                testObjects.Setup(o => o.CurveGroupFilterProvider)
                           .Returns(curveGroupFilterProvider.Object);

                var curveGroupFilterSelectionService = new Mock<ICurveGroupFilterSelectionService>();

                testObjects.SetupGet(o => o.CurveGroupFilterSelectionService)
                           .Returns(curveGroupFilterSelectionService.Object);

                var publisherFilterService = new Mock<IPublisherFilterService>();

                publisherFilterService.Setup(f => f.GetPublishers(It.IsAny<IList<int>>(), 
                                                                  It.IsAny<IList<User>>(),
                                                                  It.IsAny<User>()))
                                      .Returns(_filteredPublishers);

                testObjects.SetupGet(o => o.PublisherFilterService)
                           .Returns(publisherFilterService.Object);

                var filterSubscriptions = Disposable.Empty;

                testObjects.SetupGet(o => o.FilterSubscriptions)
                           .Returns(filterSubscriptions);

                var filterSubscriptionsService = new Mock<IFilterSubscriptionsService>();

                filterSubscriptionsService.SetupGet(f => f.CurveGroupFilter)
                                          .Returns(curveGroupFilterSelectionService.Object);

                filterSubscriptionsService.SetupGet(f => f.PublisherFilter)
                                          .Returns(publisherFilterService.Object);

                filterSubscriptionsService.Setup(f => f.SubscribeFilters(It.IsAny<IEnumerable<CurvePublisherViewModel>>()))
                                          .Returns(filterSubscriptions);

                testObjects.SetupGet(o => o.FilterSubscriptionsService)
                           .Returns(filterSubscriptionsService.Object);


                var undoPublicationControlChanges = new Subject<Unit>();

                testObjects.SetupGet(o => o.UndoPublicationControlChanges)
                           .Returns(undoPublicationControlChanges);

                var updatePublicationControlChanges = new Subject<Unit>();

                testObjects.SetupGet(o => o.UpdatePublicationControlChanges)
                           .Returns(updatePublicationControlChanges);

                var toolBarService = new Mock<IPublicationControlsToolBarService>();
                
                toolBarService.SetupGet(o => o.UndoPublicationControlChanges)
                              .Returns(undoPublicationControlChanges);

                toolBarService.SetupGet(o => o.UpdatePublicationControlChanges)
                              .Returns(updatePublicationControlChanges);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBarService.Object);

                var popupService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var curveSettingsGridRefresh = new Subject<CurveSettingsGridRefreshArgs>();

                testObjects.SetupGet(o => o.CurveSettingsGridRefresh)
                           .Returns(curveSettingsGridRefresh);

                var gridRefreshService = new Mock<ICurveSettingsGridRefreshService>();

                gridRefreshService.Setup(r => r.CurveSettingsGridRefresh())
                                  .Returns(curveSettingsGridRefresh);

                testObjects.SetupGet(o => o.CurveSettingsGridRefreshService)
                           .Returns(gridRefreshService.Object);

                var curveSettingsGridUpdateService = new Mock<ICurveSettingsGridUpdateService>();

                testObjects.SetupGet(o => o.CurveSettingsGridUpdateService)
                           .Returns(curveSettingsGridUpdateService.Object);

                var fxCurveSettingsGridUpdateService = new Mock<IFxCurveSettingsGridUpdateService>();

                testObjects.SetupGet(o => o.FxCurveSettingsGridUpdateService)
                           .Returns(fxCurveSettingsGridUpdateService.Object);

                var tenorPremiumsGridUpdateService = new Mock<ITenorPremiumsGridUpdateService>();

                testObjects.SetupGet(o => o.TenorPremiumsGridUpdateService)
                           .Returns(tenorPremiumsGridUpdateService.Object);

                var undoChangesService = new Mock<IUndoChangesService>();

                testObjects.SetupGet(o => o.UndoChangesService)
                           .Returns(undoChangesService.Object);

                var isBetaUser = new BehaviorSubject<bool>(_isBetaUser);

                var betaUserService = new Mock<IBetaUserService>();

                betaUserService.SetupGet(b => b.IsBetaUser)
                               .Returns(isBetaUser);

                var gridRefreshSubscriptions = new Mock<ICompositeDisposableEnvelope>();

                testObjects.SetupGet(o => o.GridRefreshSubscriptions)
                           .Returns(gridRefreshSubscriptions.Object);

                var controller = new CurveSettingsViewModelController(curveControlService.Object,
                                                                      dataSource.Object,
                                                                      filterSubscriptionsService.Object,
                                                                      gridRefreshService.Object,
                                                                      publisherSettingsChangedService.Object,
                                                                      publisherBorderBrushService.Object,
                                                                      isPublishableBorderBrushService.Object,
                                                                      isTradeableBorderBrushService.Object,
                                                                      priceCurveSettingsProvider.Object, 
                                                                      fxCurveSettingsProvider.Object,
                                                                      curveGroupFilterProvider.Object,
                                                                      toolBarService.Object, 
                                                                      betaUserService.Object,
                                                                      Mocks.GetSchedulerProvider().Object, 
                                                                      Mocks.GetLoggerFactory().Object)
                {
                    GridBuilder = curveSettingsGridBuilder.Object,
                    CurveSettingsGridUpdateService = curveSettingsGridUpdateService.Object,
                    FxCurveSettingsGridUpdateService = fxCurveSettingsGridUpdateService.Object,
                    TenorPremiumsGridUpdateService = tenorPremiumsGridUpdateService.Object,
                    CurveSettingsUpdateService = curveSettingsUpdateService.Object,
                    UndoChangesService = undoChangesService.Object,
                    GridRefreshSubscriptions = gridRefreshSubscriptions.Object,
                    PopupNotificationService = popupService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object
                };

                controller.ViewModel.CurveGroups = _viewModelCurveGroups;
                controller.ViewModel.AllCurveGroupsSelected = _allCurveGroupsSelected;
                controller.ViewModel.HasChanges = _hasChanged;
                controller.ViewModel.CanEditFilter = _canEditFilter;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region ctor

        [Test]
        public void ShouldAttachServices()
        {
            // ACT
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.FilterSubscriptionsService)
                .Verify(f => f.Attach(testObjects.ViewModel));

            Mock.Get(testObjects.PublisherSettingsChangedService)
                .Verify(p => p.Attach(testObjects.ViewModel));
		}

        #endregion

		#region Initialize

		[Test]
        public void ShouldShowBusyIndicator_On_Initialize()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);
        }

		[Test]
        public void ShouldSubscribeToolBar_On_Initialize()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.UpdatePublicationControlChanges);

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.UndoPublicationControlChanges);
		}

        [Test]
        public void ShouldNotSubscribeToolBar_When_AlreadyInitialized()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.UpdatePublicationControlChanges, Times.Once);
        }

        [Test]
        public void ShouldBuildCurveGroupFilter_On_Initialized_With_CurveDefinitions_And_CurveGroups()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

            var fxCurveDefinition1 = new FxCurveDefinitionTestObjectBuilder().WithQuoteCurrencyId(1).Build();
            var fxCurveDefinition2 = new FxCurveDefinitionTestObjectBuilder().WithQuoteCurrencyId(2).Build();

			var fxCurve = new CurveGroupTestObjectBuilder().FxCurveGroup();
            var curveGroupItem = new SelectableCurveGroupItem("Item", false, 1);

            var priceCurveDefinitions = new[] { priceCurveDefinition };
            var fxCurveDefinitions = new[] { fxCurveDefinition1, fxCurveDefinition2 };
            var curveGroupItems = new List<SelectableCurveGroupItem>{ curveGroupItem };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurveDefinitions)
                                                                                     .WithFxCurveDefinitions(fxCurveDefinitions)
                                                                                     .WithCurveGroups([fxCurve])
                                                                                     .WithCurveGroupFilterProviderResult(curveGroupItems)
																					 .Build();

            var expectedFxCurveDefinitions = new[] { fxCurveDefinition1 };

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.CurveGroupFilterProvider)
                .Verify(p => p.GetCurveGroups(priceCurveDefinitions,
                                              It.Is<IList<FxCurveDefinition>>(fx => fx.SequenceEqual(expectedFxCurveDefinitions)),
                                              It.Is<IList<int>>(i => i.Count == 0),
                                              fxCurve));

            Mock.Get(testObjects.CurveGroupFilterSelectionService)
                .Verify(f => f.RefreshFilterItems(testObjects.ViewModel,
                                                  testObjects.ViewModel.CurveGroups));

            Assert.That(testObjects.ViewModel.CurveGroups, Is.SameAs(curveGroupItems));
		}

        [Test]
        public void ShouldBuildPublisherFilter_On_Initialized_With_CurveSettings_And_Users()
        {
			var priceCurveSettings
                = new Dictionary<int, PriceCurveSetting>
                  {
                      {
                          101,
                          new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101).WithPublisherId(10).Build()
                      }
                  };

            var fxCurveSettings = new List<FxCurveSetting> { new(301, 11, 1, true, true) };

            var user = new UserBuilder().User();
            var users = new List<User> { user };
            var publishers = new[] { Mock.Of<ISelectableUserItem>() };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithPriceCurveSettings(priceCurveSettings)
                                                                                     .WithFxCurveSettings(fxCurveSettings)
                                                                                     .WithUsers(users)
                                                                                     .WithCurrentUser(user)
                                                                                     .WithFilteredPublishers(publishers)
                                                                                     .Build();

            var expectedCurveSettingIds = new[] { 10, 11 };

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

			// ASSERT
            Mock.Get(testObjects.PublisherFilterService)
                .Verify(f => f.GetPublishers(It.Is<IList<int>>(ids => ids.SequenceEqual(expectedCurveSettingIds)),
                                             It.Is<IList<User>>(u => u.Count == 1),
                                             user));

			Assert.That(testObjects.ViewModel.Publishers.Count, Is.EqualTo(1));
		}

        [Test]
        public void ShouldBuildCurveSettingsGrid_And_SetIsBusyFalse_On_Initialized_With_CurveSettings_And_CurveDefinitions_And_CurveGroups_And_Users()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();
            var monthlyCurveDefinition = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithCurveId(101).Build();
            var dailyCurveDefinition = new ManualCurveDefinitionBuilder<DailyTenor>().WithCurveId(102).Build();
            var fxCurveDefinition = new FxCurveDefinitionTestObjectBuilder().WithQuoteCurrencyId(1).Build();
            var fxCurve = new CurveGroupTestObjectBuilder().FxCurveGroup();
            var curveGroupItem = new SelectableCurveGroupItem("Item", false, 1);

			var priceCurveDefinitions = new[] { priceCurveDefinition };
            var fxCurveDefinitions = new[] { fxCurveDefinition };
            var monthlyCurveDefinitions = new[] { monthlyCurveDefinition };
            var dailyCurveDefinitions = new List<ManualCurveDefinition<DailyTenor>>{ dailyCurveDefinition };


            var curveGroupItems = new List<SelectableCurveGroupItem> { curveGroupItem };
            var priceCurveSetting = new PriceCurveSettingTestObjectBuilder().Build();

            var priceCurveSettings = new Dictionary<int, PriceCurveSetting> { { 101, priceCurveSetting } };
            var fxCurveSettings = new List<FxCurveSetting> { new(301, 11, 1, true, true) };

            var user = new UserBuilder().User();
            var users = new List<User> { user };
            var curvePublisher = new CurvePublisherViewModel(Mock.Of<IDisposable>());
            var curvePublishers = new List<CurvePublisherViewModel> { curvePublisher };

            var expectedPriceCurveSettings = new[] { priceCurveSetting };

			var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurveDefinitions)
                                                                                     .WithMonthlyCurveDefinitions(monthlyCurveDefinitions)
                                                                                     .WithDailyCurveDefinitions(dailyCurveDefinitions)
                                                                                     .WithFxCurveDefinitions(fxCurveDefinitions)
                                                                                     .WithCurveGroups([fxCurve])
                                                                                     .WithViewModelCurveGroups(curveGroupItems)
                                                                                     .WithFxCurveDefinitions(fxCurveDefinitions)
                                                                                     .WithPriceCurveSettings(priceCurveSettings)
                                                                                     .WithFxCurveSettings(fxCurveSettings)
                                                                                     .WithCurveGroups([fxCurve])
                                                                                     .WithUsers(users)
                                                                                     .WithCurrentUser(user)
                                                                                     .WithCurvePublisherViewModels(curvePublishers)
                                                                                     .WithIsBetaUser(true)
																					 .Build();
            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

			// ASSERT
			Mock.Get(testObjects.CurveSettingsGridBuilder)
                .Verify(b => b.GetCurvePublishers(expectedPriceCurveSettings,
                                                  fxCurveSettings, 
                                                  priceCurveDefinitions,
                                                  monthlyCurveDefinitions,
                                                  dailyCurveDefinitions,
												  fxCurveDefinitions, 
                                                  fxCurve, 
                                                  true));

            Mock.Get(testObjects.DataSource)
                .Verify(d => d.InitializeDataSource(curvePublishers));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        [Test]
        public void ShouldSetIsBetaUserTrue_When_UserIsBetaUser()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithIsBetaUser(true)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBetaUser, Is.True);
        }

        #endregion

        #region CurveGroupFilter

        [Test]
        public void ShouldSetAllCurveGroupsSelectedTrue_When_BuildFilter_With_Null_And_AllCurveGroupsSelected()
        {
            var fxCurve = new CurveGroupTestObjectBuilder().FxCurveGroup();

            var curveGroupItems = new List<SelectableCurveGroupItem>
                                  {
									  new("Item", false, 1){IsSelected = true},
                                      new("Item", false, 2){IsSelected = true}
								  };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions([])
                                                                                     .WithFxCurveDefinitions([])
                                                                                     .WithCurveGroups([fxCurve])
                                                                                     .WithCurveGroupFilterProviderResult(curveGroupItems)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.AllCurveGroupsSelected, Is.True);
		}

        [Test]
        public void ShouldNotSetAllCurveGroupsSelected_When_BuildFilter_With_Null_And_NotAllCurveGroupsSelected()
        {
            var fxCurve = new CurveGroupTestObjectBuilder().FxCurveGroup();

            var curveGroupItems = new List<SelectableCurveGroupItem>
                                  {
                                      new("Item", false, 1){IsSelected = false},
                                      new("Item", false, 2){IsSelected = true}
                                  };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions([])
                                                                                     .WithFxCurveDefinitions([])
                                                                                     .WithCurveGroups([fxCurve])
                                                                                     .WithCurveGroupFilterProviderResult(curveGroupItems)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.AllCurveGroupsSelected, Is.Null);
        }

        [Test]
        public void ShouldNotSetAllCurveGroupsSelected_When_BuildFilter_With_False_And_AllCurveGroupsSelected()
        {
            var fxCurve = new CurveGroupTestObjectBuilder().FxCurveGroup();

            var curveGroupItems = new List<SelectableCurveGroupItem>
                                  {
                                      new("Item", false, 1){IsSelected = true},
                                      new("Item", false, 2){IsSelected = true}
                                  };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions([])
                                                                                     .WithFxCurveDefinitions([])
                                                                                     .WithCurveGroups([fxCurve])
                                                                                     .WithCurveGroupFilterProviderResult(curveGroupItems)
                                                                                     .WithAllCurveGroupsSelected(false)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.AllCurveGroupsSelected, Is.False);
        }

        #endregion

        #region Build CurveSettings Grid - GridRefresh

        [Test]
        public void ShouldRefreshSubscriptions_And_UpdateGrid_On_GridRefresh_With_RefreshArgsPopulated()
        {
			var fxCurve = new CurveGroupTestObjectBuilder().FxCurveGroup();
			var user = new UserBuilder().WithId(10).User();
			var users = new List<User> { user };
            var dataSourceItems = new[] { new CurvePublisherViewModel(Mock.Of<IDisposable>()) };

			var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions([])
																					 .WithMonthlyCurveDefinitions([])
                                                                                     .WithDailyCurveDefinitions([])
																					 .WithFxCurveDefinitions([])
																					 .WithCurveGroups([fxCurve])
																					 .WithFxCurveDefinitions([])
																					 .WithPriceCurveSettings([])
																					 .WithFxCurveSettings([])
																					 .WithUsers(users)
																					 .WithCurrentUser(user)
																					 .WithCurvePublisherViewModels([])
                                                                                     .WithDataSourceItems(dataSourceItems)
																					 .Build();

            var curveSettings = new[] { new PriceCurveSettingTestObjectBuilder().Build() };
            var fxCurveSettings = new[] { new FxCurveSettingTestObjectBuilder().Build() };
            var tenorPremiums = new Dictionary<int, Dictionary<int, PublisherTenorPremium>>();

            var refreshArgs = new CurveSettingsGridRefreshArgs(curveSettings, fxCurveSettings, tenorPremiums);

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.CurveSettingsGridRefresh.OnNext(refreshArgs);

            // ASSERT 
            Mock.Get(testObjects.GridRefreshSubscriptions)
                .Verify(r => r.ResetSubscriptions());

            Mock.Get(testObjects.PublisherSettingsChangedService)
                .Verify(d => d.UnsubscribeUpdates());

            Mock.Get(testObjects.PublisherBorderBrushService)
                .Verify(d => d.UnsubscribeUpdates());

            Mock.Get(testObjects.IsPublishableBorderBrushService)
                .Verify(d => d.UnsubscribeUpdates());

            Mock.Get(testObjects.IsTradeableBorderBrushService)
                .Verify(d => d.UnsubscribeUpdates());

            Mock.Get(testObjects.CurveSettingsGridUpdateService)
                .Verify(g => g.UpdateCurveSettings(It.Is<IList<CurvePublisherViewModel>>(cp => cp.SequenceEqual(dataSourceItems)), curveSettings, user));

            Mock.Get(testObjects.FxCurveSettingsGridUpdateService)
                .Verify(g => g.UpdateFxCurveSettings(It.Is<IList<CurvePublisherViewModel>>(cp => cp.SequenceEqual(dataSourceItems)), fxCurveSettings, user));

            Mock.Get(testObjects.TenorPremiumsGridUpdateService)
                .Verify(g => g.UpdateTenorPremiums(It.Is<IList<CurvePublisherViewModel>>(cp => cp.SequenceEqual(dataSourceItems)), tenorPremiums, 10));

            Mock.Get(testObjects.FilterSubscriptionsService)
                .Verify(f => f.SubscribeFilters(It.Is<IList<CurvePublisherViewModel>>(cp => cp.SequenceEqual(dataSourceItems))));

            Mock.Get(testObjects.PublisherSettingsChangedService)
                .Verify(d => d.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.PublisherBorderBrushService)
                .Verify(d => d.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.IsPublishableBorderBrushService)
                .Verify(d => d.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.IsTradeableBorderBrushService)
                .Verify(d => d.SubscribeUpdates(testObjects.DataSourceConnect));

            Mock.Get(testObjects.GridRefreshSubscriptions)
                .Verify(s => s.AddSubscription(testObjects.FilterSubscriptions));
        }

		#endregion

        #region ToolBar Commands

        [Test]
        public void ShouldEnableToolBarCommands_And_DisableFilters_On_HasChangedTrue()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithHasChanged(false)
                                                                                     .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.HasChanges = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditFilter, Is.False);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetHasChanges(true));
        }

        [Test]
        public void ShouldDisableToolBarCommands_And_EnableFilters_On_HasChangedTrue()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithHasChanged(true)
                                                                                     .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.HasChanges = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditFilter, Is.True);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetHasChanges(false));
        }

        [Test]
        public void ShouldUndoChanges_On_ToolBarUndoChanges()
        {
            var user = new UserBuilder().WithId(10).User();
            var other = new UserBuilder().User();

            var users = new List<User> { user, other };
                
            var controller1 = new Mock<IDisposable>();
            var controller2 = new Mock<IDisposable>();

            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithController(controller1.Object)
                                                                                .Build();

            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithController(controller2.Object)
                                                                                .WithHasChanged(true)
                                                                                .Build();
            
            var publisherViewModels = new[] { curvePublisher1, curvePublisher2 };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithCurrentUser(user)
                                                                                     .WithUsers(users)
                                                                                     .WithDataSourceItems(publisherViewModels)
                                                                                     .WithCanEditFilter(false)
                                                                                     .WithHasChanged(true)
                                                                                     .Build();

            var expected = new[] { curvePublisher2 };

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.UndoPublicationControlChanges.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.UndoChangesService)
                .Verify(s => s.UndoChanges(It.Is<IList<CurvePublisherViewModel>>(cp => cp.SequenceEqual(expected)), 
                                           10,
                                           It.Is<IList<User>>(u => u.SequenceEqual(users))));

            Assert.That(testObjects.ViewModel.HasChanges, Is.False);
        }

        #endregion

        [Test]
        public void ShouldDisplayPublishPopupOnCommand()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.ShowPublishAllPopupCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPublishAllPopup, Is.True);
        }

        [Test]
        public void ShouldSetIsPublishableTrue_OnFilteredUserRows_AndHidePopup_OnCommandPublishAllCommand()
        {
            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(true)
                                                                                .WithCanEditIsPublishable(true)
                                                                                .Build();

            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(true)
                                                                                .WithCanEditIsPublishable(false)
                                                                                .Build();

            var curvePublisher3 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(false)
                                                                                .WithCanEditIsPublishable(true)
                                                                                .Build();

            var dataSourceItems = new[]
                                  {
                                      curvePublisher1, curvePublisher2, curvePublisher3
                                  };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithDataSourceItems(dataSourceItems)
                                                                                     .Build();

            testObjects.ViewModel.ShowPublishAllPopupCommand.Execute();

            // ACT
            testObjects.ViewModel.PublishAllCommand.Execute();

            // ASSERT

            Assert.That(curvePublisher1.IsPublishable, Is.True);
            Assert.That(curvePublisher2.IsPublishable, Is.False);
            Assert.That(curvePublisher3.IsPublishable, Is.False);

            Assert.That(testObjects.ViewModel.ShowPublishAllPopup, Is.False);
        }

        [Test]
        public void ShouldSetIsPublishableFalse_OnFilteredUserRows_AndHidePopup_OnCommandPublishNoneCommand()
        {
            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(true)
                                                                                .WithCanEditIsPublishable(true)
                                                                                .WithIsPublishable(true)
                                                                                .Build();

            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(true)
                                                                                .WithCanEditIsPublishable(false)
                                                                                .WithIsPublishable(true)
                                                                                .Build();

            var curvePublisher3 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(false)
                                                                                .WithCanEditIsPublishable(true)
                                                                                .WithIsPublishable(true)
                                                                                .Build();

            var dataSourceItems = new[]
                                  {
                                      curvePublisher1, curvePublisher2, curvePublisher3
                                  };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithDataSourceItems(dataSourceItems)
                                                                                     .Build();

            testObjects.ViewModel.ShowPublishAllPopupCommand.Execute();

            // ACT
            testObjects.ViewModel.PublishNoneCommand.Execute();

            // ASSERT

            Assert.That(curvePublisher1.IsPublishable, Is.False);
            Assert.That(curvePublisher2.IsPublishable, Is.True);
            Assert.That(curvePublisher3.IsPublishable, Is.True);

            Assert.That(testObjects.ViewModel.ShowPublishAllPopup, Is.False);
        }

        [Test]
        public void ShouldDisplayTradeAllPopupOnCommand()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.ShowTradeAllPopupCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowTradeAllPopup, Is.True);
        }

        [Test]
        public void ShouldSetFilteredPublisherRowsToIsTradeableTrue_On_TradeAllCommand()
        {
            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(true)
                                                                                .WithCanEditIsTradeable(true)
                                                                                .Build();

            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(false)
                                                                                .WithCanEditIsTradeable(true)
                                                                                .Build();

            var curvePublisher3 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(true)
                                                                                .WithCanEditIsTradeable(false)
                                                                                .Build();

            var dataSourceItems = new[]
                                  {
                                      curvePublisher1, curvePublisher2, curvePublisher3
                                  };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithDataSourceItems(dataSourceItems)
                                                                                     .Build();

            testObjects.ViewModel.ShowTradeAllPopupCommand.Execute();

            // ACT
            testObjects.ViewModel.TradeAllCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowTradeAllPopup, Is.False);

            Assert.That(curvePublisher1.IsTradeable, Is.True);
            Assert.That(curvePublisher2.IsTradeable, Is.False);
            Assert.That(curvePublisher3.IsTradeable, Is.False);
        }

        [Test]
        public void ShouldSetFilteredPublisherRowsToIsTradeableFalse_On_TradeNoneCommand()
        {
            var curvePublisher1 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(true)
                                                                                .WithCanEditIsTradeable(true)
                                                                                .WithIsTradeable(true)
                                                                                .Build();

            var curvePublisher2 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(false)
                                                                                .WithCanEditIsTradeable(true)
                                                                                .WithIsTradeable(true)
                                                                                .Build();

            var curvePublisher3 = new CurvePublisherViewModelTestObjectBuilder().WithIsInFilter(true)
                                                                                .WithCanEditIsTradeable(false)
                                                                                .WithIsTradeable(true)
                                                                                .Build();

            var dataSourceItems = new[]
                                  {
                                      curvePublisher1, curvePublisher2, curvePublisher3
                                  };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithDataSourceItems(dataSourceItems)
                                                                                     .Build();

            testObjects.ViewModel.ShowTradeAllPopupCommand.Execute();

            // ACT
            testObjects.ViewModel.TradeNoneCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowTradeAllPopup, Is.False);

            Assert.That(curvePublisher1.IsTradeable, Is.False);
            Assert.That(curvePublisher2.IsTradeable, Is.True);
            Assert.That(curvePublisher3.IsTradeable, Is.True);
        }

        [Test]
        public void ShouldInvokeUpdatePublisherSettings_On_ToolBarUpdatePublicationChanges()
        {
            var currentUser = new UserBuilder().WithId(10).User();

            var changed = new CurvePublisherViewModelTestObjectBuilder().WithHasChanged(true).Build();
            var notChanged = new CurvePublisherViewModelTestObjectBuilder().Build();

            var dataSourceItems = new[] { changed, notChanged };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithDataSourceItems(dataSourceItems)
                                                                                     .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.UpdatePublicationControlChanges.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);

            var expectedSequence = new[] { changed };

            Mock.Get(testObjects.CurveSettingsUpdateService)
                .Verify(u => u.Update(It.Is<List<CurvePublisherViewModel>>(p => p.SequenceEqual(expectedSequence)), 
                                      It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldNotInvokeUpdatePublisherSettings_On_ToolBarUpdatePublicationChanges_With_NoChanges()
        {
            var currentUser = new UserBuilder().WithId(10).User();

            var notChanged = new CurvePublisherViewModelTestObjectBuilder().Build();

            var dataSourceItems = new[] { notChanged };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithDataSourceItems(dataSourceItems)
                                                                                     .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.UpdatePublicationControlChanges.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);


            Mock.Get(testObjects.CurveSettingsUpdateService)
                .Verify(u => u.Update(It.IsAny<List<CurvePublisherViewModel>>(),
                                      It.IsAny<IScheduler>()), 
                        Times.Never);
        }

        [Test]
        public void ShouldSendPopupNotification_When_CurveSettingsUpdateCompleted()
        {
            var currentUser = new UserBuilder().WithId(10).User();

            var changed = new CurvePublisherViewModelTestObjectBuilder().WithHasChanged(true).Build();

            var dataSourceItems = new[] { changed };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithDataSourceItems(dataSourceItems)
                                                                                     .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.UpdatePublicationControlChanges.OnNext(Unit.Default);

            // ACT
            testObjects.CurveSettingsUpdateResponse.OnNext(new AdminApiActionCompleted());

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        [Test]
        public void ShouldShowMessageDialog_When_CurveSettingsUpdateWarning()
        {
            var currentUser = new UserBuilder().WithId(10).User();

            var changed = new CurvePublisherViewModelTestObjectBuilder().WithHasChanged(true).Build();

            var dataSourceItems = new[] { changed };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithDataSourceItems(dataSourceItems)
                                                                                     .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.UpdatePublicationControlChanges.OnNext(Unit.Default);

            // ACT
            testObjects.CurveSettingsUpdateResponse.OnNext(new AdminApiActionCompleted("warning"));

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "warning"
                                                                                && args.ShowSendFeedback)));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        [Test]
        public void ShouldShowMessageDialog_On_CurveSettingsUpdateError()
        {
            var currentUser = new UserBuilder().WithId(10).User();

            var changed = new CurvePublisherViewModelTestObjectBuilder().WithHasChanged(true).Build();

            var dataSourceItems = new[] { changed };

            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithDataSourceItems(dataSourceItems)
                                                                                     .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.UpdatePublicationControlChanges.OnNext(Unit.Default);

            // ACT
            testObjects.CurveSettingsUpdateResponse.OnError(new Exception("error"));

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "error"
                                                                        && args.ShowSendFeedback)));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.PublisherSettingsChangedService)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.PublisherBorderBrushService)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.IsPublishableBorderBrushService)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.IsTradeableBorderBrushService)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.GridRefreshSubscriptions)
                .Verify(g => g.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new CurveSettingsViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

			// ASSERT
			Mock.Get(testObjects.GridRefreshSubscriptions)
			    .Verify(g => g.Dispose(), Times.Once);
        }
    }
}
