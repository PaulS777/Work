﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.CurveSettings.Controllers;
using Dsp.Gui.CurveSettings.Services.Calculators;
using Dsp.Gui.CurveSettings.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.CurveSettings.UnitTests.Controllers
{
    internal interface IFxCurvePublisherViewModelControllerTestObjects
    {
        ICurvePublisherViewModelCalculator ViewModelCalculator { get; }
        ISubject<User> CurrentUser { get; }
        FxCurvePublisherViewModelController Controller { get; }
        CurvePublisherViewModel ViewModel { get; }
    }

    [TestFixture]
    public class FxCurvePublisherViewModelControllerTests
    {
        private class FxCurvePublisherViewModelControllerTestObjectBuilder
        {
            private User _currentUser;
            private IList<User> _users;
            private FxCurveSetting _fxCurveSetting;
            private bool _isOwnedByCurrentUser;
            private bool _subscribeUpdates;

            public FxCurvePublisherViewModelControllerTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

            public FxCurvePublisherViewModelControllerTestObjectBuilder WithUsers(IList<User> values)
            {
                _users = values;
                return this;
            }

            public FxCurvePublisherViewModelControllerTestObjectBuilder WithFxCurveSetting(FxCurveSetting value)
            {
                _fxCurveSetting = value;
                return this;
            }

            public FxCurvePublisherViewModelControllerTestObjectBuilder WithIsOwnedByCurrentUser(bool value)
            {
                _isOwnedByCurrentUser = value;
                return this;
            }

            public FxCurvePublisherViewModelControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public IFxCurvePublisherViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IFxCurvePublisherViewModelControllerTestObjects>();

                var currentUser = new BehaviorSubject<User>(_currentUser);

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(currentUser);

                curveControlService.SetupGet(c => c.CurrentUserSnapshot)
                                   .Returns(_currentUser);

                curveControlService.Setup(c => c.GetUsersSnapshot())
                                   .Returns(_users);

                var viewModelCalculator = new Mock<ICurvePublisherViewModelCalculator>();

                testObjects.SetupGet(o => o.ViewModelCalculator)
                           .Returns(viewModelCalculator.Object);

                var controller = new FxCurvePublisherViewModelController(curveControlService.Object,
                                                                         viewModelCalculator.Object,
                                                                         TestMocks.GetSchedulerProvider().Object);

                controller.ViewModel.PublicationDetails().FxCurveSetting = _fxCurveSetting;
                controller.ViewModel.PublicationDetails().IsOwnedByCurrentUser = _isOwnedByCurrentUser;
                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetCanUpdateCurveTrue_When_SubscribeUpdates_With_UpdatePermissions()
        {
            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationFxCurve(new[] {new AuthorisationFxCurve(101, true, true)})
                                               .User();

            var users = new List<User> { currentUser };

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(101).WithPublisherId(11).Build();
            
            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithUsers(users)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.True);
        }

        [Test]
        public void ShouldSetCanAssumeTrue_When_SubscribeUpdates_With_OtherUserAsPublisher_And_UpdatePermissions()
        {
            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationFxCurve(new[] { new AuthorisationFxCurve(101, true, true) })
                                               .User();

            var users = new List<User> { currentUser };

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(101).WithPublisherId(11).Build();

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithUsers(users)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithIsOwnedByCurrentUser(false)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanAssume, Is.True);
        }

        [Test]
        public void ShouldSetCanAssumeFalse_When_SubscribeUpdates_With_CurrentUserAsPublisher()
        {
            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationFxCurve(new[] { new AuthorisationFxCurve(101, true, true) })
                                               .User();

            var users = new List<User> { currentUser };

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(101).WithPublisherId(10).Build();

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithUsers(users)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithIsOwnedByCurrentUser(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CanAssume, Is.False);
        }

        [Test]
        public void ShouldEnableAssumeCommand_When_CanAssumeTrue()
        {
            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.CanAssume = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.AssumeCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldNotCalculateHasChanged_When_Changed_With_SubscribeUpdatesFalse()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();

            testObjects.ViewModel.SubscribeUpdates = false;

            // ACT
            testObjects.ViewModel.IsPublishableChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldDisableAssumeCommand_When_CanAssumeFalse()
        {
            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.CanAssume = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.AssumeCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldSetCanUpdateCurveFalse_On_UserUpdate_With_ReadonlyPermissions()
        {
            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorizationFxCurve([new AuthorisationFxCurve(101,
                                                                                                   true,
                                                                                                   true)])
                                               .User();

            var userUpdate = new UserBuilder().WithId(10)
                                              .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(),
                                                                                                         true, 
                                                                                                         false)])
                                              .User();

            var users = new List<User> { currentUser };

            var fxCurveSetting = new FxCurveSettingTestObjectBuilder().WithFxCurveDefinitionId(101).WithPublisherId(11).Build();

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithUsers(users)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.CurrentUser.OnNext(userUpdate);

            // ASSERT
            Assert.That(testObjects.ViewModel.CanUpdateCurve, Is.False);
        }

        [Test]
        public void ShouldCalculate_On_AssumeCommand()
        {
            var currentUser = new UserBuilder().User();

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.AssumeCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnAssumeFxCurve(testObjects.ViewModel, currentUser));
        }

        [Test]
        public void ShouldCalculate_When_IsPublishableChanged()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 11, 1.0, false, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.IsPublishable = true;

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnIsPublishableChanged(testObjects.ViewModel, false));
        }

        [Test]
        public void ShouldCalculate_When_IsTradeableChanged()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.IsTradeable = true;

            // ASSERT
            Mock.Get(testObjects.ViewModelCalculator)
                .Verify(c => c.CalculateOnIsTradeableChanged(testObjects.ViewModel, false));
        }

        [Test]
        public void ShouldSetHasChangedTrueWhen_PublisherChanged()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.PublisherChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedTrue_On_IsPublishableChanged()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.IsPublishableChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedTrue_On_IsTradeableChanged()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            // ACT
            testObjects.ViewModel.IsTradeableChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldSetHasChangedFalse_On_IsTradeableChangedFalse()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            testObjects.ViewModel.IsTradeableChanged = true;

            // ACT
            testObjects.ViewModel.IsTradeableChanged = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
        }


        [Test]
        public void ShouldNotCalculateHasChanged_When_Disposed()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            testObjects.Controller.Dispose();
            
            // ACT
            testObjects.ViewModel.IsTradeableChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var currentUser = new UserBuilder().User();

            var fxCurveSetting = new FxCurveSetting(101, 10, 1.0, true, false);

            var testObjects = new FxCurvePublisherViewModelControllerTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                        .WithFxCurveSetting(fxCurveSetting)
                                                                                        .WithSubscribeUpdates(true)
                                                                                        .Build();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.IsTradeableChanged = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
        }
    }
}
