﻿using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Controllers;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Controllers
{
    public interface IErrorMessageDialogViewModelControllerTestObjects
    {
        ISubject<ErrorMessageDialogArgs> ShowMessageDialog { get; }
        ErrorMessageDialogViewModelController Controller { get; }
        MessageErrorDialogViewModel ViewModel { get; }
    }

    public class ErrorMessageDialogViewModelControllerTests
    {
        private class ErrorMessageDialogViewModelControllerTestObjectBuilder
        {
            public IErrorMessageDialogViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IErrorMessageDialogViewModelControllerTestObjects>();

                var showMessageDialog = new Subject<ErrorMessageDialogArgs>();

                testObjects.SetupGet(o => o.ShowMessageDialog)
                           .Returns(showMessageDialog);

                var dialogService = new Mock<IErrorMessageDialogService>();

                dialogService.SetupGet(t => t.OnShowDialog)
                             .Returns(showMessageDialog);

                var controller = new ErrorMessageDialogViewModelController(dialogService.Object, 
                                                                      TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowDialog_OnShowMessageDialog()
        {
            var message = new ErrorMessageDialogArgs("header", new[]{"line-1","line-2"}, true);

            var testObjects = new ErrorMessageDialogViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowMessageDialog.OnNext(message);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.ShowDialog);
            Assert.AreEqual("header", testObjects.ViewModel.Header);
            Assert.AreEqual(2, testObjects.ViewModel.DialogMessages.Count);
            Assert.IsTrue(testObjects.ViewModel.ShowSendFeedback);
        }

        [Test]
        public void ShouldCloseDialog_OnCloseCommand()
        {
            var message = new ErrorMessageDialogArgs("header", new[] { "line-1", "line-2"}, false);

            var testObjects = new ErrorMessageDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.ShowMessageDialog.OnNext(message);

            // ACT
            testObjects.ViewModel.DialogOkCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
            Assert.IsNull(testObjects.ViewModel.Header);
            Assert.IsNull(testObjects.ViewModel.DialogMessages);
        }

        [Test]
        public void ShouldNotShowDialog_WhenDisposed()
        {
            var message = new ErrorMessageDialogArgs("header", new[] { "line-1", "line-2" }, false);

            var testObjects = new ErrorMessageDialogViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ShowMessageDialog.OnNext(message);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }
    }
}
