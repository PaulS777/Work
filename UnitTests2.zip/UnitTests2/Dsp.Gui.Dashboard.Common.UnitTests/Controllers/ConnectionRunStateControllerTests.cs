﻿using System.Reactive.Subjects;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.Dashboard.Common.Controllers;
using Dsp.Gui.Dashboard.Common.Services.Application;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.Dashboard.Common.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Controllers
{
    public interface IConnectionRunStateControllerTestObjects
    {
        IAdminApiConnectionService AdminApiConnectionService { get; }
        ICurvePublisherConnectionService CurvePublisherConnectionService { get; }
        ISubject<SystemStartupConnectState> SystemStartupConnectState { get; }
        ISubject<HubConnectionRunState> AdminApiRunState { get; }
        ISubject<HubConnectionRunState> CurvePublisherRunState { get; }
        IApplicationShutdownService ApplicationShutdownService { get; }
        ConnectionRunStateViewModel ViewModel { get; }
        ConnectionRunStateController Controller { get; }
    }

    [TestFixture]
    public class ConnectionRunStateControllerTests
    {
        private class ConnectionRunStateControllerTestObjectBuilder
        {
            private SystemStartupConnectState _systemStartupConnectState;
            private HubConnectionRunState _adminApiRunState;
            private HubConnectionRunState _curvePublisherRunState;
            private bool _adminApiConnected;
            private bool _curvePublisherConnected;
            //private bool _showRetryConnections;

            public ConnectionRunStateControllerTestObjectBuilder WithSystemStartupConnectState(SystemStartupConnectState value)
            {
                _systemStartupConnectState = value;
                return this;
            }

            public ConnectionRunStateControllerTestObjectBuilder WithAdminApiRunState(HubConnectionRunState value)
            {
                _adminApiRunState = value;
                return this;
            }

            public ConnectionRunStateControllerTestObjectBuilder WithCurvePublisherRunState(HubConnectionRunState value)
            {
                _curvePublisherRunState = value;
                return this;
            }

            public ConnectionRunStateControllerTestObjectBuilder WithAdminApiConnected(bool value)
            {
                _adminApiConnected = value;
                return this;
            }

            public ConnectionRunStateControllerTestObjectBuilder WithCurvePublisherConnected(bool value)
            {
                _curvePublisherConnected = value;
                return this;
            }

            //public ConnectionRunStateControllerTestObjectBuilder WithShowRetryConnections(bool value)
            //{
            //    _showRetryConnections = value;
            //    return this;
            //}

            public IConnectionRunStateControllerTestObjects Build()
            {
                var testObjects = new Mock<IConnectionRunStateControllerTestObjects>();

                var systemStartupConnectState = new BehaviorSubject<SystemStartupConnectState>(_systemStartupConnectState);

                testObjects.SetupGet(o => o.SystemStartupConnectState)
                           .Returns(systemStartupConnectState);

                var startupMonitor = new Mock<IConnectionStartupMonitor>();

                startupMonitor.SetupGet(s => s.ConnectState)
                              .Returns(systemStartupConnectState);

                var adminApiRunState = new BehaviorSubject<HubConnectionRunState>(_adminApiRunState);

                testObjects.SetupGet(o => o.AdminApiRunState)
                           .Returns(adminApiRunState);

                var adminApiConnectionService = new Mock<IAdminApiConnectionService>();

                adminApiConnectionService.SetupGet(a => a.RunState)
                                         .Returns(adminApiRunState);

                adminApiConnectionService.Setup(a => a.IsConnected)
                                         .Returns(_adminApiConnected);

                testObjects.SetupGet(o => o.AdminApiConnectionService)
                           .Returns(adminApiConnectionService.Object);

                var curvePublisherRunState = new BehaviorSubject<HubConnectionRunState>(_curvePublisherRunState);

                testObjects.SetupGet(o => o.CurvePublisherRunState)
                           .Returns(curvePublisherRunState);

                var curvePublisherConnectionService = new Mock<ICurvePublisherConnectionService>();

                curvePublisherConnectionService.SetupGet(c => c.RunState)
                                               .Returns(curvePublisherRunState);

                curvePublisherConnectionService.SetupGet(c => c.IsConnected)
                                               .Returns(_curvePublisherConnected);

                testObjects.SetupGet(o => o.CurvePublisherConnectionService)
                           .Returns(curvePublisherConnectionService.Object);

                var applicationShutdownService = new Mock<IApplicationShutdownService>();

                testObjects.SetupGet(o => o.ApplicationShutdownService)
                           .Returns(applicationShutdownService.Object);

                var controller = new ConnectionRunStateController(startupMonitor.Object,
                                                                  adminApiConnectionService.Object,
                                                                  curvePublisherConnectionService.Object,
                                                                  applicationShutdownService.Object,
                                                                  TestMocks.GetSchedulerProvider().Object,
                                                                  TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region startup connect

        [Test]
        public void ShouldSubscribeRunStates_On_StartupConnectState_Connected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.SystemStartupConnectState.OnNext(SystemStartupConnectState.Connected);

            // ASSERT
            Mock.Get(testObjects.AdminApiConnectionService)
                .VerifyGet(a => a.RunState);

            Mock.Get(testObjects.CurvePublisherConnectionService)
                .VerifyGet(c => c.RunState);
        }

        [Test]
        public void ShouldNotSubscribeRunStates_On_StartupConnectState_NotConnected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.SystemStartupConnectState.OnNext(SystemStartupConnectState.HttpFailed);

            // ASSERT
            Mock.Get(testObjects.AdminApiConnectionService)
                .VerifyGet(a => a.RunState, Times.Never);
        }

        #endregion

        #region auto reconnecting

        [Test]
        public void ShouldShowDialog_AdminServiceConnecting_On_AdminApiReconnecting()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnecting);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.True);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);

        }

        [Test]
        public void ShouldShowDialog_CurvePublisherConnecting_On_CurvePublisherReconnecting()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            // ACT
            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.Reconnecting);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.True);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideDialog_On_AdminApiReconnected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Reconnecting)
                                                                                 .Build();

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldHideDialog_On_CurvePublisherReconnected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Reconnecting)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            // ACT
            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        #endregion

        #region connection closed

        [Test]
        public void ShouldShowDialog_And_EnableReconnect_On_AdminApiClosed()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Closed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.True);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldShowDialog_And_EnableReconnect_On_CurvePublisherClosed()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            // ACT
            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.Closed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.True);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldShowAdminApiConnecting_And_DisableRestartConnections_On_RestartConnections_With_AdminApiClosed()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(true)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldRestartConnectAdminApi_When_RestartConnect_With_AdminApiClosed()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(true)
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.AdminApiConnectionService)
                .Verify(c => c.RestartConnect());

            Mock.Get(testObjects.CurvePublisherConnectionService)
                .Verify(c => c.RestartConnect(), Times.Never);
        }

        [Test]
        public void ShouldDisableRestartConnections_On_RestartConnections_With_CurvePublisher_NotConnected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiConnected(true)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldRestartConnectCurvePublisher_When_RestartConnect_With_CurvePublisher_NotConnected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                                 .WithAdminApiConnected(true)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.CurvePublisherConnectionService)
                .Verify(c => c.RestartConnect());

            Mock.Get(testObjects.AdminApiConnectionService)
                .Verify(c => c.RestartConnect(), Times.Never);
        }

        #endregion

        #region manual reconnect failed

        [Test]
        public void ShouldShowConnectionLost_And_EnableRestartConnect_On_AdminApiManualReconnectHttpFailed()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(true)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.HttpFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.True);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.False);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldShowConnectionLost_And_EnableRestartConnect_On_CurvePublisherManualReconnectHttpFailed()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiConnected(true)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            // ACT
            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.HttpFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.True);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.False);

            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldNotEnableRestartConnect_On_AdminApiManualReconnectHttpFailed_With_CurvePublisherConnecting()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.Reconnecting);

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.HttpFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldNotEnableRestartConnect_On_CurvePublisherManualReconnectHttpFailed_With_AdminApiConnecting()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnecting);

            // ACT
            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.HttpFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);
        }

        #endregion

        #region manual reconnect success

        [Test]
        public void ShouldCloseDialog_On_AdminApiReconnectd_After_AdminApiManualReconnect_With_CurvePublisher_Connected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(true)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldCloseDialog_On_Connected_After_CurvePublisherManualReconnect_With_AdminApi_Connected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiConnected(true)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            // ACT
            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldNotCloseDialog_On_AdminApiReconnected_With_CurvePublisher_Reconnecting()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.Reconnecting);

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.True);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldNotCloseDialog_On_CurvePublisherReconnected_With_AdminApi_Reconnecting()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnecting);

            // ACT
            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.True);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldCloseDialog_On_CurvePublisherReconnected_With_AdminApiReconnected()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithAdminApiRunState(HubConnectionRunState.Closed)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                                 .WithAdminApiConnected(false)
                                                                                 .WithCurvePublisherConnected(false)
                                                                                 .Build();

            testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.Execute();

            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);

            // ACT
            testObjects.CurvePublisherRunState.OnNext(HubConnectionRunState.Reconnected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.AdminServiceConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnectionLost, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.CurvePublisherConnecting, Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.RestartConnectionsCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.ConnectionsRetry.IsManualReconnect, Is.False);

            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        #endregion

        #region connections exceeded

        [Test]
        public void ShouldShowConnectionsExceeded_On_ConnectionsExceeded()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.ConnectionsExceeded);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsExceeded.ShowConnectionsExceeded, Is.True);
        }

        [Test]
        public void ShouldHideRetryConnections_On_ConnectionsExceeded()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.HttpFailed);

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.ConnectionsExceeded);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsRetry.ShowConnectionsRetry, Is.False);
        }

        [Test]
        public void ShouldIgnoreRunsStatusUpdates_When_ConnectionsExceeded()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.ConnectionsExceeded);

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Connected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ConnectionsExceeded.ShowConnectionsExceeded, Is.True);
        }

        #endregion

        #region shutdown

        [Test]
        public void ShouldShutdownApplication_On_ExitCommand()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.ConnectionsExceeded.ExitCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ApplicationShutdownService)
                .Verify(s => s.Shutdown());
        }

        #endregion

        #region dispose

        [Test]
        public void ShouldNotShowDialog_When_Disposed()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnecting);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ConnectionRunStateControllerTestObjectBuilder().WithSystemStartupConnectState(SystemStartupConnectState.Connected)
                                                                                 .WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                                 .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnecting);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        #endregion
    }
}
