﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Controllers;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.CurveValidation;
using Dsp.Gui.Dashboard.Common.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Controllers
{
    public interface IDspSystemStatusViewModelControllerTestObjects
    {
        ISubject<List<ServiceStatusNotification>> ServiceStatusNotifications { get; }
        ISubject<List<string>> CurveErrors { get; }
        DspSystemStatusViewModelController Controller { get; }
        DspSystemStatusViewModel ViewModel { get; }
    }

    [TestFixture]
    public class DspSystemStatusViewModelControllerTests
    {
        private class DspSystemStatusViewModelControllerTestObjectBuilder
        {
            private Dictionary<SubSystem, SystemStatusRowViewModel> _systemStatusLookup;
            public DspSystemStatusViewModelControllerTestObjectBuilder WithSystemStatusLookup(Dictionary<SubSystem, SystemStatusRowViewModel> values)
            {
                _systemStatusLookup = values;
                return this;
            }

            public IDspSystemStatusViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IDspSystemStatusViewModelControllerTestObjects>();

                var statusNotifications = new Subject<List<ServiceStatusNotification>>();

                testObjects.SetupGet(o => o.ServiceStatusNotifications)
                           .Returns(statusNotifications);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ServiceStatusNotifications)
                                   .Returns(statusNotifications);

                var statusLookupProvider = new Mock<ISubSystemStatusLookupProvider>();

                statusLookupProvider.Setup(p => p.GetSubSystemStatusLookup(It.IsAny<IList<ServiceStatusNotification>>()))
                                    .Returns(_systemStatusLookup);

                var curveErrors = new BehaviorSubject<List<string>>(null);

                testObjects.SetupGet(o => o.CurveErrors)
                           .Returns(curveErrors);

                var priceCurveValidationService = new Mock<IPriceCurveValidationService>();

                priceCurveValidationService.SetupGet(o => o.CurveLengthErrors)
                                           .Returns(curveErrors);

                var controller = new DspSystemStatusViewModelController(curveControlService.Object,
                                                                        statusLookupProvider.Object,
                                                                        priceCurveValidationService.Object,
                                                                        TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldOpenPopup_On_ShowDetailsCommand()
        {
            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.ShowDetailsCommand.Execute();

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.ShowDetails);
        }

        [Test]
        public void ShouldSetRowDspSystemStatus_From_SystemNotifications()
        {
            var statusLookup = new Dictionary<SubSystem, SystemStatusRowViewModel>
            {
                { SubSystem.GUI, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } },
                { SubSystem.PriceFeedToDsx, new SystemStatusRowViewModel{ Status = DspSystemStatus.Warning } },
                { SubSystem.ChatScraper, new SystemStatusRowViewModel{ Status = DspSystemStatus.Error } }
            };

            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().WithSystemStatusLookup(statusLookup)
                                                                                       .Build();

            // ACT
            testObjects.ServiceStatusNotifications.OnNext(new List<ServiceStatusNotification>());

            // ASSERT
            Assert.AreEqual(DspSystemStatus.Ok, testObjects.ViewModel.DspGuiSystemStatus.Status);
            Assert.AreEqual(DspSystemStatus.Warning, testObjects.ViewModel.PriceFeedDsxStatus.Status);
            Assert.AreEqual(DspSystemStatus.Error, testObjects.ViewModel.ChatScraperStatus.Status);
        }

        [TestCase(DspSystemStatus.Ok, DspSystemStatus.Ok, DspSystemStatus.Ok, DspSystemStatus.Ok, "DSP System Status : OK")]
        [TestCase(DspSystemStatus.Ok, DspSystemStatus.Ok, DspSystemStatus.Error, DspSystemStatus.Warning, "DSP System Status : Warning(s)")]
        [TestCase(DspSystemStatus.Ok, DspSystemStatus.Ok, DspSystemStatus.Warning, DspSystemStatus.Warning, "DSP System Status : Warning(s)")]
        [TestCase(DspSystemStatus.Warning, DspSystemStatus.Ok, DspSystemStatus.Ok, DspSystemStatus.Warning, "DSP System Status : Warning(s)")]
        [TestCase(DspSystemStatus.Ok, DspSystemStatus.Warning, DspSystemStatus.Ok, DspSystemStatus.Warning, "DSP System Status : Warning(s)")]
        [TestCase(DspSystemStatus.Error, DspSystemStatus.Ok, DspSystemStatus.Ok, DspSystemStatus.Error, "DSP System Status : Error(s)")]
        [TestCase(DspSystemStatus.Ok, DspSystemStatus.Error, DspSystemStatus.Ok, DspSystemStatus.Error, "DSP System Status : Error(s)")]
        public void ShouldSetSummaryStatus_From_RowStatuses(DspSystemStatus guiStatus,
                                                            DspSystemStatus priceFeedDsxStatus,
                                                            DspSystemStatus chatScraperStatus,
                                                            DspSystemStatus expectedSummaryStatus,
                                                            string expectedSummaryStatusText)
        {
            var statusLookup = new Dictionary<SubSystem, SystemStatusRowViewModel>
            {
                { SubSystem.GUI, new SystemStatusRowViewModel{ Status = guiStatus } },
                { SubSystem.PriceFeedToDsx, new SystemStatusRowViewModel{ Status = priceFeedDsxStatus } },
                { SubSystem.ChatScraper, new SystemStatusRowViewModel{ Status = chatScraperStatus } }
            };

            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().WithSystemStatusLookup(statusLookup)
                                                                                       .Build();

            // ACT
            testObjects.ServiceStatusNotifications.OnNext(new List<ServiceStatusNotification>());

            // ASSERT
            Assert.AreEqual(expectedSummaryStatus, testObjects.ViewModel.SummaryStatus);
            Assert.AreEqual(expectedSummaryStatusText, testObjects.ViewModel.SummaryStatusText);
        }

        [Test]
        public void ShouldSetSummaryStatusError_When_GuiStatusMissing()
        {
            var statusLookup = new Dictionary<SubSystem, SystemStatusRowViewModel>
            {
                { SubSystem.PriceFeedToDsx, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } },
                { SubSystem.ChatScraper, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } }
            };

            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().WithSystemStatusLookup(statusLookup)
                                                                                       .Build();

            // ACT
            testObjects.ServiceStatusNotifications.OnNext(new List<ServiceStatusNotification>());

            // ASSERT
            Assert.AreEqual(DspSystemStatus.Error, testObjects.ViewModel.SummaryStatus);
        }

        [Test]
        public void ShouldSetSummaryStatusError_When_PriceFeedDsxStatusMissing()
        {
            var statusLookup = new Dictionary<SubSystem, SystemStatusRowViewModel>
            {
                { SubSystem.GUI, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } },
                { SubSystem.ChatScraper, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } }
            };

            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().WithSystemStatusLookup(statusLookup)
                                                                                       .Build();

            // ACT
            testObjects.ServiceStatusNotifications.OnNext(new List<ServiceStatusNotification>());

            // ASSERT
            Assert.AreEqual(DspSystemStatus.Error, testObjects.ViewModel.SummaryStatus);
        }

        [Test]
        public void ShouldSetSummaryStatusWarning_When_ChatScraperStatusMissing()
        {
            var statusLookup = new Dictionary<SubSystem, SystemStatusRowViewModel>
            {
                { SubSystem.GUI, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } },
                { SubSystem.PriceFeedToDsx, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } }
            };

            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().WithSystemStatusLookup(statusLookup)
                                                                                       .Build();

            // ACT
            testObjects.ServiceStatusNotifications.OnNext(new List<ServiceStatusNotification>());

            // ASSERT
            Assert.AreEqual(DspSystemStatus.Warning, testObjects.ViewModel.SummaryStatus);
        }

        [Test]
        public void ShouldSetStatusActions_From_StatusNotifications()
        {
            var statusLookup = new Dictionary<SubSystem, SystemStatusRowViewModel>
            {
                { SubSystem.GUI, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok, ActionMessages = new List<string>{"gui"}}},
                { SubSystem.PriceFeedToDsx, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok, ActionMessages = new List<string>{"dsx"}}},
                { SubSystem.ChatScraper, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok, ActionMessages = new List<string> { "chat"}}}
            };

            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().WithSystemStatusLookup(statusLookup)
                                                                                       .Build();

            // ACT
            testObjects.ServiceStatusNotifications.OnNext(new List<ServiceStatusNotification>());

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.HasStatusActions);

            Assert.AreEqual(3, testObjects.ViewModel.StatusActions.Count);
            Assert.AreEqual("gui", testObjects.ViewModel.StatusActions[0]);
            Assert.AreEqual("dsx", testObjects.ViewModel.StatusActions[1]);
            Assert.AreEqual("chat", testObjects.ViewModel.StatusActions[2]);

            Assert.IsTrue(testObjects.ViewModel.HasStatusActions);
            Assert.IsTrue(testObjects.ViewModel.HasActions);
            Assert.That(testObjects.ViewModel.SummaryStatusText.Contains("with Actions Required"));
        }

        [Test]
        public void ShouldSetActions_From_ManualCurves()
        {
            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().Build();

            var curveErrors = new List<string> { "curve" };

            // ACT
            testObjects.CurveErrors.OnNext(curveErrors);

            // ASSERT
            Assert.AreEqual(1, testObjects.ViewModel.ValidationActions.Count);

            Assert.IsTrue(testObjects.ViewModel.HasValidationActions);
            Assert.IsTrue(testObjects.ViewModel.HasActions);
            Assert.That(testObjects.ViewModel.SummaryStatusText.Contains("with Actions Required"));
        }

        [Test]
        public void ShouldNotSetRowDspSystemStatus_When_Disposed()
        {
            var statusLookup = new Dictionary<SubSystem, SystemStatusRowViewModel>
            {
                { SubSystem.GUI, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } },
                { SubSystem.PriceFeedToDsx, new SystemStatusRowViewModel{ Status = DspSystemStatus.Warning } },
                { SubSystem.ChatScraper, new SystemStatusRowViewModel{ Status = DspSystemStatus.Error } }
            };

            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().WithSystemStatusLookup(statusLookup)
                                                                                       .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ServiceStatusNotifications.OnNext(new List<ServiceStatusNotification>());

            // ASSERT
            Assert.IsNull(testObjects.ViewModel.DspGuiSystemStatus);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var statusLookup = new Dictionary<SubSystem, SystemStatusRowViewModel>
            {
                { SubSystem.GUI, new SystemStatusRowViewModel{ Status = DspSystemStatus.Ok } },
                { SubSystem.PriceFeedToDsx, new SystemStatusRowViewModel{ Status = DspSystemStatus.Warning } },
                { SubSystem.ChatScraper, new SystemStatusRowViewModel{ Status = DspSystemStatus.Error } }
            };

            var testObjects = new DspSystemStatusViewModelControllerTestObjectBuilder().WithSystemStatusLookup(statusLookup)
                                                                                       .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ServiceStatusNotifications.OnNext(new List<ServiceStatusNotification>());

            // ASSERT
            Assert.IsNull(testObjects.ViewModel.DspGuiSystemStatus);
        }

    }
}
