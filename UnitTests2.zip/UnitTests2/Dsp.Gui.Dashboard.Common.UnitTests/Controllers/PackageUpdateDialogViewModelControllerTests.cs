﻿using System;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Windows.ApplicationModel;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Controllers;
using Dsp.Gui.Dashboard.Common.Services.Application;
using Dsp.Gui.Dashboard.Common.ViewModels;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Controllers
{
    internal interface IPackageUpdateDialogViewModelControllerTestObjects
    {
        ILocalTimeProvider LocalTimeProvider { get; }
        IApplicationShutdownService ApplicationShutdownService { get; }
        ICheckPackageUpdatesService CheckPackageUpdatesService { get; }
        ISubject<PackageUpdateAvailability> PackageUpdateAvailability { get; }
        long Interval { get; }
        TestScheduler Scheduler { get; }
        PackageUpdateDialogViewModel ViewModel { get; }
        PackageUpdateDialogViewModelController Controller { get; }
    }

    [TestFixture]
    public class PackageUpdateDialogViewModelControllerTests
    {
        private class PackageUpdateDialogViewModelControllerTestObjectBuilder
        {
            private bool _isNetworkDeployment;
            private TimeOnly _localTime;
            private TimeOnly _timeWindowDisableStart;
            private TimeOnly _timeWindowDisableEnd;

            public PackageUpdateDialogViewModelControllerTestObjectBuilder WithIsNetworkDeployment(bool value)
            {
                _isNetworkDeployment = value;
                return this;
            }

            public PackageUpdateDialogViewModelControllerTestObjectBuilder WithLocalTime(TimeOnly value)
            {
                _localTime = value;
                return this;
            }

            public PackageUpdateDialogViewModelControllerTestObjectBuilder WithTimeWindowDisableStart(TimeOnly value)
            {
                _timeWindowDisableStart = value;
                return this;
            }

            public PackageUpdateDialogViewModelControllerTestObjectBuilder WithTimeWindowDisableEnd(TimeOnly value)
            {
                _timeWindowDisableEnd = value;
                return this;
            }

            public IPackageUpdateDialogViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IPackageUpdateDialogViewModelControllerTestObjects>();

                var interval = TimeSpan.FromMinutes(61).Ticks;

                testObjects.SetupGet(o => o.Interval)
                           .Returns(interval);

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.Scheduler).Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
                schedulerProvider.SetupGet(p => p.Immediate).Returns(Scheduler.Immediate);

                var applicationShutdownService = new Mock<IApplicationShutdownService>();

                testObjects.SetupGet(o => o.ApplicationShutdownService)
                           .Returns(applicationShutdownService.Object);

                var packageInfoProvider = new Mock<IPackageInfoProvider>();

                packageInfoProvider.SetupGet(p => p.IsNetworkDeployment)
                                   .Returns(_isNetworkDeployment);

                var checkPackageUpdatesService = new Mock<ICheckPackageUpdatesService>();

                var packageUpdateAvailability = new Subject<PackageUpdateAvailability>();

                testObjects.SetupGet(o => o.PackageUpdateAvailability)
                           .Returns(packageUpdateAvailability);

                checkPackageUpdatesService.Setup(p => p.GetPackageUpdateAvailability())
                                          .Returns(packageUpdateAvailability);

                testObjects.SetupGet(o => o.CheckPackageUpdatesService)
                           .Returns(checkPackageUpdatesService.Object);

                var packageUpdateTimeWindow = new Mock<IPackageUpdateTimeWindow>();

                packageUpdateTimeWindow.SetupGet(t => t.DisableStartTime)
                                       .Returns(_timeWindowDisableStart);

                packageUpdateTimeWindow.SetupGet(t => t.DisableEndTime)
                                       .Returns(_timeWindowDisableEnd);

                var localTimeProvider = new Mock<ILocalTimeProvider>();

                localTimeProvider.SetupGet(t => t.LocalTime)
                                 .Returns(_localTime);

                testObjects.SetupGet(o => o.LocalTimeProvider)
                           .Returns(localTimeProvider.Object);

                var controller = new PackageUpdateDialogViewModelController(packageInfoProvider.Object,
                                                                            checkPackageUpdatesService.Object,
                                                                            applicationShutdownService.Object,
                                                                            packageUpdateTimeWindow.Object,
                                                                            localTimeProvider.Object,
                                                                            schedulerProvider.Object,
                                                                            TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCheckForPackageUpdatesOnInterval_With_IsNetworkDeploymentTrue()
        {
            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .Build();

            // ACT
            testObjects.Scheduler.AdvanceBy(testObjects.Interval);

            // ASSERT
            Mock.Get(testObjects.LocalTimeProvider)
                .Verify(c => c.LocalTime);
        }

        [Test]
        public void ShouldNotCheckForPackageUpdates_With_IsNetworkDeploymentFalse()
        {
            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(false)
                                                                                           .Build();

            // ACT
            testObjects.Scheduler.AdvanceBy(testObjects.Interval);

            // ASSERT
            Mock.Get(testObjects.LocalTimeProvider)
                .Verify(c => c.LocalTime, Times.Never);
        }

        [Test]
        public void ShouldCheckForPackageUpdates_When_LocalTime_IsBeforeDisableTimeWindow_With_IsNetworkDeployment()
        {
            var localTime = new TimeOnly(5, 0);
            var startTime = new TimeOnly(8, 0);
            var endTime = new TimeOnly(19, 0);

            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .WithLocalTime(localTime)
                                                                                           .WithTimeWindowDisableStart(startTime)
                                                                                           .WithTimeWindowDisableEnd(endTime)
                                                                                           .Build();


            // ACT
            testObjects.Scheduler.AdvanceBy(testObjects.Interval);

            // ASSERT
            Mock.Get(testObjects.CheckPackageUpdatesService)
                .Verify(c => c.GetPackageUpdateAvailability(), Times.Once);
        }

        [Test]
        public void ShouldCheckForPackageUpdates_When_LocalTime_IsAfterDisableTimeWindow_With_IsNetworkDeployment()
        {
            var localTime = new TimeOnly(20, 0);
            var startTime = new TimeOnly(8, 0);
            var endTime = new TimeOnly(19, 0);

            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .WithLocalTime(localTime)
                                                                                           .WithTimeWindowDisableStart(startTime)
                                                                                           .WithTimeWindowDisableEnd(endTime)
                                                                                           .Build();


            // ACT
            testObjects.Scheduler.AdvanceBy(testObjects.Interval);

            // ASSERT
            Mock.Get(testObjects.CheckPackageUpdatesService)
                .Verify(c => c.GetPackageUpdateAvailability(), Times.Once);
        }

        [Test]
        public void ShouldNotCheckForPackageUpdates_When_LocalTime_IsWithinDisableTimeWindow_With_IsNetworkDeployment()
        {
            var localTime = new TimeOnly(9, 0);
            var startTime = new TimeOnly(8, 0);
            var endTime = new TimeOnly(20, 0);

            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .WithLocalTime(localTime)
                                                                                           .WithTimeWindowDisableStart(startTime)
                                                                                           .WithTimeWindowDisableEnd(endTime)
                                                                                           .Build();


            // ACT
            testObjects.Scheduler.AdvanceBy(testObjects.Interval);

            // ASSERT
            Mock.Get(testObjects.CheckPackageUpdatesService)
                .Verify(c => c.GetPackageUpdateAvailability(), Times.Never);
        }


        [TestCase(PackageUpdateAvailability.Available)]
        [TestCase(PackageUpdateAvailability.Required)]
        public void ShouldShowDialog_When_PackageUpdateAvailableOrRequired(PackageUpdateAvailability availability)
        {
            var localTime = new TimeOnly(5, 0);
            var startTime = new TimeOnly(8, 0);
            var endTime = new TimeOnly(19, 0);

            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .WithLocalTime(localTime)
                                                                                           .WithTimeWindowDisableStart(startTime)
                                                                                           .WithTimeWindowDisableEnd(endTime)
                                                                                           .Build();

            var interval = TimeSpan.FromMinutes(61).Ticks;
            testObjects.Scheduler.AdvanceBy(interval);

            // ACT
            testObjects.PackageUpdateAvailability.OnNext(availability);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [TestCase(PackageUpdateAvailability.NoUpdates)]
        [TestCase(PackageUpdateAvailability.Unknown)]
        [TestCase(PackageUpdateAvailability.Error)]
        public void ShouldNotShowDialog_When_NoPackageUpdateAvailable(PackageUpdateAvailability availability)
        {
            var localTime = new TimeOnly(5, 0);
            var startTime = new TimeOnly(8, 0);
            var endTime = new TimeOnly(19, 0);

            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .WithLocalTime(localTime)
                                                                                           .WithTimeWindowDisableStart(startTime)
                                                                                           .WithTimeWindowDisableEnd(endTime)
                                                                                           .Build();

            var interval = TimeSpan.FromMinutes(61).Ticks;
            testObjects.Scheduler.AdvanceBy(interval);

            // ACT
            testObjects.PackageUpdateAvailability.OnNext(availability);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }


        [Test]
        public void ShouldCheckForPackageUpdatesOnNextInterval()
        {
            var localTime = new TimeOnly(5, 0);
            var startTime = new TimeOnly(8, 0);
            var endTime = new TimeOnly(19, 0);

            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .WithLocalTime(localTime)
                                                                                           .WithTimeWindowDisableStart(startTime)
                                                                                           .WithTimeWindowDisableEnd(endTime)
                                                                                           .Build();

            var interval = TimeSpan.FromMinutes(61).Ticks;
            testObjects.Scheduler.AdvanceBy(interval);

            testObjects.PackageUpdateAvailability.OnNext(PackageUpdateAvailability.NoUpdates);
            testObjects.PackageUpdateAvailability.OnCompleted();

            // ACT
            testObjects.Scheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.CheckPackageUpdatesService)
                .Verify(c => c.GetPackageUpdateAvailability(), Times.Exactly(2));
        }

        [Test]
        public void ShouldCloseApplication_On_CloseApplicationCommand()
        {
            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CloseApplicationCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ApplicationShutdownService)
                .Verify(a => a.Shutdown());
        }

        [Test]
        public void ShouldNotCheckForUpdates_When_Disposed()
        {
            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .Build();

            testObjects.Controller.Dispose();

            var interval = TimeSpan.FromMinutes(61).Ticks;

            // ACT
            testObjects.Scheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.LocalTimeProvider)
                .Verify(c => c.LocalTime, Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new PackageUpdateDialogViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                           .Build();

            testObjects.Controller.Dispose();
            testObjects.Controller.Dispose();

            var interval = TimeSpan.FromMinutes(61).Ticks;

            // ACT
            testObjects.Scheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.LocalTimeProvider)
                .Verify(c => c.LocalTime, Times.Never);
        }
    }
}
