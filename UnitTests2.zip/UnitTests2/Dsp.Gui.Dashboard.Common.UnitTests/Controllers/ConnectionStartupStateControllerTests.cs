﻿using System.Reactive.Subjects;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Dashboard.Common.Controllers;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.Dashboard.Common.ViewModels;
using Dsp.Gui.Dashboard.Mail.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Controllers
{
    public interface IConnectionStartupStateControllerTestObjects
    {
        IInitializeConnectionsService InitializeConnectionsService { get; }
        IMailService MailService { get; }
        ISubject<SystemStartupErrorArgs> StartupFailed { get; }
        ISubject<SystemStartupConnectState> StartupConnectState { get; }
        ConnectionStartupStateController Controller { get; }
        ConnectionStartupStateViewModel ViewModel { get; }
    }

    [TestFixture]
    public class ConnectionStartupStateControllerTests
    {
        private class ConnectionStartupStateControllerTestObjectBuilder
        {
            private string _mailDistributionSlack;
            private SystemStartupErrorArgs _startupErrorArgs;
            private SystemStartupConnectState _startupConnectState;
            private string _environmentName;

            public ConnectionStartupStateControllerTestObjectBuilder WithMailDistributionSlack(string value)
            {
                _mailDistributionSlack = value;
                return this;
            }

            public ConnectionStartupStateControllerTestObjectBuilder WithStartupError(SystemStartupErrorArgs value)
            {
                _startupErrorArgs = value;
                return this;
            }

            public ConnectionStartupStateControllerTestObjectBuilder WithStartupConnectState(SystemStartupConnectState value)
            {
                _startupConnectState = value;
                return this;
            }

            public ConnectionStartupStateControllerTestObjectBuilder WithEnvironmentName(string value)
            {
                _environmentName = value;
                return this;
            }

            public IConnectionStartupStateControllerTestObjects Build()
            {
                var testObjects = new Mock<IConnectionStartupStateControllerTestObjects>();

                var initializeConnectionsService = new Mock<IInitializeConnectionsService>();

                testObjects.SetupGet(o => o.InitializeConnectionsService)
                           .Returns(initializeConnectionsService.Object);

                var mailService = new Mock<IMailService>();

                testObjects.SetupGet(o => o.MailService)
                           .Returns(mailService.Object);

                var configProvider = new Mock<IConfigProvider>();

                var commonConfig = Mock.Of<ICommonConfiguration>(c => c.HelpDistributionSlack == _mailDistributionSlack
                                                                      && c.EnvironmentName == _environmentName);

                configProvider.SetupGet(c => c.Configuration)
                              .Returns(commonConfig);

                var startupFailed = new BehaviorSubject<SystemStartupErrorArgs>(_startupErrorArgs);

                testObjects.SetupGet(o => o.StartupFailed)
                           .Returns(startupFailed);

                var startupState = new BehaviorSubject<SystemStartupConnectState>(_startupConnectState);

                testObjects.SetupGet(o => o.StartupConnectState)
                           .Returns(startupState);

                var connectionStartupMonitor = new Mock<IConnectionStartupMonitor>();

                connectionStartupMonitor.SetupGet(c => c.SystemStartupFailed)
                                        .Returns(startupFailed);

                connectionStartupMonitor.SetupGet(c => c.ConnectState)
                                        .Returns(startupState);

                var controller = new ConnectionStartupStateController(configProvider.Object,
                                                                      initializeConnectionsService.Object,
                                                                      connectionStartupMonitor.Object,
                                                                      mailService.Object,
                                                                      TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region ctor

        [Test]
        public void ShouldShowInitializingConnections_And_DisableCommands_When_Constructed()
        {
            // ACT
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.True);
            Assert.That(testObjects.ViewModel.RetryConnectionCommand.CanExecute(), Is.False);
        }

        #endregion

        #region connecting

        [Test]
        public void ShouldNotShowDialogOnConnecting()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupConnectState.OnNext(SystemStartupConnectState.Connecting);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        #endregion

        #region fatal errors

        [Test]
        public void ShouldHideInitializingConnections_And_ShowObsoleteClientFailed_On_ObsoleteClientFailed()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupFailed.OnNext(new SystemStartupErrorArgs(SystemStartupError.ObsoleteClient, null));

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.False);
            Assert.That(testObjects.ViewModel.ShowObsoleteClientFailed, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideInitializingConnections_And_ShowAuthenticationFailed_On_AuthenticationFailed()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupFailed.OnNext(new SystemStartupErrorArgs(SystemStartupError.ApiAuthenticationFailed, null));

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.False);
            Assert.That(testObjects.ViewModel.ShowAuthenticationFailed, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideInitializingConnections_And_ShowSingleSignOnFailed_On_ShowSingleSignOnFailed()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupFailed.OnNext(new SystemStartupErrorArgs(SystemStartupError.SingleSignOnFailed, null));

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.False);
            Assert.That(testObjects.ViewModel.ShowSingleSignOnFailed, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideInitializingConnections_And_ShowAuthorizationFailed_On_Unauthorized()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupFailed.OnNext(new SystemStartupErrorArgs(SystemStartupError.AuthorizationFailed, null));

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.False);
            Assert.That(testObjects.ViewModel.ShowAuthorizationFailed, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideInitializingConnections_And_ShowSingleSignOnFailed_On_SingleSignOnFailed()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupFailed.OnNext(new SystemStartupErrorArgs(SystemStartupError.SingleSignOnFailed, null));

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.False);
            Assert.That(testObjects.ViewModel.ShowSingleSignOnFailed, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideInitializingConnections_And_ShowShowUnexpectedError_On_HubInitializeFailed()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupFailed.OnNext(new SystemStartupErrorArgs(SystemStartupError.HubInitializeFailed, null));
            
            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.False);
            Assert.That(testObjects.ViewModel.ShowUnexpectedError, Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideInitializingConnections_And_ShowShowUnexpectedError_On_UnexpectedError()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupFailed.OnNext(new SystemStartupErrorArgs(SystemStartupError.UnexpectedError, "failed"));

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.False);
            Assert.That(testObjects.ViewModel.ShowUnexpectedError, Is.True);
            Assert.That(testObjects.ViewModel.ErrorMessage, Is.EqualTo("failed"));
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        #endregion

        #region authentication failed, mail

        [Test]
        public void ShouldInvokeMailService_And_ShowAuthenticationFailed_On_AuthenticationFailed()
        {
            var startupError = new SystemStartupErrorArgs(SystemStartupError.ApiAuthenticationFailed, null);

			var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().WithMailDistributionSlack("slack")
                                                                                     .WithEnvironmentName("DEV")
                                                                                     .WithStartupError(startupError)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.RequestUserAccessCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.RequestUserAccessCommand.CanExecute(), Is.False);
            
            Mock.Get(testObjects.MailService)
                .Verify(m => m.CreateUserAccessRequestMail("slack", "DEV"));
        }

        #endregion

        #region http connection failed, retry

        [Test]
        public void ShouldShowInitialConnectionFailed_And_EnabledRetryCommand_On_HttpFailed()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().Build();

            // ACT
            testObjects.StartupConnectState.OnNext(SystemStartupConnectState.HttpFailed);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitializingConnections, Is.False);
            Assert.That(testObjects.ViewModel.ShowInitialConnectionFailed, Is.True);
            Assert.That(testObjects.ViewModel.RetryConnectionCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldShowReconnecting_And_RetryConnect_On_RetryConnectionCommand()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().WithStartupConnectState(SystemStartupConnectState.HttpFailed)
                                                                                     .Build();

            // ACT
            testObjects.ViewModel.RetryConnectionCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowInitialConnectionFailed, Is.False);
            Assert.That(testObjects.ViewModel.ShowConnectingAfterInitialFailure, Is.True);
            Assert.That(testObjects.ViewModel.RetryConnectionCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);

            Mock.Get(testObjects.InitializeConnectionsService)
                .Verify(i => i.RetryConnect());
        }

        [Test]
        public void ShouldHideDialog_On_Connected_After_Retry()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().WithStartupConnectState(SystemStartupConnectState.HttpFailed)
                                                                                     .Build();

            testObjects.ViewModel.RetryConnectionCommand.Execute();

            // ACT
            testObjects.StartupConnectState.OnNext(SystemStartupConnectState.Connected);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        #endregion

        #region dispose

        [Test]
        public void ShouldUnsubscribeStartupState_When_Dispose()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().WithStartupConnectState(SystemStartupConnectState.HttpFailed)
                                                                                     .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.StartupConnectState.OnNext(SystemStartupConnectState.Connecting);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowConnectingAfterInitialFailure, Is.False);

        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ConnectionStartupStateControllerTestObjectBuilder().WithStartupConnectState(SystemStartupConnectState.HttpFailed)
                                                                                     .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.StartupConnectState.OnNext(SystemStartupConnectState.Connecting);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowConnectingAfterInitialFailure, Is.False);
        }

        #endregion
    }
}
