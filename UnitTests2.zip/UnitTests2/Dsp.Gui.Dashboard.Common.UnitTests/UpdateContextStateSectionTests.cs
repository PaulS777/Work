﻿using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests
{
	[TestFixture]
	public class UpdateContextStateSectionTests
	{
		[Test]
		public void ShouldStateValueTrue_When_UpdateStateContextSection_Created()
		{
			var value = false;

			using (new UpdateStateContextSection(updating => value = updating))
			{
				//ASSERT
				Assert.That(value, Is.True);
			}
		}

        [Test]
        public void ShouldStateValueFalse_When_UpdateStateContextSection_Disposed()
        {
            var value = false;

            using (new UpdateStateContextSection(updating => value = updating))
            {
            }

            //ASSERT
			Assert.That(value, Is.False);
		}
	}
}
