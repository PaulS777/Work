﻿using System.Linq;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.Common.Settings;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Settings
{
    [TestFixture]
    public class DashboardSettingsCollectionTests
    {
        [Test]
        public void ShouldCloneDashboardSettingsCollection()
        {
            var dashboardSettingsCollection = new DashboardSettingsCollection
                                              {
                                                  InfoSettings = new DashboardInfoSettings
                                                                 {
                                                                     ScratchPadNavigationConfirmed = true
                                                                 },
                                                  Version = new DashboardVersion(1, 2, 3, 4),
                                                  DashboardSettings =
                                                  [
                                                      new DashboardSettings
                                                      {
                                                          Name = "Dashboard",
                                                          PageNumber = 1,
                                                          ShowPriceGridPanel = true,
                                                          ShowScratchPadPanel = true,
                                                          PriceGridSettings = new DashboardPriceGridSettings
                                                                              {
                                                                                  ShowPriceDirection = true,
                                                                                  PriceColumnSettings =
                                                                                  [
                                                                                      new()
                                                                                      {
                                                                                          Id = 10,
                                                                                          DefinitionType = PriceCurveDefinitionType.PriceCurve,
                                                                                          VisibleIndex = 6,
                                                                                          ColumnWidth = 1.2d,
                                                                                          Averages = [1, 2],
                                                                                          Spreads = [3, 4],
                                                                                          Highlights = [5, 6]
                                                                                      }
                                                                                  ]
                                                                              },
                                                          ScratchPadSettings = new DashboardScratchPadSettings
                                                                               {
                                                                                   WorksheetSettingsList =
                                                                                   [
                                                                                       new()
                                                                                       {
                                                                                           WorksheetId = 1,
                                                                                           WorksheetBindingListCollection =
                                                                                           [
                                                                                               new()
                                                                                               {
                                                                                                   ColumnIndex = 1,
                                                                                                   RowIndex = 2,
                                                                                                   BindingListItems =
                                                                                                   [
                                                                                                       new()
                                                                                                       {
                                                                                                           CurveId = 10,
                                                                                                           Tenor = 20230102
                                                                                                       }
                                                                                                   ]
                                                                                               }
                                                                                           ]
                                                                                       }
                                                                                   ]
                                                                               }
                                                      }
                                                  ]
                                              };

            // ACT
            var result = dashboardSettingsCollection.Clone() as DashboardSettingsCollection;

            // ASSERT
            Assert.That(result, Is.Not.Null);

            Assert.That(ReferenceEquals(result.InfoSettings, dashboardSettingsCollection.InfoSettings), Is.False);
            Assert.That(ReferenceEquals(result.Version, dashboardSettingsCollection.Version), Is.False);
            Assert.That(ReferenceEquals(result.DashboardSettings[0], dashboardSettingsCollection.DashboardSettings[0]), Is.False);

            Assert.That(result.InfoSettings.ScratchPadNavigationConfirmed, Is.True);

            Assert.That(result.Version.Major, Is.EqualTo(1));
            Assert.That(result.Version.Minor, Is.EqualTo(2));
            Assert.That(result.Version.Build, Is.EqualTo(3));
            Assert.That(result.Version.Revision, Is.EqualTo(4));

            Assert.That(result.DashboardSettings.Count , Is.EqualTo(1));

            Assert.That(result.DashboardSettings[0].Name, Is.EqualTo("Dashboard"));
            Assert.That(result.DashboardSettings[0].PageNumber, Is.EqualTo(1));
            Assert.That(result.DashboardSettings[0].ShowPriceGridPanel, Is.True);
            Assert.That(result.DashboardSettings[0].ShowScratchPadPanel, Is.True);

            Assert.That(result.DashboardSettings[0].PriceGridSettings.ShowPriceDirection, Is.True);
            Assert.That(result.DashboardSettings[0].PriceGridSettings.PriceColumnSettings.Count, Is.EqualTo(1));
            Assert.That(result.DashboardSettings[0].PriceGridSettings.PriceColumnSettings[0].Id, Is.EqualTo(10));
            Assert.That(result.DashboardSettings[0].PriceGridSettings.PriceColumnSettings[0].DefinitionType, Is.EqualTo(PriceCurveDefinitionType.PriceCurve));
            Assert.That(result.DashboardSettings[0].PriceGridSettings.PriceColumnSettings[0].VisibleIndex, Is.EqualTo(6));
            Assert.That(result.DashboardSettings[0].PriceGridSettings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(1.2d));
            Assert.That(result.DashboardSettings[0].PriceGridSettings.PriceColumnSettings[0].Averages.SequenceEqual(new[] { 1, 2 }));
            Assert.That(result.DashboardSettings[0].PriceGridSettings.PriceColumnSettings[0].Spreads.SequenceEqual(new[] { 3, 4 }));
            Assert.That(result.DashboardSettings[0].PriceGridSettings.PriceColumnSettings[0].Highlights.SequenceEqual(new[] { 5, 6 }));

            Assert.That(result.DashboardSettings[0].ScratchPadSettings.WorksheetSettingsList.Count, Is.EqualTo(1));
            Assert.That(result.DashboardSettings[0].ScratchPadSettings.WorksheetSettingsList[0].WorksheetId, Is.EqualTo(1));
            Assert.That(result.DashboardSettings[0].ScratchPadSettings.WorksheetSettingsList[0].WorksheetBindingListCollection.Count, Is.EqualTo(1));
            Assert.That(result.DashboardSettings[0].ScratchPadSettings.WorksheetSettingsList[0].WorksheetBindingListCollection[0].ColumnIndex, Is.EqualTo(1));
            Assert.That(result.DashboardSettings[0].ScratchPadSettings.WorksheetSettingsList[0].WorksheetBindingListCollection[0].RowIndex, Is.EqualTo(2));
            Assert.That(result.DashboardSettings[0].ScratchPadSettings.WorksheetSettingsList[0].WorksheetBindingListCollection[0].BindingListItems.Count, Is.EqualTo(1));
            Assert.That(result.DashboardSettings[0].ScratchPadSettings.WorksheetSettingsList[0].WorksheetBindingListCollection[0].BindingListItems[0].CurveId, Is.EqualTo(10));
            Assert.That(result.DashboardSettings[0].ScratchPadSettings.WorksheetSettingsList[0].WorksheetBindingListCollection[0].BindingListItems[0].Tenor, Is.EqualTo(20230102));
        }
    }
}
