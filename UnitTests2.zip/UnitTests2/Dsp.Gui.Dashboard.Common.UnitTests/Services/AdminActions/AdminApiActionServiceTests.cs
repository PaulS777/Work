﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.AdminActions
{
    public interface IAdminApiActionServiceTestObjects
    {
        IAdminApiServiceClient AdminApiServiceClient { get; }
        TestScheduler Scheduler { get; }
        AdminApiActionService<object> AdminApiActionService { get; }
    }

    [TestFixture]
    public class AdminApiActionServiceTests
    {
        private class AdminApiActionServiceTestObjectBuilder
        {
            private AdminApiActionResponse _response;

            public AdminApiActionServiceTestObjectBuilder WithAdminApiActionResponse(AdminApiActionResponse value)
            {
                _response = value;
                return this;
            }

            public IAdminApiActionServiceTestObjects Build()
            {
                var testObjects = new Mock<IAdminApiActionServiceTestObjects>();

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.Scheduler)
                           .Returns(testScheduler);

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                adminApiServiceClient.Setup(a => a.UpdateAction(It.IsAny<List<object>>()))
                                     .Returns(Task.FromResult(_response));

                testObjects.SetupGet(o => o.AdminApiServiceClient)
                           .Returns(adminApiServiceClient.Object);

                var service = new AdminApiActionService<object>(adminApiServiceClient.Object);

                testObjects.SetupGet(o => o.AdminApiActionService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInvokeUpdateAction_When_Update()
        {
            var testObjects = new AdminApiActionServiceTestObjectBuilder().Build();

            var objects = new List<object> { new() };

            var actions = testObjects.AdminApiActionService.Update(objects, testObjects.Scheduler);

            using (actions.Subscribe(_ => { }))
            {
                // ACT
                testObjects.Scheduler.AdvanceBy(10);

                // ASSERT
                Mock.Get(testObjects.AdminApiServiceClient)
                    .Verify(a => a.UpdateAction(It.Is<List<object>>(values => values.SequenceEqual(objects))));
            }
        }

        [Test]
        public void ShouldPublishActionCompleted_Then_Complete_On_ActionResponseSuccess()
        {
            var testObjects = new AdminApiActionServiceTestObjectBuilder().WithAdminApiActionResponse(AdminApiActionResponse.Success())
                                                                          .Build();

            var objects = new List<object> { new() };

            var actions = testObjects.AdminApiActionService.Update(objects, testObjects.Scheduler);

            AdminApiActionCompleted actionCompleted = null;
            var completed = false;

            using (actions.Subscribe(r => actionCompleted = r, () => completed = true))
            {
                // ACT
                testObjects.Scheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(actionCompleted, Is.Not.Null);
                Assert.That(actionCompleted.CompletedWithWarnings, Is.False);
                Assert.That(completed, Is.True);
            }
        }

		[Test]
        public void ShouldPublishActionCompletedWithWarnings_Then_Complete_On_ActionResponseCompletedWithWarnings()
        {
            var testObjects = new AdminApiActionServiceTestObjectBuilder().WithAdminApiActionResponse(AdminApiActionResponse.CompletedWithWarnings("warning"))
                                                                          .Build();

            var objects = new List<object> { new() };

            var actions = testObjects.AdminApiActionService.Update(objects, testObjects.Scheduler);

            AdminApiActionCompleted actionCompleted = null;
            var completed = false;

			using (actions.Subscribe(r => actionCompleted = r, () => completed = true))
            {
                // ACT
                testObjects.Scheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(actionCompleted, Is.Not.Null);
                Assert.That(actionCompleted.CompletedWithWarnings, Is.True);
                Assert.That(actionCompleted.WarningMessage, Is.EqualTo("warning"));
                Assert.That(completed, Is.True);
			}
        }

        [Test]
        public void ShouldPublishError_On_UpdateError()
        {
            var testObjects =
                new AdminApiActionServiceTestObjectBuilder().WithAdminApiActionResponse(AdminApiActionResponse.Failed("error"))
                                                            .Build();

            var objects = new List<object> { new() };

            var actions = testObjects.AdminApiActionService.Update(objects, testObjects.Scheduler);

            Exception error = null;

            using (actions.Subscribe(_ => {}, ex => error = ex))
            {
                // ACT
                testObjects.Scheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(error, Is.Not.Null);
                Assert.That(error.Message, Is.EqualTo("error"));
            }
        }
    }
}
