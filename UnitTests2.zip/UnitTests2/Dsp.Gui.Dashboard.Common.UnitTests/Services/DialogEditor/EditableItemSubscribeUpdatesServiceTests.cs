﻿using Dsp.Gui.Dashboard.Common.Services.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.DialogEditor
{
    public interface IEditableItemSubscribeUpdatesServiceTestObjects
    {
        IEditableItemChangedObserver<IEditableItem> ItemChangedObserver { get; }
        IEditableItemValidationService<IEditableItem> ItemValidationService { get; }
        EditableItemSubscribeUpdatesService<IEditableItem> EditableItemSubscribeUpdatesService { get; }
    }

    [TestFixture]
    public class EditableItemSubscribeUpdatesServiceTests
    {
        private class TestEditableItemSubscribeUpdatesService : EditableItemSubscribeUpdatesService<IEditableItem>
        {
            public TestEditableItemSubscribeUpdatesService(IEditableItemChangedObserver<IEditableItem> changedObserver, 
                                                           IEditableItemValidationService<IEditableItem> validationService)
            :base(changedObserver, validationService)
            {
            }
        }

        private class SubscribeUpdatesServiceTestObjectBuilder
        {
            public IEditableItemSubscribeUpdatesServiceTestObjects Build()
            {
                var testObjects = new Mock<IEditableItemSubscribeUpdatesServiceTestObjects>();

                var itemChangedObserver = new Mock<IEditableItemChangedObserver<IEditableItem>>();

                testObjects.SetupGet(o => o.ItemChangedObserver)
                           .Returns(itemChangedObserver.Object);

                var validationService = new Mock<IEditableItemValidationService<IEditableItem>>();

                testObjects.SetupGet(o => o.ItemValidationService)
                           .Returns(validationService.Object);

                var subscribeUpdatesService = new TestEditableItemSubscribeUpdatesService(itemChangedObserver.Object, 
                                                                                          validationService.Object);

                testObjects.SetupGet(o => o.EditableItemSubscribeUpdatesService)
                           .Returns(subscribeUpdatesService);

                return testObjects.Object;
            }
        }

        [TestCase(true)]
        [TestCase(false)]
        public void ShouldAttachValidationService_When_SubscribeUpdates(bool newRecord)
        {
            var item = Mock.Of<IEditableItem>(r => r.NewRecord == newRecord);

            var testObjects = new SubscribeUpdatesServiceTestObjectBuilder().Build();

            testObjects.EditableItemSubscribeUpdatesService.Attach(item);

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.SubscribeUpdates, true);

            // ASSERT
            Mock.Get(testObjects.ItemValidationService)
                .Verify(v => v.Attach(item));
        }

        [Test]
        public void ShouldObserveChanges_When_SubscribeUpdates_With_NewRecordFalse()
        {
            var item = Mock.Of<IEditableItem>(r => r.NewRecord == false);

            var testObjects = new SubscribeUpdatesServiceTestObjectBuilder().Build();

            testObjects.EditableItemSubscribeUpdatesService.Attach(item);

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.SubscribeUpdates, true);

            // ASSERT
            Assert.IsFalse(item.IsDirty);

            Mock.Get(testObjects.ItemChangedObserver)
                .Verify(v => v.SubscribeUpdates(item));
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_SubscribeUpdates_With_NewRecordTrue()
        {
            var item = Mock.Of<IEditableItem>(r => r.NewRecord == true);

            var testObjects = new SubscribeUpdatesServiceTestObjectBuilder().Build();

            testObjects.EditableItemSubscribeUpdatesService.Attach(item);

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.SubscribeUpdates, true);

            // ASSERT
            Assert.IsTrue(item.IsDirty);
        }

        [Test]
        public void ShouldUnSubscribeChangesAndValidation_When_UnSubscribeUpdates()
        {
            var item = Mock.Of<IEditableItem>(r => r.SubscribeUpdates == true);

            var testObjects = new SubscribeUpdatesServiceTestObjectBuilder().Build();

            testObjects.EditableItemSubscribeUpdatesService.Attach(item);

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.SubscribeUpdates, false);

            // ASSERT
            Mock.Get(testObjects.ItemChangedObserver)
                .Verify(v => v.UnSubscribe());

            Mock.Get(testObjects.ItemValidationService)
                .Verify(v => v.Unsubscribe());
        }

        [Test]
        public void ShouldNotObserveChanges_When_Disposed()
        {
            var item = Mock.Of<IEditableItem>(r => r.NewRecord == false);

            var testObjects = new SubscribeUpdatesServiceTestObjectBuilder().Build();

            testObjects.EditableItemSubscribeUpdatesService.Attach(item);

            testObjects.EditableItemSubscribeUpdatesService.Dispose();

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.SubscribeUpdates, true);

            // ASSERT
            Mock.Get(testObjects.ItemChangedObserver)
                .Verify(v => v.SubscribeUpdates(item), Times.Never);
        }

        [Test]
        public void ShouldDisposeRowChangedObserver_When_Dispose()
        {
            var item = Mock.Of<IEditableItem>();

            var testObjects = new SubscribeUpdatesServiceTestObjectBuilder().Build();

            testObjects.EditableItemSubscribeUpdatesService.Attach(item);

            // ACT
            testObjects.EditableItemSubscribeUpdatesService.Dispose();

            // ASSERT
            Mock.Get(testObjects.ItemChangedObserver)
                .Verify(v => v.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var item = Mock.Of<IEditableItem>();

            var testObjects = new SubscribeUpdatesServiceTestObjectBuilder().Build();

            testObjects.EditableItemSubscribeUpdatesService.Attach(item);

            testObjects.EditableItemSubscribeUpdatesService.Dispose();

            Mock.Get(testObjects.ItemChangedObserver).Invocations.Clear();

            // ACT
            testObjects.EditableItemSubscribeUpdatesService.Dispose();

            // ASSERT
            Mock.Get(testObjects.ItemChangedObserver)
                .Verify(v => v.Dispose(), Times.Never);
        }
    }
}
