﻿using System.Collections.Generic;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.DialogEditor
{
    [TestFixture]
    public class DuplicateItemsServiceTests
    {
        private class TestItem : EditableItem
        {
            private string _name;

            public string Name
            {
                get => _name;
                set
                {
                    _name = value;
                    RaisePropertyChanged(nameof(Name));
                }
            }

            protected override void Dispose(bool value)
            {
            }
        }

        private class TestDuplicateItemsService : DuplicateItemsService<TestItem, string>
        {
            public TestDuplicateItemsService() 
                : base(vm => vm.Name, vm => vm.Name, vm => !string.IsNullOrEmpty(vm.Name))
            {
            }
        }

        [Test]
        public void ShouldSetIsDuplicateFalse_When_NonMatchingNames()
        {
            var item1 = new TestItem { Name = "name-1" };
            var item2 = new TestItem { Name = "name-2" };

            var items = new List<TestItem> {item1, item2};

            using (var service = new TestDuplicateItemsService())
            {
                // ASSERT
                service.RefreshItems(items);

                // ASSERT
                Assert.IsFalse(item1.IsDuplicate);
                Assert.IsFalse(item2.IsDuplicate);
            }
        }

        [Test]
        public void ShouldSetIsDuplicateTrue_When_RefreshItems_WithMatchingNames()
        {
            var item1 = new TestItem { Name = "name" };
            var item2 = new TestItem { Name = "name" };

            var items = new List<TestItem> { item1, item2 };

            using (var service = new TestDuplicateItemsService())
            {
                // ACT
                service.RefreshItems(items);

                // ASSERT
                Assert.IsTrue(item1.IsDuplicate);
                Assert.IsTrue(item2.IsDuplicate);
            }
        }

        [Test]
        public void ShouldNotSetIsDuplicateTrue_When_RefreshItems_WithNamesNotSet()
        {
            var item1 = new TestItem { Name = null };
            var item2 = new TestItem { Name = null };

            var items = new List<TestItem> { item1, item2 };

            using (var service = new TestDuplicateItemsService())
            {
                // ACT
                service.RefreshItems(items);

                // ASSERT
                Assert.IsFalse(item1.IsDuplicate);
                Assert.IsFalse(item2.IsDuplicate);
            }
        }

        [Test]
        public void ShouldSetIsDuplicateTrue_When_NameChangedToDuplicate()
        {
            var item1 = new TestItem { Name = "name-1" };
            var item2 = new TestItem { Name = "name-2" };

            var items = new List<TestItem> { item1, item2 };

            using (var service = new TestDuplicateItemsService())
            {
                // ACT
                service.RefreshItems(items);

                // ACT
                item2.Name = "name-1";

                // ASSERT
                Assert.IsTrue(item1.IsDuplicate);
                Assert.IsTrue(item2.IsDuplicate);
            }
        }

        [Test]
        public void ShouldSetIsDuplicateFalse_When_MatchingItemDeleted()
        {
            var item1 = new TestItem { Name = "name" };
            var item2 = new TestItem { Name = "name" };

            var items = new List<TestItem> { item1, item2 };

            using (var service = new TestDuplicateItemsService())
            {
                service.RefreshItems(items);

                // ACT
                item1.IsDeleted = true;

                // ASSERT
                Assert.IsFalse(item1.IsDuplicate);
                Assert.IsFalse(item2.IsDuplicate);
            }
        }

        [Test]
        public void ShouldSetIsDuplicateTrue_When_MatchingDeletedItem_DeletionUndone()
        {
            var item1 = new TestItem { Name = "name" };
            var item2 = new TestItem { Name = "name" };

            var items = new List<TestItem> { item1, item2 };

            using (var service = new TestDuplicateItemsService())
            {
                service.RefreshItems(items);

                item1.IsDeleted = true;

                // ACT
                item1.IsDeleted = false;

                // ASSERT
                Assert.IsTrue(item1.IsDuplicate);
                Assert.IsTrue(item2.IsDuplicate);
            }
        }

        [Test]
        public void ShouldNotSetIsDuplicateTrue_When_Disposed()
        {
            var item1 = new TestItem { Name = "name-1" };
            var item2 = new TestItem { Name = "name-2" };

            var items = new List<TestItem> { item1, item2 };

            using (var service = new TestDuplicateItemsService())
            {
                service.RefreshItems(items);
                service.Dispose();

                // ACT
                item2.Name = "name-1";

                // ASSERT
                Assert.IsFalse(item1.IsDuplicate);
                Assert.IsFalse(item2.IsDuplicate);
            }
        }

        [Test]
        public void ShouldNotDisposed_When_Disposed()
        {
            var item1 = new TestItem { Name = "name-1" };
            var item2 = new TestItem { Name = "name-2" };

            var items = new List<TestItem> { item1, item2 };

            using (var service = new TestDuplicateItemsService())
            {
                service.RefreshItems(items);
                service.Dispose();

                // ACT
                service.Dispose();
                item2.Name = "name-1";

                // ASSERT
                Assert.IsFalse(item1.IsDuplicate);
                Assert.IsFalse(item2.IsDuplicate);
            }
        }
    }
}
