﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.DialogEditor
{
    [TestFixture]
    public class EditableEntityCollectionProviderTests
    {
        private record Model : DeletableEntity
        {
            public Model(int id, EntityStatus status) : base(id, status)
            {
            }
        }

        [Test]
        public void ShouldBuildNewCollection()
        {
            var builderResult = Mock.Of<IEditableEntity>();
       
            var entities = new List<IEditableEntity>();

            var models = new List<Model> {new Model(1, EntityStatus.Active)};

            var provider = new EditableEntityCollectionProvider<IEditableEntity, Model>();

            // ACT
            var result = provider.GetCollection(entities, models, (r, m) => false, (r, m) => { }, m => builderResult);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldAddToCollection_FromNewUser_And_OrderByName()
        {
            var entity = Mock.Of<IEditableEntity>(r => r.Id == 1);

            var builderResult = Mock.Of<IEditableEntity>(r => r.Id == 2);

            var entities = new List<IEditableEntity> {entity};

            var models = new List<Model>
            {
                new Model(2, EntityStatus.Active),
            };

            var provider = new EditableEntityCollectionProvider<IEditableEntity, Model>();

            // ACT
            var result = provider.GetCollection(entities, models, (r, m) => false, (r, m) => { }, m => builderResult);

            // ASSERT
            Assert.AreEqual(2, result.Count);
        }

        [Test]
        public void ShouldUpdateExistingRecords_With_ModelUpdates()
        {
            var entity1 = Mock.Of<IEditableEntity>(r => r.Id == 1);
            var entity2 = Mock.Of<IEditableEntity>(r => r.Id == 2);

            var entities = new List<IEditableEntity> { entity1, entity2 };

            var updates = new List<Model>
            {
                new Model(2, EntityStatus.Active),
            };

            var provider = new EditableEntityCollectionProvider<IEditableEntity, Model>();

            var updateCount = 0;

            // ACT
            var result = provider.GetCollection(entities, updates, (r, m) => false, (r, m) => updateCount++, m => null);

            // ASSERT
            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, updateCount);
        }

        [Test]
        public void ShouldUpdateNewRecords_With_ModelUpdates()
        {
            var entity1 = Mock.Of<IEditableEntity>(r => r.Id == 1);
            var entity2 = Mock.Of<IEditableEntity>(r => r.Id == 0 && r.NewRecord);

            var entities = new List<IEditableEntity> { entity1, entity2 };

            var update = new Model(2, EntityStatus.Active);

            var models = new List<Model> {update};

            var provider = new EditableEntityCollectionProvider<IEditableEntity, Model>();

            // ACT
            var result = provider.GetCollection(entities, 
                                                models, (r, m) => true, 
                                                (r, m) => Mock.Get(entity2).SetupGet(row => row.Id).Returns(update.Id),
                                                m => null);
            // ASSERT
            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, result[0].Id);
            Assert.AreEqual(2, result[1].Id);
        }

        [Test]
        public void ShouldRemoveExistingRecord_On_ModelDeletionUpdate()
        {
            var entity1 = Mock.Of<IEditableEntity>(r => r.Id == 1);
            var entity2 = Mock.Of<IEditableEntity>(r => r.Id == 2);

            var entities = new List<IEditableEntity> { entity1, entity2 };

            var update = new Model(2, EntityStatus.Deleted);

            var models = new List<Model> { update };

            var provider = new EditableEntityCollectionProvider<IEditableEntity, Model>();

            // ACT
            var result = provider.GetCollection(entities, models, (r, m) => false, (r, m) => { }, m => null);

            // ASSERT
            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(1, result[0].Id);
        }

        [Test]
        public void ShouldGetCollectionReset()
        {
            var builderResult = Mock.Of<IEditableEntity>(r => r.Id == 1);

            var models = new List<Model>
            {
                new Model(1, EntityStatus.Active),
            };

            var provider = new EditableEntityCollectionProvider<IEditableEntity, Model>();

            // ACT
            var result = provider.GetCollectionReset(models, m => builderResult);

            // ASSERT
            Assert.AreEqual(1, result.Count);
        }
    }
}
