﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.DialogEditor
{
    public interface IEditableItemsConflictServiceTestObjects
    {
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        EditableItemsConflictService<IEditableItem, IIdentifiable>  EditableItemsConflictService { get; }
    }

    [TestFixture]
    public class EditableItemsConflictServiceTests
    {
        private class EditableItemsConflictServiceTestObjectBuilder
        {
            public IEditableItemsConflictServiceTestObjects Build()
            {
                var testObjects = new Mock<IEditableItemsConflictServiceTestObjects>();

                var dialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(dialogService.Object);

                var conflictService = new EditableItemsConflictService<IEditableItem, IIdentifiable>(dialogService.Object);

                testObjects.SetupGet(o => o.EditableItemsConflictService)
                           .Returns(conflictService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldFindConflict_When_ItemIsInEdit_And_MatchingId()
        {
            var items = new[] { Mock.Of<IEditableItem>(r => r.Id == 1 && r.IsInEdit) };

            var model = Mock.Of<IIdentifiable>(m => m.Id == 1);

            var models = new[] {model};

            var testObjects = new EditableItemsConflictServiceTestObjectBuilder().Build();

            // ACT
            var results = testObjects.EditableItemsConflictService.GetConflicts(items, models);

            // ASSERT
            Assert.AreEqual(1, results.Count);
        }

        [Test]
        public void ShouldNotFindConflict_When_ItemIsInEdit_And_NonMatchingId()
        {
            var items = new[] { Mock.Of<IEditableItem>(r => r.Id == 1 && r.IsInEdit) };

            var model = Mock.Of<IIdentifiable>(m => m.Id == 2);

            var models = new[] { model };

            var testObjects = new EditableItemsConflictServiceTestObjectBuilder().Build();

            // ACT
            var results = testObjects.EditableItemsConflictService.GetConflicts(items, models);

            // ASSERT
            Assert.AreEqual(0, results.Count);
        }

        [Test]
        public void ShouldNotFindConflict_When_ItemNotIsInEdit_And_MatchingId()
        {
            var items = new[] { Mock.Of<IEditableItem>(r => r.Id == 1) };

            var model = Mock.Of<IIdentifiable>(m => m.Id == 1);

            var models = new[] { model };

            var testObjects = new EditableItemsConflictServiceTestObjectBuilder().Build();

            // ACT
            var results = testObjects.EditableItemsConflictService.GetConflicts(items, models);

            // ASSERT
            Assert.AreEqual(0, results.Count);
        }

        [Test]
        public void ShouldShowConflicts()
        {
            var conflicts = new[] { "name" };

            var testObjects = new EditableItemsConflictServiceTestObjectBuilder().Build();

            // ACT
            testObjects.EditableItemsConflictService.ShowConflictsDialog(conflicts);

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(md => md.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.ShowSendFeedback == false)));
        }
    }
}
