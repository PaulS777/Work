﻿using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.DialogEditor
{
    [TestFixture]
    public class EditableItemValidationServiceTests
    {
        private class RuleBuilder
        {
            private Subject<IEditableItem> _propertyChanged;
            private string _validationResult;

            public RuleBuilder WithPropertyChanged(Subject<IEditableItem> value)
            {
                _propertyChanged = value;
                return this;
            }

            public RuleBuilder WithValidationResult(string value)
            {
                _validationResult = value;
                return this;
            }

            public Mock<IValidationRule<IEditableItem>> Build()
            {
                var rule = new Mock<IValidationRule<IEditableItem>>();

                rule.Setup(r => r.ObservePropertyChanged(It.IsAny<IEditableItem>()))
                    .Returns(_propertyChanged);

                rule.Setup(r => r.Validate(It.IsAny<IEditableItem>()))
                    .Returns(_validationResult);

                return rule;
            }
        }

        [Test]
        public void ShouldValidateItem_When_Attach()
        {
            var viewModel = Mock.Of<IEditableItem>(vm => vm.IsDuplicate);

            var service = new EditableItemValidationService<IEditableItem>();

            // ACT
            service.Attach(viewModel);

            // ASSERT
            Assert.IsFalse(viewModel.IsValid);
            Assert.AreEqual("Duplicate Item", viewModel.ErrorText);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_IsDuplicate()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var service = new EditableItemValidationService<IEditableItem>();

            service.Attach(viewModel);

            // ACT
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDuplicate, true);

            // ASSERT
            Assert.IsFalse(viewModel.IsValid);
            Assert.AreEqual("Duplicate Item", viewModel.ErrorText);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_RuleFails()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var propertyChanged = new Subject<IEditableItem>();

            var rule = new RuleBuilder().WithPropertyChanged(propertyChanged)
                                        .WithValidationResult("Rule Failed")
                                        .Build();

            var service = new EditableItemValidationService<IEditableItem>(rule.Object);

            service.Attach(viewModel);

            // ACT
            propertyChanged.OnNext(viewModel);

            // ASSERT
            Assert.IsFalse(viewModel.IsValid);
            Assert.AreEqual("Rule Failed", viewModel.ErrorText);
        }

        [Test]
        public void ShouldSetIsValidTrue_When_RulePasses()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var propertyChanged = new Subject<IEditableItem>();

            var rule = new RuleBuilder().WithPropertyChanged(propertyChanged)
                                        .WithValidationResult(string.Empty)
                                        .Build();

            var service = new EditableItemValidationService<IEditableItem>(rule.Object);

            service.Attach(viewModel);

            // ACT
            propertyChanged.OnNext(viewModel);

            // ASSERT
            Assert.IsTrue(viewModel.IsValid);
            Assert.IsNull(viewModel.ErrorText);
        }

        [Test]
        public void ShouldAppendErrorText_When_IsDuplicateAndRuleFails()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var propertyChanged = new Subject<IEditableItem>();

            var rule = new RuleBuilder().WithPropertyChanged(propertyChanged)
                                        .WithValidationResult("Rule Failed")
                                        .Build();

            var service = new EditableItemValidationService<IEditableItem>(rule.Object);

            service.Attach(viewModel);

            // ACT
            propertyChanged.OnNext(viewModel);
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDuplicate, true);
            
            // ASSERT
            Assert.IsFalse(viewModel.IsValid);
            Assert.AreEqual("Rule Failed\r\nDuplicate Item", viewModel.ErrorText);
        }

        [Test]
        public void ShouldSetIsValidTrue_When_Deleted()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var propertyChanged = new Subject<IEditableItem>();

            var rule = new RuleBuilder().WithPropertyChanged(propertyChanged)
                                        .WithValidationResult("Rule Failed")
                                        .Build();

            var service = new EditableItemValidationService<IEditableItem>(rule.Object);

            service.Attach(viewModel);

            propertyChanged.OnNext(viewModel);
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDuplicate, true);

            // ACT
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDeleted, true);

            // ASSERT
            Assert.IsTrue(viewModel.IsValid);
            Assert.IsNull(viewModel.ErrorText);
        }

        [Test]
        public void ShouldSetIsValidFalse_When_UndoDeleted_With_InvalidItem()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var propertyChanged = new Subject<IEditableItem>();

            var rule = new RuleBuilder().WithPropertyChanged(propertyChanged)
                                        .WithValidationResult("Rule Failed")
                                        .Build();

            var service = new EditableItemValidationService<IEditableItem>(rule.Object);

            service.Attach(viewModel);

            propertyChanged.OnNext(viewModel);
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDuplicate, true);
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDeleted, true);

            // ACT
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDeleted, false);

            // ASSERT
            Assert.IsFalse(viewModel.IsValid);
            Assert.AreEqual("Rule Failed\r\nDuplicate Item", viewModel.ErrorText);
        }

        [Test]
        public void ShouldNotValidate_When_Unsubscribe()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var service = new EditableItemValidationService<IEditableItem>();

            service.Attach(viewModel);

            service.Unsubscribe();

            // ACT
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDuplicate, true);

            // ASSERT
            Assert.IsTrue(viewModel.IsValid);
            Assert.IsNull(viewModel.ErrorText);
        }

        [Test]
        public void ShouldNotValidate_When_Disposed()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var service = new EditableItemValidationService<IEditableItem>();

            service.Attach(viewModel);

            service.Dispose();

            // ACT
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDuplicate, true);

            // ASSERT
            Assert.IsTrue(viewModel.IsValid);
            Assert.IsNull(viewModel.ErrorText);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var viewModel = Mock.Of<IEditableItem>();

            var service = new EditableItemValidationService<IEditableItem>();

            service.Attach(viewModel);

            service.Dispose();

            // ACT
            service.Dispose();
            Mock.Get(viewModel).NotifyPropertyChanged(vm => vm.IsDuplicate, true);

            // ASSERT
            Assert.IsTrue(viewModel.IsValid);
            Assert.IsNull(viewModel.ErrorText);
        }
    }
}
