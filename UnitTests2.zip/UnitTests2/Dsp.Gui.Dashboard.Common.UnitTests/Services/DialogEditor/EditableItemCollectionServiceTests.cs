﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.DialogEditor
{
    public interface IEditableItemCollectionServiceTestObjects
    {
        IDuplicateItemsService<IEditableItem> DuplicateItemsValidationService { get; }
        EditableItemCollectionService<IEditableItem> EditableItemCollectionService { get; }
    }

    [TestFixture]
    public class EditableItemCollectionServiceTests
    {
        private class TestEditableItemCollectionService : EditableItemCollectionService<IEditableItem>
        {
            public TestEditableItemCollectionService(IDuplicateItemsService<IEditableItem> duplicateItemsService)
                : base(duplicateItemsService)
            {
            }
        }

        private class EditableItemCollectionServiceTestObjectObjectBuilder
        {
            public IEditableItemCollectionServiceTestObjects Build()
            {
                var testObjects = new Mock<IEditableItemCollectionServiceTestObjects>();

                var validationService = new Mock<IDuplicateItemsService<IEditableItem>>();

                testObjects.SetupGet(o => o.DuplicateItemsValidationService)
                           .Returns(validationService.Object);

                var editableItemCollectionService = new TestEditableItemCollectionService(validationService.Object);

                testObjects.SetupGet(o => o.EditableItemCollectionService)
                           .Returns(editableItemCollectionService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInvokeDuplicateItemValidation_When_RefreshItems()
        {
            var items = new List<IEditableItem>();

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            // ACT
            testObjects.EditableItemCollectionService.RefreshItems(items);

            // ASSERT
            Mock.Get(testObjects.DuplicateItemsValidationService)
                .Verify(v => v.RefreshItems(items));
        }

        [Test]
        public void ShouldSetIsInEditFalse_When_RefreshItems_With_IsDirtyFalse_And_IsDeletedFalse()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            // ACT
            testObjects.EditableItemCollectionService.RefreshItems(items);

            // ASSERT
            Assert.IsFalse(item.IsInEdit);
        }

        [Test]
        public void ShouldSetIsInEditTrue_When_IsDirtyTrue()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.IsDirty, true);

            // ASSERT
            Assert.IsTrue(item.IsInEdit);
        }

        [Test]
        public void ShouldSetIsInEditTrue_When_IsDeletedTrue()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.IsDeleted, true);

            // ASSERT
            Assert.IsTrue(item.IsInEdit);
        }

        [Test]
        public void ShouldSetIsInEditFalse_When_IsDirtyResetToFalse()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            Mock.Get(item).NotifyPropertyChanged(m => m.IsDirty, true);

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.IsDirty, false);

            // ASSERT
            Assert.IsFalse(item.IsInEdit);
        }

        [Test]
        public void ShouldSetIsInEditFalse_When_IsDeletedResetToFalse()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            Mock.Get(item).NotifyPropertyChanged(m => m.IsDeleted, true);

            // ACT
            Mock.Get(item).NotifyPropertyChanged(m => m.IsDeleted, false);

            // ASSERT
            Assert.IsFalse(item.IsInEdit);
        }

        [Test]
        public void ShouldPublishCanExecuteUpdateCommandTrue_When_ItemChanged_With_AllItemsValid()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var item2 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> {item1, item2};

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                // ACT
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsDirty, true);

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUndoCommandTrue_When_ItemChanged_With_AllItemsValid()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid  && r.NewRecord == false);
            var item2 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item1, item2 };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUndoCommand.Subscribe(r => result = r))
            {
                // ACT
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsDirty, true);

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUpdateCommandTrue_When_ItemDeleted_With_AllItemsValid()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var item2 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item1, item2 };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                // ACT
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsDeleted, true);

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUndoCommandTrue_When_ItemDeleted_With_AllItemsValid()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var item2 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item1, item2 };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUndoCommand.Subscribe(r => result = r))
            {
                // ACT
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsDeleted, true);

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldAppendItems_And_SetSelectedItem_When_NewItemAdded()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var items = new List<IEditableItem> { item};

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var newItem = Mock.Of<IEditableItem>(r => r.IsDirty == false &&  r.IsDeleted == false && r.IsValid == false && r.NewRecord);

            // ACT
            testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

            // ASSERT
            Assert.AreEqual(2, items.Count);
            Assert.AreEqual(newItem, items[1]);
        }

        [Test]
        public void Should_SetSelectedItem_When_NewItemAdded_WithDialog()
        {
            var dialog = Mock.Of<IEditableItemCollectionDialog>();

            var items = new List<IEditableItem> { Mock.Of<IEditableItem>() };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var newItem = Mock.Of<IEditableItem>();

            // ACT
            testObjects.EditableItemCollectionService.AddNewItem(newItem, items, dialog);

            // ASSERT
            Assert.AreSame(newItem, dialog.SelectedItem);
        }

        [Test]
        public void ShouldInvoke_DuplicateItemValidation_When_NewItemAdded()
        {
            var items = new List<IEditableItem> { Mock.Of<IEditableItem>()};

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var newItem = Mock.Of<IEditableItem>();

            // ACT
            testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

            // ASSERT
            Mock.Get(testObjects.DuplicateItemsValidationService).Verify(v => v.RefreshItems(items));
        }

        [Test]
        public void ShouldPublishValidationErrors_When_NewItemAdded_AsInvalid()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            IList<string> result = null;

            using (testObjects.EditableItemCollectionService.ValidationErrors.Subscribe(r => result = r))
            {
                var newItem = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid == false && r.ErrorText == "error" && r.NewRecord);

                // ACT
                testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

                // ASSERT
                Assert.That(result != null && result.Count == 1 && result[0] == "error");
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUndoCommandTrue_When_NewItemAdded_AsInvalid()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUndoCommand.Subscribe(r => result = r))
            {
                var newItem = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid == false && r.NewRecord);

                // ACT
                testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUpdateCommandTrue_When_NewItemUpdatedToValid()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                var newItem = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid == false && r.NewRecord);

                testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

                // ACT
                Mock.Get(newItem).NotifyPropertyChanged(m => m.IsValid, true);

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUpdateCommandFalse_When_NewItemDeleted_As_Valid()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                var newItem = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord);

                testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

                // ACT
                Mock.Get(newItem).NotifyPropertyChanged(m => m.IsDeleted, true);

                // ASSERT
                Assert.IsFalse(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUndoCommandFalse_When_NewItemDeleted_As_Valid()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUndoCommand.Subscribe(r => result = r))
            {
                var newItem = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord);

                testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

                // ACT
                Mock.Get(newItem).NotifyPropertyChanged(m => m.IsDeleted, true);

                // ASSERT
                Assert.IsFalse(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUpdateCommandFalse_When_ItemChangedToInvalid()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var item2 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item1, item2 };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                // ACT
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsDirty, true);
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsValid, false);

                // ASSERT
                Assert.IsFalse(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUpdateCommandFalse_When_ItemChangedToValid_WithExistingInvalidItem()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid == false && r.NewRecord == false);
            var item2 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid == false && r.NewRecord == false);

            var items = new List<IEditableItem> { item1, item2 };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                // ACT
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsDirty, true);
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsValid, true);

                // ASSERT
                Assert.IsFalse(result);
            }
        }

        [Test]
        public void ShouldPublishDistinctValidationErrors_When_ItemInvalid()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid);
            var item2 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid == false && r.ErrorText == "error-2");
            var item3 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid == false && r.ErrorText == "error-2");

            var items = new List<IEditableItem> { item1, item2, item3 };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            IList<string> result = null;

            using (testObjects.EditableItemCollectionService.ValidationErrors.Subscribe(r => result = r))
            {
                // ACT
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsValid, false);
                Mock.Get(item1).NotifyPropertyChanged(m => m.ErrorText, "error-1");

                // ASSERT
                Assert.AreEqual(2, result.Count);
            }
        }

        [Test]
        public void ShouldPublishDistinctValidationErrors_When_ItemErrorTextChanged()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid == false && r.ErrorText == "error-1");
            var item2 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid == false && r.ErrorText == "error-2");
            var item3 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid == false && r.ErrorText == "error-2");

            var items = new List<IEditableItem> { item1, item2, item3 };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            IList<string> result = null;

            using (testObjects.EditableItemCollectionService.ValidationErrors.Subscribe(r => result = r))
            {
                // ACT
                Mock.Get(item3).NotifyPropertyChanged(m => m.ErrorText, "error-3");

                // ASSERT
                Assert.AreEqual(3, result.Count);
            }
        }

        [Test]
        public void ShouldPublishNoValidationErrors_When_InvalidItem_ChangedToValid()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            IList<string> result = null;

            using (testObjects.EditableItemCollectionService.ValidationErrors.Subscribe(r => result = r))
            {
                Mock.Get(item).NotifyPropertyChanged(m => m.IsValid, false);
                Mock.Get(item).NotifyPropertyChanged(m => m.ErrorText, "error-1");

                // ACT
                Mock.Get(item).NotifyPropertyChanged(m => m.IsValid, true);
                Mock.Get(item).NotifyPropertyChanged(m => m.ErrorText, null);

                // ASSERT
                Assert.AreEqual(0, result.Count);
            }
        }

        [Test]
        public void ShouldDisposeAndRemoveNewItem_When_Deleted()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var newItem = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid == false && r.NewRecord);

            testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

            // ACT
            Mock.Get(newItem).NotifyPropertyChanged(m => m.IsDeleted, true);

            // ASSERT
            Mock.Get(newItem).Verify(r => r.Dispose());
            Assert.AreEqual(1, items.Count);
        }

        [Test]
        public void ShouldInvokeDuplicateItemValidationService_When_NewItemDeleted()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var newItem = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid == false && r.NewRecord);

            testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

            // ACT
            Mock.Get(newItem).NotifyPropertyChanged(m => m.IsDeleted, true);

            // ASSERT
            Mock.Get(testObjects.DuplicateItemsValidationService).Verify(v => v.RefreshItems(items));
        }

        [Test]
        public void ShouldPublishCanExecuteUpdateCommandFalse_When_NewItemDeleted_AsValid()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                var newItem = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid == false && r.NewRecord);

                testObjects.EditableItemCollectionService.AddNewItem(newItem, items);

                Mock.Get(newItem).NotifyPropertyChanged(m => m.IsValid, true);

                // ACT
                Mock.Get(newItem).NotifyPropertyChanged(m => m.IsDeleted, true);

                // ASSERT
                Assert.IsFalse(result);
            }
        }

        [Test]
        public void ShouldPublishCanExecuteUpdateTrue_When_UndoDeleteItem_With_NewValidItem()
        {
            var item = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                var newItem = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid == false && r.NewRecord);

                var editableItemsSource = new List<IEditableItem> { item };

                testObjects.EditableItemCollectionService.AddNewItem(newItem, editableItemsSource);

                Mock.Get(newItem).NotifyPropertyChanged(m => m.IsValid, true);

                // ACT
                Mock.Get(item).NotifyPropertyChanged(m => m.IsDeleted, true);
                Mock.Get(item).NotifyPropertyChanged(m => m.IsDeleted, false);

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldNotPublishCanExecuteUpdateCommand_When_Disposed()
        {
            var item1 = Mock.Of<IEditableItem>(r => r.IsDirty == false && r.IsDeleted == false && r.IsValid && r.NewRecord == false);
            var item2 = Mock.Of<IEditableItem>(r => r.IsDeleted == false && r.IsValid && r.NewRecord == false);

            var items = new List<IEditableItem> { item1, item2 };

            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.RefreshItems(items);

            var result = false;

            using (testObjects.EditableItemCollectionService.CanExecuteUpdateCommand.Subscribe(r => result = r))
            {
                testObjects.EditableItemCollectionService.Dispose();

                // ACT
                Mock.Get(item1).NotifyPropertyChanged(m => m.IsDirty, true);

                // ASSERT
                Assert.IsFalse(result);
            }
        }

        [Test]
        public void ShouldDisposeDuplicationItemValidationService_When_Disposed()
        {
            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            // ACT
            testObjects.EditableItemCollectionService.Dispose();

            // ASSERT
            Mock.Get(testObjects.DuplicateItemsValidationService).Verify(v => v.Dispose(), Times.Once);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new EditableItemCollectionServiceTestObjectObjectBuilder().Build();

            testObjects.EditableItemCollectionService.Dispose();

            // ACT
            testObjects.EditableItemCollectionService.Dispose();

            // ASSERT
            Mock.Get(testObjects.DuplicateItemsValidationService).Verify(v => v.Dispose(), Times.Once);
        }
    }
}
