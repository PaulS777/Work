﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    public interface IPriceCurveSettingsServiceTestObjects
    {
        IPriceCurveSettingsUpdateService PriceCurveSettingsUpdateService { get; }
        ISubject<Unit> UpdatePriceCurveSettings { get; }
        ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
        PriceCurveSettingsNonTradeableService PriceCurveSettingsService { get; }
    }

    [TestFixture]
    public class PriceCurveSettingsNonTradeableServiceTests
    {
        private class PriceCurveSettingsServiceTestObjectBuilder
        {
            private Dictionary<int, PriceCurveSetting> _priceCurveSettings;

            public PriceCurveSettingsServiceTestObjectBuilder WithPriceCurveSettings(Dictionary<int, PriceCurveSetting> values)
            {
                _priceCurveSettings = values;
                return this;
            }

            public IPriceCurveSettingsServiceTestObjects Build()
            {
                var testObjects = new Mock<IPriceCurveSettingsServiceTestObjects>();

                var priceCurveSettings = new BehaviorSubject<Dictionary<int, PriceCurveSetting>>(_priceCurveSettings);
                testObjects.SetupGet(o => o.PriceCurveSettings).Returns(priceCurveSettings);

                var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();
                priceCurveSettingsProvider.SetupGet(p => p.PriceCurveSettings).Returns(priceCurveSettings);

                var updatePriceCurveSettings = new Subject<Unit>();
                testObjects.SetupGet(o => o.UpdatePriceCurveSettings).Returns(updatePriceCurveSettings);

                var priceCurveSettingsUpdateService = new Mock<IPriceCurveSettingsUpdateService>();

                priceCurveSettingsUpdateService.Setup(p => p.UpdateSettings(It.IsAny<IScheduler>(), 
                                                                            It.IsAny<IList<PriceCurveSetting>>(), 
                                                                            null, null))
                                               .Returns(updatePriceCurveSettings);

                testObjects.SetupGet(o => o.PriceCurveSettingsUpdateService)
                           .Returns(priceCurveSettingsUpdateService.Object);

                var priceCurveSettingsService = new PriceCurveSettingsNonTradeableService(priceCurveSettingsProvider.Object, 
                                                                                          priceCurveSettingsUpdateService.Object, 
                                                                                          TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.PriceCurveSettingsService)
                           .Returns(priceCurveSettingsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishCurveSettingsLoaded_OnPriceCurveSettings()
        {
            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                            .WithPublisherId(10)
                                                            .Build()
                }
            };

            var testObjects = new PriceCurveSettingsServiceTestObjectBuilder().Build();

            var loaded = false;

            using (testObjects.PriceCurveSettingsService.CurveSettingsLoaded.Subscribe(r => loaded = r))
            {
                // ACT
                testObjects.PriceCurveSettings.OnNext(settings);

                // ASSERT
                Assert.That(loaded, Is.True);
            }
        }

        [Test]
        public void ShouldUpdatePriceCurveSettingsWithTradeableFalse_When_SetNonTradeable()
        {
            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                            .WithPublisherId(10)
                                                            .WithIsPublishable(true)
                                                            .WithIsTradeable(true)
                                                            .WithIsExcelSource(true)
                                                            .Build()
                }
            };

            var testObjects = new PriceCurveSettingsServiceTestObjectBuilder().WithPriceCurveSettings(settings)
                                                                              .Build();
            // ACT
            using (testObjects.PriceCurveSettingsService.SetAllPriceCurveSettingsNonTradeable()
                              .Subscribe(_ => { }))
            {
                // ASSERT
                Mock.Get(testObjects.PriceCurveSettingsUpdateService).Verify(u =>
                    u.UpdateSettings(It.IsAny<IScheduler>(), 
                                     It.Is<List<PriceCurveSetting>>(s => s.Count == 1
                                                                         && s[0].PriceCurveDefinitionId == 101
                                                                         && s[0].PublisherId == 10
                                                                         && s[0].IsExcelSourced
                                                                         && s[0].IsPublishable
                                                                         && s[0].IsTradeable == false), 
                                     null, null));
            }
        }

        [Test]
        public void ShouldNotUpdatePriceCurveSettings_When_PriceCurveSettingsNotLoaded()
        {
            var testObjects = new PriceCurveSettingsServiceTestObjectBuilder().WithPriceCurveSettings(null)
                                                                              .Build();
            // ACT
            using (testObjects.PriceCurveSettingsService.SetAllPriceCurveSettingsNonTradeable()
                              .Subscribe(_ => { }))
            {
                // ASSERT
                Mock.Get(testObjects.PriceCurveSettingsUpdateService).Verify(u =>
                    u.UpdateSettings(It.IsAny<IScheduler>(),
                                      It.IsAny<List<PriceCurveSetting>>(),
                                      null, null), Times.Never);
            }
        }

        [Test]
        public void ShouldPublishComplete_When_SettingsUpdateComplete()
        {
            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                            .WithPublisherId(10)
                                                            .Build()
                }
            };

            var testObjects = new PriceCurveSettingsServiceTestObjectBuilder().WithPriceCurveSettings(settings)
                                                                              .Build();

            var result = false;

            // ACT
            using (testObjects.PriceCurveSettingsService.SetAllPriceCurveSettingsNonTradeable()
                              .Subscribe(_ => result = true))
            {
                // ACT
                testObjects.UpdatePriceCurveSettings.OnNext(Unit.Default);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishError_When_SettingsUpdateError()
        {
            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                            .WithPublisherId(10)
                                                            .Build()
                }
            };

            var testObjects = new PriceCurveSettingsServiceTestObjectBuilder().WithPriceCurveSettings(settings)
                                                                              .Build();

            var result = false;
            Exception error = null;

            // ACT
            using (testObjects.PriceCurveSettingsService.SetAllPriceCurveSettingsNonTradeable()
                              .Subscribe(_ => result = true,
                                         ex => error = ex))
            {
                // ACT
                testObjects.UpdatePriceCurveSettings.OnError(new Exception());

                // ASSERT
                Assert.That(result, Is.False);
                Assert.IsNotNull(error);
            }
        }

        [Test]
        public void ShouldNotPublishCurveSettingsLoaded_WhenDisposed()
        {
            var settings = new Dictionary<int, PriceCurveSetting>
            {
                {
                    101,
                    new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                            .WithPublisherId(10)
                                                            .Build()
                }
            };

            var testObjects = new PriceCurveSettingsServiceTestObjectBuilder().Build();

            var loaded = false;

            using (testObjects.PriceCurveSettingsService.CurveSettingsLoaded.Subscribe(r => loaded = r))
            {
                testObjects.PriceCurveSettingsService.Dispose();

                // ACT
                testObjects.PriceCurveSettings.OnNext(settings);

                // ASSERT
                Assert.That(loaded, Is.False);
            }
        }
    }
}
