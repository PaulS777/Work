﻿using System;
using System.Reactive.Subjects;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.Connection
{
    public interface IConnectionRunStateMonitorTestObjects
    {
        ISubject<HubConnectionRunState> AdminApiRunState { get; }
        ISubject<HubConnectionRunState> CurvePublisherRunState { get; }
        ConnectionRunStateMonitor ConnectionRunStateMonitor { get; }
    }

    [TestFixture]
    public class ConnectionRunStateMonitorTests
    {
        private class ConnectionRunStateMonitorTestObjectBuilder
        {
            private HubConnectionRunState _adminApiRunState;
            private HubConnectionRunState _curvePublisherRunState;

            public ConnectionRunStateMonitorTestObjectBuilder WithAdminApiRunState(HubConnectionRunState value)
            {
                _adminApiRunState = value;
                return this;
            }

            public ConnectionRunStateMonitorTestObjectBuilder WithCurvePublisherRunState(HubConnectionRunState value)
            {
                _curvePublisherRunState = value;
                return this;
            }

            public IConnectionRunStateMonitorTestObjects Build()
            {
                var testObjects = new Mock<IConnectionRunStateMonitorTestObjects>();

                var adminApiRunState = new BehaviorSubject<HubConnectionRunState>(_adminApiRunState);

                testObjects.SetupGet(o => o.AdminApiRunState)
                           .Returns(adminApiRunState);

                var adminApiConnectionService = new Mock<IAdminApiConnectionService>();

                adminApiConnectionService.SetupGet(a => a.RunState)
                                         .Returns(adminApiRunState);

                var curvePublisherRunState = new BehaviorSubject<HubConnectionRunState>(_curvePublisherRunState);

                testObjects.SetupGet(o => o.CurvePublisherRunState)
                           .Returns(curvePublisherRunState);

                var curvePublisherConnectionService = new Mock<ICurvePublisherConnectionService>();

                curvePublisherConnectionService.SetupGet(c => c.RunState)
                                               .Returns(curvePublisherRunState);

                var connectionRunStateMonitor = new ConnectionRunStateMonitor(adminApiConnectionService.Object,
                                                                              curvePublisherConnectionService.Object,
                                                                              TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.ConnectionRunStateMonitor)
                           .Returns(connectionRunStateMonitor);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishFailedStartup_OnFailedStartup_With_OtherConnected()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.FailedStartup);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.FailedStartup));
        }

        [Test]
        public void ShouldPublishConnected_OnConnected_With_OtherConnected()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Connected);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Connected));
        }

        #region publication seqence on single reconnect

        [Test]
        public void ShouldPublishReconnecting_OnReconnecting_With_OtherConnected()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                              .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnecting);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Reconnecting));
        }

        [Test]
        public void ShouldPublishReconnecting_OnReconnecting_With_OtherClosed()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                              .WithAdminApiRunState(HubConnectionRunState.Connected)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnecting);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Reconnecting));
        }

        [Test]
        public void ShouldPublishReconnected_OnReconnecting_With_OtherConnected()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                              .WithAdminApiRunState(HubConnectionRunState.Reconnecting)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Reconnected));
        }


        #endregion

        #region publication sequence on closed

        [Test]
        public void ShouldPublishClosed_OnClosed_With_OtherClosed()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Closed)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Closed);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Closed));
        }

        [Test]
        public void ShouldPublishClosed_OnClosed_With_OtherConnected()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Connected)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Closed);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Closed));
        }

        [Test]
        public void ShouldPublishClosed_OnClosed_With_OtherReconnected()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Reconnected)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Closed);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Closed));
        }

        #endregion

        #region publication sequence on both reconnect

        [Test]
        public void ShouldPublishReconnecting_OnReconnecting_With_OtherLostConnection()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Reconnecting)
                                                                              .WithAdminApiRunState(HubConnectionRunState.Reconnecting)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Reconnecting));
        }

        [Test]
        public void ShouldPublishReconnected_OnReconnected_With_OtherReconnected()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Reconnected)
                                                                              .WithAdminApiRunState(HubConnectionRunState.Reconnecting)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Reconnected));
        }

        #endregion

        #region dispose

        [Test]
        public void ShouldNotPublishReconnected_When_Disposed()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Reconnected)
                                                                              .WithAdminApiRunState(HubConnectionRunState.Reconnecting)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                testObjects.ConnectionRunStateMonitor.Dispose();

                // ACT
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Reconnecting));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ConnectionRunStateMonitorTestObjectBuilder().WithCurvePublisherRunState(HubConnectionRunState.Reconnected)
                                                                              .WithAdminApiRunState(HubConnectionRunState.Reconnecting)
                                                                              .Build();

            var result = SystemRunConnectState.NotSet;

            using (testObjects.ConnectionRunStateMonitor.RunState.Subscribe(value => result = value))
            {
                testObjects.ConnectionRunStateMonitor.Dispose();

                // ACT
                testObjects.ConnectionRunStateMonitor.Dispose();
                testObjects.AdminApiRunState.OnNext(HubConnectionRunState.Reconnected);
            }

            Assert.That(result, Is.EqualTo(SystemRunConnectState.Reconnecting));
        }

        #endregion
    }
}
