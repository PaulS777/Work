﻿using System;
using System.Reactive.Subjects;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.Connection
{
    public interface IConnectionStartupMonitorTestObjects
    {
        ISubject<HubConnectionStartupArgs> AdminApiStartupState { get; }
        ISubject<HubConnectionStartupArgs> CurvePublisherStartupState { get; }
        ConnectionStartupMonitor ConnectionStartupMonitor { get; }
    }

    [TestFixture]
    public class ConnectionStartupMonitorTests
    {
        private class ConnectionStartupMonitorTestObjectBuilder
        {
            private HubConnectionStartupArgs _curvePublisherStartupState;

            public ConnectionStartupMonitorTestObjectBuilder WithCurvePublisherStartupState(HubConnectionStartupArgs value)
            {
                _curvePublisherStartupState = value;
                return this;
            }

            public IConnectionStartupMonitorTestObjects Build()
            {
                var testObjects = new Mock<IConnectionStartupMonitorTestObjects>();

                var adminApiStartupState = new BehaviorSubject<HubConnectionStartupArgs>(null);

                testObjects.SetupGet(o => o.AdminApiStartupState)
                           .Returns(adminApiStartupState);

                var adminApiConnectionService = new Mock<IAdminApiConnectionService>();

                adminApiConnectionService.SetupGet(a => a.StartupState)
                                         .Returns(adminApiStartupState);

                var curvePublisherStartupState = new BehaviorSubject<HubConnectionStartupArgs>(_curvePublisherStartupState);

                testObjects.SetupGet(o => o.CurvePublisherStartupState)
                           .Returns(curvePublisherStartupState);

                var curvePublisherConnectionService = new Mock<ICurvePublisherConnectionService>();

                curvePublisherConnectionService.SetupGet(c => c.StartupState)
                                               .Returns(curvePublisherStartupState);

                var connectionStartupMonitor = new ConnectionStartupMonitor(adminApiConnectionService.Object,
                                                                            curvePublisherConnectionService.Object,
                                                                            TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.ConnectionStartupMonitor)
                           .Returns(connectionStartupMonitor);

                return testObjects.Object;
            }
        }

        [TestCase(FatalHubConnectionError.ApiAuthenticationFailed, SystemStartupError.ApiAuthenticationFailed)]
        [TestCase(FatalHubConnectionError.ObsoleteClient, SystemStartupError.ObsoleteClient)]
        [TestCase(FatalHubConnectionError.AuthorizationFailed, SystemStartupError.AuthorizationFailed)]
        [TestCase(FatalHubConnectionError.SsoAuthenticationFailed, SystemStartupError.SingleSignOnFailed)]
        [TestCase(FatalHubConnectionError.UnexpectedError, SystemStartupError.UnexpectedError)]
        public void ShouldPublishSystemStartupFailed_On_AnyFatalError(FatalHubConnectionError fatalHubConnectionError, SystemStartupError expected)
        {
            var testObjects = new ConnectionStartupMonitorTestObjectBuilder().WithCurvePublisherStartupState(new HubConnectionStartupArgs(HubConnectingState.Connecting))
                                                                             .Build();

            SystemStartupErrorArgs result = null;

            using (testObjects.ConnectionStartupMonitor.SystemStartupFailed.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiStartupState.OnNext(new HubConnectionStartupArgs(fatalHubConnectionError, "message"));
            }
      
            // ASSERT
            Assert.That(result.SystemStartupError, Is.EqualTo(expected));
            Assert.That(result.Message, Is.EqualTo("message"));
        }

        [Test]
        public void ShouldNotPublish_On_NextFatalError_After_FatalErrorPublished()
        {
            var testObjects = new ConnectionStartupMonitorTestObjectBuilder().WithCurvePublisherStartupState(new HubConnectionStartupArgs(HubConnectingState.Connecting))
                                                                             .Build();

            SystemStartupErrorArgs result = null;

            using (testObjects.ConnectionStartupMonitor.SystemStartupFailed.Subscribe(value => result = value))
            {
                testObjects.AdminApiStartupState.OnNext(new HubConnectionStartupArgs(FatalHubConnectionError.UnexpectedError, null));

                // ACT
                testObjects.AdminApiStartupState.OnNext(new HubConnectionStartupArgs(FatalHubConnectionError.ApiAuthenticationFailed, null));
            }

            // ASSERT
            Assert.That(result.SystemStartupError, Is.EqualTo(SystemStartupError.UnexpectedError));
        }

        [TestCase(HubConnectingState.Connecting)]
        [TestCase(HubConnectingState.Connected)]
        public void ShouldPublishStartupStateConnecting_On_Any_Connecting_With_Other_NotHttpFailed(HubConnectingState state)
        {
            var testObjects = new ConnectionStartupMonitorTestObjectBuilder().WithCurvePublisherStartupState(new HubConnectionStartupArgs(state))
                                                                             .Build();

            var result = SystemStartupConnectState.NotSet;

            using (testObjects.ConnectionStartupMonitor.ConnectState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiStartupState.OnNext(new HubConnectionStartupArgs(HubConnectingState.Connecting));
            }

            // ASSERT
            Assert.That(result, Is.EqualTo(SystemStartupConnectState.Connecting));
        }

        [TestCase(HubConnectingState.Connecting)]
        [TestCase(HubConnectingState.Connected)]
        [TestCase(HubConnectingState.HttpFailed)]
        public void ShouldPublishStartupStateHttpFailed_On_Any_HttpFailed(HubConnectingState state)
        {
            var testObjects = new ConnectionStartupMonitorTestObjectBuilder().WithCurvePublisherStartupState(new HubConnectionStartupArgs(state))
                                                                             .Build();

            var result = SystemStartupConnectState.NotSet;

            using (testObjects.ConnectionStartupMonitor.ConnectState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiStartupState.OnNext(new HubConnectionStartupArgs(HubConnectingState.HttpFailed));
            }

            // ASSERT
            Assert.That(result, Is.EqualTo(SystemStartupConnectState.HttpFailed));
        }

        [Test]
        public void ShouldPublishStartupStateConnected_On_All_Connected()
        {
            var testObjects = new ConnectionStartupMonitorTestObjectBuilder().WithCurvePublisherStartupState(new HubConnectionStartupArgs(HubConnectingState.Connected))
                                                                             .Build();

            var result = SystemStartupConnectState.NotSet;

            using (testObjects.ConnectionStartupMonitor.ConnectState.Subscribe(value => result = value))
            {
                // ACT
                testObjects.AdminApiStartupState.OnNext(new HubConnectionStartupArgs(HubConnectingState.Connected));
            }

            // ASSERT
            Assert.That(result, Is.EqualTo(SystemStartupConnectState.Connected));
        }

        [Test]
        public void ShouldNotPublishStartupState_When_Disposed()
        {
            var testObjects = new ConnectionStartupMonitorTestObjectBuilder().WithCurvePublisherStartupState(new HubConnectionStartupArgs(HubConnectingState.NotSet))
                                                                             .Build();

            var result = SystemStartupConnectState.NotSet;

            using (testObjects.ConnectionStartupMonitor.ConnectState.Subscribe(value => result = value))
            {
                testObjects.ConnectionStartupMonitor.Dispose();

                // ACT
                testObjects.AdminApiStartupState.OnNext(new HubConnectionStartupArgs(HubConnectingState.Connecting));
            }

            // ASSERT
            Assert.That(result, Is.EqualTo(SystemStartupConnectState.NotSet));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ConnectionStartupMonitorTestObjectBuilder().WithCurvePublisherStartupState(new HubConnectionStartupArgs(HubConnectingState.NotSet))
                                                                             .Build();

            var result = SystemStartupConnectState.NotSet;

            using (testObjects.ConnectionStartupMonitor.ConnectState.Subscribe(value => result = value))
            {
                testObjects.ConnectionStartupMonitor.Dispose();

                // ACT
                testObjects.ConnectionStartupMonitor.Dispose();
                testObjects.AdminApiStartupState.OnNext(new HubConnectionStartupArgs(HubConnectingState.Connecting));
            }

            // ASSERT
            Assert.That(result, Is.EqualTo(SystemStartupConnectState.NotSet));
        }

    }
}
