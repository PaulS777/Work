﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    public interface IPriceCurveSettingsUpdateServiceTestObjects
    {
        IPriceCurveSettingAdminUpdateService PriceCurveSettingAdminUpdateService { get; }
        IFxCurveSettingUpdateService FxCurveSettingUpdateService { get; }
        IPublisherTenorPremiumUpdateService PublisherTenorPremiumUpdateService { get; }
        ISubject<Unit> PriceCurveSettingsUpdate { get; }
        ISubject<Unit> FxCurveSettingsUpdate { get; }
        ISubject<Unit> PublisherTenorPremiumUpdate { get; }
        ISubject<Unit> PublisherTenorPremiumAdd { get; }
        PriceCurveSettingsUpdateService PriceCurveSettingsUpdateService { get; }
    }

    [TestFixture]
    public class PriceCurveSettingsUpdateServiceTests
    {
        private class PriceCurveSettingsUpdateServiceTestObjectBuilder
        {
            public IPriceCurveSettingsUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IPriceCurveSettingsUpdateServiceTestObjects>();

                var priceCurveSettingsUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.PriceCurveSettingsUpdate)
                           .Returns(priceCurveSettingsUpdate);

                var fxCurveSettingsUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.FxCurveSettingsUpdate)
                           .Returns(fxCurveSettingsUpdate);

                var publisherTenorPremiumUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.PublisherTenorPremiumUpdate)
                           .Returns(publisherTenorPremiumUpdate);

                var publisherTenorPremiumAdd = new Subject<Unit>();

                testObjects.SetupGet(o => o.PublisherTenorPremiumAdd)
                           .Returns(publisherTenorPremiumAdd);

                var priceCurveSettingAdminUpdateService = new Mock<IPriceCurveSettingAdminUpdateService>();

                priceCurveSettingAdminUpdateService.Setup(p => p.Update(It.IsAny<IList<PriceCurveSetting>>(),
                                                                        It.IsAny<IScheduler>()))
                                                   .Returns(priceCurveSettingsUpdate);

                testObjects.SetupGet(o => o.PriceCurveSettingAdminUpdateService)
                           .Returns(priceCurveSettingAdminUpdateService.Object);

                var fxCurveSettingUpdateService = new Mock<IFxCurveSettingUpdateService>();

                fxCurveSettingUpdateService.Setup(p => p.Update(It.IsAny<IList<FxCurveSetting>>(),
                                                                It.IsAny<IScheduler>()))
                                           .Returns(fxCurveSettingsUpdate);

                testObjects.SetupGet(o => o.FxCurveSettingUpdateService)
                           .Returns(fxCurveSettingUpdateService.Object);

                var publisherTenorPremiumUpdateService = new Mock<IPublisherTenorPremiumUpdateService>();

                publisherTenorPremiumUpdateService.Setup(p => p.Update(It.IsAny<IList<PublisherTenorPremium>>(),
                                                                       It.IsAny<IScheduler>()))
                                                  .Returns(publisherTenorPremiumUpdate);

                publisherTenorPremiumUpdateService.Setup(p => p.Add(It.IsAny<IList<PublisherTenorPremium>>(),
                                                                    It.IsAny<IScheduler>()))
                                                  .Returns(publisherTenorPremiumAdd);

                testObjects.SetupGet(o => o.PublisherTenorPremiumUpdateService)
                           .Returns(publisherTenorPremiumUpdateService.Object);

                var priceCurveSettingsUpdateService = new PriceCurveSettingsUpdateService(priceCurveSettingAdminUpdateService.Object,
                                                                                          fxCurveSettingUpdateService.Object,
                                                                                          publisherTenorPremiumUpdateService.Object);

                testObjects.SetupGet(o => o.PriceCurveSettingsUpdateService)
                           .Returns(priceCurveSettingsUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdatePriceCurveAndFxSettings_When_SettingsChanged_With_NoPremiums()
        {
            var testScheduler = new TestScheduler();

            var priceCurveSettings = new List<PriceCurveSetting>
                                     {
                                         new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                                 .WithPublisherId(10)
                                                                                 .Build()
                                     };

            var fxCurveSettings = new List<FxCurveSetting>
                                  {
                                      new(201, 10, 1.0, true, true)
                                  };

            var testObjects = new PriceCurveSettingsUpdateServiceTestObjectBuilder().Build();

            testObjects.PriceCurveSettingsUpdateService.UpdateSettings(testScheduler,
                                                                       priceCurveSettings,
                                                                       fxCurveSettings,
                                                                       new List<PublisherTenorPremium>());

            Mock.Get(testObjects.PriceCurveSettingAdminUpdateService)
                .Verify(p => p.Update(priceCurveSettings, It.IsAny<IScheduler>()));

            Mock.Get(testObjects.FxCurveSettingUpdateService)
                .Verify(fx => fx.Update(fxCurveSettings, It.IsAny<IScheduler>()));

            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<List<PublisherTenorPremium>>(), It.IsAny<IScheduler>()), Times.Never);

            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Add(It.IsAny<List<PublisherTenorPremium>>(), It.IsAny<IScheduler>()), Times.Never);
        }

        [Test]
        public void ShouldUpdateCopyPremiums_And_AddNewUserPremiums_When_UpdateSettings_With_Premiums()
        {
            var testScheduler = new TestScheduler();

            var priceCurveSettings = new List<PriceCurveSetting>
            {
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                        .WithPublisherId(10)
                                                        .Build(),
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
                                                        .WithPublisherId(10)
                                                        .Build()
            };
            var tenorPremiums = new List<PublisherTenorPremium>
            {
                new PublisherTenorPremiumTestObjectBuilder().WithId(51)
                                                            .WithPublisherId(10)
                                                            .Build(),
                new PublisherTenorPremiumTestObjectBuilder().WithId(0)
                                                            .WithPublisherId(10)
                                                            .Build()
            };

            var testObjects = new PriceCurveSettingsUpdateServiceTestObjectBuilder().Build();

            testObjects.PriceCurveSettingsUpdateService.UpdateSettings(testScheduler,
                                                                       priceCurveSettings,
                                                                       new List<FxCurveSetting>(),
                                                                       tenorPremiums);

            Mock.Get(testObjects.PriceCurveSettingAdminUpdateService)
                .Verify(p => p.Update(priceCurveSettings, It.IsAny<IScheduler>()));

            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Update(It.Is<List<PublisherTenorPremium>>(tps => tps.Count == 1 && tps[0].Id == 51),
                                      It.IsAny<IScheduler>()));

            Mock.Get(testObjects.PublisherTenorPremiumUpdateService)
                .Verify(p => p.Add(It.Is<List<PublisherTenorPremium>>(tps => tps.Count == 1 && tps[0].Id == 0),
                                   It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldPublishCompleted_When_AllSettingsUpdated()
        {
            var testScheduler = new TestScheduler();

            var priceCurveSettings = new List<PriceCurveSetting>
            {
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                        .WithPublisherId(10)
                                                        .Build(),
                new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
                                                        .WithPublisherId(10)
                                                        .Build()
            };

            var fxCurveSettings = new List<FxCurveSetting>
            {
                new(201, 10, 1.0, true, true)
            };

            var tenorPremiums = new List<PublisherTenorPremium>
            {
                new PublisherTenorPremiumTestObjectBuilder().WithId(51)
                                                            .WithPublisherId(10)
                                                            .Build(),
                new PublisherTenorPremiumTestObjectBuilder().WithId(0)
                                                            .WithPublisherId(10)
                                                            .Build()
            };

            var testObjects = new PriceCurveSettingsUpdateServiceTestObjectBuilder().Build();

            testObjects.PriceCurveSettingsUpdateService.UpdateSettings(testScheduler,
                                                                       priceCurveSettings,
                                                                       fxCurveSettings,
                                                                       tenorPremiums);

            var result = false;

            using (testObjects.PriceCurveSettingsUpdateService.UpdateSettings(testScheduler,
                                                                              priceCurveSettings,
                                                                              fxCurveSettings,
                                                                              tenorPremiums)
                              .Subscribe(_ => {}, () => result = true))
            {
                testObjects.PriceCurveSettingsUpdate.OnCompleted();
                testObjects.FxCurveSettingsUpdate.OnCompleted();
                testObjects.PublisherTenorPremiumUpdate.OnCompleted();
                testObjects.PublisherTenorPremiumAdd.OnCompleted();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }
    }
}
