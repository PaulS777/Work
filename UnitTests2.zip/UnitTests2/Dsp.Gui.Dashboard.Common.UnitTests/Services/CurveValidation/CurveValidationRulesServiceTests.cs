﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.Common.Services.CurveValidation;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts.MonthEndRoll;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.CurveValidation
{
    public interface ICurveValidationRulesServiceTestObjects
    {
        IMonthEndRollValidationService MonthEndRollValidationService { get; }
        CurveValidationRulesService CurveValidationRulesService { get; }
    }

    [TestFixture]
    public class CurveValidationRulesServiceTests
    {
        private class CurveValidationRulesServiceTestObjectBuilder
        {
            private List<string> _flatPriceCurvesValidationResult;
            private List<string> _manualCurveLengthsValidationResult;

            public CurveValidationRulesServiceTestObjectBuilder WithFlatPriceCurvesValidationResult(List<string> values)
            {
                _flatPriceCurvesValidationResult = values;
                return this;
            }

            public CurveValidationRulesServiceTestObjectBuilder WithManualCurveLengthsValidationResult(List<string> values)
            {
                _manualCurveLengthsValidationResult = values;
                return this;
            }

            public ICurveValidationRulesServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveValidationRulesServiceTestObjects>();

                var monthEndRollValidation = new Mock<IMonthEndRollValidationService>();

                monthEndRollValidation.Setup(m => m.ValidateFlatPriceCurves(It.IsAny<List<ManualCurveDefinition<MonthlyTenor>>>()))
                                      .Returns(_flatPriceCurvesValidationResult);

                monthEndRollValidation.Setup(m => m.ValidateManualCurvesLength(It.IsAny<List<ManualCurveDefinition<MonthlyTenor>>>()))
                                      .Returns(_manualCurveLengthsValidationResult);

                testObjects.SetupGet(o => o.MonthEndRollValidationService)
                           .Returns(monthEndRollValidation.Object);

                var validationRules = new CurveValidationRulesService(monthEndRollValidation.Object);

                testObjects.SetupGet(o => o.CurveValidationRulesService)
                           .Returns(validationRules);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldValidateFlatPriceCurves_With_FlatPriceCurves()
        {
            var manualCurves = new []
                {
                    new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101).WithEomRollAction(EomRollAction.ShiftAnchor).Build(),
                    new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(102).WithEomRollAction(EomRollAction.NoAction).Build()
                };

            var errors = new List<string> { "error" };

            var testObjects = new CurveValidationRulesServiceTestObjectBuilder().WithFlatPriceCurvesValidationResult(errors)
                                                                                .Build();

            // ACT
            var result = testObjects.CurveValidationRulesService.ValidateFlatPriceCurves(manualCurves);

            // ASSERT
            Mock.Get(testObjects.MonthEndRollValidationService)
                                .Verify(m => m.ValidateFlatPriceCurves(It.Is<List<ManualCurveDefinition<MonthlyTenor>>>(c => c.Count == 1
                                                                                                                        && c[0].Id == 101)));

            CollectionAssert.AreEqual(errors, result);
        }

        [Test]
        public void ShouldValidateManualCurvesLength_With_NonFlatPriceCurves()
        {
            var manualCurves = new []
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101).WithEomRollAction(EomRollAction.ShiftAnchor).Build(),
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(102).WithEomRollAction(EomRollAction.ExtendCurve).Build()
            };

            var errors = new List<string> { "error" };

            var testObjects = new CurveValidationRulesServiceTestObjectBuilder().WithManualCurveLengthsValidationResult(errors)
                                                                                .Build();

            // ACT
            var result = testObjects.CurveValidationRulesService.ValidateManualCurves(manualCurves);

            // ASSERT
            Mock.Get(testObjects.MonthEndRollValidationService)
                .Verify(m => m.ValidateManualCurvesLength(It.Is<List<ManualCurveDefinition<MonthlyTenor>>>(c => c.Count == 1
                                                                                                                && c[0].Id == 102)));

            CollectionAssert.AreEqual(errors, result);
        }
    }
}
