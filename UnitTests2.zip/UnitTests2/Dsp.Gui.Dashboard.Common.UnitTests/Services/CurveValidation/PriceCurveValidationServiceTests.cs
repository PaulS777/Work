﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.CurveValidation;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.CurveValidation
{
    public interface IPriceCurveValidationServiceTestObjects
    {
        ICurveValidationRulesService ValidationRules { get; }
        ISubject<IList<ManualCurveDefinition<MonthlyTenor>>> ManualCurveDefinitions { get; }
        PriceCurveValidationService PriceCurveValidationService { get; }
    }

    [TestFixture]
    public class PriceCurveValidationServiceTests
    {
        private class PriceCurveValidationServiceTestObjectBuilder
        {
            private List<string> _flatPriceCurvesValidationResult;
            private List<string> _manualCurveLengthsValidationResult;

            public PriceCurveValidationServiceTestObjectBuilder WithFlatPriceCurvesValidationResult(List<string> values)
            {
                _flatPriceCurvesValidationResult = values;
                return this;
            }

            public PriceCurveValidationServiceTestObjectBuilder WithManualCurveLengthsValidationResult(List<string> values)
            {
                _manualCurveLengthsValidationResult = values;
                return this;
            }

            public IPriceCurveValidationServiceTestObjects Build()
            {
                var testObjects = new Mock<IPriceCurveValidationServiceTestObjects>();

                var manualCurveDefinitions = new Subject<IList<ManualCurveDefinition<MonthlyTenor>>>();

                testObjects.SetupGet(o => o.ManualCurveDefinitions)
                           .Returns(manualCurveDefinitions);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ManualCurveDefinitions)
                                   .Returns(manualCurveDefinitions);

                var validationRules = new Mock<ICurveValidationRulesService>();

                validationRules.Setup(r => r.ValidateFlatPriceCurves(It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>()))
                               .Returns(_flatPriceCurvesValidationResult);

                validationRules.Setup(r => r.ValidateManualCurves(It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>()))
                               .Returns(_manualCurveLengthsValidationResult);

                testObjects.SetupGet(o => o.ValidationRules)
                           .Returns(validationRules.Object);

                var priceCurveValidationService = new PriceCurveValidationService(curveControlService.Object,
                                                                                  validationRules.Object);

                testObjects.SetupGet(o => o.PriceCurveValidationService)
                           .Returns(priceCurveValidationService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldValidateCurves_On_ManualCurves()
        {
            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
                {
                    new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101).WithEomRollAction(EomRollAction.ShiftAnchor).Build()
                };

            var testObjects = new PriceCurveValidationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ManualCurveDefinitions.OnNext(manualCurves);

            // ASSERT
            Mock.Get(testObjects.ValidationRules)
                .Verify(m => m.ValidateFlatPriceCurves(manualCurves));

            Mock.Get(testObjects.ValidationRules)
                .Verify(m => m.ValidateManualCurves(manualCurves));
        }

        [Test]
        public void ShouldPublishFlatPriceCurveValidationResult()
        {
            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
                {
                    new ManualCurveDefinitionBuilder < MonthlyTenor >().WithId(101).WithEomRollAction(EomRollAction.ShiftAnchor).Build()
                };

            var errors = new List<string> { "error" };

            var testObjects = new PriceCurveValidationServiceTestObjectBuilder().WithFlatPriceCurvesValidationResult(errors)
                                                                                .Build();

            List<string> result = null;

            using (testObjects.PriceCurveValidationService.FlatPriceCurveErrors.Subscribe(e => result = e))
            {
                // ACT
                testObjects.ManualCurveDefinitions.OnNext(manualCurves);

                // ASSERT
                Assert.That(result is { Count: 1 });
            }
        }

        [Test]
        public void ShouldPublishManualCurveLengthValidationResult()
        {
            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
                {
                    new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101).WithEomRollAction(EomRollAction.ExtendCurve).Build()
                };

            var errors = new List<string> { "error" };

            var testObjects = new PriceCurveValidationServiceTestObjectBuilder().WithManualCurveLengthsValidationResult(errors)
                                                                                .Build();

            List<string> result = null;

            using (testObjects.PriceCurveValidationService.CurveLengthErrors.Subscribe(e => result = e))
            {
                // ACT
                testObjects.ManualCurveDefinitions.OnNext(manualCurves);

                // ASSERT
                Assert.That(result is { Count: 1 });
            }
        }

        [Test]
        public void ShouldNotValidateCurves_When_Disposed()
        {
            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101).WithEomRollAction(EomRollAction.ExtendCurve).Build()
            };

            var testObjects = new PriceCurveValidationServiceTestObjectBuilder().Build();

            testObjects.PriceCurveValidationService.Dispose();

            // ACT
            testObjects.ManualCurveDefinitions.OnNext(manualCurves);

            // ASSERT
            Mock.Get(testObjects.ValidationRules)
                .Verify(m => m.ValidateFlatPriceCurves(It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>()), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder < MonthlyTenor >().WithId(101).WithEomRollAction(EomRollAction.ExtendCurve).Build()
            };

             var testObjects = new PriceCurveValidationServiceTestObjectBuilder().Build();

            testObjects.PriceCurveValidationService.Dispose();

            // ACT
            testObjects.PriceCurveValidationService.Dispose();
            testObjects.ManualCurveDefinitions.OnNext(manualCurves);

            // ASSERT
            Mock.Get(testObjects.ValidationRules)
                .Verify(m => m.ValidateFlatPriceCurves(It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>()), Times.Never);
        }
    }
}
