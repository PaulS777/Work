﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Subjects;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Exceptions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.AdminUpdate
{
    public interface IAdminUpdateServiceServiceTestObjects
    {
        IAdminApiServiceClient AdminApiServiceClient { get; }

        IAdminUpdateService<IIdentifiable> AdminUpdateService { get; }

        ISubject<Unit> ServiceUpdate { get; }
    }

    [TestFixture]
    public class AdminUpdateServiceTests
    {
        private class AdminUpdateServiceTestObjectBuilder
        {
            private AdminApiServiceResponse _updateResponse;
            private AdminApiServiceResponse _addResponse;
            private Exception _serviceException;

            public AdminUpdateServiceTestObjectBuilder WithUpdateResponse(AdminApiServiceResponse value)
            {
                _updateResponse = value;
                return this;
            }

            public AdminUpdateServiceTestObjectBuilder WithAddResponse(AdminApiServiceResponse value)
            {
                _addResponse = value;
                return this;
            }

            public AdminUpdateServiceTestObjectBuilder WithUpdateResponseException(Exception value)
            {
                _serviceException = value;
                return this;
            }

            public IAdminUpdateServiceServiceTestObjects Build()
            {
                var testObjects = new Mock<IAdminUpdateServiceServiceTestObjects>();

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                if (_serviceException == null)
                {
                    adminApiServiceClient.Setup(a => a.Update(It.IsAny<int>(), It.IsAny<IIdentifiable>()))
                                         .Returns(Task.FromResult(_updateResponse));

                    adminApiServiceClient.Setup(a => a.Update(It.IsAny<IList<IIdentifiable>>()))
                                         .Returns(Task.FromResult(_updateResponse));
                }
                else
                {
                    adminApiServiceClient.Setup(a => a.Update(It.IsAny<int>(), It.IsAny<IIdentifiable>()))
                                         .Throws(_serviceException);

                    adminApiServiceClient.Setup(a => a.Update(It.IsAny<IList<IIdentifiable>>()))
                                         .Throws(_serviceException);
                }

                adminApiServiceClient.Setup(a => a.Add(It.IsAny<IIdentifiable>()))
                                     .Returns(Task.FromResult(_addResponse));

                adminApiServiceClient.Setup(a => a.Add(It.IsAny<IList<IIdentifiable>>()))
                                     .Returns(Task.FromResult(_addResponse));

                testObjects.SetupGet(o => o.AdminApiServiceClient)
                           .Returns(adminApiServiceClient.Object);

                var userUpdated = new Subject<Unit>();

                testObjects.SetupGet(o => o.ServiceUpdate)
                           .Returns(userUpdated);

                var adminUpdateService = new AdminUpdateService<IIdentifiable>(adminApiServiceClient.Object,
                                                                               TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.AdminUpdateService)
                           .Returns(adminUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInvokeAdminApiUpdate_With_Id_When_UpdateItem()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(true);

            var testObjects = new AdminUpdateServiceTestObjectBuilder().WithUpdateResponse(response)
                                                                       .Build();

            var value = Mock.Of<IIdentifiable>(m => m.Id == 10);

            // ACT
            using (testObjects.AdminUpdateService.Update(value, testScheduler)
                              .Subscribe(_ => { }))
            {
                testScheduler.AdvanceBy(10);

                // ASSERT
                Mock.Get(testObjects.AdminApiServiceClient)
                    .Verify(a => a.Update(10, value));
            }
        }

        [Test]
        public void ShouldInvokeAdminApiUpdate_With_When_UpdateList()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(true);

            var testObjects = new AdminUpdateServiceTestObjectBuilder().WithUpdateResponse(response)
                                                                       .Build();

            var values = new [] {Mock.Of<IIdentifiable>(m => m.Id == 10)};

            // ACT
            using (testObjects.AdminUpdateService.Update(values, testScheduler)
                              .Subscribe(_ => { }))
            {
                testScheduler.AdvanceBy(10);

                // ASSERT
                Mock.Get(testObjects.AdminApiServiceClient)
                    .Verify(a => a.Update(It.Is<IList<IIdentifiable>>(ids => ids[0].Id == 10)));
            }
        }

        [Test]
        public void ShouldInvokeAdd_WithItem_When_Add()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(true);

            var testObjects = new AdminUpdateServiceTestObjectBuilder().WithAddResponse(response)
                                                                       .Build();

            var value = Mock.Of<IIdentifiable>(m => m.Id == 0);

            // ACT
            using (testObjects.AdminUpdateService.Add(value, testScheduler)
                              .Subscribe(_ => { }))
            {
                testScheduler.AdvanceBy(10);

                // ASSERT
                Mock.Get(testObjects.AdminApiServiceClient)
                    .Verify(a => a.Add(value));
            }
        }

        [Test]
        public void ShouldInvokeAdd_WithItems_When_AddList()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(true);

            var testObjects = new AdminUpdateServiceTestObjectBuilder().WithAddResponse(response)
                                                                       .Build();

            var values = new[] { Mock.Of<IIdentifiable>(m => m.Id == 0) };

            // ACT
            using (testObjects.AdminUpdateService.Add(values, testScheduler)
                              .Subscribe(_ => { }))
            {
                testScheduler.AdvanceBy(10);

                // ASSERT
                Mock.Get(testObjects.AdminApiServiceClient)
                    .Verify(a => a.Add(It.IsAny<IList<IIdentifiable>>()));
            }
        }

        [Test]
        public void ShouldInvokeUpdateChatUserWithTenors_WithItem_When_UpdateChatUserTenors()
        {
            var testScheduler = new TestScheduler();

            var testObjects = new AdminUpdateServiceTestObjectBuilder().Build();

            var user = new UserBuilder().WithId(10).User();

            // ACT
            using (testObjects.AdminUpdateService.UpdateUserChatTenors(user, testScheduler)
                              .Subscribe(_ => { }))
            {
                testScheduler.AdvanceBy(10);

                // ASSERT
                Mock.Get(testObjects.AdminApiServiceClient)
                    .Verify(a => a.UpdateChatTenorSelection(user));
            }
        }

        [Test]
        public void ShouldPublishCompleted_On_Update_ResponseSuccess()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(true);

            var testObjects = new AdminUpdateServiceTestObjectBuilder().WithUpdateResponse(response)
                                                                       .Build();

            var completed = false;

            var value = Mock.Of<IIdentifiable>();

            using (testObjects.AdminUpdateService.Update(value, testScheduler)
                              .Subscribe(_ => { },
                                         () => completed = true))
            {
                // ACT
                testObjects.ServiceUpdate.OnNext(Unit.Default);
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(completed, Is.True);
            }
        }

        [Test]
        public void ShouldPublishError_On_UpdateResponseError()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(AdminApiServiceResponseReason.DspServerError);

            var testObjects = new AdminUpdateServiceTestObjectBuilder().WithUpdateResponse(response)
                                                                       .Build();

            var value = Mock.Of<IIdentifiable>();

            Exception result = null;

            using (testObjects.AdminUpdateService
                              .Update(value, testScheduler)
                              .Subscribe(_ => { },
                                         ex => result = ex))
            {
                // ACT
                testObjects.ServiceUpdate.OnNext(Unit.Default);
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.AreEqual(response.ReasonText, result.Message);
                Assert.IsNull(result.InnerException);
            }
        }

        [Test]
        public void ShouldPublishError_With_PricingFailures_On_UpdateResponseError_WithPricingFailures()
        {
            var testScheduler = new TestScheduler();

            var response = new AdminApiServiceResponse(AdminApiServiceResponseReason.DspServerError,
                                                       new List<PricingFailure>
                                                       {
                                                           new PricingFailure(101,
                                                                              201,
                                                                              PricingFailureReason.AnchorPointTenorReferenceNotFound,
                                                                              new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                                              "failed")
                                                       });

            var testObjects = new AdminUpdateServiceTestObjectBuilder().WithUpdateResponse(response)
                                                                       .Build();

            var value = Mock.Of<IIdentifiable>();

            Exception result = null;

            using (testObjects.AdminUpdateService
                              .Update(value, testScheduler)
                              .Subscribe(_ => { },
                                         ex => result = ex))
            {
                // ACT
                testObjects.ServiceUpdate.OnNext(Unit.Default);
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.AreEqual(response.ReasonText, result.Message);
                Assert.That(result.InnerException is PricingFailuresException ex && ex.PricingFailures.Count == 1);
            }
        }

        [Test]
        public void ShouldPublishError_On_UpdateResponseException()
        {
            var testScheduler = new TestScheduler();

            var exception = new Exception("error");

            var testObjects = new AdminUpdateServiceTestObjectBuilder().WithUpdateResponseException(exception)
                                                                       .Build();
            var calendar = new Calendar();

            Exception result = null;

            using (testObjects.AdminUpdateService.Update(calendar, testScheduler)
                              .Subscribe(_ => { },
                                         ex => result = ex))
            {
                // ACT
                testObjects.ServiceUpdate.OnNext(Unit.Default);
                testScheduler.AdvanceBy(10);

                // ASSERT
                Assert.IsNotNull(result);
            }
        }
    }
}
