﻿using System;
using Dsp.Gui.Dashboard.Common.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    [TestFixture]
    public class PopupNotificationServiceTests
    {
        [Test]
        public void ShouldPublishPopupNotificationArgs()
        {
            var service = new PopupNotificationService();

            PopupNotificationArgs result = null;

            using (service.OnPopupNotification.Subscribe(args => result = args))
            {
                // TEST
                service.SendPopupNotification("line-1", "line-2");

                // ACT
                Assert.That(result.MessageLine1, Is.EqualTo("line-1"));
                Assert.That(result.MessageLine2, Is.EqualTo("line-2"));
            }
        }

        [Test]
        public void ShouldNotPublishPopupNotificationArgs_When_Disposed()
        {
            var service = new PopupNotificationService();

            PopupNotificationArgs result = null;

            using (service.OnPopupNotification.Subscribe(args => result = args))
            {
                service.Dispose();

                // TEST
                service.SendPopupNotification("line-1", "line-2");

                // ACT
                Assert.That(result, Is.Null);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var service = new PopupNotificationService();

            PopupNotificationArgs result = null;

            using (service.OnPopupNotification.Subscribe(args => result = args))
            {
                service.Dispose();

                // TEST
                service.Dispose();
                service.SendPopupNotification("line-1", "line-2");

                // ACT
                Assert.That(result, Is.Null);
            }
        }
    }
}
