﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Configuration;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.CurveValidation;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts.MonthEndRoll;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    public interface IRollPricesStatusProviderTestObjects
    {
        IMonthEndRollValidationService MonthEndRollValidationService { get; }
        ICurveValidationRulesService ValidationRules { get; }
        ISubject<List<MonthEndRollStatus>> MonthEndRollStatus { get; }
        ISubject<IList<ManualCurveDefinition<MonthlyTenor>>> ManualCurveDefinitions { get; }
        ICurrentBusinessDateProvider CurrentBusinessDateProvider { get; }
        TestScheduler TestScheduler { get; }
        RollPricesStatusProvider RollPricesStatusProvider { get; }
    }

    [TestFixture]
    public class RollPricesStatusProviderTests
    {
        private class RollPricesStatusProviderTestObjectBuilder
        {
            private IList<ManualCurveDefinition<MonthlyTenor>> _manualCurvesDefinitions = Array.Empty<ManualCurveDefinition<MonthlyTenor>>();

            private List<MonthEndRollStatus> _monthEndRollStatus;
            private List<MonthEndRollStatus> _monthEndRollStatusSnapshot = new();

            private DateTime _timestamp;
            private DateTime? _timestampNext;
            private bool _canMonthEndRoll;
            private bool _canMonthEndRollNext;
            private Exception _canMonthEndRollException;
            private List<string> _validateFlatPriceCurves = new();
            private List<string> _validateManualCurves = new();
            private DynamicConfiguration _rollWindowConfig = new(1, string.Empty, string.Empty, string.Empty);

            public RollPricesStatusProviderTestObjectBuilder WithManualCurveDefinitions(IList<ManualCurveDefinition<MonthlyTenor>> values)
            {
                _manualCurvesDefinitions = values;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithMonthEndRollStatus(List<MonthEndRollStatus> value)
            {
                _monthEndRollStatus = value;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithMonthEndRollStatusSnapshot(List<MonthEndRollStatus> value)
            {
                _monthEndRollStatusSnapshot = value;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithCanMonthEndRoll(bool value)
            {
                _canMonthEndRoll = value;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithCanMonthEndRollNext(bool value)
            {
                _canMonthEndRollNext = value;
                return this;
            }
            public RollPricesStatusProviderTestObjectBuilder WithCanMonthEndRollException(Exception value)
            {
                _canMonthEndRollException = value;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithValidateFlatPriceCurves(List<string> values)
            {
                _validateFlatPriceCurves = values;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithValidateManualCurves(List<string> values)
            {
                _validateManualCurves = values;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithTimestamp(DateTime value)
            {
                _timestamp = value;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithTimestampNext(DateTime value)
            {
                _timestampNext = value;
                return this;
            }

            public RollPricesStatusProviderTestObjectBuilder WithRollWindowConfig(DynamicConfiguration value)
            {
                _rollWindowConfig = value;
                return this;
            }

            public IRollPricesStatusProviderTestObjects Build()
            {
                var testObjects = new Mock<IRollPricesStatusProviderTestObjects>();

                var testScheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
                schedulerProvider.SetupGet(p => p.Immediate).Returns(Scheduler.Immediate);

                var rollHistory = new BehaviorSubject<List<MonthEndRollStatus>>(_monthEndRollStatus);

                testObjects.SetupGet(o => o.MonthEndRollStatus)
                           .Returns(rollHistory);

                var manualCurveDefinitions = new BehaviorSubject<IList<ManualCurveDefinition<MonthlyTenor>>>(_manualCurvesDefinitions);

                testObjects.SetupGet(o => o.ManualCurveDefinitions)
                           .Returns(manualCurveDefinitions);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.ManualCurveDefinitions)
                                   .Returns(manualCurveDefinitions);

                curveControlService.Setup(o => o.GetManualCurveDefinitionsSnapshot())
                                   .Returns(Array.Empty<ManualCurveDefinition<MonthlyTenor>>());

                curveControlService.SetupGet(o => o.MonthEndRollStatusOnUpdate)
                                   .Returns(rollHistory);

                curveControlService.Setup(o => o.GetMonthEndRollStatusSnapshot())
                                   .Returns(_monthEndRollStatusSnapshot);

               var config = new List<DynamicConfiguration>{_rollWindowConfig};

                curveControlService.SetupGet(o => o.ConfigurationOnUpdate)
                                   .Returns(Observable.Return(config));

                curveControlService.Setup(o => o.GetConfigurationSnapshot())
                                   .Returns(config);

                var validationService = new Mock<IMonthEndRollValidationService>();

                validationService.Setup(v => v.GetCurrentRollMonth(It.IsAny<DateTime>()))
                                 .Returns(new Func<DateTime, DateOnly>(d => new DateOnly(d.Year, d.Month, 1)));

                if (_canMonthEndRollException == null)
                {
                    validationService.SetupSequence(v => v.CanMonthEndRoll(
                                                        It.IsAny<DateOnly>(),
                                                        It.IsAny<RollStatus>(),
                                                        It.IsAny<DateTime>(),
                                                        It.IsAny<int>()))
                                     .Returns(_canMonthEndRoll)
                                     .Returns(_canMonthEndRollNext);
                }
                else
                {
                    validationService.Setup(v => v.CanMonthEndRoll(It.IsAny<DateOnly>(),
                                                                   It.IsAny<RollStatus>(),
                                                                   It.IsAny<DateTime>(),
                                                                   It.IsAny<int>()))
                                     .Throws(_canMonthEndRollException);
                }

                testObjects.SetupGet(o => o.MonthEndRollValidationService)
                           .Returns(validationService.Object);

                var currentBusinessDateProvider = new Mock<ICurrentBusinessDateProvider>();

                if (_timestampNext.HasValue)
                {
                    currentBusinessDateProvider.SetupSequence(p => p.CurrentDate)
                                    .Returns(_timestamp)
                                    .Returns(_timestampNext.Value);
                }
                else
                {
                    currentBusinessDateProvider.Setup(p => p.CurrentDate)
                                               .Returns(_timestamp);
                }

                testObjects.SetupGet(o => o.CurrentBusinessDateProvider)
                           .Returns(currentBusinessDateProvider.Object);

                var validationRules = new Mock<ICurveValidationRulesService>();

                validationRules.Setup(r => r.ValidateFlatPriceCurves(It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>()))
                               .Returns(_validateFlatPriceCurves);

                validationRules.Setup(r => r.ValidateManualCurves(It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>()))
                               .Returns(_validateManualCurves);

                testObjects.SetupGet(o => o.ValidationRules)
                           .Returns(validationRules.Object);

                var rollPricesStatusProvider = new RollPricesStatusProvider(curveControlService.Object,
                                                                            validationService.Object,
                                                                            validationRules.Object,
                                                                            currentBusinessDateProvider.Object,
                                                                            schedulerProvider.Object, 
                                                                            TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.RollPricesStatusProvider)
                           .Returns(rollPricesStatusProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishStatusWindowClosed_When_NoRollHistoryToday_And_CanMonthEndRollFalse()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithCanMonthEndRoll(false)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            // ACT
            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.WindowClosed));
            }
        }

        [Test, Ignore("Change of approach - 2023-10-03")]
        public void ShouldPublishStatusRolling_When_RollHistoryToday_With_StatusRolling()
        {
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            // ACT
            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.Rolling));
            }
        }

        [Test]
        public void ShouldPublishStatusCompleted_When_RollHistoryToday_With_StatusCompleted()
        {
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate)
            };

            var monthEndRollStatusesCompleted = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Completed, rollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                // ACT
                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatusesCompleted);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.Completed));
            }
        }

        [Test]
        public void ShouldNotPublishStatusCompleted_When_StatusCompleted_AlreadyPublished()
        {
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Completed, rollDate)
            };

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                .Build()
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .Build();

            var count = 0;
            var status = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus =>
                               {
                                   count++;
                                   status = serviceStatus;
                               }))
            {
                // ACT
                testObjects.ManualCurveDefinitions.OnNext(manualCurves);

                // ASSERT
                Assert.That(count, Is.EqualTo(1));
                Assert.That(status, Is.EqualTo(MonthEndRollPricesStatus.Completed));
            }
        }

        [Test]
        public void ShouldPublishStatusWindowClosed_When_ValidationThrowsException_With_NoRollHistoryToday()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                .Build()
            };

            var validationException = new Exception("error");

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithCanMonthEndRollException(validationException)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(status =>
                               {
                                   result = status;
                               }))
            {
                // ACT
                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatuses);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.WindowClosed));
            }
        }

        [Test]
        public void ShouldPublishStatusWindowClosed_OnTimerInterval_With_ValidationThrowsException()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                .Build()
            };

            var validationException = new Exception("error");

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithCanMonthEndRollException(validationException)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(status =>
                               {
                                   result = status;
                               }))
            {
                result = MonthEndRollPricesStatus.NotRolled;

                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(61).Ticks);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.WindowClosed));
            }
        }

        [Test]
        public void ShouldNotPublishStatusCompleted_OnTimer_With_RollHistoryToday_With_StatusCompleted()
        {
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate)
            };

            var monthEndRollStatusesCompleted = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Completed, rollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithMonthEndRollStatusSnapshot(monthEndRollStatusesCompleted)
                                                                             .Build();
            var result = 0;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(status =>
                               {
                                   if (status == MonthEndRollPricesStatus.Completed)
                                       result++;
                               }))
            {
                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatusesCompleted);

                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(61).Ticks);

                // ASSERT
                Assert.That(result, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldGetLatestMonthEndRollStatus_When_RollHistoryToday_With_StatusCompleted()
        {
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate)
            };

            var monthEndRollStatusesCompleted = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Completed, rollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .Build();
            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(_ => { }))
            {
                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatusesCompleted);


                // ACT
                var result = testObjects.RollPricesStatusProvider.GetLatestMonthEndRollStatus();

                // ASSERT
                Assert.That(result.RollStatus, Is.EqualTo(RollStatus.Completed));
            }
        }

        [Test]
        public void ShouldGetLatestMonthEndRollStatus_When_RollHistoryToday_With_StatusFailed()
        {
            var rollDate = new DateTime(2021, 2, 1);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate)
            };

            var monthEndRollStatusesCompleted = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Failed, rollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .Build();
            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(_ => { }))
            {
                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatusesCompleted);


                // ACT
                var result = testObjects.RollPricesStatusProvider.GetLatestMonthEndRollStatus();

                // ASSERT
                Assert.That(result.RollStatus, Is.EqualTo(RollStatus.Failed));
            }
        }

        [Test, Ignore("Change of approach - 2023-10-03")]
        public void ShouldUseRollWindowConfig_When_ValidatingCanMonthEndRoll()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var rollWindowConfig = new DynamicConfiguration(1, PermissionCategory.EomRoll.ToString(), ConfigurationName.EomRollWindow.ToString(), "7");

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithRollWindowConfig(rollWindowConfig)
                                                                             .Build();
            // ASSERT
            Mock.Get(testObjects.MonthEndRollValidationService)
                .Verify(v => v.CanMonthEndRoll(historicRollDate.ToDateOnly(), RollStatus.Completed, rollDate, 7));
        }

        [Test, Ignore("Change of approach - 2023-10-03")]
        public void ShouldValidateCanMonthEndRoll_With_Default_WhenRollWindowConfigMissing()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var config = new DynamicConfiguration(1, "test","test", string.Empty);

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithRollWindowConfig(config)
                                                                             .Build();
            // ASSERT
            Mock.Get(testObjects.MonthEndRollValidationService)
                .Verify(v => v.CanMonthEndRoll(historicRollDate.ToDateOnly(), RollStatus.Completed, rollDate, 5));
        }

        [Test]
        public void ShouldPublishStatusNotRolled_When_NoRollHistoryToday_And_CanMonthEndRollTrue_With_NoValidationErrors()
        {
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                .WithOverrides(new List<CurvePoint<MonthlyTenor>>{new(new MonthlyTenor(2021, 1), 1.0)})
                                                                .Build()
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            // ACT
            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.NotRolled));
            }
        }

        [Test, Ignore("Change of approach - 2023-10-03")]
        [TestCase(RollStatus.AutoRollFailed)]
        [TestCase(RollStatus.Failed)]
        public void ShouldPublishStatusNotRolled_When_LatestTodayHistoryResetAfterFailed_And_CanMonthEndRollTrue_With_NoValidationErrors(RollStatus failedStatus)
        {
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), failedStatus, new DateTime(2021, 2, 1, 9, 0, 0)),
                new(rollDate.ToDateOnly(), RollStatus.Reset, new DateTime(2021, 2, 1, 12, 0, 0))
            };

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                .WithOverrides(new List<CurvePoint<MonthlyTenor>>{new(new MonthlyTenor(2021, 1), 1.0)})
                                                                .Build()
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.AutoRollFailed;

            // ACT
            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatuses);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.NotRolled));
            }
        }

        [Test, Ignore("Change of approach - 2023-10-03")]
        public void ShouldPublishStatusFailed_When_LatestTodayHistoryFailedAfterReset()
        {
            var rollDate = new DateTime(2021, 2, 1);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new MonthEndRollStatus(rollDate.ToDateOnly(), RollStatus.Reset, new DateTime(2021, 2, 1, 9, 0, 0)),
                new MonthEndRollStatus(rollDate.ToDateOnly(), RollStatus.Failed, new DateTime(2021, 2, 1, 12, 0, 0))
                
            };

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                .WithOverrides(new List<CurvePoint<MonthlyTenor>>{new(new MonthlyTenor(2021, 1), 1.0)})
                                                                .Build()
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.AutoRollFailed;

            // ACT
            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatuses);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.ManualRollFailed));
            }
        }

        [Test]
        public void ShouldValidateCurves_When_CurvesUpdated_With_NoRollHistoryToday_And_CanMonthEndRollTrue()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new[]
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                .WithEomRollAction(EomRollAction.ShiftAnchor)
                                                                .WithOverrides(new List<CurvePoint<MonthlyTenor>>{new(new MonthlyTenor(2021, 1), 1.0)})
                                                                .Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .WithCanMonthEndRollNext(true)
                                                                             .Build();
   
            Mock.Get(testObjects.MonthEndRollValidationService).Invocations.Clear();

            // ACT
            testObjects.ManualCurveDefinitions.OnNext(manualCurves);

            // ASSERT
            Mock.Get(testObjects.ValidationRules)
                .Verify(v => v.ValidateFlatPriceCurves(It.Is<IList<ManualCurveDefinition<MonthlyTenor>>>(m => m.SequenceEqual(manualCurves))));

            Mock.Get(testObjects.ValidationRules)
                .Verify(v => v.ValidateManualCurves(manualCurves));
        }

        [Test]
        public void ShouldPublishValidationFailed_When_FlatPriceMonthEndInvalid_With_NoRollHistoryToday_And_CanMonthEndRollTrue()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                .WithEomRollAction(EomRollAction.ShiftAnchor)
                                                                .WithOverrides(new List<CurvePoint<MonthlyTenor>>{new(new MonthlyTenor(2021, 1), 1.0)})
                                                                .Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var validation = new List<string> {"bad-curve"};

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithManualCurveDefinitions(null)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .WithCanMonthEndRollNext(true)
                                                                             .WithValidateFlatPriceCurves(validation)
                                                                             .Build();

            var result = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                // ACT
                testObjects.ManualCurveDefinitions.OnNext(manualCurves);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.ValidationFailed));
            }
        }

        [Test]
        public void ShouldPublishValidationFailed_When_ManualCurveLengthInvalid_With_NoRollHistoryToday_And_CanMonthEndRollTrue()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder < MonthlyTenor >().WithId(101)
                                                                .WithEomRollAction(EomRollAction.ExtendCurve)
                                                                .WithOverrides(new List<CurvePoint<MonthlyTenor>>{new CurvePoint<MonthlyTenor>(new MonthlyTenor(2021, 1), 1.0)})
                                                                .Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var validation = new List<string> { "bad-curve" };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithManualCurveDefinitions(null)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .WithCanMonthEndRollNext(true)
                                                                             .WithValidateManualCurves(validation)
                                                                             .Build();

            var result = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                // ACT
                testObjects.ManualCurveDefinitions.OnNext(manualCurves);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.ValidationFailed));
            }
        }

        [Test]
        public void ShouldGetFlatPriceValidationErrors()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder < MonthlyTenor >().WithId(101)
                                                                .WithEomRollAction(EomRollAction.ShiftAnchor)
                                                                .WithOverrides(new List<CurvePoint<MonthlyTenor>>{new(new MonthlyTenor(2021, 1), 1.0)})
                                                                .Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var validation = new List<string> { "bad-curve" };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .WithCanMonthEndRollNext(true)
                                                                             .WithValidateFlatPriceCurves(validation)
                                                                             .Build();

            var result = testObjects.RollPricesStatusProvider.GetFlatPriceValidationErrors();

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldGetManualCurveValidationErrors()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                              .WithEomRollAction(EomRollAction.ShiftAnchor)
                                                                              .WithOverrides(new List<CurvePoint<MonthlyTenor>> { new(new MonthlyTenor(2021, 1), 1.0) })
                                                                              .Build();

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>> { manualCurve };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var validation = new List<string> { "bad-curve" };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .WithCanMonthEndRollNext(true)
                                                                             .WithValidateManualCurves(validation)
                                                                             .Build();

            var result = testObjects.RollPricesStatusProvider.GetCurveLengthValidationErrors();

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldPublishStatusNotRolled_OnTimer_With_DayRolled_And_NoRollHistory_And_CanMonthEndRollTrue()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var today = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithTimestampNext(today)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(61).Ticks);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.NotRolled));
            }
        }

        [Test]
        public void ShouldPublishStatusWindowClosed_OnTimer_With_DayRolled_And_NoRollHistory_And_CanMonthEndRollFalse()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var today = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithTimestampNext(today)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithCanMonthEndRoll(false)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(61).Ticks);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.WindowClosed));
            }
        }

        [Test, Ignore("Change of approach - 2023-10-03")]
        public void ShouldPublishStatusUpdatesSequenceAcrossRollWindowTransition()
        {
            var rollDate = new DateTime(2021, 1, 1);
            var rollDate1Next = new DateTime(2021, 1, 2);

            var monthEndNoHistory = new List<MonthEndRollStatus>();

            var monthEndHistoryRolling = new List<MonthEndRollStatus>
            {
                new MonthEndRollStatus(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate)
            };

            var monthEndHistoryCompleted = new List<MonthEndRollStatus>
            {
                new MonthEndRollStatus(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate),
                new MonthEndRollStatus(rollDate.ToDateOnly(), RollStatus.Completed, rollDate)
            };

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101).Build()
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .WithMonthEndRollStatus(monthEndNoHistory)
                                                                             .WithMonthEndRollStatusSnapshot(monthEndHistoryCompleted)
                                                                             .Build();
            var count = 0;
            var status = MonthEndRollPricesStatus.NotRolled;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus =>
                              {
                                  count++;
                                  status = serviceStatus;
                              }))
            {
                // ACT - Start of Roll Window
                Assert.That(count, Is.EqualTo(1));
                // ASSERT
                Assert.That(status, Is.EqualTo(MonthEndRollPricesStatus.NotRolled));

                // ACT - Rolling
                testObjects.MonthEndRollStatus.OnNext(monthEndHistoryRolling);
                // ASSERT
                Assert.That(count, Is.EqualTo(2));
                Assert.That(status, Is.EqualTo(MonthEndRollPricesStatus.Rolling));

                // ACT- Completed
                testObjects.MonthEndRollStatus.OnNext(monthEndHistoryCompleted);
                // ASSERT
                Assert.That(count, Is.EqualTo(3));
                Assert.That(status, Is.EqualTo(MonthEndRollPricesStatus.Completed));

                // ACT - Curve Update after Completed
                testObjects.ManualCurveDefinitions.OnNext(manualCurves);
                // ASSERT
                Assert.That(count, Is.EqualTo(3));
                Assert.That(status, Is.EqualTo(MonthEndRollPricesStatus.Completed));

                // ACT - Timer after Completed
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(61).Ticks);
                // ASSERT
                Assert.That(count, Is.EqualTo(3));
                Assert.That(status, Is.EqualTo(MonthEndRollPricesStatus.Completed));

                // ACT - Next Day
                Mock.Get(testObjects.CurrentBusinessDateProvider)
                    .Setup(dt => dt.CurrentDate).Returns(rollDate1Next);

                Mock.Get(testObjects.MonthEndRollValidationService)
                    .Setup(v => v.CanMonthEndRoll(It.IsAny<DateOnly>(),
                                                  It.IsAny<RollStatus>(),
                                                  It.IsAny<DateTime>(),
                                                  It.IsAny<int>()))
                    .Returns(false);

                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromHours(24).Ticks);
                // ASSERT
                Assert.That(count, Is.EqualTo(4));
                Assert.That(status, Is.EqualTo(MonthEndRollPricesStatus.WindowClosed));
            }
        }

        [Test]
        public void ShouldNotPublishDuplicateStatus_OnTimer_With_NoRollHistory()
        {
            var historicRollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var rollDate = new DateTime(2021, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            var today = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var manualCurves = new List<ManualCurveDefinition<MonthlyTenor>>
            {
                new ManualCurveDefinitionBuilder<MonthlyTenor>().Build()
            };

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(historicRollDate.ToDateOnly(), RollStatus.Completed, historicRollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithTimestampNext(today)
                                                                             .WithManualCurveDefinitions(manualCurves)
                                                                             .WithMonthEndRollStatus(monthEndRollStatuses)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .WithCanMonthEndRollNext(true)
                                                                             .Build();
            var result = 0;

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus =>
                               {
                                   if (serviceStatus == MonthEndRollPricesStatus.NotRolled)
                                       result++;
                               }))
            {
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(61).Ticks);

                // ACT
                testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(61).Ticks);

                // ASSERT
                Assert.That(result, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotPublishMonthEndRollStatusRolling_When_Disposed()
        {
            var rollDate = new DateTime(2021, 2, 1);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new MonthEndRollStatus(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate)
            };

            var validation = new List<string>();

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .WithValidateFlatPriceCurves(validation)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            testObjects.RollPricesStatusProvider.Dispose();

            // ACT
            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatuses);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.NotRolled));
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var rollDate = new DateTime(2021, 2, 1, 0, 0, 0, DateTimeKind.Utc);

            var monthEndRollStatuses = new List<MonthEndRollStatus>
            {
                new(rollDate.ToDateOnly(), RollStatus.Rolling, rollDate)
            };

            var testObjects = new RollPricesStatusProviderTestObjectBuilder().WithTimestamp(rollDate)
                                                                             .WithCanMonthEndRoll(true)
                                                                             .Build();
            var result = MonthEndRollPricesStatus.NotRolled;

            testObjects.RollPricesStatusProvider.Dispose();

            // ACT
            testObjects.RollPricesStatusProvider.Dispose();

            using (testObjects.RollPricesStatusProvider
                              .RollPricesStatus
                              .Subscribe(serviceStatus => result = serviceStatus))
            {
                testObjects.RollPricesStatusProvider.Dispose();

                testObjects.MonthEndRollStatus.OnNext(monthEndRollStatuses);

                // ASSERT
                Assert.That(result, Is.EqualTo(MonthEndRollPricesStatus.NotRolled));
            }
        }
    }
}
