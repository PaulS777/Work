﻿using System;
using Dsp.Gui.Dashboard.Common.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    [TestFixture]
    public class ProgressUpdateServiceTests
    {
        [Test]
        public void ShouldPublishMessageDialogArgs()
        {
            var service = new ProgressUpdateService();

            ProgressUpdateArgs result = null;

            using (service.Progress.Subscribe(args => result = args))
            {
                var progress = new ProgressUpdateArgs(true, "busy");

                // TEST
                service.UpdateProgress(progress);

                // ASSERT
                Assert.That(result.IsBusy, Is.True);
                Assert.That(result.Text, Is.EqualTo("busy"));
            }
        }

        [Test]
        public void ShouldNotPublishMessageDialogArgs_When_Disposed()
        {
            var service = new ProgressUpdateService();

            ProgressUpdateArgs result = null;

            using (service.Progress.Subscribe(args => result = args))
            {
                var progress = new ProgressUpdateArgs(true, "busy");

                service.Dispose();

                // TEST
                service.UpdateProgress(progress);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var service = new ProgressUpdateService();

            ProgressUpdateArgs result = null;

            using (service.Progress.Subscribe(args => result = args))
            {
                var progress = new ProgressUpdateArgs(true, "busy");

                service.Dispose();

                // TEST
                service.Dispose();
                service.UpdateProgress(progress);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
