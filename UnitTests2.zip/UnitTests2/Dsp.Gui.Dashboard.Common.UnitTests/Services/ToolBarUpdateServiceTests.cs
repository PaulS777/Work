﻿using System;
using Dsp.Gui.Dashboard.Common.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    [TestFixture]
    public class ToolBarUpdateServiceTests
    {
        [Test]
        public void ShouldShowMarketsToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowMarketsToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowMarketsToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldSetMarketsCurrentPage()
        {
            var service = new ToolBarUpdateService();

            var result = 0;

            using (service.OnSetCurrentMarketsPageNumber.Subscribe(r => result = r))
            {
                // ACT
                service.SetCurrentMarketsPageNumber(2);

                // ASSERT
                Assert.That(result, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldShowPublicationControlsToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowPublicationControlToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowPublicationControlToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowPremiumsEditorToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowPremiumsEditorToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowPremiumsEditorToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }


        [Test]
        public void ShouldShowUserAdminToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowUserAdminToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowUserAdminToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowCalendarAdminToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowCalendarAdminToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowCalendarAdminToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowFxPremiumsToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowFxPremiumsToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowFxPremiumsToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

		[Test]
		public void ShouldShowCurveApprovalsToolBar()
		{
			var service = new ToolBarUpdateService();

			var result = false;

			using (service.OnShowCurveApprovalsToolBar.Subscribe(r => result = r))
			{
				// ACT
				service.ShowCurveApprovalsToolBar(true);

				// ASSERT
				Assert.That(result, Is.True);
			}
		}

		[Test]
        public void ShouldShowManualCurveEditorToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowManualCurveEditorToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowManualCurveEditorToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

		[Test]
		public void ShouldShowFormulaCurveEditorToolBar()
		{
			var service = new ToolBarUpdateService();

			var result = false;

			using (service.OnShowFormulaCurveEditorToolBar.Subscribe(r => result = r))
			{
				// ACT
				service.ShowFormulaCurveEditorToolBar(true);

				// ASSERT
				Assert.That(result, Is.True);
			}
		}

		[Test]
        public void ShouldShowFxCurveEditorToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowFxCurveEditorToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowFxCurveEditorToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }
        [Test]
        public void ShouldShowProductEditorToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowProductEditorToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowProductEditorToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowPartitionCurveEditorToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowPartitionCurveEditorToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowPartitionCurveEditorToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowFlatPriceCurveBuilderToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowFlatPriceCurveBuilderToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowFlatPriceCurveBuilderToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowPartitionShiftToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowPartitionShiftToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowPartitionShiftToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowChatScraperBrokerAdminToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowChatScraperBrokerAdminToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowChatScraperBrokerAdminToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowChatScraperProductAdminToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowChatScraperProductAdminToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowChatScraperProductAdminToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowChatScraperMarketAdminToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowChatScraperMarketAdminToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowChatScraperMarketAdminToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowChatPriceSummaryToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowChatPriceSummaryToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowChatPriceSummaryToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldShowDailyPricingToolBar()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowDailyPricingToolBar.Subscribe(r => result = r))
            {
                // ACT
                service.ShowDailyPricingToolBar(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotShowMarketsToolBar_When_Disposed()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowMarketsToolBar.Subscribe(r => result = r))
            {
                service.Dispose();

                // ACT
                service.ShowMarketsToolBar(true);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var service = new ToolBarUpdateService();

            var result = false;

            using (service.OnShowMarketsToolBar.Subscribe(r => result = r))
            {
                service.Dispose();

                // ACT
                service.Dispose();
                service.ShowMarketsToolBar(true);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
