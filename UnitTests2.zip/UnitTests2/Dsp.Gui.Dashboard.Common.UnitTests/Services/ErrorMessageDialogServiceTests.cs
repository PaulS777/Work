﻿using System;
using Dsp.Gui.Dashboard.Common.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    [TestFixture]
    public class ErrorMessageDialogServiceTests
    {
        [Test]
        public void ShouldPublishMessageDialogArgs()
        {
            var service = new ErrorMessageDialogService();

            ErrorMessageDialogArgs result = null;

            using (service.OnShowDialog.Subscribe(args => result = args))
            {
                var message = new ErrorMessageDialogArgs("header", "error", true);

                // TEST
                service.ShowDialog(message);

                // ASSERT
                Assert.That(result.Header, Is.EqualTo("header"));
                Assert.That(result.Messages[0], Is.EqualTo("error"));
                Assert.That(result.ShowSendFeedback, Is.True);
            }
        }

        [Test]
        public void ShouldNotPublishMessageDialogArgs_When_Disposed()
        {
            var service = new ErrorMessageDialogService();

            ErrorMessageDialogArgs result = null;

            using (service.OnShowDialog.Subscribe(args => result = args))
            {
                var message = new ErrorMessageDialogArgs("header", "error", true);

                service.Dispose();

                // TEST
                service.ShowDialog(message);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var service = new ErrorMessageDialogService();

            ErrorMessageDialogArgs result = null;

            using (service.OnShowDialog.Subscribe(args => result = args))
            {
                var message = new ErrorMessageDialogArgs("header", "error", true);

                service.Dispose();
                service.Dispose();

                // TEST
                service.ShowDialog(message);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
