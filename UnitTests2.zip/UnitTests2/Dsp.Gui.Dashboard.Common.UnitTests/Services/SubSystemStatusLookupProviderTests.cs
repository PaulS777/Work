﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.Common.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    [TestFixture]
    public class SubSystemStatusLookupProviderTests
    {
        [Test]
        public void ShouldGetLookupWithErrorPrecedenceOnFirstUpdate()
        {
            var gui1 = new ServiceStatusNotification(DspServiceName.AdminWebApi,
                                                     ServiceStatus.Ok,
                                                     SubSystem.GUI,
                                                     SubSystemStatus.Ok,
                                                     new List<string> { "action-1" },
                                                     DateTime.MinValue);

            var gui2 = new ServiceStatusNotification(DspServiceName.CurvePublisherService,
                                                     ServiceStatus.Ok,
                                                     SubSystem.GUI,
                                                     SubSystemStatus.Ok,
                                                     new List<string>(),
                                                     DateTime.MinValue);

            var priceFeedDsx1 = new ServiceStatusNotification(DspServiceName.PricingService,
                                                              ServiceStatus.Ok,
                                                              SubSystem.PriceFeedToDsx,
                                                              SubSystemStatus.Ok,
                                                              new List<string>(),
                                                              DateTime.MinValue);

            var priceFeedDsx2 = new ServiceStatusNotification(DspServiceName.FxService,
                                                              ServiceStatus.WarningServiceDegraded,
                                                              SubSystem.PriceFeedToDsx,
                                                              SubSystemStatus.WarningServiceDegraded,
                                                              new List<string>{"warning"},
                                                              DateTime.MinValue);

            var chatScraper1 = new ServiceStatusNotification(DspServiceName.ChatScraper,
                                                              ServiceStatus.WarningServiceDegraded,
                                                              SubSystem.ChatScraper,
                                                              SubSystemStatus.WarningServiceDegraded,
                                                              new List<string>{"warning"},
                                                              DateTime.MinValue);

            var chatScraper2 = new ServiceStatusNotification(DspServiceName.ChatScraperParser,
                                                             ServiceStatus.Unavailable,
                                                             SubSystem.ChatScraper,
                                                             SubSystemStatus.Unavailable,
                                                             new List<string>{"error"},
                                                             DateTime.MinValue);

            var notifications = new List<ServiceStatusNotification>
            {
                gui1, gui2, priceFeedDsx1, priceFeedDsx2, chatScraper1, chatScraper2
            };

            var statusLookupProvider = new SubSystemStatusLookupProvider();

            // ACT
            var results = statusLookupProvider.GetSubSystemStatusLookup(notifications);

            // ASSERT
            Assert.AreEqual(3, results.Count);

            Assert.That(results.TryGetValue(SubSystem.GUI, out var guiStatus)
                        && guiStatus.Status == DspSystemStatus.Ok);

            Assert.That(results.TryGetValue(SubSystem.PriceFeedToDsx, out var priceFeedDsxStatus)
                        && priceFeedDsxStatus.Status == DspSystemStatus.Warning);

            Assert.That(priceFeedDsxStatus.StatusMessages.Count == 1
                        && priceFeedDsxStatus.StatusMessages[0] == "warning");

            Assert.That(results.TryGetValue(SubSystem.ChatScraper, out var chatScraperStatus)
                        && chatScraperStatus.Status == DspSystemStatus.Error);

            Assert.That(chatScraperStatus.StatusMessages.Count == 1
                        && chatScraperStatus.StatusMessages[0] == "error");
        }

        [Test]
        public void ShouldGetLookup_With_ActionsRequired()
        {
            var priceFeedDsx1 = new ServiceStatusNotification(DspServiceName.AdminWebApi,
                                                              ServiceStatus.Ok,
                                                              SubSystem.PriceFeedToDsx,
                                                              SubSystemStatus.Ok,
                                                              new List<string>(),
                                                              DateTime.MinValue);

            var priceFeedDsx2 = new ServiceStatusNotification(DspServiceName.CurvePublisherService,
                                                              ServiceStatus.Ok,
                                                              SubSystem.PriceFeedToDsx,
                                                              SubSystemStatus.WarningFutureActionRequired,
                                                              new List<string>{"action-1"},
                                                              DateTime.MinValue);

            var priceFeedDsx3 = new ServiceStatusNotification(DspServiceName.PricingService,
                                                              ServiceStatus.Ok,
                                                              SubSystem.PriceFeedToDsx,
                                                              SubSystemStatus.WarningFutureActionRequired,
                                                              new List<string> { "action-2" },
                                                              DateTime.MinValue);

            var notifications = new List<ServiceStatusNotification>
            {
                priceFeedDsx1, priceFeedDsx2, priceFeedDsx3
            };

            var statusLookupProvider = new SubSystemStatusLookupProvider();

            // ACT
            var results = statusLookupProvider.GetSubSystemStatusLookup(notifications);

            // ASSERT
            Assert.That(results.TryGetValue(SubSystem.PriceFeedToDsx, out var priceFeedDsx) 
                        && priceFeedDsx.Status == DspSystemStatus.Ok);

            Assert.That(priceFeedDsx.ActionMessages.Count == 2 
                        && priceFeedDsx.ActionMessages[0] == "action-1"
                        && priceFeedDsx.ActionMessages[1] == "action-2");
        }

        [Test]
        public void ShouldGetLookup_With_ChangesOnly_After_InitialUpdate()
        {
            var gui1 = new ServiceStatusNotification(DspServiceName.AdminWebApi,
                                                     ServiceStatus.WarningFutureActionRequired,
                                                     SubSystem.GUI,
                                                     SubSystemStatus.WarningFutureActionRequired,
                                                     new List<string> { "action-1" },
                                                     DateTime.MinValue);

            var priceFeedDsx1 = new ServiceStatusNotification(DspServiceName.CurvePublisherService,
                                                              ServiceStatus.Ok,
                                                              SubSystem.PriceFeedToDsx,
                                                              SubSystemStatus.Ok,
                                                              new List<string>(),
                                                              DateTime.MinValue);

            var priceFeedDsx2 = new ServiceStatusNotification(DspServiceName.PricingService,
                                                              ServiceStatus.Ok,
                                                              SubSystem.PriceFeedToDsx,
                                                              SubSystemStatus.WarningFutureActionRequired,
                                                              new List<string> { "action-1" },
                                                              DateTime.MinValue);

            var notifications = new List<ServiceStatusNotification>
            {
                gui1, priceFeedDsx1, priceFeedDsx2
            };

            var priceFeedDsx3 = new ServiceStatusNotification(DspServiceName.FxService,
                                                              ServiceStatus.WarningServiceDegraded,
                                                              SubSystem.PriceFeedToDsx,
                                                              SubSystemStatus.WarningServiceDegraded,
                                                              new List<string>(),
                                                              DateTime.MinValue);

            var statusLookupProvider = new SubSystemStatusLookupProvider();
            
            statusLookupProvider.GetSubSystemStatusLookup(notifications);

            var notificationsUpdate = new List<ServiceStatusNotification>
            {
                priceFeedDsx3
            };

            // ACT
            var results = statusLookupProvider.GetSubSystemStatusLookup(notificationsUpdate);

            // ASSERT
            Assert.AreEqual(1, results.Count);

            Assert.That(results.TryGetValue(SubSystem.PriceFeedToDsx, out var priceFeedDsx)
                        && priceFeedDsx.Status == DspSystemStatus.Warning);

            Assert.That(priceFeedDsx.ActionMessages.Count == 1
                        && priceFeedDsx.ActionMessages[0] == "action-1");
        }

        [Test]
        public void ShouldSetDefaultErrorMessage_When_None()
        {
            var gui1 = new ServiceStatusNotification(DspServiceName.AdminWebApi,
                                                     ServiceStatus.Error,
                                                     SubSystem.GUI,
                                                     SubSystemStatus.Unavailable,
                                                     new List<string>(),
                                                     DateTime.MinValue);

            var notifications = new List<ServiceStatusNotification>
            {
                gui1
            };

            var statusLookupProvider = new SubSystemStatusLookupProvider();

            // ACT
            var results = statusLookupProvider.GetSubSystemStatusLookup(notifications);

            // ASSERT
            Assert.That(results.TryGetValue(SubSystem.GUI, out var guiStatus)
                        && guiStatus.StatusMessages.Count == 1
                        && guiStatus.StatusMessages[0] == $"{DspServiceName.AdminWebApi} Unavailable");
        }

        [Test]
        public void ShouldFilterOtherSubSystems()
        {
            var gui = new ServiceStatusNotification(DspServiceName.AdminWebApi,
                                                    ServiceStatus.WarningFutureActionRequired,
                                                    SubSystem.GUI,
                                                    SubSystemStatus.WarningFutureActionRequired,
                                                    new List<string> { "action-1" },
                                                    DateTime.MinValue);

            var other = new ServiceStatusNotification(DspServiceName.CurvePublisherService,
                                                              ServiceStatus.Ok,
                                                              SubSystem.Other,
                                                              SubSystemStatus.Ok,
                                                              new List<string>(),
                                                              DateTime.MinValue);

            var notifications = new List<ServiceStatusNotification>
            {
                gui, other
            };

            var statusLookupProvider = new SubSystemStatusLookupProvider();

            // ACT
            var results = statusLookupProvider.GetSubSystemStatusLookup(notifications);

            // ASSERT
            Assert.That(results.Count == 1 && results.ContainsKey(SubSystem.GUI));
        }
    }
}
