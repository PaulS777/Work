﻿using System;
using Dsp.Gui.Dashboard.Common.Services.Navigation;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.Navigation
{
    [TestFixture]
    public class NavigationMenuEnabledServiceTests
    {
        [Test]
        public void ShouldEnableNavigationOnSubscribe()
        {
            var service = new NavigationMenuEnabledService();

            var result = false;

            // ACT
            using (service.NavigationEnabled.Subscribe(r => result = r))
            {
                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldDisableNavigationOnSetEnabledFalse()
        {
            var service = new NavigationMenuEnabledService();

            var result = false;

            using (service.NavigationEnabled.Subscribe(r => result = r))
            {
                // ACT
                service.SetNavigationEnabled(false);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDisableNavigation_When_Disposed()
        {
            var service = new NavigationMenuEnabledService();

            var result = false;

            using (service.NavigationEnabled.Subscribe(r => result = r))
            {
                service.Dispose();

                // ACT
                service.SetNavigationEnabled(false);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var service = new NavigationMenuEnabledService();

            var result = false;

            using (service.NavigationEnabled.Subscribe(r => result = r))
            {
                service.Dispose();

                // ACT
                service.Dispose();
                service.SetNavigationEnabled(false);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }
    }
}
