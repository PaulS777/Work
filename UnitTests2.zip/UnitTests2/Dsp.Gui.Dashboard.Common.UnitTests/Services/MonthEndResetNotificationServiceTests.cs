﻿using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    public interface IMonthEndResetNotificationServiceTestObjects
    {
        IPopupNotificationService PopupNotificationService { get; }
        ISubject<List<MonthEndRollStatus>> MonthEndRollStatus { get; }
        MonthEndResetNotificationService MonthEndResetNotificationService { get; }
    }

    [TestFixture]
    public class MonthEndResetNotificationServiceTests
    {
        private class MonthEndResetNotificationServiceTestObjectBuilder
        {
            private User _currentUser;
            private IEnumerable<User> _usersSnapshot;
            private DateTime _currentDate;
            private List<MonthEndRollStatus> _monthEndRollStatuses;

            public MonthEndResetNotificationServiceTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

            public MonthEndResetNotificationServiceTestObjectBuilder WithUsersSnapshot(IEnumerable<User> values)
            {
                _usersSnapshot = values;
                return this;
            }

            public MonthEndResetNotificationServiceTestObjectBuilder WithCurrentDate(DateTime value)
            {
                _currentDate = value;
                return this;
            }

            public MonthEndResetNotificationServiceTestObjectBuilder WithMonthEndRollStatuses(List<MonthEndRollStatus> values)
            {
                _monthEndRollStatuses = values;
                return this;
            }

            public IMonthEndResetNotificationServiceTestObjects Build()
            {
                var testObjects = new Mock<IMonthEndResetNotificationServiceTestObjects>();

                var monthEndRollStatus = new BehaviorSubject<List<MonthEndRollStatus>>(_monthEndRollStatuses);


                testObjects.SetupGet(o => o.MonthEndRollStatus)
                           .Returns(monthEndRollStatus);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.MonthEndRollStatusOnUpdate)
                                   .Returns(monthEndRollStatus);

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(Observable.Return(_currentUser));

                curveControlService.Setup(c => c.GetUsersSnapshot())
                                   .Returns(_usersSnapshot);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var currentBusinessDateProvider = new Mock<ICurrentBusinessDateProvider>();

                currentBusinessDateProvider.Setup(p => p.CurrentDate)
                                           .Returns(_currentDate);

                var monthEndResetNotificationService 
                    = new MonthEndResetNotificationService(curveControlService.Object,
                                                           popupNotificationService.Object,
                                                           currentBusinessDateProvider.Object);

                testObjects.SetupGet(o => o.MonthEndResetNotificationService)
                           .Returns(monthEndResetNotificationService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldNotSendNotification_On_InitialHistory_With_LastTodayRecordReset()
        {
            var date1 = new DateTime(2022, 1, 1);
            var date2 = new DateTime(2022, 2, 1);

            var userPermissions = new List<AuthorisationUserPermission>
            {
                new(1, PermissionCategory.EomRoll.ToString(), 10, true)
            };

            var user = new UserBuilder().WithId(10)
                                        .WithAuthorisationUserPermissions(userPermissions)
                                        .User();

            var history = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Reset, date2)
            };

            var testObjects = new MonthEndResetNotificationServiceTestObjectBuilder().WithCurrentUser(user)
                                                                                     .WithCurrentDate(date2)
                                                                                     .WithMonthEndRollStatuses(history)
                                                                                     .Build();

            // ACT
            testObjects.MonthEndResetNotificationService.Initialize();

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Test]
        public void ShouldSendNotification_On_HistoryUpdate_With_LastTodayRecordReset_AndUserHasEomRollPermissions()
        {
            var date1 = new DateTime(2022, 1, 1);
            var date2 = new DateTime(2022, 2, 1);

            var userPermissions = new List<AuthorisationUserPermission>
            {
                new(1, PermissionCategory.EomRoll.ToString(), 10, true)
            };

            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorisationUserPermissions(userPermissions)
                                               .User();

            var otherUser = new UserBuilder().WithId(11)
                                             .User();

            var users = new[]
            {
                currentUser, otherUser
            };

            var history = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1))
            };

            var testObjects = new MonthEndResetNotificationServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithUsersSnapshot(users)
                                                                                     .WithCurrentDate(date2)
                                                                                     .WithMonthEndRollStatuses(history)
                                                                                     .Build();

            testObjects.MonthEndResetNotificationService.Initialize();

            // ACT
            var statusList = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Reset, date2)
            };

            testObjects.MonthEndRollStatus.OnNext(statusList);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification("Month End Roll Prices Has Been Reset", null));
        }

        [Test]
        public void ShouldNotSendNotification_On_HistoryUpdate_With_LastTodayRecordReset_AndUserHasNoEomRollPermissions()
        {
            var date1 = new DateTime(2022, 1, 1);
            var date2 = new DateTime(2022, 2, 1);

            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorisationUserPermissions(new List<AuthorisationUserPermission>())
                                               .User();

            var otherUser = new UserBuilder().WithId(11)
                                             .User();

            var users = new[]
            {
                currentUser, otherUser
            };

            var history = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1))
            };

            var testObjects = new MonthEndResetNotificationServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithUsersSnapshot(users)
                                                                                     .WithCurrentDate(date2)
                                                                                     .WithMonthEndRollStatuses(history)
                                                                                     .Build();

            testObjects.MonthEndResetNotificationService.Initialize();

            // ACT
            var historyUpdate = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1)),
                new(date2.ToDateOnly(), RollStatus.Reset, date2.AddHours(2))
            };

            testObjects.MonthEndRollStatus.OnNext(historyUpdate);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Test]
        public void ShouldNotSendNotification_On_HistoryUpdate_With_LastTodayRecordNotReset_AndUserHasEomRollPermissions()
        {
            var date1 = new DateTime(2022, 1, 1);
            var date2 = new DateTime(2022, 2, 1);

            var userPermissions = new List<AuthorisationUserPermission>
            {
                new(1, PermissionCategory.EomRoll.ToString(), 10, true)
            };

            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorisationUserPermissions(userPermissions)
                                               .User();

            var otherUser = new UserBuilder().WithId(11)
                                             .User();

            var users = new[]
            {
                currentUser, otherUser
            };

            var history = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1))
            };

            var testObjects = new MonthEndResetNotificationServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithUsersSnapshot(users)
                                                                                     .WithCurrentDate(date2)
                                                                                     .WithMonthEndRollStatuses(history)
                                                                                     .Build();

            testObjects.MonthEndResetNotificationService.Initialize();

            // ACT
            var historyUpdate = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1)),
                new(date2.ToDateOnly(), RollStatus.Reset, date2.AddHours(2)),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(3))
            };

            testObjects.MonthEndRollStatus.OnNext(historyUpdate);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Test]
        public void ShouldSendNotification_When_Disposed()
        {
            var date1 = new DateTime(2022, 1, 1);
            var date2 = new DateTime(2022, 2, 1);

            var userPermissions = new List<AuthorisationUserPermission>
            {
                new(1, PermissionCategory.EomRoll.ToString(), 10, true)
            };

            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorisationUserPermissions(userPermissions)
                                               .User();

            var otherUser = new UserBuilder().WithId(11)
                                             .User();

            var users = new[]
            {
                currentUser, otherUser
            };

            var history = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1))
            };

            var testObjects = new MonthEndResetNotificationServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithUsersSnapshot(users)
                                                                                     .WithCurrentDate(date2)
                                                                                     .WithMonthEndRollStatuses(history)
                                                                                     .Build();

            testObjects.MonthEndResetNotificationService.Initialize();

            testObjects.MonthEndResetNotificationService.Dispose();

            // ACT
            var historyUpdate = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1)),
                new(date2.ToDateOnly(), RollStatus.Reset, date2.AddHours(2))
            };

            testObjects.MonthEndRollStatus.OnNext(historyUpdate);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }

        [Test]
        public void ShouldDispose_When_Disposed()
        {
            var date1 = new DateTime(2022, 1, 1);
            var date2 = new DateTime(2022, 2, 1);

            var userPermissions = new List<AuthorisationUserPermission>
            {
                new(1, PermissionCategory.EomRoll.ToString(), 10, true)
            };

            var currentUser = new UserBuilder().WithId(10)
                                               .WithAuthorisationUserPermissions(userPermissions)
                                               .User();

            var otherUser = new UserBuilder().WithId(11)
                                             .User();

            var users = new[]
            {
                currentUser, otherUser
            };

            var history = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1))
            };

            var testObjects = new MonthEndResetNotificationServiceTestObjectBuilder().WithCurrentUser(currentUser)
                                                                                     .WithUsersSnapshot(users)
                                                                                     .WithCurrentDate(date2)
                                                                                     .WithMonthEndRollStatuses(history)
                                                                                     .Build();

            testObjects.MonthEndResetNotificationService.Initialize();

            testObjects.MonthEndResetNotificationService.Dispose();

            // ACT
            testObjects.MonthEndResetNotificationService.Dispose();

            var historyUpdate = new List<MonthEndRollStatus>
            {
                new(date1.ToDateOnly(), RollStatus.Completed, date1),
                new(date2.ToDateOnly(), RollStatus.Failed, date2.AddHours(1)),
                new(date2.ToDateOnly(), RollStatus.Reset, date2.AddHours(2))
            };

            testObjects.MonthEndRollStatus.OnNext(historyUpdate);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()), Times.Never);
        }
    }
}
