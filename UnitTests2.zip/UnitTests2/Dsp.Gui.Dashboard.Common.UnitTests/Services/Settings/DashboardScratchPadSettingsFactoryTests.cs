﻿using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.Settings
{
    [TestFixture]
    public class DashboardScratchPadSettingsFactoryTests
    {
        [Test]
        public void ShouldUpdateWorksheetSettings_When_ApplyToSettings_With_Added_And_Updated()
        {
            var worksheet1 = new WorksheetSettings
                             {
                                 WorksheetId = 1,
                                 WorksheetBindingListCollection = new List<WorksheetBindingList> { new() }
                             };

            var worksheet3 = new WorksheetSettings
                             {
                                 WorksheetId = 3,
                                 WorksheetBindingListCollection = new List<WorksheetBindingList> { new() }
                             };


            var scratchPadSettings = new DashboardScratchPadSettings
                                     {
                                         WorksheetSettingsList = new List<WorksheetSettings>
                                                                 {
                                                                     worksheet1, worksheet3
                                                                 }
                                     };

            var worksheet3Update = new WorksheetSettings
                                   {
                                       WorksheetId = 3,
                                       WorksheetBindingListCollection = new List<WorksheetBindingList> { new(), new() }
                                   };

            var worksheet2 = new WorksheetSettings
                             {
                                 WorksheetId = 2,
                                 WorksheetBindingListCollection = new List<WorksheetBindingList>()
                             };

            var update = new[] { worksheet2, worksheet3Update };

            var expected = new List<WorksheetSettings>
                           {
                               worksheet1,
                               worksheet2,
                               worksheet3Update
                           };

            var factory = new DashboardScratchPadSettingsFactory();

            // ACT
            factory.ApplyScratchPadSettings(update, scratchPadSettings);
            
            // ASSERT
            Assert.That(scratchPadSettings.WorksheetSettingsList.SequenceEqual(expected, new WorksheetSettingsEqualityComparer()));
        }

        [Test]
        public void ShouldRemoveWorksheetSettings()
        {
            var worksheet1 = new WorksheetSettings
            {
                WorksheetId = 1,
                WorksheetBindingListCollection = new List<WorksheetBindingList> { new() }
            };

            var worksheet2 = new WorksheetSettings
            {
                WorksheetId = 2,
                WorksheetBindingListCollection = new List<WorksheetBindingList>()
            };

            var scratchPadSettings = new DashboardScratchPadSettings
            {
                WorksheetSettingsList = new List<WorksheetSettings>
                                        {
                                            worksheet1, worksheet2
                                        }
            };

            var expected = new [] { worksheet2 };

            var factory = new DashboardScratchPadSettingsFactory();

            // ACT
            factory.RemoveWorksheetSettings(1, scratchPadSettings);

            // ASSERT
            Assert.That(scratchPadSettings.WorksheetSettingsList.SequenceEqual(expected, new WorksheetSettingsEqualityComparer()));
        }
    }
}
