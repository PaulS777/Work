﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Concurrency;
using System.Windows;
using Windows.ApplicationModel;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.Common.UnitTests.Helpers;
using Dsp.ServiceContracts;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.Settings
{
    public interface IDashboardSettingsServiceTestObjects
    {
        IDashboardSettingsFileService DashboardSettingsFileProvider { get; }
        IDashboardPriceGridSettingsFactory PriceGridSettingsFactory { get; }
        IDashboardScratchPadSettingsFactory ScratchPadSettingsFactory { get; }
        TestScheduler TestScheduler { get; }
        ILogger Logger { get; }
        DashboardSettingsService DashboardSettingsService { get; }
    }

    [TestFixture]
    public class DashboardSettingsServiceTests
    {
        private class DashboardSettingsServiceTestObjectBuilder
        {
            private DashboardSettingsCollection _dashboardSettings;
            private DashboardPriceGridSettings _dashboardSettingsFactoryFilterResult;
            private bool _saveDashboardSettingsFailed;

            public DashboardSettingsServiceTestObjectBuilder WithDashboardSettingsCollection(DashboardSettingsCollection value)
            {
                _dashboardSettings = value;
                return this;
            }

            public DashboardSettingsServiceTestObjectBuilder WithDashboardSettingsFactoryFilterResult(DashboardPriceGridSettings value)
            {
                _dashboardSettingsFactoryFilterResult = value;
                return this;
            }

            public DashboardSettingsServiceTestObjectBuilder WithSaveDashboardSettingsFailed()
            {
                _saveDashboardSettingsFailed = true;
                return this;
            }

            public IDashboardSettingsServiceTestObjects Build()
            {
                var testObjects = new Mock<IDashboardSettingsServiceTestObjects>();

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(testScheduler);

                schedulerProvider.SetupGet(p => p.Dispatcher)
                                 .Returns(Scheduler.Immediate);

                var dashboardSettingsFileProvider = new Mock<IDashboardSettingsFileService>();

                if (_saveDashboardSettingsFailed)
                {
                    dashboardSettingsFileProvider.Setup(p => p.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()))
                                                 .Throws(new ApplicationException());
                }

                dashboardSettingsFileProvider.Setup(p => p.LoadDashboardSettings())
                                             .Returns(_dashboardSettings);

                testObjects.SetupGet(o => o.DashboardSettingsFileProvider)
                           .Returns(dashboardSettingsFileProvider.Object);

                var priceGridSettingsFactory = new Mock<IDashboardPriceGridSettingsFactory>();

                priceGridSettingsFactory.Setup(f => f.GetPriceGridSettingsWithFilter(
                                                   It.IsAny<IList<FilterSettingsItem>>(),
                                                   It.IsAny<DashboardPriceGridSettings>()))
                                        .Returns(_dashboardSettingsFactoryFilterResult);

                priceGridSettingsFactory.Setup(f => f.GetFilterPriceGridSettingsWithColumnOrder(
                                                   It.IsAny<IList<FilterSettingsItem>>(),
                                                   It.IsAny<DashboardPriceGridSettings>()))
                                        .Returns(_dashboardSettingsFactoryFilterResult);

                testObjects.SetupGet(o => o.PriceGridSettingsFactory)
                           .Returns(priceGridSettingsFactory.Object);

                var scratchPadSettingsFactory = new Mock<IDashboardScratchPadSettingsFactory>();

                testObjects.SetupGet(o => o.ScratchPadSettingsFactory)
                           .Returns(scratchPadSettingsFactory.Object);

                var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

                var loggerFactory = new Mock<ILoggerFactory>();

                loggerFactory.Setup(f => f.Create(It.IsAny<string>()))
                             .Returns(logger.Object);

                var dashboardSettingsService = new DashboardSettingsService(dashboardSettingsFileProvider.Object,
                                                                            priceGridSettingsFactory.Object,
                                                                            scratchPadSettingsFactory.Object,
                                                                            schedulerProvider.Object,
                                                                            loggerFactory.Object);

                testObjects.SetupGet(o => o.DashboardSettingsService)
                           .Returns(dashboardSettingsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldLoadDashboardSettings()
        {
            var settings = new DashboardSettingsCollection();

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            // ACT
            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.LoadDashboardSettings());
        }

        [Test]
        public void ShouldPublishDashboardSettings_When_Loaded()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [new DashboardSettings()],
                InfoSettings = new DashboardInfoSettings { ScratchPadNavigationConfirmed = true }
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            DashboardSettingsCollection result = null;

            using (testObjects.DashboardSettingsService.DashboardSettings.Subscribe(s => result = s))
            {
                // ACT
                testObjects.DashboardSettingsService.LoadSettings();
                testObjects.TestScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(result, Is.Not.Null);
                Assert.That(result.DashboardSettings.Count, Is.EqualTo(1));
                Assert.That(result.InfoSettings.ScratchPadNavigationConfirmed, Is.True);
            }
        }

        [Test]
        public void ShouldPublishDashboardSettingsLoaded_When_Loaded()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [new DashboardSettings()]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            var result = false;

            using (testObjects.DashboardSettingsService.DashboardSettingsLoaded.Subscribe(s => result = s))
            {
                // ACT
                testObjects.DashboardSettingsService.LoadSettings();
                testObjects.TestScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldGetDashboardSettings()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard"
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            // ACT
            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var result = testObjects.DashboardSettingsService.GetDashboardSettingsForPage(1);

            // ASSERT
            Assert.AreSame("Dashboard", result.Name);
        }

        [Test]
        public void ShouldGetDashboardSettingsCollection()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard"
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            // ACT
            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var result = testObjects.DashboardSettingsService.DashboardSettingsSnapshot();

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(1));
        }


        [Test]
        public void ShouldGetVersion()
        {
            var version = new DashboardVersion(1, 0);

            var settings = new DashboardSettingsCollection
            {
                Version = version
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            // ACT
            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var result = testObjects.DashboardSettingsService.GetVersion();

            // ASSERT
            Assert.That(result, Is.EqualTo(version));
        }

        [Test]
        public void ShouldInitializeWithDefaultSettings()
        {
            var testObjects = new DashboardSettingsServiceTestObjectBuilder().Build();

            // ACT
            testObjects.DashboardSettingsService.InitializeWithDefaultSettings(1);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(d => d.SaveDashboardSettings(
                            It.Is<DashboardSettingsCollection>(s => s.DashboardSettings.Count == 1
                                                                    && s.DashboardSettings[0].PageNumber == 1
                                                                    && s.DashboardSettings[0].Name == Headers.PriceDashboard
                                                                    && s.DashboardSettings[0].PriceGridSettings.PriceColumnSettings.Count == 0
                                                                    && s.InfoSettings.ScratchPadNavigationConfirmed == false)));
        }

        [Test]
        public void ShouldCreateNewDashboardAndSaveSettings_When_AddDashboard()
        {
            var dashboard = new DashboardSettings
                            {
                                PageNumber = 1,
                                Name = "Dashboard"
                            };

            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [dashboard]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.AddDashboard(2, "Dashboard-2");
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            var expected = new[]
                           {
                               dashboard,
                               new DashboardSettings {
                                                         PageNumber = 2, Name = "Dashboard-2"
                                                     }
                           };


            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(f => f.SaveDashboardSettings(It.Is<DashboardSettingsCollection>(d => d.DashboardSettings.Count == 2)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(f => f.SaveDashboardSettings(It.Is<DashboardSettingsCollection>(d => d.DashboardSettings.SequenceEqual(expected, new DashBoardSettingsComparer()))));
        }

        [Test]
        public void ShouldPublishSettings_InCreatedOrder_When_DashboardAdded()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [new DashboardSettings { PageNumber = 2 }]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            DashboardSettingsCollection result = null;

            using (testObjects.DashboardSettingsService.DashboardSettings.Subscribe(s => result = s))
            {
                // ACT
                testObjects.DashboardSettingsService.AddDashboard(1, "Dashboard");
                testObjects.TestScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(result.DashboardSettings.Count, Is.EqualTo(2));
                Assert.That(result.DashboardSettings[0].PageNumber, Is.EqualTo(2));
                Assert.That(result.DashboardSettings[1].PageNumber, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishNewDashboard_When_AddDashboard()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [new DashboardSettings { PageNumber = 2 }]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            DashboardSettings result = null;

            using (testObjects.DashboardSettingsService.DashboardAdded.Subscribe(d => result = d))
            {
                // ACT
                testObjects.DashboardSettingsService.AddDashboard(1, "Dashboard");
                testObjects.TestScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(result.PageNumber, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldHandle_AddDashboardFailure()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [new DashboardSettings { PageNumber = 1, Name = "Dashboard" }]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .WithSaveDashboardSettingsFailed()
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.AddDashboard(2, "Dashboard-2");
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(l => l.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldRemoveDashboardAndSaveSettings_When_RemoveDashboard()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings { PageNumber = 1 },
                    new DashboardSettings { PageNumber = 2 }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.RemoveDashboard(2);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(f => f.SaveDashboardSettings(It.Is<DashboardSettingsCollection>(d => d.DashboardSettings.Count == 1)));
        }

        [Test]
        public void ShouldPublishDashboards_When_RemoveDashboard()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings { PageNumber = 1 },
                    new DashboardSettings { PageNumber = 2 }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            DashboardSettingsCollection result = null;

            using (testObjects.DashboardSettingsService.DashboardSettings.Subscribe(s => result = s))
            {
                // ACT
                testObjects.DashboardSettingsService.RemoveDashboard(2);
                testObjects.TestScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(result.DashboardSettings.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldHandle_RemoveDashboardFailure()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings { PageNumber = 1 },
                    new DashboardSettings { PageNumber = 2 }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .WithSaveDashboardSettingsFailed()
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.RemoveDashboard(99);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(l => l.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldUpdateLayout()
        {
             var settings = new DashboardSettingsCollection
                           {
                              DashboardSettings = [new DashboardSettings
                                                    {
                                                        PageNumber = 1, ShowPriceGridPanel = false, ShowScratchPadPanel = false
                                                    }]
                           };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateLayout(true, true, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyLayoutToDashboardSettings(true, true, It.IsAny<DashboardSettings>()));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(d => d.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));

        }

        [Test]
        public void ShouldUpdateDashboardName()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [new DashboardSettings { PageNumber = 1, Name = "Dashboard" }]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateDashboardName("Dashboard2", 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyNameToDashboardSettings("Dashboard2", It.IsAny<DashboardSettings>()));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(d => d.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldPublishSettings_When_UpdateDashboardName()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [new DashboardSettings { PageNumber = 1, Name = "Dashboard" }]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            DashboardSettingsCollection result = null;

            using (testObjects.DashboardSettingsService.DashboardSettings.Subscribe(s => result = s))
            {
                result = null;

                // ACT
                testObjects.DashboardSettingsService.UpdateDashboardName("Dashboard2", 1);
                testObjects.TestScheduler.AdvanceBy(10);

                // ASSERT
                Assert.That(result, Is.Not.Null);
                Assert.That(result.DashboardSettings.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldHandle_UpdateDashboardName_Failure()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings = [new DashboardSettings { PageNumber = 1, Name = "Dashboard" }]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateDashboardName("Dashboard2", 99);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(log => log.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldGetFilterPriceGridSettingsWithColumnOrders_When_UpdateFilterSettings_With_MaintainColumnOrder()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1,
                        Name = "Dashboard",
                        PriceGridSettings = new DashboardPriceGridSettings
                                            {
                                                PriceColumnSettings = [new PriceColumnSetting()]
                                            }
                    }
                ]
            };

            var factorySettings = new DashboardPriceGridSettings
            {
                PriceColumnSettings =
                [
                    new PriceColumnSetting(),
                    new PriceColumnSetting()
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .WithDashboardSettingsFactoryFilterResult(factorySettings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var filter = new[]
            {
                new FilterSettingsItem(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve)),
                new FilterSettingsItem(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve))
            };

            // ACT
            testObjects.DashboardSettingsService.UpdateFilterSettings(filter, 1, true);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.GetFilterPriceGridSettingsWithColumnOrder(filter, It.Is<DashboardPriceGridSettings>(s => s.PriceColumnSettings.Count == 1)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(d => d.SaveDashboardSettings(
                            It.Is<DashboardSettingsCollection>(s => s.DashboardSettings[0].Name == "Dashboard" 
                                                                    && s.DashboardSettings[0].PriceGridSettings.PriceColumnSettings.Count == 2)));
        }

        [Test]
        public void ShouldGetFilterPriceGridSettings_When_UpdateFilterSettings_With_MaintainColumnOrderFalse()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1,
                        Name = "Dashboard",
                        PriceGridSettings = new DashboardPriceGridSettings
                                            {
                                                PriceColumnSettings = [new PriceColumnSetting()]
                                            }
                    }
                ]
            };

            var factorySettings = new DashboardPriceGridSettings
            {
                PriceColumnSettings =
                [
                    new PriceColumnSetting(),
                    new PriceColumnSetting()
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .WithDashboardSettingsFactoryFilterResult(factorySettings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var filter = new[]
            {
                new FilterSettingsItem(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve)),
                new FilterSettingsItem(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve))
            };

            // ACT
            testObjects.DashboardSettingsService.UpdateFilterSettings(filter, 1, false);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.GetPriceGridSettingsWithFilter(filter, It.Is<DashboardPriceGridSettings>(s => s.PriceColumnSettings.Count == 1)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(d => d.SaveDashboardSettings(
                            It.Is<DashboardSettingsCollection>(s => s.DashboardSettings[0].Name == "Dashboard"
                                                                    && s.DashboardSettings[0].PriceGridSettings.PriceColumnSettings.Count == 2)));
        }

        [Test]
        public void ShouldHandle_UpdateFilterSettings_Failure()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);


            var filter = new[]
            {
                new FilterSettingsItem(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve)),
                new FilterSettingsItem(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve))
            };

            // ACT
            testObjects.DashboardSettingsService.UpdateFilterSettings(filter, 99, false);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(log => log.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldUpdateScratchPadSettings()
        {
            var scratchPad = new DashboardScratchPadSettings();

            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new DashboardSettings
                                   {
                                       PageNumber = 1, Name = "Dashboard", ScratchPadSettings = scratchPad
                                   }
                               ]
                           };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var worksheet = new WorksheetSettings[] { new() };

            // ACT
            testObjects.DashboardSettingsService.UpdateScratchPadBindings(worksheet, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.ScratchPadSettingsFactory)
                .Verify(f => f.ApplyScratchPadSettings(worksheet, scratchPad));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldRemoveScratchPadSettings()
        {
            var scratchPad = new DashboardScratchPadSettings();

            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new DashboardSettings
                                   {
                                       PageNumber = 1, Name = "Dashboard", ScratchPadSettings = scratchPad
                                   }
                               ]
                           };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.RemoveWorksheetBindings(1, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.ScratchPadSettingsFactory)
                .Verify(f => f.RemoveWorksheetSettings(1, scratchPad));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateColumnWidthSettings()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var columnWidths = new Dictionary<LinkedCurve, double>
            {
                {new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 50.1}
            };

            // ACT
            testObjects.DashboardSettingsService.UpdateColumnWidthSettings(columnWidths, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyColumnWidthsToPriceGridSettings(columnWidths, It.Is<DashboardPriceGridSettings>(s => s.ShowPriceDirection == true)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateBandVisibleIndexSettings()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var columnIndices = new Dictionary<LinkedCurve, int>
            {
                {new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 1}
            };

            // ACT
            testObjects.DashboardSettingsService.UpdateBandVisibleIndexSettings(columnIndices, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyColumnIndicesToPriceGridSettings(columnIndices, It.Is<DashboardPriceGridSettings>(s => s.ShowPriceDirection == true)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateAverages()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var averages = new Dictionary<LinkedCurve, int[]>
            {
                {new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), [10] }
            };

            // ACT
            testObjects.DashboardSettingsService.UpdateAverages(averages, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyAveragesToPriceGridSettings(averages, It.Is<DashboardPriceGridSettings>(s => s.ShowPriceDirection == true)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateColumnAverages()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();

            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var averages = new[] { 10 };

            // ACT
            testObjects.DashboardSettingsService.UpdateColumnAverages(1,
                                                                      linkedCurve, 
                                                                      averages);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyColumnAveragesToPriceGridSettings(linkedCurve, 
                                                                      averages, 
                                                                      It.Is<DashboardPriceGridSettings>(s => s.ShowPriceDirection == true)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateSpreads()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var spreads = new Dictionary<LinkedCurve, int[]>
            {
                { new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), [10] }
            };

            // ACT
            testObjects.DashboardSettingsService.UpdateSpreads(spreads, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplySpreadsToPriceGridSettings(spreads, It.Is<DashboardPriceGridSettings>(s => s.ShowPriceDirection == true)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateColumnSpreads()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();

            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var spreads = new[] { 10 };

            // ACT
            testObjects.DashboardSettingsService.UpdateColumnSpreads(1, linkedCurve, spreads);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyColumnSpreadsToPriceGridSettings(linkedCurve, 
                                                                     spreads, 
                                                                     It.Is<DashboardPriceGridSettings>(s => s.ShowPriceDirection == true)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateHighlights()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var highlights = new Dictionary<LinkedCurve, int[]>
            {
                {new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), [10] }
            };

            // ACT
            testObjects.DashboardSettingsService.UpdateHighlights(highlights, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyHighlightsToPriceGridSettings(highlights, It.Is<DashboardPriceGridSettings>(s => s.ShowPriceDirection == true)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateShowPriceDirection()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateShowPriceDirection(true, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyShowPriceDirectionToPriceGridSettings(true, It.Is<DashboardPriceGridSettings>(s => s.ShowPriceDirection == true)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateHeaderAlignment()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new DashboardSettings
                                   {
                                       PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                               {
                                                                                                   HeaderAlignment = HorizontalAlignment.Left
                                                                                               }
                                   }
                               ]
                           };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateHeaderAlignment(HorizontalAlignment.Right, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyHeaderAlignmentToPriceGridSettings(HorizontalAlignment.Right, 
                                                                       It.Is<DashboardPriceGridSettings>(s => s.HeaderAlignment == HorizontalAlignment.Left)));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateColumnWidth()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1,
                        Name = "Dashboard",
                        PriceGridSettings = new DashboardPriceGridSettings { ColumnWidth = 50 }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateColumnWidth(45, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.PriceGridSettingsFactory)
                .Verify(f => f.ApplyColumnWidthToPriceGridSettings(45, It.Is<DashboardPriceGridSettings>(s => s.ColumnWidth.Equals(50))));

            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.IsAny<DashboardSettingsCollection>()));
        }

        [Test]
        public void ShouldUpdateVersion()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings()
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            var version = new PackageVersion(1, 2, 3, 4);

            // ACT
            testObjects.DashboardSettingsService.UpdateVersion(version);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.Is<DashboardSettingsCollection>(s => s.Version.Major == 1
                                                                                          && s.Version.Minor == 2
                                                                                          && s.Version.Build == 3 
                                                                                          && s.Version.Revision == 4)));
        }

        [Test]
        public void ShouldUpdateScratchPadNavigationConfirmed()
        {
            var settings = new DashboardSettingsCollection
                           {
                               InfoSettings = new DashboardInfoSettings
                                              {
                                                  ScratchPadNavigationConfirmed = false,
                                                  ScratchPadHelpConfirmed = true
                                              },
                               DashboardSettings =
                               [
                                   new DashboardSettings
                                   {
                                       PageNumber = 1,
                                       Name = "Dashboard",
                                       PriceGridSettings = new DashboardPriceGridSettings()
                                   }
                               ]
                           };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateScratchPadNavigationConfirmed(true);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.Is<DashboardSettingsCollection>(s => s.InfoSettings.ScratchPadNavigationConfirmed == true
                                                                                               && s.InfoSettings.ScratchPadHelpConfirmed == true)));
        }

        [Test]
        public void ShouldUpdateScratchPadHelpConfirmed()
        {
            var settings = new DashboardSettingsCollection
                           {
                               InfoSettings = new DashboardInfoSettings
                                              {
                                                  ScratchPadNavigationConfirmed = true,
                                                  ScratchPadHelpConfirmed = false
                                              },
                               DashboardSettings =
                               [
                                   new DashboardSettings
                                   {
                                       PageNumber = 1,
                                       Name = "Dashboard",
                                       PriceGridSettings = new DashboardPriceGridSettings()
                                   }
                               ]
                           };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateScratchPadHelpConfirmed(true);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsFileProvider)
                .Verify(fp => fp.SaveDashboardSettings(It.Is<DashboardSettingsCollection>(s => s.InfoSettings.ScratchPadNavigationConfirmed == true
                                                                                            && s.InfoSettings.ScratchPadHelpConfirmed == true)));
        }

        [Test]
        public void ShouldHandle_UpdateShowPriceDirection_Failure()
        {
            var settings = new DashboardSettingsCollection
            {
                DashboardSettings =
                [
                    new DashboardSettings
                    {
                        PageNumber = 1, Name = "Dashboard", PriceGridSettings = new DashboardPriceGridSettings
                                                                                {
                                                                                    ShowPriceDirection = true
                                                                                }
                    }
                ]
            };

            var testObjects = new DashboardSettingsServiceTestObjectBuilder().WithDashboardSettingsCollection(settings)
                                                                             .WithSaveDashboardSettingsFailed()
                                                                             .Build();

            testObjects.DashboardSettingsService.LoadSettings();
            testObjects.TestScheduler.AdvanceBy(10);

            // ACT
            testObjects.DashboardSettingsService.UpdateShowPriceDirection(true, 1);
            testObjects.TestScheduler.AdvanceBy(10);

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(l => l.Error(It.IsAny<string>()));
        }
    }
}
