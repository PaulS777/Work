﻿using System;
using System.Collections.Generic;
using System.Windows;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.Settings
{
    [TestFixture]
    public class DashboardPriceGridSettingsFactoryTests
    {
        [Test]
        public void ShouldGetPriceGridSettings_When_New_ColumnAdded()
        {
            var settings = new DashboardPriceGridSettings
            {
                PriceColumnSettings = new List<PriceColumnSetting>()
            };

            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filter = new List<FilterSettingsItem>
            {
                new(curveId)
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            var result = factory.GetPriceGridSettingsWithFilter(filter, settings);

            // ASSERT
            Assert.That(result.PriceColumnSettings.Count, Is.EqualTo(1));
            Assert.That(result.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId));
        }

        [Test]
        public void ShouldMaintainExistingColumnIndices_When_MatchedManualCurveAddedToFilter()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                HeaderAlignment = HorizontalAlignment.Left,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    { 
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 2
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 1
                    },
                    new()
                    {
                        Id = 103,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 3
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var manualCurveId1 = new LinkedCurve(101, PriceCurveDefinitionType.DerivedCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);
            var curveId3 = new LinkedCurve(103, PriceCurveDefinitionType.PriceCurve);

            var filter = new List<FilterSettingsItem>
            {
                new(curveId1),
                new(manualCurveId1, curveId1.Id),
                new(curveId2),
                new(curveId3)
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            var result = factory.GetFilterPriceGridSettingsWithColumnOrder(filter, settings);

            // ASSERT
            Assert.That(result.ShowPriceDirection, Is.True);
            Assert.That(result.HeaderAlignment, Is.EqualTo(HorizontalAlignment.Left));

            Assert.That(result.PriceColumnSettings.Count, Is.EqualTo(4));

            Assert.That(result.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId2));
            Assert.That(result.PriceColumnSettings[0].VisibleIndex, Is.EqualTo(1));

            Assert.That(result.PriceColumnSettings[1].LinkedCurve, Is.EqualTo(curveId1));
            Assert.That(result.PriceColumnSettings[1].VisibleIndex, Is.EqualTo(2));

            Assert.That(result.PriceColumnSettings[2].LinkedCurve, Is.EqualTo(manualCurveId1));
            Assert.That(result.PriceColumnSettings[2].VisibleIndex, Is.EqualTo(3));

            Assert.That(result.PriceColumnSettings[3].LinkedCurve, Is.EqualTo(curveId3));
            Assert.That(result.PriceColumnSettings[3].VisibleIndex, Is.EqualTo(4));
        }

        [Test]
        public void ShouldAddNewPriceCurvesAndUnmatchedManualCurves_ToEndOfGrid_When_AddedToFilter()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                HeaderAlignment = HorizontalAlignment.Left,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 2
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 1
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var manualCurveId = new LinkedCurve(200, PriceCurveDefinitionType.DerivedCurve);
            var curveId3 = new LinkedCurve(103, PriceCurveDefinitionType.PriceCurve);

            var filter = new List<FilterSettingsItem>
            {
                new(curveId1),
                new(curveId2),
                new(curveId3),
                new(manualCurveId, 200)
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            var result = factory.GetFilterPriceGridSettingsWithColumnOrder(filter, settings);

            // ASSERT
            Assert.That(result.ShowPriceDirection, Is.True);
            Assert.That(result.HeaderAlignment, Is.EqualTo(HorizontalAlignment.Left));

            Assert.That(result.PriceColumnSettings.Count, Is.EqualTo(4));

            Assert.That(result.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId2));
            Assert.That(result.PriceColumnSettings[0].VisibleIndex, Is.EqualTo(1));

            Assert.That(result.PriceColumnSettings[1].LinkedCurve, Is.EqualTo(curveId1));
            Assert.That(result.PriceColumnSettings[1].VisibleIndex, Is.EqualTo(2));

            Assert.That(result.PriceColumnSettings[2].LinkedCurve, Is.EqualTo(curveId3));
            Assert.That(result.PriceColumnSettings[2].VisibleIndex, Is.EqualTo(3));

            Assert.That(result.PriceColumnSettings[3].LinkedCurve, Is.EqualTo(manualCurveId));
            Assert.That(result.PriceColumnSettings[3].VisibleIndex, Is.EqualTo(4));
        }

        [Test]
        public void ShouldMaintainExistingColumnIndices_When_ManualCurveRemovedFromFilter()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 1
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 2
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.DerivedCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 3
                    },
                    new()
                    {
                        Id = 103,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        ColumnWidth = 50,
                        VisibleIndex = 4
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);
            var curveId3 = new LinkedCurve(103, PriceCurveDefinitionType.PriceCurve);

            var filter = new List<FilterSettingsItem>
            {
                new(curveId1),
                new(curveId2),
                new(curveId3)
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            var result = factory.GetFilterPriceGridSettingsWithColumnOrder(filter, settings);

            // ASSERT
            Assert.That(result.ShowPriceDirection, Is.True);

            Assert.That(result.PriceColumnSettings.Count, Is.EqualTo(3));

            Assert.That(result.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId1));
            Assert.That(result.PriceColumnSettings[0].VisibleIndex, Is.EqualTo(1));

            Assert.That(result.PriceColumnSettings[1].LinkedCurve, Is.EqualTo(curveId2));
            Assert.That(result.PriceColumnSettings[1].VisibleIndex, Is.EqualTo(2));

            Assert.That(result.PriceColumnSettings[2].LinkedCurve, Is.EqualTo(curveId3));
            Assert.That(result.PriceColumnSettings[2].VisibleIndex, Is.EqualTo(3));
        }

        [Test]
        public void ShouldMaintainExistingColumnSettings_When_New_ColumnAdded()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                ColumnWidth = 50,
                HeaderAlignment = HorizontalAlignment.Right,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{7},
                        Spreads = new []{8},
                        Highlights = new []{9},
                        ColumnWidth = 50
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var filter = new List<FilterSettingsItem>
            {
                new(curveId1),
                new(curveId2)
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            var result = factory.GetPriceGridSettingsWithFilter(filter, settings);

            // ASSERT
            Assert.That(result.ShowPriceDirection, Is.True);
            Assert.That(result.HeaderAlignment, Is.EqualTo(HorizontalAlignment.Right));
            Assert.That(result.ColumnWidth, Is.EqualTo(50));

            Assert.That(result.PriceColumnSettings.Count, Is.EqualTo(2));

            Assert.That(result.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId1));
            Assert.That(result.PriceColumnSettings[0].Averages[0], Is.EqualTo(7));
            Assert.That(result.PriceColumnSettings[0].Spreads[0], Is.EqualTo(8));
            Assert.That(result.PriceColumnSettings[0].Highlights[0], Is.EqualTo(9));
            Assert.That(result.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(50));

            Assert.That(result.PriceColumnSettings[1].LinkedCurve, Is.EqualTo(curveId2));
            Assert.IsNull(result.PriceColumnSettings[1].ColumnWidth);
        }

        [Test]
        public void ShouldApplyColumnWidthsToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{7},
                        Spreads = new []{8},
                        Highlights = new []{9},
                        ColumnWidth = 50,
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = Array.Empty<int>(),
                        Spreads = Array.Empty<int>(),
                        Highlights = Array.Empty<int>(),
                        ColumnWidth = 50,
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var columnWidths = new Dictionary<LinkedCurve, double>
            {
                {curveId1, 100},
                {curveId2, 110}
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyColumnWidthsToPriceGridSettings(columnWidths, settings);

            // ASSERT
            Assert.That(settings.ShowPriceDirection, Is.True);

            Assert.That(settings.PriceColumnSettings.Count, Is.EqualTo(2));

            Assert.That(settings.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId1));
            Assert.That(settings.PriceColumnSettings[0].Averages[0], Is.EqualTo(7));
            Assert.That(settings.PriceColumnSettings[0].Spreads[0], Is.EqualTo(8));
            Assert.That(settings.PriceColumnSettings[0].Highlights[0], Is.EqualTo(9));
            Assert.That(settings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(100));

            Assert.That(settings.PriceColumnSettings[1].LinkedCurve, Is.EqualTo(curveId2));
            Assert.That(settings.PriceColumnSettings[1].ColumnWidth, Is.EqualTo(110));
        }

        [Test]
        public void ShouldApplyColumnIndicesToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{7},
                        Spreads = new []{8},
                        Highlights = new []{9},
                        ColumnWidth = 50,
                        VisibleIndex = 1
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = Array.Empty<int>(),
                        Spreads = Array.Empty<int>(),
                        Highlights = Array.Empty<int>(),
                        ColumnWidth = 50,
                        VisibleIndex = 2
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var columnIndices = new Dictionary<LinkedCurve, int>
            {
                {curveId1, 2},
                {curveId2, 1}
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyColumnIndicesToPriceGridSettings(columnIndices, settings);

            // ASSERT
            Assert.That(settings.PriceColumnSettings[0].VisibleIndex, Is.EqualTo(2));
            Assert.That(settings.PriceColumnSettings[1].VisibleIndex, Is.EqualTo(1));
        }

        [Test]
        public void ShouldApplyAveragesToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = Array.Empty<int>(),
                        Spreads = new []{8},
                        Highlights = new []{9},
                        ColumnWidth = 50,
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{4},
                        Spreads = Array.Empty<int>(),
                        Highlights = Array.Empty<int>(),
                        ColumnWidth = 50,
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var averages = new Dictionary<LinkedCurve, int[]>
            {
                {curveId1, new[] {6, 7}},
                {curveId2, Array.Empty<int>()}
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyAveragesToPriceGridSettings(averages, settings);

            // ASSERT - AVERAGES
            Assert.That(settings.PriceColumnSettings[1].Averages.Length, Is.EqualTo(0));
            Assert.That(settings.PriceColumnSettings[0].Averages.Length, Is.EqualTo(2));
            Assert.That(settings.PriceColumnSettings[0].Averages[0], Is.EqualTo(6));
            Assert.That(settings.PriceColumnSettings[0].Averages[1], Is.EqualTo(7));

            // ASSERT - EXISTING
            Assert.That(settings.ShowPriceDirection, Is.True);

            Assert.That(settings.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId1));
            Assert.That(settings.PriceColumnSettings[0].Spreads[0], Is.EqualTo(8));
            Assert.That(settings.PriceColumnSettings[0].Highlights[0], Is.EqualTo(9));
            Assert.That(settings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(50));

            Assert.That(settings.PriceColumnSettings[1].LinkedCurve, Is.EqualTo(curveId2));
            Assert.That(settings.PriceColumnSettings[1].ColumnWidth, Is.EqualTo(50));
        }

        [Test]
        public void ShouldClearAveragesFromPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{1,2,3},
                    }
                }
            };

            var averages = new Dictionary<LinkedCurve, int[]>();

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyAveragesToPriceGridSettings(averages, settings);

            // ASSERT - AVERAGES
            Assert.That(settings.PriceColumnSettings[0].Averages.Length, Is.EqualTo(0));
        }

        [Test]
        public void ShouldApplyColumnAveragesToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = Array.Empty<int>(),
                        Spreads = new []{8},
                        Highlights = new []{9},
                        ColumnWidth = 50
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{4},
                        Spreads = Array.Empty<int>(),
                        Highlights = Array.Empty<int>(),
                        ColumnWidth = 50,
                    }
                }
            };

            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var averages = new[] { 6, 7 };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyColumnAveragesToPriceGridSettings(linkedCurve, 
                                                           averages, 
                                                           settings);

            // ASSERT - AVERAGES
            Assert.That(settings.PriceColumnSettings[0].Averages.Length, Is.EqualTo(2));
            Assert.That(settings.PriceColumnSettings[0].Averages[0], Is.EqualTo(6));
            Assert.That(settings.PriceColumnSettings[0].Averages[1], Is.EqualTo(7));

            // ASSERT - EXISTING
            Assert.That(settings.ShowPriceDirection, Is.True);

            Assert.That(settings.PriceColumnSettings[0].Spreads[0], Is.EqualTo(8));
            Assert.That(settings.PriceColumnSettings[0].Highlights[0], Is.EqualTo(9));
            Assert.That(settings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(50));

            Assert.That(settings.PriceColumnSettings[1].Averages.Length, Is.EqualTo(1));
        }

        [Test]
        public void ShouldApplySpreadsToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{8},
                        Spreads = Array.Empty<int>(),
                        Highlights = new []{9},
                        ColumnWidth = 50,
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = Array.Empty<int>(),
                        Spreads = new[]{6},
                        Highlights = Array.Empty<int>(),
                        ColumnWidth = 50,
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var spreads = new Dictionary<LinkedCurve, int[]>
            {
                {curveId1, new[] {6, 7}},
                {curveId2, Array.Empty<int>()}
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplySpreadsToPriceGridSettings(spreads, settings);

            // ASSERT - SPREADS
            Assert.That(settings.PriceColumnSettings[1].Spreads.Length, Is.EqualTo(0));
            Assert.That(settings.PriceColumnSettings[0].Spreads.Length, Is.EqualTo(2));
            Assert.That(settings.PriceColumnSettings[0].Spreads[0], Is.EqualTo(6));
            Assert.That(settings.PriceColumnSettings[0].Spreads[1], Is.EqualTo(7));

            // ASSERT - EXISTING
            Assert.That(settings.ShowPriceDirection, Is.True);

            Assert.That(settings.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId1));
            Assert.That(settings.PriceColumnSettings[0].Averages[0], Is.EqualTo(8));
            Assert.That(settings.PriceColumnSettings[0].Highlights[0], Is.EqualTo(9));
            Assert.That(settings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(50));

            Assert.That(settings.PriceColumnSettings[1].LinkedCurve, Is.EqualTo(curveId2));
            Assert.That(settings.PriceColumnSettings[1].ColumnWidth, Is.EqualTo(50));
        }

        [Test]
        public void ShouldClearSpreadsFromPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Spreads = new []{1,2,3},
                        ColumnWidth = 50
                    }
                }
            };

            var spreads = new Dictionary<LinkedCurve, int[]>();

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplySpreadsToPriceGridSettings(spreads, settings);

            // ASSERT - SPREADS
            Assert.That(settings.PriceColumnSettings[0].Spreads.Length, Is.EqualTo(0));
        }

        [Test]
        public void ShouldApplyColumnSpreadsToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{8},
                        Spreads = Array.Empty<int>(),
                        Highlights = new []{9},
                        ColumnWidth = 50,
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = Array.Empty<int>(),
                        Spreads = new[]{6},
                        Highlights = Array.Empty<int>(),
                        ColumnWidth = 50,
                    }
                }
            };

            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var spreads = new[] { 6, 7 };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyColumnSpreadsToPriceGridSettings(linkedCurve, 
                                                          spreads, 
                                                          settings);

            // ASSERT - SPREADS

            Assert.That(settings.PriceColumnSettings[0].Spreads.Length, Is.EqualTo(2));
            Assert.That(settings.PriceColumnSettings[0].Spreads[0], Is.EqualTo(6));
            Assert.That(settings.PriceColumnSettings[0].Spreads[1], Is.EqualTo(7));

            // ASSERT - EXISTING
            Assert.That(settings.ShowPriceDirection, Is.True);

            Assert.That(settings.PriceColumnSettings[0].Averages[0], Is.EqualTo(8));
            Assert.That(settings.PriceColumnSettings[0].Highlights[0], Is.EqualTo(9));
            Assert.That(settings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(50));

            Assert.That(settings.PriceColumnSettings[1].Spreads.Length, Is.EqualTo(1));
            Assert.That(settings.PriceColumnSettings[1].ColumnWidth, Is.EqualTo(50));
        }

        [Test]
        public void ShouldApplyHighlightsToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{8},
                        Spreads = new []{9},
                        Highlights = Array.Empty<int>(),
                        ColumnWidth = 50,
                    },
                    new()
                    {
                        Id = 102,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = Array.Empty<int>(),
                        Spreads = Array.Empty<int>(),
                        Highlights = new []{3},
                        ColumnWidth = 50,
                    }
                }
            };

            var curveId1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var curveId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var highlights = new Dictionary<LinkedCurve, int[]>
            {
                {curveId1, new[] {6, 7}},
                {curveId2, Array.Empty<int>()}
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyHighlightsToPriceGridSettings(highlights, settings);

            // ASSERT - HIGHLIGHTS
            Assert.That(settings.PriceColumnSettings[1].Highlights.Length, Is.EqualTo(0));
            Assert.That(settings.PriceColumnSettings[0].Highlights.Length, Is.EqualTo(2));
            Assert.That(settings.PriceColumnSettings[0].Highlights[0], Is.EqualTo(6));
            Assert.That(settings.PriceColumnSettings[0].Highlights[1], Is.EqualTo(7));

            // ASSERT - EXISTING
            Assert.That(settings.ShowPriceDirection, Is.True);

            Assert.That(settings.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId1));
            Assert.That(settings.PriceColumnSettings[0].Averages[0], Is.EqualTo(8));
            Assert.That(settings.PriceColumnSettings[0].Spreads[0], Is.EqualTo(9));
            Assert.That(settings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(50));

            Assert.That(settings.PriceColumnSettings[1].LinkedCurve, Is.EqualTo(curveId2));
            Assert.That(settings.PriceColumnSettings[1].ColumnWidth, Is.EqualTo(50));
        }

        [Test]
        public void ShouldClearHighlightsFromPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Highlights = new []{1,2,3},
                        ColumnWidth = 50
                    }
                }
            };

            var highlights = new Dictionary<LinkedCurve, int[]>();

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyHighlightsToPriceGridSettings(highlights, settings);

            // ASSERT - HIGHLIGHTS
            Assert.That(settings.PriceColumnSettings[0].Highlights.Length, Is.EqualTo(0));
        }

        [Test]
        public void ShouldApplyShowPriceDirectionToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = false,
                PriceColumnSettings = new List<PriceColumnSetting>
                {
                    new()
                    {
                        Id = 101,
                        DefinitionType = PriceCurveDefinitionType.PriceCurve,
                        Averages = new []{6},
                        Spreads = new []{7},
                        Highlights = new []{8},
                        ColumnWidth = 50
                    }
                }
            };

            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
   
            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyShowPriceDirectionToPriceGridSettings(true, settings);

            // ASSERT - SHOW PRICE DIRECTION
            Assert.That(settings.ShowPriceDirection, Is.True);

            // ASSERT - EXISTING
            Assert.That(settings.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId));
            Assert.That(settings.PriceColumnSettings[0].Averages[0], Is.EqualTo(6));
            Assert.That(settings.PriceColumnSettings[0].Spreads[0], Is.EqualTo(7));
            Assert.That(settings.PriceColumnSettings[0].Highlights[0], Is.EqualTo(8));
            Assert.That(settings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(50));
        }


        [Test]
        public void ShouldApplyHeaderAlignmentToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
                           {
                               ShowPriceDirection = true,
                               HeaderAlignment = HorizontalAlignment.Left,
                               PriceColumnSettings = new List<PriceColumnSetting>
                                                     {
                                                         new()
                                                         {
                                                             Id = 101,
                                                             DefinitionType = PriceCurveDefinitionType.PriceCurve,
                                                             Averages = new []{6},
                                                             Spreads = new []{7},
                                                             Highlights = new []{8},
                                                             ColumnWidth = 50
                                                         }
                                                     }
                           };

            var curveId = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyHeaderAlignmentToPriceGridSettings(HorizontalAlignment.Right, settings);

            // ASSERT - SHOW PRICE DIRECTION
            Assert.That(settings.HeaderAlignment, Is.EqualTo(HorizontalAlignment.Right));

            // ASSERT - EXISTING
            Assert.That(settings.PriceColumnSettings[0].LinkedCurve, Is.EqualTo(curveId));
            Assert.That(settings.PriceColumnSettings[0].Averages[0], Is.EqualTo(6));
            Assert.That(settings.PriceColumnSettings[0].Spreads[0], Is.EqualTo(7));
            Assert.That(settings.PriceColumnSettings[0].Highlights[0], Is.EqualTo(8));
            Assert.That(settings.PriceColumnSettings[0].ColumnWidth, Is.EqualTo(50));
        }

        [Test]
        public void ShouldApplyColumnWidthToPriceGridSettings()
        {
            var settings = new DashboardPriceGridSettings
            {
                ShowPriceDirection = true,
                HeaderAlignment = HorizontalAlignment.Left,
                PriceColumnSettings = new List<PriceColumnSetting>
                                                     {
                                                         new()
                                                         {
                                                             Id = 101,
                                                             DefinitionType = PriceCurveDefinitionType.PriceCurve,
                                                             ColumnWidth = 50
                                                         }
                                                     }
            };

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyColumnWidthToPriceGridSettings(50, settings);

            // ASSERT - SHOW PRICE DIRECTION
            Assert.That(settings.ColumnWidth, Is.EqualTo(50));
        }

        [Test]
        public void ShouldApplyNameToDashboardSettings()
        {
            var dashboardSettings = new DashboardSettings();

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyNameToDashboardSettings("markets", dashboardSettings);

            // ASSERT
            Assert.That(dashboardSettings.Name, Is.EqualTo("markets"));
        }

        [Test]
        public void ShouldApplyLayoutToDashboardSettings()
        {
            var dashboardSettings = new DashboardSettings();

            var factory = new DashboardPriceGridSettingsFactory();

            // ACT
            factory.ApplyLayoutToDashboardSettings(true, true, dashboardSettings);

            // ASSERT
            Assert.That(dashboardSettings.ShowPriceGridPanel, Is.True);
            Assert.That(dashboardSettings.ShowScratchPadPanel, Is.True);
        }
    }
}
