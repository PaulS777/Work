﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    public interface IBetaUserServiceTestObjects
    {
        ISubject<User> CurrentUser { get; }
        BetaUserService BetaUserService { get; }
    }

    [TestFixture]
    public class BetaUserServiceTests
    {
        private class BetaUserServiceTestObjectBuilder
        {
            public IBetaUserServiceTestObjects Build()
            {
                var testObjects = new Mock<IBetaUserServiceTestObjects>();

                var user = new Subject<User>();

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(user);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(user);

                var betaUserService = new BetaUserService(curveControlService.Object);

                testObjects.SetupGet(o => o.BetaUserService)
                           .Returns(betaUserService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishTrue_When_User_Has_BetaUserPermission()
        {
            var userPermissions = new List<AuthorisationUserPermission>
                                  {
                                      new(1, PermissionCategory.BetaUser.ToString(), 10, true)
                                  };

            var user = new UserBuilder().WithId(10)
                                        .WithAuthorisationUserPermissions(userPermissions)
                                        .User();

            var testObjects = new BetaUserServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.BetaUserService.IsBetaUser.Subscribe(value => result = value))
            {
                // ACT
                testObjects.CurrentUser.OnNext(user);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_User_DoesNotHave_BetaUserPermission()
        {
            var user = new UserBuilder().WithId(10)
                                        .WithAuthorisationUserPermissions(new List<AuthorisationUserPermission>())
                                        .User();

            var testObjects = new BetaUserServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.BetaUserService.IsBetaUser.Subscribe(value => result = value))
            {
                // ACT
                testObjects.CurrentUser.OnNext(user);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishTrue_When_Disposed()
        {
            var userPermissions = new List<AuthorisationUserPermission>
                                  {
                                      new(1, PermissionCategory.BetaUser.ToString(), 10, true)
                                  };

            var user = new UserBuilder().WithId(10)
                                        .WithAuthorisationUserPermissions(userPermissions)
                                        .User();

            var testObjects = new BetaUserServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.BetaUserService.IsBetaUser.Subscribe(value => result = value))
            {
                testObjects.BetaUserService.Dispose();

                // ACT
                testObjects.CurrentUser.OnNext(user);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var userPermissions = new List<AuthorisationUserPermission>
                                  {
                                      new(1, PermissionCategory.BetaUser.ToString(), 10, true)
                                  };

            var user = new UserBuilder().WithId(10)
                                        .WithAuthorisationUserPermissions(userPermissions)
                                        .User();

            var testObjects = new BetaUserServiceTestObjectBuilder().Build();

            var result = false;

            using (testObjects.BetaUserService.IsBetaUser.Subscribe(value => result = value))
            {
                testObjects.BetaUserService.Dispose();

                // ACT
                testObjects.BetaUserService.Dispose();
                testObjects.CurrentUser.OnNext(user);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

    }
}
