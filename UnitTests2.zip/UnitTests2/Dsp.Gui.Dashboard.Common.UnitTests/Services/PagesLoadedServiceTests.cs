﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Dashboard.Common.Services;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services
{
    [TestFixture]
    public class PagesLoadedServiceTests
    {
        [Test]
        public void ShouldPublishFirstPageLoaded()
        {
            List<int> result = null;

            var service = new PagesLoadedService();

            using (service.PagesLoaded.Subscribe(pages => result = pages))
            {
                // ACT
                service.SetPageLoaded(1);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishCurrentPageNumber()
        {
            var result = 0;

            var service = new PagesLoadedService();

            using (service.CurrentPageNumber.Subscribe(page => result = page))
            {
                // ACT
                service.SetPageLoaded(1);

                // ASSERT
                Assert.That(result, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldPublishPagesLoaded_On_NextPage()
        {
            List<int> result = null;

            var service = new PagesLoadedService();

            using (service.PagesLoaded.Subscribe(pages => result = pages))
            {
                service.SetPageLoaded(1);

                // ACT
                service.SetPageLoaded(2);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldNotPublishPagesLoaded_When_Disposed()
        {
            List<int> result = null;

            var service = new PagesLoadedService();

            using (service.PagesLoaded.Subscribe(pages => result = pages))
            {
                service.SetPageLoaded(1);

                service.Dispose();

                // ACT
                service.SetPageLoaded(2);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            List<int> result = null;

            var service = new PagesLoadedService();

            using (service.PagesLoaded.Subscribe(pages => result = pages))
            {
                service.SetPageLoaded(1);

                service.Dispose();

                // ACT
                service.Dispose();
                service.SetPageLoaded(2);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }
    }
}
