﻿using System;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services.ManualCurve;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ManualCurve
{
    [TestFixture]
    public class CurveEditSourcesCombinedTests
    {
        #region Add single source, make change, then remove with unsaved changes

        [Test]
        public void ShouldPublishFalse_When_AddSource_With_NoChanges()
        {
            var curveChanged = new BehaviorSubject<bool>(false);

            var source = new CurveEditSource
                         {
                             ManualCurveChanged = curveChanged
                         };

            var service = new CurveEditSourcesCombined();

            var result = false;

            using (service.HasChanges.Subscribe(value => result = value))
            {
                // ACT
                service.AddEditSource(source);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_SourceChanged()
        {
            var curveChanged = new BehaviorSubject<bool>(false);

            var source = new CurveEditSource
                         {
                             ManualCurveChanged = curveChanged
                         };

            var service = new CurveEditSourcesCombined();

            var result = false;

            using (service.HasChanges.Subscribe(value => result = value))
            {
               
                service.AddEditSource(source);

                // ACT
                curveChanged.OnNext(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_RemoveSource_With_UnsavedChanges()
        {
            var curveChanged = new BehaviorSubject<bool>(false);

            var source = new CurveEditSource
                         {
                             ManualCurveChanged = curveChanged
                         };

            var service = new CurveEditSourcesCombined();

            var result = false;

            using (service.HasChanges.Subscribe(value => result = value))
            {
                // ARRANGE
                service.AddEditSource(source);
                curveChanged.OnNext(true);

                // ACT
                service.RemoveEditSource(source);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        #endregion

        #region Add multiple sources

        [Test]
        public void ShouldPublishTrue_When_Add_SecondSource_With_Changes()
        {
            var curveChanged1 = new BehaviorSubject<bool>(false);

            var source1 = new CurveEditSource
                         {
                             ManualCurveChanged = curveChanged1
                         };

            var curveChanged2 = new BehaviorSubject<bool>(true);

            var source2 = new CurveEditSource
                          {
                              ManualCurveChanged = curveChanged2
                          };

            var service = new CurveEditSourcesCombined();

            var result = false;

            using (service.HasChanges.Subscribe(value => result = value))
            {
                service.AddEditSource(source1);

                // ACT
                service.AddEditSource(source2);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_SecondSource_UndoChanges()
        {
            var curveChanged1 = new BehaviorSubject<bool>(false);

            var source1 = new CurveEditSource
                          {
                              ManualCurveChanged = curveChanged1
                          };

            var curveChanged2 = new BehaviorSubject<bool>(true);

            var source2 = new CurveEditSource
                          {
                              ManualCurveChanged = curveChanged2
                          };

            var service = new CurveEditSourcesCombined();

            var result = false;

            using (service.HasChanges.Subscribe(value => result = value))
            {
                service.AddEditSource(source1);
                service.AddEditSource(source2);

                // ACT
                curveChanged2.OnNext(false);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_Remove_SecondSource_With_Changes()
        {
            var curveChanged1 = new BehaviorSubject<bool>(false);

            var source1 = new CurveEditSource
                          {
                              ManualCurveChanged = curveChanged1
                          };

            var curveChanged2 = new BehaviorSubject<bool>(true);

            var source2 = new CurveEditSource
                          {
                              ManualCurveChanged = curveChanged2
                          };

            var service = new CurveEditSourcesCombined();

            var result = false;

            using (service.HasChanges.Subscribe(value => result = value))
            {
                service.AddEditSource(source1);
                service.AddEditSource(source2);

                // ACT
                service.RemoveEditSource(source2);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        #endregion

        #region Unexpected - Handle Duplicate Source and Remove when not Added

        [Test]
        public void ShouldNotPublish_When_AddDuplicateSource()
        {
            var curveChanged1 = new BehaviorSubject<bool>(false);

            var source1 = new CurveEditSource
                          {
                              ManualCurveChanged = curveChanged1
                          };

            var service = new CurveEditSourcesCombined();

            bool? result = null;

            using (service.HasChanges.Subscribe(value => result = value))
            {
                service.AddEditSource(source1);

                result = null;

                // ACT
                service.AddEditSource(source1);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }

        [Test]
        public void ShouldNotPublish_When_RemoveSource_NotAdded()
        {
            var curveChanged1 = new BehaviorSubject<bool>(false);

            var source1 = new CurveEditSource
                          {
                              ManualCurveChanged = curveChanged1
                          };

            var curveChanged2 = new BehaviorSubject<bool>(true);

            var source2 = new CurveEditSource
                          {
                              ManualCurveChanged = curveChanged2
                          };

            var service = new CurveEditSourcesCombined();

            bool? result = null;

            using (service.HasChanges.Subscribe(value => result = value))
            {
                service.AddEditSource(source1);

                result = null;

                // ACT
                service.RemoveEditSource(source2);

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }

        #endregion

        #region Dispose

        [Test]
        public void ShouldNotPublish_When_Disposed()
        {
            var curveChanged = new BehaviorSubject<bool>(false);

            var source = new CurveEditSource
                         {
                             ManualCurveChanged = curveChanged
                         };

            var service = new CurveEditSourcesCombined();

            var result = false;

            using (service.HasChanges.Subscribe(value => result = value))
            {

                service.AddEditSource(source);

                service.Dispose();

                // ACT
                curveChanged.OnNext(true);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var curveChanged = new BehaviorSubject<bool>(false);

            var source = new CurveEditSource
                         {
                             ManualCurveChanged = curveChanged
                         };

            var service = new CurveEditSourcesCombined();

            var result = false;

            using (service.HasChanges.Subscribe(value => result = value))
            {

                service.AddEditSource(source);

                service.Dispose();

                // ACT
                service.Dispose();
                curveChanged.OnNext(true);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        #endregion
    }
}
