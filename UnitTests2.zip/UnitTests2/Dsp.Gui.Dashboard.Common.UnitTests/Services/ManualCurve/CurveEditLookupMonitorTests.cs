﻿using System.Reactive.Subjects;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ManualCurve;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ManualCurve
{
    public interface ICurvesEditLookupMonitorTestObjects
    {
        ICurveEditSourcesCombined CurveEditSourcesCombined1 { get; }
        ICurveEditSourcesCombined CurveEditSourcesCombined2 { get; }
        IServiceFactory<ICurveEditSourcesCombined> Factory { get; }
        CurveEditLookupMonitor CurvesEditLookupService { get; }
    }

    [TestFixture]
    public class CurvesEditLookupMonitorTests
    {
        private class CurvesEditLookupMonitorTestObjectBuilder
        {
            public ICurvesEditLookupMonitorTestObjects Build()
            {
                var testObjects = new Mock<ICurvesEditLookupMonitorTestObjects>();

                var hasChanges1 = new Subject<bool>();

                var curveEditSourcesCombined1 = new Mock<ICurveEditSourcesCombined>();

                curveEditSourcesCombined1.SetupGet(c => c.HasChanges)
                                         .Returns(hasChanges1);

                testObjects.SetupGet(o => o.CurveEditSourcesCombined1)
                           .Returns(curveEditSourcesCombined1.Object);

                var hasChanges2 = new Subject<bool>();

                var curveEditSourcesCombined2 = new Mock<ICurveEditSourcesCombined>();

                curveEditSourcesCombined2.SetupGet(c => c.HasChanges)
                                         .Returns(hasChanges2);

                testObjects.SetupGet(o => o.CurveEditSourcesCombined2)
                           .Returns(curveEditSourcesCombined2.Object);

                var factory = new Mock<IServiceFactory<ICurveEditSourcesCombined>>();

                factory.SetupSequence(f => f.Create())
                       .Returns(curveEditSourcesCombined1.Object)
                       .Returns(curveEditSourcesCombined2.Object);

                testObjects.SetupGet(o => o.Factory)
                           .Returns(factory.Object);

                var curvesEditLookupService = new CurveEditLookupMonitor
                                              {
                                                  Factory = factory.Object
                                              };

                testObjects.SetupGet(o => o.CurvesEditLookupService)
                           .Returns(curvesEditLookupService);

                return testObjects.Object;
            }
        }

        #region RegisterCurveEditSource - Curve Added to Grid

        [Test]
        public void ShouldCreateCombined_And_AddEditSource_When_First_RegisterCurveEditSource()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource = Mock.Of<ICurveEditSource>();

            // ACT
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource);

            // ASSERT
            Mock.Get(testObjects.Factory)
                .Verify(f => f.Create());

            Mock.Get(testObjects.CurveEditSourcesCombined1)
                .Verify(c => c.AddEditSource(curveEditSource));
        }

        [Test]
        public void ShouldAddEditSourceToExistingCombined_When_Next_RegisterCurveEditSource_With_SameId()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource1 = Mock.Of<ICurveEditSource>();
            var curveEditSource2 = Mock.Of<ICurveEditSource>();

            // ARRANGE
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource1);

            // ACT
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource2);

            // ASSERT
            Mock.Get(testObjects.Factory)
                .Verify(f => f.Create(), Times.Once);

            Mock.Get(testObjects.CurveEditSourcesCombined1)
                .Verify(c => c.AddEditSource(curveEditSource2));
        }

        [Test]
        public void ShouldCreateCombined_When_Next_RegisterCurveEditSource_With_NewId()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource1 = Mock.Of<ICurveEditSource>();
            var curveEditSource2 = Mock.Of<ICurveEditSource>();

            // ARRANGE
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource1);

            // ACT
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(202, curveEditSource2);

            // ASSERT
            Mock.Get(testObjects.Factory)
                .Verify(f => f.Create(), Times.Exactly(2));

            Mock.Get(testObjects.CurveEditSourcesCombined2)
                .Verify(c => c.AddEditSource(curveEditSource2));
        }

        #endregion

        #region UnregisterCurveEditSource - Curve Removed from Grid

        [Test]
        public void ShouldRemoveEditSource_When_UnregisterCurveEditSource_With_Existing()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource = Mock.Of<ICurveEditSource>();

            // ARRANGE
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource);

            // ACT
            testObjects.CurvesEditLookupService.UnRegisterCurveEditSource(201, curveEditSource);

            // ASSERT
            Mock.Get(testObjects.CurveEditSourcesCombined1)
                .Verify(c => c.RemoveEditSource(curveEditSource));
        }

        [Test]
        public void ShouldNotRemoveEditSource_When_UnregisterCurveEditSource_With_NotExisting()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource = Mock.Of<ICurveEditSource>();

            // ARRANGE
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource);

            // ACT
            testObjects.CurvesEditLookupService.UnRegisterCurveEditSource(99, curveEditSource);

            // ASSERT
            Mock.Get(testObjects.CurveEditSourcesCombined1)
                .Verify(c => c.RemoveEditSource(curveEditSource), Times.Never);
        }

        #endregion

        #region ObserveCurveEdit

        [Test]
        public void ShouldReturnCombinedEditSourcesHasChanges_When_ObserveCurveEdit_With_SourcesExists()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource = Mock.Of<ICurveEditSource>();

            // ARRANGE
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource);

            // ACT
            var result = testObjects.CurvesEditLookupService.ObserveCurveEdit(201);

            // ASSERT
            Assert.That(result, Is.SameAs(testObjects.CurveEditSourcesCombined1.HasChanges));
        }

        [Test]
        public void ShouldCreateCombined_And_ReturnHasChanged_When_ObserveCurveEdit_With_SourcesNotExists()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            // ACT
            var result = testObjects.CurvesEditLookupService.ObserveCurveEdit(201);

            // ASSERT
            Mock.Get(testObjects.Factory)
                .Verify(f => f.Create());

            Assert.That(result, Is.SameAs(testObjects.CurveEditSourcesCombined1.HasChanges));
        }

        [Test]
        public void ShouldReturnHasChanged_When_ObserveCurveEdit_With_SourcesExists()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource = Mock.Of<ICurveEditSource>();

            // ARRANGE
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource);

            // ACT
            var result = testObjects.CurvesEditLookupService.ObserveCurveEdit(201);

            // ASSERT
            Mock.Get(testObjects.Factory)
                .Verify(f => f.Create(), Times.Once);

            Assert.That(result, Is.SameAs(testObjects.CurveEditSourcesCombined1.HasChanges));
        }

        #endregion

        #region Dispose

        [Test]
        public void ShouldDisposeCombined_When_Dispose()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource = Mock.Of<ICurveEditSource>();

            // ARRANGE
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource);

            // ACT
            testObjects.CurvesEditLookupService.Dispose();

            // ASSERT
            Mock.Get(testObjects.CurveEditSourcesCombined1)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new CurvesEditLookupMonitorTestObjectBuilder().Build();

            var curveEditSource = Mock.Of<ICurveEditSource>();

            // ARRANGE
            testObjects.CurvesEditLookupService.RegisterCurveEditSource(201, curveEditSource);

            testObjects.CurvesEditLookupService.Dispose();

            // ACT
            testObjects.CurvesEditLookupService.Dispose();

            // ASSERT
            Mock.Get(testObjects.CurveEditSourcesCombined1)
                .Verify(c => c.Dispose(), Times.Once);
        }

        #endregion
    }
}
