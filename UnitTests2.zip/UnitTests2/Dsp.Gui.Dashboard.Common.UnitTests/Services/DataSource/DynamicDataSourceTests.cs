﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.Common.Services.DataSource;
using DynamicData;
using Moq;
using NUnit.Framework;
using Prism.Mvvm;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.DataSource
{
    [TestFixture]
    public class DynamicDataSourceTests
    {
        private class TestDataSourceItem : BindableBase, IDataSourceItem
        {
            private bool _value;

            public bool Value
            {
                get => _value;
                set
                {
                    _value = value;
                    RaisePropertyChanged();
                }
            }

            public bool Predicate { get; init; }

            public void Dispose()
            {
            }
        }

        [Test]
        public void ShouldInitializeDataSource_With_Items()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var items = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>()
                        };

            // ACT
            var result = dataSource.InitializeDataSource(items);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldReturnItems_With_DataSourceInitialized()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var items = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>()
                        };

            dataSource.InitializeDataSource(items);

            // ACT
            var result = dataSource.Items();

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldUpdateCollection_From_Source_When_InitializeItems()
        {
            var dataSource = new DynamicDataSource<TestDataSourceItem>();

            var item = new TestDataSourceItem { Predicate = true };

            var items = new List<TestDataSourceItem> { item };

           var collection =  dataSource.InitializeDataSource(items);

            // ACT
            items[0].Value = true;

            // ASSERT
            Assert.That(collection[0].Value, Is.True);
        }

        [Test]
        public void ShouldUpdateDataSource_When_RefreshItems()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var item1 = new Mock<IDataSourceItem>();

            dataSource.InitializeDataSource(new List<IDataSourceItem> { item1.Object });

            var item2 = new Mock<IDataSourceItem>();
            var expectedSequence = new[] { item2.Object };

            // ACT
            dataSource.RefreshItems(new List<IDataSourceItem> { item2.Object });

            // ASSERT
            var result = dataSource.Items();
            Assert.That(result.SequenceEqual(expectedSequence));
        }

        [Test]
        public void ShouldDisposeBoundItems_When_RefreshItems()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var item1 = new Mock<IDataSourceItem>();
            
            dataSource.InitializeDataSource(new List<IDataSourceItem> {item1.Object});

            var item2 = new Mock<IDataSourceItem>();

            // ACT
            dataSource.RefreshItems(new List<IDataSourceItem>{item2.Object});

            // ASSERT
            item1.Verify(i => i.Dispose());
        }

        [Test]
        public void ShouldAddItems()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var items = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>()
                        };

            dataSource.InitializeDataSource(items);

            var added = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>()
                        };

            // ACT
            dataSource.AddItems(added);

            // ASSERT
            var result = dataSource.Items();

            Assert.That(result.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldInsertItemsAtIndex()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();


            var items = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>(),
                            Mock.Of<IDataSourceItem>()
                        };

            dataSource.InitializeDataSource(items);

            var item = Mock.Of<IDataSourceItem>();

            var inserts = new List<IDataSourceItem>
                          {
                              item
                          };

            // ACT
            dataSource.InsertItems(inserts, 1);

            // ASSERTS
            var result = dataSource.Items().ToList();

            Assert.That(result.Count, Is.EqualTo(3));
            Assert.That(result[1], Is.SameAs(item));
        }

        [Test]
        public void ShouldRemoveItemsFromStart()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var item = Mock.Of<IDataSourceItem>();

            var items = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>(),
                            Mock.Of<IDataSourceItem>(),
                            item,
                            Mock.Of<IDataSourceItem>()
                        };

            dataSource.InitializeDataSource(items);

            // ACT
            dataSource.RemoveItemsFromStart(2);

            // ASSERT
            Assert.That(dataSource.Items().Count, Is.EqualTo(2));
            Assert.That(dataSource.Items().First(), Is.SameAs(item));
        }

        [Test]
        public void ShouldRemoveItemsFromIndex_When_TrimEnd_With_IndexWithinRange()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var items = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>(),
                            Mock.Of<IDataSourceItem>(),
                            Mock.Of<IDataSourceItem>(),
                            Mock.Of<IDataSourceItem>()
                        };

            dataSource.InitializeDataSource(items);

            // ACT
            dataSource.RemoveItemsFromIndex(2);

            // ASSERT
            Assert.That(dataSource.Items().Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldNotRemoveItemsFromIndex_When_TrimEnd_With_IndexOutsideRange()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var items = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>(),
                            Mock.Of<IDataSourceItem>(),
                            Mock.Of<IDataSourceItem>(),
                            Mock.Of<IDataSourceItem>()
                        };

            dataSource.InitializeDataSource(items);

            // ACT
            dataSource.RemoveItemsFromIndex(5);

            // ASSERT
            Assert.That(dataSource.Items().Count, Is.EqualTo(4));
        }

        [Test]
        public void ShouldClearItems_When_Clear()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var items = new List<IDataSourceItem>
                        {
                            Mock.Of<IDataSourceItem>()
                        };

            dataSource.InitializeDataSource(items);

            // ACT
            dataSource.Clear();

            // ASSERT
            Assert.That(dataSource.Items().Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldNotifyChange_With_ConnectOnMatchingPredicate()
        {
            var dataSource = new DynamicDataSource<TestDataSourceItem>();

            var item = new TestDataSourceItem { Predicate = true };

            var items = new List<TestDataSourceItem> { item };

            dataSource.InitializeDataSource(items);

            IChangeSet<TestDataSourceItem> result = null;

            var updates = dataSource.Connect(i => i.Predicate).AutoRefresh(row => row.Value);

            using (updates.Subscribe(changes => result = changes))
            {
                result = null;

                // ACT
                dataSource.Items().First().Value = true;

                // ASSERT
                Assert.IsNotNull(result);
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotifyChange_With_Connect_With_MissingPredicate()
        {
            var dataSource = new DynamicDataSource<TestDataSourceItem>();

            var item = new TestDataSourceItem();

            var items = new List<TestDataSourceItem> { item };

            dataSource.InitializeDataSource(items);

            IChangeSet<TestDataSourceItem> result = null;

            var updates = dataSource.Connect().AutoRefresh(row => row.Value);

            using (updates.Subscribe(changes => result = changes))
            {
                result = null;

                // ACT
                dataSource.Items().First().Value = true;

                // ASSERT
                Assert.IsNotNull(result);
                Assert.That(result.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotNotifyChange_With_ConnectOnNonMatchingPredicate()
        {
            var dataSource = new DynamicDataSource<TestDataSourceItem>();

            var item = new TestDataSourceItem { Predicate = false };

            var items = new List<TestDataSourceItem> { item };

            dataSource.InitializeDataSource(items);

            IChangeSet<TestDataSourceItem> result = null;

            var updates = dataSource.Connect(i => i.Predicate).AutoRefresh(row => row.Value);

            using (updates.Subscribe(changes => result = changes))
            {
                result = null;

                // ACT
                dataSource.Items().First().Value = true;

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldDisposeBoundItems_When_Dispose()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var item1 = new Mock<IDataSourceItem>();

            dataSource.InitializeDataSource(new List<IDataSourceItem> { item1.Object });

            // ACT
            dataSource.Dispose();

            // ASSERT
            item1.Verify(i => i.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var dataSource = new DynamicDataSource<IDataSourceItem>();

            var item1 = new Mock<IDataSourceItem>();

            dataSource.InitializeDataSource(new List<IDataSourceItem> { item1.Object });
            dataSource.Dispose();

            // ACT
            dataSource.Dispose();

            // ASSERT
            item1.Verify(i => i.Dispose(), Times.Once);
        }
    }
}
