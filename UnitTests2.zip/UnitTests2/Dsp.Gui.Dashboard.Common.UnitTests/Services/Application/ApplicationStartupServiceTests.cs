﻿// ***********************************************************************************************************************
// ApplicationStartupServiceTests.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------

using System.Reactive.Subjects;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Application;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.Application
{
    public interface IApplicationStartupServiceTestObjects
    {
        ISubject<bool?> MutexInstanceStatus { get; }
        IDashboardSettingsService DashboardSettingsService { get; }
        ICurveSettingsService CurveSettingsService { get; }
        IMonthEndResetNotificationService MonthEndResetNotificationService { get; }
        ApplicationStartupService ApplicationStartupService { get; }
    }

    [TestFixture]
    public class ApplicationStartupServiceTests
    {
        private class ApplicationStartupServiceTestObjectBuilder
        {
            public IApplicationStartupServiceTestObjects Build()
            {
                var testObjects = new Mock<IApplicationStartupServiceTestObjects>();

                var status = new Subject<bool?>();

                testObjects.SetupGet(o => o.MutexInstanceStatus)
                           .Returns(status);

                var mutexInstance = new Mock<IMutexInstance>();

                mutexInstance.SetupGet(i => i.Status)
                             .Returns(status);

                var settingsService = new Mock<IDashboardSettingsService>();

                testObjects.SetupGet(o => o.DashboardSettingsService)
                           .Returns(settingsService.Object);

                var curveSettingsService = new Mock<ICurveSettingsService>();

                testObjects.SetupGet(o => o.CurveSettingsService)
                           .Returns(curveSettingsService.Object);

                var monthEndService = new Mock<IMonthEndResetNotificationService>();

                testObjects.SetupGet(o => o.MonthEndResetNotificationService)
                           .Returns(monthEndService.Object);

                var service = new ApplicationStartupService
                              {
                                  MutexInstance = mutexInstance.Object,
                                  DashboardSettingsService = settingsService.Object,
                                  CurveSettingsService = curveSettingsService.Object,
                                  MonthEndResetNotificationService = monthEndService.Object
                              };

                testObjects.SetupGet(o => o.ApplicationStartupService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeServices_And_InvokeInitializedAction_On_MutexInstanceStatusTrue()
        {
            var testObjects = new ApplicationStartupServiceTestObjectBuilder().Build();

            var invoked = false;

            testObjects.ApplicationStartupService.Initialize(() => invoked = true, () => { });

            // ACT
            testObjects.MutexInstanceStatus.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.LoadSettings());

            Mock.Get(testObjects.CurveSettingsService)
                .Verify(c => c.Initialize());

            Mock.Get(testObjects.MonthEndResetNotificationService)
                .Verify(m => m.Initialize());

            Assert.That(invoked, Is.True);
        }

        [Test]
        public void ShouldInvokeDuplicateAction_On_MutexInstanceStatusFalse()
        {
            var testObjects = new ApplicationStartupServiceTestObjectBuilder().Build();

            var invoked = false;

            testObjects.ApplicationStartupService.Initialize(() => {}, () => invoked = true);

            // ACT
            testObjects.MutexInstanceStatus.OnNext(false);

            // ASSERT
            Assert.That(invoked, Is.True);

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.LoadSettings(), Times.Never);

            Mock.Get(testObjects.CurveSettingsService)
                .Verify(c => c.Initialize(), Times.Never);

            Mock.Get(testObjects.MonthEndResetNotificationService)
                .Verify(m => m.Initialize(), Times.Never);
        }

        [Test]
        public void Should_Not_InitializeServices_When_Disposed()
        {
            var testObjects = new ApplicationStartupServiceTestObjectBuilder().Build();

            testObjects.ApplicationStartupService.Initialize(() => {}, () => { });

            testObjects.ApplicationStartupService.Dispose();

            // ACT
            testObjects.MutexInstanceStatus.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.LoadSettings(), Times.Never);
        }

        [Test]
        public void Should_Not_Dispose_When_Disposed()
        {
            var testObjects = new ApplicationStartupServiceTestObjectBuilder().Build();

            testObjects.ApplicationStartupService.Initialize(() => { }, () => { });

            testObjects.ApplicationStartupService.Dispose();

            // ACT
            testObjects.ApplicationStartupService.Dispose();
            testObjects.MutexInstanceStatus.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.LoadSettings(), Times.Never);
        }
    }
}
