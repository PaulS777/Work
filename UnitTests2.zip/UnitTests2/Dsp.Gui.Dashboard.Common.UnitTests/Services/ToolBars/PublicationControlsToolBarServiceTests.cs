﻿using System;
using System.Reactive;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Navigation;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    public interface IPublicationControlsToolBarServiceTestObjects
    {
        ISubject<Unit> StopTrading { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        INavigationMenuEnabledService NavigationMenuService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IProgressUpdateService ProgressUpdateService { get; }
        ISubject<bool> HasPublicationControlChanges { get; }
        PublicationControlsToolBarService PublicationControlsToolBarService { get; }
    }

    [TestFixture]
    public class PublicationControlsToolBarServiceTests
    {
        private class PublicationControlsToolBarServiceTestObjectBuilder
        {
            private bool _hasPublicationControlChanges;

            public PublicationControlsToolBarServiceTestObjectBuilder WithHasPublicationControlChanges(bool value)
            {
                _hasPublicationControlChanges = value;
                return this;
            }

            public IPublicationControlsToolBarServiceTestObjects Build()
            {
                var testObjects = new Mock<IPublicationControlsToolBarServiceTestObjects>();

                var hasPublicationControlChanges = new BehaviorSubject<bool>(_hasPublicationControlChanges);
                testObjects.SetupGet(o => o.HasPublicationControlChanges).Returns(hasPublicationControlChanges);

                var stopTrading = new Subject<Unit>();

                testObjects.SetupGet(o => o.StopTrading)
                           .Returns(stopTrading);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var progressUpdateService = new Mock<IProgressUpdateService>();

                testObjects.SetupGet(o => o.ProgressUpdateService)
                           .Returns(progressUpdateService.Object);

                var navigationMenuService = new Mock<INavigationMenuEnabledService>();

                testObjects.SetupGet(o => o.NavigationMenuService)
                           .Returns(navigationMenuService.Object);

                var toolBarService = new PublicationControlsToolBarService(navigationMenuService.Object);

                testObjects.SetupGet(o => o.PublicationControlsToolBarService)
                           .Returns(toolBarService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldEnableUpdatePublicationChangesCommand_OnHasChangesTrue()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);

            // ACT
            testObjects.PublicationControlsToolBarService.SetHasChanges(true);

            // ASSERT
            Assert.That(toolBar.UpdateCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableUpdatePublicationChangesCommand_OnHasChangesFalse()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().WithHasPublicationControlChanges(true)
                                                                                      .Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);

            // ACT
            testObjects.PublicationControlsToolBarService.SetHasChanges(false);

            // ASSERT
            Assert.That(toolBar.UpdateCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableUndoPublicationChangesCommand_OnHasChangesTrue()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);

            // ACT
            testObjects.PublicationControlsToolBarService.SetHasChanges(true);

            // ASSERT
            Assert.That(toolBar.UndoCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableUndoPublicationChangesCommand_OnHasChangesFalse()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().WithHasPublicationControlChanges(true)
                                                                                      .Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);
  
            // ACT
            testObjects.PublicationControlsToolBarService.SetHasChanges(false);

            // ASSERT
            Assert.That(toolBar.UndoCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableNavigation_OnHasChangesTrue()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);

            // ACT
            testObjects.PublicationControlsToolBarService.SetHasChanges(false);

            // ASSERT
            Mock.Get(testObjects.NavigationMenuService)
                .Verify(m => m.SetNavigationEnabled(true));
        }

        [Test]
        public void ShouldEnableNavigation_OnHasChangesFalse()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);

            // ACT
            testObjects.PublicationControlsToolBarService.SetHasChanges(true);

            // ASSERT
            Mock.Get(testObjects.NavigationMenuService)
                .Verify(m => m.SetNavigationEnabled(false));
        }

        [Test]
        public void ShouldDisableNavigation_OnHasChangesFalse()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);

            // ACT
            testObjects.PublicationControlsToolBarService.SetHasChanges(false);

            // ASSERT
            Mock.Get(testObjects.NavigationMenuService)
                .Verify(m => m.SetNavigationEnabled(true));
        }

        [Test]
        public void ShouldPublishUpdatePublicationControlChanges_OnUpdatePublicationChangesCommand()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);

            var result = false;

            using (testObjects.PublicationControlsToolBarService.UpdatePublicationControlChanges.Subscribe(_ => result = true))
            {
                // ACT
                toolBar.UpdateCommand.Execute();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishUndoPublicationControlChanges_OnUndoPublicationChangesCommand()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);

            var result = false;

            using (testObjects.PublicationControlsToolBarService.UndoPublicationControlChanges.Subscribe(_ => result = true))
            {
                // ACT
                toolBar.UndoCommand.Execute();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotEnableUndoPublicationChanges_WhenDisposed()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().WithHasPublicationControlChanges(false)
                                                                                      .Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);
            testObjects.PublicationControlsToolBarService.Dispose();

            // ACT
            testObjects.HasPublicationControlChanges.OnNext(true);

            // ASSERT
            Assert.That(toolBar.UndoCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableUpdatePublicationChanges_WhenDisposed()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().WithHasPublicationControlChanges(false)
                                                                                             .Build();

            testObjects.PublicationControlsToolBarService.Attach(toolBar);
            testObjects.PublicationControlsToolBarService.Dispose();

            // ACT
            testObjects.HasPublicationControlChanges.OnNext(true);

            // ASSERT
            Assert.That(toolBar.UpdateCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldNotDispose_WhenDisposed()
        {
            var toolBar = new EditDialogToolBarViewModel();

            var testObjects = new PublicationControlsToolBarServiceTestObjectBuilder().WithHasPublicationControlChanges(false)
                                                                                      .Build();
            testObjects.PublicationControlsToolBarService.Attach(toolBar);
            testObjects.PublicationControlsToolBarService.Dispose();

            testObjects.PublicationControlsToolBarService.Dispose();

            // ACT
            testObjects.HasPublicationControlChanges.OnNext(true);

            // ASSERT
            Assert.That(toolBar.UpdateCommand.CanExecute(), Is.False);
        }
    }
}
