﻿using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    public interface IMonthEndRollToolBarServiceTestObjects
    {
		ISubject<User> CurrentUser { get; }
		MonthEndRollToolBarService MonthEndRollToolBarService { get; }
    }

    [TestFixture]
    public class MonthEndRollToolBarServiceTests
    {
        private class MonthEndRollToolBarServiceTestObjectBuilder
        {
            public IMonthEndRollToolBarServiceTestObjects Build()
            {
                var testObjects = new Mock<IMonthEndRollToolBarServiceTestObjects>();

                var currentUser = new Subject<User>();

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.CurrentUser)
                                   .Returns(currentUser);

				var monthEndRollToolBarService = new MonthEndRollToolBarService(curveControlService.Object, 
                                                                                TestMocks.GetSchedulerProvider().Object);
                
                testObjects.SetupGet(o => o.MonthEndRollToolBarService)
                           .Returns(monthEndRollToolBarService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowToolBarMenu_OnUser_With_EodPermissions()
        {
			var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.EomRoll.ToString(), 0, true)])
                                        .User();

			var toolBar = new MonthEndRollToolBarViewModel();

            var testObjects = new MonthEndRollToolBarServiceTestObjectBuilder().Build();

            testObjects.MonthEndRollToolBarService.Attach(toolBar);

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.True);
        }

		[Test]
        public void ShouldNotShowToolBarMenu_OnUser_With_MissingEodPermissions()
        {
            var user = new UserBuilder().User();

            var toolBar = new MonthEndRollToolBarViewModel();

            var testObjects = new MonthEndRollToolBarServiceTestObjectBuilder().Build();

            testObjects.MonthEndRollToolBarService.Attach(toolBar);

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldNotShowToolBarMenu_When_Disposed()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.EomRoll.ToString(), 0, true)])
                                        .User();

            var toolBar = new MonthEndRollToolBarViewModel();

            var testObjects = new MonthEndRollToolBarServiceTestObjectBuilder().Build();

            testObjects.MonthEndRollToolBarService.Attach(toolBar);

            testObjects.MonthEndRollToolBarService.Dispose();

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.EomRoll.ToString(), 0, true)])
                                        .User();

            var toolBar = new MonthEndRollToolBarViewModel();

            var testObjects = new MonthEndRollToolBarServiceTestObjectBuilder().Build();

            testObjects.MonthEndRollToolBarService.Attach(toolBar);

            testObjects.MonthEndRollToolBarService.Dispose();

			// ACT
			testObjects.MonthEndRollToolBarService.Dispose();
			testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.False);
        }
	}
}
