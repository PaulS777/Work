﻿using System;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    [TestFixture]
    public class FxPremiumsToolBarServiceTests
    {
        [Test]
        public void ShouldSetToolBarVisibleTrue_WhenToolBarAttached()
        {
            var toolBar = new FxPremiumsToolBarViewModel();

            var service = new FxPremiumsToolBarService();

            // ACT
            service.Attach(toolBar);

            // ASSERT
            Assert.IsTrue(service.ToolBarVisible);
        }

        [Test]
        public void ShouldSetToolBarVisibleFalse_WhenToolBarNotAttached()
        {
            var service = new FxPremiumsToolBarService();

            // ASSERT
            Assert.IsFalse(service.ToolBarVisible);
        }

        [Test]
        public void ShouldEnableUpdateCommand_OnSetUpdateTrue()
        {
            var toolBar = new FxPremiumsToolBarViewModel();

            var service = new FxPremiumsToolBarService();

            service.Attach(toolBar);

            // ACT
            service.SetCanUpdate(true);

            // ASSERT
            Assert.IsTrue(toolBar.UpdateCommand.CanExecute());
        }

        [Test]
        public void ShouldPublishUpdate_OnToolBarUpdateCommand()
        {
            var toolBar = new FxPremiumsToolBarViewModel();

            var service = new FxPremiumsToolBarService();

            service.Attach(toolBar);

            var result = false;

            using (service.Update.Subscribe(_ => result = true))
            {
                // ACT
                toolBar.UpdateCommand.Execute();

                // ASSERT
                Assert.IsTrue(result);
            }
        }
    }
}
