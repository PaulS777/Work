﻿using System;
using System.Reactive;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    public interface IStopTradingToolBarServiceTestObjects
    {
        IPriceCurveSettingsNonTradeableService PriceCurveSettingsService { get; }
        ISubject<Unit> StopTrading { get; }
        ISubject<bool> CurveSettingsLoaded { get; }
        ISubject<HubConnectionRunState> RunState { get; }
        ISubject<User> CurrentUser { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IProgressUpdateService ProgressUpdateService { get; }
        StopTradingToolBarService StopTradingToolBarService { get; }
    }

    [TestFixture]
    public class StopTradingToolBarServiceTests
    {
        private class StopTradingToolBarServiceTestObjectObjectBuilder
        {
            private HubConnectionRunState _runState;
            private bool _curveSettingsLoaded;

            public StopTradingToolBarServiceTestObjectObjectBuilder WithRunState(HubConnectionRunState value)
            {
                _runState = value;
                return this;
            }

            public StopTradingToolBarServiceTestObjectObjectBuilder WithCurveSettingsLoaded(bool value)
            {
                _curveSettingsLoaded = value;
                return this;
            }

            public IStopTradingToolBarServiceTestObjects Build()
            {
                var testObjects = new Mock<IStopTradingToolBarServiceTestObjects>();

                var curveSettingsLoaded = new BehaviorSubject<bool>(_curveSettingsLoaded);
                testObjects.SetupGet(o => o.CurveSettingsLoaded).Returns(curveSettingsLoaded);

                var stopTrading = new Subject<Unit>();

                testObjects.SetupGet(o => o.StopTrading)
                           .Returns(stopTrading);

                var priceCurveSettingsService = new Mock<IPriceCurveSettingsNonTradeableService>();

                priceCurveSettingsService.SetupGet(p => p.CurveSettingsLoaded)
                                         .Returns(curveSettingsLoaded);

                priceCurveSettingsService.Setup(p => p.SetAllPriceCurveSettingsNonTradeable())
                                         .Returns(stopTrading);

                testObjects.SetupGet(o => o.PriceCurveSettingsService)
                           .Returns(priceCurveSettingsService.Object);

                var currentUser = new BehaviorSubject<User>(null);

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var runState = new BehaviorSubject<HubConnectionRunState>(_runState);

                testObjects.SetupGet(o => o.RunState)
                           .Returns(runState);

                var adminApiConnectionService = new Mock<IAdminApiConnectionService>();

                adminApiConnectionService.SetupGet(a => a.RunState)
                                         .Returns(runState);

                adminApiConnectionService.SetupGet(a => a.CurrentUser)
                                         .Returns(currentUser);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var progressUpdateService = new Mock<IProgressUpdateService>();

                testObjects.SetupGet(o => o.ProgressUpdateService)
                           .Returns(progressUpdateService.Object);

                var toolBarService = new StopTradingToolBarService(priceCurveSettingsService.Object,
                                                                   adminApiConnectionService.Object,
                                                                   errorMessageDialogService.Object,
                                                                   popupNotificationService.Object,
                                                                   progressUpdateService.Object,
                                                                   TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.StopTradingToolBarService)
                           .Returns(toolBarService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowToolBar_When_UserHasPublicationAccessOnAllCurves()
        {
            var toolBar = new StopTradingToolBarViewModel();

            var crude = new CurveGroupTestObjectBuilder().Crude();
     
            var curveGroups = new[]
            {
                new AuthorisationCurveGroup(crude, true, true),
                new AuthorisationCurveGroup(crude, true, true)
            };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().Build();

            testObjects.StopTradingToolBarService.Attach(toolBar);

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldNotShowToolBar_When_UserDoesNotHavePublicationAccessOnAllCurves()
        {
            var toolBar = new StopTradingToolBarViewModel();

            var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[]
            {
                new AuthorisationCurveGroup(crude, true, true),
                new AuthorisationCurveGroup(crude, true, false)
            };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().Build();

            testObjects.StopTradingToolBarService.Attach(toolBar);

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.False);
        }

        [TestCase(HubConnectionRunState.Connected)]
        [TestCase(HubConnectionRunState.Reconnected)]
        public void ShouldEnableStopTrading_When_Connected_With_CurvesLoaded(HubConnectionRunState state)
        {
            var toolBar = new StopTradingToolBarViewModel();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().WithCurveSettingsLoaded(true)
                                                                                    .Build();

            testObjects.StopTradingToolBarService.Attach(toolBar);

            // ASSERT
            testObjects.RunState.OnNext(state);

            // ASSERT
            Assert.That(toolBar.StopTradingCommand.CanExecute(), Is.True);
        }

        [TestCase(HubConnectionRunState.NotSet)]
        [TestCase(HubConnectionRunState.FailedStartup)]
        [TestCase(HubConnectionRunState.Reconnecting)]
        public void ShouldDisableStopTrading_When_NotConnected(HubConnectionRunState state)
        {
            var toolBar = new StopTradingToolBarViewModel();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().WithRunState(state)
                                                                                    .WithCurveSettingsLoaded(true)
                                                                                    .Build();
            testObjects.StopTradingToolBarService.Attach(toolBar);

            // ACT
            testObjects.RunState.OnNext(state);

            // ASSERT
            Assert.That(toolBar.StopTradingCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableStopTrading_When_CurveSettingsNotLoaded_With_Connected()
        {
            var toolBar = new StopTradingToolBarViewModel();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                    .Build();
            testObjects.StopTradingToolBarService.Attach(toolBar);

            // ACT
            testObjects.CurveSettingsLoaded.OnNext(false);

            // ASSERT
            Assert.That(toolBar.StopTradingCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableStopTrading_And_SetProgress_When_StopTradingExecuted()
        {
            var toolBar = new StopTradingToolBarViewModel();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                    .WithCurveSettingsLoaded(true)
                                                                                    .Build();

            testObjects.StopTradingToolBarService.Attach(toolBar);

            // ACT
            toolBar.StopTradingCommand.Execute();

            // ASSERT
            Assert.That(toolBar.StopTradingCommand.CanExecute(), Is.False);

            Mock.Get(testObjects.ProgressUpdateService)
                .Verify(tb => tb.UpdateProgress(It.Is<ProgressUpdateArgs>(args => args.IsBusy)));
        }

        [Test]
        public void Should_CompleteProgress_And_Show_Popup_When_PriceCurveSettingsUpdateSuccess()
        {
            var toolBar = new StopTradingToolBarViewModel();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                    .WithCurveSettingsLoaded(true)
                                                                                    .Build();
            testObjects.StopTradingToolBarService.Attach(toolBar);

            toolBar.StopTradingCommand.Execute();
            Mock.Get(testObjects.ProgressUpdateService).Invocations.Clear();

            // ACT
            testObjects.StopTrading.OnNext(Unit.Default);

            // ASSERT
            Assert.That(toolBar.StopTradingCommand.CanExecute(), Is.True);

            Mock.Get(testObjects.ProgressUpdateService)
                .Verify(tb => tb.UpdateProgress(It.Is<ProgressUpdateArgs>(args => args.IsBusy == false)));

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(d => d.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void Should_CompleteProgress_And_Show_Dialog_When_PriceCurveSettingsUpdateFailed()
        {
            var toolBar = new StopTradingToolBarViewModel();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                    .WithCurveSettingsLoaded(true)
                                                                                    .Build();
            testObjects.StopTradingToolBarService.Attach(toolBar);

            toolBar.StopTradingCommand.Execute();
            Mock.Get(testObjects.ProgressUpdateService).Invocations.Clear();

            // ACT
            testObjects.StopTrading.OnError(new Exception());

            // ASSERT
            Assert.That(toolBar.StopTradingCommand.CanExecute(), Is.True);

            Mock.Get(testObjects.ProgressUpdateService)
                .Verify(tb => tb.UpdateProgress(It.Is<ProgressUpdateArgs>(args => args.IsBusy == false)));

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldNotEnableStopTrading_When_Disposed()
        {
            var toolBar = new StopTradingToolBarViewModel();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                    .Build();

            testObjects.StopTradingToolBarService.Attach(toolBar);
            testObjects.StopTradingToolBarService.Dispose();

            // ACT
            testObjects.CurveSettingsLoaded.OnNext(true);

            // ASSERT
            Assert.That(toolBar.StopTradingCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var toolBar = new StopTradingToolBarViewModel();

            var testObjects = new StopTradingToolBarServiceTestObjectObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                    .Build();

            testObjects.StopTradingToolBarService.Attach(toolBar);
            testObjects.StopTradingToolBarService.Dispose();

            // ACT
            testObjects.StopTradingToolBarService.Dispose();
            testObjects.CurveSettingsLoaded.OnNext(true);

            // ASSERT
            Assert.That(toolBar.StopTradingCommand.CanExecute(), Is.False);
        }
    }
}
