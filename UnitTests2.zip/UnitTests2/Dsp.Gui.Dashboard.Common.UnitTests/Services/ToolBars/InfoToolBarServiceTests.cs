﻿using System;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    [TestFixture]
    public class InfoToolBarServiceTests
    {
        [Test]
        public void ShouldPublishShowInfoHome_When_SetShowInfo()
        {
            var result = false;

            var service = new InfoToolBarService();

            using (service.ShowInfo.Subscribe(_ => result = true))
            {
                // ACT
                service.SetShowInfo();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishInfoHomeOpenState_When_SetInfoOpenState()
        {
            var result = false;

            var service = new InfoToolBarService();

            using (service.InfoOpenState.Subscribe(value => result = value))
            {
                // ACT
                service.SetInfoOpenState(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldNotPublishShowInfoHome_When_Disposed()
        {
            var result = false;

            var service = new InfoToolBarService();

            using (service.ShowInfo.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.SetShowInfo();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var result = false;

            var service = new InfoToolBarService();

            using (service.ShowInfo.Subscribe(_ => result = true))
            {
                service.Dispose();

                // ACT
                service.Dispose();
                service.SetShowInfo();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
