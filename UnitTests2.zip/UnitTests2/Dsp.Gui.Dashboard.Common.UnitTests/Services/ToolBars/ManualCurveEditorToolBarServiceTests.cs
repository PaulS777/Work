﻿using System;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    [TestFixture]
    public class ManualCurveEditorToolBarServiceTests
    {
        [Test]
        public void ShouldEnableUpdateCommand_OnSetUpdateTrue()
        {
            var toolBar = new CurveEditorToolBarViewModel();

			var service = new ManualCurveEditorToolBarService();

            service.Attach(toolBar);

            // ACT
            service.SetCanUpdate(true);

            // ASSERT
            Assert.That(toolBar.UpdateCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableUndoCommand_OnSetUndoTrue()
		{
			var toolBar = new CurveEditorToolBarViewModel();

            var service = new ManualCurveEditorToolBarService();

            service.Attach(toolBar);

            // ACT
            service.SetCanUndoChanges(true);

            // ASSERT
            Assert.That(toolBar.UndoCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldPublishUpdate_OnToolBarUpdateCommand()
        {
            var toolBar = new CurveEditorToolBarViewModel();

			var service = new ManualCurveEditorToolBarService();

            service.Attach(toolBar);

            var result = false;

            using (service.Update.Subscribe(_ => result = true))
            {
                // ACT
                toolBar.UpdateCommand.Execute();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishUndo_OnToolBarUndoCommand()
        {
            var toolBar = new CurveEditorToolBarViewModel();

			var service = new ManualCurveEditorToolBarService();

            service.Attach(toolBar);

            var result = false;

            using (service.UndoChanges.Subscribe(_ => result = true))
            {
                // ACT
                toolBar.UndoCommand.Execute();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }
    }
}
