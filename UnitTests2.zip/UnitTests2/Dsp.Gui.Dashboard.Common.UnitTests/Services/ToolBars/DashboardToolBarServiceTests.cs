﻿using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services.Navigation;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    public interface IDashboardToolBarServiceTestObjects
    {
        ISubject<bool> NavigationEnabled { get; }
        IDashboardSettingsService DashboardSettingsService { get; }
        ISubject<DashboardSettingsCollection> DashboardSettings { get; }
        DashboardToolBarService DashboardToolBarService { get; }
    }

    [TestFixture]
    public class DashboardToolBarServiceTests
    {
        private class DashboardToolBarServiceTestObjectBuilder
		{
			private bool _navigationEnabled;
            private DashboardSettingsCollection _dashboardSettings;

			public DashboardToolBarServiceTestObjectBuilder WithNavigationEnabled(bool value)
			{
				_navigationEnabled = value;
				return this;
			}

			public DashboardToolBarServiceTestObjectBuilder WithDashboardSettings(DashboardSettingsCollection value)
            {
                _dashboardSettings = value;
                return this;
            }

            public IDashboardToolBarServiceTestObjects Build()
            {
                var testObjects = new Mock<IDashboardToolBarServiceTestObjects>();

				var navigationEnabled = new BehaviorSubject<bool>(_navigationEnabled);

				testObjects.SetupGet(o => o.NavigationEnabled)
						   .Returns(navigationEnabled);

				var navigationMenuEnabledService = new Mock<INavigationMenuEnabledService>();

				navigationMenuEnabledService.SetupGet(n => n.NavigationEnabled)
											.Returns(navigationEnabled);

				var dashboardSettings = new BehaviorSubject<DashboardSettingsCollection>(_dashboardSettings);

                testObjects.SetupGet(o => o.DashboardSettings)
                           .Returns(dashboardSettings);

                var dashboardSettingsService = new Mock<IDashboardSettingsService>();

                dashboardSettingsService.SetupGet(d => d.DashboardSettings)
                                        .Returns(dashboardSettings);

                dashboardSettingsService.Setup(d => d.DashboardSettingsSnapshot())
                                        .Returns(_dashboardSettings.DashboardSettings);

                testObjects.SetupGet(o => o.DashboardSettingsService)
                           .Returns(dashboardSettingsService.Object);

                var toolBarService = new DashboardToolBarService(dashboardSettingsService.Object,
																 navigationMenuEnabledService.Object);

                testObjects.SetupGet(o => o.DashboardToolBarService)
                           .Returns(toolBarService);

                return testObjects.Object;
            }
        }

		[Test]
		public void ShouldEnableToolBar_When_Attach_With_NavigationEnabled()
		{
			var settings = new DashboardSettingsCollection
						   {
							   DashboardSettings = []
						   };

			var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithNavigationEnabled(true)
																			.WithDashboardSettings(settings)
																			.Build();

			var toolBar = new DashboardToolBarViewModel();

			// ACT
			testObjects.DashboardToolBarService.Attach(toolBar);

            // ASSERT
            Assert.That(toolBar.ToolBarEnabled, Is.True);
		}

		[Test]
		public void ShouldDisableToolBar_On_NavigationEnabledFalse()
		{
			var settings = new DashboardSettingsCollection
						   {
							   DashboardSettings = []
						   };

			var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithNavigationEnabled(true)
																			.WithDashboardSettings(settings)
																			.Build();

			var toolBar = new DashboardToolBarViewModel();

			testObjects.DashboardToolBarService.Attach(toolBar);

            // ACT
            testObjects.NavigationEnabled.OnNext(false);

			// ASSERT
			Assert.That(toolBar.ToolBarEnabled, Is.False);
		}

		[Test]
        public void ShouldEnableAddDashboardCommand_When_Attach_WithDashboardSettingsEmpty()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings = []
                           };

            var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithDashboardSettings(settings)
                                                                            .Build();

            var toolBar = new DashboardToolBarViewModel();

            // ACT
            testObjects.DashboardToolBarService.Attach(toolBar);

            // ACT
            Assert.That(toolBar.AddDashboardCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableAddDashboardCommand_When_SettingsHasPageAvailable()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new() { PageNumber = 1 },
                                   new() { PageNumber = 2 },
                                   new() { PageNumber = 3 },
                                   new() { PageNumber = 4 },
                                   new() { PageNumber = 5 },
                                   new() { PageNumber = 6 },
                                   new() { PageNumber = 7 },
                                   new() { PageNumber = 8 },
                                   new() { PageNumber = 9 }
                               ]
                           };

            var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithDashboardSettings(settings)
                                                                            .Build();

            var toolBar = new DashboardToolBarViewModel();

            // ACT
            testObjects.DashboardToolBarService.Attach(toolBar);

            // ACT
            Assert.That(toolBar.AddDashboardCommand.CanExecute(), Is.True);
        }

        [Test] 
        public void ShouldDisableAddDashboardCommand_When_SettingsHasNoSparePagesAvailable()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new() { PageNumber = 1 },
                                   new() { PageNumber = 2 },
                                   new() { PageNumber = 3 },
                                   new() { PageNumber = 4 },
                                   new() { PageNumber = 5 },
                                   new() { PageNumber = 6 },
                                   new() { PageNumber = 7 },
                                   new() { PageNumber = 8 },
                                   new() { PageNumber = 9 },
                                   new() { PageNumber = 10 }
                               ]
                           };

            var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithDashboardSettings(settings)
                                                                            .Build();

            var toolBar = new DashboardToolBarViewModel();

            // ACT
            testObjects.DashboardToolBarService.Attach(toolBar);

            // ASSERT
            Assert.That(toolBar.AddDashboardCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldAddNewDashboard_With_PageNumber_On_AddDashboardCommand_With_PageRemoved()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new() { PageNumber = 1 },
                                   new() { PageNumber = 2 },
                                   new() { PageNumber = 4 },
                                   new() { PageNumber = 5 },
                                   new() { PageNumber = 6 },
                                   new() { PageNumber = 7 },
                                   new() { PageNumber = 8 },
                                   new() { PageNumber = 9 },
                                   new() { PageNumber = 10 }
                               ]
                           };

            var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithDashboardSettings(settings)
                                                                            .Build();

            var toolBar = new DashboardToolBarViewModel();

            testObjects.DashboardToolBarService.Attach(toolBar);

            // ACT
            toolBar.AddDashboardCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.AddDashboard(3, Headers.PriceDashboard));
        }

        [Test]
        public void ShouldDisableAddDashboardCommand_When_DashboardSettingsUpdateEqualsMaxAllowed()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new() { PageNumber = 1 },
                                   new() { PageNumber = 2 },
                                   new() { PageNumber = 3 },
                                   new() { PageNumber = 4 },
                                   new() { PageNumber = 5 },
                                   new() { PageNumber = 6 },
                                   new() { PageNumber = 7 },
                                   new() { PageNumber = 8 },
                                   new() { PageNumber = 9 }
                               ]
                           };

            var settingsUpdate = new DashboardSettingsCollection
                                 {
                                     DashboardSettings =
                                     [
                                         new() { PageNumber = 1 },
                                         new() { PageNumber = 2 },
                                         new() { PageNumber = 3 },
                                         new() { PageNumber = 4 },
                                         new() { PageNumber = 5 },
                                         new() { PageNumber = 6 },
                                         new() { PageNumber = 7 },
                                         new() { PageNumber = 8 },
                                         new() { PageNumber = 9 },
                                         new() { PageNumber = 10 }
                                     ]
                                   };

            var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithDashboardSettings(settings)
                                                                            .Build();

            var toolBar = new DashboardToolBarViewModel();

            testObjects.DashboardToolBarService.Attach(toolBar);

            // ACT
            testObjects.DashboardSettings.OnNext(settingsUpdate);

            // ASSERT
            Assert.That(toolBar.AddDashboardCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableAddDashboardCommand_When_DashboardSettingsUpdateBelowMaxAllowed()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new() { PageNumber = 1 },
                                   new() { PageNumber = 2 },
                                   new() { PageNumber = 3 },
                                   new() { PageNumber = 4 },
                                   new() { PageNumber = 5 },
                                   new() { PageNumber = 6 },
                                   new() { PageNumber = 7 },
                                   new() { PageNumber = 8 },
                                   new() { PageNumber = 9 },
                                   new() { PageNumber = 10 }
                               ]
                           };

            var settingsUpdate = new DashboardSettingsCollection
                                 {
                                     DashboardSettings =
                                     [
                                         new() { PageNumber = 1 },
                                         new() { PageNumber = 2 },
                                         new() { PageNumber = 3 },
                                         new() { PageNumber = 4 },
                                         new() { PageNumber = 5 },
                                         new() { PageNumber = 6 },
                                         new() { PageNumber = 7 },
                                         new() { PageNumber = 8 },
                                         new() { PageNumber = 9 }
                                     ]
                                 };

            var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithDashboardSettings(settings)
                                                                            .Build();

            var toolBar = new DashboardToolBarViewModel();

            testObjects.DashboardToolBarService.Attach(toolBar);

            // ACT
            testObjects.DashboardSettings.OnNext(settingsUpdate);

            // ASSERT
            Assert.That(toolBar.AddDashboardCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldNotEnableAddDashboardCommand_When_Disposed()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new() { PageNumber = 1 },
                                   new() { PageNumber = 2 },
                                   new() { PageNumber = 3 },
                                   new() { PageNumber = 4 },
                                   new() { PageNumber = 5 },
                                   new() { PageNumber = 6 },
                                   new() { PageNumber = 7 },
                                   new() { PageNumber = 8 },
                                   new() { PageNumber = 9 },
                                   new() { PageNumber = 10 }
                               ]
                           };

            var settingsUpdate = new DashboardSettingsCollection
                                 {
                                     DashboardSettings =
                                     [
                                         new() { PageNumber = 1 },
                                         new() { PageNumber = 2 },
                                         new() { PageNumber = 3 },
                                         new() { PageNumber = 4 },
                                         new() { PageNumber = 5 },
                                         new() { PageNumber = 6 },
                                         new() { PageNumber = 7 },
                                         new() { PageNumber = 8 },
                                         new() { PageNumber = 9 }
                                     ]
                                 };

            var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithDashboardSettings(settings)
                                                                            .Build();

            var toolBar = new DashboardToolBarViewModel();

            testObjects.DashboardToolBarService.Attach(toolBar);

            testObjects.DashboardToolBarService.Dispose();

            // ACT
            testObjects.DashboardSettings.OnNext(settingsUpdate);

            // ASSERT
            Assert.That(toolBar.AddDashboardCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new() { PageNumber = 1 },
                                   new() { PageNumber = 2 },
                                   new() { PageNumber = 3 },
                                   new() { PageNumber = 4 },
                                   new() { PageNumber = 5 },
                                   new() { PageNumber = 6 },
                                   new() { PageNumber = 7 },
                                   new() { PageNumber = 8 },
                                   new() { PageNumber = 9 },
                                   new() { PageNumber = 10 }
                               ]
                           };

            var settingsUpdate = new DashboardSettingsCollection
                                 {
                                     DashboardSettings =
                                     [
                                         new() { PageNumber = 1 },
                                         new() { PageNumber = 2 },
                                         new() { PageNumber = 3 },
                                         new() { PageNumber = 4 },
                                         new() { PageNumber = 5 },
                                         new() { PageNumber = 6 },
                                         new() { PageNumber = 7 },
                                         new() { PageNumber = 8 },
                                         new() { PageNumber = 9 }
                                     ]
                                 };

            var testObjects = new DashboardToolBarServiceTestObjectBuilder().WithDashboardSettings(settings)
                                                                            .Build();

            var toolBar = new DashboardToolBarViewModel();

            testObjects.DashboardToolBarService.Attach(toolBar);

            testObjects.DashboardToolBarService.Dispose();

            // ACT
            testObjects.DashboardToolBarService.Dispose();
            testObjects.DashboardSettings.OnNext(settingsUpdate);

            // ASSERT
            Assert.That(toolBar.AddDashboardCommand.CanExecute(), Is.False);
        }
    }
}
