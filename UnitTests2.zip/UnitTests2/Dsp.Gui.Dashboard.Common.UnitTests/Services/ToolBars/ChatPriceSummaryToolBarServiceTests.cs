﻿using System;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    [TestFixture]
    public class ChatPriceSummaryToolBarServiceTests
    {
        [Test]
        public void ShouldPublishShowFilter_OnFilterMarketsCommand()
        {
            var viewModel = new ChatPriceSummaryToolBarViewModel();

            var service = new ChatPriceSummaryToolBarService();

            service.Attach(viewModel);

            var result = false;

            using (service.ShowMarketsFilter.Subscribe(_ => result = true))
            {
                // ACT
                viewModel.MarketsFilterCommand.Execute();

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldPublishShowSettings_OnSettingsCommand()
        {
            var viewModel = new ChatPriceSummaryToolBarViewModel();

            var service = new ChatPriceSummaryToolBarService();

            service.Attach(viewModel);

            var result = false;

            using (service.ShowColumnSettings.Subscribe(_ => result = true))
            {
                // ACT
                viewModel.ColumnSettingsCommand.Execute();

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldAddPriceGrid_OnAddPriceGridCommand()
        {
            var viewModel = new ChatPriceSummaryToolBarViewModel();

            var service = new ChatPriceSummaryToolBarService();

            service.Attach(viewModel);

            var result = false;

            using (service.AddPriceGrid.Subscribe(_ => result = true))
            {
                // ACT
                viewModel.AddPriceGridCommand.Execute();

                // ASSERT
                Assert.IsTrue(result);
            }
        }

        [Test]
        public void ShouldEnableAddPriceGrid_On_SetCanAddPriceGridTrue()
        {
            var viewModel = new ChatPriceSummaryToolBarViewModel();

            var service = new ChatPriceSummaryToolBarService();

            service.Attach(viewModel);

            // ACT
            service.SetCanAddPriceGrid(true);

            // ASSERT
            Assert.IsTrue(viewModel.AddPriceGridCommand.CanExecute());
        }

        [Test]
        public void ShouldDisableAddPriceGrid_On_SetCanAddPriceGridFalse()
        {
            var viewModel = new ChatPriceSummaryToolBarViewModel();

            var service = new ChatPriceSummaryToolBarService();

            service.Attach(viewModel);
            service.SetCanAddPriceGrid(true);

            // ACT
            service.SetCanAddPriceGrid(false);

            // ASSERT
            Assert.IsFalse(viewModel.AddPriceGridCommand.CanExecute());
        }
    }
}
