﻿using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    public interface IPublishersToolBarServiceTestObjects
    {
		ISubject<User> CurrentUser { get; }
		PublishersToolBarService PublishersToolBarService { get; }
    }

    [TestFixture]
    public class PublishersToolBarServiceTests
    {
        private class PublishersToolBarServiceTestObjectBuilder
        {
            public IPublishersToolBarServiceTestObjects Build()
            {
                var testObjects = new Mock<IPublishersToolBarServiceTestObjects>();

				var currentUser = new Subject<User>();

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.CurrentUser)
                                   .Returns(currentUser);

				var toolBarService = new PublishersToolBarService(curveControlService.Object, 
                                                                  TestMocks.GetSchedulerProvider().Object);


                testObjects.SetupGet(o => o.PublishersToolBarService)
                           .Returns(toolBarService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowToolBarMenu_On_User_With_PublisherPermissions()
        {
			var user = new UserBuilder().WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)])
                                        .User();

			var toolBar = new PublishersToolBarViewModel();

            var testObjects = new PublishersToolBarServiceTestObjectBuilder().Build();

            testObjects.PublishersToolBarService.Attach(toolBar);

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldNotShowToolBarMenu_On_User_With_MissingPublisherPermissions()
        {
			var user = new UserBuilder().User();

            var toolBar = new PublishersToolBarViewModel();

            var testObjects = new PublishersToolBarServiceTestObjectBuilder().Build();

            testObjects.PublishersToolBarService.Attach(toolBar);

            // ACT
            testObjects.CurrentUser.OnNext(user);

			// ASSERT
			Assert.That(toolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldNotShowToolBarMenu_When_Disposed()
        {
            var user = new UserBuilder().WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)])
                                        .User();

            var toolBar = new PublishersToolBarViewModel();

            var testObjects = new PublishersToolBarServiceTestObjectBuilder().Build();

            testObjects.PublishersToolBarService.Attach(toolBar);

            testObjects.PublishersToolBarService.Dispose();

			// ACT
			testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var user = new UserBuilder().WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)])
                                        .User();

            var toolBar = new PublishersToolBarViewModel();

            var testObjects = new PublishersToolBarServiceTestObjectBuilder().Build();

            testObjects.PublishersToolBarService.Attach(toolBar);

            testObjects.PublishersToolBarService.Dispose();

            // ACT
            testObjects.CurrentUser.OnNext(user);

            // ASSERT
            Assert.That(toolBar.ShowToolBar, Is.False);
		}
    }
}
