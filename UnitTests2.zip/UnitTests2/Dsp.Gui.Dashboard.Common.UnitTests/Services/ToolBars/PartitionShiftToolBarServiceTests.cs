﻿namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    class PartitionShiftToolBarServiceTests
    {
    }
}
