﻿using System;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    [TestFixture]
    public class UserAdminToolBarServiceTests
    {
        [Test]
        public void ShouldEnableUpdateUserCommand_OnCanUpdateUserTrue()
        {
            var toolBar = new UserAdminToolBarViewModel();

            var service = new UserAdminToolBarService();

            service.Attach(toolBar);

            // ACT
            service.SetCanUpdateUser(true);

            // ASSERT
            Assert.That(toolBar.UpdateUserCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldPublishUpdateUser_OnUpdateUserCommand()
        {
            var toolBar = new UserAdminToolBarViewModel();

            var service = new UserAdminToolBarService();

            service.Attach(toolBar);

            var result = false;

            using (service.UpdateUser.Subscribe(_ => result = true))
            {
                // ACT
                toolBar.UpdateUserCommand.Execute();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }
    }
}
