﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Navigation;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.ToolBar;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Services.ToolBars
{
    public interface IAdminUpdateToolBarServiceBaseTestObjects
    {
        INavigationMenuEnabledService NavigationMenuService { get; }
        AdminUpdateToolBarServiceBase AdminUpdateToolBarService { get; }
    }

    [TestFixture]
    public class AdminUpdateToolBarServiceBaseTests
    {
        private class AdminUpdateToolBarServiceBaseTestObjectBuilder
        {
            public IAdminUpdateToolBarServiceBaseTestObjects Build()
            {
                var testObjects = new Mock<IAdminUpdateToolBarServiceBaseTestObjects>();

                var navigationMenuService = new Mock<INavigationMenuEnabledService>();

                testObjects.SetupGet(o => o.NavigationMenuService)
                           .Returns(navigationMenuService.Object);

                var toolBarService = new AdminUpdateToolBarServiceBase(navigationMenuService.Object);

                testObjects.SetupGet(o => o.AdminUpdateToolBarService)
                           .Returns(toolBarService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldEnableUpdateCommand_OnSetUpdateTrue()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            // ACT
            testObjects.AdminUpdateToolBarService.SetCanUpdate(true);

            // ASSERT
            Assert.That(toolBar.UpdateCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableUndoCommand_OnSetUndoTrue()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            // ACT
            testObjects.AdminUpdateToolBarService.SetCanUndo(true);

            // ASSERT
            Assert.That(toolBar.UndoCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableNavigation_OnSetCanUpdateTrue()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            // ACT
            testObjects.AdminUpdateToolBarService.SetCanUpdate(true);

            // ASSERT
            Mock.Get(testObjects.NavigationMenuService)
                .Verify(m => m.SetNavigationEnabled(false));
        }

        [Test]
        public void ShouldEnableNavigation_OnSetCanUpdateFalse()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            // ACT
            testObjects.AdminUpdateToolBarService.SetCanUpdate(false);

            // ASSERT
            Mock.Get(testObjects.NavigationMenuService)
                .Verify(m => m.SetNavigationEnabled(true));
        }

        [Test]
        public void ShouldPublishUpdate_OnToolBarUpdateCommand()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            var result = false;

            using (testObjects.AdminUpdateToolBarService.Update.Subscribe(_ => result = true))
            {
                // ACT
                toolBar.UpdateCommand.Execute();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishUndo_OnToolBarUndoCommand()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            var result = false;

            using (testObjects.AdminUpdateToolBarService.Undo.Subscribe(_ => result = true))
            {
                // ACT
                toolBar.UndoCommand.Execute();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldSetValidationError()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            // ACT
            testObjects.AdminUpdateToolBarService.SetValidationError("error-1");

            // ASSERT
            Assert.That(toolBar.ValidationText, Is.EqualTo("error-1"));
        }

        [Test]
        public void ShouldSetValidationErrors()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            var errors = new List<string> {"error-1", "error-2"};

            // ACT
            testObjects.AdminUpdateToolBarService.SetValidationErrors(errors);

            // ASSERT
            Assert.That(toolBar.ValidationText, Is.EqualTo($"error-1{Environment.NewLine}error-2"));
        }

        [Test]
        public void ShouldClearValidationErrors()
        {
            var toolBar = new AdminUpdateToolBarViewModel()
            {
                ValidationText = "error"
            };

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            // ACT
            testObjects.AdminUpdateToolBarService.ClearValidation();

            // ASSERT
            Assert.IsNull(toolBar.ValidationText);
        }

        [Test]
        public void ShouldNotPublishUpdate_When_Disposed()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            var result = false;

            using (testObjects.AdminUpdateToolBarService.Update.Subscribe(_ => result = true))
            {
                testObjects.AdminUpdateToolBarService.Dispose();

                // ACT
                toolBar.UpdateCommand.Execute();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishUndo_When_Disposed()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            var result = false;

            using (testObjects.AdminUpdateToolBarService.Undo.Subscribe(_ => result = true))
            {
                testObjects.AdminUpdateToolBarService.Dispose();

                // ACT
                toolBar.UndoCommand.Execute();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var toolBar = new AdminUpdateToolBarViewModel();

            var testObjects = new AdminUpdateToolBarServiceBaseTestObjectBuilder().Build();

            testObjects.AdminUpdateToolBarService.Attach(toolBar);

            var result = false;

            using (testObjects.AdminUpdateToolBarService.Update.Subscribe(_ => result = true))
            {
                testObjects.AdminUpdateToolBarService.Dispose();

                // ACT
                testObjects.AdminUpdateToolBarService.Dispose();
                toolBar.UpdateCommand.Execute();

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
