﻿using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests
{
    [TestFixture]
    public class UpdateGuardSectionTests
    {
        [Test]
        public void ShouldSetIndicatorContext()
        {
            var indicator = true;

            using (new UpdateGuardSection(value => indicator = value, true))
            {
                // ASSERT
                Assert.IsFalse(indicator);
            }
            // ASSERT
            Assert.IsTrue(indicator);
        }
    }
}
