﻿using Dsp.Gui.Dashboard.Common.Settings;
using System;
using System.Collections.Generic;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Helpers
{
    public class DashBoardSettingsComparer : IEqualityComparer<DashboardSettings>
    {
        public bool Equals(DashboardSettings x, DashboardSettings y)
        {
            if (ReferenceEquals(x, y)) return true;
            if (ReferenceEquals(x, null)) return false;
            if (ReferenceEquals(y, null)) return false;
            if (x.GetType() != y.GetType()) return false;

            return x.PageNumber == y.PageNumber && x.Name == y.Name;
        }

        public int GetHashCode(DashboardSettings obj)
        {
            return HashCode.Combine(obj.PageNumber, obj.Name);
        }
    }
}
