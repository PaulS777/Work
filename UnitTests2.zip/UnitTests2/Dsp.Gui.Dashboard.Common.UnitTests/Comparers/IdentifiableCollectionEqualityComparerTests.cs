﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.Common.Comparers;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Common.UnitTests.Comparers
{
	[TestFixture]
	public class IdentifiableCollectionEqualityComparerTests
	{
		[Test]
		public void ShouldReturnTrue_When_Equals_With_SameIdsDifferentOrder_IgnoreOrder_True()
		{
			var collection1 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 1),
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 3)
							  };

			var collection2 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 3),
								  Mock.Of<IIdentifiable>(i => i.Id == 1)
							  };

			var comparer = new IdentifiableCollectionEqualityComparer(true);

			// ACT
			var result = comparer.Equals(collection1, collection2);

			// ASSERT
			Assert.That(result, Is.True);
		}

		[Test]
		public void ShouldReturnFalse_When_Equals_With_SameIdsDifferentOrder_IgnoreOrder_False()
		{
			var collection1 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 1),
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 3)
							  };

			var collection2 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 3),
								  Mock.Of<IIdentifiable>(i => i.Id == 1)
							  };

			var comparer = new IdentifiableCollectionEqualityComparer(false);

			// ACT
			var result = comparer.Equals(collection1, collection2);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnFalse_When_Equals_With_DifferentIds_IgnoreOrder_True()
		{
			var collection1 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 1),
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 3)
							  };

			var collection2 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 1),
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 4)
							  };

			var comparer = new IdentifiableCollectionEqualityComparer(true);

			// ACT
			var result = comparer.Equals(collection1, collection2);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnTrue_When_Equals_With_SameReference()
		{
			var collection1 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 1),
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 3)
							  };

			var comparer = new IdentifiableCollectionEqualityComparer();

			// ACT
			var result = comparer.Equals(collection1, collection1);

			// ASSERT
			Assert.That(result, Is.True);
		}

		[Test]
		public void ShouldReturnFalse_When_Equals_With_FirstCollectionNull()
		{
			var collection1 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 1),
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 3)
							  };

			var comparer = new IdentifiableCollectionEqualityComparer();

			// ACT
			var result = comparer.Equals(null, collection1);

			// ASSERT
			Assert.That(result, Is.False);
		}


		[Test]
		public void ShouldReturnFalse_When_Equals_With_SecondCollectionNull()
		{
			var collection1 = new[]
							  {
								  Mock.Of<IIdentifiable>(i => i.Id == 1),
								  Mock.Of<IIdentifiable>(i => i.Id == 2),
								  Mock.Of<IIdentifiable>(i => i.Id == 3)
							  };

			var comparer = new IdentifiableCollectionEqualityComparer();

			// ACT
			var result = comparer.Equals(collection1, null);

			// ASSERT
			Assert.That(result, Is.False);
		}
	}
}
