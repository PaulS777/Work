﻿using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.PriceGrid.Services.PriceStream.Manual;
using Moq;

namespace Dsp.Gui.PriceGrid.UnitTests
{
    internal class MockManualPriceStreamServiceBuilder
    {
        private LinkedCurve _linkedCurve;
        private string _description;
        private int _precision;
        private ISubject<ManualCurveDefinition<MonthlyTenor>> _manualCurveSubject;
        private ManualCurveDefinition<MonthlyTenor> _manualCurve;

        public MockManualPriceStreamServiceBuilder WithLinkedCurve(LinkedCurve value)
        {
            _linkedCurve = value;
            return this;
        }

        public MockManualPriceStreamServiceBuilder WithDescription(string value)
        {
            _description = value;
            return this;
        }

        public MockManualPriceStreamServiceBuilder WithPrecision(int value)
        {
            _precision = value;
            return this;
        }

        public MockManualPriceStreamServiceBuilder WithManualCurveSubject(ISubject<ManualCurveDefinition<MonthlyTenor>> value)
        {
            _manualCurveSubject = value;
            return this;
        }

        public MockManualPriceStreamServiceBuilder WithManualCurve(ManualCurveDefinition<MonthlyTenor> value)
        {
            _manualCurve = value;
            return this;
        }

        public Mock<IManualPriceStreamService> Build()
        {
            var details = new PriceCurveDetails(PriceCurveType.Manual,
                                                _linkedCurve,
                                                _precision);

            var service = new Mock<IManualPriceStreamService>();

            service.Setup(s => s.GetDetails())
                   .Returns(details);

            service.SetupGet(s => s.ManualCurve)
                   .Returns(_manualCurveSubject);

            service.SetupGet(s => s.ManualCurveSnapshot)
                   .Returns(_manualCurve);

            return service;
        }
    }
}
