﻿using Dsp.DataContracts;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid.Model;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Common
{
    [TestFixture]
    public class TenorEnvelopeTests
    {
        [Test]
        public void ShouldConstructTenorEnvelope_From_YearlyTenor()
        {
            var tenor = new AnnualTenor("2019");

            var envelope = new TenorEnvelope(tenor);

            Assert.That(envelope.TenorType, Is.EqualTo(RowTenorType.Yearly));
            Assert.That(envelope.Tenor, Is.EqualTo(tenor));
            Assert.That(envelope.TenorIdentifier, Is.EqualTo("2019"));
            Assert.That(envelope.TenorValue, Is.EqualTo(20190000));
        }

        [TestCase(1, "2019Q1", 20190100)]
        [TestCase(2, "2019Q2", 20190200)]
        [TestCase(3, "2019Q3", 20190300)]
        [TestCase(4, "2019Q4", 20190400)]
        public void ShouldConstructTenorEnvelope_From_QuarterlyTenor(int quarter, string tenorIdentifier, int tenorValue)
        {
            var tenor = new QuarterlyTenor(2019, 3);

            var envelope = new TenorEnvelope(tenor);

            Assert.That(envelope.TenorType, Is.EqualTo(RowTenorType.Quarterly));
            Assert.That(envelope.Tenor, Is.EqualTo(tenor));
            Assert.That(tenorIdentifier, Is.EqualTo(tenorIdentifier));
            Assert.That(tenorValue, Is.EqualTo(tenorValue));
        }

        [TestCase(1, "Jan19", 20190101)]
        [TestCase(2, "Feb19", 20190102)]
        [TestCase(3, "Mar19", 20190103)]
        [TestCase(4, "Apr19", 20190204)]
        [TestCase(5, "May19", 20190205)]
        [TestCase(6, "Jun19", 20190206)]
        [TestCase(7, "Jul19", 20190307)]
        [TestCase(8, "Aug19", 20190308)]
        [TestCase(9, "Sep19", 20190309)]
        [TestCase(10, "Oct19", 20190410)]
        [TestCase(11, "Nov19", 20190411)]
        [TestCase(12, "Dec19", 20190412)]
        public void ShouldConstructTenorEnvelope_From_MonthlyTenor(int month, string tenorIdentifier, int tenorValue)
        {
            var tenor = new MonthlyTenor(2019, month);

            var envelope = new TenorEnvelope(tenor);

            Assert.That(envelope.TenorType, Is.EqualTo(RowTenorType.Monthly));
            Assert.That(envelope.Tenor, Is.EqualTo(tenor));
            Assert.That(envelope.TenorIdentifier, Is.EqualTo(tenorIdentifier));
            Assert.That(envelope.TenorValue, Is.EqualTo(tenorValue));
        }
    }
}
