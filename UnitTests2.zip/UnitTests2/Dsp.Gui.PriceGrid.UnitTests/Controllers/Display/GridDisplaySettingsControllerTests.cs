﻿using Dsp.Gui.Dashboard.ToolBar.Markets.ViewModels;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.PriceGrid.Controllers.Display;
using Dsp.Gui.PriceGrid.ViewModels.Display;
using Moq;
using NUnit.Framework;
using System;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Display
{
    public interface IGridDisplaySettingsControllerTestObjects
    {
        ITenorPriceRowDataSource DataSource { get; }
        GridDisplaySettingsViewModel ViewModel { get; }
        GridDisplaySettingsController Controller { get; }
    }

    [TestFixture]
    public class GridDisplaySettingsControllerTests
    {
        private class GridDisplaySettingsControllerTestObjectBuilder
        {
            private bool _showDialog;

            public GridDisplaySettingsControllerTestObjectBuilder WithShowDialog(bool value)
            {
                _showDialog = value;
                return this;
            }

            public IGridDisplaySettingsControllerTestObjects Build()
            {
                var testObjects = new Mock<IGridDisplaySettingsControllerTestObjects>();

                var controller = new GridDisplaySettingsController();

                controller.ViewModel.ShowDialog = _showDialog;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowDialog_On_ToolBarShowPriceGridSettingsTrue()
        {
            var testObjects = new GridDisplaySettingsControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>())
            {
                                                ShowPriceGridSettings = false
                                            };

            // ACT
            testObjects.ViewModel.ToolBar.ShowPriceGridSettings = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldCloseDialogOnCommand()
        {
            var testObjects = new GridDisplaySettingsControllerTestObjectBuilder().WithShowDialog(true)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.CloseDialogCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldNotShowDialog_When_Disposed()
        {
            var testObjects = new GridDisplaySettingsControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>())
            {
                                                ShowPriceGridSettings = false
                                            };

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.ToolBar.ShowPriceGridSettings = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new GridDisplaySettingsControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>())
            {
                                                ShowPriceGridSettings = false
                                            };

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.ToolBar.ShowPriceGridSettings = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }
    }
}
