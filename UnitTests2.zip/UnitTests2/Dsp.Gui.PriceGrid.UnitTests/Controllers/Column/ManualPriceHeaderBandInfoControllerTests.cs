﻿using System;
using Dsp.Gui.PriceGrid.Controllers.Column;
using Dsp.Gui.PriceGrid.Services.Column.Manual;
using Dsp.Gui.PriceGrid.Services.Column.Manual.ChatPrice;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Column
{
    internal interface IManualPriceHeaderBandInfoControllerTestObjects
    {
        IManualCurveMonitor ManualCurveMonitor { get; }
        IManualPriceCanUseChatPriceService CanUseChatPriceService { get; }
        IManualOverridesIsExcelSourceService ManualOverridesIsExcelSourceService { get; }
        ManualPriceHeaderBandInfo ViewModel { get; }
        ManualPriceHeaderBandInfoController Controller { get; }
    }

    [TestFixture]
    public class ManualPriceHeaderBandInfoControllerTests
    {
        private class ManualPriceHeaderBandInfoControllerTestObjectBuilder
        {
            private bool _subscribeUpdates;

            public ManualPriceHeaderBandInfoControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public IManualPriceHeaderBandInfoControllerTestObjects Build()
            {
                var testObjects = new Mock<IManualPriceHeaderBandInfoControllerTestObjects>();

                var manualCurveMonitor = new Mock<IManualCurveMonitor>();

                testObjects.SetupGet(o => o.ManualCurveMonitor)
                           .Returns(manualCurveMonitor.Object);

                var canUseChatPriceService = new Mock<IManualPriceCanUseChatPriceService>();

                testObjects.SetupGet(o => o.CanUseChatPriceService)
                           .Returns(canUseChatPriceService.Object);

                var manualPriceBandInfo = new ManualPriceBandInfo(Mock.Of<IDisposable>());

                var manualPriceBandInfoController = new Mock<IManualPriceBandInfoController>();

                manualPriceBandInfoController.SetupGet(c => c.ViewModel)
                                             .Returns(manualPriceBandInfo);

                var chatPriceBandInfo = new ChatPriceBandInfo(Mock.Of<IDisposable>());

                var chatPriceBandInfoController = new Mock<IChatPriceBandInfoController>();

                chatPriceBandInfoController.SetupGet(c => c.ViewModel)
                                           .Returns(chatPriceBandInfo);

                var manualOverridesIsExcelSourceService = new Mock<IManualOverridesIsExcelSourceService>();

                testObjects.SetupGet(o => o.ManualOverridesIsExcelSourceService)
                           .Returns(manualOverridesIsExcelSourceService.Object);

                var controller = new ManualPriceHeaderBandInfoController(manualPriceBandInfoController.Object,
                                                                         manualCurveMonitor.Object,
                                                                         chatPriceBandInfoController.Object,
                                                                         canUseChatPriceService.Object,
                                                                         manualOverridesIsExcelSourceService.Object);

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldConstructViewModel()
        {
            // ACT
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel, Is.Not.Null);
            Assert.That(testObjects.ViewModel.BandHeaderType, Is.EqualTo(BandHeaderType.ManualPriceHeader));
            Assert.That(testObjects.ViewModel.ManualPriceBandInfo, Is.Not.Null);
            Assert.That(testObjects.ViewModel.ChatPriceBandInfo, Is.Not.Null);
        }

        [Test]
        public void ShouldAttachServices()
        {
            // ACT
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.ManualCurveMonitor)
                .Verify(t => t.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.CanUseChatPriceService)
                .Verify(cp => cp.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.ManualOverridesIsExcelSourceService)
                .Verify(e => e.AttachBandInfo(testObjects.ViewModel));
        }


        [Test]
        public void ShouldAddChatPriceBand_When_ShowChatPriceTrue()
        {
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().Build();

            testObjects.ViewModel.BandInfos = [testObjects.ViewModel.ManualPriceBandInfo];

            // ACT
            testObjects.ViewModel.ShowChatPrice = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(2));
            Assert.AreSame(testObjects.ViewModel.ChatPriceBandInfo, testObjects.ViewModel.BandInfos[1]);

            Assert.That(testObjects.ViewModel.ChatPriceBandInfo.ShowChatPrice, Is.True);
        }

        [Test]
        public void ShouldHideChatPriceBand_When_ShowChatPriceFalse()
        {
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().Build();

            testObjects.ViewModel.BandInfos = [testObjects.ViewModel.ManualPriceBandInfo];

            testObjects.ViewModel.ShowChatPrice = true;

            // ACT
            testObjects.ViewModel.ShowChatPrice = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.ChatPriceBandInfo.ShowChatPrice, Is.False);
        }

        [Test]
        public void ShouldNotAddChatPriceBand_When_ShowChatPrice_WithExistingChatPriceBand()
        {
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().Build();

            testObjects.ViewModel.BandInfos =
            [
                testObjects.ViewModel.ManualPriceBandInfo,
                testObjects.ViewModel.ChatPriceBandInfo
            ];

            // ACT
            testObjects.ViewModel.ShowChatPrice = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldSubscribeUpdates_And_UpdateBandInfos_When_SubscribeUpdatesTrue()
        {
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.ManualCurveMonitor)
                .Verify(t => t.SubscribeUpdates());

            Mock.Get(testObjects.CanUseChatPriceService)
                .Verify(cp => cp.SubscribeUpdates());

            Mock.Get(testObjects.ManualOverridesIsExcelSourceService)
                .Verify(e => e.SubscribeUpdates());

            Assert.That(testObjects.ViewModel.ManualPriceBandInfo.SubscribeUpdates, Is.True);
            Assert.That(testObjects.ViewModel.ChatPriceBandInfo.SubscribeUpdates, Is.True);
        }

        [Test]
        public void ShouldUnsubscribeUpdates_And_UpdateBandInfos_When_SubscribeUpdatesFalse()
        {
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                        .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.ManualCurveMonitor)
                .Verify(t => t.UnsubscribeUpdates());

            Mock.Get(testObjects.CanUseChatPriceService)
                .Verify(cp => cp.UnsubscribeUpdates());

            Mock.Get(testObjects.ManualOverridesIsExcelSourceService)
                .Verify(e => e.UnsubscribeUpdates());

            Assert.That(testObjects.ViewModel.ManualPriceBandInfo.SubscribeUpdates, Is.False);
            Assert.That(testObjects.ViewModel.ChatPriceBandInfo.SubscribeUpdates, Is.False);
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ManualCurveMonitor)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.CanUseChatPriceService)
                .Verify(cp => cp.Dispose());

            Mock.Get(testObjects.ManualOverridesIsExcelSourceService)
                .Verify(e => e.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new ManualPriceHeaderBandInfoControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();
            Mock.Get(testObjects.CanUseChatPriceService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.CanUseChatPriceService)
                .Verify(cp => cp.Dispose(), Times.Never);
        }
    }
}
