﻿using System.Collections.Generic;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.Controllers.Column;
using Dsp.Gui.PriceGrid.Services.GridSummary;
using Dsp.Gui.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Column
{
    internal interface ILivePriceColumnInfoControllerTestObjects
    {
        IAveragePriceCalculator AveragePriceCalculator { get; }
        ISpreadPriceCalculator SpreadPriceCalculator { get; }
        IDashboardSettingsUpdater DashboardSettingsUpdater { get; }
        ColumnInfo ViewModel { get; }
        LivePriceColumnInfoController Controller { get; }
    }

    [TestFixture]
    public class LivePriceColumnInfoControllerTests
    {
        private class LivePriceColumnInfoControllerTestObjectBuilder
        {
            private int _pageNumber;
            private LinkedCurve _linkedCurve;
            private List<PriceCellViewModel> _priceCells;
            private bool _showSummary;

            public LivePriceColumnInfoControllerTestObjectBuilder WithPageNumber(int value)
            {
                _pageNumber = value;
                return this;
            }

            public LivePriceColumnInfoControllerTestObjectBuilder WithLinkedCurve(LinkedCurve value)
            {
                _linkedCurve = value;
                return this;
            }

            public LivePriceColumnInfoControllerTestObjectBuilder WithPriceCells(List<PriceCellViewModel> values)
            {
                _priceCells = values;
                return this;
            }

            public LivePriceColumnInfoControllerTestObjectBuilder WithShowSummary(bool value)
            {
                _showSummary = value;
                return this;
            }

            public ILivePriceColumnInfoControllerTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceColumnInfoControllerTestObjects>();

                var dashboardSettingsService = new Mock<IDashboardSettingsService>();

                testObjects.SetupGet(o => o.DashboardSettingsUpdater)
                           .Returns(dashboardSettingsService.Object);

                var averagePriceCalculator = new Mock<IAveragePriceCalculator>();

                testObjects.SetupGet(o => o.AveragePriceCalculator)
                           .Returns(averagePriceCalculator.Object);

                var spreadPriceCalculator = new Mock<ISpreadPriceCalculator>();

                testObjects.SetupGet(o => o.SpreadPriceCalculator)
                           .Returns(spreadPriceCalculator.Object);

                var controller = new LivePriceColumnInfoController
                {
                    DashboardSettingsService = dashboardSettingsService.Object,
                    AveragePriceCalculator = averagePriceCalculator.Object,
                    SpreadPriceCalculator = spreadPriceCalculator.Object
                };

                var details = new BandInfoDetails(_pageNumber, _linkedCurve, new PriceGridViewModel());

                details.SetPriceCells(_priceCells);

                controller.ViewModel.SetDetails(details);
                controller.ViewModel.ShowSummary = _showSummary;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldEnableColumnSpreadsCommand_On_CanSelectSpreadsTrue()
        {
            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanSelectSpreads = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.SetColumnSpreadsCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableColumnSpreadsCommand_On_CanSelectSpreadsFalse()
        {
            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().Build();

            testObjects.ViewModel.CanSelectSpreads = true;

            // ACT
            testObjects.ViewModel.CanSelectSpreads = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.SetColumnSpreadsCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldUpdateColumnAverages_On_SetColumnAveragesCommand_With_SelectedMonths()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell1 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithIsSelected(true)
                                                             .WithTenorValue(1000)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithIsSelected(false)
                                                             .WithTenorValue(1100)
                                                             .PriceCell();

            var priceCells = new List<PriceCellViewModel>
            {
                priceCell1, priceCell2
            };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.SetColumnAveragesCommand.Execute();

            // ASSERT
            Assert.That(priceCell1.LivePrice.IsSelectedAverage, Is.True);
            Assert.That(priceCell2.LivePrice.IsSelectedAverage, Is.False);

            Mock.Get(testObjects.AveragePriceCalculator)
                .Verify(c => c.Calculate(testObjects.ViewModel));

            Mock.Get(testObjects.DashboardSettingsUpdater)
                .Verify(u => u.UpdateColumnAverages(1, linkedCurve, It.Is<int[]>(a => a.Length == 1
                                                                                 && a[0] == 1000)));
        }

        [Test]
        public void ShouldShowSummary_On_SetColumnAveragesCommand_With_SelectedMonths()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell1 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithIsSelected(true)
                                                             .WithTenorValue(1000)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithIsSelected(false)
                                                             .WithTenorValue(1100)
                                                             .PriceCell();

            var priceCells = new List<PriceCellViewModel>
                             {
                                 priceCell1, priceCell2
                             };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.SetColumnAveragesCommand.Execute();

            // ACT
            Assert.That(testObjects.ViewModel.ShowSummary, Is.True);
        }

        [Test]
        public void ShouldUpdateColumnAverages_On_SetColumnAveragesCommand_With_SelectedMonthsByQuarter()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell1 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithIsSelected(true)
                                                             .WithIsSelectedMonthByQuarter(false)
                                                             .WithTenorValue(1000)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithIsSelected(false)
                                                             .WithIsSelectedMonthByQuarter(true)
                                                             .WithTenorValue(1100)
                                                             .PriceCell();

            var priceCells = new List<PriceCellViewModel>
            {
                priceCell1, priceCell2
            };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.SetColumnAveragesCommand.Execute();

            // ASSERT
            Assert.That(priceCell1.LivePrice.IsSelectedAverage, Is.False);
            Assert.That(priceCell2.LivePrice.IsSelectedAverage, Is.True);

            Mock.Get(testObjects.AveragePriceCalculator)
                .Verify(c => c.Calculate(testObjects.ViewModel));

            Mock.Get(testObjects.DashboardSettingsUpdater)
                .Verify(u => u.UpdateColumnAverages(1, linkedCurve, It.Is<int[]>(a => a.Length == 1
                                                                                 && a[0] == 1100)));
        }

        [Test]
        public void ShouldUpdateColumnAverages_On_ClearColumnAveragesCommand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new PriceCellTestObjectBuilder().WithIsSelectedAverage(true)
                                                            .PriceCell();

            var priceCells = new List<PriceCellViewModel>{ priceCell };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.ClearColumnAveragesCommand.Execute();

            // ASSERT
            Assert.That(priceCell.LivePrice.IsSelectedAverage, Is.False);

            Mock.Get(testObjects.AveragePriceCalculator)
                .Verify(c => c.Calculate(testObjects.ViewModel));

            Mock.Get(testObjects.DashboardSettingsUpdater)
                .Verify(u => u.UpdateColumnAverages(1, linkedCurve, It.Is<int[]>(a  => a.Length == 0)));
        }

        [Test]
        public void ShouldHideSummary_On_ClearColumnAveragesCommand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new PriceCellTestObjectBuilder().WithIsSelectedAverage(true)
                                                            .PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .WithShowSummary(true)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.ClearColumnAveragesCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowSummary, Is.False);
        }

        [Test]
        public void ShouldUpdateColumnSpreads_On_SetColumnSpreadsCommand_With_MonthsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell1 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Quarterly).PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenorValue(1000)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell3 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenorValue(1100)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell4 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Quarterly).PriceCell();
            var priceCell5 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly).PriceCell();

            var priceCells = new List<PriceCellViewModel>
            {
                priceCell1, priceCell2, priceCell3, priceCell4, priceCell5
            };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.SetColumnSpreadsCommand.Execute();

            // ASSERT
            Assert.That(priceCell1.LivePrice.IsSelectedSpread, Is.False);
            Assert.That(priceCell2.LivePrice.IsSelectedSpread, Is.True);
            Assert.That(priceCell3.LivePrice.IsSelectedSpread, Is.True);
            Assert.That(priceCell4.LivePrice.IsSelectedSpread, Is.False);
            Assert.That(priceCell5.LivePrice.IsSelectedSpread, Is.False);

            Mock.Get(testObjects.SpreadPriceCalculator)
                .Verify(c => c.Calculate(testObjects.ViewModel));

            Mock.Get(testObjects.DashboardSettingsUpdater)
                .Verify(u => u.UpdateColumnSpreads(1, linkedCurve, It.Is<int[]>(a => a.Length == 2
                                                                                && a[0] == 1000 && a[1] == 1100)));
        }

        [Test]
        public void ShouldShowSummary_On_SetColumnSpreadsCommand_With_MonthsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell1 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Quarterly).PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenorValue(1000)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell3 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenorValue(1100)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell4 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Quarterly).PriceCell();
            var priceCell5 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly).PriceCell();

            var priceCells = new List<PriceCellViewModel>
            {
                priceCell1, priceCell2, priceCell3, priceCell4, priceCell5
            };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.SetColumnSpreadsCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowSummary, Is.True);
        }

        [Test]
        public void ShouldUpdateColumnSpreads_On_SetColumnSpreadsCommand_With_QuartersSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell1 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(1000)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly).PriceCell();

            var priceCell4 =new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                            .WithTenorValue(1100)
                                                            .WithIsSelected(true)
                                                            .PriceCell();

            var priceCell5 = new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly).PriceCell();

            var priceCells = new List<PriceCellViewModel>
            {
                priceCell1, priceCell2, priceCell3, priceCell4, priceCell5
            };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.SetColumnSpreadsCommand.Execute();

            // ASSERT
            Assert.That(priceCell1.LivePrice.IsSelectedSpread, Is.True);
            Assert.That(priceCell2.LivePrice.IsSelectedSpread, Is.False);
            Assert.That(priceCell3.LivePrice.IsSelectedSpread, Is.False);
            Assert.That(priceCell4.LivePrice.IsSelectedSpread, Is.True);
            Assert.That(priceCell5.LivePrice.IsSelectedSpread, Is.False);

            Mock.Get(testObjects.SpreadPriceCalculator)
                .Verify(c => c.Calculate(testObjects.ViewModel));

            Mock.Get(testObjects.DashboardSettingsUpdater)
                .Verify(u => u.UpdateColumnSpreads(1, linkedCurve, It.Is<int[]>(a => a.Length == 2
                                                                                     && a[0] == 1000 && a[1] == 1100)));
        }

        [Test]
        public void ShouldUpdateColumnSpreads_On_ClearColumnSpreadsCommand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new PriceCellTestObjectBuilder().WithIsSelectedSpread(true)
                                                            .PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .WithShowSummary(true)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.ClearColumnSpreadsCommand.Execute();

            // ASSERT
            Assert.That(priceCell.LivePrice.IsSelectedSpread, Is.False);

            Mock.Get(testObjects.SpreadPriceCalculator)
                .Verify(c => c.Calculate(testObjects.ViewModel));

            Mock.Get(testObjects.DashboardSettingsUpdater)
                .Verify(u => u.UpdateColumnSpreads(1, linkedCurve, It.Is<int[]>(a => a.Length == 0)));
        }

        [Test]
        public void ShouldHideSummary_On_ClearColumnSpreadsCommand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new PriceCellTestObjectBuilder().WithIsSelectedSpread(true)
                                                            .PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell };

            var testObjects = new LivePriceColumnInfoControllerTestObjectBuilder().WithPageNumber(1)
                                                                                  .WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.ClearColumnSpreadsCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowSummary, Is.False);
        }
    }
}
