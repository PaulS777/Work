﻿using System;
using Dsp.Gui.PriceGrid.Controllers.Column;
using Dsp.Gui.PriceGrid.Services.Column.Live;
using Dsp.Gui.PriceGrid.Services.Column.Live.Premiums;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Column
{
    internal interface ILivePriceHeaderBandInfoControllerTestObjects
    {
        ILivePriceCurrentUserIsPublisherService CurrentUserIsPublisherService { get; }
        ILivePricePublisherDetailsService PublisherDetailsService { get; }
        ILivePriceCanShowMarginsService CanShowMarginsService { get; }
        IAutoDisplayMarginErrorsService AutoDisplayMarginErrorsService { get; }
        ILivePriceShowPremiumsEnabledService LivePriceShowPremiumsEnabledService { get; }
        ILivePriceCurveValidityTimestampService CurveValidityTimestampService { get; }
        LivePriceHeaderBandInfo ViewModel { get; }
        LivePriceHeaderBandInfoController Controller { get; }
    }

    [TestFixture]
    public class LivePriceHeaderBandInfoControllerTests
    {
        private class LivePriceHeaderBandInfoControllerTestObjectBuilder
        {
            private bool _subscribeUpdates;
            private bool _canUndoPremiums;

            public LivePriceHeaderBandInfoControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public LivePriceHeaderBandInfoControllerTestObjectBuilder WithCanUndoPremiums(bool value)
            {
                _canUndoPremiums= value;
                return this;
            }

            public ILivePriceHeaderBandInfoControllerTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceHeaderBandInfoControllerTestObjects>();

                var currentUserIsPublisherService = new Mock<ILivePriceCurrentUserIsPublisherService>();

                testObjects.SetupGet(o => o.CurrentUserIsPublisherService)
                    .Returns(currentUserIsPublisherService.Object);
            
                var publisherDetailsService = new Mock<ILivePricePublisherDetailsService>();

                testObjects.SetupGet(o => o.PublisherDetailsService)
                           .Returns(publisherDetailsService.Object);

                var canShowMarginsService = new Mock<ILivePriceCanShowMarginsService>();

                testObjects.SetupGet(o => o.CanShowMarginsService)
                           .Returns(canShowMarginsService.Object);

                var autoDisplayMarginErrorsService = new Mock<IAutoDisplayMarginErrorsService>();

                testObjects.SetupGet(o => o.AutoDisplayMarginErrorsService)
                           .Returns(autoDisplayMarginErrorsService.Object);

                var livePriceShowPremiumsEnabledService = new Mock<ILivePriceShowPremiumsEnabledService>();

                testObjects.SetupGet(o => o.LivePriceShowPremiumsEnabledService)
                           .Returns(livePriceShowPremiumsEnabledService.Object);

                var curveValidityTimestampService = new Mock<ILivePriceCurveValidityTimestampService>();

                testObjects.SetupGet(o => o.CurveValidityTimestampService)
                           .Returns(curveValidityTimestampService.Object);

                var livePriceBandInfo = new LivePriceBandInfo(Mock.Of<IDisposable>());

                var livePriceBandInfoController = new Mock<ILivePriceBandInfoController>();

                livePriceBandInfoController.SetupGet(c => c.ViewModel)
                                           .Returns(livePriceBandInfo);

                var tenorPriceBandInfo = new PremiumsBandInfo(Mock.Of<IDisposable>())
                {
                    CanUndoPremiums = _canUndoPremiums
                };

                var tenorPriceBandInfoController = new Mock<IPremiumsBandInfoController>();

                tenorPriceBandInfoController.SetupGet(c => c.ViewModel)
                                            .Returns(tenorPriceBandInfo);

				var changeOnCloseBandInfo = new ChangeOnCloseBandInfo();

				var changeOnCloseBandInfoController = new Mock<IChangeOnCloseBandInfoController>();

				changeOnCloseBandInfoController.SetupGet(c => c.ViewModel)
											   .Returns(changeOnCloseBandInfo);

                var controller = new LivePriceHeaderBandInfoController(livePriceBandInfoController.Object,
                                                                       changeOnCloseBandInfoController.Object,
                                                                       tenorPriceBandInfoController.Object, 
                                                                       currentUserIsPublisherService.Object,
                                                                       publisherDetailsService.Object, 
                                                                       canShowMarginsService.Object,
                                                                       autoDisplayMarginErrorsService.Object,
                                                                       livePriceShowPremiumsEnabledService.Object,
                                                                       curveValidityTimestampService.Object);

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldConstructViewModel()
        {
            // ACT
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.IsNotNull(testObjects.ViewModel);
            Assert.That(testObjects.ViewModel.BandHeaderType, Is.EqualTo(BandHeaderType.LivePriceHeader));
            Assert.IsNotNull(testObjects.ViewModel.LivePriceBandInfo);
            Assert.IsNotNull(testObjects.ViewModel.ChangeOnCloseBandInfo);
            Assert.IsNotNull(testObjects.ViewModel.PremiumsBandInfo);
        }

        [Test]
        public void ShouldAttachServices()
        {
            // ACT
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.CurrentUserIsPublisherService)
                .Verify(p => p.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.PublisherDetailsService)
                .Verify(p => p.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.CanShowMarginsService)
                .Verify(m => m.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.AutoDisplayMarginErrorsService)
                .Verify(m => m.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.LivePriceShowPremiumsEnabledService)
                .Verify(m => m.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.CurveValidityTimestampService)
                .Verify(m => m.AttachBandInfo(testObjects.ViewModel));
        }

        [Test]
        public void ShouldUpdateBandInfos_When_CurrentUserIsPublisher()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CurrentUserIsPublisher = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.LivePriceBandInfo.CurrentUserIsPublisher, Is.True);
            Assert.That(testObjects.ViewModel.PremiumsBandInfo.CurrentUserIsPublisher, Is.True);
        }

		#region ChangeOnCloseBand

		[Test]
		public void ShouldAddChangeOnCloseBand_When_ShowChangeOnCloseTrue_With_Premiums_NotAdded()
		{
			var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

			testObjects.ViewModel.BandInfos = [testObjects.ViewModel.LivePriceBandInfo];

			// ACT
			testObjects.ViewModel.LivePriceBandInfo.ShowChangeOnClose = true;

			// ASSERT
			Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(2));
			Assert.AreSame(testObjects.ViewModel.ChangeOnCloseBandInfo, testObjects.ViewModel.BandInfos[1]);

			Assert.That(testObjects.ViewModel.ChangeOnCloseBandInfo.ShowChangeOnClose, Is.True);
		}

		[Test]
		public void ShouldInsertChangeOnCloseBand_When_ShowChangeOnCloseTrue_With_Premiums_Added()
		{
			var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

			testObjects.ViewModel.BandInfos = [testObjects.ViewModel.LivePriceBandInfo];

			testObjects.ViewModel.ShowPremiums = true;

			// ACT
			testObjects.ViewModel.LivePriceBandInfo.ShowChangeOnClose = true;

			// ASSERT
			Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(3));
			Assert.AreSame(testObjects.ViewModel.ChangeOnCloseBandInfo, testObjects.ViewModel.BandInfos[1]);

			Assert.That(testObjects.ViewModel.ChangeOnCloseBandInfo.ShowChangeOnClose, Is.True);
		}

		#endregion

		#region PremiumsBand

		[Test]
        public void ShouldAddPremiumsBand_When_ShowPremiumsTrue_With_ChangeOnClose_NotAdded()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            testObjects.ViewModel.BandInfos = [testObjects.ViewModel.LivePriceBandInfo];

            // ACT
            testObjects.ViewModel.ShowPremiums = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(2));
            Assert.AreSame(testObjects.ViewModel.PremiumsBandInfo, testObjects.ViewModel.BandInfos[1]);

            Assert.That(testObjects.ViewModel.PremiumsBandInfo.ShowPremiums, Is.True);
        }

        [Test]
        public void ShouldHidePremiumsBand_When_ShowPremiumsFalse_With_ChangeOnClose_NotAdded()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            testObjects.ViewModel.BandInfos = [testObjects.ViewModel.LivePriceBandInfo];

            testObjects.ViewModel.ShowPremiums = true;

            // ACT
            testObjects.ViewModel.ShowPremiums = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.PremiumsBandInfo.ShowPremiums, Is.False);
        }

        [Test]
        public void ShouldNotAddPremiumsBand_When_ShowPremiums_WithExistingPremiumsBand_With_ChangeOnClose_NotAdded()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            testObjects.ViewModel.BandInfos =
			[
				testObjects.ViewModel.LivePriceBandInfo,
				testObjects.ViewModel.PremiumsBandInfo
			];

            // ACT
            testObjects.ViewModel.ShowPremiums = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(2));
        }

		[Test]
		public void ShouldAddPremiumsBand_When_ShowPremiumsTrue_With_ChangeOnClose_Added()
		{
			var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

			testObjects.ViewModel.BandInfos = [testObjects.ViewModel.LivePriceBandInfo];

            // ARRANGE
			testObjects.ViewModel.LivePriceBandInfo.ShowChangeOnClose = true;

			// ACT
			testObjects.ViewModel.ShowPremiums = true;

			// ASSERT
			Assert.That(testObjects.ViewModel.BandInfos.Count, Is.EqualTo(3));
			Assert.AreSame(testObjects.ViewModel.PremiumsBandInfo, testObjects.ViewModel.BandInfos[2]);

			Assert.That(testObjects.ViewModel.PremiumsBandInfo.ShowPremiums, Is.True);
		}

		#endregion

		#region SubscribeUpdates

		[Test]
        public void ShouldUpdateBandInfos_When_SubscribeUpdates()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.LivePriceBandInfo.SubscribeUpdates, Is.True);
            Assert.That(testObjects.ViewModel.PremiumsBandInfo.SubscribeUpdates, Is.True);
        }

        [Test]
        public void ShouldInvokeServiceSubscribeUpdates_When_SubscribeUpdates()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.CurrentUserIsPublisherService)
           .Verify(p => p.SubscribeUpdates());

            Mock.Get(testObjects.PublisherDetailsService)
                .Verify(p => p.SubscribeUpdates());

            Mock.Get(testObjects.CanShowMarginsService)
                .Verify(p => p.SubscribeUpdates());

            Mock.Get(testObjects.AutoDisplayMarginErrorsService)
                .Verify(m => m.SubscribeUpdates());

            Mock.Get(testObjects.LivePriceShowPremiumsEnabledService)
                .Verify(m => m.SubscribeUpdates());

            Mock.Get(testObjects.CurveValidityTimestampService)
                .Verify(m => m.SubscribeUpdates());
        }

        [Test]
        public void ShouldUnsubscribeUpdatesOnBands_When_SubscribeUpdatesFalse()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.LivePriceBandInfo.SubscribeUpdates, Is.False);
            Assert.That(testObjects.ViewModel.PremiumsBandInfo.SubscribeUpdates, Is.False);
        }

        [Test]
        public void ShouldInvokeServiceUnsubscribeUpdates_When_SubscribeUpdatesFalse()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                                      .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.CurrentUserIsPublisherService)
                .Verify(p => p.UnsubscribeUpdates());

            Mock.Get(testObjects.PublisherDetailsService)
                .Verify(p => p.UnsubscribeUpdates());

            Mock.Get(testObjects.CanShowMarginsService)
                .Verify(p => p.UnsubscribeUpdates());

            Mock.Get(testObjects.AutoDisplayMarginErrorsService)
                .Verify(m => m.UnsubscribeUpdates());

            Mock.Get(testObjects.LivePriceShowPremiumsEnabledService)
                .Verify(m => m.UnsubscribeUpdates());

            Mock.Get(testObjects.CurveValidityTimestampService)
                .Verify(m => m.UnsubscribeUpdates());
        }

		#endregion

		#region Dispose

		[Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.CurrentUserIsPublisherService)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.PublisherDetailsService)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.CanShowMarginsService)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.AutoDisplayMarginErrorsService)
                .Verify(T => T.Dispose());

            Mock.Get(testObjects.LivePriceShowPremiumsEnabledService)
                .Verify(T => T.Dispose());

            Mock.Get(testObjects.CurveValidityTimestampService)
                .Verify(m => m.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new LivePriceHeaderBandInfoControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            Mock.Get(testObjects.CurrentUserIsPublisherService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.CurrentUserIsPublisherService)
                .Verify(t => t.Dispose(), Times.Never);
        }

		#endregion
	}
}
