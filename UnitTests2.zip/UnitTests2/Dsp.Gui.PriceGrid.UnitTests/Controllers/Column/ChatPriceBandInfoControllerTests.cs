﻿using Dsp.Gui.Markets.Common.Common;
using Dsp.Gui.PriceGrid.Controllers.Column;
using Dsp.Gui.PriceGrid.Services.Column.Manual.ChatPrice;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Column
{
    internal interface IChatPriceBandInfoControllerTestObjects
    {
        IChatTenorSelectionUpdateService ChatTenorSelectionUpdateService { get; }
        ChatPriceBandInfo ViewModel { get; }
        ChatPriceBandInfoController Controller { get; }
    }

    [TestFixture]
    public class ChatPriceBandInfoControllerTests
    {
        private class ChatPriceBandInfoControllerTestObjectsBuilder
        {
            private bool _subscribeUpdates;

            public ChatPriceBandInfoControllerTestObjectsBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public IChatPriceBandInfoControllerTestObjects Build()
            {
                var testObjects = new Mock<IChatPriceBandInfoControllerTestObjects>();

                var chatTenorSelectionUpdateService = new Mock<IChatTenorSelectionUpdateService>();

                testObjects.SetupGet(o => o.ChatTenorSelectionUpdateService)
                           .Returns(chatTenorSelectionUpdateService.Object);

                var controller = new ChatPriceBandInfoController(chatTenorSelectionUpdateService.Object);

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldConstructChatPriceColumn()
        {
            // ACT
            var testObjects = new ChatPriceBandInfoControllerTestObjectsBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatPriceColumnInfo.ColumnType, Is.EqualTo(ColumnType.ChatPrice));
        }

        [Test]
        public void ShouldAttachServices()
        {
            // ACT
            var testObjects = new ChatPriceBandInfoControllerTestObjectsBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.ChatTenorSelectionUpdateService)
                .Verify(ct => ct.AttachBandInfo(testObjects.ViewModel));
        }

        [Test]
        public void ShouldInvokeServiceSubscribeUpdates_When_SubscribeUpdates()
        {
            var testObjects = new ChatPriceBandInfoControllerTestObjectsBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.ChatTenorSelectionUpdateService)
                .Verify(ct => ct.SubscribeUpdates());
        }

        [Test]
        public void ShouldInvokeServiceUnsubscribeUpdates_When_SubscribeUpdatesFalse()
        {
            var testObjects = new ChatPriceBandInfoControllerTestObjectsBuilder().WithSubscribeUpdates(true)
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.ChatTenorSelectionUpdateService)
                .Verify(ct => ct.UnsubscribeUpdates());
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new ChatPriceBandInfoControllerTestObjectsBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ChatTenorSelectionUpdateService)
                .Verify(ct => ct.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new ChatPriceBandInfoControllerTestObjectsBuilder().Build();

            testObjects.Controller.Dispose();
            Mock.Get(testObjects.ChatTenorSelectionUpdateService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ChatTenorSelectionUpdateService)
                .Verify(ct => ct.Dispose(), Times.Never);
        }
    }
}
