﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Subjects;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Markets.Common.Common;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.Controllers.Column;
using Dsp.Gui.PriceGrid.Services.Column.Manual;
using Dsp.Gui.PriceGrid.Services.Column.Manual.ChatPrice;
using Dsp.Gui.PriceGrid.Services.ManualOverrides;
using Dsp.Gui.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Column
{
    internal interface IManualPriceBandInfoControllerTestObjects
    {
        IManualOverridesChangedService ManualOverridesChangedService { get; }
        IManualPriceBandInfoUpdater ManualPriceBandInfoUpdater { get; }
        ICurveEditRegistrationService CurveEditRegistration { get; }
        ISubject<IList<ManualOverrideViewModel>> ManualOverrides { get; }
        IManualOverridesResetService ManualOverridesResetService { get; }
        IManualOverridesUpdateCommandService ManualOverridesUpdateCommandService { get; }
        IAutoSaveOverridesService AutoSaveOverridesService { get; }
        IPasteManualOverridesService PasteManualOverridesService { get; }
        ISubject<Unit> ManualOverridesUpdateResponse { get; }
        IManualPriceAnchorPointsService AnchorPointsService { get; }
        IManualPriceUseChatPriceService UseChatPriceService { get; }
        IPopupNotificationService PopupNotificationService { get; set; }
        IErrorMessageDialogService ErrorMessageDialogService { get; set; }
        ILogger Logger { get; }
        ManualPriceBandInfo ViewModel { get; }
        ManualPriceBandInfoController Controller { get; }
    }

    [TestFixture]
    public class ManualPriceBandInfoControllerTests
    {
        private class ManualPriceBandInfoControllerTestObjectBuilder
        {
            private bool _subscribeUpdates;
            private List<PriceCellViewModel> _priceCells;
            private LinkedCurve _linkedCurve;
            private Exception _resetOverridesException;
            private bool _isPasteFromClipboard;

            public ManualPriceBandInfoControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public ManualPriceBandInfoControllerTestObjectBuilder WithPriceCells(List<PriceCellViewModel> values)
            {
                _priceCells = values;
                return this;
            }

            public ManualPriceBandInfoControllerTestObjectBuilder WithLinkedCurve(LinkedCurve value)
            {
                _linkedCurve = value;
                return this;
            }

            public ManualPriceBandInfoControllerTestObjectBuilder WithResetOverridesException(Exception value)
            {
                _resetOverridesException = value;
                return this;
            }

            public ManualPriceBandInfoControllerTestObjectBuilder WithIsPasteFromClipboard(bool value)
            {
                _isPasteFromClipboard = value;
                return this;
            }

            public IManualPriceBandInfoControllerTestObjects Build()
            {
                var testObjects = new Mock<IManualPriceBandInfoControllerTestObjects>();

                var manualOverrides = new BehaviorSubject<List<ManualOverrideViewModel>>(null);

                var manualOverridesChangedService = new Mock<IManualOverridesChangedService>();

                manualOverridesChangedService.SetupGet(m => m.ManualOverrides)
                                             .Returns(manualOverrides);

                testObjects.SetupGet(o => o.ManualOverridesChangedService)
                           .Returns(manualOverridesChangedService.Object);

                var manualPriceBandInfoUpdater = new Mock<IManualPriceBandInfoUpdater>();

                testObjects.SetupGet(o => o.ManualPriceBandInfoUpdater)
                           .Returns(manualPriceBandInfoUpdater.Object);

                var curveEditRegistration = new Mock<ICurveEditRegistrationService>();

                testObjects.SetupGet(o => o.CurveEditRegistration)
                           .Returns(curveEditRegistration.Object);

                var manualCurveUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.ManualOverridesUpdateResponse)
                           .Returns(manualCurveUpdate);

                var manualOverridesUpdateCommandService = new Mock<IManualOverridesUpdateCommandService>();

                manualOverridesUpdateCommandService.Setup(u => u.UpdateManualOverrides(It.IsAny<LinkedCurve>(),
                                                                                       It.IsAny<List<PriceCellViewModel>>()))
                                                   .Returns(manualCurveUpdate);

                testObjects.SetupGet(o => o.ManualOverridesUpdateCommandService)
                           .Returns(manualOverridesUpdateCommandService.Object);

                var manualOverridesResetService = new Mock<IManualOverridesResetService>();

                if (_resetOverridesException != null)
                {
                    manualOverridesResetService.Setup(r => r.ResetOverrides(It.IsAny<List<PriceCellViewModel>>()))
                                               .Throws(_resetOverridesException);
                }

                testObjects.SetupGet(o => o.ManualOverridesResetService)
                           .Returns(manualOverridesResetService.Object);

                var anchorPointsService = new Mock<IManualPriceAnchorPointsService>();

                testObjects.SetupGet(o => o.AnchorPointsService)
                           .Returns(anchorPointsService.Object);

                var useChatPriceService = new Mock<IManualPriceUseChatPriceService>();

                testObjects.SetupGet(o => o.UseChatPriceService)
                           .Returns(useChatPriceService.Object);

                var autoSaveOverridesService = new Mock<IAutoSaveOverridesService>();

                testObjects.SetupGet(o => o.AutoSaveOverridesService)
                           .Returns(autoSaveOverridesService.Object);

                var pasteManualOverridesService = new Mock<IPasteManualOverridesService>();

                testObjects.SetupGet(o => o.PasteManualOverridesService)
                           .Returns(pasteManualOverridesService.Object);

                var loggerFactory = Mocks.GetLoggerFactory();

                var logger = loggerFactory.Object.Create(typeof(ManualPriceBandInfoController));

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var controller = new ManualPriceBandInfoController(manualOverridesChangedService.Object,
                                                                   manualPriceBandInfoUpdater.Object,
                                                                   anchorPointsService.Object,
                                                                   useChatPriceService.Object,
                                                                   autoSaveOverridesService.Object,
                                                                   curveEditRegistration.Object,
                                                                   TestMocks.GetSchedulerProvider().Object,
                                                                   loggerFactory.Object)
                {
                    ManualOverridesUpdateCommandService = manualOverridesUpdateCommandService.Object,
                    ManualOverridesResetService = manualOverridesResetService.Object,
                    PasteManualOverridesService = pasteManualOverridesService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    PopupNotificationService = popupNotificationService.Object
                };

                var details = new BandInfoDetails(1, _linkedCurve, new PriceGridViewModel());

                details.SetPriceCells(_priceCells);

                controller.ViewModel.SetDetails(details);

                controller.ViewModel.IsPasteFromClipboard = _isPasteFromClipboard;
                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldConstructManualPriceColumn()
        {
            // ACT
            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualPriceColumnInfo.ColumnType, Is.EqualTo(ColumnType.ManualPrice));
        }

        [Test]
        public void ShouldAttachServices()
        {
            // ACT
            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(t => t.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.ManualPriceBandInfoUpdater)
                .Verify(t => t.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.AnchorPointsService)
                .Verify(t => t.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.UseChatPriceService)
                .Verify(t => t.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.AutoSaveOverridesService)
                .Verify(t => t.AttachBandInfo(testObjects.ViewModel));
        }

        [Test]
        public void ShouldInvokeServiceSubscribeUpdates_When_SubscribeUpdates()
        {
            var linkedCurve = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var priceCell1 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly).PriceCell();
            var priceCell2 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Quarterly).PriceCell();
            var priceCell3 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Yearly).PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell1, priceCell2, priceCell3 };

            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();

            var expectedPriceCells = new[]
                                     {
                                         priceCell1.ManualOverride, priceCell2.ManualOverride, priceCell3.ManualOverride
                                     };

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(t => t.SubscribeUpdates());

            Mock.Get(testObjects.AnchorPointsService)
                .Verify(t => t.SubscribeUpdates());

            Mock.Get(testObjects.UseChatPriceService)
                .Verify(t => t.SubscribeUpdates());

            Mock.Get(testObjects.AutoSaveOverridesService)
                .Verify(t => t.SubscribeUpdates());

            Mock.Get(testObjects.ManualPriceBandInfoUpdater)
                .Verify(t => t.SubscribeUpdates(testObjects.ManualOverridesChangedService.ManualOverrides,
                                                It.Is<IList<ManualOverrideViewModel>>(cells => cells.SequenceEqual(expectedPriceCells))));

            Mock.Get(testObjects.CurveEditRegistration)
                .Verify(r => r.RegisterCurve(testObjects.ViewModel, 201));
        }

        [Test]
        public void ShouldInvokeServiceUnsubscribeUpdates_When_SubscribeUpdatesFalse()
        {
            var linkedCurve = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .WithSubscribeUpdates(true)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(t => t.UnsubscribeUpdates());

            Mock.Get(testObjects.AnchorPointsService)
                .Verify(t => t.UnsubscribeUpdates());

            Mock.Get(testObjects.UseChatPriceService)
                .Verify(t => t.UnsubscribeUpdates());

            Mock.Get(testObjects.AutoSaveOverridesService)
                .Verify(t => t.UnsubscribeUpdates());

            Mock.Get(testObjects.ManualPriceBandInfoUpdater)
                .Verify(t => t.UnsubscribeUpdates());
        }

        [Test]
        public void ShouldSuspendBandInfoUpdater_And_UndoManualOverrideChanges_OnUndoCurveOverridesCommand()
        {
            var linkedCurve = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCell1 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly).PriceCell();
            var priceCell2 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Quarterly).PriceCell();
            var priceCell3 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Yearly).PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell1, priceCell2, priceCell3 };

            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();

            var expectedPriceCells = new[]
                                     {
                                         priceCell1.ManualOverride , priceCell2.ManualOverride , priceCell3.ManualOverride
                                     };

            // ACT
            testObjects.ViewModel.UndoOverridesCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ManualPriceBandInfoUpdater)
                .Verify(t => t.UnsubscribeUpdates());

            Mock.Get(testObjects.ManualOverridesResetService)
                .Verify(r => r.ResetOverrides(priceCells));

            Mock.Get(testObjects.ManualPriceBandInfoUpdater)
                .Verify(t => t.SubscribeUpdates(testObjects.ManualOverridesChangedService.ManualOverrides,
                                                It.Is<IList<ManualOverrideViewModel>>(cells => cells.SequenceEqual(expectedPriceCells))));
        }

        [Test]
        public void ShouldResetIsPasteFromClipboard_OnUndoCurveOverridesCommand()
        {
            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithIsPasteFromClipboard(true)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.UndoOverridesCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsPasteFromClipboard, Is.False);
        }

        [Test]
        public void ShouldLogError_When_UndoCurveOverridesCommandException()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var priceCells = new List<PriceCellViewModel>();
            var exception = new InvalidOperationException();

            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .WithResetOverridesException(exception)
                                                                                  .Build();
            // ACT
            testObjects.ViewModel.UndoOverridesCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(l => l.Error(It.IsAny<string>()));
        }

        [Test]
        public void ShouldDisablePriceCells_And_UpdateManualOverrides_OnSaveCurveOverridesCommand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCells = new List<PriceCellViewModel>
            {
                new ManualPriceCellBuilder().PriceCell()
            };

            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
            // ACT
            testObjects.Controller.ViewModel.UpdateOverridesCommand.Execute(null);

            // ASSERT
            Assert.That(priceCells.TrueForAll(cell => cell.ManualOverride.IsBusy));

            Mock.Get(testObjects.ManualOverridesUpdateCommandService)
                .Verify(p => p.UpdateManualOverrides(linkedCurve, priceCells));
        }

        [Test]
        public void ShouldEnablePriceCells_And_ShowPopup_OnSaveCurveOverridesCompleted()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCells = new List<PriceCellViewModel>
            {
                new ManualPriceCellBuilder().PriceCell()
            };

            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();
  
            testObjects.Controller.ViewModel.UpdateOverridesCommand.Execute(null);

            // ACT
            testObjects.ManualOverridesUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.That(priceCells.All(cell => !cell.ManualOverride.IsBusy));

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification("Manual Overrides Updated", null));
        }

        [Test]
        public void ShouldResetIsPasteFromClipboard_OnSaveCurveOverridesCompleted()
        {
            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithPriceCells(new List<PriceCellViewModel>())
                                                                                  .WithIsPasteFromClipboard(true)
                                                                                  .Build();

            testObjects.Controller.ViewModel.UpdateOverridesCommand.Execute(null);

            // ACT
            testObjects.ManualOverridesUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsPasteFromClipboard, Is.False);
        }

        [Test]
        public void ShouldClearProgress_And_ShowErrorDialog_OnSaveCurveOverridesError()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCells = new List<PriceCellViewModel>
            {
                new ManualPriceCellBuilder().PriceCell()
            };

            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                                  .WithPriceCells(priceCells)
                                                                                  .Build();

            testObjects.Controller.ViewModel.UpdateOverridesCommand.Execute(null);

            // ACT
            testObjects.ManualOverridesUpdateResponse.OnError(new InvalidOperationException("error"));

            // ASSERT
            Assert.That(priceCells.All(cell => !cell.ManualOverride.IsBusy));

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Header == "Manual Overrides Update Failed"
                                                                                && args.Messages[0] == "error"
                                                                                && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldPastePriceCells_And_Set_IsPasteFromClipboardTrue_On_PasteFromClipboardCommand()
        {
            var priceCell = new ManualPriceCellBuilder().PriceCell();

            var priceCells = new List<PriceCellViewModel>
                             {
                                 priceCell,
                                 new ManualPriceCellBuilder().PriceCell()
                             };

            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                                  .Build();

            // ACT
            testObjects.ViewModel.PasteFromClipboardCommand.Execute(priceCell);

            // ASSERT
            Mock.Get(testObjects.PasteManualOverridesService)
                .Verify(p => p.PastePriceCells(priceCell, priceCells));

            Assert.That(testObjects.ViewModel.IsPasteFromClipboard, Is.True);
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.ManualPriceBandInfoUpdater)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.AnchorPointsService)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.UseChatPriceService)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.AutoSaveOverridesService)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.CurveEditRegistration)
                .Verify(r => r.UnRegisterCurve(It.IsAny<int>()));
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new ManualPriceBandInfoControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            Mock.Get(testObjects.ManualOverridesChangedService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ManualOverridesChangedService)
                .Verify(t => t.Dispose(), Times.Never);
        }
    }
}
