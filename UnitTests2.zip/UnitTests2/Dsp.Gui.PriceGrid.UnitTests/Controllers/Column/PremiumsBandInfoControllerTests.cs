﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Subjects;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Markets.Common.Common;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.Controllers.Column;
using Dsp.Gui.PriceGrid.Services.Column.Live.Premiums;
using Dsp.Gui.PriceGrid.Services.Command;
using Dsp.Gui.PriceGrid.Services.Premiums;
using Dsp.Gui.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Column
{
    internal interface IPremiumsBandInfoControllerTestObjects
    {
        ILivePriceTenorPremiumsService TenorPremiumsService { get; }
        ITenorPremiumsMonitor TenorPremiumsMonitor { get; }
        ITenorPremiumsCommandService TenorPremiumsCommandService { get; }
        ITenorPremiumCellGroupingService TenorPremiumCellGroupingService { get; }
        ITenorPremiumRevertMarginsService RevertMarginsService { get; }
        ITenorPremiumsUpdateCommandService TenorPremiumsUpdateCommandService { get; }
        ISubject<Unit> TenorPremiumsUpdateResponse { get; }
        IPopupNotificationService PopupNotificationService { get; set; }
        IErrorMessageDialogService ErrorMessageDialogService { get; set; }
        IScrollToMarginErrorsService ScrollToMarginErrorsService { get; set; }
        PremiumsBandInfo ViewModel { get; }
        PremiumsBandInfoController Controller { get; }
    }

    [TestFixture]
    public class PremiumsBandInfoControllerTests
    {
        private class PremiumsBandInfoControllerTestObjectBuilder
        {
            private bool _subscribeUpdates;
            private List<PriceCellViewModel> _priceCells;
            private LinkedCurve _linkedCurve;
 
            public PremiumsBandInfoControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public PremiumsBandInfoControllerTestObjectBuilder WithPriceCells(List<PriceCellViewModel> values)
            {
                _priceCells = values;
                return this;
            }

            public PremiumsBandInfoControllerTestObjectBuilder WithLinkedCurve(LinkedCurve value)
            {
                _linkedCurve = value;
                return this;
            }

            public IPremiumsBandInfoControllerTestObjects Build()
            {
                var testObjects = new Mock<IPremiumsBandInfoControllerTestObjects>();

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var tenorPremiumsCommandService = new Mock<ITenorPremiumsCommandService>();

                testObjects.SetupGet(o => o.TenorPremiumsCommandService)
                           .Returns(tenorPremiumsCommandService.Object);

                var tenorPremiumsMonitor = new Mock<ITenorPremiumsMonitor>();

                testObjects.SetupGet(o => o.TenorPremiumsMonitor)
                           .Returns(tenorPremiumsMonitor.Object);

                var premiumsService = new Mock<ILivePriceTenorPremiumsService>();

                testObjects.SetupGet(o => o.TenorPremiumsService)
                           .Returns(premiumsService.Object);

                var updateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.TenorPremiumsUpdateResponse)
                           .Returns(updateResponse);

                var tenorPremiumsUpdateCommandService = new Mock<ITenorPremiumsUpdateCommandService>();

                tenorPremiumsUpdateCommandService.Setup(tp => tp.UpdatePremiums(It.IsAny<LinkedCurve>(),
                                                                                It.IsAny<IReadOnlyList<PriceCellViewModel>>()))
                                                 .Returns(updateResponse);
                
                testObjects.SetupGet(o => o.TenorPremiumsUpdateCommandService)
                           .Returns(tenorPremiumsUpdateCommandService.Object);

                var cellGroupingService = new Mock<ITenorPremiumCellGroupingService>();

                testObjects.SetupGet(o => o.TenorPremiumCellGroupingService)
                           .Returns(cellGroupingService.Object);

                var scrollToMarginErrorsService = new Mock<IScrollToMarginErrorsService>();

                testObjects.SetupGet(o => o.ScrollToMarginErrorsService)
                           .Returns(scrollToMarginErrorsService.Object);

                var revertMarginsService = new Mock<ITenorPremiumRevertMarginsService>();

                testObjects.SetupGet(o => o.RevertMarginsService)
                           .Returns(revertMarginsService.Object);

                var controller = new PremiumsBandInfoController(premiumsService.Object,
                                                                tenorPremiumsMonitor.Object)
                {
                    TenorPremiumsCommandService = tenorPremiumsCommandService.Object,
                    TenorPremiumsUpdateCommandService = tenorPremiumsUpdateCommandService.Object,
                    TenorPremiumCellGroupingService = cellGroupingService.Object,
                    RevertMarginsService = revertMarginsService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    PopupNotificationService = popupNotificationService.Object,
                    ScrollToMarginErrorsService = scrollToMarginErrorsService.Object
                };

                var details = new BandInfoDetails(1, _linkedCurve, new PriceGridViewModel());

                details.SetPriceCells(_priceCells);

                controller.ViewModel.SetDetails(details);

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldConstructMarginColumns()
        {
            // ACT
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.ColumnType, Is.EqualTo(ColumnType.Margin));
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.Header, Is.EqualTo("Bid"));
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.ColumnType, Is.EqualTo(ColumnType.Margin));
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.Header, Is.EqualTo("Ask"));
        }

        [Test]
        public void ShouldAttachServices()
        {
            // ACT
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsService)
                .Verify(tp => tp.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.TenorPremiumsMonitor)
                .Verify(tp => tp.AttachBandInfo(testObjects.ViewModel));
        }

        [Test]
        public void ShouldInvokeServiceSubscribeUpdates_When_SubscribeUpdates()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsService)
                .Verify(tp => tp.SubscribeUpdates());

            Mock.Get(testObjects.TenorPremiumsMonitor)
                .Verify(tp => tp.SubscribeUpdates());
        }

        [Test]
        public void ShouldInvokeServiceUnsubscribeUpdates_When_SubscribeUpdatesFalse()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsService)
                .Verify(tp => tp.UnsubscribeUpdates());

            Mock.Get(testObjects.TenorPremiumsMonitor)
                .Verify(tp => tp.UnsubscribeUpdates());
        }

        [Test]
        public void ShouldScrollToMarginErrors_On_Command()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.ScrollToMarginErrorsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ScrollToMarginErrorsService)
                .Verify(s => s.ScrollToMarginErrors(testObjects.ViewModel));
        }

        [Test]
        public void ShouldDisableMarginCells_And_InvokeUpdatePremiums_When_UpdatePremiumsCommand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new PriceCellTestObjectBuilder().PriceCell();

            var priceCells = new List<PriceCellViewModel>{ priceCell };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                               .WithPriceCells(priceCells)
                                                                               .Build();
            // ACT
            testObjects.ViewModel.UpdatePremiumsCommand.Execute();

            // ASSERT
            Assert.That(priceCell.TenorPremium.BidMargin.IsBusy, Is.True);
            Assert.That(priceCell.TenorPremium.AskMargin.IsBusy, Is.True);

            Mock.Get(testObjects.TenorPremiumsUpdateCommandService)
                .Verify(p => p.UpdatePremiums(linkedCurve, priceCells));
        }

        [Test]
        public void ShouldEnableMarginCells_And_ShowPopup_On_UpdatePremiumsCompleted()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new PriceCellTestObjectBuilder().PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                               .WithPriceCells(priceCells)
                                                                               .Build();
  
            testObjects.ViewModel.UpdatePremiumsCommand.Execute();

            // ACT
            testObjects.TenorPremiumsUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.That(priceCell.TenorPremium.BidMargin.IsBusy, Is.False);
            Assert.That(priceCell.TenorPremium.AskMargin.IsBusy, Is.False);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldEnableMarginCells_And_ShowErrorMessageDialog_On_UpdatePremiumsError()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new PriceCellTestObjectBuilder().PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                               .WithPriceCells(priceCells)
                                                                               .Build();

            testObjects.ViewModel.UpdatePremiumsCommand.Execute();

            // ACT
            var exception = new InvalidOperationException("error");

            testObjects.TenorPremiumsUpdateResponse.OnError(exception);

            // ASSERT
            Assert.That(priceCell.TenorPremium.BidMargin.IsBusy, Is.False);
            Assert.That(priceCell.TenorPremium.AskMargin.IsBusy, Is.False);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldUndoChanges_And_ClearDependencies_OnUndoPremiumsCommand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceCell = new PriceCellTestObjectBuilder().WithCanApplyMargins(true)
                                                            .PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                               .WithPriceCells(priceCells)
                                                                               .Build();

            priceCell.TenorPremium.BidMargin.Margin.Value = 1.1M;
            priceCell.TenorPremium.AskMargin.Margin.Value = 1.3M;

            // ACT
            testObjects.ViewModel.UndoPremiumsCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.RevertMarginsService)
                .Verify(r => r.RevertToServerValues(priceCell.TenorPremium));

            Mock.Get(testObjects.TenorPremiumCellGroupingService)
                .Verify(cs => cs.ClearDependencies(It.Is<List<TenorPremiumViewModel>>(cells => cells.Count == 1)));
        }

        #region Margin Commands - Enabled/Disabled

        [Test]
        public void ShouldEnableSetMarginParentCommands_On_CanSetMarginParentTrue()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanSetMarginParent = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.SetMarginParentCommand.CanExecute, Is.True);
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.SetMarginParentCommand.CanExecute, Is.True);
        }

        [Test]
        public void ShouldDisableSetMarginParentCommands_On_CanSetMarginParentFalse()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanSetMarginParent = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.SetMarginParentCommand.CanExecute, Is.False);
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.SetMarginParentCommand.CanExecute, Is.False);
        }

        [Test]
        public void ShouldEnableSetMarginChildrenCommands_On_CanSetMarginChildrenTrue()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanSetMarginChildren = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.SetMarginChildrenCommand.CanExecute, Is.True);
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.SetMarginChildrenCommand.CanExecute, Is.True);
        }

        [Test]
        public void ShouldDisableSetMarginChildrenCommands_On_CanSetMarginChildrenFalse()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanSetMarginChildren = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.SetMarginChildrenCommand.CanExecute, Is.False);
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.SetMarginChildrenCommand.CanExecute, Is.False);
        }

        [Test]
        public void ShouldEnableSetMarginChildrenBelowParentCommands_On_CanSetMarginChildrenBelowParentTrue()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanSetMarginChildrenBelowParent = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.SetMarginChildrenBelowParentCommand.CanExecute, Is.True);
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.SetMarginChildrenBelowParentCommand.CanExecute, Is.True);
        }

        [Test]
        public void ShouldDisableSetMarginChildrenBelowParentCommands_On_CanSetMarginChildrenBelowParentFalse()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanSetMarginChildrenBelowParent = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.SetMarginChildrenBelowParentCommand.CanExecute, Is.False);
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.SetMarginChildrenBelowParentCommand.CanExecute, Is.False);
        }

        [Test]
        public void ShouldEnableClearMarginDependenciesCommands_On_ClearMarginDependenciesTrue()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanClearMarginDependencies = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.ClearMarginDependenciesCommand.CanExecute, Is.True);
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.ClearMarginDependenciesCommand.CanExecute, Is.True);
        }

        [Test]
        public void ShouldDisableClearMarginDependenciesCommands_On_ClearMarginDependenciesFalse()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.CanClearMarginDependencies = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.BidMarginColumnInfo.ClearMarginDependenciesCommand.CanExecute, Is.False);
            Assert.That(testObjects.ViewModel.AskMarginColumnInfo.ClearMarginDependenciesCommand.CanExecute, Is.False);
        }

        #endregion

        #region Margin Commands (Bid) - Execute

        [Test]
        public void ShouldUpdateMarginParent_On_BidColumn_SetMarginParentCommand()
        {
            var priceCells = new List<PriceCellViewModel>
                             {
                                 new PriceCellTestObjectBuilder().PriceCell()
                             };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.BidMarginColumnInfo.SetMarginParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsCommandService)
                .Verify(t => t.UpdateMarginParent(priceCells));
        }

        [Test]
        public void ShouldUpdateMarginChildren_On_BidColumn_SetMarginChildrenCommand()
        {
            var priceCells = new List<PriceCellViewModel>
                             {
                                 new PriceCellTestObjectBuilder().PriceCell()
                             };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.BidMarginColumnInfo.SetMarginChildrenCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsCommandService)
                .Verify(t => t.UpdateMarginChildren(priceCells));
        }

        [Test]
        public void ShouldUpdateMarginChildrenBelowParent_On_BidColumn_SetMarginChildrenBelowParentCommand()
        {
            var priceCells = new List<PriceCellViewModel>
                             {
                                 new PriceCellTestObjectBuilder().PriceCell()
                             };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.BidMarginColumnInfo.SetMarginChildrenBelowParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsCommandService)
                .Verify(t => t.UpdateMarginChildrenBelowParent(priceCells));
        }

        [Test]
        public void ShouldClearMarginDependencies_On_BidColumn_ClearMarginDependenciesCommand()
        {
            var priceCells = new List<PriceCellViewModel>
                             {
                                 new PriceCellTestObjectBuilder().PriceCell()
                             };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.BidMarginColumnInfo.ClearMarginDependenciesCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsCommandService)
                .Verify(t => t.ClearMarginDependencies(priceCells));
        }

        #endregion

        #region Margin Commands (Ask) - Execute

        [Test]
        public void ShouldUpdateMarginParent_On_AskColumn_SetMarginParentCommand()
        {
            var priceCells = new List<PriceCellViewModel>
                             {
                                 new PriceCellTestObjectBuilder().PriceCell()
                             };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.AskMarginColumnInfo.SetMarginParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsCommandService)
                .Verify(t => t.UpdateMarginParent(priceCells));
        }

        [Test]
        public void ShouldUpdateMarginChildren_On_AskColumn_SetMarginChildrenCommand()
        {
            var priceCells = new List<PriceCellViewModel>
                             {
                                 new PriceCellTestObjectBuilder().PriceCell()
                             };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.AskMarginColumnInfo.SetMarginChildrenCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsCommandService)
                .Verify(t => t.UpdateMarginChildren(priceCells));
        }

        [Test]
        public void ShouldUpdateMarginChildrenBelowParent_On_AskColumn_SetMarginChildrenBelowParentCommand()
        {
            var priceCells = new List<PriceCellViewModel>
                             {
                                 new PriceCellTestObjectBuilder().PriceCell()
                             };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.AskMarginColumnInfo.SetMarginChildrenBelowParentCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsCommandService)
                .Verify(t => t.UpdateMarginChildrenBelowParent(priceCells));
        }

        [Test]
        public void ShouldClearMarginDependencies_On_AskColumn_ClearMarginDependenciesCommand()
        {
            var priceCells = new List<PriceCellViewModel>
                             {
                                 new PriceCellTestObjectBuilder().PriceCell()
                             };

            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().WithPriceCells(priceCells)
                                                                               .Build();

            // ACT
            testObjects.ViewModel.AskMarginColumnInfo.ClearMarginDependenciesCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsCommandService)
                .Verify(t => t.ClearMarginDependencies(priceCells));
        }

        #endregion

        #region Dispose

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsService)
                .Verify(tp => tp.Dispose());

            Mock.Get(testObjects.TenorPremiumsMonitor)
                .Verify(tp => tp.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new PremiumsBandInfoControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();
            Mock.Get(testObjects.TenorPremiumsService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumsService)
                .Verify(tp => tp.Dispose(), Times.Never);
        }

        #endregion
    }
}
