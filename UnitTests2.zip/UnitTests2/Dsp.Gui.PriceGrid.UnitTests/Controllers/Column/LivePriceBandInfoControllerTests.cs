﻿using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.PriceGrid.Controllers.Column;
using Dsp.Gui.PriceGrid.Services.Column.Live;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Column
{
    internal interface ILivePriceBandInfoControllerTestObjects
    {
        ILivePriceCurveSettingsService CurveSettingsService { get; }
        IToggleIsTradeableService ToggleIsTradeableService { get; }
        LivePriceBandInfo ViewModel { get; }
        LivePriceBandInfoController Controller { get; }
    }

    [TestFixture]
    public class LivePriceBandInfoControllerTests
    {
        private class LivePriceBandInfoControllerTestObjectBuilder
        {
            private bool _subscribeUpdates;

            public LivePriceBandInfoControllerTestObjectBuilder WithSubscribeUpdates(bool value)
            {
                _subscribeUpdates = value;
                return this;
            }

            public ILivePriceBandInfoControllerTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceBandInfoControllerTestObjects>();

                var curveSettingsService = new Mock<ILivePriceCurveSettingsService>();

                testObjects.SetupGet(o => o.CurveSettingsService)
                           .Returns(curveSettingsService.Object);

                var toggleIsTradeableService = new Mock<IToggleIsTradeableService>();

                testObjects.SetupGet(o => o.ToggleIsTradeableService)
                           .Returns(toggleIsTradeableService.Object);

                var controller = new LivePriceBandInfoController(curveSettingsService.Object,
                                                                 toggleIsTradeableService.Object);

                controller.ViewModel.SubscribeUpdates = _subscribeUpdates;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldConstructViewModel()
        {
            // ACT
            var testObjects = new LivePriceBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.IsNotNull(testObjects.ViewModel);
        }

        [Test]
        public void ShouldAttachServices()
        {
            // ACT
            var testObjects = new LivePriceBandInfoControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.CurveSettingsService)
                .Verify(t => t.AttachBandInfo(testObjects.ViewModel));

            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldInvokeServiceSubscribeUpdates_When_SubscribeUpdates()
        {
            var testObjects = new LivePriceBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = true;

            // ASSERT
            Mock.Get(testObjects.CurveSettingsService)
                .Verify(t => t.SubscribeUpdates());

            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.SubscribeUpdates());
        }

        [Test]
        public void ShouldInvokeServiceSubscribeUpdates_When_UnsubscribeUpdates()
        {
            var testObjects = 
                new LivePriceBandInfoControllerTestObjectBuilder().WithSubscribeUpdates(true)
                                                                  .Build();

            // ACT
            testObjects.ViewModel.SubscribeUpdates = false;

            // ASSERT
            Mock.Get(testObjects.CurveSettingsService)
                .Verify(t => t.UnsubscribeUpdates());

            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.UnsubscribeUpdates());
        }

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new LivePriceBandInfoControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.CurveSettingsService)
                .Verify(t => t.Dispose());

            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new LivePriceBandInfoControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            Mock.Get(testObjects.ToggleIsTradeableService).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ToggleIsTradeableService)
                .Verify(t => t.Dispose(), Times.Never);
        }
    }
}
