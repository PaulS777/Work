﻿using Dsp.Gui.PriceGrid.Controllers.Column;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.Column
{
    [TestFixture]
    public class TenorHeaderBandInfoControllerTests
    {
        [Test]
        public void ShouldConstructViewModel()
        {
            // ACT
            var controller = new TenorHeaderBandInfoController();

            // ASSERT
            Assert.IsNotNull(controller.ViewModel);
            Assert.That(controller.ViewModel.BandHeaderType, Is.EqualTo(BandHeaderType.TenorBandHeader));
        }
    }
}
