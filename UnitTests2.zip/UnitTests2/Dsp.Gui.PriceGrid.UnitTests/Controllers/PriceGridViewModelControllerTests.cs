﻿using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.ToolBar.Markets.ViewModels;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.Services.ScratchPad;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.PriceGrid.Common;
using Dsp.Gui.PriceGrid.Controllers;
using Dsp.Gui.PriceGrid.Services.Clipboard;
using Dsp.Gui.PriceGrid.Services.Common;
using Dsp.Gui.PriceGrid.Services.GridBuilder;
using Dsp.Gui.PriceGrid.Services.GridSettings;
using Dsp.Gui.PriceGrid.Services.GridSummary;
using Dsp.Gui.PriceGrid.Services.GridUpdate;
using Dsp.Gui.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using Dsp.ServiceContracts;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using System.Windows.Input;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid.Model;
using Dsp.Gui.PriceGrid.Services;
using Dsp.Gui.PriceGrid.Services.Command;
using Dsp.Gui.UnitTest.Helpers.Builders;
using DevExpress.Xpf.Grid;
using Dsp.Gui.Dashboard.ToolBar.Markets.Controllers;
using Dsp.Gui.PriceGrid.Services.DataSource;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers
{
    internal interface IPriceGridViewModelControllerTestObjects
    {
        ITenorPriceRowDataSource DataSource { get; }
        IPriceGridToolBarController PriceGridToolBarController { get; }
        IPriceGridCommandService PriceGridCommandService { get; }
        IPriceBandVisibleIndexService PriceBandVisibleIndexService { get; }
        IPriceGridSummaryService PriceGridSummaryService { get; }
        IPriceGridSettingsRestorationService RestorationService { get; }
        IGridSummarySettingsRestorationService GridSummarySettingsRestorationService { get; }
        ICanSelectSpreadsService CanSelectSpreadsService { get; }
        IPriceGridBindingsService PriceGridBindingsService { get; }
        IBandHeaderInfoDataSourceService BandHeaderInfoDataSourceService { get; }
        IBandHeaderInfoDataSource BandHeaderInfoDataSource { get; }
        IPriceGridService PriceGridService { get; }
        ILivePriceGridUpdateService LivePriceGridUpdateService { get; }
        IRemovePriceBandService RemovePriceBandService { get; }
        IExportPriceCellsService ExportPriceCellsService { get; }
        ITimestampService TimestampService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        IDashboardSettingsService DashboardSettingsService { get;}
        IScratchPadPriceCurvesService ScratchPadPriceCurvesService { get; }
        IScratchPadClipboard ScratchPadClipboard { get; }
        IPriceDirectionDisplayService PriceDirectionDisplayService { get; }
        IBandHeaderAlignmentService BandHeaderAlignmentService { get; }
        IPriceColumnWidthService PriceColumnWidthService { get; }
        ILogger Logger { get; }
        PriceGridLoadArgs PriceGridFilterLoadedArgs { get; }
        ISubject<PriceGridLoadArgs> PriceGridLoad { get; }
        PriceGridInitializedArgs PriceGridInitializedArgs { get; }
        ISubject<PriceGridInitializedArgs> PriceGridRefresh { get; }
        ISubject<Unit> GridBindings { get; }
        ISubject<Unit> PriceGridReconnected { get; }
        ISubject<DateTime> Timestamp { get; }
        TestScheduler TestScheduler { get; }
        PriceGridViewModel ViewModel { get; }
        PriceGridViewModelController Controller { get; }
    }

    [TestFixture]
    public class PriceGridViewModelControllerTests
    {
        private class PriceGridViewModelControllerTestObjectBuilder
        {
            private IEnumerable<TenorPriceRowViewModel> _dataSourceItems;
            private IEnumerable<IPriceBandHeaderInfo> _priceBandHeaderInfos;
            private IEnumerable<LivePriceHeaderBandInfo> _livePriceHeaderBandInfos;
            private IEnumerable<ManualPriceHeaderBandInfo> _manualPriceHeaderBandInfos;
            private DashboardSettings _dashboardSettings;
            private bool _showGrid;
            private bool _showAddRowButton;
            private Exception _priceGridSummaryException;
            private ObservableCollection<GridSummaryItem> _summaryItems;
            private string _marketsFilterText;
            private int? _initializePage;
            private Dictionary<LinkedCurve, List<PriceCellViewModel>> _priceCurveLookup = [];
            private List<List<TenorPriceCell>> _exportPriceCells;
            private Exception _exportPriceCellsException;
            private List<string> _exportHeaders;
            private Exception _exportHeadersException;

            public PriceGridViewModelControllerTestObjectBuilder WithDataSourceItems(IEnumerable<TenorPriceRowViewModel> values)
            {
                _dataSourceItems = values;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithPriceBandHeaderBandInfos(IEnumerable<IPriceBandHeaderInfo> values)
            {
                _priceBandHeaderInfos = values;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithLivePriceHeaderBandInfos(IEnumerable<LivePriceHeaderBandInfo> values)
            {
                _livePriceHeaderBandInfos = values;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithManualPriceHeaderBandInfos(IEnumerable<ManualPriceHeaderBandInfo> values)
            {
                _manualPriceHeaderBandInfos = values;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithDashboardSettings(DashboardSettings value)
            {
                _dashboardSettings = value;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithShowGrid(bool value)
            {
                _showGrid = value;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithShowAddRowButton(bool value)
            {
                _showAddRowButton = value;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithPriceGridSummaryException(Exception value)
            {
                _priceGridSummaryException = value;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithSummaryItems(ObservableCollection<GridSummaryItem> values)
            {
                _summaryItems = values;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithMarketsFilterText(string value)
            {
                _marketsFilterText = value;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithInitializePage(int value)
            {
                _initializePage = value;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithPriceCurveLookup(Dictionary<LinkedCurve, List<PriceCellViewModel>> value)
            {
                _priceCurveLookup = value;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithExportPriceCells(List<List<TenorPriceCell>> values)
            {
                _exportPriceCells = values;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithExportPriceCellsException(Exception value)
            {
                _exportPriceCellsException = value;
                return this;
            }
            public PriceGridViewModelControllerTestObjectBuilder WithExportHeaders(List<string> values)
            {
                _exportHeaders = values;
                return this;
            }

            public PriceGridViewModelControllerTestObjectBuilder WithExportHeadersException(Exception value)
            {
                _exportHeadersException = value;
                return this;
            }

            public IPriceGridViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IPriceGridViewModelControllerTestObjects>();

                var priceGridToolBarController = new Mock<IPriceGridToolBarController>();

                var priceGridToolBar = new PriceGridToolBarViewModel(priceGridToolBarController.Object);

                priceGridToolBarController.SetupGet(c => c.ViewModel)
                                          .Returns(priceGridToolBar);

                testObjects.SetupGet(o => o.PriceGridToolBarController)
                           .Returns(priceGridToolBarController.Object);

                var priceGridCommandService = new Mock<IPriceGridCommandService>();

                testObjects.SetupGet(o => o.PriceGridCommandService)
                           .Returns(priceGridCommandService.Object);

                var removePriceBandService = new Mock<IRemovePriceBandService>();

                testObjects.SetupGet(o => o.RemovePriceBandService)
                           .Returns(removePriceBandService.Object);

                var restorationService = new Mock<IPriceGridSettingsRestorationService>();

                testObjects.SetupGet(o => o.RestorationService)
                           .Returns(restorationService.Object);

                var gridSummarySettingsRestorationService = new Mock<IGridSummarySettingsRestorationService>();

                testObjects.SetupGet(o => o.GridSummarySettingsRestorationService)
                           .Returns(gridSummarySettingsRestorationService.Object);

                var dataSource = new Mock<ITenorPriceRowDataSource>();

                dataSource.Setup(d => d.Items())
                          .Returns(_dataSourceItems);

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var priceGridInitializedArgs = new PriceGridInitializedArgs([],
                                                                            new ObservableCollection<IBandHeaderInfo>(),
                                                                            _priceCurveLookup,
                                                                            false);

                testObjects.SetupGet(o => o.PriceGridInitializedArgs)
                           .Returns(priceGridInitializedArgs);

                var priceGridFilterLoadedArgs = new PriceGridLoadArgs([], PriceGridLoadReason.FilterLoaded);

                testObjects.SetupGet(o => o.PriceGridFilterLoadedArgs)
                           .Returns(priceGridFilterLoadedArgs);

                var priceGridSummaryService = new Mock<IPriceGridSummaryService>();

                if (_priceGridSummaryException != null)
                {
                    priceGridSummaryService.Setup(p => p.RefreshColumns(It.IsAny<IList<ColumnInfo>>()))
                                           .Throws(_priceGridSummaryException);
                }

                testObjects.SetupGet(o => o.PriceGridSummaryService)
                           .Returns(priceGridSummaryService.Object);

                var priceGridRefresh = new Subject<PriceGridInitializedArgs>();

                testObjects.SetupGet(o => o.PriceGridRefresh)
                           .Returns(priceGridRefresh);

                var priceGridService = new Mock<IPriceGridService>();

                priceGridService.Setup(p => p.SchedulePriceGridRefresh(It.IsAny<IList<UserMarket>>(), 
                                                                       It.IsAny<PriceGridViewModel>(), 
                                                                       It.IsAny<List<TenorPriceRowViewModel>>(),
                                                                       It.IsAny<bool>(),
                                                                       It.IsAny<TimeSpan>()))
                                .Returns(priceGridRefresh);

                var priceGridReconnected = new Subject<Unit>();

                testObjects.SetupGet(o => o.PriceGridReconnected)
                           .Returns(priceGridReconnected);

                priceGridService.Setup(p => p.ScheduleReconnectPriceGrid(It.IsAny<IList<UserMarket>>(),
                                                                         It.IsAny<IList<LivePriceHeaderBandInfo>>(),
                                                                         It.IsAny<IList<ManualPriceHeaderBandInfo>>(),
                                                                         It.IsAny<Dictionary<LinkedCurve, List<PriceCellViewModel>>>(),
                                                                         It.IsAny<TimeSpan>()))
                                .Returns(priceGridReconnected);

                testObjects.SetupGet(o => o.PriceGridService)
                           .Returns(priceGridService.Object);

                var livePriceGridUpdateService = new Mock<ILivePriceGridUpdateService>();

                testObjects.SetupGet(o => o.LivePriceGridUpdateService)
                           .Returns(livePriceGridUpdateService.Object);

                var timestamp = new Subject<DateTime>();

                testObjects.SetupGet(o => o.Timestamp)
                           .Returns(timestamp);

                var timestampService = new Mock<ITimestampService>();

                timestampService.SetupGet(o => o.Timestamp)
                                .Returns(timestamp);

                testObjects.SetupGet(o => o.TimestampService)
                           .Returns(timestampService.Object);

                var loggerFactory = Mocks.GetLoggerFactory();

                var logger = loggerFactory.Object.Create(typeof(PriceGridViewModelController));

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var priceGridLoad = new Subject<PriceGridLoadArgs>();

                testObjects.SetupGet(o => o.PriceGridLoad)
                           .Returns(priceGridLoad);

                var dashboardSettingsService = new Mock<IDashboardSettingsService>();

                dashboardSettingsService.Setup(r => r.GetDashboardSettingsForPage(It.IsAny<int>()))
                                        .Returns(_dashboardSettings);

                testObjects.SetupGet(o => o.DashboardSettingsService)
                           .Returns(dashboardSettingsService.Object);

                var scratchPadPriceCurvesService = new Mock<IScratchPadPriceCurvesService>();

                testObjects.SetupGet(o => o.ScratchPadPriceCurvesService)
                           .Returns(scratchPadPriceCurvesService.Object);

                var scratchPadClipboard = new Mock<IScratchPadClipboard>();

                testObjects.SetupGet(o => o.ScratchPadClipboard)
                           .Returns(scratchPadClipboard.Object);

                var gridBindings = new Subject<Unit>();

                testObjects.SetupGet(o => o.GridBindings)
                           .Returns(gridBindings);

                var gridBindingsService = new Mock<IPriceGridBindingsService>();

                testObjects.SetupGet(o => o.PriceGridBindingsService)
                           .Returns(gridBindingsService.Object);

                var canSelectSpreadsService = new Mock<ICanSelectSpreadsService>();

                testObjects.SetupGet(o => o.CanSelectSpreadsService)
                           .Returns(canSelectSpreadsService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var exportPriceCellsService = new Mock<IExportPriceCellsService>();

                if (_exportPriceCellsException == null)
                {
                    exportPriceCellsService.Setup(e => e.GetPriceCellsForExport(It.IsAny<Dictionary<LinkedCurve, List<PriceCellViewModel>>>(),
                                                                                It.IsAny<IEnumerable<LivePriceHeaderBandInfo>>()))
                                           .Returns(_exportPriceCells);
                }
                else
                {
                    exportPriceCellsService.Setup(e => e.GetPriceCellsForExport(It.IsAny<Dictionary<LinkedCurve, List<PriceCellViewModel>>>(),
                                                                                It.IsAny<IEnumerable<LivePriceHeaderBandInfo>>()))
                                           .Throws(_exportPriceCellsException);
                }

                if (_exportHeadersException == null)
                {
                    exportPriceCellsService.Setup(e => e.GetHeadersForExport(It.IsAny<Dictionary<LinkedCurve, List<PriceCellViewModel>>>(),
                                                                             It.IsAny<IEnumerable<LivePriceHeaderBandInfo>>()))
                                           .Returns(_exportHeaders);
                }
                else
                {
                    exportPriceCellsService.Setup(e => e.GetHeadersForExport(It.IsAny<Dictionary<LinkedCurve, List<PriceCellViewModel>>>(),
                                                                             It.IsAny<IEnumerable<LivePriceHeaderBandInfo>>()))
                                           .Throws(_exportHeadersException);
                }

                testObjects.SetupGet(o => o.ExportPriceCellsService)
                           .Returns(exportPriceCellsService.Object);

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.Dispatcher)
                                 .Returns(Scheduler.Immediate);

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(testScheduler);

                var priceDirectionDisplayService = new Mock<IPriceDirectionDisplayService>();

                testObjects.SetupGet(o => o.PriceDirectionDisplayService)
                           .Returns(priceDirectionDisplayService.Object);

                var bandHeaderAlignmentService = new Mock<IBandHeaderAlignmentService>();

                testObjects.SetupGet(o => o.BandHeaderAlignmentService)
                           .Returns(bandHeaderAlignmentService.Object);

                var priceColumnWidthService = new Mock<IPriceColumnWidthService>();

                testObjects.SetupGet(o => o.PriceColumnWidthService)
                           .Returns(priceColumnWidthService.Object);

                var bandHeaderInfoDataSource = new Mock<IBandHeaderInfoDataSource>();

                testObjects.SetupGet(o => o.BandHeaderInfoDataSource)
                           .Returns(bandHeaderInfoDataSource.Object);

                var bandHeaderInfoDataSourceService = new Mock<IBandHeaderInfoDataSourceService>();

                bandHeaderInfoDataSourceService.Setup(d => d.PriceBandHeadersInfos())
                                               .Returns(_priceBandHeaderInfos);

                bandHeaderInfoDataSourceService.Setup(d => d.LivePriceHeaderBandInfos())
                                               .Returns(_livePriceHeaderBandInfos);

                bandHeaderInfoDataSourceService.Setup(d => d.ManualPriceHeaderBandInfos())
                                               .Returns(_manualPriceHeaderBandInfos);

                bandHeaderInfoDataSourceService.SetupGet(d => d.DataSource)
                                               .Returns(bandHeaderInfoDataSource.Object);

                testObjects.SetupGet(o => o.BandHeaderInfoDataSourceService)
                           .Returns(bandHeaderInfoDataSourceService.Object);

                var priceBandVisibleIndexService = new Mock<IPriceBandVisibleIndexService>();

                testObjects.SetupGet(o => o.PriceBandVisibleIndexService)
                           .Returns(priceBandVisibleIndexService.Object);

                var controller = new PriceGridViewModelController(priceGridService.Object,
                                                                  livePriceGridUpdateService.Object,
                                                                  gridBindingsService.Object,
                                                                  priceGridToolBarController.Object,
                                                                  timestampService.Object,
                                                                  schedulerProvider.Object,
                                                                  loggerFactory.Object)
                {
                    BandHeaderInfoDataSourceService = bandHeaderInfoDataSourceService.Object,
                    PriceGridCommandService = priceGridCommandService.Object,
                    PriceGridSummaryService = priceGridSummaryService.Object,
                    PriceBandVisibleIndexService = priceBandVisibleIndexService.Object,
                    PopupNotificationService = popupNotificationService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    DashboardSettingsService = dashboardSettingsService.Object,
                    ExportPriceCellsService = exportPriceCellsService.Object,
                    PriceDirectionDisplayService = priceDirectionDisplayService.Object,
                    BandHeaderAlignmentService = bandHeaderAlignmentService.Object,
                    PriceColumnWidthService = priceColumnWidthService.Object,
                    RestorationService = restorationService.Object,
                    GridSummarySettingsRestorationService = gridSummarySettingsRestorationService.Object,
                    PerformanceLogger = Mock.Of<IPerformanceLogger>()
                };

                controller.ViewModel.ToolBar.MarketsFilterText = _marketsFilterText;
                
                controller.ViewModel.ShowGrid = _showGrid;
                controller.ViewModel.ShowAddRowButton = _showAddRowButton;

                if (_summaryItems != null)
                {
                    controller.ViewModel.SummaryItems = _summaryItems;
                }

                gridBindingsService.Setup(gb => gb.BindAll(It.IsAny<PriceGridViewModel>(),
                                                           It.IsAny<ITenorPriceRowDataSource>(),
                                                           It.IsAny<IBandHeaderInfoDataSource>(),
                                                           It.IsAny<IList<IBandHeaderInfo>>(),
                                                           It.IsAny<List<TenorPriceRowEnvelope>>(),
                                                           It.IsAny<IList<ColumnInfo>>()))
                                   .Returns(gridBindings);
                
                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                if (_initializePage.HasValue)
                {
                    controller.Initialize(1,
                                          dataSource.Object,
                                          removePriceBandService.Object,
                                          scratchPadPriceCurvesService.Object,
                                          scratchPadClipboard.Object,
                                          priceGridLoad);
                }

                controller.ViewModel.Model().PriceCurveLookup = _priceCurveLookup;

                return testObjects.Object;
            }
        }

        #region Initialize

        [Test]
        public void ShouldSetPriceGridToolBar()
        {
            // ACT
            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.ToolBar, Is.Not.Null);
        }

        [Test]
        public void ShouldDisplayWaitIndicatorWithTextOnStart()
        {
            // ACT
            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);
        }

        [Test]
        public void ShouldSetPageNumber_And_InitializeCommandsAndSummary_When_LoadFromSettings()
        {
            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .Build();

            // ACT
            testObjects.Controller.Initialize(1, 
                                              testObjects.DataSource,
                                              testObjects.RemovePriceBandService, 
                                              testObjects.ScratchPadPriceCurvesService,
                                              testObjects.ScratchPadClipboard,
                                              testObjects.PriceGridLoad);

            // ASSERT
            Assert.That(testObjects.ViewModel.Model().PageNumber, Is.EqualTo(1));

            Mock.Get(testObjects.PriceGridCommandService)
                .Verify(p => p.Initialize(testObjects.ViewModel,
                                          testObjects.DataSource, 
                                          testObjects.BandHeaderInfoDataSourceService));

            Mock.Get(testObjects.PriceGridSummaryService)
                .Verify(s => s.AttachPriceGrid(testObjects.ViewModel));
   
        }

        #endregion

        #region Timestamp

        [Test]
        public void ShouldSubscribeToTimestamp()
        {
            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Mock.Get(testObjects.TimestampService).VerifyGet(t => t.Timestamp, Times.Once);
        }

        [Test]
        public void ShouldUpdateTimestamp()
        {
            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().Build();

            var time = new DateTime(2019, 1, 1, 12, 30, 15, DateTimeKind.Utc);
 
            // ACT
            testObjects.Timestamp.OnNext(time);

            // ASSERT
            Assert.That(testObjects.ViewModel.Timestamp, Is.EqualTo("UTC : 01/01/2019 12:30:15"));
        }

        #endregion

        #region Load Price Grid - Prepare Grid Refresh

        [TestCase(PriceGridLoadReason.FilterLoaded)]
        [TestCase(PriceGridLoadReason.ManualFilter)]
        [TestCase(PriceGridLoadReason.PublicationSettings)]
        [TestCase(PriceGridLoadReason.MonthEndRoll)]
        [TestCase(PriceGridLoadReason.RemovedCurves)]
		[TestCase(PriceGridLoadReason.CurvesDeleted)]
		public void ShouldClearPriceGrid_On_PriceGridLoad_With_GridColumnsOrRowsChanged(PriceGridLoadReason reason)
        {
            var rowItems = new[] { new TenorPriceRowViewModel(new TenorEnvelope(new MonthlyTenor(2023, 1))) };

            var summaryItem = new GridSummaryItem();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()], reason);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithDataSourceItems(rowItems)
                                                                                 .WithSummaryItems([summaryItem])
                                                                                 .WithShowGrid(true)
                                                                                 .WithShowAddRowButton(true)
                                                                                 .WithMarketsFilterText("abc")
                                                                                 .Build();
            // ACT
            testObjects.PriceGridLoad.OnNext(args);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.ToolBar.MarketsFilterText, Is.Null);
            Assert.That(testObjects.ViewModel.ShowGrid, Is.False);
            Assert.That(testObjects.ViewModel.ShowAddRowButton, Is.False);
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.EqualTo("Loading Price Curves..."));
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.True);

            Mock.Get(testObjects.LivePriceGridUpdateService)
                .Verify(u => u.DisposeMonitors());

            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .Verify(s => s.UpdateIsLoading(true));

            Mock.Get(testObjects.BandHeaderInfoDataSource)
                .Verify(d => d.Clear());

            Assert.That(testObjects.ViewModel.SummaryItems, Is.Empty);
        }

        [TestCase(PriceGridLoadReason.FilterLoaded)]
        [TestCase(PriceGridLoadReason.ManualFilter)]
        [TestCase(PriceGridLoadReason.PublicationSettings)]
        [TestCase(PriceGridLoadReason.RemovedCurves)]
		[TestCase(PriceGridLoadReason.CurvesDeleted)]
		public void ShouldSchedulePriceGridRefresh_On_PriceGridLoad(PriceGridLoadReason reason)
        {
            var rowItems = new[] {
                                     new TenorPriceRowViewModel(new TenorEnvelope(new MonthlyTenor(2023, 1)))
                                 };

            var userMarkets = new[] { new UserMarketTestObjectBuilder().Build() };

            var args = new PriceGridLoadArgs(userMarkets, reason);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithDataSourceItems(rowItems)
                                                                                 .Build();
            // ACT
            testObjects.PriceGridLoad.OnNext(args);

            // ASSERT
            Mock.Get(testObjects.PriceGridService)
                .Verify(rs => rs.SchedulePriceGridRefresh(userMarkets,
                                                          testObjects.ViewModel,
                                                          It.Is<List<TenorPriceRowViewModel>>(r => r.SequenceEqual(rowItems)),
                                                          false,
                                                          It.IsAny<TimeSpan>()));
        }

        [Test]
        public void ShouldSchedulePriceGridRefresh_With_RefreshAllPrices_On_PriceGridLoad_With_MonthEndRoll()
        {
            var rowItems = new[] {
                                     new TenorPriceRowViewModel(new TenorEnvelope(new MonthlyTenor(2023, 1)))
                                 };

            var userMarkets = new[] { new UserMarketTestObjectBuilder().Build() };

            var args = new PriceGridLoadArgs(userMarkets, PriceGridLoadReason.MonthEndRoll);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithDataSourceItems(rowItems)
                                                                                 .Build();
            // ACT
            testObjects.PriceGridLoad.OnNext(args);

            // ASSERT
            Mock.Get(testObjects.PriceGridService)
                .Verify(rs => rs.SchedulePriceGridRefresh(userMarkets,
                                                          testObjects.ViewModel,
                                                          It.Is<List<TenorPriceRowViewModel>>(r => r.SequenceEqual(rowItems)),
                                                          true,
                                                          It.IsAny<TimeSpan>()));
        }

        [TestCase(PriceGridLoadReason.FilterLoaded)]
        [TestCase(PriceGridLoadReason.ManualFilter)]
        [TestCase(PriceGridLoadReason.PublicationSettings)]
        [TestCase(PriceGridLoadReason.MonthEndRoll)]
        [TestCase(PriceGridLoadReason.RemovedCurves)]
		[TestCase(PriceGridLoadReason.CurvesDeleted)]
		public void ShouldSetBindings_And_PriceCurveLookup_On_PriceGridRefresh(PriceGridLoadReason reason)
        {
            var settings = new DashboardSettings();

            var tenorBandHeaderInfo = new TenorHeaderBandTestObjectBuilder().BandHeaderInfo();
            var livePriceHeaderBandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();
            var manualPriceBandHeaderInfo = new ManualPriceHeaderBandInfoTestObjectBuilder().ManualPriceBandHeaderInfo();

            var bandHeaderInfos = new List<IBandHeaderInfo>
                                  {
                                      tenorBandHeaderInfo, livePriceHeaderBandInfo, manualPriceBandHeaderInfo
                                  };

            var rowEnvelope = new TenorPriceRowEnvelope(new TenorPriceRowViewModel(new TenorEnvelope(new MonthlyTenor(2024, 1))),
                                                        RowRefreshStatus.Add);

            var rowEnvelopes = new List<TenorPriceRowEnvelope> { rowEnvelope };

            var lookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>();

            var priceGridInitializedArgs = new PriceGridInitializedArgs(rowEnvelopes,
                                                                       bandHeaderInfos,
                                                                       lookup,
                                                                       false);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             reason);

            testObjects.PriceGridLoad.OnNext(args);

            var expectedColumnInfos = new[]
                                      {
                                          livePriceHeaderBandInfo.LivePriceBandInfo.LivePriceColumnInfo,
                                          manualPriceBandHeaderInfo.ManualPriceBandInfo.ManualPriceColumnInfo
                                      };

            // ACT
            testObjects.PriceGridRefresh.OnNext(priceGridInitializedArgs);

            // ASSERT
            Assert.AreSame(testObjects.ViewModel.Model().PriceCurveLookup, lookup);

            Mock.Get(testObjects.PriceGridBindingsService)
                .Verify(bs => bs.BindAll(testObjects.ViewModel,
                                         testObjects.DataSource,
                                         testObjects.BandHeaderInfoDataSource,
                                         bandHeaderInfos,
                                         rowEnvelopes,
                                         It.Is<IList<ColumnInfo>>(c => c.SequenceEqual(expectedColumnInfos))));
        }

        [TestCase(PriceGridLoadReason.FilterLoaded)]
        [TestCase(PriceGridLoadReason.ManualFilter)]
        [TestCase(PriceGridLoadReason.PublicationSettings)]
        [TestCase(PriceGridLoadReason.MonthEndRoll)]
        [TestCase(PriceGridLoadReason.RemovedCurves)]
		[TestCase(PriceGridLoadReason.CurvesDeleted)]
		public void ShouldRestoreColumnWidths_And_Highlights_On_PriceGridRefresh(PriceGridLoadReason reason)
        {
            var settings = new DashboardSettings();

            var tenorBandHeaderInfo = new TenorHeaderBandTestObjectBuilder().BandHeaderInfo();
            var livePriceHeaderBandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();
            var manualPriceBandHeaderInfo = new ManualPriceHeaderBandInfoTestObjectBuilder().ManualPriceBandHeaderInfo();

            var bandHeaderInfos = new List<IBandHeaderInfo>
                                  {
                                      tenorBandHeaderInfo, livePriceHeaderBandInfo, manualPriceBandHeaderInfo
                                  };

            var priceGridInitializedArgs = new PriceGridInitializedArgs([], bandHeaderInfos, [], false);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             reason);

            testObjects.PriceGridLoad.OnNext(args);

            var expectedColumnInfos = new[]
                                      {
                                          livePriceHeaderBandInfo.LivePriceBandInfo.LivePriceColumnInfo,
                                          manualPriceBandHeaderInfo.ManualPriceBandInfo.ManualPriceColumnInfo
                                      };

            // ACT
            testObjects.PriceGridRefresh.OnNext(priceGridInitializedArgs);

            // ASSERT
            Mock.Get(testObjects.RestorationService)
                .Verify(r => r.RestoreColumnWidths(It.Is<IList<ColumnInfo>>(c => c.SequenceEqual(expectedColumnInfos)),
                                                   settings.PriceGridSettings,
                                                   It.IsAny<int>()));

            Mock.Get(testObjects.RestorationService)
                .Verify(r => r.RestoreHighlightedPrices(It.Is<IList<ColumnInfo>>(c => c.SequenceEqual(expectedColumnInfos)),
                                                        settings.PriceGridSettings));

            Mock.Get(testObjects.GridSummarySettingsRestorationService)
                .Verify(r => r.RestoreSelectedSpreadsAndAverages(It.Is<List<ColumnInfo>>(c => c.SequenceEqual(expectedColumnInfos)),
                                                                 settings.PriceGridSettings));
        }

        [TestCase(PriceGridLoadReason.FilterLoaded)]
        [TestCase(PriceGridLoadReason.PublicationSettings)]
        [TestCase(PriceGridLoadReason.MonthEndRoll)]
        [TestCase(PriceGridLoadReason.RemovedCurves)]
		[TestCase(PriceGridLoadReason.CurvesDeleted)]
		public void ShouldRestoreBandIndices_On_PriceGridRefresh_WithReason_Not_ManualFilter(PriceGridLoadReason reason)
        {
            var settings = new DashboardSettings();

            var tenorBandHeaderInfo = new TenorHeaderBandTestObjectBuilder().BandHeaderInfo();
            var livePriceHeaderBandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();
            var manualPriceBandHeaderInfo = new ManualPriceHeaderBandInfoTestObjectBuilder().ManualPriceBandHeaderInfo();

            var bandHeaderInfos = new List<IBandHeaderInfo>
                                  {
                                      tenorBandHeaderInfo, livePriceHeaderBandInfo, manualPriceBandHeaderInfo
                                  };

            var priceGridInitializedArgs = new PriceGridInitializedArgs([], bandHeaderInfos, [], false);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .Build();

            var userMarkets = new[] { new UserMarketTestObjectBuilder().Build() };

            var args = new PriceGridLoadArgs(userMarkets, reason);

            testObjects.PriceGridLoad.OnNext(args);


            var expectedBandHeaderInfos = new IBandHeaderInfo[] { livePriceHeaderBandInfo, manualPriceBandHeaderInfo };

            // ACT
            testObjects.PriceGridRefresh.OnNext(priceGridInitializedArgs);

            // ASSERT
            Mock.Get(testObjects.RestorationService)
                .Verify(r => r.RestoreBandIndices(It.Is<IList<IPriceBandHeaderInfo>>(b => b.SequenceEqual(expectedBandHeaderInfos)),
                                                  settings.PriceGridSettings));
        }

        [Test]
        public void ShouldNotRestoreBandIndices_On_PriceGridRefresh_WithReason_ManualFilter()
        {
            var settings = new DashboardSettings();

            var tenorBandHeaderInfo = new TenorHeaderBandTestObjectBuilder().BandHeaderInfo();
            var livePriceHeaderBandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();
            var manualPriceBandHeaderInfo = new ManualPriceHeaderBandInfoTestObjectBuilder().ManualPriceBandHeaderInfo();

            var bandHeaderInfos = new List<IBandHeaderInfo>
                                  {
                                      tenorBandHeaderInfo, livePriceHeaderBandInfo, manualPriceBandHeaderInfo
                                  };

            var priceGridInitializedArgs = new PriceGridInitializedArgs([], bandHeaderInfos, [], false);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .Build();

            var userMarkets = new[] { new UserMarketTestObjectBuilder().Build() };

            var args = new PriceGridLoadArgs(userMarkets,  PriceGridLoadReason.ManualFilter);

            testObjects.PriceGridLoad.OnNext(args);

            // ACT
            testObjects.PriceGridRefresh.OnNext(priceGridInitializedArgs);

            // ASSERT
            Mock.Get(testObjects.RestorationService)
                .Verify(r => r.RestoreBandIndices(It.IsAny<IList<IPriceBandHeaderInfo>>(), settings.PriceGridSettings), 
                        Times.Never);
        }

        [TestCase(PriceGridLoadReason.FilterLoaded)]
        [TestCase(PriceGridLoadReason.PublicationSettings)]
        [TestCase(PriceGridLoadReason.MonthEndRoll)]
        [TestCase(PriceGridLoadReason.RemovedCurves)]
        [TestCase(PriceGridLoadReason.ManualFilter)]
		[TestCase(PriceGridLoadReason.CurvesDeleted)]
		public void ShouldRefreshSettingAndMonitors_On_GridBindingsComplete(PriceGridLoadReason reason)
        {
            var settings = new DashboardSettings
            {
                PriceGridSettings = new DashboardPriceGridSettings { ShowPriceDirection = true }
            };

            var livePriceHeaderBandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();

            var manualPriceBandHeaderInfo = new ManualPriceHeaderBandInfoTestObjectBuilder().WithPriceCells([])
                                                                                            .ManualPriceBandHeaderInfo();

            var priceBandHeaders = new IPriceBandHeaderInfo[] { livePriceHeaderBandInfo, manualPriceBandHeaderInfo };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos(priceBandHeaders)
                                                                                 .WithLivePriceHeaderBandInfos([livePriceHeaderBandInfo])
                                                                                 .WithManualPriceHeaderBandInfos([manualPriceBandHeaderInfo])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            var priceGridInitializedArgs = new PriceGridInitializedArgs([], [], [], false);

            testObjects.PriceGridRefresh.OnNext(priceGridInitializedArgs);

            var expectedLivePriceColumns = new[] { livePriceHeaderBandInfo.LivePriceBandInfo.LivePriceColumnInfo };

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.PriceDirectionDisplayService)
                .Verify(d => d.RefreshFromSettings(testObjects.ViewModel, 
                                                   testObjects.DataSource, 
                                                   settings.PriceGridSettings));

            Mock.Get(testObjects.BandHeaderAlignmentService)
                .Verify(b => b.RefreshFromSettings(testObjects.ViewModel.GridDisplaySettings,
                                                   It.Is<IEnumerable<IPriceBandHeaderInfo>>(h => h.SequenceEqual(priceBandHeaders)),
                                                   1,
                                                   settings.PriceGridSettings));

            Mock.Get(testObjects.PriceGridSummaryService)
                .Verify(s => s.RefreshColumns(It.Is<IList<ColumnInfo>>(i => i.SequenceEqual(expectedLivePriceColumns))));

            Mock.Get(testObjects.PriceColumnWidthService)
                .Verify(c => c.RefreshColumns(1,
                                              testObjects.ViewModel.GridDisplaySettings,
                                              It.Is<IList<ColumnInfo>>(i => i.SequenceEqual(expectedLivePriceColumns)),
                                              settings.PriceGridSettings,
                                              It.IsAny<int>(),
                                              It.IsAny<IScheduler>()));

            Mock.Get(testObjects.PriceBandVisibleIndexService)
                .Verify(p => p.MonitorBandIndexChanges(It.Is<IList<IPriceBandHeaderInfo>>(b => b.SequenceEqual(priceBandHeaders)),
                                                       1,
                                                       It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldUpdateScratchPad_On_GridBindingsComplete()
        {
            var settings = new DashboardSettings();

            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var q3 = new QuarterlyTenor(2023, 3).GetTenorValue();
            var oct = new MonthlyTenor(2023, 10).GetTenorValue();
            var nov = new MonthlyTenor(2023, 11).GetTenorValue();

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithRowTenorType(RowTenorType.Quarterly).WithTenorValue(q3).PriceCell();
            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithRowTenorType(RowTenorType.Monthly).WithTenorValue(oct).WithIsSelected(true).PriceCell();
            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithRowTenorType(RowTenorType.Monthly).WithTenorValue(nov).PriceCell();

            var curveLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
                              {
                                  { linkedCurve1, [priceCell1, priceCell2, priceCell3] }
                              };

            var expectedKeys = new[] { linkedCurve1 };

            var expectedValues = new[]
                           {
                               new TenorPriceCell(101, oct, priceCell2.LivePrice.MidPrice),
                               new TenorPriceCell(101, nov, priceCell3.LivePrice.MidPrice)
                           };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithPriceCurveLookup(curveLookup)
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithPriceBandHeaderBandInfos([])
                                                                                 .WithInitializePage(1)
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(testObjects.PriceGridInitializedArgs);

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .Verify(s => s.UpdatePriceCurves(It.Is<Dictionary<LinkedCurve, List<TenorPriceCell>>>(pc => pc.Keys.SequenceEqual(expectedKeys)
                                                                                                     && pc[linkedCurve1].SequenceEqual(expectedValues, new TenorPriceCellEqualityComparer()))));

            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .Verify(s => s.UpdateIsLoading(false));
        }

        [Test]
        public void ShouldShowPriceGrid_On_GridBindingsComplete()
        {
            var settings = new DashboardSettings();

            var livePriceHeaderBandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([livePriceHeaderBandInfo])
                                                                                 .WithPriceBandHeaderBandInfos([])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(new PriceGridInitializedArgs([], [], [], false));

            testObjects.ViewModel.IsBusy = true;
            testObjects.ViewModel.BusyText = "busy";

            Mock.Get(testObjects.LivePriceGridUpdateService).Invocations.Clear();

            var expectedLivePriceBands = new[] { livePriceHeaderBandInfo.LivePriceBandInfo };

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.LivePriceGridUpdateService)
                .Verify(d => d.RefreshPriceMonitors(It.Is<IEnumerable<LivePriceBandInfo>>(b => b.SequenceEqual(expectedLivePriceBands))));

            Assert.That(testObjects.ViewModel.ShowGrid, Is.True);
            Assert.That(testObjects.ViewModel.PriceGridLoaded, Is.True);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.False);
        }

        [Test]
        public void ShouldShowAddRowsButton_On_GridBindings_With_ManualCurves()
        {
            var manualPriceBandHeader = new ManualPriceHeaderBandInfoTestObjectBuilder().WithPriceCells([]).ManualPriceBandHeaderInfo();

            var settings = new DashboardSettings();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([])
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithManualPriceHeaderBandInfos([manualPriceBandHeader])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(new PriceGridInitializedArgs([], [], [], false));

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowAddRowButton, Is.True);
        }

        [Test]
        public void ShouldHideAddRowsButton_On_GridBindings_With_NoManualCurves()
        {
            var settings = new DashboardSettings();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([])
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithManualPriceHeaderBandInfos([])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(new PriceGridInitializedArgs([], [], [], false));

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowAddRowButton, Is.False);
        }

        #endregion

        #region Load Price Grid - Popup Notifications 

        [Test]
        public void ShouldShowPopupNotification_When_GridRefreshed_After_MonthEndRoll()
        {
            var settings = new DashboardSettings
            {
                PriceGridSettings = new DashboardPriceGridSettings()
            };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([])
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithManualPriceHeaderBandInfos([])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.MonthEndRoll);

            // ARRANGE = Month End Roll
            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(new PriceGridInitializedArgs([], [], [], false));

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification("Price Grid has reloaded due to", "Month End Roll"));
        }

        [Test]
        public void ShouldShowPopupNotification_On_GridBindingsComplete_With_PublisherChanged()
        {
            var settings = new DashboardSettings
            {
                PriceGridSettings = new DashboardPriceGridSettings()
            };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([])
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithManualPriceHeaderBandInfos([])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.PublicationSettings);

            // ARRANGE - Publisher Changed
            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(new PriceGridInitializedArgs([], [], [], false));

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification("Price Grid has reloaded due to change in", "your Curve Publication Settings"));
        }

		[Test]
		public void ShouldShowPopupNotification_On_GridBindingsComplete_With_CurvesDeleted()
		{
			var settings = new DashboardSettings
						   {
							   PriceGridSettings = new DashboardPriceGridSettings()
						   };

			var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
																				 .WithInitializePage(1)
																				 .WithPriceBandHeaderBandInfos([])
																				 .WithLivePriceHeaderBandInfos([])
																				 .WithManualPriceHeaderBandInfos([])
																				 .Build();

			var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
											 PriceGridLoadReason.CurvesDeleted);

			// ARRANGE - Publisher Changed
			testObjects.PriceGridLoad.OnNext(args);

			testObjects.PriceGridRefresh.OnNext(new PriceGridInitializedArgs([], [], [], false));

			// ACT
			testObjects.GridBindings.OnNext(Unit.Default);

			// ASSERT
			Mock.Get(testObjects.PopupNotificationService)
				.Verify(p => p.SendPopupNotification("Price Grid has reloaded due to deletion of", "Curves in your Filter"));
		}

		#endregion

		#region Load Price Grid - Errors

		[Test]
        public void ShouldShowMessageDialog_On_GridBindings_With_LivePricesPartialOrFailed()
        {
            var settings = new DashboardSettings
            {
                PriceGridSettings = new DashboardPriceGridSettings { ShowPriceDirection = true }
            };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([])
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(new PriceGridInitializedArgs([], [], [], true));

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(a => a.Messages[0] == "Some Live Price Curves Have Failed to Load"
                                                                        && a.ShowSendFeedback)));

            Assert.That(testObjects.ViewModel.PriceGridLoaded, Is.True);
        }

        [Test]
        public void ShouldLogError_And_ActivePriceGrid_When_PriceGridRefreshError()
        {
            var settings = new DashboardSettings();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                          .WithPriceBandHeaderBandInfos([])
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithInitializePage(1)
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            // ACT
            testObjects.PriceGridRefresh.OnError(new Exception("error"));

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowGrid, Is.True);
            Assert.That(testObjects.ViewModel.PriceGridLoaded, Is.True);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.False);

            Mock.Get(testObjects.LivePriceGridUpdateService)
                .Verify(u => u.RefreshPriceMonitors(It.IsAny<IEnumerable<LivePriceBandInfo>>()), Times.Never);
        }

        [Test]
        public void ShouldLogError_And_ActivePriceGrid_When_GridBindingsError()
        {
            var settings = new DashboardSettings();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(testObjects.PriceGridInitializedArgs);

            testObjects.ViewModel.IsBusy = true;
            testObjects.ViewModel.BusyText = "busy";

            // ACT
            testObjects.GridBindings.OnError(new Exception());

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(o => o.Error(It.IsAny<string>()));

            Assert.That(testObjects.ViewModel.ShowGrid, Is.True);
            Assert.That(testObjects.ViewModel.PriceGridLoaded, Is.True);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.False);
        }

        #endregion

        #region Price Grid Load - Failed Startup

        [Test]
        public void ShouldHideBusyIndicator_On_FailedStartup()
        {
            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()], PriceGridLoadReason.FailedStartup);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .Build();

            testObjects.ViewModel.IsBusy = true;
            testObjects.ViewModel.BusyText = "test";

            // ACT
            testObjects.PriceGridLoad.OnNext(args);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.False);
        }

        [Test]
        public void ShouldHideBusyIndicator_On_EmptyUserMarkets()
        {
            var args = new PriceGridLoadArgs([], PriceGridLoadReason.FilterLoaded);

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .Build();

            testObjects.ViewModel.IsBusy = true;
            testObjects.ViewModel.BusyText = "test";

            // ACT
            testObjects.PriceGridLoad.OnNext(args);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.False);
        }

        #endregion

        #region Reconnected

        [Test]
        public void ShouldClearScratchPad_And_ScheduleReconnectPriceGrid_On_Reconnected()
        {
            var livePriceBand = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();
            var manualPriceBand = new ManualPriceHeaderBandInfoTestObjectBuilder().ManualPriceBandHeaderInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([livePriceBand])
                                                                                 .WithManualPriceHeaderBandInfos([manualPriceBand])
                                                                                 .WithDashboardSettings(new DashboardSettings())
                                                                                 .Build();

            var userMarkets = new[] { new UserMarketTestObjectBuilder().Build() };

            var filterLoaded = new PriceGridLoadArgs(userMarkets, PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(filterLoaded);
            testObjects.PriceGridRefresh.OnNext(testObjects.PriceGridInitializedArgs);

            var expectedLiveBands = new[] { livePriceBand };
            var expectedManualBands = new[] { manualPriceBand };

            var reconnected = new PriceGridLoadArgs(userMarkets, PriceGridLoadReason.Reconnected);

            // ACT
            testObjects.PriceGridLoad.OnNext(reconnected);

            // ASSERT
            Mock.Get(testObjects.LivePriceGridUpdateService)
                .Verify(l => l.DisposeMonitors());

            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .Verify(s => s.UpdateIsLoading(true));

            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .Verify(s => s.NotifyClearBindings());

            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.True);

            Mock.Get(testObjects.PriceGridService)
                .Verify(rs => rs.ScheduleReconnectPriceGrid(It.Is<IList<UserMarket>>(m => m.SequenceEqual(userMarkets)),
                                                            It.Is<IList<LivePriceHeaderBandInfo>>(b => b.SequenceEqual(expectedLiveBands)),
                                                            It.Is<IList<ManualPriceHeaderBandInfo>>(b => b.SequenceEqual(expectedManualBands)),
                                                            It.IsAny<Dictionary<LinkedCurve, List<PriceCellViewModel>>>(),
                                                            It.IsAny<TimeSpan>()));
        }

        [Test]
        public void ShouldRefreshMonitors_And_SetIsBusyFalse_And_ShowPopup_On_PriceGridReconnected()
        {
            var settings = new DashboardSettings {
                                                     PriceGridSettings = new DashboardPriceGridSettings()
                                                 };

            var liveBandHeader = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();
            var manualBandHeader = new ManualPriceHeaderBandInfoTestObjectBuilder().ManualPriceBandHeaderInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithLivePriceHeaderBandInfos([liveBandHeader])
                                                                                 .WithManualPriceHeaderBandInfos([manualBandHeader])
                                                                                 .WithInitializePage(1)
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.Reconnected);

            testObjects.PriceGridLoad.OnNext(args);

            var expectedBandHeaders = new[] { liveBandHeader.LivePriceBandInfo };

            // ACT
            testObjects.PriceGridReconnected.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.LivePriceGridUpdateService)
                .Verify(l => l.RefreshPriceMonitors(It.Is<IEnumerable<LivePriceBandInfo>>(b => b.SequenceEqual(expectedBandHeaders))));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.False);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification("Curve Publisher Reconnected", "Price updates have been restored"));
        }

        [Test]
        public void ShouldRestoreScratchPad_On_PriceGridReconnected()
        {
            var settings = new DashboardSettings {
                                                     PriceGridSettings = new DashboardPriceGridSettings()
                                                 };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithManualPriceHeaderBandInfos([])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.Reconnected);

            testObjects.PriceGridLoad.OnNext(args);

            // ACT
            testObjects.PriceGridReconnected.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .Verify(s => s.UpdateIsLoading(false));

            Mock.Get(testObjects.ScratchPadPriceCurvesService)
                .Verify(s => s.NotifyRestoreBindings());
        }

        [Test]
        public void ShouldSetIsBusyFalse_On_PriceGridReconnected_With_Error()
        {
            var settings = new DashboardSettings {
                                                     PriceGridSettings = new DashboardPriceGridSettings()
                                                 };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithManualPriceHeaderBandInfos([])
                                                                                 .WithDashboardSettings(settings)
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);
            testObjects.PriceGridRefresh.OnNext(testObjects.PriceGridInitializedArgs);

            var reconnected = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                                    PriceGridLoadReason.Reconnected);

            testObjects.PriceGridLoad.OnNext(reconnected);

            // ACT
            testObjects.PriceGridReconnected.OnError(new Exception());

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(a => a.ShowSendFeedback)));
        }

        #endregion

        #region Add Row Command

        [Test]
        public void ShouldExtendPriceGrid_On_AddRowCommand()
        {
            var livePriceBand = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();
            var manualPriceBand = new ManualPriceHeaderBandInfoTestObjectBuilder().ManualPriceBandHeaderInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([livePriceBand])
                                                                                 .WithManualPriceHeaderBandInfos([manualPriceBand])
                                                                                 .Build();

            var expectedLiveBands = new[] { livePriceBand };
            var expectedManualBands = new[] { manualPriceBand };

            // ACT
            testObjects.ViewModel.AddRowCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.PriceGridService)
                .Verify(p => p.ExtendPriceGrid(testObjects.ViewModel, 
                                               It.Is<IList<LivePriceHeaderBandInfo>>(b => b.SequenceEqual(expectedLiveBands)),
                                               It.Is<IList<ManualPriceHeaderBandInfo>>(b => b.SequenceEqual(expectedManualBands)),
                                               testObjects.DataSource));
        }

        #endregion

        #region Bindings Completed Exception Handling

        [Test]
        public void ShouldShowMessageDialog_And_ShowGrid_OnPriceGridSummaryException()
        {
            var settings = new DashboardSettings
            {
                PriceGridSettings = new DashboardPriceGridSettings { ShowPriceDirection = true }
            };

            var error = new Exception("error");

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithDashboardSettings(settings)
                                                                                 .WithPriceGridSummaryException(error)
                                                                                 .WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([])
                                                                                 .WithManualPriceHeaderBandInfos([])
                                                                                 .Build();

            var args = new PriceGridLoadArgs([new UserMarketTestObjectBuilder().Build()],
                                             PriceGridLoadReason.FilterLoaded);

            testObjects.PriceGridLoad.OnNext(args);

            testObjects.PriceGridRefresh.OnNext(testObjects.PriceGridInitializedArgs);

            // ACT
            testObjects.GridBindings.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(a => a.Messages[0] == "An error has occurred generating the Price Grid"
                                                                         && a.ShowSendFeedback)));

            Mock.Get(testObjects.LivePriceGridUpdateService)
                .Verify(u => u.RefreshPriceMonitors(It.IsAny<IEnumerable<LivePriceBandInfo>>()));

            Assert.That(testObjects.ViewModel.ShowGrid, Is.True);
            Assert.That(testObjects.ViewModel.PriceGridLoaded, Is.True);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.False);
        }

        #endregion

        #region Commands - Remove Price Column

        [Test]
        public void ShouldRemoveLivePriceColumnOnCommand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var priceBand = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                          .LivePriceHeaderBandInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .Build();

            //ACT
            testObjects.ViewModel.RemovePriceBandCommand.Execute(priceBand);

            //ASSERT
            Mock.Get(testObjects.RemovePriceBandService)
                .Verify(c => c.RemovePriceBand(linkedCurve));
        }

        [Test]
        public void ShouldNotRemoveTenorHeaderBand()
        {
            var tenorBand = new TenorHeaderBandTestObjectBuilder().BandHeaderInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.RemovePriceBandCommand.Execute(tenorBand);

            // ASSERT
            Mock.Get(testObjects.RemovePriceBandService)
                .Verify(c => c.RemovePriceBand(It.IsAny<LinkedCurve>()), Times.Never());
        }

        #endregion

        #region Commands - Paste Price Cells

        [Test]
        public void ShouldPastePriceCells_When_Paste_From_ManualPriceCell()
        {
            var linkedCurve1 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);
            var linkedCurve2 = new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve);

            var pasteCommand = new Mock<ICommand>();

            var bandHeaderInfo1 = new ManualPriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve1)
                                                                                  .WithPasteFromClipboardCommand(pasteCommand.Object)
                                                                                  .ManualPriceBandHeaderInfo();

            bandHeaderInfo1.ManualPriceBandInfo.PasteFromClipboardCommand = pasteCommand.Object;

            var bandHeaderInfo2 = new ManualPriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve2)
                                                                                  .ManualPriceBandHeaderInfo();

            var priceCell = new ManualPriceCellBuilder().WithLinkedCurve(linkedCurve1)
                                                        .PriceCell();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithManualPriceHeaderBandInfos([bandHeaderInfo1, bandHeaderInfo2])
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.PastePriceCellsCommand.Execute(priceCell);

            // ASSERT
            pasteCommand.Verify(c => c.Execute(priceCell));
        }

        [Test]
        public void ShouldNotPastePriceCells_When_PasteFrom_LivePriceCell()
        {
            var linkedCurve1 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);
            var linkedCurve2 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var pasteCommand = new Mock<ICommand>();

            var bandHeaderInfo1 = new ManualPriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve1)
                                                                                  .WithPasteFromClipboardCommand(pasteCommand.Object)
                                                                                  .ManualPriceBandHeaderInfo();

            bandHeaderInfo1.ManualPriceBandInfo.PasteFromClipboardCommand = pasteCommand.Object;

            var bandHeaderInfo2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve2)
                                                                                .LivePriceHeaderBandInfo();

            var priceCell = new ManualPriceCellBuilder().WithLinkedCurve(linkedCurve2)
                                                        .PriceCell();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithManualPriceHeaderBandInfos([bandHeaderInfo1])
                                                                                 .WithLivePriceHeaderBandInfos([bandHeaderInfo2])
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.PastePriceCellsCommand.Execute(priceCell);

            // ASSERT
            pasteCommand.Verify(c => c.Execute(It.IsAny<object>()), Times.Never());
        }

        [Test]
        public void ShouldNotPaste_When_PriceCellIsNull()
        {
            var linkedCurve1 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var pasteCommand = new Mock<ICommand>();

            var bandHeaderInfo1 = new ManualPriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve1)
                                                                                  .WithPasteFromClipboardCommand(pasteCommand.Object)
                                                                                  .ManualPriceBandHeaderInfo();


            bandHeaderInfo1.ManualPriceBandInfo.PasteFromClipboardCommand = pasteCommand.Object;

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithManualPriceHeaderBandInfos([bandHeaderInfo1])
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.PastePriceCellsCommand.Execute(null);

            // ASSERT
            pasteCommand.Verify(c => c.Execute(It.IsAny<object>()), Times.Never());
        }

        #endregion

        #region Commands - Markets Filter Text

        [Test]
        public void ShouldHideGrid_And_SetBandHeadersVisibility_On_MarketsFilterText_After_BufferInterval()
        {
            var controller = new Mock<IDisposable>();

            var bandInfo1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithController(controller.Object)
                                                                          .WithHeader("ABC")
                                                                          .WithIsVisible(true)
                                                                          .LivePriceHeaderBandInfo();

            var bandInfo2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithController(controller.Object)
                                                                          .WithHeader("DEF")
                                                                          .WithIsVisible(true)
                                                                          .LivePriceHeaderBandInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([bandInfo1, bandInfo2])
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.ToolBar.MarketsFilterText = "ab";
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(510).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowGrid, Is.False);
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.True);

            Assert.That(bandInfo1.IsVisible, Is.True);
            Assert.That(bandInfo2.IsVisible, Is.False);
        }

        [Test]
        public void ShouldShowGrid_On_Timer_With_MarketsFilterText_BandHeadersVisibility()
        {
            var controller = new Mock<IDisposable>();

            var bandInfo1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithController(controller.Object)
                                                                          .WithHeader("ABC")
                                                                          .WithIsVisible(true)
                                                                          .LivePriceHeaderBandInfo();

            var bandInfo2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithController(controller.Object)
                                                                          .WithHeader("DEF")
                                                                          .WithIsVisible(true)
                                                                          .LivePriceHeaderBandInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([bandInfo1, bandInfo2])
                                                                                 .Build();

            testObjects.ViewModel.ToolBar.MarketsFilterText = "ab";
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(310).Ticks);

            // ACT
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(1).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowGrid, Is.True);
            Assert.That(testObjects.ViewModel.BeginDataUpdate, Is.False);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
            Assert.That(testObjects.ViewModel.ToolBar.PriceGridIsBusy, Is.False);
        }

        [Test]
        public void ShouldNotSetBandHeadersVisibility_On_MarketsFilterText_Before_BufferInterval()
        {
            var controller = new Mock<IDisposable>();

            var bandInfo1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithController(controller.Object)
                                                                          .WithHeader("ABC")
                                                                          .WithIsVisible(true)
                                                                          .LivePriceHeaderBandInfo();

            var bandInfo2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithController(controller.Object)
                                                                          .WithHeader("DEF")
                                                                          .WithIsVisible(true)
                                                                          .LivePriceHeaderBandInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([bandInfo1, bandInfo2])
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.ToolBar.MarketsFilterText = "ab";
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(10).Ticks);

            // ASSERT
            Assert.That(bandInfo1.IsVisible, Is.True);
            Assert.That(bandInfo2.IsVisible, Is.True);
        }

        [Test]
        public void ShouldNotFiler__On_MarketsFilterText_SameAsPrevious_IgnoreCase()
        {
            var controller = new Mock<IDisposable>();

            var bandInfo1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithController(controller.Object)
                                                                          .WithHeader("ABC")
                                                                          .WithIsVisible(true)
                                                                          .LivePriceHeaderBandInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([bandInfo1])
                                                                                 .WithMarketsFilterText("ab")
                                                                                 .Build();

            testObjects.ViewModel.ToolBar.MarketsFilterText = "AB";
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(310).Ticks);
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(1).Ticks);

            // ACT
            testObjects.ViewModel.ToolBar.MarketsFilterText = "ab";
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(310).Ticks);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowGrid, Is.True);
        }

        [Test]
        public void ShouldSetAllBandHeaderVisible_On_MarketsFilterText_Empty()
        {
            var bandInfo1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithHeader("ABC")
                                                                          .WithIsVisible(false)
                                                                          .LivePriceHeaderBandInfo();

            var bandInfo2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithHeader("DEF")
                                                                          .WithIsVisible(false)
                                                                          .LivePriceHeaderBandInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([bandInfo1, bandInfo2])
                                                                                 .Build();

            // ACT
            testObjects.ViewModel.ToolBar.MarketsFilterText = "";
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(310).Ticks);

            // ASSERT
            Assert.That(bandInfo1.IsVisible, Is.True);
            Assert.That(bandInfo2.IsVisible, Is.True);
        }

        [Test]
        public void ShouldSetAllBandHeaderVisible_On_ClearMarketsFilterCommand()
        {
            var bandInfo1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithHeader("ABC")
                                                                          .WithIsVisible(true)
                                                                          .LivePriceHeaderBandInfo();

            var bandInfo2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithHeader("DEF")
                                                                          .WithIsVisible(false)
                                                                          .LivePriceHeaderBandInfo();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithPriceBandHeaderBandInfos([bandInfo1, bandInfo2])
                                                                                 .WithMarketsFilterText("AB")
                                                                                 .Build();

            testObjects.ViewModel.ToolBar.ClearMarketsFilterCommand.Execute();

            // ASSERT
            Assert.That(bandInfo1.IsVisible, Is.True);
            Assert.That(bandInfo2.IsVisible, Is.True);
        }

        #endregion

        #region Commands - Export Prices to Scratch Pad

        [Test]
        public void ShouldCopySelectedTenors_And_Prices_To_ScratchPadClipboard_On_ExportPricesCommand()
        {
            var curveLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>();

            var bandHeaderInfo = new LivePriceHeaderBandInfoTestObjectBuilder().LivePriceHeaderBandInfo();

            var exportPriceCells = new List<List<TenorPriceCell>> { new() { Defaults.TenorPriceCell() } };

            var q3 = new QuarterlyTenor(2023, 3);
            var oct = new MonthlyTenor(2023, 10);
            var nov = new MonthlyTenor(2023, 11);

            var tenorPriceRow1 = new TenorPriceRowViewModel(new TenorEnvelope(q3));
            var tenorPriceRow2 = new TenorPriceRowViewModel(new TenorEnvelope(oct));
            var tenorPriceRow3 = new TenorPriceRowViewModel(new TenorEnvelope(nov));

            tenorPriceRow1.Tenor.IsSelected = true;
            tenorPriceRow2.Tenor.IsSelected = true;

            var tenorPriceRows = new[] { tenorPriceRow1, tenorPriceRow2, tenorPriceRow3 };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([bandHeaderInfo])
                                                                                 .WithPriceCurveLookup(curveLookup)
                                                                                 .WithDataSourceItems(tenorPriceRows)
                                                                                 .WithExportPriceCells(exportPriceCells)
                                                                                 .Build();

            var expectedHeaders = new[] { bandHeaderInfo };
            var expectedTenors = new List<ITenor> { oct };

            // ACT
            testObjects.ViewModel.ExportPricesCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ExportPriceCellsService)
                .Verify(e => e.GetPriceCellsForExport(curveLookup, expectedHeaders));

            Mock.Get(testObjects.ScratchPadClipboard)
                .Verify(c => c.CopyToClipboard(exportPriceCells,
                                               It.Is<IList<ITenor>>(t => t.SequenceEqual(expectedTenors)), 
                                               It.Is<IList<string>>(h => h.Count == 0)));
        }

        [Test]
        public void ShouldShowPopup_On_ExportPricesCommand_Exception()
        {
            var exportError = new Exception("error");

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithExportPriceCellsException(exportError)
                                                                                 .Build();
            // ACT
            testObjects.ViewModel.ExportPricesCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldCopySelectedTenors_And_Prices_And_Headers_To_ScratchPadClipboard_On_ExportPricesAndHeadersCommand()
        {
            var curveLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>();

            var bandHeaderInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithHeader("curve-1").LivePriceHeaderBandInfo();

            var headers = new List<string>{ "curve-1", "curve-2" };

            var exportPriceCells = new List<List<TenorPriceCell>> { new() { Defaults.TenorPriceCell() } };

            var q3 = new QuarterlyTenor(2023, 3);
            var oct = new MonthlyTenor(2023, 10);
            var nov = new MonthlyTenor(2023, 11);

            var tenorPriceRow1 = new TenorPriceRowViewModel(new TenorEnvelope(q3));
            var tenorPriceRow2 = new TenorPriceRowViewModel(new TenorEnvelope(oct));
            var tenorPriceRow3 = new TenorPriceRowViewModel(new TenorEnvelope(nov));

            tenorPriceRow1.Tenor.IsSelected = true;
            tenorPriceRow2.Tenor.IsSelected = true;

            var tenorPriceRows = new[] { tenorPriceRow1, tenorPriceRow2, tenorPriceRow3 };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([bandHeaderInfo])
                                                                                 .WithPriceCurveLookup(curveLookup)
                                                                                 .WithDataSourceItems(tenorPriceRows)
                                                                                 .WithExportPriceCells(exportPriceCells)
                                                                                 .WithExportHeaders(headers)
                                                                                 .Build();

            var expectedHeaders = new[] { bandHeaderInfo };
            var expectedTenors = new List<ITenor> { oct };

            // ACT
            testObjects.ViewModel.ExportPricesAndHeadersCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ExportPriceCellsService)
                .Verify(e => e.GetPriceCellsForExport(curveLookup, expectedHeaders));

            Mock.Get(testObjects.ExportPriceCellsService)
                .Verify(e => e.GetHeadersForExport(curveLookup, expectedHeaders));

            Mock.Get(testObjects.ScratchPadClipboard)
                .Verify(c => c.CopyToClipboard(exportPriceCells,
                                               It.Is<IList<ITenor>>(t => t.SequenceEqual(expectedTenors)),
                                               headers));
        }

        [Test]
        public void ShouldShowPopup_On_ExportSelectedPricesAndHeadersCommand_Exception()
        {
            var exportError = new Exception("error");

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithExportPriceCellsException(exportError)
                                                                                 .Build();
            // ACT
            testObjects.ViewModel.ExportPricesAndHeadersCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldCopySelected_Headers_To_ScratchPadClipboard_On_ExportHeadersCommand()
        {
            var curveLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>();

            var bandHeaderInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithHeader("curve-1").LivePriceHeaderBandInfo();

            var headers = new List<string> { "curve-1", "curve-2" };

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithLivePriceHeaderBandInfos([bandHeaderInfo])
                                                                                 .WithPriceCurveLookup(curveLookup)
                                                                                 .WithExportHeaders(headers)
                                                                                 .Build();

            var expectedHeaders = new[] { bandHeaderInfo };

            // ACT
            testObjects.ViewModel.ExportHeadersCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ExportPriceCellsService)
                .Verify(e => e.GetHeadersForExport(curveLookup, expectedHeaders));

            Mock.Get(testObjects.ScratchPadClipboard)
                .Verify(c => c.CopyToClipboard(It.Is<IList<List<TenorPriceCell>>>(p => p.Count == 0),
                                               It.Is<IList<ITenor>>(t => t.Count == 0),
                                               headers));
        }

        [Test]
        public void ShouldShowPopup_On_ExportHeadersCommand_Exception()
        {
            var exportError = new Exception("error");

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .WithExportHeadersException(exportError)
                                                                                 .Build();
            // ACT
            testObjects.ViewModel.ExportHeadersCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        #endregion

        #region Dispose

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.PriceGridToolBarController).Verify(c => c.Dispose());
            Mock.Get(testObjects.PriceBandVisibleIndexService).Verify(s => s.Dispose());
            Mock.Get(testObjects.LivePriceGridUpdateService).Verify(s => s.Dispose());
            Mock.Get(testObjects.PriceGridService).Verify(s => s.Dispose());
            Mock.Get(testObjects.PriceColumnWidthService).Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            Mock.Get(testObjects.PriceBandVisibleIndexService).Reset();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.PriceBandVisibleIndexService)
                .Verify(s => s.Dispose(), Times.Never);
        }

        [Test]
        public void ShouldIgnoreFilterUpdates_When_Disposed()
        {
            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.PriceGridLoad.OnNext(new PriceGridLoadArgs([], PriceGridLoadReason.FilterLoaded));

            // ASSERT
            Mock.Get(testObjects.PriceGridService)
                .Verify(rs => rs.SchedulePriceGridRefresh(It.IsAny<IList<UserMarket>>(),
                                                          It.IsAny<PriceGridViewModel>(),
                                                          It.IsAny<List<TenorPriceRowViewModel>>(),
                                                          It.IsAny<bool>(),
                                                          It.IsAny<TimeSpan>()),
                        Times.Never);
        }

        [Test]
        public void ShouldIgnorePriceGridInitialized_When_Disposed()
        {
            var tenorPriceRowEnvelopes = new List<TenorPriceRowEnvelope>
                                         {
                                             new(new TenorPriceRowViewModel(new TenorEnvelope(new MonthlyTenor(2019, 1))), RowRefreshStatus.Add)
                                         };

            var priceLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>();

            var testObjects = new PriceGridViewModelControllerTestObjectBuilder().WithInitializePage(1)
                                                                                 .Build();

            testObjects.PriceGridLoad.OnNext(new PriceGridLoadArgs([], PriceGridLoadReason.FilterLoaded));

            testObjects.ViewModel.IsBusy = true;

            testObjects.Controller.Dispose();

            // ACT
            testObjects.PriceGridRefresh.OnNext(new PriceGridInitializedArgs(tenorPriceRowEnvelopes,
                                                                             new List<IBandHeaderInfo>(),
                                                                             priceLookup,
                                                                             false));

            // ASSERT
            Assert.IsNull(testObjects.ViewModel.BandHeaderInfos);
            Assert.IsNull(testObjects.ViewModel.SummaryItems);
            Assert.IsNull(testObjects.ViewModel.TenorPriceRows);

            Mock.Get(testObjects.LivePriceGridUpdateService)
                .Verify(u => u.RefreshPriceMonitors(It.IsAny<IEnumerable<LivePriceBandInfo>>()), Times.Never);

            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
        }

        #endregion
    }
}
