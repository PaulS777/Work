﻿using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.Controllers.PriceCell;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.PriceCell
{
    internal interface IPriceCellViewModelControllerTestObjects
    {
        ILivePriceViewModelController LivePriceViewModelController { get; }
        IChangeOnCloseViewModelController ChangeOnCloseViewModelController { get; }
        ITenorPremiumViewModelController TenorPremiumViewModelController { get; }
        PriceCellViewModelController Controller { get; }
    }

    [TestFixture]
    public class PriceCellViewModelControllerTests
    {
        private class PriceCellViewModelControllerTestObjectBuilder
        {
            public IPriceCellViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IPriceCellViewModelControllerTestObjects>();

                var livePriceViewModel = new LivePriceViewModel();
                var livePriceController = new Mock<ILivePriceViewModelController>();

                livePriceController.SetupGet(c => c.ViewModel)
                                   .Returns(livePriceViewModel);

                testObjects.SetupGet(o => o.LivePriceViewModelController)
                           .Returns(livePriceController.Object);


				var changeOnCloseViewModel = new ChangeOnCloseViewModel();
				var changeOnCloseController = new Mock<IChangeOnCloseViewModelController>();

				changeOnCloseController.SetupGet(c => c.ViewModel)
									   .Returns(changeOnCloseViewModel);

				testObjects.SetupGet(o => o.ChangeOnCloseViewModelController)
						   .Returns(changeOnCloseController.Object);

                var tenorPremiumViewModel = new TenorPremiumViewModel();
                var tenorPremiumController = new Mock<ITenorPremiumViewModelController>();

                tenorPremiumController.SetupGet(c => c.ViewModel)
                                   .Returns(tenorPremiumViewModel);

                testObjects.SetupGet(o => o.TenorPremiumViewModelController)
                           .Returns(tenorPremiumController.Object);

                var controller = new PriceCellViewModelController(livePriceController.Object, 
                                                                  changeOnCloseController.Object,
                                                                  tenorPremiumController.Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                return testObjects.Object;
            }
        }


        [Test]
        public void ShouldInitializeViewModels()
        {
            var testObjects = new PriceCellViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.IsNotNull(testObjects.Controller.ViewModel.LivePrice);
            Assert.IsNotNull(testObjects.Controller.ViewModel.ChangeOnClose);
            Assert.IsNotNull(testObjects.Controller.ViewModel.TenorPremium);
        }

        [Test]
        public void ShouldDisposeControllers_OnDispose()
        {
            var testObjects = new PriceCellViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ACT
            Mock.Get(testObjects.TenorPremiumViewModelController)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldDispose_From_ViewModelDispose()
        {
            var testObjects = new PriceCellViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.Dispose();

            // ACT
            Mock.Get(testObjects.TenorPremiumViewModelController)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new PriceCellViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ACT
            Mock.Get(testObjects.TenorPremiumViewModelController)
                .Verify(c => c.Dispose(), Times.Once);
        }
    }
}
