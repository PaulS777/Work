﻿using Dsp.Gui.PriceGrid.Controllers.PriceCell;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.PriceCell
{
    [TestFixture]
    public class ManualOverrideViewModelControllerTests
    {
        [Test]
        public void ShouldUpdateMidPrice_From_MidPriceServer_When_UseChatPrice()
        {
            var controller = new ManualOverrideViewModelController();

            var viewModel = controller.ViewModel;

            viewModel.Model().MidPriceServer = 1.0M;

            viewModel.MidPrice = 2.0M;
            viewModel.Model().SubscribeUpdates = true;

            // ACT
            viewModel.UseChatPrice = true;

            // ASSERT
            Assert.That(viewModel.MidPrice, Is.EqualTo(1.0));
        }

        [Test]
        public void ShouldDisableChatPrice_When_IsBusy()
        {
            var controller = new ManualOverrideViewModelController();

            var viewModel = controller.ViewModel;

            viewModel.CanUseChatPrice = true;

            // ACT
            viewModel.IsBusy = true;

            // ASSERT
            Assert.That(viewModel.UseChatPriceEnabled, Is.False);
        }

        [Test]
        public void ShouldDisableChatPrice_When_CanUseChatPriceFalse()
        {
            var controller = new ManualOverrideViewModelController();

            var viewModel = controller.ViewModel;

            viewModel.IsBusy = false;

            // ACT
            viewModel.CanUseChatPrice = false;

            // ASSERT
            Assert.That(viewModel.UseChatPriceEnabled, Is.False);
        }

        [Test]
        public void ShouldEnableChatPrice_When_CanUseChatPriceTrue()
        {
            var controller = new ManualOverrideViewModelController();

            var viewModel = controller.ViewModel;

            viewModel.IsBusy = false;

            // ACT
            viewModel.CanUseChatPrice = true;

            // ASSERT
            Assert.That(viewModel.UseChatPriceEnabled, Is.True);
        }

        [Test]
        public void ShouldNotUpdateMidPrice_When_Disposed()
        {
            var controller = new ManualOverrideViewModelController();

            var viewModel = controller.ViewModel;

            viewModel.Model().MidPriceServer = 1.0M;

            viewModel.MidPrice = 2.0M;
            viewModel.Model().SubscribeUpdates = true;

            controller.Dispose();

            // ACT
            viewModel.UseChatPrice = true;

            // ASSERT
            Assert.That(viewModel.MidPrice, Is.EqualTo(2.0));
        }


        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var controller = new ManualOverrideViewModelController();

            var viewModel = controller.ViewModel;

            viewModel.Model().MidPriceServer = 1.0M;

            viewModel.MidPrice = 2.0M;
            viewModel.Model().SubscribeUpdates = true;

            controller.Dispose();

            // ACT
            controller.Dispose();
            viewModel.UseChatPrice = true;

            // ASSERT
            Assert.That(viewModel.MidPrice, Is.EqualTo(2.0));
        }
    }
}
