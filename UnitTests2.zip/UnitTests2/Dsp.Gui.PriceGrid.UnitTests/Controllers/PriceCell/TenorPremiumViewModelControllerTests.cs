﻿using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.Controllers.PriceCell;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.PriceCell
{
    internal interface ITenorPremiumViewModelControllerTestObjects
    {
        ITenorPremiumPresentationService TenorPremiumPresentationService { get; }
        ITenorPremiumChangedService TenorPremiumChangedService { get; }
        ITenorMarginsValidationService TenorMarginsValidationService { get; }
        TenorPremiumViewModelController Controller { get; }
        TenorPremiumViewModel ViewModel { get; }
    }

    [TestFixture]
    public class TenorPremiumViewModelControllerTests
    {
        private class TenorPremiumViewModelControllerTestObjectBuilder
        {
            private bool _canApplyMargins;

            public TenorPremiumViewModelControllerTestObjectBuilder WithCanApplyMargins(bool value)
            {
                _canApplyMargins = value;
                return this;
            }

            public ITenorPremiumViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<ITenorPremiumViewModelControllerTestObjects>();

                var tenorPremiumPresentationService = new Mock<ITenorPremiumPresentationService>();

                testObjects.SetupGet(o => o.TenorPremiumPresentationService)
                           .Returns(tenorPremiumPresentationService.Object);

                var tenorPremiumChanged = new Mock<ITenorPremiumChangedService>();

                testObjects.SetupGet(o => o.TenorPremiumChangedService)
                           .Returns(tenorPremiumChanged.Object);

                var tenorMarginsValidation = new Mock<ITenorMarginsValidationService>();

                testObjects.SetupGet(o => o.TenorMarginsValidationService)
                           .Returns(tenorMarginsValidation.Object);

                var controller = new TenorPremiumViewModelController(tenorPremiumPresentationService.Object,
                                                                     tenorPremiumChanged.Object,
                                                                     tenorMarginsValidation.Object);

                controller.ViewModel.Model().CanApplyMargins = _canApplyMargins;

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldAttachToPresentationService_When_ShowMarginsFirstTime()
        {
            var testObjects 
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            // ACT
            testObjects.ViewModel.ShowMargins = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(tp => tp.Attach(testObjects.ViewModel));
        }

        [Test]
        public void ShouldNotAttachToPresentationService_When_ShowMarginsFirstTime_With_CanApplyMarginsFalse()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(false)
                                                                        .Build();

            // ACT
            testObjects.ViewModel.ShowMargins = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(tp => tp.Attach(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldAttachToChangedAndValidationServices_When_ShowMarginsFirstTime()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            // ACT
            testObjects.ViewModel.ShowMargins = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Attach(testObjects.ViewModel));

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(v => v.AttachPremium(testObjects.ViewModel));
        }

        [Test]
        public void ShouldAttachToChangedAndValidationServices_When_UserIsPublisherFirstTime()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            // ACT
            testObjects.ViewModel.IsCurrentUserPublisher = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Attach(testObjects.ViewModel));

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(v => v.AttachPremium(testObjects.ViewModel));
        }

        [Test]
        public void ShouldNotAttachToChangedAndValidationServices_When_UserIsPublisherFirstTime_With_CanApplyMarginsFalse()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(false)
                                                                        .Build();

            // ACT
            testObjects.ViewModel.IsCurrentUserPublisher = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Attach(testObjects.ViewModel), Times.Never);

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(v => v.AttachPremium(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldNotAttachToChangedAndValidationServices_When_UserIsPublisher_After_ShowMargins()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            testObjects.ViewModel.ShowMargins = true;

            // ACT
            testObjects.ViewModel.IsCurrentUserPublisher = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Attach(testObjects.ViewModel), Times.Once);

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(v => v.AttachPremium(testObjects.ViewModel), Times.Once);
        }

        [Test]
        public void ShouldNotAttachToChangedAndValidationServices_When_ShowMargins_After_UserIsPublisher()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            testObjects.ViewModel.IsCurrentUserPublisher = true;

            // ACT
            testObjects.ViewModel.ShowMargins = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Attach(testObjects.ViewModel), Times.Once);

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(v => v.AttachPremium(testObjects.ViewModel), Times.Once);
        }

        [Test]
        public void ShouldNotAttachToPresentationService_When_AlreadyAttached()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            testObjects.ViewModel.ShowMargins = true;
            testObjects.ViewModel.ShowMargins = false;

            // ACT
            testObjects.ViewModel.ShowMargins = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(tp => tp.Attach(testObjects.ViewModel), Times.Once);
        }

        [Test]
        public void ShouldNotAttachToServices_When_Disposed()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.ShowMargins = true;

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(tp => tp.Attach(testObjects.ViewModel), Times.Never);

            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Attach(testObjects.ViewModel), Times.Never);

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(v => v.AttachPremium(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldDisposeOfServices_When_Disposing()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            testObjects.ViewModel.ShowMargins = true;

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Dispose());

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(v => v.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects
                = new TenorPremiumViewModelControllerTestObjectBuilder().WithCanApplyMargins(true)
                                                                        .Build();

            testObjects.ViewModel.ShowMargins = true;

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.TenorPremiumPresentationService)
                .Verify(c => c.Dispose(), Times.Once);

            Mock.Get(testObjects.TenorPremiumChangedService)
                .Verify(p => p.Dispose(), Times.Once);

            Mock.Get(testObjects.TenorMarginsValidationService)
                .Verify(v => v.Dispose(), Times.Once);
        }
    }
}
