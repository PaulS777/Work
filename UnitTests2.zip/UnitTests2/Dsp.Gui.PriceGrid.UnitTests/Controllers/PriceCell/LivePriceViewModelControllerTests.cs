﻿using Dsp.Gui.PriceGrid.Controllers.PriceCell;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Controllers.PriceCell
{
    [TestFixture]
    public class LivePriceViewModelControllerTests
    {
        [Test]
        public void ShouldGetViewModel()
        {
            var controller = new LivePriceViewModelController();

            // ACT
            var viewModel = controller.ViewModel;

            // ASSERT
            Assert.IsNotNull(viewModel);
        }
    }
}
