﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Common;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Moq;

namespace Dsp.Gui.PriceGrid.UnitTests
{
    internal class LivePriceHeaderBandInfoTestObjectBuilder
    {
        private IDisposable _controller;
        private int _pageNumber;
        private LinkedCurve _linkedCurve;
        private string _header;
        private bool _isVisible;
        private ValidityIndicator _validityIndicator;
        private ISubject<PriceCurve> _priceCurve;
        private List<PriceCellViewModel> _priceCells;
        private CurveGroup _curveGroup;
        private int _adjustedVisibleIndex;
        private bool _subscribeUpdates;
        private bool _showPremiums;
        private bool _premiumsHasErrors;
        private bool _canUndoPremiums;
        private bool _currentUserIsPublisher;
        private PriceGridViewModel _priceGrid;
        private PriceCurveSetting _priceCurveSetting;
        private bool _canShowPremiums;
        private bool _showSummary;

        public LivePriceHeaderBandInfoTestObjectBuilder WithPriceCurveSetting(PriceCurveSetting value)
        {
            _priceCurveSetting = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithController(IDisposable value)
        {
            _controller = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithPageNumber(int value)
        {
            _pageNumber = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithLinkedCurve(LinkedCurve value)
        {
            _linkedCurve = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithHeader(string value)
        {
            _header = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithIsVisible(bool value)
        {
            _isVisible = value;
            return this;
        }
        public LivePriceHeaderBandInfoTestObjectBuilder WithValidityIndicator(ValidityIndicator value)
        {
            _validityIndicator = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithPriceCurve(ISubject<PriceCurve> value)
        {
            _priceCurve = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithPriceCells(List<PriceCellViewModel> values)
        {
            _priceCells = values;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithCurveGroup(CurveGroup value)
        {
            _curveGroup = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithAdjustedVisibleIndex(int value)
        {
            _adjustedVisibleIndex = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithSubscribeUpdates(bool value)
        {
            _subscribeUpdates = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithShowPremiums(bool value)
        {
            _showPremiums = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithPremiumsHasErrors(bool value)
        {
            _premiumsHasErrors = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithCanUndoPremiums(bool value)
        {
            _canUndoPremiums = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithCurrentUserIsPublisher(bool value)
        {
            _currentUserIsPublisher = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithPriceGrid(PriceGridViewModel value)
        {
            _priceGrid = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithCanShowPremiums(bool value)
        {
            _canShowPremiums = value;
            return this;
        }

        public LivePriceHeaderBandInfoTestObjectBuilder WithShowSummary(bool value)
        {
            _showSummary = value;
            return this;
        }

        public LivePriceHeaderBandInfo LivePriceHeaderBandInfo()
        {
            var controller = _controller ?? Mock.Of<IDisposable>();

            var details = new BandInfoDetails(_pageNumber, _linkedCurve, _priceGrid);

            if (_priceCells != null)
            {
                details.SetPriceCells(_priceCells);
            }

            var bandInfo = new LivePriceHeaderBandInfo(controller,
                                                       BandHeaderType.LivePriceHeader,
                                                       new LivePriceBandInfo(Mock.Of<IDisposable>())
                                                       {
                                                           LivePriceColumnInfo = new ColumnInfo(ColumnType.LivePrice, Mock.Of<IDisposable>())
                                                                                 {
                                                                                     CurveGroup = _curveGroup,
                                                                                     ShowSummary = _showSummary
                                                                                 }
                                                       },
                                                       new ChangeOnCloseBandInfo(),
                                                       new PremiumsBandInfo(Mock.Of<IDisposable>()))
                           {
                               Header = _header,
                               IsVisible = _isVisible,
                           };

      

            bandInfo.SetDetails(details);
            bandInfo.LivePriceBandInfo.SetDetails(details);
            bandInfo.PremiumsBandInfo.SetDetails(details);

            if (_priceCurve != null)
            {
                bandInfo.LivePriceBandInfo.SetPriceCurve(_priceCurve);
                bandInfo.PremiumsBandInfo.SetPriceCurve(_priceCurve);
            }

            bandInfo.LivePriceBandInfo.SetDetails(details);
            bandInfo.LivePriceBandInfo.SetPriceCurveSetting(_priceCurveSetting);

            bandInfo.LivePriceBandInfo.LivePriceColumnInfo.SetDetails(details);

            bandInfo.PremiumsBandInfo.BidMarginColumnInfo = new ColumnInfo(ColumnType.Margin)
            {
                CurveGroup = _curveGroup
            };

            bandInfo.PremiumsBandInfo.BidMarginColumnInfo.SetDetails(details);

            bandInfo.PremiumsBandInfo.AskMarginColumnInfo = new ColumnInfo(ColumnType.Margin)
            {
                CurveGroup = _curveGroup
            };

            bandInfo.CanShowPremiums = _canShowPremiums;

            bandInfo.PremiumsBandInfo.AskMarginColumnInfo.SetDetails(details);
            bandInfo.PremiumsBandInfo.HasErrors = _premiumsHasErrors;
            bandInfo.PremiumsBandInfo.CanUndoPremiums = _canUndoPremiums;
            bandInfo.PremiumsBandInfo.ShowPremiums = _showPremiums;

            bandInfo.LivePriceBandInfo.RagStatus = _validityIndicator;
            bandInfo.AdjustedVisibleIndex = _adjustedVisibleIndex;
            bandInfo.ShowPremiums = _showPremiums;
            bandInfo.CurrentUserIsPublisher = _currentUserIsPublisher;
            bandInfo.SubscribeUpdates = _subscribeUpdates;

            return bandInfo;
        }

        public LivePriceBandInfo LivePriceBandInfo() => LivePriceHeaderBandInfo().LivePriceBandInfo;
        public PremiumsBandInfo PremiumsBandInfo() => LivePriceHeaderBandInfo().PremiumsBandInfo;
    }
}
