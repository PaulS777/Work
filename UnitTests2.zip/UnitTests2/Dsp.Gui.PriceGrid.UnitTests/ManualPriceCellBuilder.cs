﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Markets.Common.Common;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid.Model;
using Moq;

namespace Dsp.Gui.PriceGrid.UnitTests
{
    public class ManualPriceCellBuilder
    {
        private IDisposable _controller = Mock.Of<IDisposable>();
        private LinkedCurve _linkedCurve;
        private RowTenorType _rowTenorType = RowTenorType.Monthly;
        private int _tenorValue;
        private int _precision;
        private decimal? _midPrice;
        private decimal? _midPriceServer;
        private decimal? _midPriceManual;
        private bool _hasManualChange;
        private bool _curveOverridesChanged;
        private bool _isSelected;
        private ITenor _tenor = new MonthlyTenor(2000, 1);
        private bool _canUseChatPrice;
        private string _error;
        private bool _useChatPrice;
        private bool _subscribeUpdates;
        private bool _isInEdit;
        private bool _isValid;

        public ManualPriceCellBuilder WithController(IDisposable controller)
        {
            _controller = controller;
            return this;
        }

        public ManualPriceCellBuilder WithLinkedCurve(LinkedCurve id)
        {
            _linkedCurve = id;
            return this;
        }

        public ManualPriceCellBuilder WithRowTenorType(RowTenorType rowTenorType)
        {
            _rowTenorType = rowTenorType;
            return this;
        }

        public ManualPriceCellBuilder WithTenorValue(int tenorValue)
        {
            _tenorValue = tenorValue;
            return this;
        }

        public ManualPriceCellBuilder WithMidPriceServer(decimal? midPriceServer)
        {
            _midPriceServer = midPriceServer;
            return this;
        }

        public ManualPriceCellBuilder WithMidPriceManual(decimal? midPriceManual)
        {
            _midPriceManual = midPriceManual;
            return this;
        }

        public ManualPriceCellBuilder WithCurveOverridesChanged(bool value)
        {
            _curveOverridesChanged = value;
            return this;
        }

        public ManualPriceCellBuilder WithHasManualChange(bool value)
        {
            _hasManualChange = value;
            return this;
        }

        public ManualPriceCellBuilder WithMidPrice(decimal? midPrice)
        {
            _midPrice = midPrice;
            return this;
        }

        public ManualPriceCellBuilder WithPrecision(int precision)
        {
            _precision = precision;
            return this;
        }

        public ManualPriceCellBuilder WithIsSelected(bool isSelected)
        {
            _isSelected = isSelected;
            return this;
        }

        public ManualPriceCellBuilder WithCanUseChatPrice(bool canUseChatPrice)
        {
            _canUseChatPrice = canUseChatPrice;
            return this;
        }

        public ManualPriceCellBuilder WithTenor(ITenor value)
        {
            _tenorValue = value.GetTenorValue();
            _tenor = value;
            return this;
        }

        public ManualPriceCellBuilder WithError(string value)
        {
            _error = value;
            return this;
        }

        public ManualPriceCellBuilder WithIsValid(bool value)
        {
            _isValid = value;
            return this;
        }


        public ManualPriceCellBuilder WithUseChatPrice(bool value)
        {
            _useChatPrice = value;
            return this;
        }

        public ManualPriceCellBuilder WithSubscribeUpdates(bool value)
        {
            _subscribeUpdates = value;
            return this;
        }

        public ManualPriceCellBuilder WithIsInEdit(bool value)
        {
            _isInEdit = value;
            return this;
        }

        public PriceCellViewModel PriceCell()
        {
            var priceCellInfo = new PriceCellInfo(_linkedCurve,
                                                  ColumnType.ManualPrice,
                                                  _rowTenorType,
                                                  _tenorValue,
                                                  _tenor);

            var manualOverride = new ManualOverrideViewModel(_controller);

            var priceCellViewModel = new PriceCellViewModel(manualOverride);

            priceCellViewModel.SetPriceCellInfo(priceCellInfo);

            priceCellViewModel.ManualOverride.Model().MidPriceManual = _midPriceManual;
            priceCellViewModel.ManualOverride.Model().MidPriceServer = _midPriceServer;
            priceCellViewModel.ManualOverride.HasManualChange = _hasManualChange;
            priceCellViewModel.ManualOverride.Model().SubscribeUpdates = _subscribeUpdates;
            priceCellViewModel.ManualOverride.Model().IsInEdit = _isInEdit;

            priceCellViewModel.ManualOverride.MidPrice = _midPrice;
            priceCellViewModel.ManualOverride.IsSelected = _isSelected;
            priceCellViewModel.ManualOverride.Precision = _precision;
            priceCellViewModel.ManualOverride.Error = _error;
            priceCellViewModel.ManualOverride.IsValid = _isValid;
            priceCellViewModel.ManualOverride.UseChatPrice = _useChatPrice;
            priceCellViewModel.ManualOverride.CanUseChatPrice = _canUseChatPrice;
            priceCellViewModel.ManualOverride.CurveOverridesChanged = _curveOverridesChanged;

            return priceCellViewModel;
        }
    }
}
