﻿using System.Collections.Generic;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.Services.ChatPrice;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.ChatPrice
{
    [TestFixture]
    public class ChatPriceTenorDependencyServiceTests
    {
        [Test]
        public void ShouldUpdateMonthlyChatTenors_From_QuarterlyChatTenor_WhenUseChatPrice()
        {
            var priceCell1 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                         .WithUseChatPrice(false)
                                                         .PriceCell();

            var priceCell2 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                         .WithUseChatPrice(false)
                                                         .WithCanUseChatPrice(true)
                                                         .PriceCell();

            var priceCell3 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                         .WithUseChatPrice(false)
                                                         .WithCanUseChatPrice(true)
                                                         .PriceCell();

            var priceCell4 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                         .WithUseChatPrice(false)
                                                         .WithCanUseChatPrice(true)
                                                         .PriceCell();

            var priceCell5 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                         .PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell1, priceCell2, priceCell3, priceCell4, priceCell5 };

            var service = new ChatPriceTenorDependencyService();

            // ACT
            priceCell1.ManualOverride.UseChatPrice = true;

            service.UpdateDependencies(priceCells, priceCell1);

            // ASSERT
            Assert.IsTrue(priceCell2.ManualOverride.UseChatPrice);
            Assert.IsFalse(priceCell2.ManualOverride.CanUseChatPrice);

            Assert.IsTrue(priceCell3.ManualOverride.UseChatPrice);
            Assert.IsFalse(priceCell3.ManualOverride.CanUseChatPrice);

            Assert.IsTrue(priceCell4.ManualOverride.UseChatPrice);
            Assert.IsFalse(priceCell4.ManualOverride.CanUseChatPrice);

            Assert.IsFalse(priceCell5.ManualOverride.UseChatPrice);
        }

        [Test]
        public void ShouldUpdateMonthlyChatTenors_From_QuarterlyChatTenor_WhenUseChatPriceFalse()
        {
            var priceCell1 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                         .WithUseChatPrice(true)
                                                         .PriceCell();

            var priceCell2 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                         .WithUseChatPrice(true)
                                                         .WithCanUseChatPrice(false)
                                                         .PriceCell();

            var priceCell3 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                         .WithUseChatPrice(true)
                                                         .WithCanUseChatPrice(false)
                                                         .PriceCell();

            var priceCell4 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                         .WithUseChatPrice(true)
                                                         .WithCanUseChatPrice(false)
                                                         .PriceCell();

            var priceCell5 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                         .WithUseChatPrice(true)
                                                         .PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell1, priceCell2, priceCell3, priceCell4, priceCell5 };

            var service = new ChatPriceTenorDependencyService();

            // ACT
            priceCell1.ManualOverride.UseChatPrice = false;

            service.UpdateDependencies(priceCells, priceCell1);

            // ASSERT
            Assert.IsFalse(priceCell2.ManualOverride.UseChatPrice);
            Assert.IsTrue(priceCell2.ManualOverride.CanUseChatPrice);

            Assert.IsFalse(priceCell3.ManualOverride.UseChatPrice);
            Assert.IsTrue(priceCell3.ManualOverride.CanUseChatPrice);

            Assert.IsFalse(priceCell4.ManualOverride.UseChatPrice);
            Assert.IsTrue(priceCell4.ManualOverride.CanUseChatPrice);

            Assert.IsTrue(priceCell5.ManualOverride.UseChatPrice);
        }

        [Test]
        public void ShouldUpdateQuarterlyAndMonthlyChatTenors_From_YearlyChatTenor_WhenUseChatPrice()
        {
            var priceCell1 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Yearly)
                                                         .WithUseChatPrice(false)
                                                         .PriceCell();

            var priceCell2 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                         .WithUseChatPrice(false)
                                                         .WithCanUseChatPrice(true)
                                                         .PriceCell();

            var priceCell3 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                         .WithUseChatPrice(false)
                                                         .WithCanUseChatPrice(true)
                                                         .PriceCell();


            var priceCell4 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Quarterly)
                                                         .WithUseChatPrice(false)
                                                         .WithCanUseChatPrice(true)
                                                         .PriceCell();

            var priceCell5 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly)
                                                         .WithUseChatPrice(false)
                                                         .WithCanUseChatPrice(true)
                                                         .PriceCell();

            var priceCell6 = new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Yearly)
                                                         .WithUseChatPrice(false)
                                                         .WithCanUseChatPrice(true)
                                                         .PriceCell();

            var priceCells = new List<PriceCellViewModel> { priceCell1, priceCell2, priceCell3, priceCell4, priceCell5 };

            var service = new ChatPriceTenorDependencyService();

            // ACT
            priceCell1.ManualOverride.UseChatPrice = true;

            service.UpdateDependencies(priceCells, priceCell1);

            // ASSERT
            Assert.IsTrue(priceCell2.ManualOverride.UseChatPrice);
            Assert.IsFalse(priceCell2.ManualOverride.CanUseChatPrice);

            Assert.IsTrue(priceCell3.ManualOverride.UseChatPrice);
            Assert.IsFalse(priceCell3.ManualOverride.CanUseChatPrice);

            Assert.IsTrue(priceCell4.ManualOverride.UseChatPrice);
            Assert.IsFalse(priceCell4.ManualOverride.CanUseChatPrice);

            Assert.IsTrue(priceCell5.ManualOverride.UseChatPrice);
            Assert.IsFalse(priceCell5.ManualOverride.CanUseChatPrice);

            Assert.IsFalse(priceCell6.ManualOverride.UseChatPrice);
        }
    }
}
