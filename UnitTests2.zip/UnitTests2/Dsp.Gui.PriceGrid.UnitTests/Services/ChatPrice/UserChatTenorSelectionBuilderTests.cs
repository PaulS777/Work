﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.Services.ChatPrice;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.ChatPrice
{
    [TestFixture]
    public class UserChatTenorSelectionBuilderTests
    {
        [Test] 
        public void ShouldApplyChatTenorsToUser()
        {
            var curveId = 201;

            var curveGroups = new [] {new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)};
            var curveRegions = new[] {new AuthorisationCurveRegion(CurveRegion.Europe, true, true)};
            var fxCurves = new[] {new AuthorisationFxCurve(99, true, true)};

            var tenor1 = new MonthlyTenor(2020, 1);
            var tenor2 = new MonthlyTenor(2020, 2);
            var tenor3 = new MonthlyTenor(2020, 3);

            var userChatTenorsSelections = new []
            {
                new UserChatTenorSelection(10, curveId, tenor1),
                new UserChatTenorSelection(10, 202, tenor1)
            };

            var user = new UserBuilder().WithId(10)
                                        .WithUserName("user-name")
                                        .WithName("name")
                                        .WithIsAdmin(true)
                                        .WithIsEnabled(true)
                                        .WithAuthorizationCurveGroups(curveGroups)
                                        .WithAuthorizationCurveRegions(curveRegions)
                                        .WithAuthorizationFxCurve(fxCurves)
                                        .WithUserChatTenorSelections(userChatTenorsSelections)
                                        .User();

            var priceCells = new List<PriceCellViewModel>
            {
                new ManualPriceCellBuilder().WithTenor(tenor1).WithUseChatPrice(false).PriceCell(),
                new ManualPriceCellBuilder().WithTenor(tenor2).WithUseChatPrice(true).PriceCell(),
                new ManualPriceCellBuilder().WithTenor(tenor3).WithUseChatPrice(true).PriceCell()
            };

            var builder = new UserChatTenorSelectionBuilder();

            // ACT
            var result = builder.GetUserChatTenorSelection(user, curveId, priceCells);

            // ASSERT
            Assert.That(result.Id, Is.EqualTo(10));
            Assert.That(result.UserName, Is.EqualTo("user-name"));
            Assert.That(result.DisplayName, Is.EqualTo("name"));
            Assert.That(result.IsAdmin, Is.True);
            Assert.That(result.IsEnabled, Is.True);
            Assert.That(result.CurveGroupPermissions.Count, Is.EqualTo(1));
            Assert.That(result.CurveRegionPermissions.Count, Is.EqualTo(1));
            Assert.That(result.FxCurvePermissions.Count, Is.EqualTo(1));

            // ASSERT - Chat Tenor Selections
            Assert.That(result.ChatTenorSelections.Count, Is.EqualTo(3));
            Assert.That(result.ChatTenorSelections[0].PriceCurveDefinitionId, Is.EqualTo(202));
            Assert.That(result.ChatTenorSelections[1].PriceCurveDefinitionId, Is.EqualTo(curveId));
            Assert.That(result.ChatTenorSelections[2].PriceCurveDefinitionId, Is.EqualTo(curveId));
        }
    }
}
