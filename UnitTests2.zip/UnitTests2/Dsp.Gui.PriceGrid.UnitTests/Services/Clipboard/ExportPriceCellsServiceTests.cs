﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.Services.Clipboard;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.Clipboard
{
    [TestFixture]
    public class ExportPriceCellsServiceTests
    {
        [Test]
        public void ShouldOrderPriceCellColumns_By_AdjustedIndex()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve3 = new LinkedCurve(103, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve4 = new LinkedCurve(104, PriceCurveDefinitionType.PriceCurve);

            var livePriceHeader1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithAdjustedVisibleIndex(2).LivePriceHeaderBandInfo();
            var livePriceHeader2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithAdjustedVisibleIndex(3).LivePriceHeaderBandInfo();
            var livePriceHeader3 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve3).WithAdjustedVisibleIndex(4).LivePriceHeaderBandInfo();
            var livePriceHeader4 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve4).WithAdjustedVisibleIndex(1).LivePriceHeaderBandInfo();

            var livePriceHeaders = new[]
                                   {
                                       livePriceHeader1, livePriceHeader2, livePriceHeader3, livePriceHeader4
                                   };

            var priceCell1 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve1).WithTenorValue(1).WithIsSelected(true).PriceCell();
            var priceCell2 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve1).WithTenorValue(2).WithIsSelected(true).PriceCell();
            var priceCell3 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve1).WithTenorValue(3).PriceCell();

            var priceCell4 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve2).WithTenorValue(1).WithIsSelected(true).PriceCell();
            var priceCell5 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve2).WithTenorValue(2).WithIsSelected(true).PriceCell();
            var priceCell6 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve2).WithTenorValue(3).PriceCell();

            var priceCell7 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve3).WithTenorValue(1).PriceCell();
            var priceCell8 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve3).WithTenorValue(2).PriceCell();
            var priceCell9 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve3).WithTenorValue(3).PriceCell();

            var priceCell10 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve4).WithTenorValue(1).WithIsSelected(true).PriceCell();
            var priceCell11 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve4).WithTenorValue(2).WithIsSelected(true).PriceCell();
            var priceCell12 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve4).WithTenorValue(3).PriceCell();

            var lookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
                         {
                             { linkedCurve1, [priceCell1, priceCell2, priceCell3] },
                             { linkedCurve2, [priceCell4, priceCell5, priceCell6] },
                             { linkedCurve3, [priceCell7, priceCell8, priceCell9] },
                             { linkedCurve4, [priceCell10, priceCell11, priceCell12] }
                         };

            var service = new ExportPriceCellsService();

            var tenorPriceCell1 = new TenorPriceCell(linkedCurve1.Id, 1, priceCell1.LivePrice.MidPrice);
            var tenorPriceCell2 = new TenorPriceCell(linkedCurve1.Id, 2, priceCell2.LivePrice.MidPrice);

            var tenorPriceCell4 = new TenorPriceCell(linkedCurve2.Id, 1, priceCell4.LivePrice.MidPrice);
            var tenorPriceCell5 = new TenorPriceCell(linkedCurve2.Id, 2, priceCell5.LivePrice.MidPrice);

            var tenorPriceCell10 = new TenorPriceCell(linkedCurve4.Id, 1, priceCell10.LivePrice.MidPrice);
            var tenorPriceCell11 = new TenorPriceCell(linkedCurve4.Id, 2, priceCell11.LivePrice.MidPrice);

            var expected = new []
                           {
                               [tenorPriceCell10, tenorPriceCell11],
                               [tenorPriceCell1, tenorPriceCell2],
                               new List<TenorPriceCell> { tenorPriceCell4, tenorPriceCell5 }
                           };

            // ACT
            var result = service.GetPriceCellsForExport(lookup, livePriceHeaders);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldFilterLiveMonthlyPrices()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve);

            var livePriceHeader1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithAdjustedVisibleIndex(1).LivePriceHeaderBandInfo();
            var livePriceHeader2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithAdjustedVisibleIndex(2).LivePriceHeaderBandInfo();

            var livePriceHeaders = new[]
                                   {
                                       livePriceHeader1, livePriceHeader2
                                   };

            var priceCell1 = PriceCellBuilderYearly().WithLinkedCurve(linkedCurve1).WithTenorValue(1).WithIsSelected(true).PriceCell();
            var priceCell2 = PriceCellBuilderQuarterly().WithLinkedCurve(linkedCurve1).WithTenorValue(2).WithIsSelected(true).PriceCell();
            var priceCell3 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve1).WithTenorValue(3).WithIsSelected(true).PriceCell();
            var priceCell4 = ManualCellBuilderMonthly().WithLinkedCurve(linkedCurve2).WithTenorValue(3).WithIsSelected(true).PriceCell();

            var lookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
                         {
                             { linkedCurve1, [priceCell1, priceCell2, priceCell3] },
                             { linkedCurve2, [priceCell4] }
                         };

            var service = new ExportPriceCellsService();

            var tenorPriceCell3 = new TenorPriceCell(linkedCurve1.Id, 3, priceCell3.LivePrice.MidPrice);

            var expected = new[]
                           {
                               new List<TenorPriceCell> { tenorPriceCell3 }
                           };

            // ACT
            var result = service.GetPriceCellsForExport(lookup, livePriceHeaders);

            // ASSERT
            Assert.That(result.SequenceEqual(expected, new TenorPriceCellListEqualityComparer()));
        }

        [Test]
        public void ShouldOrderHeaders_By_AdjustedIndex()
        {
            var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve3 = new LinkedCurve(103, PriceCurveDefinitionType.PriceCurve);
            var linkedCurve4 = new LinkedCurve(104, PriceCurveDefinitionType.PriceCurve);

            var livePriceHeader1 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithHeader("curve-1").WithAdjustedVisibleIndex(2).LivePriceHeaderBandInfo();
            var livePriceHeader2 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithHeader("curve-2").WithAdjustedVisibleIndex(3).LivePriceHeaderBandInfo();
            var livePriceHeader3 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve3).WithHeader("curve-3").WithAdjustedVisibleIndex(4).LivePriceHeaderBandInfo();
            var livePriceHeader4 = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve4).WithHeader("curve-4").WithAdjustedVisibleIndex(1).LivePriceHeaderBandInfo();

            var livePriceHeaders = new[]
                                   {
                                       livePriceHeader1, livePriceHeader2, livePriceHeader3, livePriceHeader4
                                   };

            var priceCell1 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve1).WithTenorValue(1).WithIsSelected(true).PriceCell();
            var priceCell2 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve2).WithTenorValue(1).WithIsSelected(true).PriceCell();
            var priceCell3 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve3).WithTenorValue(1).PriceCell();
            var priceCell4 = PriceCellBuilderMonthly().WithLinkedCurve(linkedCurve4).WithTenorValue(1).WithIsSelected(true).PriceCell();

            var lookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
                         {
                             { linkedCurve1, [priceCell1] },
                             { linkedCurve2, [priceCell2] },
                             { linkedCurve3, [priceCell3] },
                             { linkedCurve4, [priceCell4] }
                         };

            var service = new ExportPriceCellsService();

            var expected = new[]
                           {
                               "curve-4", "curve-1", "curve-2"
                           };

            // ACT
            var result = service.GetHeadersForExport(lookup, livePriceHeaders);

            // ASSERT
            Assert.That(result.SequenceEqual(expected));
        }

        private static PriceCellTestObjectBuilder PriceCellBuilderMonthly()
        {
            return new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Monthly);
        }

        private static PriceCellTestObjectBuilder PriceCellBuilderQuarterly()
        {
            return new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Quarterly);
        }

        private static PriceCellTestObjectBuilder PriceCellBuilderYearly()
        {
            return new PriceCellTestObjectBuilder().WithRowTenorType(RowTenorType.Yearly);
        }

        private static ManualPriceCellBuilder ManualCellBuilderMonthly()
        {
            return new ManualPriceCellBuilder().WithRowTenorType(RowTenorType.Monthly);
        }
    }
}
