﻿using System.Collections.Generic;
using Dsp.Gui.PriceGrid.Services.Clipboard;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.Clipboard
{
    [TestFixture]
    public class ClipboardParserTests
    {
        [Test]
        public void ShouldGetPrices_From_ExcelClipboard()
        {
            const string clipboard = "2.25\r\n2.35\r\n";

            var clipboardParser = new ClipboardParser();

            // ACT
            var prices = clipboardParser.GetPricesFromText(clipboard);

            // ASSERT
            Assert.That(prices.Count, Is.EqualTo(2));
            Assert.That(prices[0], Is.EqualTo(2.25));
            Assert.That(prices[1], Is.EqualTo(2.35));
        }

        [Test]
        public void ShouldGetPrices_From_IceChatClipboard()
        {
            const string clipboard = "2.25\n2.35\n";

            var clipboardParser = new ClipboardParser();

            // ACT
            var prices = clipboardParser.GetPricesFromText(clipboard);

            // ASSERT
            Assert.That(prices.Count, Is.EqualTo(2));
            Assert.That(prices[0], Is.EqualTo(2.25));
            Assert.That(prices[1], Is.EqualTo(2.35));
        }

        [Test]
        public void ShouldGetClipboardTextFromPrices()
        {
            const string expected = "12.1\t1.1\r\n12.2\t1.2\r\n";

            var prices = new List<IList<decimal?>>
                         {
                             new decimal?[] {12.1M, 12.2M}, new decimal?[] {1.1M, 1.2M}
                         };

            var clipboardParser = new ClipboardParser();

            // ACT
            var text = clipboardParser.GetClipboardTextFromPrices(prices);

            // ASSERT
            Assert.That(text, Is.EqualTo(expected));
        }
    }
}
