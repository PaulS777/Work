﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.Services.Clipboard;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.Clipboard
{
    internal interface IPriceGridClipboardServiceTestObjects
    {
        IClipboardService ClipboardService { get; }
        PriceGridClipboardService PriceGridClipboardService { get; }
    }

    [TestFixture]
    public class PriceGridClipboardServiceTests
    {
        private class PriceGridClipboardServiceTestObjectBuilder
        {
            public IPriceGridClipboardServiceTestObjects Build()
            {
                var testObjects = new Mock<IPriceGridClipboardServiceTestObjects>();

                var clipboardService = new Mock<IClipboardService>();

                testObjects.SetupGet(o => o.ClipboardService)
                           .Returns(clipboardService.Object);

                var priceGridClipboardService = new PriceGridClipboardService(clipboardService.Object);

                testObjects.SetupGet(o => o.PriceGridClipboardService)
                           .Returns(priceGridClipboardService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldCopyAllPrices_WhenPriceCellsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2020, 1);
            var tenor2 = new MonthlyTenor(2020, 2);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .WithMidPrice(1.1M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .WithMidPrice(null)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor2)
                                                             .WithMidPrice(1.2M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCurveDefinitionId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId2)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .PriceCell();

            var priceCell5 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId2)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .PriceCell();

            var priceCell6 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId2)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor2)
                                                             .PriceCell();

            var priceCurveDefinitionId3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

            var priceCell7 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId3)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .PriceCell();

            var priceCell8 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId3)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .WithMidPrice(3.3M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell9 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId3)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .WithMidPrice(3.4M)
                                                             .PriceCell();

            var priceCellLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
            {
                {linkedCurve, new List<PriceCellViewModel> {priceCell1, priceCell2, priceCell3}},
                {priceCurveDefinitionId2, new List<PriceCellViewModel> {priceCell4, priceCell5, priceCell6}},
                {priceCurveDefinitionId3, new List<PriceCellViewModel> {priceCell7, priceCell8, priceCell9}}
            };

            var testObjects = new PriceGridClipboardServiceTestObjectBuilder().Build();

            // ACT
            testObjects.PriceGridClipboardService.CopySelectedPrices(priceCellLookup, false);

            // ASSERT
            Mock.Get(testObjects.ClipboardService)
                .Verify(cs => cs.CopyPricesToClipboard(It.Is<IList<IList<decimal?>>>(prices => prices.Count == 2 
                                                                                               && prices[0].Count == 3
                                                                                               && prices[0][0] == 1.1M
                                                                                               && prices[0][1] == null
                                                                                               && prices[0][2] == 1.2M
                                                                                               && prices[1].Count == 1
                                                                                               && prices[1][0] == 3.3M)));
        }

        [Test]
        public void ShouldEnableCopyPrices_When_PriceCellsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2020, 1);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .WithMidPrice(1.1M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .WithMidPrice(null)
                                                             .PriceCell();

            var priceCellLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
            {
                {linkedCurve, new List<PriceCellViewModel> {priceCell1, priceCell2}}
            };

            var testObjects = new PriceGridClipboardServiceTestObjectBuilder().Build();

            // ACT
            var result = testObjects.PriceGridClipboardService.CanCopySelectedPrices(priceCellLookup, false);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldDisableCopyPrices_When_NoPriceCellsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2020, 1);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .WithMidPrice(1.1M)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .WithMidPrice(null)
                                                             .PriceCell();

            var priceCellLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
            {
                {linkedCurve, new List<PriceCellViewModel> {priceCell1, priceCell2}}
            };

            var testObjects = new PriceGridClipboardServiceTestObjectBuilder().Build();

            // ACT
            var result = testObjects.PriceGridClipboardService.CanCopySelectedPrices(priceCellLookup, false);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldCopyMonthlyPrices_When_MonthlyPriceCellsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2020, 1);
            var tenor2 = new MonthlyTenor(2020, 2);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .WithMidPrice(1.1M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .WithMidPrice(1.15M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell3 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor2)
                                                             .WithMidPrice(1.2M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCurveDefinitionId2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

            var priceCell4 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId2)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .WithMidPrice(3.1M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell5 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId2)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .PriceCell();

            var priceCell6 = new PriceCellTestObjectBuilder().WithLinkedCurve(priceCurveDefinitionId2)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor2)
                                                             .PriceCell();

            var priceCellLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
            {
                {linkedCurve, new List<PriceCellViewModel> {priceCell1, priceCell2, priceCell3}},
                {priceCurveDefinitionId2, new List<PriceCellViewModel> {priceCell4, priceCell5, priceCell6}}
            };

            var testObjects = new PriceGridClipboardServiceTestObjectBuilder().Build();

            // ACT
            testObjects.PriceGridClipboardService.CopySelectedPrices(priceCellLookup, true);

            // ASSERT
            Mock.Get(testObjects.ClipboardService).Verify(cs => cs.CopyPricesToClipboard(It.Is<IList<IList<decimal?>>>(
                prices => prices.Count == 1
                          && prices[0].Count == 2
                          && prices[0][0] == 1.15M
                          && prices[0][1] == 1.2M)));
        }

        [Test]
        public void ShouldEnableCopyMonthlyPrices_When_MonthlyPriceCellsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2020, 1);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .WithMidPrice(1.1M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .WithMidPrice(1.15M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCellLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
            {
                {linkedCurve, new List<PriceCellViewModel> {priceCell1, priceCell2}}
            };

            var testObjects = new PriceGridClipboardServiceTestObjectBuilder().Build();

            // ACT
            var result = testObjects.PriceGridClipboardService.CanCopySelectedPrices(priceCellLookup, true);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldDisableCopyMonthlyPrices_When_NoMonthlyPriceCellsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var tenor1 = new MonthlyTenor(2020, 1);

            var priceCell1 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Quarterly)
                                                             .WithTenorValue(20200100)
                                                             .WithMidPrice(1.1M)
                                                             .WithIsSelected(true)
                                                             .PriceCell();

            var priceCell2 = new PriceCellTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                             .WithRowTenorType(RowTenorType.Monthly)
                                                             .WithTenor(tenor1)
                                                             .WithMidPrice(1.15M)
                                                             .PriceCell();

            var priceCellLookup = new Dictionary<LinkedCurve, List<PriceCellViewModel>>
            {
                {linkedCurve, new List<PriceCellViewModel> {priceCell1, priceCell2}}
            };

            var testObjects = new PriceGridClipboardServiceTestObjectBuilder().Build();

            // ACT
            var result = testObjects.PriceGridClipboardService.CanCopySelectedPrices(priceCellLookup, true);

            // ASSERT
            Assert.That(result, Is.False);
        }
    }
}
