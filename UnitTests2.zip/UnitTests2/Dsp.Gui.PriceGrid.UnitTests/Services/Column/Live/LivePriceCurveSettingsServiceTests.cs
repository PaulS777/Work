﻿using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.PriceGrid.Services.Column.Live;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.Column.Live
{
    internal interface ILivePriceCurveSettingsServiceTestObjects
    {
        IPriceCurveSettingObserver PriceCurveSettingObserver { get; }
        ISubject<PriceCurveSetting> PriceCurveSetting { get; }
        LivePriceCurveSettingsService LivePriceCurveSettingsService { get; }
    }

    [TestFixture]
    public class LivePriceCurveSettingsServiceTests
    {
        private class LivePriceCurveSettingsServiceTestObjectBuilder
        {
            public ILivePriceCurveSettingsServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceCurveSettingsServiceTestObjects>();

                var priceCurveSetting = new Subject<PriceCurveSetting>();

                testObjects.SetupGet(o => o.PriceCurveSetting)
                           .Returns(priceCurveSetting);

                var priceCurveSettingObserver = new Mock<IPriceCurveSettingObserver>();

                priceCurveSettingObserver.Setup(o => o.Observe(It.IsAny<int>()))
                                         .Returns(priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSettingObserver)
                           .Returns(priceCurveSettingObserver.Object);

                var livePriceCurveSettingsService = new LivePriceCurveSettingsService(priceCurveSettingObserver.Object,
                                                                                      TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.LivePriceCurveSettingsService)
                           .Returns(livePriceCurveSettingsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldObservePriceCurveSettings_When_SubscribeUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceBandInfo();

            var testObjects = new LivePriceCurveSettingsServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurveSettingsService.AttachBandInfo(bandInfo);

            // ACT
            testObjects.LivePriceCurveSettingsService.SubscribeUpdates();

            // ASSERT
            Mock.Get(testObjects.PriceCurveSettingObserver)
                .Verify(o => o.Observe(101));
        }

        [Test]
        public void ShouldUpdateBandInfo_On_PriceCurveSetting()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceBandInfo();

            var testObjects = new LivePriceCurveSettingsServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurveSettingsService.AttachBandInfo(bandInfo);

            testObjects.LivePriceCurveSettingsService.SubscribeUpdates();

            var setting = new PriceCurveSetting(101, 10, true, true, false, false, null);

            // ACT
            testObjects.PriceCurveSetting.OnNext(setting);

            // ASSERT
            Assert.That(bandInfo.CanEditIsTradeable, Is.True);
            Assert.That(bandInfo.IsTradeable, Is.True);
            Assert.That(bandInfo.PriceCurveSetting(), Is.SameAs(setting));
        }

        [Test]
        public void ShouldNotUpdateBandInfo_When_UnsubscribeUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceBandInfo();

            var testObjects = new LivePriceCurveSettingsServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurveSettingsService.AttachBandInfo(bandInfo);

            testObjects.LivePriceCurveSettingsService.SubscribeUpdates();
            testObjects.LivePriceCurveSettingsService.UnsubscribeUpdates();

            var setting = new PriceCurveSetting(101, 10, true, true, false, false, null);

            // ACT
            testObjects.PriceCurveSetting.OnNext(setting);

            // ASSERT
            Assert.That(bandInfo.CanEditIsTradeable, Is.False);
        }

        [Test]
        public void ShouldSubscribeUpdates_After_UnsubscribeUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceBandInfo();

            var testObjects = new LivePriceCurveSettingsServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurveSettingsService.AttachBandInfo(bandInfo);

            testObjects.LivePriceCurveSettingsService.SubscribeUpdates();
            testObjects.LivePriceCurveSettingsService.UnsubscribeUpdates();
            testObjects.LivePriceCurveSettingsService.SubscribeUpdates();

            var setting = new PriceCurveSetting(101, 10, true, true, false, false, null);

            // ACT
            testObjects.PriceCurveSetting.OnNext(setting);

            // ASSERT
            Assert.That(bandInfo.CanEditIsTradeable, Is.True);
        }

        [Test]
        public void ShouldNotUpdateBandInfo_When_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceBandInfo();

            var testObjects = new LivePriceCurveSettingsServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurveSettingsService.AttachBandInfo(bandInfo);

            testObjects.LivePriceCurveSettingsService.SubscribeUpdates();

            var setting = new PriceCurveSetting(101, 10, true, true, false, false, null);

            testObjects.LivePriceCurveSettingsService.Dispose();

            // ACT
            testObjects.PriceCurveSetting.OnNext(setting);

            // ASSERT
            Assert.That(bandInfo.CanEditIsTradeable, Is.False);
        }

        [Test]
        public void ShouldNotSubscribeUpdates_When_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceBandInfo();

            var testObjects = new LivePriceCurveSettingsServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurveSettingsService.AttachBandInfo(bandInfo);

            var setting = new PriceCurveSetting(101, 10, true, true, false, false, null);

            testObjects.LivePriceCurveSettingsService.Dispose();
            testObjects.LivePriceCurveSettingsService.SubscribeUpdates();

            // ACT
            testObjects.PriceCurveSetting.OnNext(setting);

            // ASSERT
            Assert.That(bandInfo.CanEditIsTradeable, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceBandInfo();

            var testObjects = new LivePriceCurveSettingsServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurveSettingsService.AttachBandInfo(bandInfo);

            var setting = new PriceCurveSetting(101, 10, true, true, false, false, null);

            testObjects.LivePriceCurveSettingsService.Dispose();
            testObjects.LivePriceCurveSettingsService.SubscribeUpdates();

            // ACT
            testObjects.LivePriceCurveSettingsService.Dispose();
            testObjects.PriceCurveSetting.OnNext(setting);

            // ASSERT
            Assert.That(bandInfo.CanEditIsTradeable, Is.False);
        }
    }
}
