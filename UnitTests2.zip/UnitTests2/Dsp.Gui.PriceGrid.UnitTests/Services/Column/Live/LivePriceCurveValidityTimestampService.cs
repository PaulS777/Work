﻿using System;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.PriceGrid.Services.Column.Live;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.Column.Live
{
    internal interface ILivePriceCurveValidityTimestampServiceTestObjects
    {
        ISubject<PriceCurve> PriceCurve { get; }
        LivePriceCurveValidityTimestampService LivePriceCurveValidityTimestampService { get; }
    }

    public class LivePriceCurveValidityTimestampServiceTests
    {
        private class LivePriceRagStatusServiceTestObjectBuilder
        {
            public ILivePriceCurveValidityTimestampServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceCurveValidityTimestampServiceTestObjects>();

                var priceCurve = new Subject<PriceCurve>();

                testObjects.SetupGet(o => o.PriceCurve)
                           .Returns(priceCurve);

                var curveValidityTimestampService = new LivePriceCurveValidityTimestampService(TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.LivePriceCurveValidityTimestampService)
                           .Returns(curveValidityTimestampService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetTimestamp_On_PriceCurve()
        {
            var timestamp = new DateTime(2023, 1, 1, 12, 0, 0);

            var testObjects = new LivePriceRagStatusServiceTestObjectBuilder().Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithValidityIndicator(ValidityIndicator.Invalid)
                                                                         .WithPriceCurve(testObjects.PriceCurve)
                                                                         .LivePriceHeaderBandInfo();

            
            testObjects.LivePriceCurveValidityTimestampService.AttachBandInfo(bandInfo);
            testObjects.LivePriceCurveValidityTimestampService.SubscribeUpdates();

            var priceCurve = new PriceCurveBuilder().WithTimestamp(timestamp).Build();

            // ACT
            testObjects.PriceCurve.OnNext(priceCurve);

            // ASSERT
            Assert.That(bandInfo.CurveTimestamp, Is.Not.Null);
        }

        [Test]
        public void ShouldSetRagStatus_On_PriceCurve()
        {
            var testObjects = new LivePriceRagStatusServiceTestObjectBuilder().Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithValidityIndicator(ValidityIndicator.Invalid)
                                                                         .WithPriceCurve(testObjects.PriceCurve)
                                                                         .LivePriceHeaderBandInfo();


            testObjects.LivePriceCurveValidityTimestampService.AttachBandInfo(bandInfo);
            testObjects.LivePriceCurveValidityTimestampService.SubscribeUpdates();

            var priceCurve = new PriceCurveBuilder().WithValidityIndicator(ValidityIndicator.Valid).Build();

            // ACT
            testObjects.PriceCurve.OnNext(priceCurve);

            // ASSERT
            Assert.That(bandInfo.LivePriceBandInfo.RagStatus, Is.EqualTo(ValidityIndicator.Valid));
        }

        [Test]
        public void ShouldNotSetTimestamp_When_UnsubscribeUpdates()
        {
            var timestamp = new DateTime(2023, 1, 1, 12, 0, 0);

            var testObjects = new LivePriceRagStatusServiceTestObjectBuilder().Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithValidityIndicator(ValidityIndicator.Invalid)
                                                                         .WithPriceCurve(testObjects.PriceCurve)
                                                                         .LivePriceHeaderBandInfo();


            testObjects.LivePriceCurveValidityTimestampService.AttachBandInfo(bandInfo);
            testObjects.LivePriceCurveValidityTimestampService.SubscribeUpdates();

            var priceCurve = new PriceCurveBuilder().WithTimestamp(timestamp).Build();

            testObjects.LivePriceCurveValidityTimestampService.UnsubscribeUpdates();

            // ACT
            testObjects.PriceCurve.OnNext(priceCurve);

            // ASSERT
            Assert.That(bandInfo.CurveTimestamp, Is.Null);
        }

        [Test]
        public void ShouldNotSetTimestamp_When_Disposed()
        {
            var timestamp = new DateTime(2023, 1, 1, 12, 0, 0);

            var testObjects = new LivePriceRagStatusServiceTestObjectBuilder().Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithValidityIndicator(ValidityIndicator.Invalid)
                                                                         .WithPriceCurve(testObjects.PriceCurve)
                                                                         .LivePriceHeaderBandInfo();


            testObjects.LivePriceCurveValidityTimestampService.AttachBandInfo(bandInfo);
            testObjects.LivePriceCurveValidityTimestampService.SubscribeUpdates();

            var priceCurve = new PriceCurveBuilder().WithTimestamp(timestamp).Build();

            testObjects.LivePriceCurveValidityTimestampService.Dispose();

            // ACT
            testObjects.PriceCurve.OnNext(priceCurve);

            // ASSERT
            Assert.That(bandInfo.CurveTimestamp, Is.Null);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var timestamp = new DateTime(2023, 1, 1, 12, 0, 0);

            var testObjects = new LivePriceRagStatusServiceTestObjectBuilder().Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithValidityIndicator(ValidityIndicator.Invalid)
                                                                         .WithPriceCurve(testObjects.PriceCurve)
                                                                         .LivePriceHeaderBandInfo();


            testObjects.LivePriceCurveValidityTimestampService.AttachBandInfo(bandInfo);
            testObjects.LivePriceCurveValidityTimestampService.SubscribeUpdates();

            var priceCurve = new PriceCurveBuilder().WithTimestamp(timestamp).Build();

            testObjects.LivePriceCurveValidityTimestampService.Dispose();

            // ACT
            testObjects.LivePriceCurveValidityTimestampService.Dispose();
            testObjects.PriceCurve.OnNext(priceCurve);

            // ASSERT
            Assert.That(bandInfo.CurveTimestamp, Is.Null);
        }
    }
}
