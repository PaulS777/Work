﻿using System.Reactive.Subjects;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.PriceGrid.Services.Column.Live;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.Column.Live
{
    internal interface ILivePriceCurrentUserIsPublisherServiceTestObjects
    {
        ICurrentUserIsPublisherObserver CurrentUserIsPublisherObserver { get; }
        ISubject<bool> CurrentUserIsPublisher { get; }
        LivePriceCurrentUserIsPublisherService LivePriceCurrentUserIsPublisherService { get; }
    }

    [TestFixture]
    public class LivePriceCurrentUserIsPublisherServiceTests
    {
        private class LivePriceCurrentUserIsPublisherServiceTestObjectBuilder
        {
            public ILivePriceCurrentUserIsPublisherServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePriceCurrentUserIsPublisherServiceTestObjects>();

                var currentUserIsPublisher = new Subject<bool>();

                testObjects.SetupGet(o => o.CurrentUserIsPublisher)
                           .Returns(currentUserIsPublisher);

                var currentUserIsPublisherObserver = new Mock<ICurrentUserIsPublisherObserver>();

                currentUserIsPublisherObserver.Setup(obs => obs.Observe(It.IsAny<int>()))
                                              .Returns(currentUserIsPublisher);

                testObjects.SetupGet(o => o.CurrentUserIsPublisherObserver)
                           .Returns(currentUserIsPublisherObserver.Object);

                var currentUserIsPublisherService = new LivePriceCurrentUserIsPublisherService(currentUserIsPublisherObserver.Object,
                                                                                               TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.LivePriceCurrentUserIsPublisherService)
                           .Returns(currentUserIsPublisherService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldObserveCurrentUserIsPublisher_When_SubscribeUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            var testObjects = new LivePriceCurrentUserIsPublisherServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurrentUserIsPublisherService.AttachBandInfo(bandInfo);

            // ACT
            testObjects.LivePriceCurrentUserIsPublisherService.SubscribeUpdates();

            // ASSERT
            Mock.Get(testObjects.CurrentUserIsPublisherObserver)
                .Verify(o => o.Observe(101));
        }

        [Test]
        public void ShouldUpdateBandInfo_On_CurrentUserIsPublisherTrue()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            var testObjects = new LivePriceCurrentUserIsPublisherServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurrentUserIsPublisherService.AttachBandInfo(bandInfo);

            testObjects.LivePriceCurrentUserIsPublisherService.SubscribeUpdates();

            // ACT
            testObjects.CurrentUserIsPublisher.OnNext(true);

            // ASSERT
            Assert.That(bandInfo.CurrentUserIsPublisher, Is.True);
        }

        [Test]
        public void ShouldNotUpdateBandInfo_When_UnsubscribeUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            var testObjects = new LivePriceCurrentUserIsPublisherServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurrentUserIsPublisherService.AttachBandInfo(bandInfo);

            testObjects.LivePriceCurrentUserIsPublisherService.SubscribeUpdates();
            testObjects.LivePriceCurrentUserIsPublisherService.UnsubscribeUpdates();

            // ACT
            testObjects.CurrentUserIsPublisher.OnNext(true);

            // ASSERT
            Assert.That(bandInfo.CurrentUserIsPublisher, Is.False);
        }

        [Test]
        public void ShouldNotUpdateBandInfo_When_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            var testObjects = new LivePriceCurrentUserIsPublisherServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurrentUserIsPublisherService.AttachBandInfo(bandInfo);

            testObjects.LivePriceCurrentUserIsPublisherService.SubscribeUpdates();
            testObjects.LivePriceCurrentUserIsPublisherService.Dispose();

            // ACT
            testObjects.CurrentUserIsPublisher.OnNext(true);

            // ASSERT
            Assert.That(bandInfo.CurrentUserIsPublisher, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            var testObjects = new LivePriceCurrentUserIsPublisherServiceTestObjectBuilder().Build();

            testObjects.LivePriceCurrentUserIsPublisherService.AttachBandInfo(bandInfo);

            testObjects.LivePriceCurrentUserIsPublisherService.SubscribeUpdates();
            testObjects.LivePriceCurrentUserIsPublisherService.Dispose();

            // ACT
            testObjects.LivePriceCurrentUserIsPublisherService.Dispose();
            testObjects.CurrentUserIsPublisher.OnNext(true);

            // ASSERT
            Assert.That(bandInfo.CurrentUserIsPublisher, Is.False);
        }
    }
}
