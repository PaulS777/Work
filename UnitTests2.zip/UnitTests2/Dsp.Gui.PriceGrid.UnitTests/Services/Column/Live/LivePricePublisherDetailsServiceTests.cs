﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.PriceGrid.Services.Column.Live;
using Dsp.Gui.PriceGrid.Services.Common;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Services.Column.Live
{
    internal interface ILivePricePublisherDetailsServiceTestObjects
    {
        ISubject<PriceCurveSetting> PriceCurveSetting { get; }
        IPriceCurveSettingObserver PriceCurveSettingObserver { get; }
        IUserDetailsLookupProvider UserDetailsLookupProvider { get; }
        ISubject<int> PublisherId { get; }
        ISubject<Dictionary<int, string>> UserDetails { get; }
        LivePricePublisherDetailsService LivePricePublisherDetailsService { get; }
    }

    [TestFixture]
    public class LivePricePublisherDetailsServiceTests
    {
        private class LivePricePublisherDetailsServiceTestObjectBuilder
        {
            private PriceCurveSetting _priceCurveSetting;
            private Dictionary<int, string> _userDetails;

            public LivePricePublisherDetailsServiceTestObjectBuilder WithPriceCurveSetting(PriceCurveSetting value)
            {
                _priceCurveSetting = value;
                return this;
            }

            public LivePricePublisherDetailsServiceTestObjectBuilder WithUserDetails(Dictionary<int, string> values)
            {
                _userDetails = values;
                return this;
            }

            public ILivePricePublisherDetailsServiceTestObjects Build()
            {
                var testObjects = new Mock<ILivePricePublisherDetailsServiceTestObjects>();

                var priceCurveSetting = new BehaviorSubject<PriceCurveSetting>(_priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSetting)
                           .Returns(priceCurveSetting);

                var priceCurveSettingObserver = new Mock<IPriceCurveSettingObserver>();

                priceCurveSettingObserver.Setup(f => f.Observe(It.IsAny<int>()))
                                        .Returns(priceCurveSetting);

                testObjects.SetupGet(o => o.PriceCurveSettingObserver)
                           .Returns(priceCurveSettingObserver.Object);

                var userDetails = new BehaviorSubject<Dictionary<int, string>>(_userDetails);

                testObjects.SetupGet(o => o.UserDetails)
                           .Returns(userDetails);

                var userDetailsLookupProvider = new Mock<IUserDetailsLookupProvider>();

                userDetailsLookupProvider.SetupGet(p => p.UserDetails)
                                         .Returns(userDetails);

                testObjects.SetupGet(o => o.UserDetailsLookupProvider)
                           .Returns(userDetailsLookupProvider.Object);

                var livePricePublisherDetailsService
                    = new LivePricePublisherDetailsService(priceCurveSettingObserver.Object,
                                                           userDetailsLookupProvider.Object,
                                                           TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.LivePricePublisherDetailsService)
                           .Returns(livePricePublisherDetailsService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldObservePriceCurveSetting_When_SubscribeUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            var testObjects = new LivePricePublisherDetailsServiceTestObjectBuilder().Build();

            testObjects.LivePricePublisherDetailsService.AttachBandInfo(bandInfo);

            // ACT
            testObjects.LivePricePublisherDetailsService.SubscribeUpdates();

            //ASSERT
            Mock.Get(testObjects.PriceCurveSettingObserver)
                .Verify(f => f.Observe(101));
        }

        [Test]
        public void ShouldSetPublicationDetails_On_CurveSetting_With_UserDetails()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .Build();

            var userDetails = new Dictionary<int, string> { { 10, "details" } };

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            var testObjects = new LivePricePublisherDetailsServiceTestObjectBuilder().WithUserDetails(userDetails)
                                                                                     .Build();

            testObjects.LivePricePublisherDetailsService.AttachBandInfo(bandInfo);

            testObjects.LivePricePublisherDetailsService.SubscribeUpdates();

            // ACT
            testObjects.PriceCurveSetting.OnNext(curveSetting);

            //ASSERT
            Assert.That(bandInfo.PublicationDetails, Is.EqualTo("details"));
        }

        [Test]
        public void ShouldUpdatePublicationDetails_On_UserDetails()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .Build();

            var userDetails = new Dictionary<int, string> { { 10, "details" } };

            var testObjects = new LivePricePublisherDetailsServiceTestObjectBuilder().WithPriceCurveSetting(curveSetting)
                                                                                     .WithUserDetails(userDetails)
                                                                                     .Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            testObjects.LivePricePublisherDetailsService.AttachBandInfo(bandInfo);

            testObjects.LivePricePublisherDetailsService.SubscribeUpdates();

            var update = new Dictionary<int, string> { { 10, "update" } };

            // ACT
            testObjects.UserDetails.OnNext(update);

            //ASSERT
            Assert.That(bandInfo.PublicationDetails, Is.EqualTo("update"));
        }

        [Test]
        public void ShouldUpdatePublicationDetailsAsNull_On_UserDetails_With_Missing_PublisherDetails()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .Build();

            var userDetails = new Dictionary<int, string> { { 99, "details" } };

            var testObjects = new LivePricePublisherDetailsServiceTestObjectBuilder().WithPriceCurveSetting(curveSetting)
                                                                                     .WithUserDetails(userDetails)
                                                                                     .Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            testObjects.LivePricePublisherDetailsService.AttachBandInfo(bandInfo);

            testObjects.LivePricePublisherDetailsService.SubscribeUpdates();

            // ACT
            testObjects.UserDetails.OnNext(userDetails);

            //ASSERT
            Assert.That(bandInfo.PublicationDetails, Is.EqualTo(null));
        }

        [Test]
        public void ShouldNotUpdatePublicationDetails_When_UnsubscribeUpdates()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .Build();

            var userDetails = new Dictionary<int, string> { { 10, "details" } };

            var testObjects = new LivePricePublisherDetailsServiceTestObjectBuilder().WithPriceCurveSetting(curveSetting)
                                                                                     .WithUserDetails(userDetails)
                                                                                     .Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            testObjects.LivePricePublisherDetailsService.AttachBandInfo(bandInfo);

            testObjects.LivePricePublisherDetailsService.SubscribeUpdates();

            var update = new Dictionary<int, string> { { 10, "update" } };

            testObjects.LivePricePublisherDetailsService.UnsubscribeUpdates();

            // ACT
            testObjects.UserDetails.OnNext(update);

            //ASSERT
            Assert.That(bandInfo.PublicationDetails, Is.EqualTo("details"));
        }

        [Test]
        public void ShouldNotUpdatePublicationDetails_When_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .Build();

            var userDetails = new Dictionary<int, string> { { 10, "details" } };

            var testObjects = new LivePricePublisherDetailsServiceTestObjectBuilder().WithPriceCurveSetting(curveSetting)
                                                                                     .WithUserDetails(userDetails)
                                                                                     .Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            testObjects.LivePricePublisherDetailsService.AttachBandInfo(bandInfo);

            testObjects.LivePricePublisherDetailsService.SubscribeUpdates();

            var update = new Dictionary<int, string> { { 10, "update" } };

            testObjects.LivePricePublisherDetailsService.Dispose();

            // ACT
            testObjects.UserDetails.OnNext(update);

            //ASSERT
            Assert.That(bandInfo.PublicationDetails, Is.EqualTo("details"));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var curveSetting = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
                                                                       .WithPublisherId(10)
                                                                       .Build();

            var userDetails = new Dictionary<int, string> { { 10, "details" } };

            var testObjects = new LivePricePublisherDetailsServiceTestObjectBuilder().WithPriceCurveSetting(curveSetting)
                                                                                     .WithUserDetails(userDetails)
                                                                                     .Build();

            var bandInfo = new LivePriceHeaderBandInfoTestObjectBuilder().WithLinkedCurve(linkedCurve)
                                                                         .LivePriceHeaderBandInfo();

            testObjects.LivePricePublisherDetailsService.AttachBandInfo(bandInfo);

            testObjects.LivePricePublisherDetailsService.SubscribeUpdates();

            var update = new Dictionary<int, string> { { 10, "update" } };

            testObjects.LivePricePublisherDetailsService.Dispose();

            // ACT
            testObjects.LivePricePublisherDetailsService.Dispose();
            testObjects.UserDetails.OnNext(update);

            //ASSERT
            Assert.That(bandInfo.PublicationDetails, Is.EqualTo("details"));
        }
    }
}
