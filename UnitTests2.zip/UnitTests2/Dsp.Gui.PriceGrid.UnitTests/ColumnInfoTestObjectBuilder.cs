﻿using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Common;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels.Column;

namespace Dsp.Gui.PriceGrid.UnitTests
{
    public class ColumnInfoTestObjectBuilder
    {
        private ColumnType _columnType;
        private CurveGroup _curveGroup;
        private int _pageNumber;
        private LinkedCurve _linkedCurve;
        private List<PriceCellViewModel> _priceCells;
        private double _adjustedWidth;
        private double _width;
        private int _priceCellIndex;
        private bool _showSummary;
        private readonly PriceGridViewModel _priceGrid = new();

        public ColumnInfoTestObjectBuilder WithColumnType(ColumnType value)
        {
            _columnType = value;
            return this;
        }

        public ColumnInfoTestObjectBuilder WithCurveGroup(CurveGroup value)
        {
            _curveGroup = value;
            return this;
        }

        public ColumnInfoTestObjectBuilder WithPageNumber(int value)
        {
            _pageNumber = value;
            return this;
        }

        public ColumnInfoTestObjectBuilder WithLinkedCurve(LinkedCurve value)
        {
            _linkedCurve = value;
            return this;
        }

        public ColumnInfoTestObjectBuilder WithPriceCells(List<PriceCellViewModel> value)
        {
            _priceCells = value;
            return this;
        }

        public ColumnInfoTestObjectBuilder WithAdjustedWidth(double value)
        {
            _adjustedWidth = value;
            return this;
        }

        public ColumnInfoTestObjectBuilder WithWidth(double value)
        {
            _width = value;
            return this;
        }

        public ColumnInfoTestObjectBuilder WithPriceCellIndex(int value)
        {
            _priceCellIndex = value;
            return this;
        }

        public ColumnInfoTestObjectBuilder WithShowSummary(bool value)
        {
            _showSummary = value;
            return this;
        }


        public ColumnInfo ColumnInfo()
        {
            var columnInfo = new ColumnInfo(_columnType)
            {
                CurveGroup = _curveGroup,
                AdjustedWidth = _adjustedWidth,
                Width = _width,
                PriceCellIndex = _priceCellIndex,
                ShowSummary = _showSummary
            };

            var details = new BandInfoDetails(_pageNumber, _linkedCurve, _priceGrid);

            details.SetPriceCells(_priceCells);

            columnInfo.SetDetails(details);

            return columnInfo;
        }
    }
}
