﻿using Dsp.DataContracts;
using Dsp.Gui.PriceGrid.Comparers;
using NUnit.Framework;

namespace Dsp.Gui.PriceGrid.UnitTests.Comparers
{
    [TestFixture]
    public class MonthlyTenorRangeComparerTests
    {
        [Test]
        public void ShouldReturnTrue_When_Same_Reference()
        {
            var tenors = new MonthlyTenor[] { new(2024, 1) };

            var comparer = new MonthlyTenorRangeComparer();

            // ACT
            var result = comparer.Equals(tenors, tenors);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_First_IsNull()
        {
            var tenors = new MonthlyTenor[] { new(2024, 1) };

            var comparer = new MonthlyTenorRangeComparer();

            // ACT
            var result = comparer.Equals(null, tenors);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Second_IsNull()
        {
            var tenors = new MonthlyTenor[] { new(2024, 1) };

            var comparer = new MonthlyTenorRangeComparer();

            // ACT
            var result = comparer.Equals(tenors, null);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Same_Count_DifferentTenors()
        {
            var tenors1 = new MonthlyTenor[] { new(2024, 1) };
            var tenors2 = new MonthlyTenor[] { new(2024, 2) };

            var comparer = new MonthlyTenorRangeComparer();

            // ACT
            var result = comparer.Equals(tenors1, tenors2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnTrue_When_Same_TenorSequence()
        {
            var tenors1 = new MonthlyTenor[] { new(2024, 1) };
            var tenors2 = new MonthlyTenor[] { new(2024, 1) };

            var comparer = new MonthlyTenorRangeComparer();

            // ACT
            var result = comparer.Equals(tenors1, tenors2);

            // ASSERT
            Assert.That(result, Is.True);
        }
    }
}
