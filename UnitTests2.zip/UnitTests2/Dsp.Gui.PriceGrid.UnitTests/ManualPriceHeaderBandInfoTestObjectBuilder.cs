﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Common;
using Dsp.Gui.Markets.Common.ViewModels.PriceGrid;
using Dsp.Gui.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels.Column;
using Moq;

namespace Dsp.Gui.PriceGrid.UnitTests
{
    public class ManualPriceHeaderBandInfoTestObjectBuilder
    {
        private IDisposable _controller;
        private int _pageNumber;
        private LinkedCurve _linkedCurve;
        private string _header;
        private bool _isVisible;
        private List<PriceCellViewModel> _priceCells;
        private bool _canUndoChanges;
        private bool _canUpdateOverrides;
        private bool _validOverrides;
        private bool _hasErrors;
        private string _validationText;
        private CurveGroup _curveGroup;
        private int _adjustedVisibleIndex;
        private bool _subscribeUpdates;
        private PriceGridViewModel _priceGrid;
        private IObservable<ManualCurveDefinition<MonthlyTenor>> _manualCurve;
        private ICommand _pasteFromClipboardCommand;
        private ICommand _updateOverridesCommand;
        private bool _autoSave;
        private bool _isPasteFromClipboard;
        private bool _canUseChatPrice;

        public ManualPriceHeaderBandInfoTestObjectBuilder WithController(IDisposable value)
        {
            _controller = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithPageNumber(int value)
        {
            _pageNumber = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithLinkedCurve(LinkedCurve value)
        {
            _linkedCurve = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithHeader(string value)
        {
            _header = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithIsVisible(bool value)
        {
            _isVisible = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithPriceCells(List<PriceCellViewModel> values)
        {
            _priceCells = values;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithCanUndoChanges(bool value)
        {
            _canUndoChanges = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithCanUpdateOverrides(bool value)
        {
            _canUpdateOverrides = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithValidOverrides(bool value)
        {
            _validOverrides = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithHasErrors(bool value)
        {
            _hasErrors = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithValidationText(string value)
        {
            _validationText = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithCurveGroup(CurveGroup value)
        {
            _curveGroup = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithAdjustedVisibleIndex(int value)
        {
            _adjustedVisibleIndex = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithSubscribeUpdates(bool value)
        {
            _subscribeUpdates = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithPriceGrid(PriceGridViewModel value)
        {
            _priceGrid = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithManualCurve(IObservable<ManualCurveDefinition<MonthlyTenor>> value)
        {
            _manualCurve = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithPasteFromClipboardCommand(ICommand value)
        {
            _pasteFromClipboardCommand = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithUpdateOverridesCommand(ICommand value)
        {
            _updateOverridesCommand = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithAutoSave(bool value)
        {
            _autoSave = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithIsPasteFromClipboard(bool value)
        {
            _isPasteFromClipboard = value;
            return this;
        }

        public ManualPriceHeaderBandInfoTestObjectBuilder WithCanUseChatPrice(bool value)
        {
            _canUseChatPrice = value;
            return this;
        }

        public ManualPriceHeaderBandInfo ManualPriceBandHeaderInfo()
        {
            var controller = _controller ?? Mock.Of<IDisposable>();

            var details = new BandInfoDetails(_pageNumber, _linkedCurve, _priceGrid);

            if (_priceCells != null)
            {
                details.SetPriceCells(_priceCells);
            }

            var bandInfo = new ManualPriceHeaderBandInfo(controller,
                                                         BandHeaderType.ManualPriceHeader,
                                                         new ManualPriceBandInfo(Mock.Of<IDisposable>()),
                                                         new ChatPriceBandInfo(Mock.Of<IDisposable>()))
                           {
                               Header = _header,
                               IsVisible = _isVisible
                           };

            bandInfo.SetDetails(details);
            bandInfo.ManualPriceBandInfo.SetDetails(details);
            bandInfo.ChatPriceBandInfo.SetDetails(details);

            bandInfo.SetManualCurve(_manualCurve);

            bandInfo.ManualPriceBandInfo.ManualPriceColumnInfo = new ColumnInfo(ColumnType.ManualPrice)
            {
                CurveGroup = _curveGroup
            };
            bandInfo.ManualPriceBandInfo.ManualPriceColumnInfo.SetDetails(details);

            bandInfo.ChatPriceBandInfo.ChatPriceColumnInfo = new ColumnInfo(ColumnType.ChatPrice)
            {
                CurveGroup = _curveGroup
            };

            bandInfo.ChatPriceBandInfo.ChatPriceColumnInfo.SetDetails(details);

            bandInfo.CanUseChatPrice = _canUseChatPrice;
            bandInfo.ManualPriceBandInfo.PasteFromClipboardCommand = _pasteFromClipboardCommand;
            bandInfo.ManualPriceBandInfo.UpdateOverridesCommand = _updateOverridesCommand;
            bandInfo.ManualPriceBandInfo.AutoSave = _autoSave;
            bandInfo.ManualPriceBandInfo.IsPasteFromClipboard = _isPasteFromClipboard;
            bandInfo.ManualPriceBandInfo.ValidOverrides = _validOverrides;
            bandInfo.ManualPriceBandInfo.HasErrors = _hasErrors;
            bandInfo.ManualPriceBandInfo.ValidationText = _validationText;
            bandInfo.ManualPriceBandInfo.CanUndoChanges = _canUndoChanges;
            bandInfo.ManualPriceBandInfo.CanUpdateOverrides = _canUpdateOverrides;
            bandInfo.AdjustedVisibleIndex = _adjustedVisibleIndex;
            bandInfo.SubscribeUpdates = _subscribeUpdates;

            return bandInfo;
        }

        public ManualPriceBandInfo ManualPriceBandInfo() => ManualPriceBandHeaderInfo().ManualPriceBandInfo;
        public ChatPriceBandInfo ChatPriceBandInfo() => ManualPriceBandHeaderInfo().ChatPriceBandInfo;
    }
}
