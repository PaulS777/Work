﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.UserMaintenance.Controllers;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Controllers
{
    internal interface IUserAdminControllerTestObjects
    {
        List<User> DefaultUsers { get; }
        IList<FxCurveDefinition> DefaultFxCurveDefinitions { get; }
        IUserAdminChangedService UserAdminChangedService { get; }
        ISubject<bool> UserAdminChanged { get; } 
        ICurveGroupItemsDataSource CurveGroupItemsDataSource { get; }
        ICurveRegionItemsDataSource CurveRegionItemsDataSource { get; }
        IFxCurveItemsDataSource FxCurveItemsDataSource { get; }
        ISubject<List<CurveGroup>> CurveGroups { get; }
        ISubject<List<User>> Users { get; }
        ISubject<IList<FxCurveDefinition>> FxCurveDefinitions { get; }
        ISerialDisposableEnvelope ChangeSubscription { get; }
        IUserAdminToolBarService ToolBarService { get; }
        ISubject<Unit> ToolBarUpdateUser { get; }
        IClearUserPermissionsService ClearUserPermissionsService { get; }
        ICopyFromUserService CopyFromUserService { get; }
        IUserNameValidationService UserNameValidationService { get; }
        IDisplayNameValidationService DisplayNameValidationService { get; }
        IUserAdminBuilder UserAdminBuilder { get; }
        IUserAdminUpdateService UserAdminUpdateService { get; }
        ISubject<Unit> UpdateUserResponse { get; }
        ISubject<Unit> AddUserResponse { get; }
        IErrorMessageDialogService MessageDialogService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        UserAdminViewModel ViewModel { get; }
        UserAdminController Controller { get; } 
    }
    
    [TestFixture]
    public class UserAdminControllerTests
    {
        private class UserAdminControllerTestObjectBuilder
        {
            private List<User> _users;
            private IList<FxCurveDefinition> _fxCurveDefinitions;
            private List<CurveGroup> _curveGroups;
            private IEnumerable<CurveGroupItem> _curveGroupItems;
            private IEnumerable<CurveRegionItem> _curveRegionItems;
            private IEnumerable<FxCurveItem> _fxCurveItems;
            private bool _useDefaultUsers;
            private bool _useDefaultFxCurveDefinitions;
            private bool _validateUserNameResult;
            private bool _validateDisplayNameResult;
            private string _displayNameParserResult;
            private User _userAdminBuilderResult;

            public UserAdminControllerTestObjectBuilder WithUsers(List<User> values)
            {
                _users = values;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithDefaultUsers()
            {
                _useDefaultUsers = true;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithDefaultFxCurveDefinitions()
            {
                _useDefaultFxCurveDefinitions = true;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithCurveGroups(List<CurveGroup> values)
            {
                _curveGroups = values;
                return this;
            }

			public UserAdminControllerTestObjectBuilder WithCurveGroupItems(IEnumerable<CurveGroupItem> values)
            {
                _curveGroupItems = values;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithCurveRegionItems(IEnumerable<CurveRegionItem> values)
            {
                _curveRegionItems= values;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithFxCurveItems(IEnumerable<FxCurveItem> values)
            {
                _fxCurveItems = values;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithValidateUserNameResult(bool value)
            {
                _validateUserNameResult = value;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithValidateDisplayNameResult(bool value)
            {
                _validateDisplayNameResult = value;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithDisplayNameParserResult(string value)
            {
                _displayNameParserResult = value;
                return this;
            }

            public UserAdminControllerTestObjectBuilder WithUserAdminBuilderResult(User value)
            {
                _userAdminBuilderResult = value;
                return this;
            }

            public IUserAdminControllerTestObjects Build()
            {
                var testObjects = new Mock<IUserAdminControllerTestObjects>();

                #region Defaults

                var defaultUsers = new List<User> { new UserBuilder().User() };
                var defaultFxCurveDefinitions = new[] { new FxCurveDefinitionTestObjectBuilder().Build() };

                if (_useDefaultUsers)
                {
                    _users = defaultUsers;
                }

                if (_useDefaultFxCurveDefinitions)
                {
                    _fxCurveDefinitions = defaultFxCurveDefinitions;
                }

                testObjects.SetupGet(o => o.DefaultUsers)
                           .Returns(defaultUsers);

                testObjects.SetupGet(o => o.DefaultFxCurveDefinitions)
                           .Returns(defaultFxCurveDefinitions);

                #endregion

                #region CurveControlService

                var users = new BehaviorSubject<List<User>>(_users);

                testObjects.SetupGet(o => o.Users)
                           .Returns(users);

                var curveGroups = new BehaviorSubject<List<CurveGroup>>(_curveGroups);

                testObjects.SetupGet(o => o.CurveGroups).Returns(curveGroups);

                var fxCurveDefinitions = new BehaviorSubject<IList<FxCurveDefinition>>(_fxCurveDefinitions);

                testObjects.SetupGet(o => o.FxCurveDefinitions)
                           .Returns(fxCurveDefinitions);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.Users)
                                   .Returns(users);

                curveControlService.SetupGet(c => c.FxCurveDefinitions)
                                   .Returns(fxCurveDefinitions);

                curveControlService.SetupGet(c => c.CurveGroups)
                                   .Returns(curveGroups);

                #endregion

                #region UserAdminChangedService

                var userAdminChanged = new BehaviorSubject<bool>(false);

                testObjects.SetupGet(o => o.UserAdminChanged)
                           .Returns(userAdminChanged);

                var userAdminChangedService = new Mock<IUserAdminChangedService>();

                userAdminChangedService.Setup(a => a.ObserveChanges(It.IsAny<UserAdminViewModel>(),
                                                                    It.IsAny<ICurveGroupItemsDataSource>(),
                                                                    It.IsAny<ICurveRegionItemsDataSource>(),
                                                                    It.IsAny<IFxCurveItemsDataSource>()))
                                       .Returns(userAdminChanged);

                testObjects.SetupGet(o => o.UserAdminChangedService)
                           .Returns(userAdminChangedService.Object);

                #endregion

                var changeSubscription = new Mock<ISerialDisposableEnvelope>();

                testObjects.SetupGet(o => o.ChangeSubscription)
                           .Returns(changeSubscription.Object);

                #region Data Sources

                var curveGroupItemsDataSource = new Mock<ICurveGroupItemsDataSource>();

                if (_curveGroupItems != null)
                {
                    curveGroupItemsDataSource.Setup(d => d.InitializeDataSource(It.IsAny<IList<CurveGroupItem>>()))
                                             .Returns(new ReadOnlyObservableCollection<CurveGroupItem>(new ObservableCollection<CurveGroupItem>(_curveGroupItems)));

                    curveGroupItemsDataSource.Setup(d => d.Items())
                                             .Returns(_curveGroupItems);
                }

                testObjects.SetupGet(o => o.CurveGroupItemsDataSource)
                           .Returns(curveGroupItemsDataSource.Object);

                var curveRegionItemsDataSource = new Mock<ICurveRegionItemsDataSource>();

                if (_curveRegionItems != null)
                {
                    curveRegionItemsDataSource.Setup(d => d.InitializeDataSource(It.IsAny<IList<CurveRegionItem>>()))
                                              .Returns(new ReadOnlyObservableCollection<CurveRegionItem>(new ObservableCollection<CurveRegionItem>(_curveRegionItems)));

                    curveRegionItemsDataSource.Setup(d => d.Items())
                                              .Returns(_curveRegionItems);
                }

                testObjects.SetupGet(o => o.CurveRegionItemsDataSource)
                           .Returns(curveRegionItemsDataSource.Object);
                
                var fxCurveItemsDataSource = new Mock<IFxCurveItemsDataSource>();

                if (_fxCurveItems != null)
                {
                    fxCurveItemsDataSource.Setup(d => d.InitializeDataSource(It.IsAny<IList<FxCurveItem>>()))
                                          .Returns(new ReadOnlyObservableCollection<FxCurveItem>(new ObservableCollection<FxCurveItem>(_fxCurveItems)));

                    fxCurveItemsDataSource.Setup(d => d.Items())
                                          .Returns(_fxCurveItems);
                }

                testObjects.SetupGet(o => o.FxCurveItemsDataSource)
                           .Returns(fxCurveItemsDataSource.Object);

                var dataSourceProvider = new Mock<IUserAdminDataSourceProvider>();

                dataSourceProvider.SetupGet(p => p.CurveGroupItems)
                                  .Returns(curveGroupItemsDataSource.Object);

                dataSourceProvider.SetupGet(p => p.CurveRegionItems)
                                  .Returns(curveRegionItemsDataSource.Object);

                dataSourceProvider.SetupGet(p => p.FxCurveItems)
                                  .Returns(fxCurveItemsDataSource.Object);

                #endregion

                #region ToolBar

                var toolBarUpdateUser = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUpdateUser)
                           .Returns(toolBarUpdateUser);

                var toolBarService = new Mock<IUserAdminToolBarService>();

                toolBarService.Setup(t => t.UpdateUser)
                              .Returns(toolBarUpdateUser);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBarService.Object);

                #endregion

                #region name validation and parser

                var userNameValidationService = new Mock<IUserNameValidationService>();

                string userNameError;

                userNameValidationService.Setup(v => v.ValidateUserName(It.IsAny<string>(),
                                                                        It.IsAny<bool>(),
                                                                        It.IsAny<int>(),
                                                                        It.IsAny<IList<User>>(),
                                                                        out userNameError))
                                         .Returns(_validateUserNameResult);

                testObjects.SetupGet(o => o.UserNameValidationService)
                           .Returns(userNameValidationService.Object);


                var displayNameValidationService = new Mock<IDisplayNameValidationService>();

                string displayNameError;

                displayNameValidationService.Setup(v => v.ValidateDisplayName(It.IsAny<string>(), 
                                                                              It.IsAny<bool>(), 
                                                                              It.IsAny<int>(),
                                                                              It.IsAny<IList<User>>(), 
                                                                              out displayNameError))
                                            .Returns(_validateDisplayNameResult);

                testObjects.SetupGet(o => o.DisplayNameValidationService)
                           .Returns(displayNameValidationService.Object);

                var displayNameParser = new Mock<IDisplayNameParser>();

                displayNameParser.Setup(p => p.ParseFromUserName(It.IsAny<string>()))
                                 .Returns(_displayNameParserResult);

                #endregion

                #region UserAdminBuilder, UserAdminUpdate

                var userAdminBuilder = new Mock<IUserAdminBuilder>();

                userAdminBuilder.Setup(b => b.GetUser(It.IsAny<UserDetailsViewModel>(),
                                                      It.IsAny<UserPermissionsViewModel>(),
                                                      It.IsAny<IEnumerable<CurveGroupItem>>(),
                                                      It.IsAny<IEnumerable<CurveRegionItem>>(),
                                                      It.IsAny<IEnumerable<FxCurveItem>>(),
                                                      It.IsAny<int>()))
                                .Returns(_userAdminBuilderResult);

                testObjects.SetupGet(o => o.UserAdminBuilder)
                           .Returns(userAdminBuilder.Object);

                var updateUserResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.UpdateUserResponse)
                           .Returns(updateUserResponse);

                var addUserResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.AddUserResponse)
                           .Returns(addUserResponse);

                var userAdminUpdateService = new Mock<IUserAdminUpdateService>();

                userAdminUpdateService.Setup(a => a.Add(It.IsAny<IList<User>>(),
                                                        It.IsAny<IScheduler>()))
                                      .Returns(addUserResponse);

                userAdminUpdateService.Setup(a => a.Update(It.IsAny<User>(),
                                                           It.IsAny<IScheduler>()))
                                      .Returns(updateUserResponse);

                testObjects.SetupGet(o => o.UserAdminUpdateService)
                           .Returns(userAdminUpdateService.Object);

                #endregion

                #region Copy User

                var copyFromUserService = new Mock<ICopyFromUserService>();

                testObjects.SetupGet(o => o.CopyFromUserService)
                           .Returns(copyFromUserService.Object);

                #endregion

                #region Clear Items

                var clearUserPermissionsService = new Mock<IClearUserPermissionsService>();

                testObjects.SetupGet(o => o.ClearUserPermissionsService)
                           .Returns(clearUserPermissionsService.Object);

                #endregion

                #region Dialog and Popup

                var messageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.MessageDialogService)
                           .Returns(messageDialogService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                #endregion

                var controller = new UserAdminController(curveControlService.Object,
                                                         dataSourceProvider.Object,
                                                         userAdminChangedService.Object,
                                                         toolBarService.Object,
                                                         TestMocks.GetSchedulerProvider().Object,
                                                         TestMocks.GetLoggerFactory().Object)
                                 {
                                     ChangeSubscription = changeSubscription.Object,
                                     CopyFromUserService = copyFromUserService.Object,
                                     ClearUserPermissionsService = clearUserPermissionsService.Object,
                                     UserNameValidationService = userNameValidationService.Object,
                                     DisplayNameValidationService = displayNameValidationService.Object,
                                     DisplayNameParser = displayNameParser.Object,
                                     MessageDialogService = messageDialogService.Object,
                                     PopupNotificationService = popupNotificationService.Object,
                                     UserAdminBuilder = userAdminBuilder.Object,
                                     UserAdminUpdateService = userAdminUpdateService.Object
                                 };

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.Setup(c => c.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region Initialize

        [Test]
        public void ShouldSetIsBusy_And_PopulateDefaults_On_Initialize()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

            var curveGroupItems = new[] { new CurveGroupItem(curveGroup) };
            var curveRegionItems = new[] { new CurveRegionItem(CurveRegion.Europe) };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithCurveGroupItems(curveGroupItems)
                                                                        .WithCurveRegionItems(curveRegionItems)
                                                                        .Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);

            Assert.That(testObjects.ViewModel.IsAddNewUser, Is.True);
            Assert.That(testObjects.ViewModel.CanEditUserDetailsAndItems, Is.True);
            Assert.That(testObjects.ViewModel.AddUserNameRequired, Is.True);
            Assert.That(testObjects.ViewModel.AddDisplayNameRequired, Is.True);
            Assert.That(testObjects.ViewModel.IsUserNameValid, Is.False);
            Assert.That(testObjects.ViewModel.IsDisplayNameValid, Is.False);
            Assert.That(testObjects.ViewModel.UserPermissions.IsEnabled, Is.True);

            Mock.Get(testObjects.CurveRegionItemsDataSource)
                .Verify(d => d.InitializeDataSource(It.IsAny<IList<CurveRegionItem>>()));

            Assert.That(testObjects.ViewModel.CurveRegionItems.Count == 1);
        }

        [Test]
        public void ShouldPopulateCurveGroupItems_On_CurveGroups_With_Initialized()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

            var curveGroupItems = new[] { new CurveGroupItem(curveGroup) };
            var curveRegionItems = new[] { new CurveRegionItem(CurveRegion.Europe) };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithCurveGroupItems(curveGroupItems)
                                                                        .WithCurveRegionItems(curveRegionItems)
                                                                        .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.CurveGroups.OnNext([curveGroup]);

            // ASSERT
            Mock.Get(testObjects.CurveGroupItemsDataSource)
                .Verify(d => d.InitializeDataSource(It.Is<IList<CurveGroupItem>>(i => i.Count == 1 && ReferenceEquals(i[0].CurveGroup, curveGroup))));
		}

        [Test]
        public void ShouldRefreshCurveGroupItems_On_CurveGroupsUpdate()
        {
            var curveGroup1 = new CurveGroupTestObjectBuilder().Default();
            var curveGroup2 = new CurveGroupTestObjectBuilder().Default();

            var update = new List<CurveGroup> { curveGroup1, curveGroup2 };

            var curveGroupItems = new[] { new CurveGroupItem(curveGroup1) };
            var curveRegionItems = new[] { new CurveRegionItem(CurveRegion.Europe) };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithCurveGroupItems(curveGroupItems)
                                                                        .WithCurveRegionItems(curveRegionItems)
                                                                        .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.CurveGroups.OnNext([curveGroup1]);

			// ACT
            testObjects.CurveGroups.OnNext(update);

			// ASSERT
			Mock.Get(testObjects.CurveGroupItemsDataSource)
                .Verify(d => d.RefreshItems(It.Is<IList<CurveGroupItem>>(i => i.Count == 2)));
		}

        [Test]
        public void ShouldNotInitialize_When_Initialized()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();

			var curveGroupItems = new[] { new CurveGroupItem(curveGroup) };
            var curveRegionItems = new[] { new CurveRegionItem(CurveRegion.Europe) };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithCurveGroupItems(curveGroupItems)
                                                                        .WithCurveRegionItems(curveRegionItems)
                                                                        .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsBusy = false;

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        #endregion

        #region Users and FxCurveDefintions Loaded

        [Test]
        public void ShouldPopulateUsersOrderedByName_On_UsersAndFxCurvesLoaded()
        {
            var userA = new UserBuilder().WithUserName("user-A").User();
            var userB = new UserBuilder().WithUserName("user-B").User();
            var userC = new UserBuilder().WithUserName("user-C").User();

            var users = new List<User> { userB, userC, userA };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            var expected = new[] { userA, userB, userC };

            // ACT
            testObjects.Users.OnNext(users);

            // ASSERT
            Assert.That(testObjects.ViewModel.Users.SequenceEqual(expected));
        }

        [Test]
        public void ShouldInitializeFxCurveItemsDataSource_On_UsersAndFxCurvesLoaded()
        {
            var fxCurveDef1 = new FxCurveDefinitionTestObjectBuilder().WithId(101).WithName("fx1").WithQuoteCurrencyId(1).Build();
            var fxCurveDef2 = new FxCurveDefinitionTestObjectBuilder().WithId(102).WithQuoteCurrencyId(2).Build();

            var fxCurves = new[] { fxCurveDef1, fxCurveDef2 };

            var items = new[] { new FxCurveItem("fx1", 101) };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithFxCurveItems(items)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.FxCurveDefinitions.OnNext(fxCurves);

            // ASSERT
            Mock.Get(testObjects.FxCurveItemsDataSource)
                .Verify(d => d.InitializeDataSource(It.Is<IList<FxCurveItem>>(i => i.Count == 1 && i[0].Id == 101)));

            Assert.That(testObjects.ViewModel.FxCurveItems.Count == 1);
        }

        [Test]
        public void ShouldValidateUserNameAndDisplayName_On_UsersAndFxCurvesLoaded()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(false)
                                                                        .WithValidateDisplayNameResult(false)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.Users.OnNext(users);

            // ASSERT
            string errors;

            Mock.Get(testObjects.UserNameValidationService)
                .Verify(v => v.ValidateUserName(null, true, 0, users, out errors));

            Assert.That(testObjects.ViewModel.IsUserNameValid, Is.False);

            Mock.Get(testObjects.DisplayNameValidationService)
                .Verify(v => v.ValidateDisplayName(null, true, 0, users, out errors));

            Assert.That(testObjects.ViewModel.IsDisplayNameValid, Is.False);
        }

        [Test]
        public void ShouldSetIsBusyFalse_On_UsersAndFxCurvesLoaded()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.Users.OnNext(testObjects.DefaultUsers);
            testObjects.FxCurveDefinitions.OnNext(testObjects.DefaultFxCurveDefinitions);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
        }

        #endregion

        #region IsAddNewUser Changed

        [Test]
        public void ShouldDisposeSubscriptions_On_IsAddNewUser()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.IsAddNewUser = false;

            // ASSERT
            Mock.Get(testObjects.ChangeSubscription)
                .Verify(g => g.DisposeSubscription());
        }

        [Test]
        public void ShouldClearForm_On_IsAddNewUser()
        {
            var users = new List<User> { new UserBuilder().WithUserName("user").User() };
            var curveGroup = new CurveGroupTestObjectBuilder().Default();
			var curveGroupItems = new[] { new CurveGroupItem(curveGroup) };
            var curveRegionItems = new[] { new CurveRegionItem(CurveRegion.Europe) };
            var fxCurveItems = new[] { new FxCurveItem("name", 50) };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithCurveGroupItems(curveGroupItems)
                                                                        .WithCurveRegionItems(curveRegionItems)
                                                                        .WithFxCurveItems(fxCurveItems)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE - Mirror User
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ACT
            testObjects.ViewModel.IsAddNewUser = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedUser, Is.Null);

            Mock.Get(testObjects.ClearUserPermissionsService)
                .Verify(c => c.Clear(testObjects.ViewModel.UserPermissions,
                                     curveGroupItems,
                                     curveRegionItems,
                                     fxCurveItems));
        }

        [Test]
        public void ShouldDisableToolBar_On_IsAddNewUser()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.IsAddNewUser = false;

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(false));
        }

        #endregion

        #region Switch to Modify Existing User

        [Test]
        public void ShouldApplyDefaults_And_ClearErrors_When_SwitchTo_ModifyExisting()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsUserNameValid = false;
            testObjects.ViewModel.UserNameError = "error";

            testObjects.ViewModel.IsDisplayNameValid = false;
            testObjects.ViewModel.DisplayNameError = "error";

            // ACT
            testObjects.ViewModel.IsAddNewUser = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.AddUserNameRequired, Is.False);
            Assert.That(testObjects.ViewModel.AddDisplayNameRequired, Is.False);
            Assert.That(testObjects.ViewModel.CanEditUserDetailsAndItems, Is.False);
            Assert.That(testObjects.ViewModel.IsUserNameValid, Is.True);
            Assert.That(testObjects.ViewModel.UserNameError, Is.Null);
            Assert.That(testObjects.ViewModel.IsDisplayNameValid, Is.True);
            Assert.That(testObjects.ViewModel.DisplayNameError, Is.Null);
        }

        [Test]
        public void ShouldObserveChanges_When_SwitchTo_ModifyExisting()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            Mock.Get(testObjects.UserAdminChangedService).Invocations.Clear();
            Mock.Get(testObjects.ChangeSubscription).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsAddNewUser = false;

            // ASSERT
            Mock.Get(testObjects.UserAdminChangedService)
                .Verify(c => c.ObserveChanges(testObjects.ViewModel,
                                              testObjects.CurveGroupItemsDataSource,
                                              testObjects.CurveRegionItemsDataSource,
                                              testObjects.FxCurveItemsDataSource));

            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.ApplySubscription(It.IsAny<IDisposable>()));
        }

        #endregion

        #region Switch to Add New User

        [Test]
        public void ShouldShowUserNameBorder_And_EnableDetails_When_SwitchTo_AddNewUser()
        {
            var users = new List<User> { new UserBuilder().WithUserName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsAddNewUser = false;

            // ACT
            testObjects.ViewModel.IsAddNewUser = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.AddUserNameRequired, Is.True);
            Assert.That(testObjects.ViewModel.AddDisplayNameRequired, Is.True);
            Assert.That(testObjects.ViewModel.CanEditUserDetailsAndItems, Is.True);
        }

        [Test]
        public void ShouldSetValidation_And_HasChangedFalse_When_SwitchTo_AddNewUser()
        {
            var users = new List<User> { new UserBuilder().WithUserName("user.name").WithId(10).User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(false)
                                                                        .WithValidateDisplayNameResult(false)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.IsUserNameValid = true;
            testObjects.ViewModel.IsDisplayNameValid = true;
            testObjects.ViewModel.HasChanged = true;

            Mock.Get(testObjects.UserNameValidationService).Invocations.Clear();
            Mock.Get(testObjects.DisplayNameValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsAddNewUser = true;

            // ASSERT
            string errors;

            Mock.Get(testObjects.UserNameValidationService)
                .Verify(v => v.ValidateUserName(null, true, 0, users, out errors), Times.Once);

            Assert.That(testObjects.ViewModel.IsUserNameValid, Is.False);

            Mock.Get(testObjects.DisplayNameValidationService)
                .Verify(v => v.ValidateDisplayName(null, true, 0, users, out errors), Times.Once);

            Assert.That(testObjects.ViewModel.IsDisplayNameValid, Is.False);
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
        }

        [Test]
        public void ShouldNotObserveChanges_When_SwitchTo_AddNewUser()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsAddNewUser = false;

            Mock.Get(testObjects.UserAdminChangedService).Invocations.Clear();
            Mock.Get(testObjects.ChangeSubscription).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsAddNewUser = true;

            // ASSERT
            Mock.Get(testObjects.UserAdminChangedService)
                .Verify(c => c.ObserveChanges(testObjects.ViewModel,
                                              testObjects.CurveGroupItemsDataSource,
                                              testObjects.CurveRegionItemsDataSource,
                                              testObjects.FxCurveItemsDataSource), Times.Never);

            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.ApplySubscription(It.IsAny<IDisposable>()), Times.Never);
        }

        #endregion

        #region User Name Changed

        [Test]
        public void ShouldUpdateDisplayName_On_UserNameChanged_With_ValidationTrue()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(true)
                                                                        .WithDisplayNameParserResult("name")
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.UserDetails.UserName = "user.name";

            // ASSERT
            Assert.That(testObjects.ViewModel.UserDetails.DisplayName, Is.EqualTo("name"));
        }

        [Test]
        public void ShouldNotUpdateDisplayName_On_UserNameChanged_With_ValidationFalse()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(false)
                                                                        .WithDisplayNameParserResult("name")
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.UserDetails.UserName = "user.name";

            // ASSERT
            Assert.That(testObjects.ViewModel.UserDetails.DisplayName, Is.Null);
        }

        [Test]
        public void ShouldHideUserNameBorder_On_UserNameChanged()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();
            // ACT
            testObjects.ViewModel.UserDetails.UserName = "user.name";

            // ASSERT
            Assert.That(testObjects.ViewModel.AddUserNameRequired, Is.False);
        }

        [Test]
        public void ShouldHideDisplayNameBorder_On_DisplayNameChanged()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().WithDefaultUsers()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();
            // ACT
            testObjects.ViewModel.UserDetails.DisplayName = "name";

            // ASSERT
            Assert.That(testObjects.ViewModel.AddDisplayNameRequired, Is.False);
        }

        [Test]
        public void ShouldValidateUserName_And_EnableToolBar_On_UserNameChanged_With_ValidationTrue()
        {
            var users = new List<User> { new UserBuilder().User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithUsers(users)
                                                                        .WithValidateDisplayNameResult(true)
                                                                        .WithValidateUserNameResult(true)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.UserDetails.UserName = "user.name";

            // ASSERT
            string errors;

            Mock.Get(testObjects.UserNameValidationService)
                .Verify(v => v.ValidateUserName("user.name", true, 0, users, out errors));

            Assert.That(testObjects.ViewModel.IsUserNameValid, Is.True);

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(true));
        }

        [Test]
        public void ShouldValidateDisplay_And_EnableToolBar_On_DisplayNameChanged_With_ValidationTrue()
        {
            var users = new List<User> { new UserBuilder().User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithUsers(users)
                                                                        .WithValidateUserNameResult(true)
                                                                        .WithValidateDisplayNameResult(true)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.UserDetails.DisplayName = "name";

            // ASSERT
            string errors;

            Mock.Get(testObjects.DisplayNameValidationService)
                .Verify(v => v.ValidateDisplayName("name", true, 0, users, out errors));

            Assert.That(testObjects.ViewModel.IsDisplayNameValid, Is.True);

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(true));
        }

        [Test]
        public void ShouldDisableToolBar_On_UserNameChanged_With_ValidationFalse()
        {
            var users = new List<User> { new UserBuilder().User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithUsers(users)
                                                                        .WithValidateDisplayNameResult(true)
                                                                        .WithValidateUserNameResult(false)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.UserDetails.UserName = "user";

            // ASSERT
            Assert.That(testObjects.ViewModel.IsUserNameValid, Is.False);

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(false));
        }

        [Test]
        public void ShouldDisableToolBar_On_DisplayNameChanged_With_ValidationFalse()
        {
            var users = new List<User> { new UserBuilder().User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithUsers(users)
                                                                        .WithValidateUserNameResult(false)
                                                                        .WithValidateDisplayNameResult(false)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.UserDetails.DisplayName = "";

            // ASSERT
            Assert.That(testObjects.ViewModel.IsDisplayNameValid, Is.False);

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(false));
        }

        #endregion

        #region SelectedUser 

        [Test]
        public void ShouldDisposeSubscriptions_On_SelectedUser()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ASSERT
            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.DisposeSubscription());
        }

        [Test]
        public void Should_CopyUserDetailsAndItems_On_SelectedUser()
        {
            var curveGroup = new CurveGroupTestObjectBuilder().Default();
			var curveGroupItems = new[] { new CurveGroupItem(curveGroup) };
            var curveRegionItems = new[] { new CurveRegionItem(CurveRegion.Europe) };
            var fxCurveItems = new[] { new FxCurveItem("name", 50) };

            var user = new UserBuilder().WithId(10).WithUserName("user.name").User();

            var users = new List<User> { user };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithCurveGroupItems(curveGroupItems)
                                                                        .WithCurveRegionItems(curveRegionItems)
                                                                        .WithFxCurveItems(fxCurveItems)
                                                                        .WithValidateUserNameResult(true)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ASSERT
            Mock.Get(testObjects.CopyFromUserService)
                .Verify(c => c.CopyUserDetailsAndItems(user, 
                                                       testObjects.ViewModel.UserPermissions, 
                                                       curveGroupItems, 
                                                       curveRegionItems, 
                                                       fxCurveItems));
        }

        [Test]
        public void ShouldDisableToolbarUpdate_On_SelectedUser()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(c => c.SetCanUpdateUser(false));
        }

        #endregion

        #region SelectedUser - Add New User

        [Test]
        public void ShouldNotClearUserName_On_SelectedUser_With_AddNew()
        {
            var users = new List<User> { new UserBuilder().WithId(10).WithUserName("user.name").WithName("name").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(true)
                                                                        .WithValidateDisplayNameResult(true)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.UserDetails.UserName = "user.name";
            testObjects.ViewModel.UserDetails.DisplayName = "name";
            testObjects.ViewModel.HasChanged = true;

            Mock.Get(testObjects.UserNameValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ASSERT
            Assert.That(testObjects.ViewModel.UserDetails.UserName, Is.EqualTo("user.name"));
         
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(true));
        }

        [Test]
        public void ShouldNotObserveChanges_On_SelectedUser_With_AddNew()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ASSERT
            Mock.Get(testObjects.UserAdminChangedService)
                .Verify(c => c.ObserveChanges(testObjects.ViewModel,
                                              testObjects.CurveGroupItemsDataSource,
                                              testObjects.CurveRegionItemsDataSource,
                                              testObjects.FxCurveItemsDataSource), Times.Never);

            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.ApplySubscription(It.IsAny<IDisposable>()), Times.Never);
        }

        #endregion

        #region SelectedUser - Modify User

        [Test]
        public void ShouldEnableEntryFields_When_SelectUser_With_ModifyExisting()
        {
            var users = new List<User> { new UserBuilder().WithUserName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ASSERT
            Assert.That(testObjects.ViewModel.CanEditUserDetailsAndItems, Is.True);
        }

        [Test]
        public void ShouldSetUserName_And_ClearValidation_When_SelectedUser_With_ModifyExisting()
        {
            var users = new List<User>
                        {
                            new UserBuilder().WithUserName("user.name-1").WithName("name-1").User(),
                            new UserBuilder().WithUserName("user.name-2").WithName("name-2").WithId(10).User()
                        };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(true)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE - User Maintenance , Validation Error
            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            testObjects.ViewModel.IsUserNameValid = false;
            testObjects.ViewModel.UserNameError = "error";
            testObjects.ViewModel.IsDisplayNameValid = false;
            testObjects.ViewModel.DisplayNameError = "error";

            Mock.Get(testObjects.UserNameValidationService).Invocations.Clear();
            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[1];

            // ASSERT
            Assert.That(testObjects.ViewModel.UserDetails.UserName ,Is.EqualTo("user.name-2"));
            Assert.That(testObjects.ViewModel.UserDetails.DisplayName, Is.EqualTo("name-2"));

            string errors;

            Mock.Get(testObjects.UserNameValidationService)
                .Verify(v => v.ValidateUserName("user.name-2", false, 10, users, out errors), Times.Once);

            Assert.That(testObjects.ViewModel.IsUserNameValid, Is.True);
            Assert.That(testObjects.ViewModel.UserNameError, Is.Null);
            Assert.That(testObjects.ViewModel.IsDisplayNameValid, Is.True);
            Assert.That(testObjects.ViewModel.DisplayNameError, Is.Null);

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(false));
        }

        [Test]
        public void ShouldObserveChanges_On_SelectedUser_With_ModifyUser()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsAddNewUser = false;

            Mock.Get(testObjects.UserAdminChangedService).Invocations.Clear();
            Mock.Get(testObjects.ChangeSubscription).Invocations.Clear();

            // ACT
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ASSERT
            Mock.Get(testObjects.UserAdminChangedService)
                .Verify(c => c.ObserveChanges(testObjects.ViewModel,
                                              testObjects.CurveGroupItemsDataSource,
                                              testObjects.CurveRegionItemsDataSource,
                                              testObjects.FxCurveItemsDataSource));

            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.ApplySubscription(It.IsAny<IDisposable>()));
        }

        #endregion

        #region User Admin Changes, ToolBar enabled

        [Test]
        public void ShouldSetHasChangedTrue_And_On_UserAdminChangedTrue_With_ModifySelectedUser()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE 
            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ACT
            testObjects.UserAdminChanged.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
        }

        [Test]
        public void ShouldEnableToolbarUpdate_And_On_UserAdminChangedTrue_With_UserValid_And_ModifyUser()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(true)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE 
            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();
             
            // ACT
            testObjects.UserAdminChanged.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(true));
        }

        [Test]
        public void ShouldDisableToolbarUpdate_And_On_UserAdminChangedFalse_With_UserValid_And_ModifyUser()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(true)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE 
            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.UserAdminChanged.OnNext(false);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(false));
        }

        [Test]
        public void ShouldDisableToolbarUpdate_And_On_UserAdminChangedTrue_With_UserValidFalse_And_ModifyUser()
        {
            var users = new List<User> { new UserBuilder().WithId(1).WithName("user").User() };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithValidateUserNameResult(false)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE 
            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            Mock.Get(testObjects.ToolBarService).Invocations.Clear();

            // ACT
            testObjects.UserAdminChanged.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(false));
        }

        #endregion

        #region AdminSerice Add New User

        [Test]
        public void ShouldSetIsBusyTrue_AddUser_On_UpdateUser_With_AddNew()
        {
            var users = new List<User> { new UserBuilder().WithId(0).WithName("user").User() };

            var user = new UserBuilder().User();

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithUserAdminBuilderResult(user)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsAddNewUser = true;

            // ACT
            testObjects.ToolBarUpdateUser.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);

            var expected = new[] { user };

            Mock.Get(testObjects.UserAdminBuilder)
                .Verify(b => b.GetUser(It.IsAny<UserDetailsViewModel>(),
                                       It.IsAny<UserPermissionsViewModel>(),
                                       It.IsAny<IEnumerable<CurveGroupItem>>(),
                                       It.IsAny<IEnumerable<CurveRegionItem>>(),
                                       It.IsAny<IEnumerable<FxCurveItem>>(),
                                       0));

            Mock.Get(testObjects.UserAdminUpdateService)
                .Verify(a => a.Add(It.Is<IList<User>>(u => u.SequenceEqual(expected)), 
                                   It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldRestoreDefaults_And_ShowPopup_On_AddNewUserResponse_Success()
        {
            var users = new List<User> { new UserBuilder().WithId(0).WithName("user").User() };

            var user = new UserBuilder().User();

            var curveGroup = new CurveGroupTestObjectBuilder().Default();
			var curveGroupItems = new[] { new CurveGroupItem(curveGroup) };
            var curveRegionItems = new[] { new CurveRegionItem(CurveRegion.Europe) };
            var fxCurveItems = new[] { new FxCurveItem("name", 50) };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithCurveGroupItems(curveGroupItems)
                                                                        .WithCurveRegionItems(curveRegionItems)
                                                                        .WithFxCurveItems(fxCurveItems)
                                                                        .WithUserAdminBuilderResult(user)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsAddNewUser = true;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];
            testObjects.ViewModel.UserDetails.UserName = "user.name";

            Mock.Get(testObjects.ClearUserPermissionsService).Invocations.Clear();
            Mock.Get(testObjects.UserNameValidationService).Invocations.Clear();

            // ARRANGE
            testObjects.ToolBarUpdateUser.OnNext(Unit.Default);

            // ACT
            testObjects.AddUserResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);

            Assert.That(testObjects.ViewModel.SelectedUser, Is.Null);
            Assert.That(testObjects.ViewModel.UserDetails.UserName, Is.Null);
            Assert.That(testObjects.ViewModel.UserDetails.DisplayName, Is.Null);

            Assert.That(testObjects.ViewModel.IsAddNewUser, Is.True);
            Assert.That(testObjects.ViewModel.AddUserNameRequired, Is.True);
            Assert.That(testObjects.ViewModel.AddDisplayNameRequired, Is.True);
            Assert.That(testObjects.ViewModel.CanEditUserDetailsAndItems, Is.True);
            Assert.That(testObjects.ViewModel.UserPermissions.IsEnabled, Is.True);

            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.DisposeSubscription());

            Mock.Get(testObjects.ClearUserPermissionsService)
                .Verify(c => c.Clear(testObjects.ViewModel.UserPermissions,
                                     curveGroupItems,
                                     curveRegionItems,
                                     fxCurveItems));
            string errors;

            Mock.Get(testObjects.UserNameValidationService)
                .Verify(v => v.ValidateUserName(null, true, 0, users, out errors));

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(false));

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldSetIsBusyFalse_And_ShowMessageBox_On_AddNewUserResponse_Error()
        {
            var users = new List<User> { new UserBuilder().WithId(0).WithName("user").User() };

            var user = new UserBuilder().User();

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithUserAdminBuilderResult(user)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsAddNewUser = true;

            // ARRANGE
            testObjects.ToolBarUpdateUser.OnNext(Unit.Default);

            // ACT
            testObjects.AddUserResponse.OnError(new Exception("error"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);

            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        #endregion

        #region AdminSerice Update Exisiting User

        [Test]
        public void ShouldSetIsBusyTrue_AddUser_On_UpdateUser_With_ModifyUser()
        {
            var users = new List<User> { new UserBuilder().WithId(10).WithName("user").User() };

            var user = new UserBuilder().WithId(10).User();

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithUserAdminBuilderResult(user)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ACT
            testObjects.ToolBarUpdateUser.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);

            Mock.Get(testObjects.UserAdminBuilder)
                .Verify(b => b.GetUser(It.IsAny<UserDetailsViewModel>(),
                                       It.IsAny<UserPermissionsViewModel>(),
                                       It.IsAny<IEnumerable<CurveGroupItem>>(),
                                       It.IsAny<IEnumerable<CurveRegionItem>>(),
                                       It.IsAny<IEnumerable<FxCurveItem>>(),
                                       10));

            Mock.Get(testObjects.UserAdminUpdateService)
                .Verify(a => a.Update(user, 
                                      It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldRestoreDefaults_And_ShowPopup_On_UpdateUserResponse_Success()
        {
            var users = new List<User> { new UserBuilder().WithId(10).WithName("user").User() };

            var user = new UserBuilder().WithId(10).User();

            var curveGroup = new CurveGroupTestObjectBuilder().Default();
			var curveGroupItems = new[] { new CurveGroupItem(curveGroup) };
            var curveRegionItems = new[] { new CurveRegionItem(CurveRegion.Europe) };
            var fxCurveItems = new[] { new FxCurveItem("name", 50) };

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithCurveGroupItems(curveGroupItems)
                                                                        .WithCurveRegionItems(curveRegionItems)
                                                                        .WithFxCurveItems(fxCurveItems)
                                                                        .WithUserAdminBuilderResult(user)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];
            testObjects.ViewModel.UserDetails.UserName = "user.name";

            Mock.Get(testObjects.ClearUserPermissionsService).Invocations.Clear();
            Mock.Get(testObjects.UserNameValidationService).Invocations.Clear();

            // ARRANGE
            testObjects.ToolBarUpdateUser.OnNext(Unit.Default);

            // ACT
            testObjects.UpdateUserResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);

            Assert.That(testObjects.ViewModel.SelectedUser, Is.Null);
            Assert.That(testObjects.ViewModel.UserDetails.UserName, Is.Null);
            Assert.That(testObjects.ViewModel.UserDetails.DisplayName, Is.Null);

            Assert.That(testObjects.ViewModel.IsAddNewUser, Is.True);
            Assert.That(testObjects.ViewModel.AddUserNameRequired, Is.True);
            Assert.That(testObjects.ViewModel.AddDisplayNameRequired, Is.True);
            Assert.That(testObjects.ViewModel.CanEditUserDetailsAndItems, Is.True);
            Assert.That(testObjects.ViewModel.UserPermissions.IsEnabled, Is.True);

            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.DisposeSubscription());

            Mock.Get(testObjects.ClearUserPermissionsService)
                .Verify(c => c.Clear(testObjects.ViewModel.UserPermissions,
                                     curveGroupItems,
                                     curveRegionItems,
                                     fxCurveItems));
            string errors;

            Mock.Get(testObjects.UserNameValidationService)
                .Verify(v => v.ValidateUserName(null, true, 0, users, out errors));

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdateUser(false));

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldSetIsBusyFalse_And_ShowMessageBox_On_UpdateUserResponse_Error()
        {
            var users = new List<User> { new UserBuilder().WithId(10).WithName("user").User() };

            var user = new UserBuilder().WithId(10).User();

            var testObjects = new UserAdminControllerTestObjectBuilder().WithUsers(users)
                                                                        .WithDefaultFxCurveDefinitions()
                                                                        .WithUserAdminBuilderResult(user)
                                                                        .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsAddNewUser = false;
            testObjects.ViewModel.SelectedUser = testObjects.ViewModel.Users[0];

            // ARRANGE
            testObjects.ToolBarUpdateUser.OnNext(Unit.Default);

            // ACT
            testObjects.UpdateUserResponse.OnError(new Exception("error"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);

            Mock.Get(testObjects.MessageDialogService)
                .Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        #endregion

        #region Dispose

        [Test]
        public void ShouldDisposeChangeSubscription_When_Dispose()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_AlreadyDisposed()
        {
            var testObjects = new UserAdminControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.Controller.Dispose();
            Mock.Get(testObjects.ChangeSubscription).Invocations.Clear();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.ChangeSubscription)
                .Verify(c => c.Dispose(), Times.Never);
        }

        #endregion
    }
}
