﻿using NUnit.Framework;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    [TestFixture]
    public class CopyFromUserServiceTests
    {
        [Test]
        public void ShouldCopyUserDetailsAndItems_From_User()
        {
            var viewModel = new UserAdminViewModel();

            var curveGroupCrude = new CurveGroupTestObjectBuilder().Crude();
            var curveGroupFuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var authorisationUserPermissions = new[]
                              {
                                  new AuthorisationUserPermission(0, PermissionCategory.EomRoll.ToString(), 99, true),
                                  new AuthorisationUserPermission(0, PermissionCategory.BetaUser.ToString(), 99, true),
                                  new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 99, true),
                                  new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 99, true)
                              };

            var curveGroupItems = new[]
                                  {
                                      new CurveGroupItem(curveGroupCrude),
                                      new CurveGroupItem(curveGroupFuelOil)
                                  };

            var curveRegionItems = new[]
                                   {
                                       new CurveRegionItem(CurveRegion.Europe),
                                       new CurveRegionItem(CurveRegion.UnitedStates)
                                   };

            var fxCurveItems = new[]
                               {
                                   new FxCurveItem("item1", 50),
                                   new FxCurveItem("item2", 51)
                               };

            var authorisationCurveGroupCrude = new AuthorisationCurveGroup(curveGroupCrude, true, true);

            var authorisationCurveGroups = new[] { authorisationCurveGroupCrude };

            var authorisationCurveRegionEurope = new AuthorisationCurveRegion(CurveRegion.Europe, true, true);

            var authorisationCurveRegions = new[] { authorisationCurveRegionEurope };

            var authorisationFxCurve = new AuthorisationFxCurve(50, true, true);

            var authorisationFxCurves = new[] { authorisationFxCurve };

            var user = new UserBuilder().WithIsEnabled(true)
                                        .WithIsAdmin(true)
                                        .WithWarnActivityMinutes(30)
                                        .WithErrorActivityMinutes(60)
                                        .WithAuthorisationUserPermissions(authorisationUserPermissions)
                                        .WithAuthorizationCurveGroups(authorisationCurveGroups)
                                        .WithAuthorizationCurveRegions(authorisationCurveRegions)
                                        .WithAuthorizationFxCurve(authorisationFxCurves)
                                        .User();

            var service = new CopyFromUserService();

            // ACT
            service.CopyUserDetailsAndItems(user, 
                                            viewModel.UserPermissions, 
                                            curveGroupItems, 
                                            curveRegionItems, 
                                            fxCurveItems);

            // ASSERT
            Assert.That(viewModel.UserPermissions.IsEnabled, Is.True);
            Assert.That(viewModel.UserPermissions.IsUserAdmin, Is.True);
            Assert.That(viewModel.UserPermissions.IsCurveAdmin, Is.True);
            Assert.That(viewModel.UserPermissions.IsCurveAdminApprover, Is.True);
			Assert.That(viewModel.UserPermissions.WarnAfterInactivityMinutes, Is.EqualTo(30));
            Assert.That(viewModel.UserPermissions.ErrorAfterInactivityMinutes, Is.EqualTo(60));
            Assert.That(viewModel.UserPermissions.IsEomRoll, Is.True);
            Assert.That(viewModel.UserPermissions.IsBetaUser, Is.True);

            Assert.That(curveGroupItems[0].AuthorisationCurveGroup, Is.SameAs(authorisationCurveGroupCrude));
            Assert.That(curveGroupItems[0].CanRead , Is.True);
            Assert.That(curveGroupItems[0].CanUpdate, Is.True);

            Assert.That(curveGroupItems[1].AuthorisationCurveGroup, Is.Null);
            Assert.That(curveGroupItems[1].CanRead, Is.False);
            Assert.That(curveGroupItems[1].CanUpdate, Is.False);

            Assert.That(curveRegionItems[0].AuthorisationCurveRegion, Is.SameAs(authorisationCurveRegionEurope));
            Assert.That(curveRegionItems[0].CanRead, Is.True);
            Assert.That(curveRegionItems[0].CanUpdate, Is.True);

            Assert.That(curveRegionItems[1].AuthorisationCurveRegion, Is.Null);
            Assert.That(curveRegionItems[1].CanRead, Is.False);
            Assert.That(curveRegionItems[1].CanUpdate, Is.False);

            Assert.That(fxCurveItems[0].AuthorisationFxCurve, Is.SameAs(authorisationFxCurve));
            Assert.That(fxCurveItems[0].CanRead, Is.True);
            Assert.That(fxCurveItems[0].CanUpdate, Is.True);

            Assert.That(fxCurveItems[1].AuthorisationFxCurve, Is.Null);
            Assert.That(fxCurveItems[1].CanRead, Is.False);
            Assert.That(fxCurveItems[1].CanUpdate, Is.False);
        }
    }
}
