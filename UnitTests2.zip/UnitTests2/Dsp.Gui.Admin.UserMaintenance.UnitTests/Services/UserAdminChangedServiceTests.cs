﻿using System;
using System.Reactive.Subjects;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using NUnit.Framework;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Moq;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    internal interface IUserAdminChangedServiceTestObjects
    {
        IUserDetailsChangedService UserDetailsChangedService { get; }
        IUserPermissionsChangedService UserPermissionsChangedService { get; }
        ICurveGroupsChangedService CurveGroupsChangedService { get; }
        ICurveRegionsChangedService CurveRegionsChangedService { get; }
        IFxCurvesChangedService FxCurvesChangedService { get; }
        ISubject<bool> UserDetails { get; }
        ISubject<bool> UserPermissions { get; }
        ISubject<bool> CurveGroups { get; }
        ISubject<bool> CurveRegions { get; }
        ISubject<bool> FxCurves { get; }
        UserAdminChangedService UserAdminChangedService { get; }
    }

    [TestFixture]
    public class UserAdminChangedServiceTests
    {
        private class UserAdminChangedServiceTestObjectBuilder
        {
            public IUserAdminChangedServiceTestObjects Build()
            {
                var testObjects = new Mock<IUserAdminChangedServiceTestObjects>();

                var userDetails = new Subject<bool>();

                testObjects.SetupGet(o => o.UserDetails)
                           .Returns(userDetails);

                var userDetailsChangedService = new Mock<IUserDetailsChangedService>();

                userDetailsChangedService.Setup(c => c.ObserveChanges(It.IsAny<UserAdminViewModel>()))
                                         .Returns(userDetails);

                testObjects.SetupGet(o => o.UserDetailsChangedService)
                           .Returns(userDetailsChangedService.Object);

                var userPermissions = new Subject<bool>();

                testObjects.SetupGet(o => o.UserPermissions)
                           .Returns(userPermissions);

                var userPermissionsChangedService = new Mock<IUserPermissionsChangedService>();

                userPermissionsChangedService.Setup(c => c.ObserveChanges(It.IsAny<UserAdminViewModel>()))
                                         .Returns(userPermissions);

                testObjects.SetupGet(o => o.UserPermissionsChangedService)
                           .Returns(userPermissionsChangedService.Object);

                var curveGroups = new BehaviorSubject<bool>(false);

                testObjects.SetupGet(o => o.CurveGroups)
                           .Returns(curveGroups);

                var curveGroupsChangedService = new Mock<ICurveGroupsChangedService>();

                curveGroupsChangedService.Setup(c => c.ObserveChanges(It.IsAny<ICurveGroupItemsDataSource>()))
                                         .Returns(curveGroups);

                testObjects.SetupGet(o => o.CurveGroupsChangedService)
                           .Returns(curveGroupsChangedService.Object);

                var curveRegions = new BehaviorSubject<bool>(false);

                testObjects.SetupGet(o => o.CurveRegions)
                           .Returns(curveRegions);

                var curveRegionsChangedService = new Mock<ICurveRegionsChangedService>();

                curveRegionsChangedService.Setup(c => c.ObserveChanges(It.IsAny<ICurveRegionItemsDataSource>()))
                                          .Returns(curveRegions);

                testObjects.SetupGet(o => o.CurveRegionsChangedService)
                           .Returns(curveRegionsChangedService.Object);

                var fxCurves = new BehaviorSubject<bool>(false);

                testObjects.SetupGet(o => o.FxCurves)
                           .Returns(fxCurves);

                var fxCurvesChangedService = new Mock<IFxCurvesChangedService>();

                fxCurvesChangedService.Setup(c => c.ObserveChanges(It.IsAny<IFxCurveItemsDataSource>()))
                                      .Returns(fxCurves);

                testObjects.SetupGet(o => o.FxCurvesChangedService)
                           .Returns(fxCurvesChangedService.Object);

                var userAdminChangedService = new UserAdminChangedService(userDetailsChangedService.Object,
                                                                          userPermissionsChangedService.Object,
                                                                          curveGroupsChangedService.Object,
                                                                          curveRegionsChangedService.Object,
                                                                          fxCurvesChangedService.Object);

                testObjects.SetupGet(o => o.UserAdminChangedService)
                           .Returns(userAdminChangedService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldObserveChanges()
        {
            var testObjects = new UserAdminChangedServiceTestObjectBuilder().Build();

            // ACT
            testObjects.UserAdminChangedService.ObserveChanges(new UserAdminViewModel(),
                                                               Mock.Of<ICurveGroupItemsDataSource>(),
                                                               Mock.Of<ICurveRegionItemsDataSource>(),
                                                               Mock.Of<IFxCurveItemsDataSource>());
            // ASSERT
            Mock.Get(testObjects.UserDetailsChangedService)
                .Verify(c => c.ObserveChanges(It.IsAny<UserAdminViewModel>()));

            Mock.Get(testObjects.UserPermissionsChangedService)
                .Verify(c => c.ObserveChanges(It.IsAny<UserAdminViewModel>()));

            Mock.Get(testObjects.CurveGroupsChangedService)
                .Verify(c => c.ObserveChanges(It.IsAny<ICurveGroupItemsDataSource>()));

            Mock.Get(testObjects.CurveRegionsChangedService)
                .Verify(c => c.ObserveChanges(It.IsAny<ICurveRegionItemsDataSource>()));

            Mock.Get(testObjects.FxCurvesChangedService)
                .Verify(c => c.ObserveChanges(It.IsAny<IFxCurveItemsDataSource>()));
        }

        [Test]
        public void ShouldPublishFalse_When_ObserverChanges_WithAllChangedFalse()

        {
            var testObjects = new UserAdminChangedServiceTestObjectBuilder().Build();

            var result = new bool?();

            // ACT
            using (testObjects.UserAdminChangedService.ObserveChanges(new UserAdminViewModel(),
                                                                      Mock.Of<ICurveGroupItemsDataSource>(),
                                                                      Mock.Of<ICurveRegionItemsDataSource>(),
                                                                      Mock.Of<IFxCurveItemsDataSource>())
                             .Subscribe(value => result = value))
            {
                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [TestCase(true, false, false, false, false)]
        [TestCase(false, true, false, false, false)]
        [TestCase(false, false, true, false, false)]
        [TestCase(false, false, false, true, false)]
        [TestCase(false, false, false, false, true)]
        public void ShouldPublishTrue_WhenAny_ChangedTrue(bool userDetailsChanged,
                                                          bool userPermissionsChanged,
                                                          bool curveGroupsChanged,
                                                          bool curveRegionsChanged,
                                                          bool fxCurvesChanged)
        {
            var testObjects = new UserAdminChangedServiceTestObjectBuilder().Build();

            var result = new bool?();

            using (testObjects.UserAdminChangedService.ObserveChanges(new UserAdminViewModel(),
                                                                      Mock.Of<ICurveGroupItemsDataSource>(),
                                                                      Mock.Of<ICurveRegionItemsDataSource>(),
                                                                      Mock.Of<IFxCurveItemsDataSource>())
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.UserDetails.OnNext(userDetailsChanged);
                testObjects.UserPermissions.OnNext(userPermissionsChanged);
                testObjects.CurveGroups.OnNext(curveGroupsChanged);
                testObjects.CurveRegions.OnNext(curveRegionsChanged);
                testObjects.FxCurves.OnNext(fxCurvesChanged);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }
    }
}
