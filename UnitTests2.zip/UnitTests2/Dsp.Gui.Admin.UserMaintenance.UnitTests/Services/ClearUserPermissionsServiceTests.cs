﻿using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    [TestFixture]
    public class ClearUserPermissionsServiceTests
    {
        [Test]
        public void ShouldClearUserPermissionsAndItems()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

            var viewModel = new UserAdminViewModel
                            {
                                UserPermissions =
                                {
                                    IsUserAdmin = true,
                                    IsCurveAdmin = true,
                                    IsCurveAdminApprover = true,
                                    IsEnabled = false,
                                    IsEomRoll = true,
                                    IsBetaUser = true,
                                    WarnAfterInactivityMinutes = 30,
                                    ErrorAfterInactivityMinutes = 60
                                }
            };

            var curveGroupItems = new[]
                                  {
                                      new CurveGroupItem(crude)
                                      {
                                          AuthorisationCurveGroup = new AuthorisationCurveGroup(crude, false, false),
                                          CanRead = true,
                                          CanUpdate = true
                                      }
                                  };

            var curveRegionItems = new[]
                                   {
                                       new CurveRegionItem(CurveRegion.Europe)
                                       {
                                           AuthorisationCurveRegion = new AuthorisationCurveRegion(CurveRegion.Europe, false, false),
                                           CanRead = true,
                                           CanUpdate = true
                                       }
                                   };

            var fxCurveItems = new[]
                               {
                                   new FxCurveItem("name", 100)
                                   {
                                       AuthorisationFxCurve = new AuthorisationFxCurve(100, false, false),
                                       CanRead = true,
                                       CanUpdate = true
                                   }
                               };

            var service = new ClearUserPermissionsService();

            // ACT
            service.Clear(viewModel.UserPermissions,
                          curveGroupItems, 
                          curveRegionItems, 
                          fxCurveItems);

            // ASSERT
            Assert.That(viewModel.UserPermissions.IsEnabled, Is.True);
            Assert.That(viewModel.UserPermissions.IsUserAdmin, Is.False);
            Assert.That(viewModel.UserPermissions.IsCurveAdmin, Is.False);
            Assert.That(viewModel.UserPermissions.IsCurveAdminApprover, Is.False);
			Assert.That(viewModel.UserPermissions.IsEomRoll, Is.False);
            Assert.That(viewModel.UserPermissions.IsBetaUser, Is.False);
            Assert.That(viewModel.UserPermissions.WarnAfterInactivityMinutes, Is.EqualTo(0));
            Assert.That(viewModel.UserPermissions.ErrorAfterInactivityMinutes, Is.EqualTo(0));

            Assert.That(curveGroupItems[0].AuthorisationCurveGroup, Is.Null);
            Assert.That(curveGroupItems[0].CanRead, Is.False);
            Assert.That(curveGroupItems[0].CanUpdate, Is.False);

            Assert.That(curveRegionItems[0].AuthorisationCurveRegion, Is.Null);
            Assert.That(curveRegionItems[0].CanRead, Is.False);
            Assert.That(curveRegionItems[0].CanUpdate, Is.False);

            Assert.That(fxCurveItems[0].AuthorisationFxCurve, Is.Null);
            Assert.That(fxCurveItems[0].CanRead, Is.False);
            Assert.That(fxCurveItems[0].CanUpdate, Is.False);
        }
    }
}
