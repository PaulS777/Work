﻿using System;
using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.UnitTest.Helpers.Builders;
using DynamicData;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    internal interface ICurveGroupsChangedServiceTestObjects
    {
        ISubject<IChangeSet<CurveGroupItem>> DataSourceConnect { get; }
        ICurveGroupItemsDataSource DataSource { get; }
        CurveGroupsChangedService CurveGroupsChangedService { get; }
    }

    [TestFixture]
    public class CurveGroupsChangedServiceTests
    {
        private class CurveGroupsChangedServiceTestObjectBuilder
        {
            private IList<Change<CurveGroupItem>> _itemChanges;

            public CurveGroupsChangedServiceTestObjectBuilder WithItemChanges(IList<Change<CurveGroupItem>> values)
            {
                _itemChanges = values;
                return this;
            }

            public ICurveGroupsChangedServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveGroupsChangedServiceTestObjects>();

                var changeSet = new ChangeSet<CurveGroupItem>(_itemChanges);

                var dataSourceConnect = new BehaviorSubject<IChangeSet<CurveGroupItem>>(changeSet);

                testObjects.SetupGet(o => o.DataSourceConnect)
                           .Returns(dataSourceConnect);

                var dataSource = new Mock<ICurveGroupItemsDataSource>();

                dataSource.Setup(d => d.Connect(It.IsAny<Func<CurveGroupItem, bool>>()))
                          .Returns(dataSourceConnect);

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var service = new CurveGroupsChangedService();

                testObjects.SetupGet(o => o.CurveGroupsChangedService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanReadChanged()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var item1 = new CurveGroupItem(crude)
                        {
                            AuthorisationCurveGroup = new AuthorisationCurveGroup(crude, false, false)
                        };

            var item2 = new CurveGroupItem(fuelOil)
                        {
                            AuthorisationCurveGroup = new AuthorisationCurveGroup(fuelOil, false, false)
                        };

            var changes = new Change<CurveGroupItem>[]
                          {
                              new(ListChangeReason.AddRange, [item1, item2])
                          };

            var testObjects = new CurveGroupsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.CurveGroupsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item1.CanRead = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanUpdateChanged()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var item1 = new CurveGroupItem(crude)
                        {
                            AuthorisationCurveGroup = new AuthorisationCurveGroup(crude, false, false)
                        };

            var item2 = new CurveGroupItem(fuelOil)
                        {
                            AuthorisationCurveGroup = new AuthorisationCurveGroup(fuelOil, false, false)
                        };

            var changes = new Change<CurveGroupItem>[]
                          {
                              new(ListChangeReason.AddRange, [item1, item2])
                          };

            var testObjects = new CurveGroupsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.CurveGroupsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item1.CanUpdate = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanReadRevertedToFalse()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();
            var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var item1 = new CurveGroupItem(crude)
                        {
                            AuthorisationCurveGroup = new AuthorisationCurveGroup(crude, false, false)
                        };

            var item2 = new CurveGroupItem(fuelOil)
                        {
                            AuthorisationCurveGroup = new AuthorisationCurveGroup(fuelOil, false, false)
                        };

            var changes = new Change<CurveGroupItem>[]
                          {
                              new(ListChangeReason.AddRange, [item1, item2])
                          };

            var testObjects = new CurveGroupsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.CurveGroupsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {

                item1.CanRead = true;

                // ACT
                item1.CanRead = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanReadTrue_With_AuthorisationCurveGroup_Null()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var item = new CurveGroupItem(crude);

            var changes = new Change<CurveGroupItem>[]
                          {
                              new(ListChangeReason.AddRange, [item])
                          };

            var testObjects = new CurveGroupsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.CurveGroupsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanRead = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanReadFalse_With_AuthorisationCurveGroup_Null()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var item = new CurveGroupItem(crude)
                       {
                           CanRead = true
                       };

            var changes = new Change<CurveGroupItem>[]
                          {
                              new(ListChangeReason.AddRange, [item])
                          };

            var testObjects = new CurveGroupsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.CurveGroupsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanRead = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanUpdateTrue_With_AuthorisationCurveGroup_Null()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var item = new CurveGroupItem(crude);

            var changes = new Change<CurveGroupItem>[]
                          {
                              new(ListChangeReason.AddRange, [item])
                          };

            var testObjects = new CurveGroupsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.CurveGroupsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanUpdate = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanUpdateFalse_With_AuthorisationCurveGroup_Null()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var item = new CurveGroupItem(crude)
                       {
                           CanUpdate = true
                       };

            var changes = new Change<CurveGroupItem>[]
                          {
                              new(ListChangeReason.AddRange, [item])
                          };

            var testObjects = new CurveGroupsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.CurveGroupsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanUpdate = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
