﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    [TestFixture]
    public class DisplayNameValidationServiceTests
    {
        #region Add New User

        [Test]
        public void ShouldReturnFalse_When_Validate_With_DisplayName_Null_NewUserTrue()
        {
            var service = new DisplayNameValidationService();

            // ACT
            var result = service.ValidateDisplayName(null,
                                                     true,
                                                     0,
                                                     Array.Empty<User>(),
                                                     out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(DisplayNameValidationError.DisplayNameCannotBeBlank));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_DisplayName_Blank_NewUserTrue()
        {
            var service = new DisplayNameValidationService();

            // ACT
            var result = service.ValidateDisplayName("  ",
                                                     true,
                                                     0,
                                                     Array.Empty<User>(),
                                                     out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(DisplayNameValidationError.DisplayNameCannotBeBlank));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_Display_MatchesOtherUser_NewUserTrue()
        {
            var users = new[]
                        {
                            new UserBuilder().WithName("name").WithId(11).User()
                        };

            var service = new DisplayNameValidationService();

            // ACT
            var result = service.ValidateDisplayName("name",
                                                     true,
                                                     10,
                                                     users,
                                                     out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(DisplayNameValidationError.DuplicateUser));
        }

        [Test]
        public void ShouldReturnTrue_When_Validate_With_DisplayName_ValidFormat_And_DisplayName_NotMatchesOther_NewUserTrue()
        {
            var users = new[]
                        {
                            new UserBuilder().WithName("other").User()
                        };

            var service = new DisplayNameValidationService();

            // ACT
            var result = service.ValidateDisplayName("name",
                                                     true,
                                                     0,
                                                     users,
                                                     out var error);
            // ASSERT
            Assert.That(result, Is.True);
            Assert.That(error, Is.Null);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_DisplayName_MatchesOtherUser_NewUserFalse()
        {
            var users = new[]
                        {
                            new UserBuilder().WithName("name").WithId(11).User()
                        };

            var service = new DisplayNameValidationService();

            // ACT
            var result = service.ValidateDisplayName("name",
                                                     false,
                                                     10,
                                                     users,
                                                     out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(DisplayNameValidationError.DuplicateUser));
        }

        [Test]
        public void ShouldReturnTrue_When_Validate_With_ValidFormat_And_DisplayName_Match_Only_SelectedUser_NewUserFalse()
        {
            var users = new[]
                        {
                            new UserBuilder().WithName("name").WithId(10).User()
                        };

            var service = new DisplayNameValidationService();

            // ACT
            var result = service.ValidateDisplayName("name", 
                                                     false, 
                                                     10, 
                                                     users, 
                                                     out var error);

            // ASSERT
            Assert.That(result, Is.True);
            Assert.That(error, Is.Null);
        }
        #endregion
    }
}
