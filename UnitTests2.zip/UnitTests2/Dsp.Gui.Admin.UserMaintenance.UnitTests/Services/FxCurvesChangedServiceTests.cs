﻿using System;
using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using DynamicData;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    internal interface IFxCurvesChangedServiceTestObjects
    {
        ISubject<IChangeSet<FxCurveItem>> DataSourceConnect { get; }
        IFxCurveItemsDataSource DataSource { get; }
        FxCurvesChangedService FxCurvesChangedService { get; }
    }

    [TestFixture]
    public class FxCurvesChangedServiceTests
    {
        private class FxCurvesChangedServiceTestObjectBuilder
        {
            private IList<Change<FxCurveItem>> _itemChanges;

            public FxCurvesChangedServiceTestObjectBuilder WithItemChanges(IList<Change<FxCurveItem>> values)
            {
                _itemChanges = values;
                return this;
            }

            public IFxCurvesChangedServiceTestObjects Build()
            {
                var testObjects = new Mock<IFxCurvesChangedServiceTestObjects>();

                var changeSet = new ChangeSet<FxCurveItem>(_itemChanges);

                var dataSourceConnect = new BehaviorSubject<IChangeSet<FxCurveItem>>(changeSet);

                testObjects.SetupGet(o => o.DataSourceConnect)
                           .Returns(dataSourceConnect);

                var dataSource = new Mock<IFxCurveItemsDataSource>();

                dataSource.Setup(d => d.Connect(It.IsAny<Func<FxCurveItem, bool>>()))
                          .Returns(dataSourceConnect);

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var service = new FxCurvesChangedService();

                testObjects.SetupGet(o => o.FxCurvesChangedService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanReadChanged()
        {
            var item1 = new FxCurveItem("fx1", 51)
            {
                AuthorisationFxCurve = new AuthorisationFxCurve(51, false, false)
            };

            var item2 = new FxCurveItem("fx2", 52)
            {
                AuthorisationFxCurve = new AuthorisationFxCurve(52, false, false)
            };

            var changes = new Change<FxCurveItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item1, item2 })
                          };

            var testObjects = new FxCurvesChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.FxCurvesChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item1.CanRead = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanUpdateChanged()
        {
            var item1 = new FxCurveItem("fx1", 51)
            {
                AuthorisationFxCurve = new AuthorisationFxCurve(51, false, false)
            };

            var item2 = new FxCurveItem("fx2", 52)
            {
                AuthorisationFxCurve = new AuthorisationFxCurve(52, false, false)
            };

            var changes = new Change<FxCurveItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item1, item2 })
                          };

            var testObjects = new FxCurvesChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.FxCurvesChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item1.CanUpdate = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanReadRevertedToFalse()
        {
            var item1 = new FxCurveItem("fx1", 51)
            {
                AuthorisationFxCurve = new AuthorisationFxCurve(51, false, false)
            };

            var item2 = new FxCurveItem("fx2", 52)
            {
                AuthorisationFxCurve = new AuthorisationFxCurve(52, false, false)
            };

            var changes = new Change<FxCurveItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item1, item2 })
                          };

            var testObjects = new FxCurvesChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.FxCurvesChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {

                item1.CanRead = true;

                // ACT
                item1.CanRead = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanReadTrue_With_AuthorisationFxCurve_Null()
        {
            var item = new FxCurveItem("fx1", 51);

            var changes = new Change<FxCurveItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item })
                          };

            var testObjects = new FxCurvesChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                           .Build();

            var result = new bool?();

            using (testObjects.FxCurvesChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanRead = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanReadFalse_With_AuthorisationFxCurve_Null()
        {
            var item = new FxCurveItem("fx1", 51)
            {
                CanRead = true
            };

            var changes = new Change<FxCurveItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item })
                          };

            var testObjects = new FxCurvesChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                           .Build();

            var result = new bool?();

            using (testObjects.FxCurvesChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanRead = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanUpdateTrue_With_AuthorisationFxCurve_Null()
        {
            var item = new FxCurveItem("fx1", 51);

            var changes = new Change<FxCurveItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item })
                          };

            var testObjects = new FxCurvesChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                           .Build();

            var result = new bool?();

            using (testObjects.FxCurvesChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanUpdate = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanUpdateFalse_With_AuthorisationFxCurve_Null()
        {
            var item = new FxCurveItem("fx1", 51)
            {
                CanUpdate = true
            };

            var changes = new Change<FxCurveItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item })
                          };

            var testObjects = new FxCurvesChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                           .Build();

            var result = new bool?();

            using (testObjects.FxCurvesChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanUpdate = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
