﻿using System;
using System.Collections.Generic;
using Moq;
using NUnit.Framework;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using DynamicData;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    internal interface ICurveRegionsChangedServiceTestObjects
    {
        ISubject<IChangeSet<CurveRegionItem>> DataSourceConnect { get; }
        ICurveRegionItemsDataSource DataSource { get; }
        CurveRegionsChangedService CurveRegionsChangedService { get; }
    }

    [TestFixture]
    public class CurveRegionsChangedServiceTests
    {
        private class CurveRegionsChangedServiceTestObjectBuilder
        {
            private IList<Change<CurveRegionItem>> _itemChanges;

            public CurveRegionsChangedServiceTestObjectBuilder WithItemChanges(IList<Change<CurveRegionItem>> values)
            {
                _itemChanges = values;
                return this;
            }

            public ICurveRegionsChangedServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurveRegionsChangedServiceTestObjects>();

                var changeSet = new ChangeSet<CurveRegionItem>(_itemChanges);

                var dataSourceConnect = new BehaviorSubject<IChangeSet<CurveRegionItem>>(changeSet);

                testObjects.SetupGet(o => o.DataSourceConnect)
                           .Returns(dataSourceConnect);

                var dataSource = new Mock<ICurveRegionItemsDataSource>();

                dataSource.Setup(d => d.Connect(It.IsAny<Func<CurveRegionItem, bool>>()))
                          .Returns(dataSourceConnect);

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var service = new CurveRegionsChangedService();

                testObjects.SetupGet(o => o.CurveRegionsChangedService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanReadChanged()
        {
            var item1 = new CurveRegionItem(CurveRegion.Europe)
            {
                AuthorisationCurveRegion = new AuthorisationCurveRegion(CurveRegion.Europe, false, false)
            };

            var item2 = new CurveRegionItem(CurveRegion.UnitedStates)
            {
                AuthorisationCurveRegion = new AuthorisationCurveRegion(CurveRegion.UnitedStates, false, false)
            };

            var changes = new Change<CurveRegionItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item1, item2 })
                          };

            var testObjects = new CurveRegionsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                               .Build();

            var result = new bool?();

            using (testObjects.CurveRegionsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item1.CanRead = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanUpdateChanged()
        {
            var item1 = new CurveRegionItem(CurveRegion.Europe)
            {
                AuthorisationCurveRegion = new AuthorisationCurveRegion(CurveRegion.Europe, false, false)
            };

            var item2 = new CurveRegionItem(CurveRegion.UnitedStates)
            {
                AuthorisationCurveRegion = new AuthorisationCurveRegion(CurveRegion.UnitedStates, false, false)
            };

            var changes = new Change<CurveRegionItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item1, item2 })
                          };

            var testObjects = new CurveRegionsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                               .Build();

            var result = new bool?();

            using (testObjects.CurveRegionsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item1.CanUpdate = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanReadRevertedToFalse()
        {
            var item1 = new CurveRegionItem(CurveRegion.Europe)
            {
                AuthorisationCurveRegion = new AuthorisationCurveRegion(CurveRegion.Europe, false, false)
            };

            var item2 = new CurveRegionItem(CurveRegion.UnitedStates)
            {
                AuthorisationCurveRegion = new AuthorisationCurveRegion(CurveRegion.UnitedStates, false, false)
            };

            var changes = new Change<CurveRegionItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item1, item2 })
                          };

            var testObjects = new CurveRegionsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                               .Build();

            var result = new bool?();

            using (testObjects.CurveRegionsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {

                item1.CanRead = true;

                // ACT
                item1.CanRead = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanReadTrue_With_AuthorisationCurveRegion_Null()
        {
            var item = new CurveRegionItem(CurveRegion.Europe);

            var changes = new Change<CurveRegionItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item })
                          };

            var testObjects = new CurveRegionsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                              .Build();

            var result = new bool?();

            using (testObjects.CurveRegionsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanRead = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanReadFalse_With_AuthorisationCurveRegion_Null()
        {
            var item = new CurveRegionItem(CurveRegion.Europe)
            {
                CanRead = true
            };

            var changes = new Change<CurveRegionItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item })
                          };

            var testObjects = new CurveRegionsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                               .Build();

            var result = new bool?();

            using (testObjects.CurveRegionsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanRead = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_ItemCanUpdateTrue_With_AuthorisationCurveRegionNull()
        {
            var item = new CurveRegionItem(CurveRegion.Europe);

            var changes = new Change<CurveRegionItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item })
                          };

            var testObjects = new CurveRegionsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                               .Build();

            var result = new bool?();

            using (testObjects.CurveRegionsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanUpdate = true;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_ItemCanUpdateFalse_With_AuthorisationCurveRegion_Null()
        {
            var item = new CurveRegionItem(CurveRegion.Europe)
            {
                CanUpdate = true
            };

            var changes = new Change<CurveRegionItem>[]
                          {
                              new(ListChangeReason.AddRange, new[] { item })
                          };

            var testObjects = new CurveRegionsChangedServiceTestObjectBuilder().WithItemChanges(changes)
                                                                               .Build();

            var result = new bool?();

            using (testObjects.CurveRegionsChangedService
                              .ObserveChanges(testObjects.DataSource)
                              .Subscribe(value => result = value))
            {
                // ACT
                item.CanUpdate = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
