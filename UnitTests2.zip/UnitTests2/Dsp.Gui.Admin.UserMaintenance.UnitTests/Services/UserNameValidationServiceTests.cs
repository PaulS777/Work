﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    [TestFixture]
    public class UserNameValidationServiceTests
    {
        [Test]
        public void ShouldReturnFalse_When_Validate_With_UserName_Null()
        {
            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName(null,
                                                  true,
                                                  0, 
                                                  Array.Empty<User>(), 
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.UserNameCannotBeBlank));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UserName_Blank()
        {
            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("  ",
                                                  true, 
                                                  0,
                                                  Array.Empty<User>(),
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.UserNameCannotBeBlank));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UserName_MissingDotSeparator()
        {
            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("user",
                                                  true, 
                                                  0,
                                                  Array.Empty<User>(), 
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.InvalidFormatMissingOrInvalidDelimiter));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UserName_StartsWithDotSeparator()
        {
            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName(".user", 
                                                  true, 
                                                  0, 
                                                  Array.Empty<User>(), 
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.InvalidFormatMissingOrInvalidDelimiter));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UserName_EndsWithDotSeparator()
        {
            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("user.",
                                                  true, 
                                                  0,
                                                  Array.Empty<User>(),
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.InvalidFormatMissingOrInvalidDelimiter));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UserName_ContainsSpace()
        {
            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("user. name",
                                                  true,
                                                  0,
                                                  Array.Empty<User>(),
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.InvalidFormatMustNotContainSpaces));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_ContiguousDotSeparator()
        {
            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("user..name",
                                                  true,
                                                  0,
                                                  Array.Empty<User>(),
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.InvalidFormatMissingOrInvalidDelimiter));
        }

        #region Add New User

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UserName_MatchesOtherUser_NewUserTrue()
        {
            var users = new[]
                        {
                            new UserBuilder().WithUserName("user.name").WithId(11).User()
                        };

            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("user.Name", 
                                                  true, 
                                                  10, 
                                                  users,
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.DuplicateUser));
        }

        [Test]
        public void ShouldReturnTrue_When_Validate_With_UserName_ValidFormat_And_UserName_NotMatchesOther_NewUserTrue()
        {
            var users = new[]
                        {
                            new UserBuilder().WithUserName("other.user").User()
                        };

            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("user.Name", 
                                                  true,
                                                  0, 
                                                  users, 
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.True);
            Assert.That(error, Is.Null);
        }

        #endregion

        #region Modify User

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UserName_MatchesOtherUser_NewUserFalse()
        {
            var users = new[]
                        {
                            new UserBuilder().WithUserName("user.name").WithId(11).User()
                        };

            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("user.name",
                                                  false, 
                                                  10,
                                                  users, 
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.False);
            Assert.That(error, Is.EqualTo(UserNameValidationError.DuplicateUser));
        }

        [Test]
        public void ShouldReturnTrue_When_Validate_With_ValidFormat_And_UserName_Match_Only_SelectedUser_NewUserFalse()
        {
            var users = new[]
                        {
                            new UserBuilder().WithUserName("user.name").WithId(10).User()
                        };

            var service = new UserNameValidationService();

            // ACT
            var result = service.ValidateUserName("user.name",
                                                  false, 
                                                  10, 
                                                  users,
                                                  out var error);

            // ASSERT
            Assert.That(result, Is.True);
            Assert.That(error, Is.Null);
        }

        #endregion
    }
}
