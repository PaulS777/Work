﻿using NUnit.Framework;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using System.Linq;
using Dsp.Gui.UnitTest.Helpers.Builders;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    [TestFixture]
    public class UserAdminBuilderTests
    {
        [Test]
        public void ShouldGetUser()
        {
            var userDetails = new UserDetailsViewModel
                              {
                                  UserName = "user.name",
                                  DisplayName = "name"
                              };

            var permissionsViewModel = new UserPermissionsViewModel 
                                       {
                                           IsUserAdmin = true,
                                           IsEnabled = true,
                                           IsCurveAdmin = true,
                                           IsCurveAdminApprover = true,
                                           WarnAfterInactivityMinutes = 30,
                                           ErrorAfterInactivityMinutes = 60,
                                           IsEomRoll = true,
                                           IsBetaUser = true,
                                       };

            var curveGroupsItems = new[] { 
                                             new CurveGroupItem(new CurveGroupTestObjectBuilder().Default())
                                             {
                                                 CanRead = true, CanUpdate = true
                                             }
                                         };

            var curveRegionsItems = new[]
                                    {
                                        new CurveRegionItem(CurveRegion.Europe)
                                        {
                                            CanRead = true, CanUpdate = true
                                        }
                                    };

            var fxCurveItems = new[]
                               {
                                   new FxCurveItem("fx", 51)
                                   {
                                       CanRead = true, CanUpdate = true
                                   }
                               };

            var builder = new UserAdminBuilder();

            // ACT
            var result = builder.GetUser(userDetails,
                                         permissionsViewModel, 
                                         curveGroupsItems, 
                                         curveRegionsItems,
                                         fxCurveItems, 
                                         10);
            // ASSERT
            Assert.That(result.Id, Is.EqualTo(10));
            Assert.That(result.UserName, Is.EqualTo("user.name"));
            Assert.That(result.DisplayName, Is.EqualTo("name"));
            Assert.That(result.IsEnabled, Is.True);
            Assert.That(result.IsAdmin, Is.True);
            Assert.That(result.WarnAfterInactivityMinutes, Is.EqualTo(30));
            Assert.That(result.ErrorAfterInactivityMinutes, Is.EqualTo(60));
            Assert.That(result.AuthorisationUserPermissions.Any(x => x.CategoryName == PermissionCategory.EomRoll.ToString() && x.Value), Is.True);
            Assert.That(result.AuthorisationUserPermissions.Any(x => x.CategoryName == PermissionCategory.BetaUser.ToString() && x.Value), Is.True);
            Assert.That(result.AuthorisationUserPermissions.Any(x => x.CategoryName == PermissionCategory.CurveAdmin.ToString() && x.Value), Is.True);
            Assert.That(result.AuthorisationUserPermissions.Any(x => x.CategoryName == PermissionCategory.CurveAdminApprover.ToString() && x.Value), Is.True);
		}
    }
}
