﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    [TestFixture]
    public class UserPermissionsChangedServiceTests
    {
        [Test]
        public void ShouldPublishTrue_When_IsEnabled_Changed()
        {
            var user = new UserBuilder().WithIsEnabled(true).User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.IsEnabled = false;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_IsAdmin_Changed()
        {
            var user = new UserBuilder().WithIsAdmin(true).User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.IsUserAdmin = false;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_IsCurveAdmin_Changed()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 0, true)])
                                        .User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.IsCurveAdmin = false;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_IsCurveAdminApprover_Changed()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 0, true)])
                                        .User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.IsCurveAdmin = false;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

		[Test]
        public void ShouldPublishTrue_When_IsEomRoll_Changed()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.EomRoll.ToString(), 0, true)])
                                        .User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.IsEomRoll = false;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_IsBetaUser_Changed()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.BetaUser.ToString(), 0, true)])
                                        .User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.IsBetaUser = false;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_WarnAfterInactivityMinutes_Changed()
        {
            var user = new UserBuilder().WithWarnActivityMinutes(30).User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.WarnAfterInactivityMinutes = 10;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_ErrorAfterInactivityMinutes_Changed()
        {
            var user = new UserBuilder().WithErrorActivityMinutes(60).User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.ErrorAfterInactivityMinutes = 50;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_IsEnabled_Change_Reverted()
        {
            var user = new UserBuilder().WithIsEnabled(true).User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserPermissions.IsEnabled = false;

                // ACT
                viewModel.UserPermissions.IsEnabled = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_IsAdmin_Change_Reverted()
        {
            var user = new UserBuilder().WithIsAdmin(true).User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserPermissions.IsUserAdmin = false;

                // ACT
                viewModel.UserPermissions.IsUserAdmin = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_IsCurveAdmin_Change_Reverted()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 0, true)])
                                        .User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserPermissions.IsCurveAdmin = false;

                // ACT
				viewModel.UserPermissions.IsCurveAdmin = true;

				// ASSERT
				Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_IsCurveAdminApprover_Change_Reverted()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 0, true)])
                                        .User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserPermissions.IsCurveAdminApprover = false;

                // ACT
                viewModel.UserPermissions.IsCurveAdminApprover = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

		[Test]
        public void ShouldPublishFalse_When_IsEomRoll_Change_Reverted()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.EomRoll.ToString(), 0, true)])
                                        .User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserPermissions.IsEomRoll = false;

                // ACT
                viewModel.UserPermissions.IsEomRoll = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_IsBetaUser_Change_Reverted()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.BetaUser.ToString(), 0, true)])
                                        .User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserPermissions.IsBetaUser = false;

                // ACT
                viewModel.UserPermissions.IsBetaUser = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_WarnAfterInactivityMinutes_Change_Reverted()
        {
            var user = new UserBuilder().WithWarnActivityMinutes(30).User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserPermissions.WarnAfterInactivityMinutes = 10;

                // ACT
                viewModel.UserPermissions.WarnAfterInactivityMinutes = 30;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_ErrorAfterInactivityMinutes_Change_Reverted()
        {
            var user = new UserBuilder().WithErrorActivityMinutes(60).User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserPermissions.ErrorAfterInactivityMinutes = 50;

                // ACT
                viewModel.UserPermissions.ErrorAfterInactivityMinutes = 60;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotPublishTrue_When_SelectedUser_Null()
        {
            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = null
                            };

            var service = new UserPermissionsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserPermissions.IsEnabled = false;

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
