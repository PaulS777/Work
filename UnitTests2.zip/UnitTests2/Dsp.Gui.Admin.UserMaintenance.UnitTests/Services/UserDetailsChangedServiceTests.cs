﻿using System;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using NUnit.Framework;


namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    [TestFixture]
    public class UserDetailsChangedServiceTests
    {
        [Test]
        public void ShouldPublishTrue_When_UserName_Changed()
        {
            var user = new UserBuilder().WithUserName("user-name").User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserDetailsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserDetails.UserName = "user-name-2";

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_When_DisplayName_Changed()
        {
            var user = new UserBuilder().WithName("name").User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserDetailsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserDetails.DisplayName = "name-2";

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_UserName_Change_Reverted()
        {
            var user = new UserBuilder().WithUserName("user-name").User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserDetailsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserDetails.UserName = "user-name-2";

                // ACT
                viewModel.UserDetails.UserName = "user-name";

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_Name_Change_Reverted()
        {
            var user = new UserBuilder().WithName("name").User();

            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = user
                            };

            var service = new UserDetailsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                viewModel.UserDetails.DisplayName = "name-2";

                // ACT
                viewModel.UserDetails.DisplayName = "name";

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_When_SelectedUser_Null()
        {
            var viewModel = new UserAdminViewModel
                            {
                                SelectedUser = null
                            };

            var service = new UserDetailsChangedService();

            bool? result = null;

            using (service.ObserveChanges(viewModel).Subscribe(value => result = value))
            {
                // ACT
                viewModel.UserDetails.UserName = "user-name-2";

                // ASSERT
                Assert.That(result, Is.Null);
            }
        }
    }
}
