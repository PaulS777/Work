﻿using NUnit.Framework;
using Dsp.Gui.Admin.UserMaintenance.Services;

namespace Dsp.Gui.Admin.UserMaintenance.UnitTests.Services
{
    [TestFixture]
    public class DisplayNameParserTests
    {
        [Test]
        public void ShouldReturnParsedName()
        {
            var parser = new DisplayNameParser();

            // ACT
            var result = parser.ParseFromUserName("user.name");

            // ASSERT
            Assert.That(result, Is.EqualTo("User Name"));
        }

        [Test]
        public void ShouldReturnParsedName_With_Initial_Mid()
        {
            var parser = new DisplayNameParser();

            // ACT
            var result = parser.ParseFromUserName("user.i.name");

            // ASSERT
            Assert.That(result, Is.EqualTo("User I Name"));
        }

        [Test]
        public void ShouldReturnParsedName_With_Spaces()
        {
            var parser = new DisplayNameParser();

            // ACT
            var result = parser.ParseFromUserName(" user.i.name ");

            // ASSERT
            Assert.That(result, Is.EqualTo("User I Name"));
        }

        [Test]
        public void ShouldReturnNull_With_InvalidFormat()
        {
            var parser = new DisplayNameParser();

            // ACT
            var result = parser.ParseFromUserName("user..name ");

            // ASSERT
            Assert.That(result, Is.Null);
        }
    }
}
