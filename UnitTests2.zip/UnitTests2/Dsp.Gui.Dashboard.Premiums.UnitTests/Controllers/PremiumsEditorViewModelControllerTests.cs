﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Premiums.Controllers;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Controllers
{
    internal interface IPremiumsEditorViewModelControllerTestObjects
    {
        IPremiumsEditorToolBarService ToolBarService { get; }
        IFeesAndPremiumsProvider FeesAndPremiumsProvider { get; }
        IPriceCurveFeesService PriceCurveFeesService { get; }
        IPremiumThresholdRowService VolumePremiumRowService { get; }
        IPremiumThresholdRowService ValidityPremiumRowService { get; }
        IPremiumRowSortingService VolumePremiumRowSortingService { get; }
        IPremiumRowSortingService ValidityPremiumRowSortingService { get; }
        IPremiumRowsAddEnabledService VolumePremiumsAddEnabledService { get; }
        IPremiumRowsAddEnabledService ValidityPremiumsAddEnabledService { get; }
        IPremiumRowsDeleteEnabledService VolumePremiumsDeleteEnabledService { get; }
        IPremiumsEditorToolBarCalculator ToolBarCalculator { get; }
        IPriceCurvePremiumBuilder PriceCurvePremiumBuilder { get; }
        IPriceCurvePremiumUpdateService PriceCurvePremiumUpdateService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        ISubject<List<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        ISubject<List<PriceCurvePremium>> PriceCurvePremiums { get; }
        ISubject<IList<IPremiumThresholdItem>> SortedVolumePremiums { get; }
        ISubject<IList<IPremiumThresholdItem>> SortedValidityPremiums { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        ISubject<Unit> ToolBarUndo { get; }
        ISubject<Unit> PriceCurvePremiumUpdateResponse { get; }
        PremiumsEditorViewModel ViewModel { get; }
        PremiumsEditorViewModelController Controller { get; }
    }

    [TestFixture]
    public class PremiumsEditorViewModelControllerTests
    {
        private class PremiumsEditorViewModelControllerTestObjectBuilder
        {
            private int _priceCurveId;
            private int _feesCurveId;
            private List<PriceCurveDefinition> _priceCurveDefinitions;
            private List<PriceCurvePremium> _priceCurvePremiums;
            private VolumePremiumItemViewModel _newVolumePremiumItem;
            private ValidityPremiumItemViewModel _newValidityPremiumItem;

            public PremiumsEditorViewModelControllerTestObjectBuilder WithPriceCurveId(int value)
            {
                _priceCurveId = value;
                return this;
            }

            public PremiumsEditorViewModelControllerTestObjectBuilder WithFeesCurveId(int value)
            {
                _feesCurveId = value;
                return this;
            }

            public PremiumsEditorViewModelControllerTestObjectBuilder WithPriceCurveDefinitions(List<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public PremiumsEditorViewModelControllerTestObjectBuilder WithPriceCurvePremiums(List<PriceCurvePremium> values)
            {
                _priceCurvePremiums = values;
                return this;
            }

            public PremiumsEditorViewModelControllerTestObjectBuilder WithNewVolumePremiumRow(VolumePremiumItemViewModel value)
            {
                _newVolumePremiumItem = value;
                return this;
            }

            public PremiumsEditorViewModelControllerTestObjectBuilder WithNewValidityPremiumRow(ValidityPremiumItemViewModel value)
            {
                _newValidityPremiumItem = value;
                return this;
            }

            public IPremiumsEditorViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IPremiumsEditorViewModelControllerTestObjects>();

                var priceCurveDefinitions = new BehaviorSubject<List<PriceCurveDefinition>>(_priceCurveDefinitions);

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurveDefinitions);

                var priceCurvePremiums = new BehaviorSubject<List<PriceCurvePremium>>(_priceCurvePremiums);

                testObjects.SetupGet(o => o.PriceCurvePremiums)
                           .Returns(priceCurvePremiums);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.PriceCurvePremiums)
                                   .Returns(priceCurvePremiums);

                var userPriceCurveDefinitionsProvider = new Mock<IUserPriceCurvePermissionsService>();

                userPriceCurveDefinitionsProvider.Setup(p => p.GetUserPriceCurveDefinitions())
                                                 .Returns(priceCurveDefinitions);

                var toolBarUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUpdate)
                           .Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUndo)
                           .Returns(toolBarUndo);

                var toolBarService = new Mock<IPremiumsEditorToolBarService>();

                toolBarService.SetupGet(t => t.Update)
                              .Returns(toolBarUpdate);

                toolBarService.SetupGet(t => t.Undo)
                              .Returns(toolBarUndo);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBarService.Object);

                var feesAndPremiumsProvider = new Mock<IFeesAndPremiumsProvider>();

                feesAndPremiumsProvider.Setup(p => p.CreateNewVolumePremiumRow())
                                       .Returns(_newVolumePremiumItem);

                feesAndPremiumsProvider.Setup(p => p.CreateNewValidityPremiumRow())
                                       .Returns(_newValidityPremiumItem);

                testObjects.SetupGet(o => o.FeesAndPremiumsProvider)
                           .Returns(feesAndPremiumsProvider.Object);

                var priceCurveFeesService = new Mock<IPriceCurveFeesService>();

                testObjects.SetupGet(o => o.PriceCurveFeesService)
                           .Returns(priceCurveFeesService.Object);

                var volumePremiumRowService = new Mock<IPremiumThresholdRowService>();

                testObjects.SetupGet(o => o.VolumePremiumRowService)
                           .Returns(volumePremiumRowService.Object);

                var validityPremiumRowService = new Mock<IPremiumThresholdRowService>();

                testObjects.SetupGet(o => o.ValidityPremiumRowService)
                           .Returns(validityPremiumRowService.Object);

                var volumePremiumsRowsSortOrder = new Subject<IList<IPremiumThresholdItem>>();

                testObjects.SetupGet(o => o.SortedVolumePremiums)
                           .Returns(volumePremiumsRowsSortOrder);

                var volumePremiumSortingService = new Mock<IPremiumRowSortingService>();

                volumePremiumSortingService.SetupGet(s => s.RowsSorted)
                                           .Returns(volumePremiumsRowsSortOrder);

                testObjects.SetupGet(o => o.VolumePremiumRowSortingService)
                           .Returns(volumePremiumSortingService.Object);

                var validityPremiumsRowsSortOrder = new Subject<IList<IPremiumThresholdItem>>();

                testObjects.SetupGet(o => o.SortedValidityPremiums)
                           .Returns(validityPremiumsRowsSortOrder);

                var validityPremiumSortingService = new Mock<IPremiumRowSortingService>();

                validityPremiumSortingService.SetupGet(s => s.RowsSorted)
                                             .Returns(validityPremiumsRowsSortOrder);

                testObjects.SetupGet(o => o.ValidityPremiumRowSortingService)
                           .Returns(validityPremiumSortingService.Object);

                var toolBarCalculator = new Mock<IPremiumsEditorToolBarCalculator>();

                testObjects.SetupGet(o => o.ToolBarCalculator)
                           .Returns(toolBarCalculator.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var priceCurvePremiumUpdateResponse = new Subject<Unit>();

                testObjects.SetupGet(o => o.PriceCurvePremiumUpdateResponse)
                           .Returns(priceCurvePremiumUpdateResponse);

                var priceCurvePremiumUpdateService = new Mock<IPriceCurvePremiumUpdateService>();

                priceCurvePremiumUpdateService.Setup(p => p.Update(It.IsAny<PriceCurvePremium>(),
                                                                   It.IsAny<IScheduler>()))
                                              .Returns(priceCurvePremiumUpdateResponse);

                testObjects.SetupGet(o => o.PriceCurvePremiumUpdateService)
                           .Returns(priceCurvePremiumUpdateService.Object);

                var volumePremiumsAddEnabledService = new Mock<IPremiumRowsAddEnabledService>();

                testObjects.SetupGet(o => o.VolumePremiumsAddEnabledService)
                           .Returns(volumePremiumsAddEnabledService.Object);

                var validityPremiumsAddEnabledService = new Mock<IPremiumRowsAddEnabledService>();

                testObjects.SetupGet(o => o.ValidityPremiumsAddEnabledService)
                           .Returns(validityPremiumsAddEnabledService.Object);

                var volumePremiumDeleteEnabledService = new Mock<IPremiumRowsDeleteEnabledService>();

                testObjects.SetupGet(o => o.VolumePremiumsDeleteEnabledService)
                           .Returns(volumePremiumDeleteEnabledService.Object);

                var priceCurvePremiumBuilder = new Mock<IPriceCurvePremiumBuilder>();

                testObjects.SetupGet(o => o.PriceCurvePremiumBuilder)
                           .Returns(priceCurvePremiumBuilder.Object);

                var controller = new PremiumsEditorViewModelController(curveControlService.Object,
                                                                       userPriceCurveDefinitionsProvider.Object,
                                                                       toolBarService.Object,
                                                                       priceCurveFeesService.Object,
                                                                       volumePremiumRowService.Object,
                                                                       validityPremiumRowService.Object,
                                                                       volumePremiumSortingService.Object,
                                                                       validityPremiumSortingService.Object,
                                                                       volumePremiumsAddEnabledService.Object,
                                                                       validityPremiumsAddEnabledService.Object,
                                                                       volumePremiumDeleteEnabledService.Object,
                                                                       toolBarCalculator.Object,
                                                                       TestMocks.GetSchedulerProvider().Object,
                                                                       TestMocks.GetLoggerFactory().Object)
                {
                    FeesAndPremiumsProvider = feesAndPremiumsProvider.Object,
                    PriceCurvePremiumUpdateService = priceCurvePremiumUpdateService.Object,
                    PopupNotificationService = popupNotificationService.Object,
                    ErrorMessageDialogService = errorMessageDialogService.Object,
                    PriceCurvePremiumBuilder = priceCurvePremiumBuilder.Object
                };

                var model = new PriceCurvePremium(_priceCurveId, 
                                                  Array.Empty<VolumePremium>(),
                                                  Array.Empty<ValidityPremium>(),
                                                  new PriceCurveFees(_feesCurveId, 0, 0, 0, 0, 0));

                controller.ViewModel.SetModel(model);

                feesAndPremiumsProvider.Setup(p => p.UpdateFeesAndPremiums(It.IsAny<PremiumsEditorViewModel>(),
                                                                           It.IsAny<PriceCurvePremium>(), 
                                                                           It.IsAny<int>()))
                                       .Callback<PremiumsEditorViewModel, PriceCurvePremium, int>(
                                            (_, priceCurvePremium, _) =>
                                            {
                                                controller.ViewModel.SetModel(priceCurvePremium);
                                            });

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetPriceCurveDefinitionItems_From_UserPriceCurveDefinitions()
        {
            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(1)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(2)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .Build();

            var priceCurves = new List<PriceCurveDefinition> { priceCurve1, priceCurve2 };

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.PriceCurveDefinitions.OnNext(priceCurves);

            // ASSERT
            Assert.That(testObjects.ViewModel.PriceCurveDefinitions.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldPopulateVolumePremiums_From_SortedVolumePremiums()
        {
            var volumePremiums = new List<IPremiumThresholdItem>
            {
                new VolumePremiumItemViewModel(Mock.Of<IDisposable>()) {Threshold = 1000},
                new VolumePremiumItemViewModel(Mock.Of<IDisposable>()) {Threshold = 2000}
            };

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.SortedVolumePremiums.OnNext(volumePremiums);

            // ASSERT
            Assert.That(testObjects.ViewModel.VolumePremiums.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.VolumePremiums[0].Threshold, Is.EqualTo(1000));
            Assert.That(testObjects.ViewModel.VolumePremiums[1].Threshold, Is.EqualTo(2000));
        }

        [Test]
        public void ShouldPopulateValidityPremiums_From_SortedValidityPremiums()
        {
            var validityPremiums = new List<IPremiumThresholdItem>
            {
                new ValidityPremiumItemViewModel(Mock.Of<IDisposable>()) {Threshold = 1000},
                new ValidityPremiumItemViewModel(Mock.Of<IDisposable>()) {Threshold = 2000}
            };

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.SortedValidityPremiums.OnNext(validityPremiums);

            // ASSERT
            Assert.That(testObjects.ViewModel.ValidityPremiums.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.ValidityPremiums[0].Threshold, Is.EqualTo(1000));
            Assert.That(testObjects.ViewModel.ValidityPremiums[1].Threshold, Is.EqualTo(2000));
        }

        [Test]
        public void ShouldPopulatePriceCurvePremium_From_SelectedPriceCurveDefinition()
        {
            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .Build();

            var priceCurves = new List<PriceCurveDefinition> { priceCurve1, priceCurve2 };

            var priceCurvePremium1 = new PriceCurvePremium(101, Array.Empty<VolumePremium>(), Array.Empty<ValidityPremium>(), new PriceCurveFees());
            var priceCurvePremium2 = new PriceCurvePremium(102, Array.Empty<VolumePremium>(), Array.Empty<ValidityPremium>(), new PriceCurveFees());

            var priceCurvePremiums = new List<PriceCurvePremium> { priceCurvePremium1, priceCurvePremium2 };

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                      .WithPriceCurvePremiums(priceCurvePremiums)
                                                                                      .Build();
            // ACT
            testObjects.ViewModel.SelectedPriceCurveDefinition = testObjects.ViewModel.PriceCurveDefinitions[1];

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPremiums, Is.True);

            Mock.Get(testObjects.FeesAndPremiumsProvider)
                .Verify(p => p.UpdateFeesAndPremiums(testObjects.ViewModel, priceCurvePremium2, It.IsAny<int>()));

            Mock.Get(testObjects.PriceCurveFeesService)
                .Verify(p => p.RefreshFees(testObjects.ViewModel.PriceCurveFees));

            Mock.Get(testObjects.VolumePremiumRowService)
                .Verify(v => v.RefreshItems(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.VolumePremiumRowSortingService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.VolumePremiumsAddEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>(), It.IsAny<Action<bool>>()));

            Mock.Get(testObjects.VolumePremiumsDeleteEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumRowService)
                .Verify(v => v.RefreshItems(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumRowSortingService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumsAddEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>(), It.IsAny<Action<bool>>()));
        }

        [Test]
        public void ShouldSetUnitOfMeasure_From_SelectedPriceCurveDefinition()
        {
            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                         .WithProductUnitOfMeasure(UnitOfMeasure.BBL)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                         .WithProductUnitOfMeasure(UnitOfMeasure.M3)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .Build();

            var priceCurves = new List<PriceCurveDefinition> { priceCurve1, priceCurve2 };

            var priceCurvePremium1 = new PriceCurvePremium(101, Array.Empty<VolumePremium>(), Array.Empty<ValidityPremium>(), new PriceCurveFees());
            var priceCurvePremium2 = new PriceCurvePremium(102, Array.Empty<VolumePremium>(), Array.Empty<ValidityPremium>(), new PriceCurveFees());

            var priceCurvePremiums = new List<PriceCurvePremium> { priceCurvePremium1, priceCurvePremium2 };

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                      .WithPriceCurvePremiums(priceCurvePremiums)
                                                                                      .Build();
            // ACT
            testObjects.ViewModel.SelectedPriceCurveDefinition = testObjects.ViewModel.PriceCurveDefinitions[1];

            // ASSERT
            Assert.That(testObjects.ViewModel.UnitOfMeasureText, Is.EqualTo("Threshold (M3)"));
        }

        [Test]
        public void ShouldPopulatePriceCurvePremium_On_PriceCurvePremiumsUpdate()
        {
            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithProductPrecision(2)
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithProductPrecision(4)
                                                                         .Build();

            var priceCurves = new List<PriceCurveDefinition> { priceCurve1, priceCurve2 };

            var priceCurvePremium1 = new PriceCurvePremium(101, Array.Empty<VolumePremium>(), Array.Empty<ValidityPremium>(), new PriceCurveFees());
            var priceCurvePremium2 = new PriceCurvePremium(102, Array.Empty<VolumePremium>(), Array.Empty<ValidityPremium>(), new PriceCurveFees());

            var priceCurvePremiums = new List<PriceCurvePremium> { priceCurvePremium1, priceCurvePremium2 };

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                      .Build();

            testObjects.ViewModel.SelectedPriceCurveDefinition = testObjects.ViewModel.PriceCurveDefinitions[1];

            // ACT
            testObjects.PriceCurvePremiums.OnNext(priceCurvePremiums);

            // ASSERT
            Mock.Get(testObjects.FeesAndPremiumsProvider)
                .Verify(p => p.UpdateFeesAndPremiums(testObjects.ViewModel, priceCurvePremium2, 4));

            Mock.Get(testObjects.VolumePremiumRowService)
                .Verify(v => v.RefreshItems(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.VolumePremiumRowSortingService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.VolumePremiumsAddEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>(), It.IsAny<Action<bool>>()));

            Mock.Get(testObjects.VolumePremiumsDeleteEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumRowService)
                .Verify(v => v.RefreshItems(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumRowSortingService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumsAddEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>(), It.IsAny<Action<bool>>()));

            Mock.Get(testObjects.ToolBarCalculator)
                .Verify(c => c.Attach(testObjects.ToolBarService, 
                                      It.IsAny<IObservable<bool>>(),
                                      testObjects.VolumePremiumRowService, 
                                      testObjects.ValidityPremiumRowService, 
                                      testObjects.PriceCurveFeesService));
        }

        [Test]
        public void ShouldAddNewVolumePremiumRow_On_AddNewVolumePremiumCommand()
        {
            var newVolumePremiumRow = new VolumePremiumItemViewModel(Mock.Of<IDisposable>());

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().WithNewVolumePremiumRow(newVolumePremiumRow)
                                                                                      .Build();
            // ACT
            testObjects.ViewModel.AddVolumePremiumCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.VolumePremiums.Count, Is.EqualTo(1));

            Mock.Get(testObjects.VolumePremiumRowService)
                .Verify(v => v.RefreshItems(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.VolumePremiumRowSortingService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.VolumePremiumsAddEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>(), It.IsAny<Action<bool>>()));


            Mock.Get(testObjects.VolumePremiumsDeleteEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));
        }

        [Test]
        public void ShouldAddNewValidityPremiumRow_On_AddNewValidityPremiumCommand()
        {
            var newValidityPremiumRow = new ValidityPremiumItemViewModel(Mock.Of<IDisposable>());

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().WithNewValidityPremiumRow(newValidityPremiumRow)
                                                                                      .Build();
            // ACT
            testObjects.ViewModel.AddValidityPremiumCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ValidityPremiums.Count, Is.EqualTo(1));

            Mock.Get(testObjects.ValidityPremiumRowService)
                .Verify(v => v.RefreshItems(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumRowSortingService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumsAddEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>(), It.IsAny<Action<bool>>()));
        }

        [Test]
        public void ShouldResetFeesAndPremiums_On_UndoCommand()
        {
            var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                        .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                        .Build();

            var priceCurves = new List<PriceCurveDefinition> { priceCurve};

            var priceCurvePremium = new PriceCurvePremium(101, Array.Empty<VolumePremium>(), Array.Empty<ValidityPremium>(), new PriceCurveFees());

            var priceCurvePremiums = new List<PriceCurvePremium> { priceCurvePremium };

            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurves)
                                                                                      .WithPriceCurvePremiums(priceCurvePremiums)
                                                                                      .Build();
            // ACT
            testObjects.ViewModel.SelectedPriceCurveDefinition = testObjects.ViewModel.PriceCurveDefinitions[0];

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.FeesAndPremiumsProvider)
                .Verify(p => p.ResetFeesAndPremiums(testObjects.ViewModel));

            Mock.Get(testObjects.PriceCurveFeesService)
                .Verify(p => p.RefreshFees(testObjects.ViewModel.PriceCurveFees));

            Mock.Get(testObjects.VolumePremiumRowService)
                .Verify(v => v.RefreshItems(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.VolumePremiumRowSortingService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.VolumePremiumsAddEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>(), It.IsAny<Action<bool>>()));

            Mock.Get(testObjects.VolumePremiumsDeleteEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumRowService)
                .Verify(v => v.RefreshItems(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumRowSortingService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>()));

            Mock.Get(testObjects.ValidityPremiumsAddEnabledService)
                .Verify(v => v.RefreshRows(It.IsAny<IList<IPremiumThresholdItem>>(), It.IsAny<Action<bool>>()));
        }

        [Test]
        public void ShouldSetIsBusyAndInvokeUpdateService_On_UpdateCommand()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().WithPriceCurveId(101)
                                                                                      .WithFeesCurveId(201)
                                                                                      .Build();

            

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.IsNotNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.PriceCurvePremiumBuilder)
                .Verify(b => b.GetPriceCurvePremium(101, 
                                                    201, 
                                                    testObjects.ViewModel.PriceCurveFees, 
                                                    testObjects.ViewModel.VolumePremiums,
                                                    testObjects.ViewModel.ValidityPremiums));

            Mock.Get(testObjects.PriceCurvePremiumUpdateService)
                .Verify(p => p.Update(It.IsAny<PriceCurvePremium>(), 
                                      It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldSetIsBusyFalse_And_SendPopupNotification_On_PriceCurvePremiumUpdateResponse_Success()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();
            
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.PriceCurvePremiumUpdateResponse.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.PopupNotificationService)
                .Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldEnableAddVolumeCommand_On_CanAddVolumePremiumsTrue()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.CanAddVolumePremiums = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.AddVolumePremiumCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableAddVolumeCommand_On_CanAddVolumePremiumsFalse()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.CanAddVolumePremiums = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.AddVolumePremiumCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableAddValidityCommand_On_CanAddValidityPremiumsTrue()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.CanAddValidityPremiums = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.AddValidityPremiumCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableAddValidityCommand_On_CanAddValidityPremiumsFalse()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.CanAddValidityPremiums = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.AddValidityPremiumCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldSetIsBusyFalse_And_ShowMessageDialog_On_PriceCurvePremiumUpdateResponse_Failed()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.PriceCurvePremiumUpdateResponse.OnError(new Exception("error"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.IsNull(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.Messages[0] == "error"
                                                                                && args.ShowSendFeedback)));
        }

        [Test]
        public void ShouldDisposeServices_On_Dispose()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.PriceCurveFeesService)
                .Verify(v => v.Dispose());

            Mock.Get(testObjects.VolumePremiumRowService)
                .Verify(v => v.Dispose());

            Mock.Get(testObjects.ValidityPremiumRowService)
                .Verify(v => v.Dispose());

            Mock.Get(testObjects.VolumePremiumRowSortingService)
                .Verify(v => v.Dispose());

            Mock.Get(testObjects.ValidityPremiumRowSortingService)
                .Verify(v => v.Dispose());

            Mock.Get(testObjects.VolumePremiumsDeleteEnabledService)
                .Verify(v => v.Dispose());

            Mock.Get(testObjects.ToolBarCalculator)
                .Verify(v => v.Dispose());
        }

        [Test]
        public void ShouldNotDisposeServices_When_Disposed()
        {
            var testObjects = new PremiumsEditorViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.PriceCurveFeesService)
                .Verify(v => v.Dispose(), Times.Once);
        }
    }
}
