﻿using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Premiums.Controllers;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Controllers
{
    internal interface IValidityPremiumItemViewModelControllerTestObjects
    {
        IPremiumRowValidationService ValidationService { get; }
        ValidityPremiumItemViewModel ViewModel { get; }
        ValidityPremiumItemViewModelController Controller { get; }
    }

    [TestFixture]
    public class ValidityPremiumItemViewModelControllerTests
    {
        private class ValidityPremiumItemViewModelControllerTestObjectBuilder
        {
            private ValidityPremium _validityPremium;

            public ValidityPremiumItemViewModelControllerTestObjectBuilder WithValidityPremium(ValidityPremium value)
            {
                _validityPremium = value;
                return this;
            }

            public IValidityPremiumItemViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IValidityPremiumItemViewModelControllerTestObjects>();

                var validationService = new Mock<IPremiumRowValidationService>();

                var controller = new ValidityPremiumItemViewModelController
                {
                    PremiumRowValidationService = validationService.Object
                };

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(validationService.Object);

                controller.ViewModel.SetModel(_validityPremium);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldEnableDeleteCommand_On_CanDeleteTrue()
        {
            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            testObjects.ViewModel.CanDelete = true;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.DeleteCommand.CanExecute());
        }

        [Test]
        public void ShouldDisableDeleteCommand_On_CanDeleteFalse()
        {
            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            testObjects.ViewModel.CanDelete = false;

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.DeleteCommand.CanExecute());
        }

        [Test]
        public void ShouldSetIsDeleted_OnDeleteCommand()
        {
            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDeleted);
        }

        [Test]
        public void ShouldSetIsDeletedFalse_OnUndoDeleteCommand()
        {
            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.DeleteCommand.Execute();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.IsDeleted);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_ValuesSetFromVolumePremium()
        {

            var volumePremium = new ValidityPremium(600, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.SetModel(volumePremium);

            // ACT
            testObjects.ViewModel.Threshold = 10;
            testObjects.ViewModel.BidMargin = 1;
            testObjects.ViewModel.AskMargin = 2;

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldUpdateThresholdInSecs_From_Threshold()
        {
            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            testObjects.ViewModel.Threshold = 10;

            // ASSERT
            Assert.AreEqual(600, testObjects.ViewModel.ThresholdInSecs);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_ThresholdChanged()
        {
            var validityPremium = new ValidityPremium(600, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            testObjects.ViewModel.Threshold = 10;
            testObjects.ViewModel.BidMargin = 1;
            testObjects.ViewModel.AskMargin = 2;

            // ACT
            testObjects.ViewModel.Threshold = 20;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_BidMarginChanged()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            testObjects.ViewModel.Threshold = 1000;
            testObjects.ViewModel.BidMargin = 1;
            testObjects.ViewModel.AskMargin = 2;

            // ACT
            testObjects.ViewModel.BidMargin = 1.5;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_AskMarginChanged()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            testObjects.ViewModel.Threshold = 1000;
            testObjects.ViewModel.BidMargin = 1;
            testObjects.ViewModel.AskMargin = 2;

            // ACT
            testObjects.ViewModel.AskMargin = 2.5;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldValidate_On_ThresholdChanged()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.Threshold = 1000;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldValidate_On_BidMarginChanged()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.BidMargin = 0.1;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldValidate_On_AskMarginChanged()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.AskMargin = 0.2;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldValidate_On_IsDuplicateChanged()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsDuplicate = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldValidate_On_IsDeletedChanged()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldNotValidate_When_Disposed()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldDispose_From_ViewModelDispose()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            testObjects.ViewModel.Dispose();

            // ACT
            testObjects.ViewModel.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var validityPremium = new ValidityPremium(1000, 1, 2);

            var testObjects = new ValidityPremiumItemViewModelControllerTestObjectBuilder().WithValidityPremium(validityPremium)
                                                                                           .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel), Times.Never);
        }

    }
}
