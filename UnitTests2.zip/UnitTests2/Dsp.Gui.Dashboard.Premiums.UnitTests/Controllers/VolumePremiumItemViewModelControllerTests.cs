﻿using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Premiums.Controllers;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Controllers
{
    internal interface IVolumePremiumRowViewModelControllerTestObjects
    {
        IPremiumRowValidationService ValidationService { get; }
        VolumePremiumItemViewModel ViewModel { get; }
        VolumePremiumItemViewModelController Controller { get; }
    }

    [TestFixture]
    public class VolumePremiumItemViewModelControllerTests
    {
        private class VolumePremiumRowViewModelControllerTestObjectBuilder
        {
            private VolumePremium _volumePremium;

            public VolumePremiumRowViewModelControllerTestObjectBuilder WithVolumePremium(VolumePremium value)
            {
                _volumePremium = value;
                return this;
            }

            public IVolumePremiumRowViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IVolumePremiumRowViewModelControllerTestObjects>();

                var validationService = new Mock<IPremiumRowValidationService>();

                var controller = new VolumePremiumItemViewModelController
                {
                    PremiumRowValidationService = validationService.Object
                };

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(validationService.Object);

                controller.ViewModel.SetModel(_volumePremium);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldEnableDeleteCommand_On_CanDeleteTrue()
        {
            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            testObjects.ViewModel.CanDelete = true;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.DeleteCommand.CanExecute());
        }

        [Test]
        public void ShouldDisableDeleteCommand_On_CanDeleteFalse()
        {
            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().Build();

            // ASSERT
            testObjects.ViewModel.CanDelete = false;

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.DeleteCommand.CanExecute());
        }

        [Test]
        public void ShouldSetIsDeleted_OnDeleteCommand()
        {
            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.DeleteCommand.Execute();

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDeleted);
        }

        [Test]
        public void ShouldSetIsDeletedFalse_OnUndoDeleteCommand()
        {
            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.DeleteCommand.Execute();

            // ACT
            testObjects.ViewModel.UndoDeleteCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.IsDeleted);
        }

        [Test]
        public void ShouldSetIsDirtyFalse_When_ValuesSetFromVolumePremium()
        {

            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.SetModel(volumePremium);

            // ACT
            testObjects.ViewModel.Threshold = 1000;
            testObjects.ViewModel.BidMargin = 1;
            testObjects.ViewModel.AskMargin = 2;

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_ThresholdChanged()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            testObjects.ViewModel.Threshold = 1000;
            testObjects.ViewModel.BidMargin = 1;
            testObjects.ViewModel.AskMargin = 2;

            // ACT
            testObjects.ViewModel.Threshold = 2000;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_BidMarginChanged()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            testObjects.ViewModel.Threshold = 1000;
            testObjects.ViewModel.BidMargin = 1;
            testObjects.ViewModel.AskMargin = 2;

            // ACT
            testObjects.ViewModel.BidMargin = 1.5;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldSetIsDirtyTrue_When_AskMarginChanged()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            testObjects.ViewModel.Threshold = 1000;
            testObjects.ViewModel.BidMargin = 1;
            testObjects.ViewModel.AskMargin = 2;

            // ACT
            testObjects.ViewModel.AskMargin = 2.5;

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsDirty);
        }

        [Test]
        public void ShouldValidate_On_ThresholdChanged()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.Threshold = 1000;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldValidate_On_BidMarginChanged()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.BidMargin = 0.1;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldValidate_On_AskMarginChanged()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.AskMargin = 0.2;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldValidate_On_IsDuplicateChanged()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsDuplicate = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldValidate_On_IsDeletedChanged()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            // ACT
            testObjects.ViewModel.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel));
        }

        [Test]
        public void ShouldNotValidate_When_Disposed()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldDispose_From_ViewModelDispose()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            testObjects.ViewModel.Dispose();

            // ACT
            testObjects.ViewModel.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var volumePremium = new VolumePremium(1000, 1, 2);

            var testObjects = new VolumePremiumRowViewModelControllerTestObjectBuilder().WithVolumePremium(volumePremium)
                                                                                        .Build();

            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.IsDeleted = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ValidateRow(testObjects.ViewModel), Times.Never);
        }
    }
}
