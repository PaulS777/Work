﻿using System;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Premiums.Controllers;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    internal interface IFeesAndPremiumsProviderTestObjects
    {
        FeesAndPremiumsProvider FeesAndPremiumsProvider { get; }
    }

    [TestFixture]
    public class FeesAndPremiumsProviderTests
    {
        private class FeesAndPremiumsProviderTestObjectsBuilder
        {
            public IFeesAndPremiumsProviderTestObjects Build()
            {
                var testObjects = new Mock<IFeesAndPremiumsProviderTestObjects>();

                var volumePremiumController1 = new Mock<IVolumePremiumItemViewModelController>();

                var volumePremium1 = new VolumePremiumItemViewModel(volumePremiumController1.Object);

                volumePremiumController1.SetupGet(c => c.ViewModel)
                                        .Returns(volumePremium1);

                var volumePremiumController2 = new Mock<IVolumePremiumItemViewModelController>();

                var volumePremium2 = new VolumePremiumItemViewModel(volumePremiumController2.Object);

                volumePremiumController2.SetupGet(c => c.ViewModel)
                                        .Returns(volumePremium2);

                var volumePremiumFactory = new Mock<IServiceFactory<IVolumePremiumItemViewModelController>>();

                volumePremiumFactory.SetupSequence(f => f.Create())
                                    .Returns(volumePremiumController1.Object)
                                    .Returns(volumePremiumController2.Object);

                var validityPremiumController1 = new Mock<IValidityPremiumItemViewModelController>();

                var validityPremium1 = new ValidityPremiumItemViewModel(volumePremiumController1.Object);

                validityPremiumController1.SetupGet(c => c.ViewModel)
                                         .Returns(validityPremium1);

                var validityPremiumController2 = new Mock<IValidityPremiumItemViewModelController>();

                var validityPremium2 = new ValidityPremiumItemViewModel(volumePremiumController1.Object);

                validityPremiumController2.SetupGet(c => c.ViewModel)
                                          .Returns(validityPremium2);

                var validityPremiumFactory = new Mock<IServiceFactory<IValidityPremiumItemViewModelController>>();

                validityPremiumFactory.SetupSequence(f => f.Create())
                                      .Returns(validityPremiumController1.Object)
                                      .Returns(validityPremiumController2.Object);

                var feesAndPremiumsProvider = new FeesAndPremiumsProvider
                                              {
                                                  VolumePremiumFactory = volumePremiumFactory.Object,
                                                  ValidityPremiumFactory = validityPremiumFactory.Object
                                              };

                testObjects.SetupGet(o => o.FeesAndPremiumsProvider)
                           .Returns(feesAndPremiumsProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdateViewModel_From_PriceCurvePremium_OrderedByThreshold()
        {
            var viewModel = new PremiumsEditorViewModel();

            var priceCurvePremium = new PriceCurvePremium(1, 
                                                          new []
                                                          {
                                                              new VolumePremium(2000, -0.1, 0.1),
                                                              new VolumePremium(1000, -0.1, 0.1),
                                                          }, 
                                                          new[]
                                                          {
                                                              new ValidityPremium(600, -0.2, 0.2),
                                                              new ValidityPremium(300, -0.2, 0.2)
                                                          }, 
                                                          new PriceCurveFees(2, 5, 10, 15, 20, 25));

            var testObjects = new FeesAndPremiumsProviderTestObjectsBuilder().Build();

            // ACT
            testObjects.FeesAndPremiumsProvider.UpdateFeesAndPremiums(viewModel, priceCurvePremium, 2);

            // ASSERT
            Assert.AreSame(priceCurvePremium, viewModel.Model());
            Assert.That(viewModel.PriceCurveFees.Model(), Is.EqualTo(priceCurvePremium.Fees));

            Assert.That(viewModel.PriceCurveFees.InternalPlatformFee, Is.EqualTo(5));
            Assert.That(viewModel.PriceCurveFees.ExternalPlatformFee, Is.EqualTo(10));
            Assert.That(viewModel.PriceCurveFees.InternalServiceFee, Is.EqualTo(15));
            Assert.That(viewModel.PriceCurveFees.BrokerageFee, Is.EqualTo(20));
            Assert.That(viewModel.PriceCurveFees.ClearingFee, Is.EqualTo(25));

            Assert.That(viewModel.VolumePremiums.Count, Is.EqualTo(2));
            Assert.That(viewModel.VolumePremiums[0].Threshold, Is.EqualTo(1000));
            Assert.That(viewModel.VolumePremiums[0].BidMargin, Is.EqualTo(-0.1));
            Assert.That(viewModel.VolumePremiums[0].AskMargin, Is.EqualTo(0.1));
            Assert.AreSame(priceCurvePremium.Volume[1], viewModel.VolumePremiums[0].Model());

            Assert.That(viewModel.VolumePremiums[1].Threshold, Is.EqualTo(2000));
            
            Assert.That(viewModel.ValidityPremiums.Count, Is.EqualTo(2));
            Assert.That(viewModel.ValidityPremiums[0].Threshold, Is.EqualTo(5));
            Assert.That(viewModel.ValidityPremiums[0].BidMargin, Is.EqualTo(-0.2));
            Assert.That(viewModel.ValidityPremiums[0].AskMargin, Is.EqualTo(0.2));
            Assert.That(viewModel.ValidityPremiums[0].AvailableThresholds.Count, Is.EqualTo(5));
            Assert.AreSame(priceCurvePremium.Validity[1], viewModel.ValidityPremiums[0].Model());

            Assert.That(viewModel.ValidityPremiums[1].Threshold, Is.EqualTo(10));
            Assert.That(viewModel.ValidityPremiums[1].CanDelete, Is.True);
        }

        [Test]
        public void ShouldCreateDefaultVolumePremium_When_EditMode_And_PriceCurvePremium_HasNoPremiums()
        {
            var viewModel = new PremiumsEditorViewModel {CanEditPremiums = true};

            var priceCurvePremium = new PriceCurvePremium(1,
                                                          new VolumePremium[] {},
                                                          new ValidityPremium[] {},
                                                          new PriceCurveFees(2, 5, 10, 15, 20, 25));

            var testObjects = new FeesAndPremiumsProviderTestObjectsBuilder().Build();

            // ACT
            testObjects.FeesAndPremiumsProvider.UpdateFeesAndPremiums(viewModel, priceCurvePremium, 2);

            // ASSERT
            Assert.That(viewModel.VolumePremiums.Count, Is.EqualTo(1));
            Assert.IsNull(viewModel.VolumePremiums[0].Threshold);
            Assert.That(viewModel.VolumePremiums[0].NewRecord, Is.False);
            Assert.That(viewModel.VolumePremiums[0].MarginPrecision, Is.EqualTo(2));

            Assert.That(viewModel.ValidityPremiums.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldNotCreateDefaultPremiumRows_When_ReadonlyMode_And_PriceCurvePremium_HasNoPremiums()
        {
            var viewModel = new PremiumsEditorViewModel { CanEditPremiums = false };

            var priceCurvePremium = new PriceCurvePremium(1,
                                                          Array.Empty<VolumePremium>(),
                                                          Array.Empty<ValidityPremium>(),
                                                          new PriceCurveFees(2, 5, 10, 15, 20, 25));

            var testObjects = new FeesAndPremiumsProviderTestObjectsBuilder().Build();

            // ACT
            testObjects.FeesAndPremiumsProvider.UpdateFeesAndPremiums(viewModel, priceCurvePremium, 2);

            // ASSERT
            Assert.That(viewModel.VolumePremiums.Count, Is.EqualTo(0));
            Assert.That(viewModel.ValidityPremiums.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldCreateNewVolumePremiumRow_With_NullThreshold()
        {
            var testObjects = new FeesAndPremiumsProviderTestObjectsBuilder().Build();

            // ACT
            var row = testObjects.FeesAndPremiumsProvider.CreateNewVolumePremiumRow();

            // ASSERT
            Assert.That(row.NewRecord, Is.True);
            Assert.IsNull(row.Threshold);
            Assert.That(row.BidMargin, Is.EqualTo(0));
            Assert.That(row.AskMargin, Is.EqualTo(0));
            Assert.IsNotNull(row.Model());
        }

        [Test]
        public void ShouldCreateNewValidityPremiumRow_With_NullThreshold()
        {
            var testObjects = new FeesAndPremiumsProviderTestObjectsBuilder().Build();

            // ACT
            var row = testObjects.FeesAndPremiumsProvider.CreateNewValidityPremiumRow();

            // ASSERT
            Assert.That(row.NewRecord, Is.True);
            Assert.IsNull(row.Threshold);
            Assert.That(row.BidMargin, Is.EqualTo(0));
            Assert.That(row.AskMargin, Is.EqualTo(0));
            Assert.That(row.AvailableThresholds.Count, Is.EqualTo(5));
            Assert.IsNotNull(row.Model());
            Assert.That(row.CanDelete, Is.True);
        }

        [Test]
        public void ShouldResetViewModel_From_Model()
        {
            var viewModel = new PremiumsEditorViewModel();

            var priceCurvePremium = new PriceCurvePremium(1,
                                                          new[]
                                                          {
                                                              new VolumePremium(2000, -0.1, 0.1),
                                                              new VolumePremium(1000, -0.1, 0.1),
                                                          },
                                                          new[]
                                                          {
                                                              new ValidityPremium(300, -0.2, 0.2),
                                                              new ValidityPremium(600, -0.2, 0.2)
                                                          },
                                                          new PriceCurveFees(2, 5, 10, 15, 20, 25));

            viewModel.SetModel(priceCurvePremium);

            var testObjects = new FeesAndPremiumsProviderTestObjectsBuilder().Build();

            // ACT
            testObjects.FeesAndPremiumsProvider.ResetFeesAndPremiums(viewModel);

            // ASSERT
            Assert.That(viewModel.PriceCurveFees.InternalPlatformFee, Is.EqualTo(5));
            Assert.That(viewModel.PriceCurveFees.ExternalPlatformFee, Is.EqualTo(10));
            Assert.That(viewModel.PriceCurveFees.InternalServiceFee, Is.EqualTo(15));
            Assert.That(viewModel.PriceCurveFees.BrokerageFee, Is.EqualTo(20));
            Assert.That(viewModel.PriceCurveFees.ClearingFee, Is.EqualTo(25));

            Assert.That(viewModel.VolumePremiums.Count, Is.EqualTo(2));
            Assert.That(viewModel.VolumePremiums[0].Threshold, Is.EqualTo(1000));
            Assert.That(viewModel.VolumePremiums[0].BidMargin, Is.EqualTo(-0.1));
            Assert.That(viewModel.VolumePremiums[0].AskMargin, Is.EqualTo(0.1));
            Assert.AreSame(priceCurvePremium.Volume[1], viewModel.VolumePremiums[0].Model());

            Assert.That(viewModel.VolumePremiums[1].Threshold, Is.EqualTo(2000));

            Assert.That(viewModel.ValidityPremiums.Count, Is.EqualTo(2));
            Assert.That(viewModel.ValidityPremiums[0].Threshold, Is.EqualTo(5));
            Assert.That(viewModel.ValidityPremiums[0].ThresholdInSecs, Is.EqualTo(300));
            Assert.That(viewModel.ValidityPremiums[0].BidMargin, Is.EqualTo(-0.2));
            Assert.That(viewModel.ValidityPremiums[0].AskMargin, Is.EqualTo(0.2));
            Assert.AreSame(priceCurvePremium.Validity[1], viewModel.ValidityPremiums[0].Model());

            Assert.That(viewModel.ValidityPremiums[1].Threshold, Is.EqualTo(10));
            Assert.That(viewModel.ValidityPremiums[1].ThresholdInSecs, Is.EqualTo(600));
        }

        [Test]
        public void ShouldCreateDefaultVolumePremium_When_Reset_With_EditMode_And_PriceCurvePremium_HasNoPremiums()
        {
            var viewModel = new PremiumsEditorViewModel { CanEditPremiums = true };

            var priceCurvePremium = new PriceCurvePremium(1,
                                                          Array.Empty<VolumePremium>(),
                                                          Array.Empty<ValidityPremium>(),
                                                          new PriceCurveFees(2, 5, 10, 15, 20, 25));

            var testObjects = new FeesAndPremiumsProviderTestObjectsBuilder().Build();

            testObjects.FeesAndPremiumsProvider.UpdateFeesAndPremiums(viewModel, priceCurvePremium, 2);

            viewModel.VolumePremiums.Add(new VolumePremiumItemViewModel(Mock.Of<IDisposable>()));
            viewModel.ValidityPremiums.Add(new ValidityPremiumItemViewModel(Mock.Of<IDisposable>()));

            // ACT
            testObjects.FeesAndPremiumsProvider.ResetFeesAndPremiums(viewModel);

            // ASSERT
            Assert.That(viewModel.VolumePremiums.Count, Is.EqualTo(1));
            Assert.IsNull(viewModel.VolumePremiums[0].Threshold);
            Assert.That(viewModel.VolumePremiums[0].NewRecord, Is.False);
            Assert.That(viewModel.VolumePremiums[0].MarginPrecision, Is.EqualTo(2));

            Assert.That(viewModel.ValidityPremiums.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldNotCreateDefaultPremiumRows_When_Reset_With_ReadonlyMode_And_PriceCurvePremium_HasNoPremiums()
        {
            var viewModel = new PremiumsEditorViewModel { CanEditPremiums = false};

            var priceCurvePremium = new PriceCurvePremium(1,
                                                          Array.Empty<VolumePremium>(),
                                                          Array.Empty<ValidityPremium>(),
                                                          new PriceCurveFees(2, 5, 10, 15, 20, 25));

            var testObjects = new FeesAndPremiumsProviderTestObjectsBuilder().Build();

            viewModel.SetModel(priceCurvePremium);

            // ACT
            testObjects.FeesAndPremiumsProvider.ResetFeesAndPremiums(viewModel);

            // ASSERT
            Assert.That(viewModel.VolumePremiums.Count, Is.EqualTo(0));
            Assert.That(viewModel.ValidityPremiums.Count, Is.EqualTo(0));
        }
    }
}
