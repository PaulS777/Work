﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    internal interface IUserPriceCurvePermissionsServiceTestObjects
    {
        ISubject<List<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        UserPriceCurvePermissionsService UserPriceCurvePermissionsService { get; }
    }

    [TestFixture]
    public class UserPriceCurvePermissionServiceTests
    {
        private class UserPriceCurvePermissionsServiceTestObjectBuilder
        {
            private User _user;
            private List<PriceCurveDefinition> _priceCurveDefinitions;

            public UserPriceCurvePermissionsServiceTestObjectBuilder WithUser(User value)
            {
                _user = value;
                return this;
            }

            public UserPriceCurvePermissionsServiceTestObjectBuilder WithPriceCurveDefinitions(List<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public IUserPriceCurvePermissionsServiceTestObjects Build()
            {
                var testObjects = new Mock<IUserPriceCurvePermissionsServiceTestObjects>();

                var priceCurveDefinitions = new BehaviorSubject<List<PriceCurveDefinition>>(null);

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurveDefinitions);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(Observable.Return(_user));

                curveControlService.SetupGet(c => c.CurrentUserSnapshot)
                                   .Returns(_user);

                curveControlService.SetupGet(c => c.PriceCurveDefinitions)
                                   .Returns(priceCurveDefinitions);


                curveControlService.Setup(c => c.GetPriceCurveDefinitionsSnapshot())
                                   .Returns(_priceCurveDefinitions);

                var userPriceCurveDefinitionsProvider = new UserPriceCurvePermissionsService(curveControlService.Object);

                testObjects.SetupGet(o => o.UserPriceCurvePermissionsService)
                           .Returns(userPriceCurveDefinitionsProvider);

                return testObjects.Object;
            }
        }

		[Test]
        public void ShouldPublishMonthlyAndDailyPriceCurveDefinitions_Where_UserHasCurveGroupPermissions()
        {
            var curveGroups = new[]
            {
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), true, false)
            };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithProductCurveGroup(new CurveGroupTestObjectBuilder().FuelOil())
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                         .Build();

            var priceCurve3 = new PriceCurveDefinitionTestObjectBuilder().WithId(103)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                         .WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                         .Build();

            var priceCurveDefinitions = new List<PriceCurveDefinition> {priceCurve1, priceCurve2, priceCurve3};

            var testObjects = new UserPriceCurvePermissionsServiceTestObjectBuilder().WithUser(user)
                                                                                     .Build();

            List<PriceCurveDefinition> result = null;

            var expected = new[] { priceCurve2, priceCurve3 };

            using (testObjects.UserPriceCurvePermissionsService
                              .GetUserPriceCurveDefinitions()
                              .Subscribe(defs => result = defs))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext(priceCurveDefinitions);

                // ASSERT
                Assert.That(result.SequenceEqual(expected));
            }
        }

        [Test]
        public void ShouldIgnoreChildCurves()
        {
			var curveGroups = new[]
            {
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), true, false)
            };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithProductCurveGroup(new CurveGroupTestObjectBuilder().FuelOil())
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                         .Build();

            var priceCurve3 = new PriceCurveDefinitionTestObjectBuilder().WithId(103)
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                         .WithProductCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                         .WithMarginParentCurveId(201)
                                                                         .Build();

            var priceCurveDefinitions = new List<PriceCurveDefinition> { priceCurve1, priceCurve2, priceCurve3 };

            var testObjects = new UserPriceCurvePermissionsServiceTestObjectBuilder().WithUser(user)
                                                                                     .Build();

            List<PriceCurveDefinition> result = null;

            var expected = new[] { priceCurve2 };

            using (testObjects.UserPriceCurvePermissionsService
                              .GetUserPriceCurveDefinitions()
                              .Subscribe(defs => result = defs))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext(priceCurveDefinitions);

                // ASSERT
                Assert.That(result.SequenceEqual(expected));
            }
        }

        [Test]
        public void ShouldPublishMonthlyPriceCurveDefinitions_OrderedByName()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[]
            {
                new AuthorisationCurveGroup(crude, true, false)
            };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                         .WithName("curve-B")
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithProductCurveGroup(crude)
                                                                         .Build();

            var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
                                                                         .WithName("curve-A")
                                                                         .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                         .WithProductCurveGroup(crude)
                                                                         .Build();


            var priceCurveDefinitions = new List<PriceCurveDefinition> { priceCurve1, priceCurve2 };

            var testObjects = new UserPriceCurvePermissionsServiceTestObjectBuilder().WithUser(user)
                                                                                      .Build();

            List<PriceCurveDefinition> result = null;

            using (testObjects.UserPriceCurvePermissionsService
                              .GetUserPriceCurveDefinitions()
                              .Subscribe(defs => result = defs))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext(priceCurveDefinitions);

                // ASSERT
                Assert.That(result[0].Id == 102 && result[1].Id == 101);
            }
        }

        [Test]
        public void ShouldReturnTrue_When_UserHasUpdatePermissionsOnCurve()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[]
            {
                new AuthorisationCurveGroup(crude, true, true)
            };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

            var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                        .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                        .WithProductCurveGroup(crude)
                                                                        .Build();

            var priceCurves = new List<PriceCurveDefinition> {priceCurve};

            var testObjects = new UserPriceCurvePermissionsServiceTestObjectBuilder().WithUser(user)
                                                                                     .WithPriceCurveDefinitions(priceCurves)
                                                                                     .Build();

            // ACT
            var result = testObjects.UserPriceCurvePermissionsService.GetUserCanEditCurve(101);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_UserHasReadonlyPermissionsOnCurve()
        {
            var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[]
            {
                new AuthorisationCurveGroup(crude, true, false)
            };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

            var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                        .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                        .WithProductCurveGroup(crude)
                                                                        .Build();

            var priceCurves = new List<PriceCurveDefinition> { priceCurve };

            var testObjects = new UserPriceCurvePermissionsServiceTestObjectBuilder().WithUser(user)
                                                                                     .WithPriceCurveDefinitions(priceCurves)
                                                                                     .Build();

            // ACT
            var result = testObjects.UserPriceCurvePermissionsService.GetUserCanEditCurve(101);

            // ASSERT
            Assert.That(result, Is.False);
        }
    }
}
