﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    [TestFixture]
    public class PriceCurvePremiumBuilderTests
    {
        [Test]
        public void ShouldBuildPriceCurvePremium()
        {
            var priceCurveFeesViewModel = new PriceCurveFeesViewModel
            {
                InternalPlatformFee = 1,
                ExternalPlatformFee = 2,
                InternalServiceFee = 3,
                BrokerageFee = 4,
                ClearingFee = 5
            };

            var volumeRows = new List<VolumePremiumItemViewModel>
            {
                new(Mock.Of<IDisposable>()) {Threshold = 100, BidMargin = -0.1, AskMargin = 0.1}
            };

            var validityRows = new List<ValidityPremiumItemViewModel>
            {
                new(Mock.Of<IDisposable>()) {ThresholdInSecs = 600, BidMargin = -1, AskMargin = 1}
            };

            var builder = new PriceCurvePremiumBuilder();

            // ACT
            var result = builder.GetPriceCurvePremium(10, 101, priceCurveFeesViewModel, volumeRows, validityRows);

            // ASSERT
            Assert.That(result.PriceCurveId, Is.EqualTo(10));

            Assert.That(result.Fees.PriceCurveDefinitionId, Is.EqualTo(101));
            Assert.That(result.Fees.InternalPlatformFee, Is.EqualTo(1));
            Assert.That(result.Fees.ExternalPlatformFee, Is.EqualTo(2));
            Assert.That(result.Fees.InternalServiceFee, Is.EqualTo(3));
            Assert.That(result.Fees.BrokerageFee, Is.EqualTo(4));
            Assert.That(result.Fees.ClearingFee, Is.EqualTo(5));

            Assert.That(result.Volume.Count, Is.EqualTo(1));
            Assert.That(result.Volume[0].ThresholdInUoM, Is.EqualTo(100));
            Assert.That(result.Volume[0].BidMargin, Is.EqualTo(-0.1));
            Assert.That(result.Volume[0].AskMargin, Is.EqualTo(0.1));

            Assert.That(result.Validity.Count, Is.EqualTo(1));
            Assert.That(result.Validity[0].ThresholdInSeconds, Is.EqualTo(600));
            Assert.That(result.Validity[0].BidMargin, Is.EqualTo(-1));
            Assert.That(result.Validity[0].AskMargin, Is.EqualTo(1));
        }

        [Test]
        public void ShouldRemoveDeletedRows()
        {
            var priceCurveFeesViewModel = new PriceCurveFeesViewModel
            {
                InternalPlatformFee = 1,
                ExternalPlatformFee = 2,
                InternalServiceFee = 3,
                BrokerageFee = 4,
                ClearingFee = 5
            };

            var volumeRows = new List<VolumePremiumItemViewModel>
            {
                new(Mock.Of<IDisposable>()) {Threshold = 100, BidMargin = -0.1, AskMargin = 0.1},
                new(Mock.Of<IDisposable>()) {Threshold = 300, BidMargin = -0.1, AskMargin = 0.1, IsDeleted = true}
            };

            var validityRows = new List<ValidityPremiumItemViewModel>
            {
                new(Mock.Of<IDisposable>()) {ThresholdInSecs = 600, BidMargin = -1, AskMargin = 1},
                new(Mock.Of<IDisposable>()) {ThresholdInSecs = 600, BidMargin = -1, AskMargin = 1, IsDeleted = true}
            };

            var builder = new PriceCurvePremiumBuilder();

            // ACT
            var result = builder.GetPriceCurvePremium(10, 101, priceCurveFeesViewModel, volumeRows, validityRows);

            // ASSERT
            Assert.That(result.Volume.Count, Is.EqualTo(1));
            Assert.That(result.Validity.Count, Is.EqualTo(1));
        }
    }
}
