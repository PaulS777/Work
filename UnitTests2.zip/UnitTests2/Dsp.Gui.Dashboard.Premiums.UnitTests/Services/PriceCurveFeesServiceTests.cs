﻿using System;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    [TestFixture]
    public class PriceCurveFeesServiceTests
    {
        [Test]
        public void ShouldSetChangedFalse_When_RefreshFees()
        {
            var priceCurveFees = new PriceCurveFees(10, 0, 0, 0, 0, 0);

            var viewModel = new PriceCurveFeesViewModel();

            viewModel.SetModel(priceCurveFees);

            var service = new PriceCurveFeesService();

            // ACT
            service.RefreshFees(viewModel);

            // ASSERT
            Assert.That(viewModel.InternalPlatformFeeChanged, Is.False);
            Assert.That(viewModel.ExternalPlatformFeeChanged, Is.False);
            Assert.That(viewModel.InternalServiceFeeChanged, Is.False);
            Assert.That(viewModel.BrokerageFeeChanged, Is.False);
            Assert.That(viewModel.ClearingFeeChanged, Is.False);
        }

        [Test]
        public void ShouldSetHasChanged_When_InternalServiceFeeChanged()
        {
            var priceCurveFees = new PriceCurveFees(10, 0, 0, 0, 0, 0);

            var viewModel = new PriceCurveFeesViewModel();

            viewModel.SetModel(priceCurveFees);

            var service = new PriceCurveFeesService();

            service.RefreshFees(viewModel);

            var hasChanged = false;

            using (service.HasChanged.Subscribe(c => hasChanged = c))
            {
                // ACT
                viewModel.InternalServiceFee = 5;

                // ASSERT
                Assert.That(hasChanged, Is.True);
                Assert.That(viewModel.InternalServiceFeeChanged, Is.True);
            }
        }

        [Test]
        public void ShouldSetHasChanged_When_InternalPlatformFeeChanged()
        {
            var priceCurveFees = new PriceCurveFees(10, 0, 0, 0, 0, 0);

            var viewModel = new PriceCurveFeesViewModel();

            viewModel.SetModel(priceCurveFees);

            var service = new PriceCurveFeesService();

            service.RefreshFees(viewModel);

            var hasChanged = false;

            using (service.HasChanged.Subscribe(c => hasChanged = c))
            {
                // ACT
                viewModel.InternalPlatformFee = 5;

                // ASSERT
                Assert.That(hasChanged, Is.True);
                Assert.That(viewModel.InternalPlatformFeeChanged, Is.True);
            }
        }

        [Test]
        public void ShouldSetHasChanged_When_ExternalPlatformFeeChanged()
        {
            var priceCurveFees = new PriceCurveFees(10, 0, 0, 0, 0, 0);

            var viewModel = new PriceCurveFeesViewModel();

            viewModel.SetModel(priceCurveFees);

            var service = new PriceCurveFeesService();

            service.RefreshFees(viewModel);

            var hasChanged = false;

            using (service.HasChanged.Subscribe(c => hasChanged = c))
            {
                // ACT
                viewModel.ExternalPlatformFee = 5;

                // ASSERT
                Assert.That(hasChanged, Is.True);
                Assert.That(viewModel.ExternalPlatformFeeChanged, Is.True);
            }
        }

        [Test]
        public void ShouldSetHasChanged_When_BrokerageFeeChanged()
        {
            var priceCurveFees = new PriceCurveFees(10, 0, 0, 0, 0, 0);

            var viewModel = new PriceCurveFeesViewModel();

            viewModel.SetModel(priceCurveFees);

            var service = new PriceCurveFeesService();

            service.RefreshFees(viewModel);

            var hasChanged = false;

            using (service.HasChanged.Subscribe(c => hasChanged = c))
            {
                // ACT
                viewModel.BrokerageFee = 5;

                // ASSERT
                Assert.That(hasChanged, Is.True);
                Assert.That(viewModel.BrokerageFeeChanged, Is.True);
            }
        }

        [Test]
        public void ShouldSetHasChanged_When_ClearingFeeChanged()
        {
            var priceCurveFees = new PriceCurveFees(10, 0, 0, 0, 0, 0);

            var viewModel = new PriceCurveFeesViewModel();

            viewModel.SetModel(priceCurveFees);

            var service = new PriceCurveFeesService();

            service.RefreshFees(viewModel);

            var hasChanged = false;

            using (service.HasChanged.Subscribe(c => hasChanged = c))
            {
                // ACT
                viewModel.ClearingFee = 5;

                // ASSERT
                Assert.That(hasChanged, Is.True);
                Assert.That(viewModel.ClearingFeeChanged, Is.True);
            }
        }

        [Test]
        public void ShouldNotSetHasChanged_When_Disposed()
        {
            var priceCurveFees = new PriceCurveFees(10, 0, 0, 0, 0, 0);

            var viewModel = new PriceCurveFeesViewModel();

            viewModel.SetModel(priceCurveFees);

            var service = new PriceCurveFeesService();

            service.RefreshFees(viewModel);

            var hasChanged = false;

            service.Dispose();

            using (service.HasChanged.Subscribe(c => hasChanged = c))
            {
                // ACT
                viewModel.ClearingFee = 5;

                // ASSERT
                Assert.That(hasChanged, Is.False);
                Assert.That(viewModel.ClearingFeeChanged, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var priceCurveFees = new PriceCurveFees(10, 0, 0, 0, 0, 0);

            var viewModel = new PriceCurveFeesViewModel();

            viewModel.SetModel(priceCurveFees);

            var service = new PriceCurveFeesService();

            service.RefreshFees(viewModel);

            var hasChanged = false;

            service.Dispose();
            service.Dispose();

            using (service.HasChanged.Subscribe(c => hasChanged = c))
            {
                // ACT
                viewModel.ClearingFee = 5;

                // ASSERT
                Assert.That(hasChanged, Is.False);
                Assert.That(viewModel.ClearingFeeChanged, Is.False);
            }
        }
    }
}
