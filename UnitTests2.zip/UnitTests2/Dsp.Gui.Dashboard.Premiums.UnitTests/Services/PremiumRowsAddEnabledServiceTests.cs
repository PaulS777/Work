﻿using System.Collections.Generic;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    [TestFixture]
    public class PremiumRowsAddEnabledServiceTests
    {
        [Test]
        public void ShouldEnableAdd_When_Refresh_WithAllThresholdsNotNull()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 0);

            var rows = new List<IPremiumThresholdItem> { row1 };

            var service = new PremiumRowsAddEnabledService();

            var result = false;

            // ACT
            service.RefreshRows(rows, value => result = value);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldDisableAdd_When_Refresh_WithRowThresholdNull()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 0);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == null);

            var rows = new List<IPremiumThresholdItem> { row1, row2 };

            var service = new PremiumRowsAddEnabledService();

            var result = true;

            // ACT
            service.RefreshRows(rows, value => result = value);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldEnableAdd_When_NullThresholdUpdateToValue()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 0);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == null);

            var rows = new List<IPremiumThresholdItem> { row1, row2 };

            var service = new PremiumRowsAddEnabledService();

            var result = false;

            service.RefreshRows(rows, value => result = value);

            // ACT
            Mock.Get(row2).NotifyPropertyChanged(r => r.Threshold, 1000);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldNotEnableAddCommand_When_Disposed()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 0);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == null);

            var rows = new List<IPremiumThresholdItem> { row1, row2 };

            var service = new PremiumRowsAddEnabledService();

            var result = false;

            service.RefreshRows(rows, value => result = value);

            service.Dispose();

            // ACT
            Mock.Get(row2).NotifyPropertyChanged(r => r.Threshold, 1000);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 0);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == null);

            var rows = new List<IPremiumThresholdItem> { row1, row2 };

            var service = new PremiumRowsAddEnabledService();

            var result = false;

            service.RefreshRows(rows, value => result = value);

            service.Dispose();

            // ACT
            service.Dispose();
            Mock.Get(row2).NotifyPropertyChanged(r => r.Threshold, 1000);

            // ASSERT
            Assert.That(result, Is.False);
        }
    }
}
