﻿using System.Collections.Generic;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    [TestFixture]
    public class DuplicatePremiumRowServiceTests 
    {
        [Test]
        public void ShouldSetIsDuplicateTrue_When_MatchingThresholds()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 1000);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 50);

            var rows = new List<IPremiumThresholdItem> {row1, row2};

            var service = new DuplicatePremiumItemsService();

            service.RefreshItems(rows);

            // ACT
            Mock.Get(row2).NotifyPropertyChanged(r => r.Threshold, 1000);

            // ASSERT
            Assert.That(row1.IsDuplicate, Is.True);
            Assert.That(row2.IsDuplicate, Is.True);
        }
    }
}
