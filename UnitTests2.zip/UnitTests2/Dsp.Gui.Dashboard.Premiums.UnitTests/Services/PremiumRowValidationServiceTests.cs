﻿using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Moq;
using NUnit.Framework;
// ReSharper disable CompareOfFloatsByEqualityOperator

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    [TestFixture]
    public class PremiumRowValidationServiceTests
    {
        [Test]
        public void ShouldClearValidationError_When_RowDeleted()
        {
            var row = Mock.Of<IPremiumThresholdItem>(r => r.IsValid == false && r.ErrorText == "error" && r.IsDeleted);

            var validationService = new PremiumRowValidationService();

            // ACT
            validationService.ValidateRow(row);

            // ASSERT
            Assert.That(row.IsValid, Is.True);
            Assert.That(string.IsNullOrEmpty(row.ErrorText), Is.True);
        }

        [Test]
        public void ShouldClearValidationError_When_ValidationOk()
        {
            var row = Mock.Of<IPremiumThresholdItem>(r => r.IsValid == false
                                                         && r.ErrorText == "error"
                                                         && r.IsDuplicate == false 
                                                         && r.IsDeleted == false
                                                         && r.Threshold == 1000
                                                         && r.BidMargin == 1 
                                                         && r.AskMargin == 2);

            var validationService = new PremiumRowValidationService();

            // ACT
            validationService.ValidateRow(row);

            // ASSERT
            Assert.That(row.IsValid, Is.True);
            Assert.That(string.IsNullOrEmpty(row.ErrorText), Is.True);
        }

        [Test]
        public void ShouldSetValidationError_When_Duplicate()
        {
            var row = Mock.Of<IPremiumThresholdItem>(r => r.IsValid
                                                         && r.Threshold == null
                                                         && r.IsDuplicate
                                                         && r.IsDeleted == false
                                                         && r.Threshold == 1000
                                                         && r.BidMargin == 1
                                                         && r.AskMargin == 2);

            var validationService = new PremiumRowValidationService();

            // ACT
            validationService.ValidateRow(row);

            // ASSERT
            Assert.That(row.IsValid, Is.False);
            Assert.That(string.IsNullOrEmpty(row.ErrorText), Is.False);
        }

        [Test]
        public void ShouldSetValidationError_When_ThresholdIsNull()
        {
            var row = Mock.Of<IPremiumThresholdItem>(r => r.IsValid 
                                                         && r.Threshold == null
                                                         && r.IsDuplicate == false
                                                         && r.IsDeleted == false
                                                         && r.Threshold == null
                                                         && r.BidMargin == 1
                                                         && r.AskMargin == 2);

            var validationService = new PremiumRowValidationService();

            // ACT
            validationService.ValidateRow(row);

            // ASSERT
            Assert.That(row.IsValid, Is.False);
            Assert.That(string.IsNullOrEmpty(row.ErrorText), Is.False);
        }

        [Test]
        public void ShouldSetValidationError_When_ThresholdLessThanZero()
        {
            var row = Mock.Of<IPremiumThresholdItem>(r => r.IsValid
                                                          && r.Threshold == -1
                                                          && r.IsDuplicate == false
                                                          && r.IsDeleted == false
                                                          && r.Threshold == null
                                                          && r.BidMargin == 1
                                                          && r.AskMargin == 2);

            var validationService = new PremiumRowValidationService();

            // ACT
            validationService.ValidateRow(row);

            // ASSERT
            Assert.That(row.IsValid, Is.False);
            Assert.That(string.IsNullOrEmpty(row.ErrorText), Is.False);
        }

        [TestCase(2)]
        [TestCase(2.1)]
        public void ShouldSetValidationError_When_BidMargin_GreaterThanOrEqualToAsk(double margin)
        {
            var row = Mock.Of<IPremiumThresholdItem>(r => r.IsValid
                                                         && r.Threshold == null
                                                         && r.IsDuplicate == false
                                                         && r.IsDeleted == false
                                                         && r.Threshold == 1000
                                                         && r.BidMargin == margin
                                                         && r.AskMargin == 2);

            var validationService = new PremiumRowValidationService();

            // ACT
            validationService.ValidateRow(row);

            // ASSERT
            Assert.That(row.IsValid, Is.False);
            Assert.That(string.IsNullOrEmpty(row.ErrorText), Is.False);
        }
    }
}
