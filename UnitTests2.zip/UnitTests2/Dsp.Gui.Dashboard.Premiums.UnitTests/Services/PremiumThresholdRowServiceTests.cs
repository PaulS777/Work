﻿using Dsp.Gui.Dashboard.Premiums.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    [TestFixture]
    public class PremiumThresholdRowServiceTests
    {
        [Test]
        public void ShouldDisposeDuplicationService_OnDispose()
        {
            var duplicationService = new Mock<IDuplicatePremiumItemsService>();

            var rowService = new PremiumThresholdItemCollectionService(duplicationService.Object);

            rowService.Dispose();

            duplicationService.Verify(d => d.Dispose());
        }
    }
}
