﻿using System.Collections.Generic;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    [TestFixture]
    public class PremiumRowsDeleteEnabledServiceTests
    {
        [Test]
        public void ShouldEnableDelete_When_Refresh_WithMultipleRows_IsDeletedFalse()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.IsDeleted == false);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.IsDeleted == false);

            var rows = new List<IPremiumThresholdItem> { row1, row2 };

            var service = new PremiumRowsDeleteEnabledService();

            // ACT
            service.RefreshRows(rows);

            // ASSERT
            Assert.That(row1.CanDelete, Is.True);
            Assert.That(row2.CanDelete, Is.True);
        }

        [Test]
        public void ShouldDisableDeleteCommand_When_SingleRowRemains_AfterOtherDeleted()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.IsDeleted == false);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.IsDeleted == false);

            var rows = new List<IPremiumThresholdItem> { row1, row2 };

            var service = new PremiumRowsDeleteEnabledService();

            service.RefreshRows(rows);

            // ACT
            Mock.Get(row2).NotifyPropertyChanged(r => r.IsDeleted, true);

            // ASSERT
            Assert.That(row1.CanDelete, Is.False);
            Assert.That(row2.CanDelete, Is.False);
        }

        [Test]
        public void ShouldDisableDeleteCommand_When_Refresh_WithSingleRow_IsDeletedFalse()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.IsDeleted == false);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.IsDeleted == true);

            var rows = new List<IPremiumThresholdItem> { row1, row2 };

            var service = new PremiumRowsDeleteEnabledService();

            // ACT
            service.RefreshRows(rows);

            // ASSERT
            Assert.That(row1.CanDelete, Is.False);
            Assert.That(row2.CanDelete, Is.False);
        }

        [Test]
        public void ShouldEnableDelete_When_DeletedRow_RevertedToIsDeletedFalse()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.IsDeleted == false);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.IsDeleted == true);

            var rows = new List<IPremiumThresholdItem> { row1, row2 };

            var service = new PremiumRowsDeleteEnabledService();

            service.RefreshRows(rows);

            // ACT
            Mock.Get(row2).NotifyPropertyChanged(r => r.IsDeleted, false);

            // ASSERT
            Assert.That(row1.CanDelete, Is.True);
            Assert.That(row2.CanDelete, Is.True);
        }
    }
}
