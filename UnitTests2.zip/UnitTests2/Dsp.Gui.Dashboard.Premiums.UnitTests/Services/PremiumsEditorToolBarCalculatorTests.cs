﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Premiums.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    internal interface IPremiumsEditorToolBarCalculatorTestObjects
    {
        IPremiumsEditorToolBarService PremiumsEditorToolBarService { get; }
        IPremiumThresholdRowService VolumePremiumsRowService { get; }
        IPremiumThresholdRowService ValidityPremiumsRowService { get; }
        IPriceCurveFeesService PriceCurveFeesService { get; }
        ISubject<bool> CanEditPremiums { get; }
        ISubject<bool> VolumePremiumsCanUpdate { get; }
        ISubject<bool> VolumePremiumsCanUndo { get; }
        ISubject<bool> ValidityPremiumsCanUpdate { get; }
        ISubject<bool> ValidityPremiumsCanUndo { get; }
        ISubject<bool> FeesChanged { get; }
        ISubject<IList<string>> VolumeErrors { get; }
        ISubject<IList<string>> ValidityErrors { get; }
        PremiumsEditorToolBarCalculator ToolBarCalculator { get; }
    }

    [TestFixture]
    public class PremiumsEditorToolBarCalculatorTests
    {
        private class PremiumsEditorToolBarCalculatorTestObjectBuilder
        {
            private bool _canEditPremiums;
            private bool _volumePremiumsCanUpdate;
            private bool _volumePremiumsCanUndo;
            private bool _validityPremiumsCanUpdate;
            private bool _validityPremiumsCanUndo;
            private bool _feesChanged;
            private IList<string> _volumeErrors = new List<string>();
            private IList<string> _validityErrors = new List<string>();

            public PremiumsEditorToolBarCalculatorTestObjectBuilder WithCanEditPremiums(bool value)
            {
                _canEditPremiums = value;
                return this;
            }

            public PremiumsEditorToolBarCalculatorTestObjectBuilder WithVolumePremiumsCanUpdate(bool value)
            {
                _volumePremiumsCanUpdate = value;
                return this;
            }

            public PremiumsEditorToolBarCalculatorTestObjectBuilder WithVolumePremiumsCanUndo(bool value)
            {
                _volumePremiumsCanUndo = value;
                return this;
            }

            public PremiumsEditorToolBarCalculatorTestObjectBuilder WithValidityPremiumsCanUpdate(bool value)
            {
                _validityPremiumsCanUpdate = value;
                return this;
            }

            public PremiumsEditorToolBarCalculatorTestObjectBuilder WithValidityPremiumsCanUndo(bool value)
            {
                _validityPremiumsCanUndo = value;
                return this;
            }

            public PremiumsEditorToolBarCalculatorTestObjectBuilder WithFeesChanged(bool value)
            {
                _feesChanged = value;
                return this;
            }

            public PremiumsEditorToolBarCalculatorTestObjectBuilder WithVolumeErrors(IList<string> values)
            {
                _volumeErrors = values;
                return this;
            }

            public PremiumsEditorToolBarCalculatorTestObjectBuilder WithValidityErrors(IList<string> values)
            {
                _validityErrors = values;
                return this;
            }

            public IPremiumsEditorToolBarCalculatorTestObjects Build()
            {
                var testObjects = new Mock<IPremiumsEditorToolBarCalculatorTestObjects>();

                var canEditPremiums = new BehaviorSubject<bool>(_canEditPremiums);

                testObjects.SetupGet(o => o.CanEditPremiums)
                           .Returns(canEditPremiums);

                var volumePremiumsCanUpdate = new BehaviorSubject<bool>(_volumePremiumsCanUpdate);

                testObjects.SetupGet(o => o.VolumePremiumsCanUpdate)
                           .Returns(volumePremiumsCanUpdate);

                var volumeErrors = new BehaviorSubject<IList<string>>(_volumeErrors);

                testObjects.SetupGet(o => o.VolumeErrors)
                           .Returns(volumeErrors);

                var volumeCanUndo = new BehaviorSubject<bool>(_volumePremiumsCanUndo);

                testObjects.SetupGet(o => o.VolumePremiumsCanUndo)
                           .Returns(volumeCanUndo);

                var volumePremiumsRowService = new Mock<IPremiumThresholdRowService>();

                volumePremiumsRowService.SetupGet(v => v.CanExecuteUpdateCommand)
                                        .Returns(volumePremiumsCanUpdate);

                volumePremiumsRowService.SetupGet(v => v.ValidationErrors)
                                        .Returns(volumeErrors);

                volumePremiumsRowService.SetupGet(v => v.CanExecuteUndoCommand)
                                        .Returns(volumeCanUndo);

                testObjects.SetupGet(o => o.VolumePremiumsRowService)
                           .Returns(volumePremiumsRowService.Object);

                var validityPremiumsCanUpdate = new BehaviorSubject<bool>(_validityPremiumsCanUpdate);

                testObjects.SetupGet(o => o.ValidityPremiumsCanUpdate)
                           .Returns(validityPremiumsCanUpdate);

                var validityErrors = new BehaviorSubject<IList<string>>(_validityErrors);

                testObjects.SetupGet(o => o.ValidityErrors)
                           .Returns(validityErrors);

                var validityCanUndo = new BehaviorSubject<bool>(_validityPremiumsCanUndo);

                testObjects.SetupGet(o => o.ValidityPremiumsCanUndo)
                           .Returns(validityCanUndo);

                var validityPremiumsRowService = new Mock<IPremiumThresholdRowService>();

                validityPremiumsRowService.SetupGet(v => v.CanExecuteUpdateCommand)
                                          .Returns(validityPremiumsCanUpdate);

                validityPremiumsRowService.SetupGet(v => v.ValidationErrors)
                                          .Returns(validityErrors);

                validityPremiumsRowService.SetupGet(v => v.CanExecuteUndoCommand)
                                          .Returns(validityCanUndo);

                testObjects.SetupGet(o => o.ValidityPremiumsRowService)
                           .Returns(validityPremiumsRowService.Object);

                var feesChanged = new BehaviorSubject<bool>(_feesChanged);

                testObjects.SetupGet(o => o.FeesChanged)
                           .Returns(feesChanged);

                var priceCurveFeesService = new Mock<IPriceCurveFeesService>();

                priceCurveFeesService.SetupGet(p => p.HasChanged)
                                     .Returns(feesChanged);

                testObjects.SetupGet(o => o.PriceCurveFeesService)
                           .Returns(priceCurveFeesService.Object);

                var toolBarService = new Mock<IPremiumsEditorToolBarService>();

                testObjects.SetupGet(o => o.PremiumsEditorToolBarService)
                           .Returns(toolBarService.Object);

                var toolBarCalculator = new PremiumsEditorToolBarCalculator();

                testObjects.SetupGet(o => o.ToolBarCalculator)
                           .Returns(toolBarCalculator);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetToolBarCanUpdateFalse_When_EditorHasNoChanges_With_NoValidationErrors()
        {
            var volumeErrors = new string[] { };
            var validityErrors = new string[] { };

            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .WithVolumeErrors(volumeErrors)
                                                                                    .WithValidityErrors(validityErrors)
                                                                                    .WithValidityPremiumsCanUpdate(false)
                                                                                    .WithVolumePremiumsCanUpdate(false)
                                                                                    .WithFeesChanged(false)
                                                                                    .Build();

            // ACT
            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService,
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService,
                                                 testObjects.ValidityPremiumsRowService,
                                                 testObjects.PriceCurveFeesService);

  
            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUpdate(false));

            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUpdate(true), Times.Never);

            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.ClearValidation());
        }

        [TestCase(true, false, false)]
        [TestCase(false, true, false)]
        [TestCase(false, false, true)]
        public void ShouldSetToolBarCanUpdateTrue_When_EditorHasChanges_With_NoValidationErrors(bool volumeChanged, 
                                                                                                bool validityChanged, 
                                                                                                bool feesChanged)
        {
            var volumeErrors = new string[] { };
            var validityErrors = new string[] { };

            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .WithVolumeErrors(volumeErrors)
                                                                                    .WithValidityErrors(validityErrors)
                                                                                    .Build();

            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService, 
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService, 
                                                 testObjects.ValidityPremiumsRowService, 
                                                 testObjects.PriceCurveFeesService);

            testObjects.VolumePremiumsCanUpdate.OnNext(volumeChanged);
            testObjects.ValidityPremiumsCanUpdate.OnNext(validityChanged);
            testObjects.FeesChanged.OnNext(feesChanged);

            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUpdate(true));

            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.ClearValidation());
        }

        [Test]
        public void ShouldSetToolBarCanUpdateFalse_When_EditorHasChanges_With_VolumeValidationErrors()
        {
            var volumeErrors = new[] { "error" }; 
            var validityErrors = new string[] { };

            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .WithValidityErrors(validityErrors)
                                                                                    .WithValidityPremiumsCanUpdate(true)
                                                                                    .WithVolumePremiumsCanUpdate(false)
                                                                                    .WithFeesChanged(true)
                                                                                    .Build();

            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService,
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService,
                                                 testObjects.ValidityPremiumsRowService,
                                                 testObjects.PriceCurveFeesService);

            Mock.Get(testObjects.PremiumsEditorToolBarService).Invocations.Clear();

            // ACT
            testObjects.VolumeErrors.OnNext(volumeErrors);

            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUpdate(false));

            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetValidationErrors(It.Is<IList<string>>(e => e.Count == 1)));
        }

        [Test]
        public void ShouldSetToolBarCanUpdateFalse_When_EditorHasChanges_With_ValidityValidationErrors()
        {
            var volumeErrors = new string[] { };
            var validityErrors = new[] { "error" };

            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .WithVolumeErrors(volumeErrors)
                                                                                    .WithValidityPremiumsCanUpdate(false)
                                                                                    .WithVolumePremiumsCanUpdate(true)
                                                                                    .WithFeesChanged(true)
                                                                                    .Build();

            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService,
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService,
                                                 testObjects.ValidityPremiumsRowService,
                                                 testObjects.PriceCurveFeesService);

            Mock.Get(testObjects.PremiumsEditorToolBarService).Invocations.Clear();

            // ACT
            testObjects.ValidityErrors.OnNext(validityErrors);

            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUpdate(false));

            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetValidationErrors(It.Is<IList<string>>(e => e.Count == 1)));
        }

        [TestCase(true, false, false)]
        [TestCase(false, true, false)]
        [TestCase(false, false, true)]
        public void ShouldSetToolBarCanUndoTrue_When_EditorHasChanges(bool volumeCanUndo, 
                                                                      bool validityCanUndo, 
                                                                      bool feesChanged)
        {
            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .Build();

            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService,
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService,
                                                 testObjects.ValidityPremiumsRowService,
                                                 testObjects.PriceCurveFeesService);

            // ACT
            testObjects.VolumePremiumsCanUndo.OnNext(volumeCanUndo);
            testObjects.ValidityPremiumsCanUndo.OnNext(validityCanUndo);
            testObjects.FeesChanged.OnNext(feesChanged);

            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUndo(true));
        }

        [Test]
        public void ShouldSetToolBarCanUndoFalse_When_EditorHasNoChanges()
        {
            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .WithVolumePremiumsCanUndo(false)
                                                                                    .WithValidityPremiumsCanUndo(false)
                                                                                    .WithFeesChanged(true)
                                                                                    .Build();


            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService,
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService,
                                                 testObjects.ValidityPremiumsRowService,
                                                 testObjects.PriceCurveFeesService);

            Mock.Get(testObjects.PremiumsEditorToolBarService).Invocations.Clear();

            // ACT
            testObjects.FeesChanged.OnNext(false);

            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUndo(false));

            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUndo(true), Times.Never);
        }

        [Test]
        public void ShouldSetToolBarCanUpdateFalse_And_ClearValidationErrors_When_Readonly()
        {
            var volumeErrors = new[] { "error" };
            var validityErrors = new string[] { };

            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .WithVolumeErrors(volumeErrors)
                                                                                    .WithValidityErrors(validityErrors)
                                                                                    .WithValidityPremiumsCanUpdate(false)
                                                                                    .WithVolumePremiumsCanUpdate(false)
                                                                                    .WithFeesChanged(true)
                                                                                    .Build();

            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService,
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService,
                                                 testObjects.ValidityPremiumsRowService,
                                                 testObjects.PriceCurveFeesService);

            Mock.Get(testObjects.PremiumsEditorToolBarService).Invocations.Clear();

            // ACT
            testObjects.CanEditPremiums.OnNext(false);

            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUpdate(false));

            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.ClearValidation());
        }

        [Test]
        public void ShouldNotSetToolBarCanUpdate_When_Disposed()
        {
            var volumeErrors = new string[] { };
            var validityErrors = new string[] { };

            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .WithVolumeErrors(volumeErrors)
                                                                                    .WithValidityErrors(validityErrors)
                                                                                    .WithVolumePremiumsCanUpdate(false)
                                                                                    .WithValidityPremiumsCanUpdate(false)
                                                                                    .Build();

            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService,
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService,
                                                 testObjects.ValidityPremiumsRowService,
                                                 testObjects.PriceCurveFeesService);

            testObjects.ToolBarCalculator.Dispose();

            Mock.Get(testObjects.PremiumsEditorToolBarService).Invocations.Clear();

            // ACT
            testObjects.FeesChanged.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUpdate(It.IsAny<bool>()), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var volumeErrors = new string[] { };
            var validityErrors = new string[] { };

            var testObjects = new PremiumsEditorToolBarCalculatorTestObjectBuilder().WithCanEditPremiums(true)
                                                                                    .WithVolumeErrors(volumeErrors)
                                                                                    .WithValidityErrors(validityErrors)
                                                                                    .WithVolumePremiumsCanUpdate(false)
                                                                                    .WithValidityPremiumsCanUpdate(false)
                                                                                    .Build();

            testObjects.ToolBarCalculator.Attach(testObjects.PremiumsEditorToolBarService,
                                                 testObjects.CanEditPremiums,
                                                 testObjects.VolumePremiumsRowService,
                                                 testObjects.ValidityPremiumsRowService,
                                                 testObjects.PriceCurveFeesService);

            testObjects.ToolBarCalculator.Dispose();
            testObjects.ToolBarCalculator.Dispose();

            Mock.Get(testObjects.PremiumsEditorToolBarService).Invocations.Clear();

            // ACT
            testObjects.FeesChanged.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.PremiumsEditorToolBarService)
                .Verify(p => p.SetCanUpdate(It.IsAny<bool>()), Times.Never);
        }
    }
}
