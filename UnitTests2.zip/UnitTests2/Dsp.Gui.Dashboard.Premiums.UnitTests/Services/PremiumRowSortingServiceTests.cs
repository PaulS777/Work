﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.Premiums.Services;
using Dsp.Gui.Dashboard.Premiums.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Premiums.UnitTests.Services
{
    [TestFixture]
    public class PremiumRowSortingServiceTests
    {
        [Test]
        public void ShouldPublishInitialSortOrder()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 2000);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 1000);

            var rows = new[] { row1, row2 };

            var service = new PremiumRowSortingService();

            IList<IPremiumThresholdItem> result = null;

            var expected = new[] { row2, row1 };

            using (service.RowsSorted.Subscribe(r => result = r))
            {
                // ACT
                service.RefreshRows(rows);

                // ASSERT
                Assert.That(result.SequenceEqual(expected));
            }
        }

        [Test]
        public void ShouldPublishSortedRows_When_ThresholdChange_Causes_SortOrderChange()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 1000);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 2000);

            var rows = new[] { row1, row2 };

            var service = new PremiumRowSortingService();

            IList<IPremiumThresholdItem> result = null;

            using (service.RowsSorted.Subscribe(r => result = r))
            {
                service.RefreshRows(rows);

                // ACT
                Mock.Get(row1).NotifyPropertyChanged(r => r.Threshold, 3000);

                // ASSERT
                Assert.That(result[0].Threshold == 2000 && result[1].Threshold == 3000);
            }
        }

        [Test]
        public void ShouldNotPublish_When_ThresholdChange_DoesNotCause_SortOrderChange()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 1000);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 2000);

            var rows = new[] { row1, row2 };

            var service = new PremiumRowSortingService();

            IList<IPremiumThresholdItem> result = null;

            using (service.RowsSorted.Subscribe(r => result = r))
            {
                service.RefreshRows(rows);

                result = null;

                // ACT
                Mock.Get(row1).NotifyPropertyChanged(r => r.Threshold, 500);

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldPublishSortedRows_With_NullThresholdAsLastEntry()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 2000);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 1000);
            var row3 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == null);

            var rows = new[] { row1, row2, row3 };

            var service = new PremiumRowSortingService();

            IList<IPremiumThresholdItem> result = null;

            using (service.RowsSorted.Subscribe(r => result = r))
            {
                // ACT
                service.RefreshRows(rows);

                // ASSERT
                Assert.That(result[0].Threshold == 1000
                            && result[1].Threshold == 2000
                            && result[2].Threshold == null);
            }
        }

        [Test]
        public void ShouldNotPublishWhenDisposed()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 1000);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 2000);

            var rows = new[] { row1, row2 };

            var service = new PremiumRowSortingService();

            IList<IPremiumThresholdItem> result = null;

            using (service.RowsSorted.Subscribe(r => result = r))
            {
                service.RefreshRows(rows);

                result = null;

                service.Dispose();

                // ACT
                Mock.Get(row1).NotifyPropertyChanged(r => r.Threshold, 3000);

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldNotDisposeWhenDisposed()
        {
            var row1 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 1000);
            var row2 = Mock.Of<IPremiumThresholdItem>(r => r.Threshold == 2000);

            var rows = new[] { row1, row2 };

            var service = new PremiumRowSortingService();

            IList<IPremiumThresholdItem> result = null;

            using (service.RowsSorted.Subscribe(r => result = r))
            {
                service.RefreshRows(rows);

                result = null;

                service.Dispose();

                // ACT
                service.Dispose();
                Mock.Get(row1).NotifyPropertyChanged(r => r.Threshold, 3000);

                // ASSERT
                Assert.IsNull(result);
            }
        }
    }
}
