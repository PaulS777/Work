﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Fx.Premiums.Controllers;
using Dsp.Gui.Fx.Premiums.ViewModels;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;
using System.Linq;
using System.Reactive.Linq;
using Dsp.DataContracts.AdminActions;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Fx.Premiums.Models;
using Dsp.Gui.Common.UnitTests;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.TestObjects;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.UnitTest.Helpers.Builders;

namespace Dsp.Gui.Fx.Premiums.UnitTests.Controllers
{
    public interface IFxPremiumsViewModelControllerTestObjects
    {
        IAdminApiServiceClient AdminApiServiceClient { get; }
        IAdminApiHubConnection HubConnectionProxy { get; }
        IFxCurvePipsBufferUpdateService FxPremiumsUpdateService { get; }
        ICurveControlService CurveControlService { get; }
        IFxPremiumsToolBarService ToolBarService { get; }
        IPopupNotificationService PopupNotificationService { get; }
        ISubject<Unit> ToolBarUpdate { get; }
        TestScheduler TestScheduler { get; }
        FxPremiumsViewModelController Controller { get; }
        FxPremiumsViewModel ViewModel { get; }
        ISubject<Unit> FxPremiumsUpdated { get; }
    }

    [TestFixture, Ignore("Fix Mocks Task-2744236")]
    public class FxPremiumsViewModelControllerTests
    {
        private class FxPremiumsViewModelControllerTestObjectBuilder
        {
            private User _user;
            private List<User> _activeUsers;
            private bool? _instanceStatus = null;
            private bool _toolBarVisible;

            public FxPremiumsViewModelControllerTestObjectBuilder WithUser(User value)
            {
                _user = value;
                return this;
            }

            public FxPremiumsViewModelControllerTestObjectBuilder WithActiveUsers(List<User> value)
            {
                _activeUsers = value;
                return this;
            }

            public FxPremiumsViewModelControllerTestObjectBuilder WithToolBarVisible(bool value)
            {
                _toolBarVisible = value;
                return this;
            }

            public IFxPremiumsViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IFxPremiumsViewModelControllerTestObjects>();

                var testScheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();
                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);
                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
                schedulerProvider.SetupGet(p => p.Immediate).Returns(Scheduler.Immediate);

                var user = new User(235, "muhammad.syed", "muhammad.syed", false, true, 0, 0, 0,
                                    new[]
                                    {
                                        new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, false),
                                        new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                                        new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                                        new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                                        new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, false)
                                    },
                                    new[]
                                    {
                                        new AuthorisationCurveRegion(CurveRegion.Asia, true, true),
                                        new AuthorisationCurveRegion(CurveRegion.Europe, true, true),
                                        new AuthorisationCurveRegion(CurveRegion.MiddleEast, true, true)
                                    },
                                    new[]
                                    {
                                        new AuthorisationFxCurve(21, true, true) //,
                                    },
                                    new List<UserChatTenorSelection>(),
                                    new List<AuthorisationUserPermission>());

                var anotherUser = new User(244, "muhammad.syed1", "muhammad.syed1", false, true, 0, 0, 0,
                                           new[]
                                           {
                                               new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, false),
                                               new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                                               new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                                               new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                                               new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, false)
                                           },
                                           new[]
                                           {
                                               new AuthorisationCurveRegion(CurveRegion.Asia, true, true),
                                               new AuthorisationCurveRegion(CurveRegion.Europe, true, true),
                                               new AuthorisationCurveRegion(CurveRegion.MiddleEast, true, true)
                                           },
                                           new[]
                                           {
                                               new AuthorisationFxCurve(21, true, true) //,
                                           },
                                           new List<UserChatTenorSelection>(),
                                           new List<AuthorisationUserPermission>());

                _activeUsers = new List<User> {user, anotherUser};

                var adminApiServiceClient = new Mock<IAdminApiServiceClient>();

                testObjects.SetupGet(o => o.AdminApiServiceClient)
                           .Returns(adminApiServiceClient.Object);

                var hubConnectionProxy = new Mock<IAdminApiHubConnection>();

                testObjects.SetupGet(o => o.HubConnectionProxy)
                           .Returns(hubConnectionProxy.Object);

                var subject = new BehaviorSubject<bool?>(_instanceStatus);

                var connectionInstance = new Mock<IMutexInstance>();

                connectionInstance.SetupGet(c => c.Status)
                                  .Returns(subject);

                //var hubConnectionService = new Mock<IHubConnectionService>();

                //hubConnectionService.SetupGet(h => h.ConnectionState)
                //                    .Returns(Observable.Return(ConnectionState.Connected));

                //hubConnectionService.SetupGet(h => h.CurrentUser)
                //                    .Returns(Observable.Return(user));

                var configProvider = new Mock<IConfigProvider>();

                var curveControlService = new Mock<ICurveControlService>();

                //User currentUserUpdate = null;
                //curveControlService.CurrentUser.Subscribe(u => currentUserUpdate = user);
                //curveControlService.OnUsersNotification(_activeUsers);

                curveControlService.SetupGet(c => c.Users)
                                   .Returns(Observable.Return(_activeUsers));

                curveControlService.SetupGet(c => c.CurrentUser)
                                   .Returns(Observable.Return(user));

                var fxCurveDefinitions = new List<FxCurveDefinition>
                {
                    new FxCurveDefinition(21, "FX_EURUSD", "FX EUR/USD", Currency.EUR, Currency.USD, null, 24, true, "", EntityStatus.Active),
                    new FxCurveDefinition(22, "FX_GBPUSD", "FX GBP/USD", Currency.GBP, Currency.USD, null, 24, true, "", EntityStatus.Active),
                    new FxCurveDefinition(23, "FX_CHFUSD", "FX CHF/USD", Currency.CHF, Currency.USD,
                                          FxCurveIds.UsdChf, 24, true, "", EntityStatus.Active),
                    new FxCurveDefinition(24, "FX_CADUSD", "FX CAD/USD", Currency.CAD, Currency.USD,
                                          FxCurveIds.UsdCad, 24, true, "", EntityStatus.Active)
                    //new FxCurveDefinitionTestObjectBuilder().WithId(21)

                };

                curveControlService.SetupGet(c => c.FxCurveDefinitions)
                                   .Returns(Observable.Return(fxCurveDefinitions));

         
                //using (curveControlService.FxCurveDefinitions.Subscribe(settings =>
                //                                                            result = fxCurveDefinitionSettings))
                //{
                //    curveControlService.OnFxCurveDefinitionSnapshot(result);
                //}

                var fxCurveSettings = new List<FxCurveSetting>
                {
                    new FxCurveSetting(21, 235, 0, true, true),
                    new FxCurveSetting(22, 244, 0, true, true),
                    new FxCurveSetting(23, 244, 0, true, true),
                    new FxCurveSetting(24, 244, 0, true, true)
                };


                curveControlService.SetupGet(c => c.FxCurveSettings)
                                   .Returns(Observable.Return(fxCurveSettings));



                //using (curveControlService.FxCurveSettings.Subscribe(settings =>
                //                                                         fxCurveSettingResult = fxCurveSettings))
                //{
                //    curveControlService.OnFxCurveSettingsSnapshot(fxCurveSettingResult);
                //}

                var fxCurvePipsBuffers = new List<FxCurvePipsBuffer>
                {
                    new(21, new List<PipsBufferPeriod>
                            {
                                new(false, new TimeSpan(0, 0, 0), 420),
                                new(true, new TimeSpan(15, 0, 0), 20),
                                new(true, new TimeSpan(19, 0, 0), 200),
                            }
                       ),
                    new(22, new List<PipsBufferPeriod>
                            {
                                new(false, new TimeSpan(0, 0, 0), 420),
                                new(true, new TimeSpan(15, 0, 0), 20),
                                new(true, new TimeSpan(19, 0, 0), 200),
                            }
                       ),
                    new(23, new List<PipsBufferPeriod>
                            {
                                new(false, new TimeSpan(0, 0, 0), 420),
                                new(true, new TimeSpan(15, 0, 0), 20),
                                new(true, new TimeSpan(19, 0, 0), 200),
                            }
                       ),
                    new(24, new List<PipsBufferPeriod>
                            {
                                new(false, new TimeSpan(0, 0, 0), 420),
                                new(true, new TimeSpan(15, 0, 0), 20),
                                new(true, new TimeSpan(19, 0, 0), 200),
                            }
                       )
                };

                curveControlService.SetupGet(c => c.FxCurvePipsBuffers)
                                   .Returns(Observable.Return(fxCurvePipsBuffers));

                curveControlService.Setup(c => c.GetFxCurvePipsBufferSnapshot())
                                   .Returns(fxCurvePipsBuffers);

                //using (curveControlService.FxCurvePipsBuffers.Subscribe(settings =>
                //                                                            fxCurvePipsBuffersResult =
                //                                                                fxCurvePipsBuffers))
                //{
                //    curveControlService.OnFxCurvePipsBufferSnapshot(fxCurvePipsBuffersResult);
                //}

                //testObjects.SetupGet(o => o.CurveControlService).Returns(curveControlService);

                var fxPremiumsUpdated = new Subject<Unit>();

                testObjects.SetupGet(o => o.FxPremiumsUpdated)
                           .Returns(fxPremiumsUpdated);

                var fxPremiumsUpdateService = new Mock<IFxCurvePipsBufferUpdateService>();

                fxPremiumsUpdateService.Setup(f => f.Update(It.IsAny<FxCurvePipsBuffer>(), It.IsAny<IScheduler>()))
                                       .Returns(fxPremiumsUpdated);

                testObjects.SetupGet(o => o.FxPremiumsUpdateService)
                           .Returns(fxPremiumsUpdateService.Object);

                var toolBarUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUpdate).Returns(toolBarUpdate);

                var toolBarService = new Mock<IFxPremiumsToolBarService>();

                toolBarService.SetupGet(tb => tb.ToolBarVisible).Returns(_toolBarVisible);
                toolBarService.SetupGet(tb => tb.Update).Returns(toolBarUpdate);

                testObjects.SetupGet(o => o.ToolBarService).Returns(toolBarService.Object);

                var popupNotificationService = new Mock<IPopupNotificationService>();
                testObjects.SetupGet(o => o.PopupNotificationService).Returns(popupNotificationService.Object);

                var controller = new FxPremiumsViewModelController(
                    curveControlService.Object,
                    toolBarService.Object,
                    fxPremiumsUpdateService.Object,
                    popupNotificationService.Object,
                    schedulerProvider.Object,
                    Mocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSet_OnSelectedFxCurve()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();

            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[0];

            Assert.IsTrue(testObjects.ViewModel.IsSelectedFxPips);
            Assert.IsTrue(testObjects.ViewModel.AddNewFxCurvePeriodCommand.CanExecute());
            Assert.IsFalse(testObjects.ViewModel.RemoveFxCurvePeriodCommand.CanExecute());
        }

        [Test]
        public void ShouldSet_OnSelectedFxCurvePeriod()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[0];

            Assert.IsTrue(testObjects.ViewModel.IsSelectedFxPips);
            Assert.IsTrue(testObjects.ViewModel.AddNewFxCurvePeriodCommand.CanExecute());
            Assert.IsFalse(testObjects.ViewModel.RemoveFxCurvePeriodCommand.CanExecute());
        }
            
        [Test]
        public void ShouldSet_OnSelectedFxCurvePeriodCanUpdate()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[0];
            testObjects.ViewModel.SelectedFxPipsBufferPeriodGui =
                testObjects.ViewModel.FxCurvePipsGui[0].FxCurvePips[0];

            Assert.IsTrue(testObjects.ViewModel.SelectedFxCurvePipsGui.AllowEdit);
            Assert.IsTrue(testObjects.ViewModel.AddNewFxCurvePeriodCommand.CanExecute());
            Assert.IsTrue(testObjects.ViewModel.RemoveFxCurvePeriodCommand.CanExecute());
        } 
            
        [Test]
        public void ShouldSet_OnSelectedFxCurvePeriodCanNotUpdate()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[1];
            testObjects.ViewModel.SelectedFxPipsBufferPeriodGui =
                testObjects.ViewModel.FxCurvePipsGui[1].FxCurvePips[0];

            Assert.IsFalse(testObjects.ViewModel.SelectedFxCurvePipsGui.AllowEdit);
            Assert.IsFalse(testObjects.ViewModel.AddNewFxCurvePeriodCommand.CanExecute());
            Assert.IsFalse(testObjects.ViewModel.RemoveFxCurvePeriodCommand.CanExecute());
        }

        [Test]
        public void ShouldSetBusyAndInvokeUpdate_OnToolBarUpdateCommand()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[1];
            testObjects.ViewModel.SelectedFxPipsBufferPeriodGui =
                testObjects.ViewModel.FxCurvePipsGui[1].FxCurvePips[0];

            testObjects.ViewModel.FxCurvePipsGui[1].FxCurvePips[0].PipsBuffer = 35;

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.AreEqual(35, testObjects.ViewModel.FxCurvePipsGui[1].FxCurvePips[0].PipsBuffer);
            Assert.IsTrue(testObjects.ViewModel.IsBusy);
            Assert.IsNotEmpty(testObjects.ViewModel.BusyText);

            Mock.Get(testObjects.FxPremiumsUpdateService)
                .Verify(u => u.Update(It.IsAny<FxCurvePipsBuffer>(), It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldSet_OnUpdateDuplicateFxCurvePeriod()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[0];
            testObjects.ViewModel.SelectedFxPipsBufferPeriodGui =
                testObjects.ViewModel.FxCurvePipsGui[0].FxCurvePips[0];

            FxPipsBufferPeriodGui newPeriodGui = new FxPipsBufferPeriodGui();
            newPeriodGui.PipsBuffer = 400;
            newPeriodGui.IsBusinessDay = false;
            newPeriodGui.StartTime = new TimeSpan(0, 0, 0);

            testObjects.ViewModel.SelectedFxCurvePipsGui.FxCurvePips.Add(newPeriodGui);

            // ACT
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            Assert.AreEqual("Duplicate period added. Please remove to continue.", testObjects.ViewModel.MessageDialog.DialogMessages[0]);
            Assert.IsFalse(testObjects.ViewModel.IsBusy);
            Assert.IsEmpty(testObjects.ViewModel.BusyText);
        }
        
        [Test]
        public void ShouldSet_OnAddFxCurvePeriod()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[0];
            testObjects.ViewModel.SelectedFxPipsBufferPeriodGui =
                testObjects.ViewModel.FxCurvePipsGui[0].FxCurvePips[0];

            testObjects.ViewModel.AddNewFxCurvePeriodCommand.Execute();

            Assert.IsTrue(testObjects.ViewModel.SelectedFxCurvePipsGui.FxCurvePips.Count==4);

            Assert.IsTrue(testObjects.ViewModel.AddNewFxCurvePeriodCommand.CanExecute());
            Assert.IsTrue(testObjects.ViewModel.RemoveFxCurvePeriodCommand.CanExecute());

            Mock.Get(testObjects.ToolBarService).Verify(tb => tb.SetCanUpdate(true));
        }
        
        [Test]
        public void ShouldSet_OnRemoveFxCurvePeriod()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[0];
            testObjects.ViewModel.SelectedFxPipsBufferPeriodGui =
                testObjects.ViewModel.FxCurvePipsGui[0].FxCurvePips[0];

            testObjects.ViewModel.RemoveFxCurvePeriodCommand.Execute();

            Assert.IsTrue(testObjects.ViewModel.SelectedFxCurvePipsGui.FxCurvePips.Count == 2);

            Assert.IsTrue(testObjects.ViewModel.AddNewFxCurvePeriodCommand.CanExecute());
            Assert.IsTrue(testObjects.ViewModel.RemoveFxCurvePeriodCommand.CanExecute());

            Mock.Get(testObjects.ToolBarService).Verify(tb => tb.SetCanUpdate(true));
        }


        [Test]
        public void ShouldShowPopup_OnUpdateFxCurvePeriodSuccess()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[0];
            testObjects.ViewModel.SelectedFxPipsBufferPeriodGui =
                testObjects.ViewModel.FxCurvePipsGui[0].FxCurvePips[0];

            testObjects.ViewModel.FxCurvePipsGui[0].FxCurvePips[0].PipsBuffer = 35;

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.FxPremiumsUpdated.OnNext(Unit.Default);
            testObjects.FxPremiumsUpdated.OnCompleted();

            // ASSERT
            Mock.Get(testObjects.PopupNotificationService).Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
        }

        [Test]
        public void ShouldSet_OnUpdateFxCurvePeriodFailure()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.ViewModel.SelectedFxCurvePipsGui = testObjects.ViewModel.FxCurvePipsGui[0];
            testObjects.ViewModel.SelectedFxPipsBufferPeriodGui =
                testObjects.ViewModel.FxCurvePipsGui[0].FxCurvePips[0];

            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            var exception = new Exception("Unauthorized");

            testObjects.FxPremiumsUpdated.OnError(exception);

            Assert.IsFalse(testObjects.ViewModel.IsBusy);
            Assert.IsEmpty(testObjects.ViewModel.BusyText);
            Assert.IsTrue(testObjects.ViewModel.ShowDialog);
        }

        [Test]
        public void ShouldMatch_OnFxCurvesLoaded()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            Assert.That(testObjects.ViewModel.FxCurvePipsGui.Count, 
                        Is.EqualTo(testObjects.CurveControlService.GetFxCurvePipsBufferSnapshot().Count()));

            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Empty);
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldCloseMessageDialog_OnDialogOkCommand()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.ShowDialog = true;

            // ACT
            testObjects.ViewModel.MessageDialog.DialogOkCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowDialog);
        }

        [Test]
        public void ShouldCloseMessageDialog_OnCompletedDialogOkCommand()
        {
            var currentUser = GetCurrentUser();
            var anotherUser = GetAnotherUser();
            var activeUsers = new List<User> { currentUser, anotherUser };

            var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
                                                                                  .WithUser(currentUser)
                                                                                  .Build();

            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1001).Ticks);
            testObjects.ViewModel.ShowCompletedDialog = true;

            // ACT
            testObjects.ViewModel.MessageDialog.CompletedDialogOkCommand.Execute();

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowCompletedDialog);
        }

        private User GetCurrentUser()
        {
            var user = new User(235, "muhammad.syed", "muhammad.syed", false, true, 0, 0, 0,
                new[]
                {
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, false),
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, false)
                },
                new[]
                {
                new AuthorisationCurveRegion(CurveRegion.Asia, true, true),
                new AuthorisationCurveRegion(CurveRegion.Europe, true, true),
                new AuthorisationCurveRegion(CurveRegion.MiddleEast, true, true)
                },
                new[]
                {
                new AuthorisationFxCurve(21, true, true) //,
                },
                new List<UserChatTenorSelection>(),
                new List<AuthorisationUserPermission>());

            return user;
        }

        private User GetAnotherUser()
        {
            var anotherUser = new User(1, "muhammad.syed1", "muhammad.syed1", false, true, 0, 0, 0,
                new[]
                {
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, false),
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true),
                new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, false)
                },
                new[]
                {
                new AuthorisationCurveRegion(CurveRegion.Asia, true, true),
                new AuthorisationCurveRegion(CurveRegion.Europe, true, true),
                new AuthorisationCurveRegion(CurveRegion.MiddleEast, true, true)
                },
                new[]
                {
                new AuthorisationFxCurve(21, true, true) //,
                },
                new List<UserChatTenorSelection>(),
                new List<AuthorisationUserPermission>());

            return anotherUser;
        }

    private IFxPremiumsViewModelControllerTestObjects GetFxPremiumsViewModelControllerTestObjectBuilder()
    {
    var currentUser = GetCurrentUser();
    var anotherUser = GetAnotherUser();

    var activeUsers = new List<User> { currentUser, anotherUser };

    var testObjects = new FxPremiumsViewModelControllerTestObjectBuilder().WithActiveUsers(activeUsers)
        .WithUser(currentUser)
        .Build();

    return testObjects;
    }

}
}
  

