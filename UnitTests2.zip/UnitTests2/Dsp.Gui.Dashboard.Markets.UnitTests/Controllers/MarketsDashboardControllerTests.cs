﻿using System;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.Markets.Controllers;
using Dsp.Gui.Dashboard.Markets.ViewModels;
using Dsp.Gui.Dashboard.ToolBar.Markets.Controllers;
using Dsp.Gui.Dashboard.ToolBar.Markets.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.Dashboard.Markets.Services;
using Dsp.Gui.Dashboard.ScratchPad.Controllers;
using Dsp.Gui.Dashboard.ScratchPad.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels;

namespace Dsp.Gui.Dashboard.Markets.UnitTests.Controllers
{
    internal interface IMarketsViewModelControllerTestObjects
    {
        IDashboardSettingsService DashboardSettingsService { get; }
        IMarketsDashboardService MarketsDashboardService { get; }
        IMarketsToolBarController MarketsToolBarController { get; }
        IDashboardPanelsLayoutService DashboardPanelsLayoutService { get; }
        IScratchPadInfoService ScratchPadInfoService { get; }
        ISubject<bool> ShowScratchPadNavigationPopup { get; }
        ISubject<bool> ShowScratchPadHelpPopup { get; }
        ISubject<List<int>> PagesLoaded { get; }
        ISubject<DashboardSettingsCollection> DashboardSettings { get; }
        ISubject<DashboardSettings> DashboardAdded { get; }
        ISubject<SystemRunConnectState> SystemRunConnectState { get; }
        MarketsDashboardController Controller { get; }
        MarketsDashboardViewModel ViewModel { get; }
    }

    [TestFixture]
    public class MarketsDashboardControllerTests
    {
        private class MarketsDashboardControllerTestObjectBuilder
        {
            private int? _pageNumber;
            private List<int> _pagesLoaded;
            private bool _priceGridLoaded;
            private SystemRunConnectState _systemRunConnectState;
            private PriceGridToolBarViewModel _priceGridToolBar;

            public MarketsDashboardControllerTestObjectBuilder WithPriceGridToolBar(PriceGridToolBarViewModel value)
            {
                _priceGridToolBar = value;
                return this;
            }

            public MarketsDashboardControllerTestObjectBuilder WithPageNumber(int value)
            {
                _pageNumber = value;
                return this;
            }

            public MarketsDashboardControllerTestObjectBuilder WithPagesLoaded(List<int> value)
            {
                _pagesLoaded = value;
                return this;
            }

            public MarketsDashboardControllerTestObjectBuilder WithPriceGridLoaded(bool value)
            {
                _priceGridLoaded = value;
                return this;
            }

            public MarketsDashboardControllerTestObjectBuilder WithSystemRunConnectState(SystemRunConnectState value)
            {
                _systemRunConnectState = value;
                return this;
            }

            public IMarketsViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IMarketsViewModelControllerTestObjects>();

                var dashboardAdded = new BehaviorSubject<DashboardSettings>(null);

                testObjects.SetupGet(o => o.DashboardAdded)
                           .Returns(dashboardAdded);

                var dashboardSettings = new BehaviorSubject<DashboardSettingsCollection>(null);

                testObjects.SetupGet(o => o.DashboardSettings)
                           .Returns(dashboardSettings);

                var dashboardSettingsService = new Mock<IDashboardSettingsService>();

                dashboardSettingsService.SetupGet(d => d.DashboardSettings)
                                        .Returns(dashboardSettings);

                dashboardSettingsService.SetupGet(d => d.DashboardAdded)
                                        .Returns(dashboardAdded);

                testObjects.SetupGet(o => o.DashboardSettingsService)
                           .Returns(dashboardSettingsService.Object);

                var marketsDashboardService = new Mock<IMarketsDashboardService>();

                testObjects.SetupGet(o => o.MarketsDashboardService)
                           .Returns(marketsDashboardService.Object);

                var marketsToolBar = new MarketsToolBarViewModel();

                var marketsToolBarController = new Mock<IMarketsToolBarController>();

                testObjects.SetupGet(o => o.MarketsToolBarController)
                           .Returns(marketsToolBarController.Object);

                marketsToolBarController.SetupGet(c => c.ViewModel)
                                        .Returns(marketsToolBar);

                var startupState = new BehaviorSubject<SystemRunConnectState>(_systemRunConnectState);

                testObjects.SetupGet(o => o.SystemRunConnectState)
                           .Returns(startupState);

                var connectionStatusService = new Mock<IConnectionRunStateMonitor>();

                connectionStatusService.SetupGet(c => c.RunState)
                                       .Returns(startupState);

                var pagesLoaded = new BehaviorSubject<List<int>>(_pagesLoaded);

                testObjects.SetupGet(o => o.PagesLoaded)
                           .Returns(pagesLoaded);

                var pagesLoadedService = new Mock<IPagesLoadedService>();

                pagesLoadedService.SetupGet(p => p.PagesLoaded)
                                  .Returns(pagesLoaded);

                var showScratchPadNavigationPopup = new Subject<bool>();

                testObjects.SetupGet(o => o.ShowScratchPadNavigationPopup)
                           .Returns(showScratchPadNavigationPopup);

                var showScratchPadHelpPopup = new Subject<bool>();

                testObjects.SetupGet(o => o.ShowScratchPadHelpPopup)
                           .Returns(showScratchPadHelpPopup);

                var scratchPadInfoService = new Mock<IScratchPadInfoService>();

                scratchPadInfoService.SetupGet(o => o.ShowScratchPadNavigationPopup)
                                     .Returns(showScratchPadNavigationPopup);

                scratchPadInfoService.SetupGet(o => o.ShowScratchPadHelpPopup)
                                     .Returns(showScratchPadHelpPopup);

                testObjects.SetupGet(o => o.ScratchPadInfoService)
                           .Returns(scratchPadInfoService.Object);

                var scratchPadHelp = new ScratchPadHelpViewModel();

                var scratchPadHelpController = new Mock<IScratchPadHelpController>();

                scratchPadHelpController.SetupGet(c => c.ViewModel)
                                        .Returns(scratchPadHelp);

                var dashboardPanelsDisplayService = new Mock<IDashboardPanelsLayoutService>();

                testObjects.SetupGet(o => o.DashboardPanelsLayoutService)
                           .Returns(dashboardPanelsDisplayService.Object);

                var controller = new MarketsDashboardController(dashboardSettingsService.Object,
                                                                connectionStatusService.Object,
                                                                pagesLoadedService.Object,
                                                                marketsToolBarController.Object,
                                                                scratchPadHelpController.Object,
                                                                marketsDashboardService.Object,
                                                                TestMocks.GetSchedulerProvider().Object,
                                                                TestMocks.GetLoggerFactory().Object)
                                 {
                                     DashboardPanelsLayoutService = dashboardPanelsDisplayService.Object,
                                     ScratchPadInfoService = scratchPadInfoService.Object
                                 };

                controller.ViewModel.ScratchPad = new ScratchPadViewModel();
                
                if (_pageNumber.HasValue)
                {
                    controller.ViewModel.PageNumber = _pageNumber.Value;
                }

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                marketsDashboardService.Setup(d => d.BuildNewDashboard(It.IsAny<MarketsDashboardViewModel>(),
                                                                       It.IsAny<MarketsToolBarViewModel>(),
                                                                       It.IsAny<int>()))
                                       .Callback<MarketsDashboardViewModel, MarketsToolBarViewModel, int>((_, _, _) =>
                                       {
                                           controller.ViewModel.PriceGrid = new PriceGridViewModel
                                           {
                                               ToolBar = _priceGridToolBar,
                                               PriceGridLoaded = _priceGridLoaded
                                           };
                                       })
                                       .Returns(_priceGridToolBar);

                return testObjects.Object;
            }
        }

        #region Connection and Page Loaded

        [Test]
        public void ShouldSubscribeDashboardSettings_OnConnected_With_PageLoaded()
        {
            var pagesLoaded = new List<int> { 1, 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .Build();
            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.Connected);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .VerifyGet(d => d.DashboardSettings);
        }

        [Test]
        public void ShouldSubscribeDashboardSettings_OnReconnected_With_PageLoaded()
        {
            var pagesLoaded = new List<int> { 1, 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .Build();

            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.Reconnected);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .VerifyGet(d => d.DashboardSettings);
        }

        [Test]
        public void ShouldNotSubscribeDashboardSettings_OnConnected_WithPage_NotLoaded()
        {
            var pagesLoaded = new List<int> { 1 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .Build();
            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .VerifyGet(d => d.DashboardSettings, Times.Never());
        }

        [Test]
        public void ShouldNotSubscribeDashboardSettings_OnFailedStartup_With_PageLoaded()
        {
            var pagesLoaded = new List<int> { 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .Build();
            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.FailedStartup);

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .VerifyGet(d => d.DashboardSettings, Times.Never);
        }

        #endregion

        #region Load from Settings

        [Test]
        public void ShouldInitializeDashboard_With_DefaultSettings_OnSettingsLoaded_With_SettingsEmpty()
        {
            var pagesLoaded = new List<int> { 1 };

            var dashboardSettings = new DashboardSettingsCollection
            {
                DashboardSettings = []
            };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(1)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ACT
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ASSERT
            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.BuildNewDashboard(testObjects.ViewModel,
                                                 testObjects.MarketsToolBarController.ViewModel,
                                                 1));

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(ds => ds.InitializeWithDefaultSettings(1));

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.InitializeDashboard());

            Mock.Get(testObjects.DashboardPanelsLayoutService)
                .Verify(d => d.UpdatePanelsDisplay(testObjects.ViewModel, true, false));

            Assert.That(testObjects.ViewModel.ShowPriceGridContent, Is.True);
            Assert.That(testObjects.ViewModel.ShowDashboard, Is.True);
        }

        [Test]
        public void ShouldBuildAndInitializeNewDashboard_On_DashboardSettings_With_PageSettings()
        {
            var pagesLoaded = new List<int> { 2 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings =
                                        [
                                            new DashboardSettings
                                            {
                                                PageNumber = 2,
                                                Name = "My Markets",
                                                ShowPriceGridPanel = true,
                                                ShowScratchPadPanel = true,
                                                PriceGridSettings = new DashboardPriceGridSettings
                                                                    {
                                                                        PriceColumnSettings = [new()]
                                                                    }
                                            }
                                        ]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ACT
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ASSERT
            Assert.That(testObjects.ViewModel.DashboardName, Is.EqualTo("My Markets"));

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.BuildNewDashboard(testObjects.ViewModel,
                                                 testObjects.MarketsToolBarController.ViewModel,
                                                 2));

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.InitializeDashboard());

            Mock.Get(testObjects.DashboardPanelsLayoutService)
                .Verify(d => d.UpdatePanelsDisplay(testObjects.ViewModel, true, true));

            Assert.That(testObjects.ViewModel.ShowPriceGridContent, Is.True);
            Assert.That(testObjects.ViewModel.ShowDashboard, Is.True);
        }

        [Test]
        public void ShouldAttachScratchPadInfoService_OnSettingsLoaded()
        {
            var pagesLoaded = new List<int> { 1 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings = []
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 1 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(1)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ACT
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ASSERT
            Mock.Get(testObjects.ScratchPadInfoService)
                .Verify(s => s.AttachMarketsDashboard(testObjects.ViewModel));

            Mock.Get(testObjects.ScratchPadInfoService)
                .VerifyGet(s => s.ShowScratchPadNavigationPopup);

            Mock.Get(testObjects.ScratchPadInfoService)
                .VerifyGet(s => s.ShowScratchPadHelpPopup);
        }

        #endregion

        #region Layout

        [Test]
        public void ShouldUpdateLayoutSettings_On_ShowPriceGridPanel_Changed()
        {
            var pagesLoaded = new List<int> { 2 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings = [new DashboardSettings {  PageNumber = 2 }]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            testObjects.ViewModel.ShowPriceGridPanel = true;

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(s => s.UpdateLayout(true, false, 2));

        }

        [Test]
        public void ShouldUpdateLayoutSettings_On_ShowScratchPadPanel_Changed()
        {
            var pagesLoaded = new List<int> { 2 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings = [new DashboardSettings { PageNumber = 2 }]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            testObjects.ViewModel.ShowScratchPadPanel = true;

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(s => s.UpdateLayout(false, true, 2));

        }

        #endregion

        #region Navigation and Scratch Pad Help

        [Test]
        public void ShouldShowPriceGridExpanderPopup_On_ServiceShowScratchPadNavigationPopup_True()
        {
            var pagesLoaded = new List<int> { 1 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings = []
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 1 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(1)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();
            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            testObjects.ShowScratchPadNavigationPopup.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPriceGridExpanderPopup, Is.True);
        }

        [Test]
        public void ShouldInvokeServiceConfirmScratchPadNavigation_On_ConfirmScratchPadNavigationCommand()
        {
            var pagesLoaded = new List<int> { 1 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings = []
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 1 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(1)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            testObjects.ViewModel.ConfirmScratchPadNavigationCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ScratchPadInfoService)
                .Verify(s => s.ConfirmScratchPadNavigation());
        }

        [Test]
        public void ShouldShowScratchGridExpanderPopup_On_ServiceShowScratchPadHelpPopup_True()
        {
            var pagesLoaded = new List<int> { 1 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings = []
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 1 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(1)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            testObjects.ShowScratchPadHelpPopup.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowScratchPadExpanderPopup, Is.True);
        }

        [Test]
        public void ShouldInvokeServiceConfirmScratchPadHelp_And_ShowHelp_On_ScratchPadHelpCommand()
        {
            var pagesLoaded = new List<int> { 1 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings = []
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 1 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(1)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            testObjects.ViewModel.ScratchPadHelpCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ScratchPadInfoService)
                .Verify(s => s.ConfirmScratchPadHelp());

            Assert.That(testObjects.ViewModel.ScratchPadHelp.ShowHelp, Is.True);
        }

        [Test]
        public void ShouldInvokeServiceCancelScratchPadHelp_On_CancelScratchPadHelpCommand()
        {
            var pagesLoaded = new List<int> { 1 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings = []
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 1 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(1)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            testObjects.ViewModel.ScratchPadCancelHelpCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ScratchPadInfoService)
                .Verify(s => s.CancelScratchPadHelp());
        }

        #endregion

        #region  Add Dashboard

        [Test]
        public void ShouldBuildAndInitializeNewDashboard_On_DashboardAdded()
        {
            var pagesLoaded = new List<int> { 2 };

            var dashboard = new DashboardSettings
            {
                PageNumber = 2,
                Name = "Markets",
                PriceGridSettings = new DashboardPriceGridSettings
                {
                    PriceColumnSettings = [new()]
                }
            };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ACT
            testObjects.DashboardAdded.OnNext(dashboard);

            // ASSERT
            Assert.That(testObjects.ViewModel.DashboardName, Is.EqualTo("Markets"));

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.BuildNewDashboard(testObjects.ViewModel,
                                                 testObjects.MarketsToolBarController.ViewModel,
                                                 2));

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.InitializeDashboard());

            Assert.That(testObjects.ViewModel.ShowPriceGridContent, Is.True);

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.RemoveDashboard(testObjects.MarketsToolBarController.ViewModel), Times.Never);

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.GetDashboardSettingsForPage(It.IsAny<int>()), Times.Never);
        }

        #endregion

        #region Remove Dashboard

        [Test]
        public void ShouldRemoveDashboard_On_RemoveDashboard_With_PriceGridLoadedFalse()
        {
            var pagesLoaded = new List<int> { 1,2 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings =
                                        [
                                            new DashboardSettings { PageNumber = 1 },
                                            new DashboardSettings { PageNumber = 2 }
                                        ]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>()) { PageNumber = 2 };

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridLoaded(false)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            priceGridToolBar.RaiseRemoveDashboard();

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.RemoveDashboard(2));

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.RemoveDashboard(testObjects.MarketsToolBarController.ViewModel));
        }

        [Test]
        public void ShouldShowMessageDialogPrompt_On_RemoveDashboard_With_PriceGridLoadedTrue()
        {
            var pagesLoaded = new List<int> { 1,2 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings =
                                        [
                                            new DashboardSettings { PageNumber = 1 },
                                            new DashboardSettings { PageNumber = 2 }
                                        ]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>());

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridLoaded(true)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            priceGridToolBar.RaiseRemoveDashboard();

            // ASSERT
            Assert.That(testObjects.ViewModel.MessageDialogPrompt.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideDialog_And_RemoveDashboard_On_MessageDialogPromptYesCommand()
        {
            var pagesLoaded = new List<int> { 1,2 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings =
                                        [
                                            new DashboardSettings { PageNumber = 1 },
                                            new DashboardSettings { PageNumber = 2 }
                                        ]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>());

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridLoaded(true)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            priceGridToolBar.RaiseRemoveDashboard();

            // ACT
            testObjects.ViewModel.MessageDialogPrompt.DialogYesCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPriceGridContent, Is.False);

            Assert.IsNull(testObjects.ViewModel.PriceGrid);

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.RemoveDashboard(2));

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.RemoveDashboard(testObjects.MarketsToolBarController.ViewModel));

            Assert.That(testObjects.ViewModel.ScratchPad, Is.Null);

            Assert.That(testObjects.ViewModel.MessageDialogPrompt.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldHideDialog_And_NotRemoveDashboard_On_MessageDialogPromptNoCommand()
        {
            var pagesLoaded = new List<int> { 1,2 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings =
                                        [
                                            new DashboardSettings { PageNumber = 1 },
                                            new DashboardSettings { PageNumber = 2 }
                                        ]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>());

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridLoaded(true)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            priceGridToolBar.RaiseRemoveDashboard();

            // ACT
            testObjects.ViewModel.MessageDialogPrompt.DialogNoCommand.Execute();

            // ASSERT
            Assert.IsNotNull(testObjects.ViewModel.PriceGrid);

            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.RemoveDashboard(2), Times.Never);

            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(d => d.RemoveDashboard(testObjects.MarketsToolBarController.ViewModel), Times.Never);

            Assert.That(testObjects.ViewModel.MessageDialogPrompt.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldCreateDashboard_On_DashboardAdded_After_Removed()
        {
            var pagesLoaded = new List<int> { 1, 2 };

            var dashboard = new DashboardSettings
                            {
                                PageNumber = 2,
                                Name = "Markets",
                                PriceGridSettings = new DashboardPriceGridSettings
                                                    {
                                                        PriceColumnSettings = [new()]
                                                    }
                            };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings =
                                        [
                                            new DashboardSettings { PageNumber = 1 },
                                            dashboard
                                        ]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>());

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(2)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            priceGridToolBar.RaiseRemoveDashboard();

            Mock.Get(testObjects.MarketsDashboardService).Invocations.Clear();

            // ACT
            testObjects.DashboardAdded.OnNext(dashboard);

            // ASSERT
            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(c => c.InitializeDashboard(), Times.Once);
        }

        #endregion

        #region Dashboard Name

        [Test]
        public void ShouldUpdateDashboardSettings_When_DashboardNameChanged()
        {
            var pagesLoaded = new List<int> { 1 };

            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        DashboardSettings =
                                        [
                                            new DashboardSettings { PageNumber = 1 }
                                        ]
                                    };

            var priceGridToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>());

            var testObjects = new MarketsDashboardControllerTestObjectBuilder().WithPageNumber(1)
                                                                               .WithPagesLoaded(pagesLoaded)
                                                                               .WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                               .WithPriceGridToolBar(priceGridToolBar)
                                                                               .Build();

            // ARRANGE
            testObjects.DashboardSettings.OnNext(dashboardSettings);

            // ACT
            testObjects.ViewModel.DashboardName = "Updated";

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(d => d.UpdateDashboardName("Updated", 1));
        }

        #endregion

        #region Dispose

        [Test]
        public void ShouldDisposeServices_When_Dispose()
        {
            var testObjects = new MarketsDashboardControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.ScratchPadInfoService)
                .Verify(s => s.Dispose());
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new MarketsDashboardControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.MarketsDashboardService)
                .Verify(c => c.Dispose(), Times.Once);
        }

        #endregion
    }
}
