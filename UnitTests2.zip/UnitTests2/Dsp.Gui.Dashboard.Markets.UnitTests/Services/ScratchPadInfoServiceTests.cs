﻿using System;
using Dsp.Gui.Dashboard.Markets.ViewModels;
using Moq;
using NUnit.Framework;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Markets.Services;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.PriceGrid.ViewModels;
using Dsp.Gui.PriceGrid.ViewModels.Display;

namespace Dsp.Gui.Dashboard.Markets.UnitTests.Services
{
    internal interface IScratchPadInfoServiceTestObjects
    {
        IScratchPadInfoConfirmationService ScratchPadInfoConfirmationService { get; }
        ISubject<int> CurrentPageNumber { get; }
        ISubject<bool?> ScratchPadNavigationConfirmed { get; }
        ISubject<bool?> ScratchPadHelpConfirmed { get; }
        MarketsDashboardViewModel MarketsDashboard { get; }
        ScratchPadInfoService ScratchPadInfoService { get; }
    }

    [TestFixture]
    public class ScratchPadInfoServiceTests
    {
        internal class ScratchPadInfoServiceTestObjectBuilder
        {
            private int _dashboardPageNumber;
            private int _currentPageNumber;
            private bool _priceGridBusy;
            private bool _showPriceGridPanel;
            private bool _showScratchPadPanel;
            private bool? _scratchPadNavigationConfirmed;
            private bool? _scratchPadHelpConfirmed;

            public ScratchPadInfoServiceTestObjectBuilder WithDashboardPageNumber(int value)
            {
                _dashboardPageNumber = value;
                return this;
            }

            public ScratchPadInfoServiceTestObjectBuilder WithCurrentPageNumber(int value)
            {
                _currentPageNumber = value;
                return this;
            }

            public ScratchPadInfoServiceTestObjectBuilder WithPriceGridBusy(bool value)
            {
                _priceGridBusy = value;
                return this;
            }

            public ScratchPadInfoServiceTestObjectBuilder WithShowPriceGridPanel(bool value)
            {
                _showPriceGridPanel = value;
                return this;
            }
            public ScratchPadInfoServiceTestObjectBuilder WithShowScratchPadPanel(bool value)
            {
                _showScratchPadPanel = value;
                return this;
            }

            public ScratchPadInfoServiceTestObjectBuilder WithScratchPadNavigationConfirmed(bool? value)
            {
                _scratchPadNavigationConfirmed = value;
                return this;
            }

            public ScratchPadInfoServiceTestObjectBuilder WithScratchPadHelpConfirmed(bool? value)
            {
                _scratchPadHelpConfirmed = value;
                return this;
            }

            public IScratchPadInfoServiceTestObjects Build()
            {
                var testObjects = new Mock<IScratchPadInfoServiceTestObjects>();

                var marketsDashboard = new MarketsDashboardViewModel
                                       {
                                           MarketsFilter = new MarketsFilterViewModel(),
                                           PriceGrid = new PriceGridViewModel{IsBusy = _priceGridBusy},
                                           GridDisplaySettings = new GridDisplaySettingsViewModel(),
                                           PageNumber = _dashboardPageNumber,
                                           ShowPriceGridPanel = _showPriceGridPanel,
                                           ShowScratchPadPanel = _showScratchPadPanel
                                       };

                testObjects.SetupGet(o => o.MarketsDashboard)
                           .Returns(marketsDashboard);

                var currentPageNumber = new BehaviorSubject<int>(_currentPageNumber);

                testObjects.SetupGet(o => o.CurrentPageNumber)
                           .Returns(currentPageNumber);

                var pagesLoadedService = new Mock<IPagesLoadedService>();

                pagesLoadedService.SetupGet(p => p.CurrentPageNumber)
                                  .Returns(currentPageNumber);

                var scratchPadNavigationConfirmed = new BehaviorSubject<bool?>(_scratchPadNavigationConfirmed);

                testObjects.SetupGet(o => o.ScratchPadNavigationConfirmed)
                           .Returns(scratchPadNavigationConfirmed);

                var scratchPadHelpConfirmed = new BehaviorSubject<bool?>(_scratchPadHelpConfirmed);

                testObjects.SetupGet(o => o.ScratchPadHelpConfirmed)
                           .Returns(scratchPadHelpConfirmed);

                var confirmationService = new Mock<IScratchPadInfoConfirmationService>();

                confirmationService.SetupGet(c => c.ScratchPadNavigationConfirmed)
                                   .Returns(scratchPadNavigationConfirmed);

                confirmationService.SetupGet(c => c.ScratchPadHelpConfirmed)
                                   .Returns(scratchPadHelpConfirmed);

                testObjects.SetupGet(o => o.ScratchPadInfoConfirmationService)
                           .Returns(confirmationService.Object);

                var scratchPadInfoService = new ScratchPadInfoService(pagesLoadedService.Object,
                                                                      confirmationService.Object);

                testObjects.SetupGet(o => o.ScratchPadInfoService)
                           .Returns(scratchPadInfoService);

                return testObjects.Object;
            }
        }

        #region Publish ShowScratchPadNavigationPopup

        [Test]
        public void ShouldPublishShowNavigationFalse_When_CurrentPageNotLoaded()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(2)
                                                                          .WithCurrentPageNumber(0)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.CurrentPageNumber.OnNext(1);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowNavigationTrue_On_CurrentPageLoaded_With_IsBusyFalse()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(2)
                                                                          .WithCurrentPageNumber(0)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.CurrentPageNumber.OnNext(2);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishShowNavigationFalse_On_PriceGridBusy()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.MarketsDashboard.PriceGrid.IsBusy = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowNavigationFalse_On_PriceGridNotBusy()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithPriceGridBusy(true)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.MarketsDashboard.PriceGrid.IsBusy = false;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishShowNavigationFalse_On_HidePriceGridPanel()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.MarketsDashboard.ShowPriceGridPanel = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowNavigationFalse_On_ShowFilterDialog()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.MarketsDashboard.MarketsFilter.ShowDialog = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowNavigationFalse_On_ShowSettingsDialog()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.MarketsDashboard.GridDisplaySettings.ShowDialog = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowNavigationFalse_On_NavigationConfirmed()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.ScratchPadNavigationConfirmed.OnNext(true);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        #endregion

        #region publish ShowScratchPadHelpPopup

        [Test]
        public void ShouldPublishShowHelpFalse_When_CurrentPageNotLoaded()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(2)
                                                                          .WithCurrentPageNumber(0)
                                                                          .WithShowScratchPadPanel(false)
                                                                          .WithScratchPadHelpConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadHelpPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.CurrentPageNumber.OnNext(1);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowHelpTrue_On_CurrentPageLoaded()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(2)
                                                                          .WithCurrentPageNumber(0)
                                                                          .WithShowScratchPadPanel(true)
                                                                          .WithScratchPadHelpConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadHelpPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.CurrentPageNumber.OnNext(2);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishShowHelpFalse_On_HideScratchPadPanel()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithShowScratchPadPanel(true)
                                                                          .WithScratchPadHelpConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadHelpPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.MarketsDashboard.ShowScratchPadPanel = false;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowHelpFalse_On_ShowFilterDialog()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithShowScratchPadPanel(true)
                                                                          .WithScratchPadHelpConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);


            using (testObjects.ScratchPadInfoService.ShowScratchPadHelpPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.MarketsDashboard.MarketsFilter.ShowDialog = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowHelpFalse_On_ShowSettingsDialog()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithShowScratchPadPanel(true)
                                                                          .WithScratchPadHelpConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);


            using (testObjects.ScratchPadInfoService.ShowScratchPadHelpPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.MarketsDashboard.GridDisplaySettings.ShowDialog = true;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishShowHelpFalse_On_HelpConfirmed()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithShowScratchPadPanel(true)
                                                                          .WithScratchPadHelpConfirmed(false)
                                                                          .Build();

            bool? result = null;

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);


            using (testObjects.ScratchPadInfoService.ShowScratchPadHelpPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.ScratchPadHelpConfirmed.OnNext(true);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        #endregion

        #region publish ShowScratchPadHelpPopup

        [Test]
        public void ShouldPublishHelpPopupFalse_On_HelpConfirmedTrue()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(1)
                                                                          .WithCurrentPageNumber(1)
                                                                          .WithScratchPadHelpConfirmed(false)
                                                                          .Build();

            // ARRANGE
            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            bool? result = null;

            using (testObjects.ScratchPadInfoService.ShowScratchPadHelpPopup.Subscribe(value => result = value))
            {
                // ACT
                testObjects.ScratchPadHelpConfirmed.OnNext(true);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        #endregion

        [Test]
        public void ShouldInvokeServiceConfirmNavigation_When_ConfirmScratchPadNavigation()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ScratchPadInfoService.ConfirmScratchPadNavigation();

            // ASSERT
            Mock.Get(testObjects.ScratchPadInfoConfirmationService)
                .Verify(c => c.ConfirmNavigation());
        }

        [Test]
        public void ShouldInvokeServiceScratchPadNavigationConfirmed_On_ShowScratchPadToggle()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().Build();

            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            // ACT
            testObjects.MarketsDashboard.ShowScratchPadPanel = true;

            // ASSERT
            Mock.Get(testObjects.ScratchPadInfoConfirmationService)
                .Verify(c => c.ScratchPadNavigationConfirmed);
        }

        [Test]
        public void ShouldInvokeServiceConfirmHelp_When_ConfirmScratchPadHelp()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ScratchPadInfoService.ConfirmScratchPadHelp();

            // ASSERT
            Mock.Get(testObjects.ScratchPadInfoConfirmationService)
                .Verify(c => c.ConfirmHelp());
        }

        [Test]
        public void ShouldInvokeServiceCancelHelp_When_CancelScratchPadHelp()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ScratchPadInfoService.CancelScratchPadHelp();

            // ASSERT
            Mock.Get(testObjects.ScratchPadInfoConfirmationService)
                .Verify(c => c.CancelHelp());
        }

        #region dispose

        [Test]
        public void ShouldNotPublishFalse_When_Disposed()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(2)
                                                                          .WithCurrentPageNumber(0)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;


            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ARRANGE
                testObjects.ScratchPadInfoService.Dispose();

                // ACT
                testObjects.CurrentPageNumber.OnNext(2);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new ScratchPadInfoServiceTestObjectBuilder().WithDashboardPageNumber(2)
                                                                          .WithCurrentPageNumber(0)
                                                                          .WithPriceGridBusy(false)
                                                                          .WithShowPriceGridPanel(true)
                                                                          .WithScratchPadNavigationConfirmed(false)
                                                                          .Build();

            bool? result = null;


            testObjects.ScratchPadInfoService.AttachMarketsDashboard(testObjects.MarketsDashboard);

            using (testObjects.ScratchPadInfoService.ShowScratchPadNavigationPopup.Subscribe(value => result = value))
            {
                // ARRANGE
                testObjects.ScratchPadInfoService.Dispose();

                // ACT
                testObjects.ScratchPadInfoService.Dispose();
                testObjects.CurrentPageNumber.OnNext(2);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        #endregion
    }
}
