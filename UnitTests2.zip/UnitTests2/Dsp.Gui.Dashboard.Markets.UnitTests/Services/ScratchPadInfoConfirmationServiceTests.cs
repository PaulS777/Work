﻿using System;
using Moq;
using NUnit.Framework;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.Markets.Services;

namespace Dsp.Gui.Dashboard.Markets.UnitTests.Services
{
    internal interface IScratchPadInfoConfirmationServiceTestObjects
    {
        IDashboardSettingsService DashboardSettingsService { get; }
        ISubject<DashboardSettingsCollection> DashboardSettings { get; }
        IScratchPadInfoConfirmationService ScratchPadInfoConfirmationService { get; }
    }

    [TestFixture]
    public class ScratchPadInfoConfirmationServiceTests
    {
        private class ScratchPadInfoConfirmationServiceTestObjectBuilder
        {
            public IScratchPadInfoConfirmationServiceTestObjects Build()
            {
                var testObjects = new Mock<IScratchPadInfoConfirmationServiceTestObjects>();

                var dashboardSettings = new BehaviorSubject<DashboardSettingsCollection>(null);

                testObjects.SetupGet(o => o.DashboardSettings)
                           .Returns(dashboardSettings);

                var dashboardSettingsService = new Mock<IDashboardSettingsService>();

                dashboardSettingsService.SetupGet(o => o.DashboardSettings)
                                        .Returns(dashboardSettings);

                testObjects.SetupGet(o => o.DashboardSettingsService)
                           .Returns(dashboardSettingsService.Object);

                var scratchPadInfoConfirmationService = new ScratchPadInfoConfirmationService(dashboardSettingsService.Object);

                testObjects.SetupGet(o => o.ScratchPadInfoConfirmationService)
                           .Returns(scratchPadInfoConfirmationService);

                return testObjects.Object;
            }
        }

        #region Navigation Confirmed

        [Test]
        public void ShouldPublishNavigationConfirmedTrue_On_DashboardSettings_With_ScratchPadNavigationConfirmed()
        {
            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        InfoSettings = new DashboardInfoSettings
                                                       {
                                                           ScratchPadNavigationConfirmed = true
                                                       }
                                    };

            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            bool? result = false;

            using (testObjects.ScratchPadInfoConfirmationService.ScratchPadNavigationConfirmed.Subscribe(value => result = value))
            {
                // ACT
                testObjects.DashboardSettings.OnNext(dashboardSettings);
            }

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldInvokeSettingsService_On_ConfirmNavigation()
        {
            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ScratchPadInfoConfirmationService.ConfirmNavigation();

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(s => s.UpdateScratchPadNavigationConfirmed(true));
        }

        [Test]
        public void ShouldPublishNavigationConfirmedTrue_And_Complete_On_ConfirmNavigation()
        {
            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            bool? result = false;
            var completed = false;

            using (testObjects.ScratchPadInfoConfirmationService.ScratchPadNavigationConfirmed.Subscribe(value => result = value,
                                                                                                   () => completed = true))
            {
                // ACT
                testObjects.ScratchPadInfoConfirmationService.ConfirmNavigation();
            }

            // ASSERT
            Assert.That(result, Is.True);
            Assert.That(completed, Is.True);
        }

        #endregion

        #region Help Confirmed

        [Test]
        public void ShouldPublishHelpConfirmedTrue_On_DashboardSettings_With_ScratchPadHelpConfirmed()
        {
            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        InfoSettings = new DashboardInfoSettings
                                                       {
                                                           ScratchPadHelpConfirmed = true
                                                       }
                                    };

            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            bool? result = false;

            using (testObjects.ScratchPadInfoConfirmationService.ScratchPadHelpConfirmed.Subscribe(value => result = value))
            {
                // ACT
                testObjects.DashboardSettings.OnNext(dashboardSettings);
            }

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldInvokeSettingsService_On_ConfirmHelp()
        {
            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            // ACT
            testObjects.ScratchPadInfoConfirmationService.ConfirmHelp();

            // ASSERT
            Mock.Get(testObjects.DashboardSettingsService)
                .Verify(s => s.UpdateScratchPadHelpConfirmed(true));
        }

        [Test]
        public void ShouldPublishHelpConfirmedTrue_And_Complete_On_ConfirmHelp()
        {
            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            bool? result = false;
            var completed = false;

            using (testObjects.ScratchPadInfoConfirmationService.ScratchPadHelpConfirmed.Subscribe(value => result = value,
                                                                                                   () => completed = true))
            {
                // ACT
                testObjects.ScratchPadInfoConfirmationService.ConfirmHelp();
            }

            // ASSERT
            Assert.That(result, Is.True);
            Assert.That(completed, Is.True);
        }

        [Test]
        public void ShouldPublishHelpConfirmedTrue_And_Complete_On_CancelHelp()
        {
            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            bool? result = false;
            var completed = false;

            using (testObjects.ScratchPadInfoConfirmationService.ScratchPadHelpConfirmed.Subscribe(value => result = value,
                                                                                                   () => completed = true))
            {
                // ACT
                testObjects.ScratchPadInfoConfirmationService.CancelHelp();
            }

            // ASSERT
            Assert.That(result, Is.True);
            Assert.That(completed, Is.True);
        }

        #endregion

        [Test]
        public void ShouldNotPublishScratchPadNavigationConfirmed_When_Disposed()
        {
            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        InfoSettings = new DashboardInfoSettings
                                                       {
                                                           ScratchPadNavigationConfirmed = true
                                                       }
                                    };

            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            bool? result = false;

            using (testObjects.ScratchPadInfoConfirmationService.ScratchPadNavigationConfirmed.Subscribe(value => result = value))
            {
                // ARRANGE
                testObjects.ScratchPadInfoConfirmationService.Dispose();

                // ACT
                testObjects.DashboardSettings.OnNext(dashboardSettings);
            }

            // ASSERT
            Assert.That(result, Is.Null);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var dashboardSettings = new DashboardSettingsCollection
                                    {
                                        InfoSettings = new DashboardInfoSettings
                                                       {
                                                           ScratchPadNavigationConfirmed = true
                                                       }
                                    };

            var testObjects = new ScratchPadInfoConfirmationServiceTestObjectBuilder().Build();

            bool? result = false;

            using (testObjects.ScratchPadInfoConfirmationService.ScratchPadNavigationConfirmed.Subscribe(value => result = value))
            {
                // ARRANGE
                testObjects.ScratchPadInfoConfirmationService.Dispose();

                // ACT
                testObjects.ScratchPadInfoConfirmationService.Dispose();
                testObjects.DashboardSettings.OnNext(dashboardSettings);
            }

            // ASSERT
            Assert.That(result, Is.Null);
        }
    }
}
