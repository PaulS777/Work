﻿using Dsp.Gui.Dashboard.Markets.ViewModels;
using Moq;
using NUnit.Framework;
using Dsp.Gui.Dashboard.Common;
using Dsp.Gui.Dashboard.Markets.Services;

namespace Dsp.Gui.Dashboard.Markets.UnitTests.Services
{
    internal interface IDashboardPanelsLayoutServiceTestObjects
    {
        MarketsDashboardViewModel ViewModel { get; }
        DashboardPanelsLayoutService DashboardPanelsLayoutService { get; }
    }

    [TestFixture]
    public class DashboardPanelsLayoutServiceTests
    {
        private class DashboardPanelsLayoutServiceTestObjectBuilder
        {
            public IDashboardPanelsLayoutServiceTestObjects Build()
            {
                var testObjects = new Mock<IDashboardPanelsLayoutServiceTestObjects>();

                var dashboard = new MarketsDashboardViewModel();

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(dashboard);

                var service = new DashboardPanelsLayoutService();

                testObjects.SetupGet(o => o.DashboardPanelsLayoutService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowPriceGridPanelExpanded_With_Defaults()
        {
            var testObjects = new DashboardPanelsLayoutServiceTestObjectBuilder().Build();

            // ACT
            testObjects.DashboardPanelsLayoutService.UpdatePanelsDisplay(testObjects.ViewModel, false, false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPriceGridPanel, Is.True);
            Assert.That(testObjects.ViewModel.ShowScratchPadPanel, Is.False);

            Assert.That(testObjects.ViewModel.PriceGridExpanderToggleState, Is.EqualTo(ExpanderToggleState.Expanded));
            Assert.That(testObjects.ViewModel.ScratchPadExpanderToggleState, Is.EqualTo(ExpanderToggleState.Collapsed));
        }

        [Test]
        public void ShouldShowPriceGridPanelExpanded_With_ShowPriceGridOnly()
        {
            var testObjects = new DashboardPanelsLayoutServiceTestObjectBuilder().Build();

            // ACT
            testObjects.DashboardPanelsLayoutService.UpdatePanelsDisplay(testObjects.ViewModel, true, false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPriceGridPanel, Is.True);
            Assert.That(testObjects.ViewModel.ShowScratchPadPanel, Is.False);

            Assert.That(testObjects.ViewModel.PriceGridExpanderToggleState, Is.EqualTo(ExpanderToggleState.Expanded));
            Assert.That(testObjects.ViewModel.ScratchPadExpanderToggleState, Is.EqualTo(ExpanderToggleState.Collapsed));
        }

        [Test]
        public void ShouldShowScratchPadPanelExpanded_With_ShowScratchPadOnly()
        {
            var testObjects = new DashboardPanelsLayoutServiceTestObjectBuilder().Build();

            // ACT
            testObjects.DashboardPanelsLayoutService.UpdatePanelsDisplay(testObjects.ViewModel, false, true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPriceGridPanel, Is.False);
            Assert.That(testObjects.ViewModel.ShowScratchPadPanel, Is.True);

            Assert.That(testObjects.ViewModel.PriceGridExpanderToggleState, Is.EqualTo(ExpanderToggleState.Collapsed));
            Assert.That(testObjects.ViewModel.ScratchPadExpanderToggleState, Is.EqualTo(ExpanderToggleState.Expanded));
        }

        [Test]
        public void ShouldShowBothPanels_With_ToggleStatesNormal_ShowPriceGridTrue_ShowScratchPadTrue()
        {
            var testObjects = new DashboardPanelsLayoutServiceTestObjectBuilder().Build();

            // ACT
            testObjects.DashboardPanelsLayoutService.UpdatePanelsDisplay(testObjects.ViewModel, true, true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowPriceGridPanel, Is.True);
            Assert.That(testObjects.ViewModel.ShowScratchPadPanel, Is.True);

            Assert.That(testObjects.ViewModel.PriceGridExpanderToggleState, Is.EqualTo(ExpanderToggleState.Normal));
            Assert.That(testObjects.ViewModel.ScratchPadExpanderToggleState, Is.EqualTo(ExpanderToggleState.Normal));
        }

    }
}
