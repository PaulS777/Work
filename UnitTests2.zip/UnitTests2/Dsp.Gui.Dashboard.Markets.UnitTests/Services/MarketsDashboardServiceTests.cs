﻿using System;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Markets.ViewModels;
using Dsp.Gui.Dashboard.ToolBar.Markets.ViewModels;
using Dsp.Gui.PriceGrid.Controllers;
using Dsp.Gui.PriceGrid.ViewModels;
using Moq;
using NUnit.Framework;
using System.Reactive.Linq;
using Castle.Components.DictionaryAdapter;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.Markets.Services;
using Dsp.Gui.Dashboard.ScratchPad.Controllers;
using Dsp.Gui.Dashboard.ScratchPad.ViewModels;
using Dsp.Gui.Markets.Common.Controllers;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.Services.ScratchPad;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.PriceGrid.Controllers.Display;
using Dsp.Gui.PriceGrid.ViewModels.Display;
using Dsp.Gui.Dashboard.ScratchPad.Services;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.PriceGrid.Services;

namespace Dsp.Gui.Dashboard.Markets.UnitTests.Services
{
    internal interface IMarketsDashboardServiceTestObjects
    {
        IPriceGridViewModelController PriceGridViewModelController { get; }
        PriceGridViewModel PriceGrid { get; }
        IScratchPadFormatSettingsService ScratchPadFormatSettingsService { get; }
        IScratchPadPriceCurvesService ScratchPadPriceCurvesService { get; }
        IScratchPadClipboard ScratchPadClipboard { get; }
        MarketsDashboardViewModel MarketsViewModel { get; }
        MarketsToolBarViewModel MarketsToolBarViewModel { get; }
        MarketsDashboardService MarketsDashboardService { get; }
    }

    [TestFixture]
    public class MarketsDashboardServiceTests
    {
        private class MarketsDashboardTestObjectBuilder
		{
			private IUserPublicationsProvider _userPublicationsProvider;
			private IUserMarketsWithSettingsService _userMarketsWithSettingsService;
			private IUserMarketsUpdateReasonService _iUserMarketsUpdateReasonService;
			private IManualFilterChangedService _manualFilterChangedService;
			private IUserMarketsUpdateSettingsService _userMarketsUpdateSettingsService;

            private IPriceGridLoadService _priceGridLoadService;
            private IScratchPadController _scratchPadController;
            private IMarketsFilterViewModelController _marketsFilterController;
            private IRemovePriceBandService _removePriceBandService;
            private ITenorPriceRowDataSource _tenorPriceRowDataSource;
            private IGridDisplaySettingsController _gridDisplaySettingsController;

			public MarketsDashboardTestObjectBuilder WithUserPublicationsProvider(IUserPublicationsProvider value)
			{
				_userPublicationsProvider = value;
				return this;
			}
			public MarketsDashboardTestObjectBuilder WithUserMarketsWithSettingsService(IUserMarketsWithSettingsService value)
			{
				_userMarketsWithSettingsService = value;
				return this;
			}

			public MarketsDashboardTestObjectBuilder WithUserMarketsFilterUpdateReasonService(IUserMarketsUpdateReasonService value)
            {
                _iUserMarketsUpdateReasonService= value;
                return this;
            }

			public MarketsDashboardTestObjectBuilder WithManualFilterChangedService(IManualFilterChangedService value)
			{
				_manualFilterChangedService = value;
				return this;
			}

			public MarketsDashboardTestObjectBuilder WithUserMarketsUpdateSettingsService(IUserMarketsUpdateSettingsService value)
			{
				_userMarketsUpdateSettingsService = value;
				return this;
			}

			public MarketsDashboardTestObjectBuilder WithPriceGridLoadService(IPriceGridLoadService value)
            {
                _priceGridLoadService = value;
                return this;
            }

            public MarketsDashboardTestObjectBuilder WithScratchPadController(IScratchPadController value)
            {
                _scratchPadController = value;
                return this;
            }

            public MarketsDashboardTestObjectBuilder WithMarketsFilterController(IMarketsFilterViewModelController value)
            {
                _marketsFilterController = value;
                return this;
            }

            public MarketsDashboardTestObjectBuilder WithRemovePriceBandService(IRemovePriceBandService value)
            {
                _removePriceBandService = value;
                return this;
            }

            public MarketsDashboardTestObjectBuilder WithTenorRowDataSource(ITenorPriceRowDataSource value)
            {
                _tenorPriceRowDataSource = value;
                return this;
            }

            public MarketsDashboardTestObjectBuilder WithGridDisplaySettingsController(IGridDisplaySettingsController value)
            {
                _gridDisplaySettingsController = value;
                return this;
            }

            public IMarketsDashboardServiceTestObjects Build()
            {
                var testObjects = new Mock<IMarketsDashboardServiceTestObjects>();

                var priceGrid = new PriceGridViewModel
                                {
                                    ToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>())
                                };

                testObjects.SetupGet(o => o.PriceGrid)
                           .Returns(priceGrid);

                var priceGridController = new Mock<IPriceGridViewModelController>();

                priceGridController.SetupGet(c => c.ViewModel)
                                   .Returns(priceGrid);

                testObjects.SetupGet(o => o.PriceGridViewModelController)
                           .Returns(priceGridController.Object);

                var priceGridFactory = new Mock<IServiceFactory<IPriceGridViewModelController>>();

                priceGridFactory.Setup(f => f.Create())
                                .Returns(priceGridController.Object);

                var scratchPadFormatSettingsService = new Mock<IScratchPadFormatSettingsService>();

                testObjects.Setup(o => o.ScratchPadFormatSettingsService)
                           .Returns(scratchPadFormatSettingsService.Object);

                var scratchPadFormatSettingsFactory = new Mock<IServiceFactory<IScratchPadFormatSettingsService>>();

                scratchPadFormatSettingsFactory.Setup(f => f.Create())
                                               .Returns(scratchPadFormatSettingsService.Object);

                var scratchPadPriceCurvesService = new Mock<IScratchPadPriceCurvesService>();

                testObjects.SetupGet(o => o.ScratchPadPriceCurvesService)
                           .Returns(scratchPadPriceCurvesService.Object);

                var scratchPadClipboard = new Mock<IScratchPadClipboard>();

                testObjects.SetupGet(o => o.ScratchPadClipboard)
                           .Returns(scratchPadClipboard.Object);

                var marketsViewModel = new MarketsDashboardViewModel();

                testObjects.SetupGet(o => o.MarketsViewModel)
                           .Returns(marketsViewModel);

                var marketsToolBarViewModel = new MarketsToolBarViewModel
                                              {
                                                  PriceGridToolBars = new EditableList<PriceGridToolBarViewModel>()
                                              };

                testObjects.SetupGet(o => o.MarketsToolBarViewModel)
                           .Returns(marketsToolBarViewModel);

				var userPublicationsProviderFactory = new Mock<IServiceFactory<IUserPublicationsProvider>>();

				userPublicationsProviderFactory.Setup(f => f.Create())
											   .Returns(_userPublicationsProvider);

				var userMarketsWithSettingsServiceFactory = new Mock<IServiceFactory<IUserMarketsWithSettingsService>>();

                userMarketsWithSettingsServiceFactory.Setup(f => f.Create())
													 .Returns(_userMarketsWithSettingsService);

                var userMarketsFilterUpdateReasonServiceFactory = new Mock<IServiceFactory<IUserMarketsUpdateReasonService>>();

                userMarketsFilterUpdateReasonServiceFactory.Setup(f => f.Create())
                                               .Returns(_iUserMarketsUpdateReasonService);

				var manualFilterSettingsUpdateServiceFactory = new Mock<IServiceFactory<IManualFilterChangedService>>();

				manualFilterSettingsUpdateServiceFactory.Setup(f => f.Create())
														.Returns(_manualFilterChangedService);

				var userMarketsUpdateSettingsServiceFactory = new Mock<IServiceFactory<IUserMarketsUpdateSettingsService>>();

				userMarketsUpdateSettingsServiceFactory.Setup(f => f.Create())
													   .Returns(_userMarketsUpdateSettingsService);

                var scratchPadFactory = new Mock<IServiceFactory<IScratchPadController>>();

                scratchPadFactory.Setup(f => f.Create())
                                 .Returns(_scratchPadController);

                var marketsFilterControllerFactory = new Mock<IServiceFactory<IMarketsFilterViewModelController>>();

                marketsFilterControllerFactory.Setup(f => f.Create())
                                              .Returns(_marketsFilterController);

                var removePriceBandServiceFactory = new Mock<IServiceFactory<IRemovePriceBandService>>();

                removePriceBandServiceFactory.Setup(f => f.Create())
                                             .Returns(_removePriceBandService);

                var tenorDataSourceFactory = new Mock<IServiceFactory<ITenorPriceRowDataSource>>();

                tenorDataSourceFactory.Setup(f => f.Create())
                                      .Returns(_tenorPriceRowDataSource);

                var gridDisplaySettingsControllerFactory = new Mock<IServiceFactory<IGridDisplaySettingsController>>();

                gridDisplaySettingsControllerFactory.Setup(f => f.Create())
                                                    .Returns(_gridDisplaySettingsController);

                var priceGridLoadServiceFactory = new Mock<IServiceFactory<IPriceGridLoadService>>();

                priceGridLoadServiceFactory.Setup(f => f.Create())
                                           .Returns(_priceGridLoadService);

                var marketsDashboardService = new MarketsDashboardService(scratchPadPriceCurvesService.Object,
                                                                          scratchPadClipboard.Object)
                                              {
                                                  UserMarketsWithSettingsServiceFactory = userMarketsWithSettingsServiceFactory.Object,
                                                  UserMarketsFilterUpdateReasonServiceFactory = userMarketsFilterUpdateReasonServiceFactory.Object,
                                                  ManualFilterChangedServiceFactory = manualFilterSettingsUpdateServiceFactory.Object,
												  UserMarketsUpdateSettingsServiceFactory = userMarketsUpdateSettingsServiceFactory.Object,
												  PriceGridLoadServiceFactory = priceGridLoadServiceFactory.Object,
                                                  MarketsFilterFactory = marketsFilterControllerFactory.Object,
                                                  PriceGridFactory = priceGridFactory.Object,
                                                  ScratchPadFactory = scratchPadFactory.Object,
                                                  RemovePriceBandServiceFactory = removePriceBandServiceFactory.Object,
                                                  TenorPriceRowDataSourceFactory = tenorDataSourceFactory.Object,
                                                  GridDisplaySettingsControllerFactory = gridDisplaySettingsControllerFactory.Object,
                                                  ScratchPadFormatSettingsFactory = scratchPadFormatSettingsFactory.Object
                                              };

                testObjects.SetupGet(o => o.MarketsDashboardService)
                           .Returns(marketsDashboardService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldBuildMarketsDashboard()
		{
			var userPublicationsProvider = new Mock<IUserPublicationsProvider>();
			var userMarketsWithSettingsService = Mock.Of<IUserMarketsWithSettingsService>();
			var userMarketsFilterUpdateReasonService = Mock.Of<IUserMarketsUpdateReasonService>();
			var manualFilterChangedService = Mock.Of<IManualFilterChangedService>();
			var userMarketsUpdateSettingsService = Mock.Of<IUserMarketsUpdateSettingsService>();
            var priceGridLoadService = Mock.Of<IPriceGridLoadService>();
            var tenorRowDataSource = Mock.Of<ITenorPriceRowDataSource>();
            var gridDisplaySettings = new GridDisplaySettingsViewModel();
            var gridDisplaySettingsController = Mock.Of<IGridDisplaySettingsController>(c => c.ViewModel == gridDisplaySettings);
            var scratchPad = new ScratchPadViewModel();
            var scratchPadController = Mock.Of<IScratchPadController>(c => c.ViewModel == scratchPad);
            var marketsFilter = new MarketsFilterViewModel();
            var marketsFilterController = Mock.Of<IMarketsFilterViewModelController>(c => c.ViewModel == marketsFilter);

            var testObjects = new MarketsDashboardTestObjectBuilder().WithUserPublicationsProvider(userPublicationsProvider.Object)
																	 .WithUserMarketsWithSettingsService(userMarketsWithSettingsService)
                                                                     .WithUserMarketsFilterUpdateReasonService(userMarketsFilterUpdateReasonService)
																	 .WithManualFilterChangedService(manualFilterChangedService)
																	 .WithUserMarketsUpdateSettingsService(userMarketsUpdateSettingsService)
                                                                     .WithPriceGridLoadService(priceGridLoadService)
                                                                     .WithTenorRowDataSource(tenorRowDataSource)
                                                                     .WithScratchPadController(scratchPadController)
                                                                     .WithMarketsFilterController(marketsFilterController)
                                                                     .WithGridDisplaySettingsController(gridDisplaySettingsController)
                                                                     .Build();

            // ACT
            var result = testObjects.MarketsDashboardService.BuildNewDashboard(testObjects.MarketsViewModel,
                                                                               testObjects.MarketsToolBarViewModel,
                                                                               1);

            // ASSERT
            Assert.That(testObjects.MarketsViewModel.MarketsFilter, Is.SameAs(marketsFilter));
            Assert.That(testObjects.MarketsViewModel.PriceGrid, Is.SameAs(testObjects.PriceGrid));
            Assert.That(testObjects.MarketsViewModel.ScratchPad, Is.SameAs(scratchPad));
            Assert.That(testObjects.MarketsViewModel.GridDisplaySettings, Is.SameAs(gridDisplaySettings));

            Assert.That(testObjects.MarketsViewModel.PriceGrid.ToolBar.PageNumber, Is.EqualTo(1));

            Assert.That(testObjects.MarketsToolBarViewModel.PriceGridToolBars.Count, Is.EqualTo(1));
            Assert.That(testObjects.MarketsToolBarViewModel.SelectedToolBar, Is.SameAs(testObjects.MarketsViewModel.PriceGrid.ToolBar));

            Assert.That(marketsFilter.ToolBar, Is.SameAs(testObjects.MarketsViewModel.PriceGrid.ToolBar));
 
            Assert.That(gridDisplaySettings.ToolBar, Is.SameAs(testObjects.MarketsViewModel.PriceGrid.ToolBar));

            Assert.That(result, Is.SameAs(testObjects.MarketsViewModel.PriceGrid.ToolBar));
        }

        [Test]
        public void ShouldInitializeMarketsDashboard()
		{
			var manualFilterChangedService = Mock.Of<IManualFilterChangedService>();
			var userPublicationsProvider = Mock.Of<IUserPublicationsProvider>();
			var userMarketsWithSettingsService = Mock.Of<IUserMarketsWithSettingsService>();
			var userMarketsFilterUpdateReasonService = Mock.Of<IUserMarketsUpdateReasonService>(f => f.UserMarketsFilter == Observable.Empty<UserMarketsFilterArgs>());
			var userMarketsUpdateSettingsService = Mock.Of<IUserMarketsUpdateSettingsService>();

			var priceGridLoadService = Mock.Of<IPriceGridLoadService>();
            var tenorRowDataSource = Mock.Of<ITenorPriceRowDataSource>();
            var gridDisplaySettings = new GridDisplaySettingsViewModel();
            var gridDisplaySettingsController = Mock.Of<IGridDisplaySettingsController>(c => c.ViewModel == gridDisplaySettings);
            var scratchPad = new ScratchPadViewModel();
            var scratchPadController = Mock.Of<IScratchPadController>(c => c.ViewModel == scratchPad);

			var dataSource = Mock.Of<ICurveGroupRegionsDataSource>();
			var marketsFilter = new MarketsFilterViewModel();
            var marketsFilterController = Mock.Of<IMarketsFilterViewModelController>(c => c.ViewModel == marketsFilter && c.DataSource == dataSource);
            var removePriceBandService = Mock.Of<IRemovePriceBandService>(r => r.OnRemovePriceBand == Observable.Empty<LinkedCurve>());

            var testObjects = new MarketsDashboardTestObjectBuilder().WithManualFilterChangedService(manualFilterChangedService)
																	 .WithUserPublicationsProvider(userPublicationsProvider)
																	 .WithUserMarketsFilterUpdateReasonService(userMarketsFilterUpdateReasonService)
																	 .WithUserMarketsWithSettingsService(userMarketsWithSettingsService)
																	 .WithUserMarketsUpdateSettingsService(userMarketsUpdateSettingsService)
																	 .WithPriceGridLoadService(priceGridLoadService)
																	 .WithTenorRowDataSource(tenorRowDataSource)
																	 .WithScratchPadController(scratchPadController)
																	 .WithMarketsFilterController(marketsFilterController)
																	 .WithRemovePriceBandService(removePriceBandService)
																	 .WithGridDisplaySettingsController(gridDisplaySettingsController)
																	 .Build();

            testObjects.MarketsDashboardService.BuildNewDashboard(testObjects.MarketsViewModel,
                                                                  testObjects.MarketsToolBarViewModel,
                                                                  1);

            // ACT
            testObjects.MarketsDashboardService.InitializeDashboard();

            // ASSERT
            Assert.That(testObjects.PriceGrid.GridDisplaySettings, Is.SameAs(gridDisplaySettingsController.ViewModel));

            Mock.Get(userMarketsWithSettingsService)
                .Verify(p => p.Initialize(1, dataSource, manualFilterChangedService, removePriceBandService));

            Mock.Get(priceGridLoadService)
                .Verify(p => p.Initialize(userMarketsFilterUpdateReasonService.UserMarketsFilter, 1));

            Mock.Get(testObjects.PriceGridViewModelController)
                .Verify(c => c.Initialize(1,
                                          tenorRowDataSource,
                                          removePriceBandService,
                                          testObjects.ScratchPadPriceCurvesService,
                                          testObjects.ScratchPadClipboard,
                                          priceGridLoadService.LoadGrid));

            Mock.Get(scratchPadController)
                .Verify(c => c.Initialize(1,
                                          tenorRowDataSource,
                                          testObjects.ScratchPadFormatSettingsService,
                                          testObjects.ScratchPadPriceCurvesService,
                                          testObjects.ScratchPadClipboard));

            Mock.Get(userMarketsFilterUpdateReasonService)
                .Verify(u => u.Initialize(userMarketsWithSettingsService));

            Mock.Get(marketsFilterController)
                .Verify(c => c.Initialize(userMarketsWithSettingsService,
                                          manualFilterChangedService));

            Mock.Get(testObjects.ScratchPadFormatSettingsService)
                .Verify(f => f.Initialize(1));
        }

        [Test]
        public void ShouldRemoveToolBarsAndDisposeServices_When_RemoveDashboard()
        {
			var manualFilterChangedService = Mock.Of<IManualFilterChangedService>();
			var userPublicationsProvider = Mock.Of<IUserPublicationsProvider>();
			var userMarketsWithSettingsService = Mock.Of<IUserMarketsWithSettingsService>();
			var userMarketsFilterUpdateReasonService = Mock.Of<IUserMarketsUpdateReasonService>(f => f.UserMarketsFilter == Observable.Empty<UserMarketsFilterArgs>());
			var userMarketsUpdateSettingsService = Mock.Of<IUserMarketsUpdateSettingsService>();

			var priceGridLoadService = Mock.Of<IPriceGridLoadService>();
            var gridDisplaySettings = new GridDisplaySettingsViewModel();
            var gridDisplaySettingsController = Mock.Of<IGridDisplaySettingsController>(c => c.ViewModel == gridDisplaySettings);
            var scratchPad = new ScratchPadViewModel();
            var scratchPadController = Mock.Of<IScratchPadController>(c => c.ViewModel == scratchPad);
            var marketsFilter = new MarketsFilterViewModel();
            var marketsFilterController = Mock.Of<IMarketsFilterViewModelController>(c => c.ViewModel == marketsFilter);
            var removePriceBandService = Mock.Of<IRemovePriceBandService>(r => r.OnRemovePriceBand == Observable.Empty<LinkedCurve>());

            var testObjects = new MarketsDashboardTestObjectBuilder().WithManualFilterChangedService(manualFilterChangedService)
																	 .WithUserPublicationsProvider(userPublicationsProvider)
																	 .WithUserMarketsFilterUpdateReasonService(userMarketsFilterUpdateReasonService)
																	 .WithUserMarketsWithSettingsService(userMarketsWithSettingsService)
																	 .WithUserMarketsUpdateSettingsService(userMarketsUpdateSettingsService)
																	 .WithManualFilterChangedService(manualFilterChangedService)
																	 .WithUserMarketsUpdateSettingsService(userMarketsUpdateSettingsService)
																	 .WithPriceGridLoadService(priceGridLoadService)
																	 .WithScratchPadController(scratchPadController)
																	 .WithMarketsFilterController(marketsFilterController)
																	 .WithRemovePriceBandService(removePriceBandService)
																	 .WithGridDisplaySettingsController(gridDisplaySettingsController)
																	 .Build();

            testObjects.MarketsDashboardService.BuildNewDashboard(testObjects.MarketsViewModel,
                                                                  testObjects.MarketsToolBarViewModel,
                                                                  1);

            testObjects.MarketsDashboardService.InitializeDashboard();

            // ACT
            testObjects.MarketsDashboardService.RemoveDashboard(testObjects.MarketsToolBarViewModel);

            // ASSERT
            Assert.That(testObjects.MarketsToolBarViewModel.PriceGridToolBars, Is.Empty);
            
            Mock.Get(userMarketsFilterUpdateReasonService)
                .Verify(u => u.Dispose());

            Mock.Get(marketsFilterController)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.PriceGridViewModelController)
                .Verify(c => c.Dispose());

            Mock.Get(removePriceBandService)
                .Verify(r => r.Dispose());

            Mock.Get(gridDisplaySettingsController)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldDisposeScratchPadAndDeleteSettings_When_RemoveDashboard()
        {
			var manualFilterChangedService = Mock.Of<IManualFilterChangedService>();
			var userPublicationsProvider = Mock.Of<IUserPublicationsProvider>();
			var userMarketsWithSettingsService = Mock.Of<IUserMarketsWithSettingsService>();
			var userMarketsFilterUpdateReasonService = Mock.Of<IUserMarketsUpdateReasonService>(f => f.UserMarketsFilter == Observable.Empty<UserMarketsFilterArgs>());
			var userMarketsUpdateSettingsService = Mock.Of<IUserMarketsUpdateSettingsService>();
			var priceGridLoadService = Mock.Of<IPriceGridLoadService>();
            var gridDisplaySettings = new GridDisplaySettingsViewModel();
            var gridDisplaySettingsController = Mock.Of<IGridDisplaySettingsController>(c => c.ViewModel == gridDisplaySettings);
            var scratchPad = new ScratchPadViewModel();
            var scratchPadController = Mock.Of<IScratchPadController>(c => c.ViewModel == scratchPad);
            var marketsFilter = new MarketsFilterViewModel();
            var marketsFilterController = Mock.Of<IMarketsFilterViewModelController>(c => c.ViewModel == marketsFilter);
            var removePriceBandService = Mock.Of<IRemovePriceBandService>(r => r.OnRemovePriceBand == Observable.Empty<LinkedCurve>());

            var testObjects = new MarketsDashboardTestObjectBuilder().WithManualFilterChangedService(manualFilterChangedService)
																	 .WithUserPublicationsProvider(userPublicationsProvider)
																	 .WithUserMarketsFilterUpdateReasonService(userMarketsFilterUpdateReasonService)
																	 .WithUserMarketsWithSettingsService(userMarketsWithSettingsService)
																	 .WithUserMarketsUpdateSettingsService(userMarketsUpdateSettingsService)
																	 .WithPriceGridLoadService(priceGridLoadService)
																	 .WithScratchPadController(scratchPadController)
																	 .WithMarketsFilterController(marketsFilterController)
																	 .WithRemovePriceBandService(removePriceBandService)
																	 .WithGridDisplaySettingsController(gridDisplaySettingsController)
																	 .Build();

            testObjects.MarketsDashboardService.BuildNewDashboard(testObjects.MarketsViewModel,
                                                                  testObjects.MarketsToolBarViewModel,
                                                                  1);

            testObjects.MarketsDashboardService.InitializeDashboard();

            // ACT
            testObjects.MarketsDashboardService.RemoveDashboard(testObjects.MarketsToolBarViewModel);

            // ASSERT
            Mock.Get(testObjects.ScratchPadFormatSettingsService)
                .Verify(f => f.DeleteSettings());

            Mock.Get(testObjects.ScratchPadFormatSettingsService)
                .Verify(f => f.Dispose());

            Mock.Get(scratchPadController)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldDisposeAllServices_When_Dispose()
        {
			var manualFilterChangedService = Mock.Of<IManualFilterChangedService>();
			var userPublicationsProvider = Mock.Of<IUserPublicationsProvider>();
			var userMarketsWithSettingsService = Mock.Of<IUserMarketsWithSettingsService>();
			var userMarketsFilterUpdateReasonService = Mock.Of<IUserMarketsUpdateReasonService>(f => f.UserMarketsFilter == Observable.Empty<UserMarketsFilterArgs>());
			var userMarketsUpdateSettingsService = Mock.Of<IUserMarketsUpdateSettingsService>();
			var priceGridLoadService = Mock.Of<IPriceGridLoadService>();
            var gridDisplaySettings = new GridDisplaySettingsViewModel();
            var gridDisplaySettingsController = Mock.Of<IGridDisplaySettingsController>(c => c.ViewModel == gridDisplaySettings);
            var scratchPad = new ScratchPadViewModel();
            var scratchPadController = Mock.Of<IScratchPadController>(c => c.ViewModel == scratchPad);
            var marketsFilter = new MarketsFilterViewModel();
            var marketsFilterController = Mock.Of<IMarketsFilterViewModelController>(c => c.ViewModel == marketsFilter);
            var removePriceBandService = Mock.Of<IRemovePriceBandService>(r => r.OnRemovePriceBand == Observable.Empty<LinkedCurve>());

            var testObjects = new MarketsDashboardTestObjectBuilder().WithManualFilterChangedService(manualFilterChangedService)
																	 .WithUserPublicationsProvider(userPublicationsProvider)
																	 .WithUserMarketsFilterUpdateReasonService(userMarketsFilterUpdateReasonService)
																	 .WithUserMarketsWithSettingsService(userMarketsWithSettingsService)
																	 .WithUserMarketsUpdateSettingsService(userMarketsUpdateSettingsService)
																	 .WithPriceGridLoadService(priceGridLoadService)
																	 .WithScratchPadController(scratchPadController)
																	 .WithMarketsFilterController(marketsFilterController)
																	 .WithRemovePriceBandService(removePriceBandService)
																	 .WithGridDisplaySettingsController(gridDisplaySettingsController)
																	 .Build();

            testObjects.MarketsDashboardService.BuildNewDashboard(testObjects.MarketsViewModel,
                                                                  testObjects.MarketsToolBarViewModel,
                                                                  1);

            testObjects.MarketsDashboardService.InitializeDashboard();

            // ACT
            testObjects.MarketsDashboardService.Dispose();

            // ASSERT
            Mock.Get(userMarketsFilterUpdateReasonService)
                .Verify(u => u.Dispose());

            Mock.Get(userMarketsWithSettingsService)
				.Verify(p => p.Dispose());

            Mock.Get(marketsFilterController)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.PriceGridViewModelController)
                .Verify(c => c.Dispose());

            Mock.Get(scratchPadController)
                .Verify(c => c.Dispose());

            Mock.Get(testObjects.ScratchPadFormatSettingsService)
                .Verify(f => f.Dispose());

            Mock.Get(removePriceBandService)
                .Verify(r => r.Dispose());

            Mock.Get(gridDisplaySettingsController)
                .Verify(c => c.Dispose());
        }

        [Test]
        public void ShouldNotDisposedServices_When_Disposed()
        {
			var manualFilterChangedService = Mock.Of<IManualFilterChangedService>();
			var userPublicationsProvider = Mock.Of<IUserPublicationsProvider>();
			var userMarketsWithSettingsService = Mock.Of<IUserMarketsWithSettingsService>();
			var userMarketsFilterUpdateReasonService = Mock.Of<IUserMarketsUpdateReasonService>(f => f.UserMarketsFilter == Observable.Empty<UserMarketsFilterArgs>());
			var userMarketsUpdateSettingsService = Mock.Of<IUserMarketsUpdateSettingsService>();
			var priceGridLoadService = Mock.Of<IPriceGridLoadService>();
            var gridDisplaySettings = new GridDisplaySettingsViewModel();
            var gridDisplaySettingsController = Mock.Of<IGridDisplaySettingsController>(c => c.ViewModel == gridDisplaySettings);
            var scratchPad = new ScratchPadViewModel();
            var scratchPadController = Mock.Of<IScratchPadController>(c => c.ViewModel == scratchPad);
            var marketsFilter = new MarketsFilterViewModel();
            var marketsFilterController = Mock.Of<IMarketsFilterViewModelController>(c => c.ViewModel == marketsFilter);
            var removePriceBandService = Mock.Of<IRemovePriceBandService>(r => r.OnRemovePriceBand == Observable.Empty<LinkedCurve>());

            var testObjects = new MarketsDashboardTestObjectBuilder().WithManualFilterChangedService(manualFilterChangedService)
																	 .WithUserPublicationsProvider(userPublicationsProvider)
																	 .WithUserMarketsFilterUpdateReasonService(userMarketsFilterUpdateReasonService)
																	 .WithUserMarketsWithSettingsService(userMarketsWithSettingsService)
																	 .WithUserMarketsUpdateSettingsService(userMarketsUpdateSettingsService)
																	 .WithPriceGridLoadService(priceGridLoadService)
																	 .WithScratchPadController(scratchPadController)
																	 .WithMarketsFilterController(marketsFilterController)
																	 .WithRemovePriceBandService(removePriceBandService)
																	 .WithGridDisplaySettingsController(gridDisplaySettingsController)
																	 .Build();

			testObjects.MarketsDashboardService.BuildNewDashboard(testObjects.MarketsViewModel,
                                                                  testObjects.MarketsToolBarViewModel,
                                                                  1);

            testObjects.MarketsDashboardService.InitializeDashboard();

            testObjects.MarketsDashboardService.Dispose();

            // ACT
            testObjects.MarketsDashboardService.Dispose();

            // ASSERT
            Mock.Get(userMarketsFilterUpdateReasonService)
                .Verify(u => u.Dispose(), Times.Once);
        }
    }
}
