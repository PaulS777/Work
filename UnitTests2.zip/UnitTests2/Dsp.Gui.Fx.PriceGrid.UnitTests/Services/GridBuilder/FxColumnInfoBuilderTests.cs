﻿using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;
using Dsp.Gui.Common.UnitTests;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Services.GridBuilder;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.GridBuilder
{
    [TestFixture]
    public class FxColumnInfoBuilderTests
    {
        [Test]
        public void ShouldGetColumnInfos_From_FxCurveDefinitions()
        {
            var fxCurveDefinitions = new FxCurveDefinition[]
            {
                new(101, "name", "FX_EURUSD", Currency.EUR, Currency.USD, null, 10, true, "", EntityStatus.Active),
                new(102, "name", "FX_GBPUSD", Currency.GBP, Currency.USD, null, 10, true, "", EntityStatus.Active)
            };

            var builder = new FxColumnInfoBuilder();

            // ACT
            var result = builder.GetColumnInfos(fxCurveDefinitions);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(3));

            Assert.That(result[0].ColumnType, Is.EqualTo(FxColumnType.Tenor));
            Assert.That(result[0].BindingPath, Is.EqualTo("Tenor"));

            Assert.That(result[1].ColumnType, Is.EqualTo(FxColumnType.Price));
            Assert.That(result[1].Header, Is.EqualTo("FX_EURUSD"));
            Assert.That(result[1].BindingPath, Is.EqualTo("PriceCells[0]"));

            Assert.That(result[2].ColumnType, Is.EqualTo(FxColumnType.Price));
            Assert.That(result[2].Header, Is.EqualTo("FX_GBPUSD"));
            Assert.That(result[2].BindingPath, Is.EqualTo("PriceCells[1]"));
        }
    }
}
