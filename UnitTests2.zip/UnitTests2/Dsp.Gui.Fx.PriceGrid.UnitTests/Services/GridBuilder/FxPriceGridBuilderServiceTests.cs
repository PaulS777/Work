﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Services.GridBuilder;
using Dsp.Gui.Fx.PriceGrid.Services.PriceStream;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.GridBuilder
{
    [TestFixture]
    public class FxPriceGridBuilderServiceTests
    {
        [Test]
        public void ShouldGenerateGrid_From_Streams()
        {
            var ids = new List<int>{101, 102};

            var tenor1 = new MonthlyTenor(2020, 7);
            var tenor2 = new MonthlyTenor(2020, 8);
            var tenor3 = new MonthlyTenor(2020, 9);

            var fxCurve1 = new List<FxCurvePoint>
            {
                new(tenor1, 1.11, 1.21),
                new(tenor2, 1.12, 1.22),
            };

            var fxStreamProvider1 = new Mock<IFxStreamProvider>();
            fxStreamProvider1.SetupGet(p => p.FxPrices).Returns(fxCurve1);

            var fxCurve2 = new List<FxCurvePoint>
            {
                new(tenor2, 1.31, 1.42),
                new(tenor3, 1.32, 1.43),
            };

            var fxStreamProvider2 = new Mock<IFxStreamProvider>();
            fxStreamProvider2.SetupGet(p => p.FxPrices).Returns(fxCurve2);

            var fxStreams = new List<IFxStreamProvider> {fxStreamProvider1.Object, fxStreamProvider2.Object};

            var service = new FxPriceGridBuilderService();

            // ACT
            var grid = service.GenerateFxPriceGrid(ids, fxStreams);

            // ASSERT
            Assert.That(grid.Count, Is.EqualTo(3));

            // ASSERT - ROW 1
            Assert.That(grid[0].GetMonthlyTenor(), Is.EqualTo(tenor1));
            Assert.That(grid[0].Tenor, Is.EqualTo("Jul20"));

            Assert.That(grid[0].PriceCells.Count, Is.EqualTo(2));
            Assert.That(grid[0].PriceCells[0].PriceCellInfo().Id, Is.EqualTo(101));
            Assert.That(grid[0].PriceCells[1].PriceCellInfo().Id, Is.EqualTo(102));
            Assert.That(grid[0].PriceCells[0].PriceCellInfo().TenorValue, Is.EqualTo(tenor1.GetTenorValue()));
            Assert.That(grid[0].PriceCells[1].PriceCellInfo().TenorValue, Is.EqualTo(tenor1.GetTenorValue()));

            // ASSERT - ROW 2
            Assert.That(grid[1].GetMonthlyTenor(), Is.EqualTo(tenor2));
            Assert.That(grid[1].Tenor, Is.EqualTo("Aug20"));

            Assert.That(grid[1].PriceCells.Count, Is.EqualTo(2));
            Assert.That(grid[1].PriceCells[0].PriceCellInfo().Id, Is.EqualTo(101));
            Assert.That(grid[1].PriceCells[1].PriceCellInfo().Id, Is.EqualTo(102));
            Assert.That(grid[1].PriceCells[0].PriceCellInfo().TenorValue, Is.EqualTo(tenor2.GetTenorValue()));
            Assert.That(grid[1].PriceCells[1].PriceCellInfo().TenorValue, Is.EqualTo(tenor2.GetTenorValue()));

            // ASSERT - ROW 3
            Assert.That(grid[2].GetMonthlyTenor(), Is.EqualTo(tenor3));

            Assert.That(grid[2].Tenor, Is.EqualTo("Sep20"));

            Assert.That(grid[2].PriceCells.Count, Is.EqualTo(2));
            Assert.That(grid[2].PriceCells[0].PriceCellInfo().Id, Is.EqualTo(101));
            Assert.That(grid[2].PriceCells[1].PriceCellInfo().Id, Is.EqualTo(102));
            Assert.That(grid[2].PriceCells[0].PriceCellInfo().TenorValue, Is.EqualTo(tenor3.GetTenorValue()));
            Assert.That(grid[2].PriceCells[1].PriceCellInfo().TenorValue, Is.EqualTo(tenor3.GetTenorValue()));
        }
    }
}
