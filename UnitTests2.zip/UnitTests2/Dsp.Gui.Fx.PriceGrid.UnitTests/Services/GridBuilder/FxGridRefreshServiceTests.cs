﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Common.UnitTests;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Services.GridBuilder;
using Dsp.Gui.Fx.PriceGrid.Services.GridUpdate;
using Dsp.Gui.Fx.PriceGrid.Services.PriceStream;
using Dsp.Gui.Fx.PriceGrid.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.GridBuilder
{
    internal interface IFxGridRefreshServiceTestObjects
    {
        IFxStreamsSubscriptionService FxStreamsSubscriptionService { get; }
        IFxColumnInfoBuilder FxColumnInfoBuilder { get; }
        IFxPriceGridBuilderService FxPriceGridBuilderService { get; }
        IFxPriceGridUpdateService FxPriceGridUpdateService { get; }
        List<IFxStreamProvider> FxStreamProviders { get; }
        ISubject<List<IFxStreamProvider>> FxStreamsReady { get; }
        FxGridRefreshService FxGridRefreshService { get; }
    }

    [TestFixture]
    public class FxGridRefreshServiceTests
    {
        private class FxGridRefreshServiceTestObjectBuilder
        {
            private List<IFxStreamProvider> _fxStreamProviders;
            private Exception _refreshStreamsException;
            private List<FxColumnInfo> _columnInfos;
            private List<FxPriceRowViewModel> _grid;

            public FxGridRefreshServiceTestObjectBuilder WithFxStreamProviders(List<IFxStreamProvider> values)
            {
                _fxStreamProviders = values;
                return this;
            }

            public FxGridRefreshServiceTestObjectBuilder WithRefreshStreamsException(Exception value)
            {
                _refreshStreamsException = value;
                return this;
            }

            public FxGridRefreshServiceTestObjectBuilder WithFxColumnInfos(List<FxColumnInfo> values)
            {
                _columnInfos = values;
                return this;
            }

            public FxGridRefreshServiceTestObjectBuilder WithFxPriceGrid(List<FxPriceRowViewModel> values)
            {
                _grid = values;
                return this;
            }

            public IFxGridRefreshServiceTestObjects Build()
            {
                var testObjects = new Mock<IFxGridRefreshServiceTestObjects>();

                var fxStreamProviders = new BehaviorSubject<List<IFxStreamProvider>>(_fxStreamProviders);
                testObjects.SetupGet(o => o.FxStreamsReady).Returns(fxStreamProviders);

                var fxStreamSubscriptionService = new Mock<IFxStreamsSubscriptionService>();

                if (_refreshStreamsException != null)
                {
                    fxStreamSubscriptionService.Setup(fx => fx.RefreshFxStreams(It.IsAny<List<int>>(), It.IsAny<IScheduler>()))
                                               .Throws(_refreshStreamsException);
                }

                fxStreamSubscriptionService.SetupGet(fx => fx.FxStreamsReady).Returns(fxStreamProviders);

                testObjects.SetupGet(o => o.FxStreamsSubscriptionService).Returns(fxStreamSubscriptionService.Object);

                var fxColumnInfoBuilder = new Mock<IFxColumnInfoBuilder>();

                fxColumnInfoBuilder.Setup(b => b.GetColumnInfos(It.IsAny<List<FxCurveDefinition>>()))
                                   .Returns(_columnInfos);

                testObjects.SetupGet(o => o.FxColumnInfoBuilder).Returns(fxColumnInfoBuilder.Object);

                var fxPriceGridBuilderService = new Mock<IFxPriceGridBuilderService>();

                fxPriceGridBuilderService.Setup(b => b.GenerateFxPriceGrid(It.IsAny<List<int>>(), It.IsAny<List<IFxStreamProvider>>()))
                                         .Returns(_grid);

                testObjects.SetupGet(o => o.FxPriceGridBuilderService).Returns(fxPriceGridBuilderService.Object);

                var fxPriceGridUpdateService = new Mock<IFxPriceGridUpdateService>();
                testObjects.SetupGet(o => o.FxPriceGridUpdateService).Returns(fxPriceGridUpdateService.Object);

                var fxGridRefreshService = new FxGridRefreshService(fxStreamSubscriptionService.Object, 
                                                                    fxColumnInfoBuilder.Object,
                                                                    fxPriceGridBuilderService.Object,
                                                                    fxPriceGridUpdateService.Object,
                                                                    TestMocks.GetSchedulerProvider().Object, 
                                                                    TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.FxGridRefreshService).Returns(fxGridRefreshService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldRefreshFxStreams_OnBuildFxGridGrid()
        {
            var dispatcher = new Mock<IDispatcherExecutionService>();

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinition(101, "name", "desc", Currency.EUR, Currency.USD, null, 10, true, "", EntityStatus.Active)
            };

            var testObjects = new FxGridRefreshServiceTestObjectBuilder().Build();

            // ACT
            testObjects.FxGridRefreshService.BuildFxPriceGrid(fxCurveDefinitions, dispatcher.Object);

            // ASSERT
            Mock.Get(testObjects.FxStreamsSubscriptionService).Verify(o => 
                o.RefreshFxStreams(It.Is<List<int>>(list => list.Count ==1 && list[0] == 101), It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldReleaseSemaphore_OnRefreshFxStreamsException()
        {
            var dispatcher = new Mock<IDispatcherExecutionService>();

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinition(101, "name", "desc", Currency.EUR, Currency.USD, null, 10, true, "", EntityStatus.Active)
            };

            var exception = new Exception();

            var testObjects = new FxGridRefreshServiceTestObjectBuilder().WithRefreshStreamsException(exception)
                                                                         .Build();


            try
            {
                testObjects.FxGridRefreshService.BuildFxPriceGrid(fxCurveDefinitions, dispatcher.Object);
            }
            catch
            {
                // ignored
            }

            Mock.Get(testObjects.FxStreamsSubscriptionService).Invocations.Clear();

            // ACT
            try
            {
                testObjects.FxGridRefreshService.BuildFxPriceGrid(fxCurveDefinitions, dispatcher.Object);
            }
            catch
            {
                // ignored
            }

            // ASSERT
            Mock.Get(testObjects.FxStreamsSubscriptionService).Verify(o =>
                o.RefreshFxStreams(It.Is<List<int>>(list => list.Count == 1 && list[0] == 101), It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldBuildAndPublishFxPriceGrid_OnFxStreamsReady()
        {
            var dispatcher = new Mock<IDispatcherExecutionService>();

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinition(101, "name", "desc", Currency.EUR, Currency.USD, null, 10, true, "", EntityStatus.Active)
            };

            var columnInfos = new List<FxColumnInfo>
            {
                new FxColumnInfo(FxColumnType.Price, string.Empty)
            };

            var grid = new List<FxPriceRowViewModel>
            {
                new FxPriceRowViewModel(new MonthlyTenor(2020, 7))
            };

            var streamProviders = new List<IFxStreamProvider> {Mock.Of<IFxStreamProvider>()};

            var testObjects = new FxGridRefreshServiceTestObjectBuilder().WithFxStreamProviders(streamProviders)
                                                                         .WithFxColumnInfos(columnInfos)
                                                                         .WithFxPriceGrid(grid)
                                                                         .Build();

            FxPriceGridArgs result = null;

            using (testObjects.FxGridRefreshService.FxGridInitialized.Subscribe(args => result = args))
            {
                // ACT
                testObjects.FxGridRefreshService.BuildFxPriceGrid(fxCurveDefinitions, dispatcher.Object);

                // ASSERT
                Assert.AreEqual(1, result.ColumnInfos.Count);
                Assert.AreEqual(1, result.FxPriceRows.Count);
            }
        }

        [Test]
        public void ShouldNotBuildGridWhenDisposed()
        {
            var dispatcher = new Mock<IDispatcherExecutionService>();

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinition(101, "name", "desc", Currency.EUR, Currency.USD, null, 10, true, "", EntityStatus.Active)
            };

            var columnInfos = new List<FxColumnInfo>
            {
                new FxColumnInfo(FxColumnType.Price, string.Empty)
            };

            var grid = new List<FxPriceRowViewModel>
            {
                new FxPriceRowViewModel(new MonthlyTenor(2020, 7))
            };

            var streamProviders = new List<IFxStreamProvider> { Mock.Of<IFxStreamProvider>() };

            var testObjects = new FxGridRefreshServiceTestObjectBuilder().WithFxColumnInfos(columnInfos)
                                                                         .WithFxPriceGrid(grid)
                                                                         .Build();
            FxPriceGridArgs result = null;

            using (testObjects.FxGridRefreshService.FxGridInitialized.Subscribe(args => result = args))
            {
                testObjects.FxGridRefreshService.BuildFxPriceGrid(fxCurveDefinitions, dispatcher.Object);

                testObjects.FxGridRefreshService.Dispose();

                // ACT
                testObjects.FxStreamsReady.OnNext(streamProviders);

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldNotDisposeWhenDisposed()
        {
            var dispatcher = new Mock<IDispatcherExecutionService>();

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinition(101, "name", "desc", Currency.EUR, Currency.USD, null, 10, true, "", EntityStatus.Active)
            };

            var columnInfos = new List<FxColumnInfo>
            {
                new FxColumnInfo(FxColumnType.Price, string.Empty)
            };

            var grid = new List<FxPriceRowViewModel>
            {
                new FxPriceRowViewModel(new MonthlyTenor(2020, 7))
            };

            var streamProviders = new List<IFxStreamProvider> { Mock.Of<IFxStreamProvider>() };

            var testObjects = new FxGridRefreshServiceTestObjectBuilder().WithFxColumnInfos(columnInfos)
                                                                         .WithFxPriceGrid(grid)
                                                                         .Build();
            FxPriceGridArgs result = null;

            using (testObjects.FxGridRefreshService.FxGridInitialized.Subscribe(args => result = args))
            {
                testObjects.FxGridRefreshService.BuildFxPriceGrid(fxCurveDefinitions, dispatcher.Object);

                testObjects.FxGridRefreshService.Dispose();
                testObjects.FxGridRefreshService.Dispose();

                // ACT
                testObjects.FxStreamsReady.OnNext(streamProviders);

                // ASSERT
                Assert.IsNull(result);
            }
        }
    }
}
