﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Fx.PriceGrid.Services.PriceStream;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.PriceStream
{
    internal interface IFxStreamSubscriptionServiceTestObjects
    {
        IPriceCurveService PriceCurveService { get; }
        IAggregatedFxStreamService AggregatedFxStreamService { get; }
        IPriceCurveSubscriptionManager PriceCurveSubscriptionManager { get; }
        ISubject<Unit> FxStreamsAvailable { get; }
        IScheduler Scheduler { get; }
        FxStreamsSubscriptionService FxStreamsSubscriptionService { get; }
    }

    [TestFixture]
    public class FxStreamsSubscriptionServiceTests
    {
        private class FxStreamSubscriptionServiceTestObjectBuilder
        {
            private readonly Mock<IPriceCurveSubscriptionManager> _priceCurveSubscriptionManager = new();

            private IFxStreamProvider _fxStreamProvider = new Mock<IFxStreamProvider>().Object;
            private IFxStreamProvider _updatedFxStreamProvider = new Mock<IFxStreamProvider>().Object;

            public FxStreamSubscriptionServiceTestObjectBuilder WithFxStreamProvider(IFxStreamProvider value)
            {
                _fxStreamProvider = value;
                return this;
            }

            public FxStreamSubscriptionServiceTestObjectBuilder WithUpdatedFxStreamProvider(IFxStreamProvider value)
            {
                _updatedFxStreamProvider = value;
                return this;
            }

            public FxStreamSubscriptionServiceTestObjectBuilder WithPriceCurveSubject(int curveId, IObservable<PriceCurve> priceCurve)
            {
                _priceCurveSubscriptionManager.Setup(c => c.GetPriceCurve(curveId)).Returns(priceCurve);
                return this;
            }

            public IFxStreamSubscriptionServiceTestObjects Build()
            {
                var testObjects = new Mock<IFxStreamSubscriptionServiceTestObjects>();

                testObjects.SetupGet(o => o.Scheduler).Returns(Scheduler.Immediate);

                var priceCurveService = new Mock<IPriceCurveService>();

                testObjects.SetupGet(o => o.PriceCurveService).Returns(priceCurveService.Object);

                var streamsReady = new Subject<Unit>();

                testObjects.SetupGet(o => o.FxStreamsAvailable).Returns(streamsReady);

                var aggregatedFxStreamService = new Mock<IAggregatedFxStreamService>();

                aggregatedFxStreamService.Setup(a => a.FxStreamsAvailable(It.IsAny<List<IFxStreamProvider>>()))
                                         .Returns(streamsReady);

                testObjects.SetupGet(o => o.AggregatedFxStreamService)
                           .Returns(aggregatedFxStreamService.Object);

                var factory = new Mock<IServiceFactory<IFxStreamProvider>>();

                factory.SetupSequence(f => f.Create())
                       .Returns(_fxStreamProvider)
                       .Returns(_updatedFxStreamProvider);

                testObjects.SetupGet(o => o.PriceCurveSubscriptionManager)
                           .Returns(_priceCurveSubscriptionManager.Object);

                var fxStreamsSubscriptionService
                    = new FxStreamsSubscriptionService(priceCurveService.Object,
                                                       aggregatedFxStreamService.Object,
                                                       _priceCurveSubscriptionManager.Object)
                      {
                          FxStreamProviderFactory = factory.Object
                      };

                testObjects.SetupGet(o => o.FxStreamsSubscriptionService)
                           .Returns(fxStreamsSubscriptionService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSubscribeToFxCurves()
        {
            var ids = new List<int> {101};

            var testObjects = new FxStreamSubscriptionServiceTestObjectBuilder().Build();

            // ACT
            testObjects.FxStreamsSubscriptionService.RefreshFxStreams(ids, testObjects.Scheduler);

            // ASSERT
            Mock.Get(testObjects.PriceCurveService).Verify(p => 
                p.SubscribeToFxCurves(It.Is<IList<int>>(curveIds => curveIds.Count == 1 && curveIds.First() == 101)));
        }

        [Test]
        public void ShouldInitializeFxStream()
        {
            var ids = new List<int> { 101 };
            var fxStream = new Mock<IFxStreamProvider>();

            var testObjects = new FxStreamSubscriptionServiceTestObjectBuilder().WithFxStreamProvider(fxStream.Object)
                                                                                .Build();

            // ACT
            testObjects.FxStreamsSubscriptionService.RefreshFxStreams(ids, testObjects.Scheduler);

            // ASSERT
            fxStream.VerifySet(fx => fx.Id = 101);
            fxStream.Verify(fx => fx.Initialize(It.IsAny<IObservable<FxPriceCurve>>(), testObjects.Scheduler));

            Mock.Get(testObjects.PriceCurveSubscriptionManager).Verify(p => p.GetFxCurve(101));

            Mock.Get(testObjects.AggregatedFxStreamService)
                .Verify(a => a.FxStreamsAvailable(It.Is<List<IFxStreamProvider>>(streams => streams.Count == 1)));
        }

        [Test]
        public void ShouldPublishFxStreamsReady_When_FxStreamsAvailable()
        {
            var ids = new List<int> { 101 };
            var fxStream = new Mock<IFxStreamProvider>();

            var testObjects = new FxStreamSubscriptionServiceTestObjectBuilder().WithFxStreamProvider(fxStream.Object)
                                                                                .Build();

            var result = false;

            using (testObjects.FxStreamsSubscriptionService.FxStreamsReady.Subscribe(_ => result = true))
            {
                testObjects.FxStreamsSubscriptionService.RefreshFxStreams(ids, testObjects.Scheduler);

                // ACT
                testObjects.FxStreamsAvailable.OnNext(Unit.Default);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldUnSubscribe_And_Dispose_OldFxStreams()
        {
            var ids1 = new List<int> { 101 };
            var ids2 = new List<int> { 102 };
            var fxStream1 = new Mock<IFxStreamProvider>();
            var fxStream2 = new Mock<IFxStreamProvider>();

            var testObjects = new FxStreamSubscriptionServiceTestObjectBuilder().WithFxStreamProvider(fxStream1.Object)
                                                                                .WithUpdatedFxStreamProvider(fxStream2.Object)
                                                                                .Build();

            testObjects.FxStreamsSubscriptionService.RefreshFxStreams(ids1, testObjects.Scheduler);

            // ACT
            testObjects.FxStreamsSubscriptionService.RefreshFxStreams(ids2, testObjects.Scheduler);

            // ASSERT
            fxStream1.Verify(fx => fx.Dispose());

            Mock.Get(testObjects.PriceCurveService).Verify(p =>
                p.UnsubscribeFromFxCurves(It.Is<IList<int>>(curveIds => curveIds.Count == 1)));
        }

        [Test]
        public void ShouldUnSubscribe_And_Dispose_FxStreams_OnDispose()
        {
            var ids1 = new List<int> { 101 };

            var fxStream1 = new Mock<IFxStreamProvider>();

            var testObjects = new FxStreamSubscriptionServiceTestObjectBuilder().WithFxStreamProvider(fxStream1.Object)
                                                                                .Build();

            testObjects.FxStreamsSubscriptionService.RefreshFxStreams(ids1, testObjects.Scheduler);

            // ACT
            testObjects.FxStreamsSubscriptionService.Dispose();

            // ASSERT
            fxStream1.Verify(fx => fx.Dispose());

            Mock.Get(testObjects.PriceCurveService).Verify(p =>
                p.UnsubscribeFromFxCurves(It.Is<IList<int>>(curveIds => curveIds.Count == 1)));
        }

        [Test]
        public void ShouldNotPublishFxStreamsReady_When_Disposed()
        {
            var ids = new List<int> { 101 };
            var fxStream = new Mock<IFxStreamProvider>();

            var testObjects = new FxStreamSubscriptionServiceTestObjectBuilder().WithFxStreamProvider(fxStream.Object)
                                                                                .Build();
            var result = false;

            using (testObjects.FxStreamsSubscriptionService.FxStreamsReady.Subscribe(_ => result = true))
            {
                testObjects.FxStreamsSubscriptionService.RefreshFxStreams(ids, testObjects.Scheduler);

                testObjects.FxStreamsSubscriptionService.Dispose();

                // ACT
                testObjects.FxStreamsAvailable.OnNext(Unit.Default);

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var ids1 = new List<int> { 101 };

            var fxStream1 = new Mock<IFxStreamProvider>();

            var testObjects = new FxStreamSubscriptionServiceTestObjectBuilder().WithFxStreamProvider(fxStream1.Object)
                                                                                .Build();

            testObjects.FxStreamsSubscriptionService.RefreshFxStreams(ids1, testObjects.Scheduler);

            testObjects.FxStreamsSubscriptionService.Dispose();

            // ACT
            testObjects.FxStreamsSubscriptionService.Dispose();

            // ASSERT
            fxStream1.Verify(fx => fx.Dispose(), Times.Once);

            Mock.Get(testObjects.PriceCurveService).Verify(p =>
                p.UnsubscribeFromFxCurves(It.Is<IList<int>>(curveIds => curveIds.Count == 1)), Times.Once);
        }
    }
}
