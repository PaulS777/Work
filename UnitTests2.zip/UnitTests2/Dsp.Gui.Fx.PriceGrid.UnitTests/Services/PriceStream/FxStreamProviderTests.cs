﻿using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Services.PriceStream;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.PriceStream
{
    internal interface IFxStreamProviderTestObjects
    {
        ISubject<FxPriceCurve> PriceCurveSubject { get; }
        TestScheduler TestScheduler { get; }
        FxStreamProvider FxStreamProvider { get; }
    }

    [TestFixture]
    public class FxStreamProviderTests
    {
        private class FxStreamProviderTestObjectBuilder
        {
            public IFxStreamProviderTestObjects Build()
            {
                var testObjects = new Mock<IFxStreamProviderTestObjects>();

                var priceCurveSubject = new Subject<FxPriceCurve>();
                testObjects.SetupGet(o => o.PriceCurveSubject).Returns(priceCurveSubject);

                var testScheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(testScheduler);

                var service = new FxStreamProvider();
                testObjects.SetupGet(o => o.FxStreamProvider).Returns(service);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldSetId()
        {
            var testObjects = new FxStreamProviderTestObjectBuilder().Build();

            // ACT
            testObjects.FxStreamProvider.Id = 101;

            // ASSERT
            Assert.That(testObjects.FxStreamProvider.Id, Is.EqualTo(101));
        }

        [Test]
        public void ShouldPublishFxCurvePoints_FromPriceCurve()
        {
            var monthlyTenor = new MonthlyTenor(2019, 8);

            var priceCurve = new PriceCurveBuilder().WithId(1)
                                                    .WithMonthlyPrices(
                                                         new TenorPrices<MonthlyTenor>([monthlyTenor],
																					   [1.1d],
																					   null,
																					   new[] {1.3d},
																					   null))
                                                    .BuildFx();

            var testObjects = new FxStreamProviderTestObjectBuilder().Build();

            var tickInterval = TimeSpan.FromMilliseconds(1000).Ticks;

            IReadOnlyList<FxCurvePoint> result = null;

            testObjects.FxStreamProvider.Initialize(testObjects.PriceCurveSubject, testObjects.TestScheduler);

            using (testObjects.FxStreamProvider.FxPriceStream.Subscribe(fx => result = fx))
            {
                // ACT
                testObjects.PriceCurveSubject.OnNext(priceCurve);
                testObjects.TestScheduler.AdvanceBy(tickInterval);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
                Assert.That(result[0].Tenor, Is.EqualTo(monthlyTenor));
                Assert.That(result[0].BidValue, Is.EqualTo(1.1d));
                Assert.That(result[0].AskValue, Is.EqualTo(1.3d));

                Assert.That(testObjects.FxStreamProvider.FxPrices.Count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldThrottleUpdates()
        {
            var monthlyTenor = new MonthlyTenor(2019, 8);

            var priceCurve1 = new PriceCurveBuilder().WithId(1)
                                                    .WithMonthlyPrices(
                                                         new TenorPrices<MonthlyTenor>([monthlyTenor],
																					   [1.11d], 
																					   null,
																					   new[]{ 1.31d }, 
																					   null))
                                                    .BuildFx();

            var priceCurve2 = new PriceCurveBuilder().WithId(1)
                                                     .WithMonthlyPrices(
                                                          new TenorPrices<MonthlyTenor>([monthlyTenor],
																						[1.12d], 
																						null,
																						new[] { 1.32d },
																						null))
                                                     .BuildFx();

            var priceCurve3 = new PriceCurveBuilder().WithId(1)
                                                     .WithMonthlyPrices(
                                                          new TenorPrices<MonthlyTenor>([monthlyTenor],
																						[1.13d], 
																						null,
																						new[] { 1.33d },
																						null))
                                                     .BuildFx();

            var priceCurve4 = new PriceCurveBuilder().WithId(1)
                                                     .WithMonthlyPrices(
                                                          new TenorPrices<MonthlyTenor>([monthlyTenor],
																						[1.14d],
																						null,
																						new[] { 1.34d },
																						null))
                                                     .BuildFx();

            var testObjects = new FxStreamProviderTestObjectBuilder().Build();

            var tickInterval = TimeSpan.FromMilliseconds(1000).Ticks;

            IReadOnlyList<FxCurvePoint> result = null;
            var updates = 0;

            testObjects.FxStreamProvider.Initialize(testObjects.PriceCurveSubject, testObjects.TestScheduler);

            using (testObjects.FxStreamProvider.FxPriceStream
                              .Where(fx => fx != null)
                              .Subscribe(fx =>
                               {
                                   result = fx;
                                   updates++;
                               }))
            {
                // ACT
                testObjects.PriceCurveSubject.OnNext(priceCurve1);
                testObjects.PriceCurveSubject.OnNext(priceCurve2);

                testObjects.TestScheduler.AdvanceBy(tickInterval);

                testObjects.PriceCurveSubject.OnNext(priceCurve3);
                testObjects.PriceCurveSubject.OnNext(priceCurve4);

                testObjects.TestScheduler.AdvanceBy(tickInterval);
                testObjects.TestScheduler.AdvanceBy(tickInterval);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
                Assert.That(result[0].Tenor, Is.EqualTo(monthlyTenor));
                Assert.That(result[0].BidValue, Is.EqualTo(1.14d));
                Assert.That(result[0].AskValue, Is.EqualTo(1.34d));

                Assert.That(updates, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldNotPublishUpdatesWhenDisposed()
        {
            var monthlyTenor = new MonthlyTenor(2019, 8);

            var priceCurve = new PriceCurveBuilder().WithId(1)
                                                    .WithMonthlyPrices(
                                                          new TenorPrices<MonthlyTenor>([monthlyTenor],
																						[1.1d],
																						null,
																						new[] { 1.3d },
																						null))
                                                    .BuildFx();

            var testObjects = new FxStreamProviderTestObjectBuilder().Build();

            var tickInterval = TimeSpan.FromMilliseconds(1000).Ticks;

            IReadOnlyList<FxCurvePoint> result = null;

            testObjects.FxStreamProvider.Initialize(testObjects.PriceCurveSubject, testObjects.TestScheduler);

            using (testObjects.FxStreamProvider.FxPriceStream.Subscribe(fx => result = fx))
            {
                testObjects.FxStreamProvider.Dispose();

                // ACT
                testObjects.PriceCurveSubject.OnNext(priceCurve);
                testObjects.TestScheduler.AdvanceBy(tickInterval);

                // ASSERT
                Assert.IsNull(result);
            }
        }
    }
}
