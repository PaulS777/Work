﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Services.PriceStream;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.PriceStream
{
    [TestFixture]
    public class AggregatedFxStreamServiceTests
    {
        [Test]
        public void ShouldNotPublishBeforeAllStreamsAvailable()
        {
            var fxCurve1 = new List<FxCurvePoint>();
            var stream1 = new BehaviorSubject<IReadOnlyList<FxCurvePoint>>(null);

            var streamProvider1 = new Mock<IFxStreamProvider>();
            streamProvider1.SetupGet(s => s.FxPrices).Returns(fxCurve1);
            streamProvider1.Setup(s => s.FxPriceStream).Returns(stream1);

            var fxCurve2 = new List<FxCurvePoint>();
            var stream2 = new BehaviorSubject<IReadOnlyList<FxCurvePoint>>(null);

            var streamProvider2 = new Mock<IFxStreamProvider>();
            streamProvider2.SetupGet(s => s.FxPrices).Returns(fxCurve2);
            streamProvider2.Setup(s => s.FxPriceStream).Returns(stream2);

            var streamProviders = new List<IFxStreamProvider> { streamProvider1.Object, streamProvider2.Object };

            var service = new AggregatedFxStreamService();

            var count = 0;

            using (service.FxStreamsAvailable(streamProviders).Subscribe(_ => count++))
            {
                // ACT
                stream1.OnNext(fxCurve1);

                // ASSERT
                Assert.That(count, Is.EqualTo(0));
            }
        }

        [Test]
        public void ShouldPublishWhenAllStreamsAvailable()
        {
            var fxCurve1 = new List<FxCurvePoint>();
            var stream1 = new BehaviorSubject<IReadOnlyList<FxCurvePoint>>(null);

            var streamProvider1 = new Mock<IFxStreamProvider>();
            streamProvider1.SetupGet(s => s.FxPrices).Returns(fxCurve1);
            streamProvider1.Setup(s => s.FxPriceStream).Returns(stream1);

            var fxCurve2 = new List<FxCurvePoint>();
            var stream2 = new BehaviorSubject<IReadOnlyList<FxCurvePoint>>(null);

            var streamProvider2 = new Mock<IFxStreamProvider>();
            streamProvider2.SetupGet(s => s.FxPrices).Returns(fxCurve2);
            streamProvider2.Setup(s => s.FxPriceStream).Returns(stream2);

            var streamProviders = new List<IFxStreamProvider> {streamProvider1.Object, streamProvider2.Object};

            var service = new AggregatedFxStreamService();

            var count = 0;

            using (service.FxStreamsAvailable(streamProviders).Subscribe(_ => count++))
            {
                // ACT
                stream1.OnNext(fxCurve1);
                stream2.OnNext(fxCurve2);

                // ASSERT
                Assert.That(count, Is.EqualTo(1));
            }
        }

        [Test]
        public void ShouldNotPublish_After_FirstPublication()
        {
            var fxCurve1 = new List<FxCurvePoint>();
            var stream1 = new BehaviorSubject<IReadOnlyList<FxCurvePoint>>(null);

            var streamProvider1 = new Mock<IFxStreamProvider>();
            streamProvider1.SetupGet(s => s.FxPrices).Returns(fxCurve1);
            streamProvider1.Setup(s => s.FxPriceStream).Returns(stream1);

            var fxCurve2 = new List<FxCurvePoint>();
            var stream2 = new BehaviorSubject<IReadOnlyList<FxCurvePoint>>(null);

            var streamProvider2 = new Mock<IFxStreamProvider>();
            streamProvider2.SetupGet(s => s.FxPrices).Returns(fxCurve2);
            streamProvider2.Setup(s => s.FxPriceStream).Returns(stream2);

            var streamProviders = new List<IFxStreamProvider> { streamProvider1.Object, streamProvider2.Object };

            var service = new AggregatedFxStreamService();

            var count = 0;

            using (service.FxStreamsAvailable(streamProviders).Subscribe(_ => count++))
            {
                stream1.OnNext(fxCurve1);
                stream2.OnNext(fxCurve2);

                // ACT
                stream1.OnNext(fxCurve1);

                // ASSERT
                Assert.That(count, Is.EqualTo(1));
            }
        }
    }
}
