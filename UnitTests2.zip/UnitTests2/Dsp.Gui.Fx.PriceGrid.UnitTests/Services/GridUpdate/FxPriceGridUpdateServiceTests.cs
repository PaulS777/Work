﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Services.GridUpdate;
using Dsp.Gui.Fx.PriceGrid.Services.PriceStream;
using Dsp.Gui.Fx.PriceGrid.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.GridUpdate
{
    internal interface IFxPriceGridUpdateServiceTestObjects
    {
        IDispatcherExecutionService DispatcherExecutionService { get; }
        FxPriceGridUpdateService FxPriceGridUpdateService { get; }
    }

    [TestFixture]
    public class FxPriceGridUpdateServiceTests
    {
        private class FxPriceGridUpdateServiceTestObjectBuilder
        {
            private IFxPriceCurveMonitor _monitor1;
            private IFxPriceCurveMonitor _monitor2;

            public FxPriceGridUpdateServiceTestObjectBuilder WithMonitor1(IFxPriceCurveMonitor value)
            {
                _monitor1 = value;
                return this;
            }

            public FxPriceGridUpdateServiceTestObjectBuilder WithMonitor2(IFxPriceCurveMonitor value)
            {
                _monitor2 = value;
                return this;
            }

            public IFxPriceGridUpdateServiceTestObjects Build()
            {
                var testObjects = new Mock<IFxPriceGridUpdateServiceTestObjects>();

                var dispatcher = new Mock<IDispatcherExecutionService>();
                testObjects.SetupGet(o => o.DispatcherExecutionService).Returns(dispatcher.Object);

                var factory = new Mock<IServiceFactory<IFxPriceCurveMonitor>>();

                factory.SetupSequence(f => f.Create())
                       .Returns(_monitor1)
                       .Returns(_monitor2);

                var fxPriceGridUpdateService = new FxPriceGridUpdateService
                                               {
                                                   Factory = factory.Object
                                               };

                testObjects.SetupGet(o => o.FxPriceGridUpdateService).Returns(fxPriceGridUpdateService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeMonitors()
        {
            var monitor1 = new Mock<IFxPriceCurveMonitor>();
            var monitor2 = new Mock<IFxPriceCurveMonitor>();

            var stream1 = new Subject<IReadOnlyList<FxCurvePoint>>();
            var stream2 = new Subject<IReadOnlyList<FxCurvePoint>>();

            var streamProvider1 = Mock.Of<IFxStreamProvider>(sp => sp.Id == 101 && sp.FxPriceStream == stream1);
            var streamProvider2 = Mock.Of<IFxStreamProvider>(sp => sp.Id == 102 && sp.FxPriceStream == stream2);

            var streamProviders = new List<IFxStreamProvider>
            {
                streamProvider1, streamProvider2
            };

            var tenor1 = new MonthlyTenor(2020, 7);
            var tenor2 = new MonthlyTenor(2020, 8);

            var grid = new List<FxPriceRowViewModel>
            {
                new(tenor1)
                {
                    PriceCells = new ObservableCollection<FxPriceCellViewModel>
                    {
                        GetFxPriceCell(tenor1, 101), GetFxPriceCell(tenor1, 102)
                    }
                },
                new(tenor1)
                {
                    PriceCells = new ObservableCollection<FxPriceCellViewModel>
                    {
                        GetFxPriceCell(tenor2, 101), GetFxPriceCell(tenor2, 102)
                    }
                }
            };

            var testObjects = new FxPriceGridUpdateServiceTestObjectBuilder().WithMonitor1(monitor1.Object)
                                                                             .WithMonitor2(monitor2.Object)
                                                                             .Build();
            // ACT
            testObjects.FxPriceGridUpdateService.RefreshFxPriceCurveMonitors(streamProviders, grid, testObjects.DispatcherExecutionService);

            // ASSERT
            monitor1.Verify(m => m.Initialize(stream1, 
                                              It.Is<List<FxPriceCellViewModel>>(cells => cells.Count == 2 && cells.All(c => c.PriceCellInfo().Id == 101)),
                                              testObjects.DispatcherExecutionService));

            monitor2.Verify(m => m.Initialize(stream2,
                                              It.Is<List<FxPriceCellViewModel>>(cells => cells.Count == 2 && cells.All(c => c.PriceCellInfo().Id == 102)),
                                              testObjects.DispatcherExecutionService));
        }

        [Test]
        public void ShouldDisposeExistingMonitor_WhenRefresh()
        {
            var monitor1 = new Mock<IFxPriceCurveMonitor>();
            var monitor2 = new Mock<IFxPriceCurveMonitor>();

            var stream1 = new Subject<IReadOnlyList<FxCurvePoint>>();
            var stream2 = new Subject<IReadOnlyList<FxCurvePoint>>();

            var streamProvider1 = Mock.Of<IFxStreamProvider>(sp => sp.Id == 101 && sp.FxPriceStream == stream1);
            var streamProvider2 = Mock.Of<IFxStreamProvider>(sp => sp.Id == 102 && sp.FxPriceStream == stream2);

            var streamProviders1 = new List<IFxStreamProvider>
            {
                streamProvider1
            };

            var streamProviders2 = new List<IFxStreamProvider>
            {
                streamProvider2
            };

            var tenor1 = new MonthlyTenor(2020, 7);
            var tenor2 = new MonthlyTenor(2020, 8);

            var grid1 = new List<FxPriceRowViewModel>
            {
                new(tenor1)
                {
                    PriceCells = new ObservableCollection<FxPriceCellViewModel>
                    {
                        GetFxPriceCell(tenor1, 101),
                        GetFxPriceCell(tenor2, 101) 
                    }
                }
            };

            var grid2 = new List<FxPriceRowViewModel>
            {
                new(tenor1)
                {
                    PriceCells = new ObservableCollection<FxPriceCellViewModel>
                    {
                        GetFxPriceCell(tenor1, 102),
                        GetFxPriceCell(tenor2, 102)
                    }
                }
            };

            var testObjects = new FxPriceGridUpdateServiceTestObjectBuilder().WithMonitor1(monitor1.Object)
                                                                             .WithMonitor2(monitor2.Object)
                                                                             .Build();

            testObjects.FxPriceGridUpdateService.RefreshFxPriceCurveMonitors(streamProviders1, grid1, testObjects.DispatcherExecutionService);

            // ACT
            testObjects.FxPriceGridUpdateService.RefreshFxPriceCurveMonitors(streamProviders2, grid2, testObjects.DispatcherExecutionService);

            // ASSERT
            monitor1.Verify(m => m.Dispose());
        }

        [Test]
        public void ShouldNotInitializeMonitor_WithMissingGridCells()
        {
            var monitor1 = new Mock<IFxPriceCurveMonitor>();

            var stream1 = new Subject<IReadOnlyList<FxCurvePoint>>();

            var streamProvider1 = Mock.Of<IFxStreamProvider>(sp => sp.Id == 101 && sp.FxPriceStream == stream1);

            var streamProviders = new List<IFxStreamProvider> {streamProvider1};

            var grid = new List<FxPriceRowViewModel>();

            var testObjects = new FxPriceGridUpdateServiceTestObjectBuilder().WithMonitor1(monitor1.Object)
                                                                             .Build();
            // ACT
            testObjects.FxPriceGridUpdateService.RefreshFxPriceCurveMonitors(streamProviders, grid, testObjects.DispatcherExecutionService);

            // ASSERT
            monitor1.Verify(m => m.Initialize(It.IsAny<IObservable<IReadOnlyList<FxCurvePoint>>>(),
                                              It.IsAny<List<FxPriceCellViewModel>>(),
                                              testObjects.DispatcherExecutionService), Times.Never);
        }

        [Test]
        public void ShouldDisposeMonitorsOnDispose()
        {
            var monitor1 = new Mock<IFxPriceCurveMonitor>();

            var stream1 = new Subject<IReadOnlyList<FxCurvePoint>>();
            var streamProvider1 = Mock.Of<IFxStreamProvider>(sp => sp.Id == 101 && sp.FxPriceStream == stream1);

            var streamProviders = new List<IFxStreamProvider> {streamProvider1};

            var tenor1 = new MonthlyTenor(2020, 7);

            var grid = new List<FxPriceRowViewModel>
            {
                new(tenor1)
                {
                    PriceCells = new ObservableCollection<FxPriceCellViewModel>
                    {
                        GetFxPriceCell(tenor1, 101)
                    }
                }
            };

            var testObjects = new FxPriceGridUpdateServiceTestObjectBuilder().WithMonitor1(monitor1.Object)
                                                                             .Build();
 
            testObjects.FxPriceGridUpdateService.RefreshFxPriceCurveMonitors(streamProviders, grid, testObjects.DispatcherExecutionService);

            // ACT
            testObjects.FxPriceGridUpdateService.Dispose();

            // ASSERT
            monitor1.Verify(m => m.Dispose());
        }

        [Test]
        public void ShouldNotDispose_WhenDisposed()
        {
            var monitor1 = new Mock<IFxPriceCurveMonitor>();

            var stream1 = new Subject<IReadOnlyList<FxCurvePoint>>();
            var streamProvider1 = Mock.Of<IFxStreamProvider>(sp => sp.Id == 101 && sp.FxPriceStream == stream1);

            var streamProviders = new List<IFxStreamProvider> { streamProvider1 };

            var tenor1 = new MonthlyTenor(2020, 7);

            var grid = new List<FxPriceRowViewModel>
            {
                new(tenor1)
                {
                    PriceCells = new ObservableCollection<FxPriceCellViewModel>
                    {
                        GetFxPriceCell(tenor1, 101)
                    }
                }
            };

            var testObjects = new FxPriceGridUpdateServiceTestObjectBuilder().WithMonitor1(monitor1.Object)
                                                                             .Build();

            testObjects.FxPriceGridUpdateService.RefreshFxPriceCurveMonitors(streamProviders, grid, testObjects.DispatcherExecutionService);
            testObjects.FxPriceGridUpdateService.Dispose();

            // ACT
            testObjects.FxPriceGridUpdateService.Dispose();

            // ASSERT
            monitor1.Verify(m => m.Dispose(), Times.Once);
        }

        private static FxPriceCellViewModel GetFxPriceCell(MonthlyTenor tenor, int id)
        {
            var cellInfo = new FxPriceCellInfo(id, tenor.GetTenorValue());

            var viewModel = new FxPriceCellViewModel(cellInfo);

            return viewModel;
        }

    }
}
