﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Services.GridUpdate;
using Dsp.Gui.Fx.PriceGrid.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.GridUpdate
{
    [TestFixture]
    public class FxPriceCellUpdateServiceTests
    {
        [Test]
        public void ShouldScheduleDispatcher_On_FxStreamUpdate()
        {
            var dispatcher = GetDispatcher();

            var id = 101;

            var tenor1 = new MonthlyTenor(2020, 7);
            var tenor2 = new MonthlyTenor(2020, 8);
            var tenor3 = new MonthlyTenor(2020, 9);

            var priceCells = new List<FxPriceCellViewModel>()
            {
                GetFxPriceCell(tenor1, null, null, id),
                GetFxPriceCell(tenor2, 1.12, 1.22, id),
                GetFxPriceCell(tenor3, 1.13, 1.23, id),
            };

            var curvePoints = new List<FxCurvePoint>
            {
                new(tenor2, 1.15, 1.25),
                new(tenor3, 1.16, 1.26),
            };

            var service = new FxPriceCellUpdateService();

            // ACT
            service.UpdateFxPriceCellsFromCurve(priceCells, curvePoints, dispatcher);

            // ASSERT
            Assert.IsNull(priceCells[0].PriceCellInfo().Bid);
            Assert.IsNull(priceCells[0].PriceCellInfo().Ask);
            Assert.That(priceCells[1].PriceCellInfo().Bid, Is.EqualTo(1.15));
            Assert.That(priceCells[1].PriceCellInfo().Ask, Is.EqualTo(1.25));
            Assert.That(priceCells[2].PriceCellInfo().Bid, Is.EqualTo(1.16));
            Assert.That(priceCells[2].PriceCellInfo().Ask, Is.EqualTo(1.26));

            Mock.Get(dispatcher).Verify(d => d.Schedule(It.IsAny<Action>()), Times.Exactly(2));
        }

        [Test]
        public void ShouldUpdateFxPriceCells_From_FxStream_UsingDispatcher()
        {
            var dispatcher = GetDispatcher();

            var id = 101;

            var tenor1 = new MonthlyTenor(2020, 7);
            var tenor2 = new MonthlyTenor(2020, 8);
            var tenor3 = new MonthlyTenor(2020, 9);

            var priceCells = new List<FxPriceCellViewModel>()
            {
                GetFxPriceCell(tenor1, null, null, id),
                GetFxPriceCell(tenor2, 1.12, 1.22, id),
                GetFxPriceCell(tenor3, 1.13, 1.23, id),
            };

            var curvePoints = new List<FxCurvePoint>
            {
                new(tenor2, 1.15, 1.25),
                new(tenor3, 1.16, 1.26),
            };

            var service = new FxPriceCellUpdateService();

            // ACT
            service.UpdateFxPriceCellsFromCurve(priceCells, curvePoints, dispatcher);

            // ASSERT
            Assert.That(priceCells[1].Bid, Is.EqualTo(1.15));
            Assert.That(priceCells[1].Ask, Is.EqualTo(1.25));

            Assert.That(priceCells[2].Bid, Is.EqualTo(1.16));
            Assert.That(priceCells[2].Ask, Is.EqualTo(1.26));
        }

        [Test]
        public void ShouldNotUpdateOnDispatcher_WhenStreamPricesAreSameAsPriceCells()
        {
            var dispatcher = GetDispatcher();

            var id = 101;

            var tenor1 = new MonthlyTenor(2020, 7);
            var tenor2 = new MonthlyTenor(2020, 8);
            var tenor3 = new MonthlyTenor(2020, 9);

            var priceCells = new List<FxPriceCellViewModel>()
            {
                GetFxPriceCell(tenor1, null, null, id),
                GetFxPriceCell(tenor2, 1.12, 1.22, id),
                GetFxPriceCell(tenor3, 1.13, 1.23, id),
            };

            var curvePoints = new List<FxCurvePoint>
            {
                new(tenor2, 1.12, 1.22),
                new(tenor3, 1.13, 1.23),
            };

            var service = new FxPriceCellUpdateService();

            // ACT
            service.UpdateFxPriceCellsFromCurve(priceCells, curvePoints, dispatcher);

            // ASSERT
            Mock.Get(dispatcher).Verify(d => d.Schedule(It.IsAny<Action>()), Times.Never);
        }

        [Test]
        public void ShouldHandle_Nan_PriceValue()
        {
            var dispatcher = GetDispatcher();

            var id = 101;

            var tenor1 = new MonthlyTenor(2020, 7);
            var tenor2 = new MonthlyTenor(2020, 8);

            var priceCells = new List<FxPriceCellViewModel>()
            {
                GetFxPriceCell(tenor1, 1.11, 1.12, id),
                GetFxPriceCell(tenor2, 1.21, 1.22, id),
            };

            var curvePoints = new List<FxCurvePoint>
            {
                new(tenor1, Double.NaN, Double.NaN),
                new(tenor2, 1.22, 1.23),
            };

            var service = new FxPriceCellUpdateService();

            // ACT
            service.UpdateFxPriceCellsFromCurve(priceCells, curvePoints, dispatcher);

            // ASSERT
            Assert.IsNull(priceCells[0].Bid);
            Assert.IsNull(priceCells[0].Ask);

            Assert.That(priceCells[1].Bid, Is.EqualTo(1.22));
            Assert.That(priceCells[1].Ask, Is.EqualTo(1.23));
        }

        private static IDispatcherExecutionService GetDispatcher()
        {
            var dispatcher = new Mock<IDispatcherExecutionService>();

            dispatcher.Setup(d => d.Schedule(It.IsAny<Action>()))
                      .Callback<Action>(action => action());

            return dispatcher.Object;
        }

        private static FxPriceCellViewModel GetFxPriceCell(MonthlyTenor tenor, double? bid, double? ask, int id)
        {
            var cellInfo = new FxPriceCellInfo(id, tenor.GetTenorValue()) {Bid = bid, Ask = ask};

            var viewModel = new FxPriceCellViewModel(cellInfo);

            return viewModel;
        }
    }
}
