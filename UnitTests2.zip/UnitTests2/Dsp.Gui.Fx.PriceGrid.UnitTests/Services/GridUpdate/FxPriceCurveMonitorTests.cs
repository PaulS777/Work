﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Services.GridUpdate;
using Dsp.Gui.Fx.PriceGrid.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Services.GridUpdate
{
    internal interface IFxPriceCurveMonitorTestObjects
    {
        IFxPriceCellUpdateService FxPriceCellUpdateService { get; }
        IDispatcherExecutionService DispatcherExecutionService { get; }
        FxPriceCurveMonitor FxPriceCurveMonitor { get; }
    }

    [TestFixture]
    public class FxPriceCurveMonitorTests
    {
        private class FxPriceCurveMonitorTestObjectBuilder
        {
            public IFxPriceCurveMonitorTestObjects Build()
            {
                var testObjects = new Mock<IFxPriceCurveMonitorTestObjects>();

                var fxPriceCellUpdateService = new Mock<IFxPriceCellUpdateService>();
                testObjects.SetupGet(o => o.FxPriceCellUpdateService).Returns(fxPriceCellUpdateService.Object);

                var dispatcherExecutionService = new Mock<IDispatcherExecutionService>();

                var monitor = new FxPriceCurveMonitor(fxPriceCellUpdateService.Object, 
                                                      TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.DispatcherExecutionService).Returns(dispatcherExecutionService.Object);

                testObjects.SetupGet(o => o.FxPriceCurveMonitor).Returns(monitor);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldUpdatePriceCells_OnPriceCurveUpdate()
        {
            var fxPrices = new Subject<List<FxCurvePoint>>();
            var priceCells = new List<FxPriceCellViewModel>();

            var curvePoints = new List<FxCurvePoint>();

            var testObjects = new FxPriceCurveMonitorTestObjectBuilder().Build();

            testObjects.FxPriceCurveMonitor.Initialize(fxPrices, priceCells, testObjects.DispatcherExecutionService);

            // ACT
            fxPrices.OnNext(curvePoints);

            // ASSERT
            Mock.Get(testObjects.FxPriceCellUpdateService).Verify(u =>
                u.UpdateFxPriceCellsFromCurve(priceCells, curvePoints, testObjects.DispatcherExecutionService));
        }

        [Test]
        public void ShouldNotUpdatePriceCells_OnPriceCurveUpdate_WithNull()
        {
            var fxPrices = new Subject<List<FxCurvePoint>>();
            var priceCells = new List<FxPriceCellViewModel>();

            var testObjects = new FxPriceCurveMonitorTestObjectBuilder().Build();

            testObjects.FxPriceCurveMonitor.Initialize(fxPrices, priceCells, testObjects.DispatcherExecutionService);

            // ACT
            fxPrices.OnNext(null);

            // ASSERT
            Mock.Get(testObjects.FxPriceCellUpdateService).Verify(u =>
                u.UpdateFxPriceCellsFromCurve(priceCells, It.IsAny<List<FxCurvePoint>>(), testObjects.DispatcherExecutionService), Times.Never);
        }

        [Test]
        public void ShouldUnSubscribeFromOldPriceCurveStream_WhenInitializedWithNewStream()
        {
            var fxPrices1 = new Subject<List<FxCurvePoint>>();
            var fxPrices2 = new Subject<List<FxCurvePoint>>();

            var priceCells = new List<FxPriceCellViewModel>();

            var curvePoints = new List<FxCurvePoint>();

            var testObjects = new FxPriceCurveMonitorTestObjectBuilder().Build();

            testObjects.FxPriceCurveMonitor.Initialize(fxPrices1, priceCells, testObjects.DispatcherExecutionService);
            testObjects.FxPriceCurveMonitor.Initialize(fxPrices2, priceCells, testObjects.DispatcherExecutionService);
            // ACT
            fxPrices1.OnNext(curvePoints);

            // ASSERT
            Mock.Get(testObjects.FxPriceCellUpdateService).Verify(u =>
                u.UpdateFxPriceCellsFromCurve(priceCells, It.IsAny<List<FxCurvePoint>>(), testObjects.DispatcherExecutionService), Times.Never);
        }

        [Test]
        public void ShouldNotUpdatePriceCells_When_Disposed()
        {
            var fxPrices = new Subject<List<FxCurvePoint>>();

            var priceCells = new List<FxPriceCellViewModel>();

            var curvePoints = new List<FxCurvePoint>();

            var testObjects = new FxPriceCurveMonitorTestObjectBuilder().Build();

            testObjects.FxPriceCurveMonitor.Initialize(fxPrices, priceCells, testObjects.DispatcherExecutionService);
            testObjects.FxPriceCurveMonitor.Dispose();
            // ACT
            fxPrices.OnNext(curvePoints);

            // ASSERT
            Mock.Get(testObjects.FxPriceCellUpdateService).Verify(u =>
                u.UpdateFxPriceCellsFromCurve(priceCells, It.IsAny<List<FxCurvePoint>>(), testObjects.DispatcherExecutionService), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var fxPrices = new Subject<List<FxCurvePoint>>();

            var priceCells = new List<FxPriceCellViewModel>();

            var curvePoints = new List<FxCurvePoint>();

            var testObjects = new FxPriceCurveMonitorTestObjectBuilder().Build();

            testObjects.FxPriceCurveMonitor.Initialize(fxPrices, priceCells, testObjects.DispatcherExecutionService);
            testObjects.FxPriceCurveMonitor.Dispose();
            testObjects.FxPriceCurveMonitor.Dispose();

            // ACT
            fxPrices.OnNext(curvePoints);

            // ASSERT
            Mock.Get(testObjects.FxPriceCellUpdateService).Verify(u =>
                u.UpdateFxPriceCellsFromCurve(priceCells, It.IsAny<List<FxCurvePoint>>(), testObjects.DispatcherExecutionService), Times.Never);
        }
    }
}
