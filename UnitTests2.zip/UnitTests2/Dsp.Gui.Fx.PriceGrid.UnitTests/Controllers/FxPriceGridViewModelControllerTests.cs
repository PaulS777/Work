﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.Gui.Fx.PriceGrid.Common;
using Dsp.Gui.Fx.PriceGrid.Controllers;
using Dsp.Gui.Fx.PriceGrid.Services.GridBuilder;
using Dsp.Gui.Fx.PriceGrid.ViewModels;
using Dsp.Gui.TestObjects;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Fx.PriceGrid.UnitTests.Controllers
{
    internal interface IFxPriceGridViewModelControllerTestObjects
    {
        IDispatcherExecutionService DispatcherExecutionService { get; }
        IFxGridRefreshService FxGridRefreshService { get; }
        ISubject<List<FxCurveDefinition>> FxCurveDefinitions { get; }
        ISubject<FxPriceGridArgs> FxGridInitialized { get; }
        ISubject<HubConnectionRunState> RunState { get; }
        TestScheduler TestScheduler { get; }
        FxPriceGridViewModelController Controller { get; }
        FxPriceGridViewModel ViewModel { get; }
    }

    [TestFixture]
    public class FxPriceGridViewModelControllerTests
    {
        private class FxPriceGridViewModelControllerTestObjectBuilder
        {
            private List<FxCurveDefinition> _fxCurveDefinitions;
            private Exception _buildGridException;
            private HubConnectionRunState _runState;
            
            public FxPriceGridViewModelControllerTestObjectBuilder WithFxCurveDefinitions(List<FxCurveDefinition> values)
            {
                _fxCurveDefinitions = values;
                return this;
            }

            public FxPriceGridViewModelControllerTestObjectBuilder WithBuildGridException(Exception ex)
            {
                _buildGridException = ex;
                return this;
            }

            public FxPriceGridViewModelControllerTestObjectBuilder WithRunState(HubConnectionRunState value)
            {
                _runState = value;
                return this;
            }

            public IFxPriceGridViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IFxPriceGridViewModelControllerTestObjects>();

                var fxCurveDefinitions = new BehaviorSubject<List<FxCurveDefinition>>(_fxCurveDefinitions);

                testObjects.SetupGet(o => o.FxCurveDefinitions).Returns(fxCurveDefinitions);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.FxCurveDefinitions)
                                   .Returns(fxCurveDefinitions);

                var fxGridInitialized = new Subject<FxPriceGridArgs>();

                testObjects.SetupGet(o => o.FxGridInitialized)
                           .Returns(fxGridInitialized);

                var fxGridRefreshService = new Mock<IFxGridRefreshService>();

                fxGridRefreshService.SetupGet(fx => fx.FxGridInitialized)
                                    .Returns(fxGridInitialized);

                if (_buildGridException != null)
                {
                    fxGridRefreshService.Setup(fx => fx.BuildFxPriceGrid(It.IsAny<List<FxCurveDefinition>>(), 
                                                                         It.IsAny<IDispatcherExecutionService>()))
                                        .Throws(_buildGridException);
                }

                testObjects.SetupGet(o => o.FxGridRefreshService)
                           .Returns(fxGridRefreshService.Object);

                var runState = new BehaviorSubject<HubConnectionRunState>(_runState);

                testObjects.SetupGet(o => o.RunState)
                           .Returns(runState);

                var curvePublisherConnectionService = new Mock<ICurvePublisherConnectionService>();

                curvePublisherConnectionService.SetupGet(c => c.RunState)
                                               .Returns(runState);

                var dispatcherExecutionService = new Mock<IDispatcherExecutionService>();

                testObjects.SetupGet(o => o.DispatcherExecutionService)
                           .Returns(dispatcherExecutionService.Object);

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(testScheduler);

                schedulerProvider.SetupGet(p => p.Dispatcher)
                                 .Returns(Scheduler.Immediate);

                schedulerProvider.SetupGet(p => p.Immediate)
                                 .Returns(Scheduler.Immediate);

                var controller = new FxPriceGridViewModelController(curveControlService.Object, 
                                                                    fxGridRefreshService.Object, 
                                                                    curvePublisherConnectionService.Object,
                                                                    dispatcherExecutionService.Object, 
                                                                    schedulerProvider.Object);
                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldBuildFxPriceGrid_When_FxCurveDefinitionsLoaded()
        {
            var interval = TimeSpan.FromSeconds(6).Ticks;

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinitionTestObjectBuilder().Build()
            };

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                   .Build();
            // ACT
            testObjects.FxCurveDefinitions.OnNext(fxCurveDefinitions);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.FxGridRefreshService)
                .Verify(o => o.BuildFxPriceGrid(It.Is<List<FxCurveDefinition>>(curves => curves.Count == 1), 
                                                It.IsAny<IDispatcherExecutionService>()));
        }

        [Test]
        public void ShouldNotBuildFxPriceGrid_When_FailedStartup()
        {
            var interval = TimeSpan.FromSeconds(6).Ticks;

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinitionTestObjectBuilder().Build()
            };

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.FailedStartup)
                                                                                   .Build();
            // ACT
            testObjects.FxCurveDefinitions.OnNext(fxCurveDefinitions);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.FxGridRefreshService)
                .Verify(o => o.BuildFxPriceGrid(It.IsAny<List<FxCurveDefinition>>(), 
                                                It.IsAny<IDispatcherExecutionService>()), Times.Never);
        }

        [TestCase(HubConnectionRunState.Connected)]
        [TestCase(HubConnectionRunState.Reconnected)]
        public void ShouldBuildFxPriceGrid_When_Connected_With_FxCurveDefinitionsLoaded(HubConnectionRunState state)
        {
            var interval = TimeSpan.FromSeconds(6).Ticks;

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinitionTestObjectBuilder().Build()
            };

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.NotSet)
                                                                                   .Build();

            testObjects.FxCurveDefinitions.OnNext(fxCurveDefinitions);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ACT
            testObjects.RunState.OnNext(state);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.FxGridRefreshService).Verify(o =>
                o.BuildFxPriceGrid(It.Is<List<FxCurveDefinition>>(curves => curves.Count == 1), It.IsAny<IDispatcherExecutionService>()));
        }

        [Test]
        public void ShouldBuildFxPriceGrid_ExactlyOnce_When_PricesConnected_And_FxCurveDefinitionsReLoaded()
        {
            var interval = TimeSpan.FromSeconds(6).Ticks;

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinitionTestObjectBuilder().Build()
            };

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.NotSet)
                                                                                   .Build();

            testObjects.FxCurveDefinitions.OnNext(fxCurveDefinitions);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ACT
            testObjects.FxCurveDefinitions.OnNext(fxCurveDefinitions);
            testObjects.RunState.OnNext(HubConnectionRunState.Connected);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.FxGridRefreshService)
                .Verify(o => o.BuildFxPriceGrid(It.Is<List<FxCurveDefinition>>(curves => curves.Count == 1), 
                                                It.IsAny<IDispatcherExecutionService>()), Times.Once);
        }

        [Test]
        public void ShouldPopulateGrid_WhenFxGridInitialized()
        {
            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinitionTestObjectBuilder().Build()
            };

            var columnInfos = new List<FxColumnInfo>
            {
                new(FxColumnType.Price, string.Empty)
            };

            var grid = new List<FxPriceRowViewModel>
            {
                new(new MonthlyTenor(2020, 7))
            };

            var fxPriceGridArgs = new FxPriceGridArgs(columnInfos, grid);

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                   .WithFxCurveDefinitions(fxCurveDefinitions)
                                                                                   .Build();
            // ACT
            testObjects.FxGridInitialized.OnNext(fxPriceGridArgs);

            // ASSERT
            Assert.That(testObjects.ViewModel.ColumnInfos.Count, Is.EqualTo(1));
            Assert.That(testObjects.ViewModel.FxPriceRows.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldCloseProgress_And_StartDispatcher_WhenFxGridInitialized()
        {
            var fxCurveDefinitions = new List<FxCurveDefinition>();

            var columnInfos = new List<FxColumnInfo>();
            var grid = new List<FxPriceRowViewModel>();

            var fxPriceGridArgs = new FxPriceGridArgs(columnInfos, grid);

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                   .WithFxCurveDefinitions(fxCurveDefinitions)
                                                                                   .Build();
            // ACT
            testObjects.FxGridInitialized.OnNext(fxPriceGridArgs);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);

            Mock.Get(testObjects.DispatcherExecutionService)
                .Verify(d => d.Start());
        }

        [Test]
        public void ShouldCloseProgress_BuildGridThrowsException()
        {
            var interval = TimeSpan.FromSeconds(6).Ticks;

            var fxCurveDefinitions = new List<FxCurveDefinition>();

            var exception = new Exception();

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                   .WithBuildGridException(exception)
                                                                                   .Build();
            // ACT
            testObjects.FxCurveDefinitions.OnNext(fxCurveDefinitions);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
        }

        [Test]
        public void ShouldNotBuildFxPriceGrid_When_Disposed()
        {
            var interval = TimeSpan.FromSeconds(6).Ticks;

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinitionTestObjectBuilder().Build()
            };

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                   .Build();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.FxCurveDefinitions.OnNext(fxCurveDefinitions);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.FxGridRefreshService)
                .Verify(o => o.BuildFxPriceGrid(It.IsAny<List<FxCurveDefinition>>(),
                                                It.IsAny<IDispatcherExecutionService>()), Times.Never);
        }


        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var interval = TimeSpan.FromSeconds(6).Ticks;

            var fxCurveDefinitions = new List<FxCurveDefinition>
            {
                new FxCurveDefinitionTestObjectBuilder().Build()
            };

            var testObjects = new FxPriceGridViewModelControllerTestObjectBuilder().WithRunState(HubConnectionRunState.Connected)
                                                                                   .Build();
            testObjects.Controller.Dispose();
            testObjects.Controller.Dispose();

            // ACT
            testObjects.FxCurveDefinitions.OnNext(fxCurveDefinitions);
            testObjects.TestScheduler.AdvanceBy(interval);

            // ASSERT
            Mock.Get(testObjects.FxGridRefreshService)
                .Verify(o => o.BuildFxPriceGrid(It.IsAny<List<FxCurveDefinition>>(),
                                                It.IsAny<IDispatcherExecutionService>()), Times.Never);
        }
    }
}
