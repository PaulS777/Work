﻿using System;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.AdminActions;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Services;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Services
{
	internal interface ICurveDeletionServiceTestObjects
	{
		ICurveWorkflowActionService ActionService { get; }
		IObservable<AdminApiActionCompleted> ActionServiceResponse { get; }
		IScheduler Scheduler { get; }
		CurveDeletionService CurveDeletionService { get; }
	}

	[TestFixture]
	public class CurveDeletionServiceTests
	{
		private class CurveDeletionServiceTestObjectBuilder
		{
			public ICurveDeletionServiceTestObjects Build()
			{
				var testObjects = new Mock<ICurveDeletionServiceTestObjects>();

				var scheduler = new Mock<IScheduler>();

				testObjects.SetupGet(o => o.Scheduler)
						   .Returns(scheduler.Object);

				var actionServiceResponse = new Subject<AdminApiActionCompleted>();

				testObjects.SetupGet(o => o.ActionServiceResponse)
						   .Returns(actionServiceResponse);

				var actionService = new Mock<ICurveWorkflowActionService>();

				actionService.Setup(a => a.Update(It.IsAny<CurveWorkflowAction>(),
												  It.IsAny<IScheduler>()))
							 .Returns(actionServiceResponse);

				testObjects.SetupGet(o => o.ActionService)
						   .Returns(actionService.Object);

				var curveDeletionService = new CurveDeletionService(actionService.Object);

				testObjects.SetupGet(o => o.CurveDeletionService)
						   .Returns(curveDeletionService);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldInvokeActionService_When_Delete()
		{
			var testObjects = new CurveDeletionServiceTestObjectBuilder().Build();

			// ACT
			var response = testObjects.CurveDeletionService.DeleteCurve(101, AdminCurveType.Manual, testObjects.Scheduler);

			// ASSERT
			Mock.Get(testObjects.ActionService)
				.Verify(a => a.Update(It.Is<CurveWorkflowAction>(i => i.WorkflowOperationType == WorkflowOperationType.Delete
																	  && i.AdminCurveType == AdminCurveType.Manual
																	  && i.CurveDefinitionId == 101),
									  testObjects.Scheduler));

			Assert.That(response, Is.SameAs(testObjects.ActionServiceResponse));
		}

		[Test]
		public void ShouldInvokeActionService_When_Cancel()
		{
			var testObjects = new CurveDeletionServiceTestObjectBuilder().Build();

			// ACT
			var response = testObjects.CurveDeletionService.CancelCurve(101, AdminCurveType.Manual, testObjects.Scheduler);

			// ASSERT
			Mock.Get(testObjects.ActionService)
				.Verify(a => a.Update(It.Is<CurveWorkflowAction>(i => i.WorkflowOperationType == WorkflowOperationType.Cancel
																   && i.AdminCurveType == AdminCurveType.Manual
																   && i.CurveDefinitionId == 101),
									  testObjects.Scheduler));

			Assert.That(response, Is.SameAs(testObjects.ActionServiceResponse));
		}
	}
}
