﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Services.Validation
{
    [TestFixture]
    public class PropertyValidationServiceTests
    {
        [Test]
        public void ShouldInvokeRules_When_Validate_With_MatchingPropertyName()
        {
            var rule1 = new Mock<IValidationRule>();

            rule1.Setup(r => r.Validate(It.IsAny<object>()))
                 .Returns(ValidationResult.ValidResult);

            var rule2 = new Mock<IValidationRule>();

            var rules = new Dictionary<string, IList<IValidationRule>>
                        {
                            { "prop1", [rule1.Object] },
                            { "prop2", [rule2.Object] }
                        };

            var propertyValidationService = new PropertyValidationService();

            propertyValidationService.InitializeRules(rules);

            // ACT
            propertyValidationService.Validate("prop1", "value");

            // ASSERT
            rule1.Verify(r => r.Validate("value"), Times.Once);
            rule2.Verify(r => r.Validate(It.IsAny<object>()), Times.Never);
        }

        [Test]
        public void ShouldReturnErrors_When_Validate_With_RulesIsValidFalse()
        {
            var rule1 = new Mock<IValidationRule>();

            rule1.Setup(r => r.Validate(It.IsAny<object>()))
                 .Returns(ValidationResult.ValidResult);

            var rule2 = new Mock<IValidationRule>();

            rule2.Setup(r => r.Validate(It.IsAny<object>()))
                 .Returns(new ValidationResult(false, "error"));

            var rules = new Dictionary<string, IList<IValidationRule>>
                        {
                            { "prop", [rule1.Object, rule2.Object] }
                        };

            var propertyValidationService = new PropertyValidationService();

            propertyValidationService.InitializeRules(rules);

            var expected = new[] { "error" };

            // ACT
            var result = propertyValidationService.Validate("prop", "value");

            // ASSERT
            Assert.That(result.SequenceEqual(expected));
        }

        [Test]
        public void ShouldThrowInvalidOperationException_When_Validate_With_MissingRule()
        {
            var rule1 = new Mock<IValidationRule>();

            var rules = new Dictionary<string, IList<IValidationRule>>
                        {
                            { "prop1", [rule1.Object] }
                        };

            var propertyValidationService = new PropertyValidationService();

            propertyValidationService.InitializeRules(rules);

            InvalidOperationException result = null;

            try
            {
                // ACT
                propertyValidationService.Validate("prop2", "value");
            }
            catch (InvalidOperationException ex)
            {
                result = ex;
            }

            // ASSERT
            Assert.That(result, Is.Not.Null);
        }
    }
}
