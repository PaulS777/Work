﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Services.Validation
{
    internal interface IValidationServiceTestObjects
    {
        IPropertyValidationService PropertyValidationService { get; }
		ISubject<ValidationProperty> ValidationProperties { get; }
        DialogViewModelBase ViewModel { get; }
        ValidationService<DialogViewModelBase> ValidationService { get; }
	}

	[TestFixture]
	public class ValidationServiceTests
	{
        private class ValidationServiceTestObjectBuilder
        {
            private Dictionary<string, IList<IValidationRule>> _validationRules;
            private IList<string> _validationErrors;
            private readonly Dictionary<string, IList<string>> _viewModelErrors = new();
            private Exception _validationException;

            public ValidationServiceTestObjectBuilder WithValidationRules(Dictionary<string, IList<IValidationRule>> values)
            {
                _validationRules = values;
                return this;
            }

            public ValidationServiceTestObjectBuilder WithValidationErrors(IList<string> values)
            {
                _validationErrors = values;
                return this;
            }

			public ValidationServiceTestObjectBuilder WithViewModelErrors(string propertyName, IList<string> errors)
            {
                _viewModelErrors.Add(propertyName, errors);
                return this;
            }

            public ValidationServiceTestObjectBuilder WithValidationException(Exception value)
            {
                _validationException = value;
                return this;
            }

			public IValidationServiceTestObjects Build()
            {
                var testObjects = new Mock<IValidationServiceTestObjects>();

                var ruleProvider = new Mock<IRuleProvider<DialogViewModelBase>>();

                ruleProvider.SetupGet(p => p.ValidationRules)
                            .Returns(_validationRules);

                var validationProperties = new Subject<ValidationProperty>();

                testObjects.SetupGet(o => o.ValidationProperties)
                           .Returns(validationProperties);

                var propertyObserver = new Mock<IValidationPropertyObserver<DialogViewModelBase>>();

                propertyObserver.Setup(p => p.ObserveValidationProperties(It.IsAny<DialogViewModelBase>()))
                                .Returns(validationProperties);

                var propertyValidationService = new Mock<IPropertyValidationService>();

                if (_validationException == null)
                {
                    propertyValidationService.Setup(v => v.Validate(It.IsAny<string>(), It.IsAny<object>()))
                                             .Returns(_validationErrors);
                }
                else
                {
                    propertyValidationService.Setup(v => v.Validate(It.IsAny<string>(), It.IsAny<object>()))
                                             .Throws(_validationException);
                }

                testObjects.SetupGet(o => o.PropertyValidationService)
                           .Returns(propertyValidationService.Object);

                var viewModel = new DialogViewModelBase();

                if (_viewModelErrors != null)
                {
                    foreach (var kvp in _viewModelErrors)
                    {
                        viewModel.Errors.Add(kvp.Key, kvp.Value);
                    }
				}

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(viewModel);

                var validationService = new ValidationService<DialogViewModelBase>(ruleProvider.Object,
                                                                                   propertyObserver.Object,
                                                                                   propertyValidationService.Object);

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(validationService);

                return testObjects.Object;
            }
		}

        [Test]
        public void ShouldInitializePropertyValidationService_With_Rules()
        {
            var rules = new Dictionary<string, IList<IValidationRule>>();

            var testObjects = new ValidationServiceTestObjectBuilder().WithValidationRules(rules)
                                                                      .Build();

            // ASSERT
            Mock.Get(testObjects.PropertyValidationService)
                .Verify(p => p.InitializeRules(rules));
        }

        [Test]
        public void ShouldValidate_On_ValidationProperty()
        {
            var rules = new Dictionary<string, IList<IValidationRule>>();

            var testObjects = new ValidationServiceTestObjectBuilder().WithValidationRules(rules)
                                                                      .Build();

            var validation = testObjects.ValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => {}))
            {
                // ACT
                testObjects.ValidationProperties.OnNext(new ValidationProperty("property", "value"));

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(v => v.Validate("property", "value"));
            }
        }

        [Test]
        public void ShouldUpdateErrors_And_PublishPropertyName_On_ValidationProperty_With_Errors()
        {
            var errors = new[] { "error" };

            var testObjects = new ValidationServiceTestObjectBuilder().WithValidationErrors(errors)
                                                                      .Build();

            var validation = testObjects.ValidationService.ObserveValidation(testObjects.ViewModel);

            //string result = null;
            var result = false;

			using (validation.Subscribe(_ => result = true))
            {
                // ACT
                testObjects.ValidationProperties.OnNext(new ValidationProperty("property", "value"));

                // ASSERT
                Assert.That(testObjects.ViewModel.Errors["property"].SequenceEqual(errors));
                Assert.That(result, Is.True);
            }
		}

        [Test]
        public void ShouldInvokeErrorsChanges_On_ValidationProperty_With_Errors()
        {
            var errors = new[] { "error" };

            var testObjects = new ValidationServiceTestObjectBuilder().WithValidationErrors(errors)
                                                                      .Build();

            var validation = testObjects.ValidationService.ObserveValidation(testObjects.ViewModel);

            string result = null;
            
            testObjects.ViewModel.ErrorsChanged += (_, args) => { result = args.PropertyName; };

			using (validation.Subscribe(_ => {}))
            {
                // ACT
                testObjects.ValidationProperties.OnNext(new ValidationProperty("property", "value"));

				// ASSERT
				Assert.That(result, Is.EqualTo("property"));
			}
		}

		[Test]
        public void ShouldClearErrors_And_PublishPropertyName_On_ValidationProperty_With_NoErrors()
        {
            var testObjects = new ValidationServiceTestObjectBuilder().WithViewModelErrors("property", ["error"])
                                                                      .WithValidationErrors([])
                                                                      .Build();

            var validation = testObjects.ValidationService.ObserveValidation(testObjects.ViewModel);

            var result = false;

            using (validation.Subscribe(_ => result = true))
            {
                // ACT
                testObjects.ValidationProperties.OnNext(new ValidationProperty("property", "value"));

                // ASSERT
                Assert.That(testObjects.ViewModel.Errors, Is.Empty);
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldInvokeErrorsChanges_On_ValidationProperty_With_NoErrors()
        {
            var testObjects = new ValidationServiceTestObjectBuilder().WithValidationErrors([])
                                                                      .Build();

            var validation = testObjects.ValidationService.ObserveValidation(testObjects.ViewModel);

            string result = null;

            testObjects.ViewModel.ErrorsChanged += (_, args) => { result = args.PropertyName; };

            using (validation.Subscribe(_ => {}))
            {
                // ACT
                testObjects.ValidationProperties.OnNext(new ValidationProperty("property", "value"));

                // ASSERT
                Assert.That(result, Is.EqualTo("property"));
            }
        }

		[Test]
        public void ShouldPublishError_On_NameChanged_With_ValidationException()
        {
            var testObjects = new ValidationServiceTestObjectBuilder().WithValidationException(new Exception())
                                                                      .Build();

            var validation = testObjects.ValidationService.ObserveValidation(testObjects.ViewModel);

            Exception error = null;

            using (validation.Subscribe(_ => { }, ex => error = ex))
            {
				// ACT
				testObjects.ValidationProperties.OnNext(new ValidationProperty("property", "value"));

				// ASSERT
				Assert.That(error, Is.Not.Null);
            }
        }

		[Test]
        public void ShouldNotValidate_On_ValidationProperty_With_RequiresValidationFalse()
        {
            var testObjects = new ValidationServiceTestObjectBuilder().WithViewModelErrors("property", ["error"])
                                                                      .WithValidationErrors([])
                                                                      .Build();

            var validation = testObjects.ValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => {}))
            {
                // ACT
                testObjects.ValidationProperties.OnNext(new ValidationProperty("property"));

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
                    .Verify(v => v.Validate(It.IsAny<string>(), It.IsAny<object>()), Times.Never);
			}
        }

        [Test]
        public void ShouldClearValidationErrors()
        {
            var testObjects = new ValidationServiceTestObjectBuilder().WithViewModelErrors("property", ["error"])
                                                                      .Build();

            string result = null;

            testObjects.ViewModel.ErrorsChanged += (_, args) => { result = args.PropertyName; };

            // ACT
            testObjects.ValidationService.ClearErrors(testObjects.ViewModel);

            // ASSERT
            Assert.That(testObjects.ViewModel.Errors, Is.Empty);
            Assert.That(result, Is.EqualTo("property"));
		}
	}
}
