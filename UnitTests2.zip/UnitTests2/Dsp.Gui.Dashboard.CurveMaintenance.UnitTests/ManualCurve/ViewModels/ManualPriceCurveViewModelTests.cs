﻿using System.Linq;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.ViewModels
{
    [TestFixture]
    public class ManualPriceCurveViewModelTests
    {
        [Test]
        public void ShouldReturnPropertyErrors_When_GetErrorsWithPropertyName()
        {
            var errors = new[] { "error" };
            var otherErrors = new[] { "other" };

            var viewModel = new ManualPriceCurveViewModel();

            // ARRANGE
            viewModel.Errors.Add("prop1", errors);
            viewModel.Errors.Add("prop2", otherErrors);

            // ACT
            var result = viewModel.GetErrors("prop1").Cast<string>();

            // ASSERT
            Assert.That(result.SequenceEqual(errors));
        }

        [Test]
        public void ShouldReturnAllErrors_When_GetErrorsWithEmptyString()
        {
            var errors = new[] { "error" };
            var otherErrors = new[] { "other" };

            var viewModel = new ManualPriceCurveViewModel();

            // ARRANGE
            viewModel.Errors.Add("prop1", errors);
            viewModel.Errors.Add("prop2", otherErrors);

            var expected = new[] { "error", "other" };

            // ACT
            var result = viewModel.GetErrors(string.Empty).Cast<string>();

            // ASSERT
            Assert.That(result.SequenceEqual(expected));
        }

        [Test]
        public void ShouldReturnEmpty_When_GetErrorsWithNoErrors()
        {
            var viewModel = new ManualPriceCurveViewModel();

            // ACT
            var result = viewModel.GetErrors(string.Empty).Cast<string>();

            // ASSERT
            Assert.That(result, Is.Empty);
        }

        [Test]
        public void ShouldReturnTrue_When_HasErrors_WithErrors()
        {
            var errors = new[] { "error" };
            var otherErrors = new[] { "other" };

            var viewModel = new ManualPriceCurveViewModel();

            // ARRANGE
            viewModel.Errors.Add("prop1", errors);
            viewModel.Errors.Add("prop2", otherErrors);

            // ACT
            var result = viewModel.HasErrors;

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_HasErrors_WithNoErrors()
        {
            var viewModel = new ManualPriceCurveViewModel();

            // ACT
            var result = viewModel.HasErrors;

            // ASSERT
            Assert.That(result, Is.False);
        }
    }
}
