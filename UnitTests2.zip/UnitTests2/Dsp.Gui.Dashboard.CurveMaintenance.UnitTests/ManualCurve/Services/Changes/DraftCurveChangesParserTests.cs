﻿using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes;
using CurrencyCode = Dsp.DataContracts.CurrencyCode;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Changes
{
    internal interface IDraftCurveChangesParserTestObjects
    {
        DraftCurveChangesParser DraftCurveChangesParser { get; }
    }

    [TestFixture]
    public class DraftCurveChangesParserTests
    {
        private class DraftCurveChangesParserTestObjectBuilder
        {
            private IEnumerable<CurrencyCode> _currencyCodes;

            public DraftCurveChangesParserTestObjectBuilder WithCurrencyCodes(IEnumerable<CurrencyCode> values)
            {
                _currencyCodes = values;
                return this;
            }

            public IDraftCurveChangesParserTestObjects Build()
            {
                var testObjects = new Mock<IDraftCurveChangesParserTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.Setup(c => c.GetCurrencyCodesSnapshot())
                                   .Returns(_currencyCodes);

                var draftCurveChangesParser = new DraftCurveChangesParser(curveControlService.Object);

                testObjects.SetupGet(o => o.DraftCurveChangesParser)
                           .Returns(draftCurveChangesParser);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldRetainValue_When_Parse_With_DraftChange_NonSpecial()
        {
            var key = nameof(ManualPriceCurveViewModel.MaxPeriodCount);

            var draftChanges = new Dictionary<string, object>
                               {
                                   { key, 24 }
                               };

            var testObjects = new DraftCurveChangesParserTestObjectBuilder().Build();

            // ACT
            testObjects.DraftCurveChangesParser.ParseChanges(draftChanges);

            // ASSERT
            Assert.That(draftChanges[key], Is.EqualTo(24));
        }

        [Test]
        public void ShouldUpdateValue_When_Parse_With_DraftChangeCurrencyCode()
        {
            var currencyCodes = new[]
                                {
                                    new CurrencyCode(1, "EUR"),
                                    new CurrencyCode(2, "USD")
                                };

            var key = nameof(ManualPriceCurveViewModel.OverrideCurrencyCode);

            var draftChanges = new Dictionary<string, object>
                               {
                                   { key, 2 }
                               };

            var testObjects = new DraftCurveChangesParserTestObjectBuilder().WithCurrencyCodes(currencyCodes)
                                                                            .Build();

            // ACT
            testObjects.DraftCurveChangesParser.ParseChanges(draftChanges);

            // ASSERT
            Assert.That(draftChanges[key], Is.EqualTo("USD"));
        }

        [Test]
        public void ShouldUpdateValue_When_Parse_With_DraftChangeProduct()
        {
            var key = nameof(ManualPriceCurveViewModel.ProductDefinition);

            var product = new ProductDefinitionTestObjectBuilder().WithName("product").Build();

            var draftChanges = new Dictionary<string, object>
                               {
                                   { key, product }
                               };

            var testObjects = new DraftCurveChangesParserTestObjectBuilder().Build();

            // ACT
            testObjects.DraftCurveChangesParser.ParseChanges(draftChanges);

            // ASSERT
            Assert.That(draftChanges[key], Is.EqualTo("product"));
        }

        [Test]
        public void ShouldUpdateValue_When_Parse_With_DraftChangeOverrideDensityUnitOfVolume()
        {
            var key = nameof(ManualPriceCurveViewModel.OverrideDensityUnitOfVolume);

            var density = new Density(UnitOfMeasure.BBL, 1.0d);

            var draftChanges = new Dictionary<string, object>
                               {
                                   { key, density }
                               };

            var testObjects = new DraftCurveChangesParserTestObjectBuilder().Build();

            // ACT
            testObjects.DraftCurveChangesParser.ParseChanges(draftChanges);

            // ASSERT
            Assert.That(draftChanges[key], Is.EqualTo(UnitOfMeasure.BBL));
        }

        [Test]
        public void ShouldUpdateValue_When_Parse_With_DraftChangeOverrideDensityFactor()
        {
            var key = nameof(ManualPriceCurveViewModel.OverrideDensityFactor);

            var density = new Density(UnitOfMeasure.BBL, 1.0d);

            var draftChanges = new Dictionary<string, object>
                               {
                                   { key, density }
                               };

            var testObjects = new DraftCurveChangesParserTestObjectBuilder().Build();

            // ACT
            testObjects.DraftCurveChangesParser.ParseChanges(draftChanges);

            // ASSERT
            Assert.That(draftChanges[key], Is.EqualTo(1.0d));
        }

        [Test]
        public void ShouldUpdateValueNonSet_When_Parse_With_DraftChangeNullValue()
        {
            var key = nameof(ManualPriceCurveViewModel.OverrideLotSize);

            var draftChanges = new Dictionary<string, object>
                               {
                                   { key, null }
                               };

            var testObjects = new DraftCurveChangesParserTestObjectBuilder().Build();

            // ACT
            testObjects.DraftCurveChangesParser.ParseChanges(draftChanges);

            // ASSERT
            Assert.That(draftChanges[key], Is.EqualTo("<Not Set>"));
        }

		[TestCase(nameof(ManualPriceCurveViewModel.OverrideCurrencyCode), "value")]
		[TestCase(nameof(ManualPriceCurveViewModel.ProductDefinition), "value")]
		[TestCase(nameof(ManualPriceCurveViewModel.OverrideDensityUnitOfVolume), "value")]
		[TestCase(nameof(ManualPriceCurveViewModel.OverrideDensityFactor), "value")]
		public void ShouldNotUpdateValue_When_Parse_With_Value_UnexpectedType(string key, object value)
		{
			var draftChanges = new Dictionary<string, object>
							   {
								   { key, value }
							   };

			var testObjects = new DraftCurveChangesParserTestObjectBuilder().Build();

			// ACT
			testObjects.DraftCurveChangesParser.ParseChanges(draftChanges);

			// ASSERT
			Assert.That(draftChanges[key], Is.EqualTo(value));
		}
    }
}
