﻿using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Changes
{
    [TestFixture]
    public class ManualPriceCurveComparersTests
    {
        #region CurveType

        [Test]
        public void ShouldReturnTrue_When_Compare_With_CurveTypesEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithCurveType(CurveType.Spread).Build();
            var viewModel = new ManualPriceCurveViewModel { CurveType = CurveType.Spread };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.CurveType)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_CurveTypesNotEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithCurveType(CurveType.Spread).Build();
            var viewModel = new ManualPriceCurveViewModel { CurveType = CurveType.Crack };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.CurveType)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnCurveType_When_GetCurveValue_With_CurveType()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithCurveType(CurveType.Spread).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.CurveType)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(CurveType.Spread));
        }

        #endregion

        #region ProductDefinition

        [Test]
        public void ShouldReturnTrue_When_Compare_With_ProductDefinitionsEqual()
        {
            var product = new ProductDefinitionTestObjectBuilder().WithId(1).Build();

			var item = new ProductDefinitionItem(product);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithProductDefinition(product).Build();
            var viewModel = new ManualPriceCurveViewModel { ProductDefinition = item };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.ProductDefinition)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_ProductDefinitionsNotEqual()
        {
            var product1 = new ProductDefinitionTestObjectBuilder().WithId(1).Build();
            var product2 = new ProductDefinitionTestObjectBuilder().WithId(2).Build();

			var item2 = new ProductDefinitionItem(product2);

			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithProductDefinition(product1).Build();

            var viewModel = new ManualPriceCurveViewModel { ProductDefinition = item2 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.ProductDefinition)];

            // ACT
            var result = comparer.Compare(viewModel, priceCurveDefinition);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnProduct_When_GetCurveValue_With_Product()
        {
            var product = new ProductDefinitionTestObjectBuilder().WithId(1).Build();

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithProductDefinition(product).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.ProductDefinition)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.SameAs(product));
        }

        #endregion

        #region CurveRegion

        [Test]
        public void ShouldReturnTrue_When_Compare_With_CurveRegionsEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithCurveRegion(CurveRegion.Europe).Build();
            var viewModel = new ManualPriceCurveViewModel { CurveRegion = CurveRegion.Europe };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.CurveRegion)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_CurveRegionsNotEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithCurveRegion(CurveRegion.Europe).Build();
            var viewModel = new ManualPriceCurveViewModel { CurveRegion = CurveRegion.Asia };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.CurveRegion)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnCurveRegion_When_GetCurveValue_With_CurveRegion()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithCurveRegion(CurveRegion.Europe).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.CurveRegion)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(CurveRegion.Europe));
        }

        #endregion

        #region MaxPeriodCount

        [Test]
        public void ShouldReturnTrue_When_Compare_With_MaxPeriodCountsEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithMaxPeriodCount(12).Build();
            var viewModel = new ManualPriceCurveViewModel { MaxPeriodCount = 12 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.MaxPeriodCount)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_MaxPeriodCountsNotEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithMaxPeriodCount(12).Build();
            var viewModel = new ManualPriceCurveViewModel { MaxPeriodCount = 24 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.MaxPeriodCount)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnMaxPeriodCount_When_GetCurveValue_With_MaxPeriodCount()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithMaxPeriodCount(12).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.MaxPeriodCount)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(12));
        }

        #endregion

        #region DsxUnitOfMeasure

        [Test]
        public void ShouldReturnTrue_When_Compare_With_DsxUnitOfMeasuresEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithDsxUnitOfMeasure(UnitOfMeasure.BBL).Build();
            var viewModel = new ManualPriceCurveViewModel { DsxUnitOfMeasure = UnitOfMeasure.BBL };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.DsxUnitOfMeasure)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_DsxUnitOfMeasuresNotEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithDsxUnitOfMeasure(UnitOfMeasure.BBL).Build();
            var viewModel = new ManualPriceCurveViewModel { DsxUnitOfMeasure = UnitOfMeasure.GAL };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.DsxUnitOfMeasure)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnDsxUnitOfMeasure_When_GetCurveValue_With_DsxUnitOfMeasure()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithDsxUnitOfMeasure(UnitOfMeasure.BBL).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.DsxUnitOfMeasure)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(UnitOfMeasure.BBL));
        }

        #endregion

        #region IncludePremiums

        [Test]
        public void ShouldReturnTrue_When_Compare_With_IncludePremiumsEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithExcludePremiums(false).Build();
            var viewModel = new ManualPriceCurveViewModel { IncludePremiums = true };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.IncludePremiums)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_IncludePremiumsNotEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithExcludePremiums(true).Build();
            var viewModel = new ManualPriceCurveViewModel { IncludePremiums = true };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.IncludePremiums)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnIncludePremiums_When_GetCurveValue_With_IncludePremiums()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithExcludePremiums(false).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.IncludePremiums)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(false));
        }

        #endregion

        #region DsxLotSize

        [Test]
        public void ShouldReturnTrue_When_Compare_With_DsxLotSizesEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithDsxLotSize(100).Build();
            var viewModel = new ManualPriceCurveViewModel { DsxLotSize = 100 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.DsxLotSize)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_DsxLotSizesNotEqual()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithDsxLotSize(100).Build();
            var viewModel = new ManualPriceCurveViewModel { DsxLotSize = 200 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.DsxLotSize)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnDsxLotSize_When_GetCurveValue_With_DsxLotSize()
        {
            var curve = new PriceCurveDefinitionTestObjectBuilder().WithDsxLotSize(100).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.DsxLotSize)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(100));
        }

        #endregion

        #region OverrideUnitOfMeasure

        [Test]
        public void ShouldReturnTrue_When_Compare_With_OverrideUnitOfMeasuresEqual()
        {
            var overrides = new PriceCurveDefinitionOverride(UnitOfMeasure.BBL);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideUnitOfMeasure = UnitOfMeasure.BBL };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideUnitOfMeasure)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_OverrideUnitOfMeasuresNotEqual()
        {
            var overrides = new PriceCurveDefinitionOverride(UnitOfMeasure.BBL);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideUnitOfMeasure = UnitOfMeasure.GAL };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideUnitOfMeasure)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnOverrideUnitOfMeasure_When_GetCurveValue_With_OverrideUnitOfMeasure()
        {
            var overrides = new PriceCurveDefinitionOverride(UnitOfMeasure.BBL);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideUnitOfMeasure)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(UnitOfMeasure.BBL));
        }

        #endregion

        #region OverrideLotSize

        [Test]
        public void ShouldReturnTrue_When_Compare_With_OverrideLotSizesEqual()
        {
            var overrides = new PriceCurveDefinitionOverride(null, null, null, 100);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideLotSize = 100 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideLotSize)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_OverrideLotSizesNotEqual()
        {
            var overrides = new PriceCurveDefinitionOverride(null, null, null, 100);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideLotSize = 200 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideLotSize)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnOverrideLotSize_When_GetCurveValue_With_OverrideLotSize()
        {
            var overrides = new PriceCurveDefinitionOverride(null, null, null, 100);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideLotSize)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(100));
        }

        #endregion

        #region OverrideCurrencyCode

        [Test]
        public void ShouldReturnTrue_When_Compare_With_OverrideCurrencyCodesEqual()
        {
			var ccy1 = new CurrencyCode(1, "EUR");
			var ccyItem1 = new CurrencyCodeItem(ccy1);

			var overrides = new PriceCurveDefinitionOverride(null, null, null, null, ccy1.Id);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideCurrencyCode = ccyItem1 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideCurrencyCode)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_OverrideCurrencyCodesNotEqual()
        {
			var ccy1 = new CurrencyCode(1, "EUR");
			var ccy2 = new CurrencyCode(2, "USD");

			var ccyItem2 = new CurrencyCodeItem(ccy2);

			var overrides = new PriceCurveDefinitionOverride(null, null, null, null, ccy1.Id);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();

            var viewModel = new ManualPriceCurveViewModel { OverrideCurrencyCode = ccyItem2 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideCurrencyCode)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnOverrideCurrencyCode_When_GetCurveValue_With_OverrideCurrencyCode()
        {
            var currencyCode = new CurrencyCode(1, "EUR");

            var overrides = new PriceCurveDefinitionOverride(null, null, null, null, currencyCode.Id);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideCurrencyCode)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(1));
        }

        #endregion

        #region OverrideCurrencyDenominationFactor

        [Test]
        public void ShouldReturnTrue_When_Compare_With_OverrideCurrencyDenominationFactorsEqual()
        {
            var overrides = new PriceCurveDefinitionOverride(null, null, 2);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideCurrencyDenominationFactor = 2 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideCurrencyDenominationFactor)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_OverrideCurrencyDenominationFactorsNotEqual()
        {
            var overrides = new PriceCurveDefinitionOverride(null, null, 2);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideCurrencyDenominationFactor = 0 };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideCurrencyDenominationFactor)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnOverrideCurrencyDenominationFactor_When_GetCurveValue_With_OverrideCurrencyDenominationFactor()
        {
            var overrides = new PriceCurveDefinitionOverride(null, null, 2);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideCurrencyDenominationFactor)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.EqualTo(2));
        }

        #endregion

        #region OverrideDensityUnitOfVolume

        [Test]
        public void ShouldReturnTrue_When_Compare_With_OverrideDensityUnitOfVolumesEqual()
        {
            var density = new Density(UnitOfMeasure.BBL, 1.0d);
            var overrides = new PriceCurveDefinitionOverride(null, density);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideDensityUnitOfVolume = UnitOfMeasure.BBL };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideDensityUnitOfVolume)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_OverrideDensityUnitOfVolumesNotEqual()
        {
            var density = new Density(UnitOfMeasure.BBL, 1.0d);
            var overrides = new PriceCurveDefinitionOverride(null, density);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideDensityUnitOfVolume = UnitOfMeasure.GAL };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideDensityUnitOfVolume)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnOverrideDensityUnitOfVolume_When_GetCurveValue_With_OverrideDensityUnitOfVolume()
        {
            var density = new Density(UnitOfMeasure.BBL, 1.0d);
            var overrides = new PriceCurveDefinitionOverride(null, density);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideDensityUnitOfVolume)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.SameAs(density));
        }

        #endregion

        #region OverrideDensityFactor

        [Test]
        public void ShouldReturnTrue_When_Compare_With_OverrideDensityFactorsEqual()
        {
            var density = new Density(UnitOfMeasure.BBL, 1.0d);
            var overrides = new PriceCurveDefinitionOverride(null, density);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideDensityFactor = 1.0d };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideDensityFactor)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Compare_With_OverrideDensityFactorsNotEqual()
        {
            var density = new Density(UnitOfMeasure.BBL, 1.0d);
            var overrides = new PriceCurveDefinitionOverride(null, density);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();
            var viewModel = new ManualPriceCurveViewModel { OverrideDensityFactor = 2.0d };

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideDensityFactor)];

            // ACT
            var result = comparer.Compare(viewModel, curve);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnOverrideDensityFactor_When_GetCurveValue_With_OverrideDensityFactor()
        {
            var density = new Density(UnitOfMeasure.BBL, 1.0d);
            var overrides = new PriceCurveDefinitionOverride(null, density);

            var curve = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides).Build();

            var comparers = new ManualPriceCurveComparers();

            var comparer = comparers.Comparers[nameof(ManualPriceCurveViewModel.OverrideDensityFactor)];

            // ACT
            var result = comparer.GetValue(curve);

            // ASSERT
            Assert.That(result, Is.SameAs(density));
        }

        #endregion
    }
}
