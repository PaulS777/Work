﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using ICurveChangedObserverComparers = Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes.ICurveChangedObserverComparers;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Changes
{
	[TestFixture]
	public class ManualPriceCurveEditChangesServiceTests
	{
		internal interface IManualPriceCurveEditChangesTestObjects
		{
			PriceCurveDefinition PriceCurveDefinition { get; }
			IList<string> EditChanges { get; }
			ManualPriceCurveViewModel ViewModel { get; }
			ManualPriceCurveEditChangesService ManualPriceCurveEditChangesService { get; }
		}

		private class ManualPriceCurveEditChangesTestObjectBuilder
		{
			private IList<string> _editChanges = new List<string>();
			private bool _maxPeriodCountComparerResult;
			private bool _dsxLotSizeComparerResult;

			public ManualPriceCurveEditChangesTestObjectBuilder WithEditChanges(IList<string> value)
			{
				_editChanges = value;
				return this;
			}

			public ManualPriceCurveEditChangesTestObjectBuilder WithMaxPeriodCountComparerResult(bool value)
			{
				_maxPeriodCountComparerResult = value;
				return this;
			}

			public ManualPriceCurveEditChangesTestObjectBuilder WithDsxLotSizeComparerResult(bool value)
			{
				_dsxLotSizeComparerResult = value;
				return this;
			}

			public IManualPriceCurveEditChangesTestObjects Build()
			{
				var testObjects = new Mock<IManualPriceCurveEditChangesTestObjects>();

				var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

				testObjects.SetupGet(o => o.PriceCurveDefinition)
						   .Returns(priceCurveDefinition);

				var manualCurveDefinition = new ManualPriceCurveViewModel();

				testObjects.SetupGet(o => o.ViewModel)
						   .Returns(manualCurveDefinition);

				testObjects.SetupGet(o => o.EditChanges)
						   .Returns(_editChanges);

				var maxPeriodComparer = new Mock<IPropertyComparer>();

				maxPeriodComparer.Setup(c => c.Compare(It.IsAny<ManualPriceCurveViewModel>(), It.IsAny<PriceCurveDefinition>()))
								 .Returns(_maxPeriodCountComparerResult);

				var dsxLotSizeComparer = new Mock<IPropertyComparer>();

				dsxLotSizeComparer.Setup(c => c.Compare(It.IsAny<ManualPriceCurveViewModel>(), It.IsAny<PriceCurveDefinition>()))
								  .Returns(_dsxLotSizeComparerResult);

				var comparers = new Dictionary<string, IPropertyComparer>
								{
									{ nameof(ManualPriceCurveViewModel.MaxPeriodCount), maxPeriodComparer.Object },
									{ nameof(ManualPriceCurveViewModel.DsxLotSize), dsxLotSizeComparer.Object }
								};

				var curveComparers = new Mock<ICurveChangedObserverComparers>();

				curveComparers.SetupGet(c => c.Comparers)
							  .Returns(comparers);

				var editChangesService = new ManualPriceCurveEditChangesService(curveComparers.Object);

				testObjects.SetupGet(o => o.ManualPriceCurveEditChangesService)
						   .Returns(editChangesService);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldNotPublish_On_Subscribe_With_AnyComparerFalse()
		{
			var testObjects = new ManualPriceCurveEditChangesTestObjectBuilder().WithDsxLotSizeComparerResult(false)
																				.Build();

			var observable = testObjects.ManualPriceCurveEditChangesService.ObserveChanged(testObjects.ViewModel,
																						   testObjects.PriceCurveDefinition,
																						   testObjects.EditChanges);

			var count = 0;

			// ACT
			using (observable.Subscribe(_ => count++))
			{
				// ASSERT
				Assert.That(count, Is.EqualTo(0));
			}
		}

		[Test]
		public void ShouldAddPropertyName_And_Publish_On_Change_With_CompareFalse()
		{
			var testObjects = new ManualPriceCurveEditChangesTestObjectBuilder().WithDsxLotSizeComparerResult(false)
																				.Build();

			var observable = testObjects.ManualPriceCurveEditChangesService.ObserveChanged(testObjects.ViewModel,
																						   testObjects.PriceCurveDefinition, 
																						   testObjects.EditChanges);
			var count = 0;

			var expected = new[] { nameof(ManualPriceCurveViewModel.DsxLotSize) };

			using (observable.Subscribe(_ => count++))
			{
				// ACT
				testObjects.ViewModel.DsxLotSize = 500;

				// ASSERT
				Assert.That(count, Is.EqualTo(1));

				Assert.That(testObjects.EditChanges.SequenceEqual(expected));
			}
		}

		[Test]
		public void ShouldRemovePropertyName_And_Publish_On_Change_With_CompareTrue()
		{
			var testObjects = new ManualPriceCurveEditChangesTestObjectBuilder().WithDsxLotSizeComparerResult(true)
																				.WithEditChanges([nameof(ManualPriceCurveViewModel.DsxLotSize)])
																				.Build();

			var observable = testObjects.ManualPriceCurveEditChangesService.ObserveChanged(testObjects.ViewModel,
																						   testObjects.PriceCurveDefinition,
																						   testObjects.EditChanges);
			var count = 0;

			using (observable.Subscribe(_ => count++))
			{
				// ACT
				testObjects.ViewModel.DsxLotSize = 500;

				// ASSERT
				Assert.That(count, Is.EqualTo(1));

				Assert.That(testObjects.EditChanges, Is.Empty);
			}
		}

		[Test]
		public void ShouldNotAddPropertyName_Or_Publish_On_Change_With_CompareFalse_EditChangesContainsProperty()
		{
			var testObjects = new ManualPriceCurveEditChangesTestObjectBuilder().WithDsxLotSizeComparerResult(false)
																				.WithEditChanges([nameof(ManualPriceCurveViewModel.DsxLotSize)])
																				.Build();

			var observable = testObjects.ManualPriceCurveEditChangesService.ObserveChanged(testObjects.ViewModel,
																						   testObjects.PriceCurveDefinition,
																						   testObjects.EditChanges);
			var count = 0;

			var expected = new[] { nameof(ManualPriceCurveViewModel.DsxLotSize) };

			using (observable.Subscribe(_ => count++))
			{
				// ACT
				testObjects.ViewModel.DsxLotSize = 500;

				// ASSERT
				Assert.That(count, Is.EqualTo(0));

				Assert.That(testObjects.EditChanges.SequenceEqual(expected));
			}
		}

		[Test]
		public void ShouldNotPublish_On_Change_With_CompareTrue_EditChangesNotContainsProperty()
		{
			var testObjects = new ManualPriceCurveEditChangesTestObjectBuilder().WithDsxLotSizeComparerResult(true)
																				.Build();

			var observable = testObjects.ManualPriceCurveEditChangesService.ObserveChanged(testObjects.ViewModel,
																						   testObjects.PriceCurveDefinition,
																						   testObjects.EditChanges);
			var count = 0;

			using (observable.Subscribe(_ => count++))
			{
				// ACT
				testObjects.ViewModel.DsxLotSize = 500;

				// ASSERT
				Assert.That(count, Is.EqualTo(0));
			}
		}

		[Test]
		public void ShouldAddPropertyNames_And_PublishMultiple_On_Changes_With_CompareFalse()
		{
			var testObjects = new ManualPriceCurveEditChangesTestObjectBuilder().WithDsxLotSizeComparerResult(false)
																				.WithMaxPeriodCountComparerResult(false)
																				.Build();

			var observable = testObjects.ManualPriceCurveEditChangesService.ObserveChanged(testObjects.ViewModel,
																						   testObjects.PriceCurveDefinition,
																						   testObjects.EditChanges);
			var count = 0;

			var expected = new[]
						   {
							   nameof(ManualPriceCurveViewModel.DsxLotSize),
							   nameof(ManualPriceCurveViewModel.MaxPeriodCount)
						   };

			using (observable.Subscribe(_ => count++))
			{
				testObjects.ViewModel.DsxLotSize = 500;

				// ACT
				testObjects.ViewModel.MaxPeriodCount = 2;

				// ASSERT
				Assert.That(count, Is.EqualTo(2));

				Assert.That(testObjects.EditChanges.SequenceEqual(expected));
			}
		}
	}
}
