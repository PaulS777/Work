﻿using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Changes
{
    internal interface IDraftCurveChangesServiceTestObjects
    {
        PriceCurveDefinition PriceCurveDefinition { get; }
        ManualPriceCurveViewModel ViewModel { get; }
        DraftCurveChangesService DraftCurveChangesService { get; }
    }

    [TestFixture]
    public class DraftCurveChangesServiceTests
    {
        private class DraftCurveChangesServiceTestObjectBuilder
        {
            private bool _nameComparerResult;
            private bool _maxPeriodCountComparerResult;
            private object _maxPeriodCountComparerValue;

            public DraftCurveChangesServiceTestObjectBuilder WithNameComparerResult(bool value)
            {
                _nameComparerResult = value;
                return this;
            }

            public DraftCurveChangesServiceTestObjectBuilder WithMaxPeriodCountComparerResult(bool value)
            {
                _maxPeriodCountComparerResult = value;
                return this;
            }

            public DraftCurveChangesServiceTestObjectBuilder WithMaxPeriodCountComparerValue(object value)
            {
                _maxPeriodCountComparerValue = value;
                return this;
            }

            public IDraftCurveChangesServiceTestObjects Build()
            {
                var testObjects = new Mock<IDraftCurveChangesServiceTestObjects>();

                var viewModel = new ManualPriceCurveViewModel();

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(viewModel);

                var priceCurveDefinition = new PriceCurveDefinition();

                testObjects.SetupGet(o => o.PriceCurveDefinition)
                           .Returns(priceCurveDefinition);

                var nameComparer = new Mock<IPropertyComparer>();

                nameComparer.Setup(c => c.Compare(It.IsAny<ManualPriceCurveViewModel>(), It.IsAny<PriceCurveDefinition>()))
                            .Returns(_nameComparerResult);

                var maxPeriodComparer = new Mock<IPropertyComparer>();

                maxPeriodComparer.Setup(c => c.Compare(It.IsAny<ManualPriceCurveViewModel>(), It.IsAny<PriceCurveDefinition>()))
                                 .Returns(_maxPeriodCountComparerResult);

                maxPeriodComparer.Setup(c => c.GetValue(It.IsAny<PriceCurveDefinition>()))
                                 .Returns(_maxPeriodCountComparerValue);

                var comparers = new Dictionary<string, IPropertyComparer>
                                {
                                    { nameof(ManualPriceCurveViewModel.Name), nameComparer.Object },
                                    { nameof(ManualPriceCurveViewModel.MaxPeriodCount), maxPeriodComparer.Object }
                                };

                var curveComparers = new Mock<IDraftCurveChangeComparers>();

                curveComparers.SetupGet(c => c.Comparers)
							  .Returns(comparers);

                var draftCurveChangesService = new DraftCurveChangesService(curveComparers.Object);

                testObjects.SetupGet(o => o.DraftCurveChangesService)
                           .Returns(draftCurveChangesService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldReturnNameChanged_When_NameComparerReturnsValue()
        {
            var testObjects = new DraftCurveChangesServiceTestObjectBuilder().WithNameComparerResult(true)
                                                                             .WithMaxPeriodCountComparerResult(false)
                                                                             .WithMaxPeriodCountComparerValue(12)
                                                                             .Build();

            // ACT
            var result = testObjects.DraftCurveChangesService.GetDraftCurveChanges(testObjects.ViewModel,
                                                                                   testObjects.PriceCurveDefinition);

            // ASSERT
            Assert.That(result.Count, Is.EqualTo(1));
            Assert.That(result[nameof(ManualPriceCurveViewModel.MaxPeriodCount)], Is.EqualTo(12));
        }
    }
}
