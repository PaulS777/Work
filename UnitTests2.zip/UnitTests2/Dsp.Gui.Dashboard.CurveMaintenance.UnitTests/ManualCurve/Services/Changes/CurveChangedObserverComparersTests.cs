﻿using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Changes
{
	internal interface ICurveChangedObserverComparersTestObjects
	{
		CurveChangedObserverComparers CurveChangedObserverComparers { get; }
	}

	[TestFixture]
	public class CurveChangedObserverComparersTests
	{
		private class CurveChangedObserverComparersTestObjectBuilder
		{
			private bool _maxPeriodCountComparerResult;

			public CurveChangedObserverComparersTestObjectBuilder WithMaxPeriodCountComparerResult(bool value)
			{
				_maxPeriodCountComparerResult = value;
				return this;
			}

			public ICurveChangedObserverComparersTestObjects Build()
			{
				var testObjects = new Mock<ICurveChangedObserverComparersTestObjects>();

				var maxPeriodComparer = new Mock<IPropertyComparer>();

				maxPeriodComparer.Setup(c => c.Compare(It.IsAny<ManualPriceCurveViewModel>(), It.IsAny<PriceCurveDefinition>()))
								 .Returns(_maxPeriodCountComparerResult);

				var comparers = new Dictionary<string, IPropertyComparer>
								{
									{ nameof(ManualPriceCurveViewModel.MaxPeriodCount), maxPeriodComparer.Object }
								};

				var manualPriceCurveComparers = new Mock<IManualPriceCurveComparers>();

				manualPriceCurveComparers.SetupGet(c => c.Comparers)
										 .Returns(comparers);

				var curveChangedObserverComparers = new CurveChangedObserverComparers(manualPriceCurveComparers.Object);

				testObjects.SetupGet(o => o.CurveChangedObserverComparers)
						   .Returns(curveChangedObserverComparers);

				return testObjects.Object;
			}
		}

		#region Name

		[Test]
		public void ShouldReturnTrue_When_Compare_With_NamesEqual()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithName("name").Build();
			var viewModel = new ManualPriceCurveViewModel { Name = "name" };

			var testObjects = new CurveChangedObserverComparersTestObjectBuilder().Build();

			var comparer = testObjects.CurveChangedObserverComparers.Comparers[nameof(ManualPriceCurveViewModel.Name)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.True);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_With_NamesNotEqual()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithName("name").Build();
			var viewModel = new ManualPriceCurveViewModel { Name = "name_changed" };

			var testObjects = new CurveChangedObserverComparersTestObjectBuilder().Build();

			var comparer = testObjects.CurveChangedObserverComparers.Comparers[nameof(ManualPriceCurveViewModel.Name)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnName_When_GetCurveValue_With_Name()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithName("name").Build();

			var testObjects = new CurveChangedObserverComparersTestObjectBuilder().Build();

			var comparer = testObjects.CurveChangedObserverComparers.Comparers[nameof(ManualPriceCurveViewModel.Name)];

			// ACT
			var result = comparer.GetValue(curve);

			// ASSERT
			Assert.That(result, Is.EqualTo("name"));
		}

		#endregion

		#region Description

		[Test]
		public void ShouldReturnTrue_When_Compare_With_DescriptionsEqual()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithDescription("desc").Build();
			var viewModel = new ManualPriceCurveViewModel { Description = "desc" };

			var testObjects = new CurveChangedObserverComparersTestObjectBuilder().Build();

			var comparer = testObjects.CurveChangedObserverComparers.Comparers[nameof(ManualPriceCurveViewModel.Description)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.True);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_With_DescriptionsNotEqual()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithDescription("desc").Build();
			var viewModel = new ManualPriceCurveViewModel { Description = "desc_changed" };

			var testObjects = new CurveChangedObserverComparersTestObjectBuilder().Build();

			var comparer = testObjects.CurveChangedObserverComparers.Comparers[nameof(ManualPriceCurveViewModel.Description)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnName_When_GetCurveValue_With_Description()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithDescription("desc").Build();

			var testObjects = new CurveChangedObserverComparersTestObjectBuilder().Build();

			var comparer = testObjects.CurveChangedObserverComparers.Comparers[nameof(ManualPriceCurveViewModel.Description)];

			// ACT
			var result = comparer.GetValue(curve);

			// ASSERT
			Assert.That(result, Is.EqualTo("desc"));
		}

		#endregion

		#region ManualPriceCurveComparers - MaxPeriodCount

		[Test]
		public void ShouldReturnTrue_When_Compare_With_MaxPeriodCountsEqual_With_ManualPriceCurveComparers()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithMaxPeriodCount(12).Build();
			var viewModel = new ManualPriceCurveViewModel { MaxPeriodCount = 12 };

			var testObjects = new CurveChangedObserverComparersTestObjectBuilder().WithMaxPeriodCountComparerResult(true)
																				  .Build();

			var comparer = testObjects.CurveChangedObserverComparers.Comparers[nameof(ManualPriceCurveViewModel.MaxPeriodCount)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.True);
		}

		#endregion
	}
}
