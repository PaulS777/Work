﻿using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Changes
{
	internal interface IDraftCurveChangeComparersTestObjects
	{
		DraftCurveChangeComparers DraftCurveChangeComparers { get; }
	}

	[TestFixture]
	public class DraftCurveChangeComparersTests
	{
		private class DraftCurveChangeComparersTestObjectBuilder
		{
			private bool _maxPeriodCountComparerResult;

			public DraftCurveChangeComparersTestObjectBuilder WithMaxPeriodCountComparerResult(bool value)
			{
				_maxPeriodCountComparerResult = value;
				return this;
			}

			public IDraftCurveChangeComparersTestObjects Build()
			{
				var testObjects = new Mock<IDraftCurveChangeComparersTestObjects>();

				var maxPeriodComparer = new Mock<IPropertyComparer>();

				maxPeriodComparer.Setup(c => c.Compare(It.IsAny<ManualPriceCurveViewModel>(), It.IsAny<PriceCurveDefinition>()))
								 .Returns(_maxPeriodCountComparerResult);

				var comparers = new Dictionary<string, IPropertyComparer>
								{
									{ nameof(ManualPriceCurveViewModel.MaxPeriodCount), maxPeriodComparer.Object }
								};

				var manualPriceCurveComparers = new Mock<IManualPriceCurveComparers>();

				manualPriceCurveComparers.SetupGet(c => c.Comparers)
										 .Returns(comparers);

				var draftCurveChangeComparers = new DraftCurveChangeComparers(manualPriceCurveComparers.Object);

				testObjects.SetupGet(o => o.DraftCurveChangeComparers)
						   .Returns(draftCurveChangeComparers);

				return testObjects.Object;
			}
		}

		#region Name

		[Test]
		public void ShouldReturnTrue_When_Compare_With_NamesEqual_With_Draft()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithName("name").Build();
			var viewModel = new ManualPriceCurveViewModel { Name = "name_DRAFT" };

			var testObjects = new DraftCurveChangeComparersTestObjectBuilder().Build();

			var comparer = testObjects.DraftCurveChangeComparers.Comparers[nameof(ManualPriceCurveViewModel.Name)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.True);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_With_NamesNotEqual_With_Draft()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithName("name").Build();
			var viewModel = new ManualPriceCurveViewModel { Name = "name_changed_DRAFT" };

			var testObjects = new DraftCurveChangeComparersTestObjectBuilder().Build();

			var comparer = testObjects.DraftCurveChangeComparers.Comparers[nameof(ManualPriceCurveViewModel.Name)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnName_When_GetCurveValue_With_Name()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithName("name").Build();
			
			var testObjects = new DraftCurveChangeComparersTestObjectBuilder().Build();

			var comparer = testObjects.DraftCurveChangeComparers.Comparers[nameof(ManualPriceCurveViewModel.Name)];

			// ACT
			var result = comparer.GetValue(curve);

			// ASSERT
			Assert.That(result, Is.EqualTo("name"));
		}

		#endregion

		#region Description

		[Test]
		public void ShouldReturnTrue_When_Compare_With_DescriptionsEqual_With_Draft()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithDescription("desc").Build();
			var viewModel = new ManualPriceCurveViewModel { Description = "desc_DRAFT" };

			var testObjects = new DraftCurveChangeComparersTestObjectBuilder().Build();

			var comparer = testObjects.DraftCurveChangeComparers.Comparers[nameof(ManualPriceCurveViewModel.Description)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.True);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_With_DescriptionsNotEqual_With_Draft()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithDescription("desc").Build();
			var viewModel = new ManualPriceCurveViewModel { Description = "desc_changed_DRAFT" };

			var testObjects = new DraftCurveChangeComparersTestObjectBuilder().Build();

			var comparer = testObjects.DraftCurveChangeComparers.Comparers[nameof(ManualPriceCurveViewModel.Description)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnDescription_When_GetCurveValue_With_Description()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithDescription("desc").Build();

			var testObjects = new DraftCurveChangeComparersTestObjectBuilder().Build();

			var comparer = testObjects.DraftCurveChangeComparers.Comparers[nameof(ManualPriceCurveViewModel.Description)];

			// ACT
			var result = comparer.GetValue(curve);

			// ASSERT
			Assert.That(result, Is.EqualTo("desc"));
		}

		#endregion

		#region ManualPriceCurveComparers - MaxPeriodCount

		[Test]
		public void ShouldReturnTrue_When_Compare_With_MaxPeriodCountsEqual_With_ManualPriceCurveComparers()
		{
			var curve = new PriceCurveDefinitionTestObjectBuilder().WithMaxPeriodCount(12).Build();
			var viewModel = new ManualPriceCurveViewModel { MaxPeriodCount = 12 };

			var testObjects = new DraftCurveChangeComparersTestObjectBuilder().WithMaxPeriodCountComparerResult(true)
																			  .Build();

			var comparer = testObjects.DraftCurveChangeComparers.Comparers[nameof(ManualPriceCurveViewModel.MaxPeriodCount)];

			// ACT
			var result = comparer.Compare(viewModel, curve);

			// ASSERT
			Assert.That(result, Is.True);
		}

		#endregion
	}
}
