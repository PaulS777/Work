﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services
{
    internal interface IManualPriceCurveDefinitionProviderTestObjects
    {
        ISubject<User> CurrentUser { get; }
        ISubject<IList<ManualCurveDefinition<MonthlyTenor>>> ManualCurveDefinitions { get; }
        ISubject<IList<PriceCurveDefinition>> PriceCurveDefinitions { get; }
		TestScheduler TestScheduler { get; }
		ManualPriceCurveDefinitionProvider ManualPriceCurveDefinitionProvider { get; }
    }

    public class ManualPriceCurveDefinitionProviderTests
    {
        private class ManualPriceCurveDefinitionProviderTestObjectBuilder
		{
			private User _currentUser;
            private IList<ManualCurveDefinition<MonthlyTenor>> _manualCurveDefinitions;
            private IList<PriceCurveDefinition> _priceCurveDefinitions;

			public ManualPriceCurveDefinitionProviderTestObjectBuilder WithCurrentUser(User value)
			{
				_currentUser = value;
				return this;
			}

			public ManualPriceCurveDefinitionProviderTestObjectBuilder WithManualCurveDefinitions(IList<ManualCurveDefinition<MonthlyTenor>> values)
            {
                _manualCurveDefinitions = values;
                return this;
            }

            public ManualPriceCurveDefinitionProviderTestObjectBuilder WithPriceCurveDefinitions(IList<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public IManualPriceCurveDefinitionProviderTestObjects Build()
            {
                var testObjects = new Mock<IManualPriceCurveDefinitionProviderTestObjects>();

				var testScheduler = new TestScheduler();

				testObjects.SetupGet(o => o.TestScheduler)
						   .Returns(testScheduler);

				var schedulerProvider = new Mock<ISchedulerProvider>();

				schedulerProvider.SetupGet(p => p.TaskPool)
								 .Returns(testScheduler);

				var manualCurveDefinitions = new BehaviorSubject<IList<ManualCurveDefinition<MonthlyTenor>>>(_manualCurveDefinitions);

                testObjects.SetupGet(o => o.ManualCurveDefinitions)
                           .Returns(manualCurveDefinitions);

                var priceCurveDefinitions = new BehaviorSubject<IList<PriceCurveDefinition>>(_priceCurveDefinitions);

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurveDefinitions);

				var user = new BehaviorSubject<User>(_currentUser);

				testObjects.SetupGet(o => o.CurrentUser)
						   .Returns(user);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.ManualCurveDefinitions)
                                   .Returns(manualCurveDefinitions);

                curveControlService.SetupGet(o => o.PriceCurveDefinitions)
                                   .Returns(priceCurveDefinitions);

				curveControlService.SetupGet(o => o.CurrentUser)
								   .Returns(user);

                var manualPriceCurveDefinitionProvider = new ManualPriceCurveDefinitionProvider(curveControlService.Object);

                testObjects.SetupGet(o => o.ManualPriceCurveDefinitionProvider)
                           .Returns(manualPriceCurveDefinitionProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishPriceCurveDefinitions_Where_Matches_ManualCurve_With_CurveGroupAndRegionPermissions()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
            var authGroup = new AuthorisationCurveGroup(crude, true, false);
			var authRegion = new AuthorisationCurveRegion(CurveRegion.Europe, true, false);

			var user = new UserBuilder().WithAuthorizationCurveGroups([authGroup])
										.WithAuthorizationCurveRegions([authRegion])
										.User();
			//Id same as PriceCurveDefinition Id 
            var manualCurveDefinition1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                                        .WithCurveId(101)
                                                                                        .Build();
            //Id not same as the priceCurveDefinition Id 
            var manualCurveDefinition2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(102)
                                                                                        .WithCurveId(202)
                                                                                        .Build();

            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
                                                                                   .Build();

            var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

            var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

            var testObjects = new ManualPriceCurveDefinitionProviderTestObjectBuilder().WithCurrentUser(user)
																					   .WithManualCurveDefinitions([manualCurveDefinition1, manualCurveDefinition2])
                                                                                       .Build();

            IEnumerable<PriceCurveDefinition> result = null;

            var expected = new[] { priceCurveDefinition1 };

            using (testObjects.ManualPriceCurveDefinitionProvider
							  .PriceCurveDefinitions(testObjects.TestScheduler)
							  .Subscribe(values => result = values))
            {
                // ACT
                testObjects.PriceCurveDefinitions.OnNext(priceCurveDefinitions);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

                // ASSERT that result has only the curve with Id same as PriceCurveDefinition Id
                Assert.That(result.SequenceEqual(expected));
            }
        }

		[Test]
		public void ShouldNotPublish_On_CurrentUserUpdate_With_Same_CurveGroupPermissions()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var authGroup = new AuthorisationCurveGroup(crude, true, false);
			var authRegion = new AuthorisationCurveRegion(CurveRegion.Europe, true, false);

			var user = new UserBuilder().WithAuthorizationCurveGroups([authGroup])
										.WithAuthorizationCurveRegions([authRegion])
										.User();

			var manualCurveDefinition = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201)
																						.WithCurveId(101)
																						.Build();

			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

			var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new ManualPriceCurveDefinitionProviderTestObjectBuilder().WithCurrentUser(user)
																					   .WithManualCurveDefinitions([manualCurveDefinition])
																					   .WithPriceCurveDefinitions(priceCurveDefinitions)
																					   .Build();

			IEnumerable<PriceCurveDefinition> result = null;

			var userUpdate = new UserBuilder().WithAuthorizationCurveGroups([authGroup])
											  .WithAuthorizationCurveRegions([authRegion])
											  .WithSpreadMultiplier(1.5d)
											  .User();

			using (testObjects.ManualPriceCurveDefinitionProvider
							  .PriceCurveDefinitions(testObjects.TestScheduler)
							  .Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);
				result = null;	

				// ACT
				testObjects.CurrentUser.OnNext(userUpdate);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result, Is.Null);
			}
		}

		[Test]
		public void ShouldPublishEmpty_On_CurrentUserUpdate_With_CurveGroupRemoved()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var authGroup = new AuthorisationCurveGroup(crude, true, false);
			var authRegion = new AuthorisationCurveRegion(CurveRegion.Europe, true, false);

			var user = new UserBuilder().WithAuthorizationCurveGroups([authGroup])
										.WithAuthorizationCurveRegions([authRegion])
										.User();

			var manualCurveDefinition = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201)
																						.WithCurveId(101)
																						.Build();

			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

			var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new ManualPriceCurveDefinitionProviderTestObjectBuilder().WithCurrentUser(user)
																					   .WithManualCurveDefinitions([manualCurveDefinition])
																					   .WithPriceCurveDefinitions(priceCurveDefinitions)
																					   .Build();

			IEnumerable<PriceCurveDefinition> result = null;

			var userUpdate = new UserBuilder().WithAuthorizationCurveGroups([])
											  .WithAuthorizationCurveRegions([authRegion])
											  .WithSpreadMultiplier(1.5d)
											  .User();

			using (testObjects.ManualPriceCurveDefinitionProvider
							  .PriceCurveDefinitions(testObjects.TestScheduler)
							  .Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);
				result = null;

				// ACT
				testObjects.CurrentUser.OnNext(userUpdate);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result, Is.Empty);
			}
		}

		[Test]
		public void ShouldPublishEmpty_On_CurrentUserUpdate_With_CurveRegionRemoved()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var authGroup = new AuthorisationCurveGroup(crude, true, false);
			var authRegion = new AuthorisationCurveRegion(CurveRegion.Europe, true, false);

			var user = new UserBuilder().WithAuthorizationCurveGroups([authGroup])
										.WithAuthorizationCurveRegions([authRegion])
										.User();

			var manualCurveDefinition = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201)
																						.WithCurveId(101)
																						.Build();

			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

			var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new ManualPriceCurveDefinitionProviderTestObjectBuilder().WithCurrentUser(user)
																					   .WithManualCurveDefinitions([manualCurveDefinition])
																					   .WithPriceCurveDefinitions(priceCurveDefinitions)
																					   .Build();

			IEnumerable<PriceCurveDefinition> result = null;

			var userUpdate = new UserBuilder().WithAuthorizationCurveGroups([authGroup])
											  .WithAuthorizationCurveRegions([])
											  .WithSpreadMultiplier(1.5d)
											  .User();

			using (testObjects.ManualPriceCurveDefinitionProvider
							  .PriceCurveDefinitions(testObjects.TestScheduler)
							  .Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);
				result = null;

				// ACT
				testObjects.CurrentUser.OnNext(userUpdate);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result, Is.Empty);
			}
		}

		[Test]
        public void ShouldPublishPriceCurveDefinitionsUpdate_Where_Matches_AddedManualCurve()
        {
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var authGroup = new AuthorisationCurveGroup(crude, true, false);
			var authRegion = new AuthorisationCurveRegion(CurveRegion.Europe, true, false);

			var user = new UserBuilder().WithAuthorizationCurveGroups([authGroup])
										.WithAuthorizationCurveRegions([authRegion])
										.User();

			var manualCurveDefinition1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(101)
                                                                                         .WithCurveId(101)
                                                                                         .Build();

            var manualCurveDefinition2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(102)
                                                                                         .WithCurveId(102)
                                                                                         .Build();

            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

            var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

            var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

            var update = new[] { manualCurveDefinition1, manualCurveDefinition2 };

            var testObjects = new ManualPriceCurveDefinitionProviderTestObjectBuilder().WithCurrentUser(user)
																					   .WithManualCurveDefinitions([manualCurveDefinition1])
                                                                                       .WithPriceCurveDefinitions(priceCurveDefinitions)
                                                                                       .Build();

            IEnumerable<PriceCurveDefinition> result = null;

            var expected = new[] { priceCurveDefinition1, priceCurveDefinition2 };

            using (testObjects.ManualPriceCurveDefinitionProvider
							  .PriceCurveDefinitions(testObjects.TestScheduler)
							  .Subscribe(values => result = values.ToList()))
            {
                // ACT
                testObjects.ManualCurveDefinitions.OnNext(update);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result.SequenceEqual(expected));
            }
        }

        [Test]
        public void ShouldNotPublishPriceCurveDefinitionsUpdate_With_ManualIdsNotChanged()
        {
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var authGroup = new AuthorisationCurveGroup(crude, true, false);
			var authRegion = new AuthorisationCurveRegion(CurveRegion.Europe, true, false);

			var user = new UserBuilder().WithAuthorizationCurveGroups([authGroup])
										.WithAuthorizationCurveRegions([authRegion])
										.User();

			var manualCurveDefinition1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201)
                                                                                         .WithCurveId(101)
                                                                                         .Build();

            var manualCurveDefinition2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202)
                                                                                         .WithCurveId(102)
                                                                                         .Build();

            var overridesUpdate = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201)
                                                                                  .WithCurveId(101)
                                                                                  .WithOverrides([new CurvePoint<MonthlyTenor>(new MonthlyTenor(2024,1), 1.0)])
                                                                                  .Build();

            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

            var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																				   .WithProductCurveGroup(crude)
																				   .WithCurveRegion(CurveRegion.Europe)
																				   .Build();

            var manualCurveDefinitions = new[] { manualCurveDefinition1, manualCurveDefinition2 };
            var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

            var update = new[] { manualCurveDefinition2, overridesUpdate };

            var testObjects = new ManualPriceCurveDefinitionProviderTestObjectBuilder().WithCurrentUser(user)
																					   .WithManualCurveDefinitions(manualCurveDefinitions)
                                                                                       .WithPriceCurveDefinitions(priceCurveDefinitions)
                                                                                       .Build();

            IEnumerable<PriceCurveDefinition> result = null;

            using (testObjects.ManualPriceCurveDefinitionProvider
							  .PriceCurveDefinitions(testObjects.TestScheduler)
							  .Subscribe(values => result = values.ToList()))
            {
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);
				result = null;

                // ACT
                testObjects.ManualCurveDefinitions.OnNext(update);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result, Is.Null);
            }
        }
    }
}
