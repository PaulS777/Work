﻿using System;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services
{
	public interface IManualPriceCurveUpdateServiceTestObjects
	{
		IManagePriceCurveDefinitionActionService ActionService { get; }
		IObservable<AdminApiActionCompleted> ActionServiceResponse { get; }
		IScheduler Scheduler { get; }
		ManualPriceCurveUpdateService ManualPriceCurveUpdateService { get; }
	}

	[TestFixture]
	public class ManualPriceCurveUpdateServiceTests
	{
		private class ManualPriceCurveUpdateServiceTestObjectBuilder
		{
			public IManualPriceCurveUpdateServiceTestObjects Build()
			{
				var testObjects = new Mock<IManualPriceCurveUpdateServiceTestObjects>();

				var scheduler = new Mock<IScheduler>();

				testObjects.SetupGet(o => o.Scheduler)
				           .Returns(scheduler.Object);

				var actionServiceResponse = new Subject<AdminApiActionCompleted>();

				testObjects.SetupGet(o => o.ActionServiceResponse)
						   .Returns(actionServiceResponse);

				var actionService = new Mock<IManagePriceCurveDefinitionActionService>();

				actionService.Setup(a => a.Update(It.IsAny<ManagePriceCurveDefinitionAction>(), It.IsAny<IScheduler>()))
				             .Returns(actionServiceResponse);

                testObjects.SetupGet(o => o.ActionService)
                           .Returns(actionService.Object);

				var manualPriceCurveUpdateService = new ManualPriceCurveUpdateService(actionService.Object);

				testObjects.SetupGet(o => o.ManualPriceCurveUpdateService)
				           .Returns(manualPriceCurveUpdateService);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldInvokeActionService_When_UpdateManagePriceCurveDefinition()
        {
            const int priceCurveDefinitionId = 100;

			var ccy = new CurrencyCode(10, "EUR");
			var ccyItem = new CurrencyCodeItem(ccy);

			var product = new ProductDefinitionTestObjectBuilder().WithId(50).Build();

			var productItem = new ProductDefinitionItem(product);

			var priceCurve = new ManualPriceCurveViewModel
			{
				Name = "name",
				Description = "desc",
				ProductDefinition = productItem,
				CurveRegion = CurveRegion.Europe,
				CurveType = CurveType.Swap,
				DsxUnitOfMeasure = UnitOfMeasure.GAL,
				DsxLotSize = 1000,
				IncludePremiums = false,
				MaxPeriodCount = 10,
				OverrideUnitOfMeasure = UnitOfMeasure.M3,
				OverrideCurrencyCode = ccyItem,
				OverrideLotSize = 1500,
				OverrideCurrencyDenominationFactor = 2,
				OverrideDensityUnitOfVolume = UnitOfMeasure.BBL,
				OverrideDensityFactor = 1
			};

            var optionalFlags = new ManualCurveOptionalFlags
                                {
                                    ApplyMaxPeriodCount = true,
                                    ApplyOverrideCurrency = true,
                                    ApplyOverrideCurrencyDenominationFactor = true,
                                    ApplyOverrideDensity = true,
                                    ApplyOverrideLotSize = true,
                                    ApplyOverrideUnitOfMeasure = true
                                };

			var testObjects = new ManualPriceCurveUpdateServiceTestObjectBuilder().Build();

			// ACT
			var response = testObjects.ManualPriceCurveUpdateService.UpdateManualPriceCurveDefinition(priceCurve, 
																									  optionalFlags,
                                                                                                      priceCurveDefinitionId, 
                                                                                                      testObjects.Scheduler);
			// ASSERT
			Mock.Get(testObjects.ActionService)
                .Verify(a => a.Update(It.Is<ManagePriceCurveDefinitionAction>(d =>
                                               d.OperationType == OperationType.Update
											   && d.AdminCurveType == AdminCurveType.Manual
											   && d.PriceCurveDefinitionId == 100
											   && d.Name == "name"
											   && d.Description == "desc"
											   && d.ProductDefinitionId == 50
											   && d.CurveRegion == CurveRegion.Europe
											   && d.CurveType == CurveType.Swap
											   && d.DsxUnitOfMeasureId == UnitOfMeasure.GAL
											   && d.DsxLotSize == 1000
											   && d.ExcludePremiums
											   && d.MaxPeriodCount == 10
											   && d.Overrides.UnitOfMeasure == UnitOfMeasure.M3
											   && d.Overrides.CurrencyDenominationFactor == 2
											   && d.Overrides.Currency == 10
                                               && d.Overrides.LotSize == 1500
                                               && d.Overrides.Density.UnitOfVolume == UnitOfMeasure.BBL
											   && d.Overrides.Density.Factor.Equals(1.0d)),
                                   testObjects.Scheduler));

			Assert.That(response, Is.SameAs(testObjects.ActionServiceResponse));
		}

		[Test]
		public void ShouldInvokeActionService_With_OperationTypeCreate_When_CreateManagePriceCurveDefinition()
		{
			var ccy = new CurrencyCode(10, "EUR");
			var ccyItem = new CurrencyCodeItem(ccy);

			var product = new ProductDefinitionTestObjectBuilder().WithId(50).Build();

			var productItem = new ProductDefinitionItem(product);

			var priceCurve = new ManualPriceCurveViewModel
			{
				Name = "name",
				Description = "desc",
				ProductDefinition = productItem,
				CurveRegion = CurveRegion.Europe,
				CurveType = CurveType.Swap,
				DsxUnitOfMeasure = UnitOfMeasure.GAL,
				DsxLotSize = 1000,
				IncludePremiums = false,
				MaxPeriodCount = 10,
				OverrideCurrencyCode = ccyItem,
				OverrideLotSize = 1500,
				OverrideCurrencyDenominationFactor = 2,
				OverrideDensityUnitOfVolume = UnitOfMeasure.BBL,
				OverrideDensityFactor = 1
			};

            var optionalFlags = new ManualCurveOptionalFlags();

			var testObjects = new ManualPriceCurveUpdateServiceTestObjectBuilder().Build();

			testObjects.ManualPriceCurveUpdateService.CreateManualPriceCurveDefinition(priceCurve,
																					   optionalFlags,
                                                                                       testObjects.Scheduler);
			// ASSERT
			Mock.Get(testObjects.ActionService)
				.Verify(a => a.Update(It.Is<ManagePriceCurveDefinitionAction>(d => d.OperationType == OperationType.Create),
                                      testObjects.Scheduler));
		}
	}
}
