﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services
{
	[TestFixture]
	public class ManualPriceCurveUnsetFieldsServiceTests
	{
        [Test]
        public void ShouldRemovePropertyFromUnsetItems_And_PublishNext_On_PropertyChanged()
        {
			var viewModel = new ManualPriceCurveViewModel();

            var service = new ManualPriceCurveUnsetFieldsService();

            var unsetFields = new List<string> { 
                                                   nameof(ManualPriceCurveViewModel.Name),
                                                   nameof(ManualPriceCurveViewModel.Description)
                                               };

            var expected = new[] { nameof(ManualPriceCurveViewModel.Description) };

            var result = false;

            using (service.ObserveUnsetFields(viewModel, unsetFields).Subscribe(_ => result = true))
            {
                // ACT
                viewModel.Name = "name";

                // ASSERT
                Assert.That(unsetFields.SequenceEqual(expected));
                Assert.That(result, Is.True);
            }
		}

        [Test]
        public void ShouldPublishCompleted_On_PropertyChanged_With_LastItemRemoved()
        {
            var viewModel = new ManualPriceCurveViewModel();

            var service = new ManualPriceCurveUnsetFieldsService();

            var unsetFields = new List<string> {
                                                   nameof(ManualPriceCurveViewModel.Name)
                                               };

            var completed = false;

            using (service.ObserveUnsetFields(viewModel, unsetFields).Subscribe(_ => {}, () => completed = true))
            {
                // ACT
                viewModel.Name = "name";

                // ASSERT
                Assert.That(completed, Is.True);
            }
        }
	}
}
