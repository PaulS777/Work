﻿using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services
{
	[TestFixture]
	public class PriceCurveDefinitionItemCollectionFactoryTests
	{
		[Test]
		public void ShouldCreateCollection()
		{
			const int userId = 10;

			var activeWithoutPending = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-C").Build();

			var activeWithUserPending = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-D").WithPendingCurveId(103).Build();
			var userDraft = new PriceCurveDefinitionTestObjectBuilder().WithId(103).WithName("curve-E").WithActionedByUserId(userId).Build();

			var activeWithOtherPending = new PriceCurveDefinitionTestObjectBuilder().WithId(104).WithName("curve-A").WithPendingCurveId(105).Build();
			var otherDraft = new PriceCurveDefinitionTestObjectBuilder().WithId(105).WithName("curve-B").WithActionedByUserId(99).Build();

			var curves = new[]
						 {
							 activeWithoutPending, activeWithUserPending, userDraft, activeWithOtherPending, otherDraft
						 };

			var factory = new PriceCurveDefinitionItemCollectionFactory();

			// ACT
			var result = factory.CreateCollection(curves, userId);

			// ASSERT
			Assert.That(result.Count, Is.EqualTo(5));

			Assert.That(result[0].Id, Is.EqualTo(103));
			Assert.That(result[0].Name, Is.EqualTo("curve-E"));
			Assert.That(result[0].CurveDefinition, Is.SameAs(userDraft));
			Assert.That(result[0].IsDraftCurrentUser, Is.True);
			Assert.That(result[0].IsDraftOtherUser, Is.False);
			Assert.That(result[0].IsActivePendingApproval, Is.False);
			Assert.That(result[0].IsDraft, Is.True);

			Assert.That(result[1].Id, Is.EqualTo(104));
			Assert.That(result[1].IsDraftCurrentUser, Is.False);
			Assert.That(result[1].IsDraftOtherUser, Is.False);
			Assert.That(result[1].IsActivePendingApproval, Is.True);
			Assert.That(result[1].IsDraft, Is.False);

			Assert.That(result[2].Id, Is.EqualTo(105));
			Assert.That(result[2].IsDraftCurrentUser, Is.False);
			Assert.That(result[2].IsDraftOtherUser, Is.True);
			Assert.That(result[2].IsActivePendingApproval, Is.False);
			Assert.That(result[2].IsDraft, Is.True);

			Assert.That(result[3].Id, Is.EqualTo(101));
			Assert.That(result[3].IsDraftCurrentUser, Is.False);
			Assert.That(result[3].IsDraftOtherUser, Is.False);
			Assert.That(result[3].IsActivePendingApproval, Is.False);
			Assert.That(result[3].IsDraft, Is.False);

			Assert.That(result[4].Id, Is.EqualTo(102));
			Assert.That(result[4].IsDraftCurrentUser, Is.False);
			Assert.That(result[4].IsDraftOtherUser, Is.False);
			Assert.That(result[4].IsActivePendingApproval, Is.True);
			Assert.That(result[4].IsDraft, Is.False);
		}
	}
}
