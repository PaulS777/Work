﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services
{
	internal interface IDraftCurveItemMatchingServiceTestObjects
	{
		ISubject<IList<PriceCurveDefinitionStatusItem>> PriceCurveDefinitionItems { get; }
		DraftCurveItemMatchingService DraftCurveItemMatchingService { get; }
	}

	[TestFixture]
	public class DraftCurveItemMatchingServiceTests
	{
		private class DraftCurveItemMatchingServiceTestObjectBuilder
		{
			public IDraftCurveItemMatchingServiceTestObjects Build()
			{
				var testObjects = new Mock<IDraftCurveItemMatchingServiceTestObjects>();

				var items = new Subject<IList<PriceCurveDefinitionStatusItem>>();

				testObjects.SetupGet(o => o.PriceCurveDefinitionItems)
						   .Returns(items);

				var matchingService = new DraftCurveItemMatchingService();

				testObjects.SetupGet(o => o.DraftCurveItemMatchingService)
						   .Returns(matchingService);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldPublishItem_And_Complete_When_ActiveCurveMatchingDraftItem_Exists()
		{
			var curve1 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve1").WithId(101).Build();

			var curve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve2").WithPendingCurveId(202).Build();
			var curve2Draft = new PriceCurveDefinitionTestObjectBuilder().WithId(202).WithName("curve2_DRAFT").Build();

			var curve3 = new PriceCurveDefinitionTestObjectBuilder().WithId(103).WithName("curve3").WithPendingCurveId(203).Build();
			var curve3Draft = new PriceCurveDefinitionTestObjectBuilder().WithId(203).WithName("curve3_DRAFT").Build();

			var item1 = new PriceCurveDefinitionStatusItem(curve1);
			var item2 = new PriceCurveDefinitionStatusItem(curve2, false, false, true);
			var item3 = new PriceCurveDefinitionStatusItem(curve2Draft, true);
			var item4 = new PriceCurveDefinitionStatusItem(curve3, false, false, true);
			var item5 = new PriceCurveDefinitionStatusItem(curve3Draft, true);

			var items = new[] { item1, item2, item3, item4, item5 };

			var testObjects = new DraftCurveItemMatchingServiceTestObjectBuilder().Build();

			PriceCurveDefinitionStatusItem result = null;
			var completed = false;

			using (testObjects.DraftCurveItemMatchingService
							  .ActiveCurveMatchingDraftItem(testObjects.PriceCurveDefinitionItems, 103)
							  .Subscribe(value => result = value, () => completed = true))
			{
				// ACT
				testObjects.PriceCurveDefinitionItems.OnNext(items);

				// ASSERT
				Assert.That(result, Is.SameAs(item5));
				Assert.That(completed, Is.True);
			}
		}

		[Test]
		public void ShouldPublishNull_When_ActiveCurveMatchingDraftItem_NotExists()
		{
			var curve1 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve1").WithId(101).Build();

			var curve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve2").WithPendingCurveId(202).Build();
			var curve2Draft = new PriceCurveDefinitionTestObjectBuilder().WithId(202).WithName("curve2_DRAFT").Build();

			var curve3 = new PriceCurveDefinitionTestObjectBuilder().WithId(103).WithName("curve3").Build();

			var item1 = new PriceCurveDefinitionStatusItem(curve1);
			var item2 = new PriceCurveDefinitionStatusItem(curve2, false, false, true);
			var item3 = new PriceCurveDefinitionStatusItem(curve2Draft, true);
			var item4 = new PriceCurveDefinitionStatusItem(curve3, false, false, true);

			var items = new[] { item1, item2, item3, item4 };

			var testObjects = new DraftCurveItemMatchingServiceTestObjectBuilder().Build();

			PriceCurveDefinitionStatusItem result = null;
			var completed = false;

			using (testObjects.DraftCurveItemMatchingService
							  .ActiveCurveMatchingDraftItem(testObjects.PriceCurveDefinitionItems, 103)
							  .Subscribe(value => result = value, () => completed = true))
			{
				// ACT
				testObjects.PriceCurveDefinitionItems.OnNext(items);

				// ASSERT
				Assert.That(result, Is.Null);
				Assert.That(completed, Is.False);
			}
		}

		[Test]
		public void ShouldPublishItem_And_Complete_When_ExistingMatchingDraftItem_Exists()
		{
			var curve1 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve1").WithId(101).Build();
			var curve2Draft = new PriceCurveDefinitionTestObjectBuilder().WithId(202).WithName("curve2_DRAFT").Build();
			var curve3Draft = new PriceCurveDefinitionTestObjectBuilder().WithId(203).WithName("curve3_DRAFT").Build();

			var item1 = new PriceCurveDefinitionStatusItem(curve1);
			var item2 = new PriceCurveDefinitionStatusItem(curve2Draft, true);
			var item3 = new PriceCurveDefinitionStatusItem(curve3Draft, true);

			var items = new[] { item1, item2, item3 };

			var testObjects = new DraftCurveItemMatchingServiceTestObjectBuilder().Build();

			PriceCurveDefinitionStatusItem result = null;
			var completed = false;

			using (testObjects.DraftCurveItemMatchingService
							  .ExistingDraftMatchingDraftItem(testObjects.PriceCurveDefinitionItems, 203)
							  .Subscribe(value => result = value, () => completed = true))
			{
				// ACT
				testObjects.PriceCurveDefinitionItems.OnNext(items);

				// ASSERT
				Assert.That(result, Is.SameAs(item3));
				Assert.That(completed, Is.True);
			}
		}

		[Test]
		public void ShouldPublishNull_When_ExistingMatchingDraftItem_NotExists()
		{
			var curve1 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve1").WithId(101).Build();
			var curve2Draft = new PriceCurveDefinitionTestObjectBuilder().WithId(202).WithName("curve2_DRAFT").Build();

			var item1 = new PriceCurveDefinitionStatusItem(curve1);
			var item2 = new PriceCurveDefinitionStatusItem(curve2Draft, true);

			var items = new[] { item1, item2 };

			var testObjects = new DraftCurveItemMatchingServiceTestObjectBuilder().Build();

			PriceCurveDefinitionStatusItem result = null;
			var completed = false;

			using (testObjects.DraftCurveItemMatchingService
							  .ExistingDraftMatchingDraftItem(testObjects.PriceCurveDefinitionItems, 203)
							  .Subscribe(value => result = value, () => completed = true))
			{
				// ACT
				testObjects.PriceCurveDefinitionItems.OnNext(items);

				// ASSERT
				Assert.That(result, Is.Null);
				Assert.That(completed, Is.False);
			}
		}

		[Test]
		public void ShouldPublishItem_And_Complete_When_NewCurveMatchingDraftItem_Exists()
		{
			var curve1 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve1").Build();
			var curve2 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve2_DRAFT").Build();
			var curve3 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve3_DRAFT").Build();

			var item1 = new PriceCurveDefinitionStatusItem(curve1);
			var item2 = new PriceCurveDefinitionStatusItem(curve2, true);
			var item3 = new PriceCurveDefinitionStatusItem(curve3, true);

			var items = new[] { item1, item2, item3 };

			var testObjects = new DraftCurveItemMatchingServiceTestObjectBuilder().Build();

			PriceCurveDefinitionStatusItem result = null;
			var completed = false;

			using (testObjects.DraftCurveItemMatchingService
							  .NewCurveMatchingDraftItem(testObjects.PriceCurveDefinitionItems, "curve3")
							  .Subscribe(value => result = value, () => completed = true))
			{
				// ACT
				testObjects.PriceCurveDefinitionItems.OnNext(items);

				// ASSERT
				Assert.That(result, Is.SameAs(item3));
				Assert.That(completed, Is.True);
			}
		}

		[Test]
		public void ShouldNotPublishItem_When_NewCurveMatchingDraftItem_NotExists()
		{
			var curve1 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve1").Build();
			var curve2 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve2_DRAFT").Build();

			var item1 = new PriceCurveDefinitionStatusItem(curve1);
			var item2 = new PriceCurveDefinitionStatusItem(curve2, true);

			var items = new[] { item1, item2 };

			var testObjects = new DraftCurveItemMatchingServiceTestObjectBuilder().Build();

			PriceCurveDefinitionStatusItem result = null;
			var completed = false;

			using (testObjects.DraftCurveItemMatchingService
							  .NewCurveMatchingDraftItem(testObjects.PriceCurveDefinitionItems, "curve3")
							  .Subscribe(value => result = value, () => completed = true))
			{
				// ACT
				testObjects.PriceCurveDefinitionItems.OnNext(items);

				// ASSERT
				Assert.That(result, Is.Null);
				Assert.That(completed, Is.False);
			}
		}

		[Test]
		public void ShouldHandleDraftCurveInvalidName()
		{
			var curve1 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve1").Build();
			var curve2 = new PriceCurveDefinitionTestObjectBuilder().WithName("curve2_DRAFT_X").Build();

			var item1 = new PriceCurveDefinitionStatusItem(curve1);
			var item2 = new PriceCurveDefinitionStatusItem(curve2, true);

			var items = new[] { item1, item2 };

			var testObjects = new DraftCurveItemMatchingServiceTestObjectBuilder().Build();

			PriceCurveDefinitionStatusItem result = null;
			var completed = false;

			using (testObjects.DraftCurveItemMatchingService
							  .NewCurveMatchingDraftItem(testObjects.PriceCurveDefinitionItems, "curve2")
							  .Subscribe(value => result = value, () => completed = true))
			{
				// ACT
				testObjects.PriceCurveDefinitionItems.OnNext(items);

				// ASSERT
				Assert.That(result, Is.Null);
				Assert.That(completed, Is.False);
			}
		}
	}
}
