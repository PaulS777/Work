﻿using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using NUnit.Framework;
using System.Collections.Generic;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services
{
    [TestFixture]
    public class ManualPriceCurveTransformerTests
    {
        [Test]
        public void ShouldTransformPriceCurve_With_Overrides()
        {
            var curveTypes = new[] { CurveType.Crack, CurveType.Spread };
            var curveRegions = new[] { CurveRegion.Europe, CurveRegion.Asia };
            var unitsOfMeasure = new[] { UnitOfMeasure.BBL, UnitOfMeasure.MT, UnitOfMeasure.M3 };
      

            var ccy1 = new CurrencyCode(1, "EUR");
            var ccy2 = new CurrencyCode(2, "USD");

			var ccyItem1 = new CurrencyCodeItem(ccy1);
			var ccyItem2 = new CurrencyCodeItem(ccy2);

			var ccyItems = new[] { ccyItem1, ccyItem2 };
                        
            var curveGroups = new List<CurveGroup>();

            var product1 = new ProductDefinitionTestObjectBuilder().WithId(1)
                                                                   .WithPricingTenorGroupType(PricingTenorGroupType.Daily)
                                                                   .WithUnitOfMeasure(UnitOfMeasure.M3)
                                                                   .WithLotSize(1000)
                                                                   .WithCurrency(2)
                                                                   .WithCurrencyDenominationFactor(1)
                                                                   .WithDensity(new Density(UnitOfMeasure.GAL, 0.5d))
                                                                   .Build();

            var product2 = new ProductDefinitionTestObjectBuilder().WithId(2)
                                                                   .WithPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                   .Build();

			var productItem1 = new ProductDefinitionItem(product1);
			var productItem2 = new ProductDefinitionItem(product2);

			var products = new [] { productItem1, productItem2 };

            var overrides = new PriceCurveDefinitionOverride(UnitOfMeasure.M3, 
                                                             new Density(UnitOfMeasure.BBL, 1.1d),
                                                             2, 
                                                             1250,
                                                             1);
          
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithName("name")
                                                                                  .WithDescription("desc")
                                                                                  .WithCurveType(CurveType.Crack)
                                                                                  .WithCurveRegion(CurveRegion.Europe)
                                                                                  .WithDsxUnitOfMeasure(UnitOfMeasure.MT)
                                                                                  .WithProductDefinition(product1)
                                                                                  .WithMaxPeriodCount(10)
                                                                                  .WithExcludePremiums(false)
                                                                                  .WithDsxLotSize(1500)
                                                                                  .WithPriceCurveDefinitionOverride(overrides)
                                                                                  .Build();

            var viewModel = new ManualCurveEditorViewModel
                            {
                                CurveTypes = curveTypes,
                                CurveRegions = curveRegions,
                                UnitsOfMeasure = unitsOfMeasure,
                                ProductDefinitions = products,
                                CurrencyCodes = ccyItems
            };

            var transformer = new ManualPriceCurveTransformer();

            // ACT
            transformer.TransformPriceCurve(viewModel, priceCurveDefinition, curveGroups);

            // ASSERT
            Assert.That(viewModel.ManualPriceCurve.Name, Is.EqualTo("name"));
            Assert.That(viewModel.ManualPriceCurve.Description, Is.EqualTo("desc"));
            Assert.That(viewModel.ManualPriceCurve.CurveType, Is.EqualTo(CurveType.Crack));
            Assert.That(viewModel.ManualPriceCurve.ProductDefinition.Id, Is.EqualTo(1));
            Assert.That(viewModel.ManualPriceCurve.CurveRegion, Is.EqualTo(CurveRegion.Europe));
            Assert.That(viewModel.ManualPriceCurve.MaxPeriodCount, Is.EqualTo(10));
            Assert.That(viewModel.ManualPriceCurve.IncludePremiums, Is.True);
            Assert.That(viewModel.ManualPriceCurve.DsxUnitOfMeasure, Is.EqualTo(UnitOfMeasure.MT));
            Assert.That(viewModel.ManualPriceCurve.DsxLotSize, Is.EqualTo(1500));

            Assert.That(viewModel.ManualPriceCurve.OverrideUnitOfMeasure, Is.EqualTo(UnitOfMeasure.M3));
            Assert.That(viewModel.ManualPriceCurve.OverrideLotSize, Is.EqualTo(1250));
            Assert.That(viewModel.ManualPriceCurve.OverrideCurrencyCode, Is.SameAs(ccyItem1));
            Assert.That(viewModel.ManualPriceCurve.OverrideCurrencyDenominationFactor, Is.EqualTo(2));
            Assert.That(viewModel.ManualPriceCurve.OverrideDensityUnitOfVolume, Is.EqualTo(UnitOfMeasure.BBL));
            Assert.That(viewModel.ManualPriceCurve.OverrideDensityFactor, Is.EqualTo(1.1d));

            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyMaxPeriodCount, Is.True);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideUnitOfMeasure, Is.True);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideLotSize, Is.True);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideCurrencyDenominationFactor, Is.True);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideDensity, Is.True);

            Assert.That(viewModel.ProductUnitOfMeasure, Is.EqualTo(UnitOfMeasure.M3));
            Assert.That(viewModel.ProductLotSize, Is.EqualTo(1000));
            Assert.That(viewModel.ProductCurrencyCode, Is.EqualTo("USD"));
            Assert.That(viewModel.ProductCurrencyDenominationFactor, Is.EqualTo(1));
            Assert.That(viewModel.ProductDensityUnitOfVolume, Is.EqualTo(UnitOfMeasure.GAL));
            Assert.That(viewModel.ProductDensityFactor, Is.EqualTo(0.5d));
        }

        [Test]
        public void ShouldTransformProduct()
        {
            var unitsOfMeasure = new[] { UnitOfMeasure.BBL, UnitOfMeasure.MT, UnitOfMeasure.M3 };

			var ccy1 = new CurrencyCode(1, "EUR");
			var ccy2 = new CurrencyCode(2, "USD");

			var ccyItem1 = new CurrencyCodeItem(ccy1);
			var ccyItem2 = new CurrencyCodeItem(ccy2);

			var currencies = new[] { ccyItem1, ccyItem2 };
            
            var curveGroups = new List<CurveGroup>();

            var product = new ProductDefinitionTestObjectBuilder().WithId(1)
                                                                  .WithPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                  .WithUnitOfMeasure(UnitOfMeasure.M3)
                                                                  .WithLotSize(1000)
                                                                  .WithCurrency(2)
                                                                  .WithCurrencyDenominationFactor(1)
                                                                  .WithDensity(new Density(UnitOfMeasure.GAL, 0.5d))
                                                                  .Build();

            var viewModel = new ManualCurveEditorViewModel
            {
                UnitsOfMeasure = unitsOfMeasure,
                CurrencyCodes = currencies
            };

            var transformer = new ManualPriceCurveTransformer();

            // ACT
            transformer.TransformProduct(viewModel, product, curveGroups);

            // ASSERT
            Assert.That(viewModel.ProductUnitOfMeasure, Is.EqualTo(UnitOfMeasure.M3));
            Assert.That(viewModel.ProductLotSize, Is.EqualTo(1000));
            Assert.That(viewModel.ProductCurrencyCode, Is.EqualTo("USD"));
            Assert.That(viewModel.ProductCurrencyDenominationFactor, Is.EqualTo(1));
            Assert.That(viewModel.ProductDensityUnitOfVolume, Is.EqualTo(UnitOfMeasure.GAL));
            Assert.That(viewModel.ProductDensityFactor, Is.EqualTo(0.5d));
            Assert.That(viewModel.PricingTenorGroupType, Is.EqualTo(PricingTenorGroupType.Monthly));
        }

        [TestCase(0)]
        [TestCase(null)]
        public void ShouldClearMaxPeriodCount_And_SetApplyFalse_When_Transform_With_MaxPeriodCountNullOrZero(int? value)
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithMaxPeriodCount(value)
                                                                                  .Build();

            var curveGroups = new List<CurveGroup>();

            var viewModel = new ManualCurveEditorViewModel
                            {
                                CurveTypes = [],
                                CurveRegions = [],
                                UnitsOfMeasure = [],
                                ProductDefinitions = [],
                                CurrencyCodes = [],
                                ManualCurveOptionalFlags =
                                {
                                    ApplyMaxPeriodCount = true
                                },
                                ManualPriceCurve =
                                {
                                    MaxPeriodCount = 60
                                }
                            };

            var transformer = new ManualPriceCurveTransformer();

            // ACT
            transformer.TransformPriceCurve(viewModel, priceCurveDefinition, curveGroups);

            // ASSERT
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyMaxPeriodCount, Is.False);
            Assert.That(viewModel.ManualPriceCurve.MaxPeriodCount, Is.Null);
        }

        [Test]
        public void ShouldClearOverrides_And_SetApplyFalse_When_Transform_With_NoOverrides()
        {
            var ccy1 = new CurrencyCode(1, "EUR");
            var ccyItem1 = new CurrencyCodeItem(ccy1);
           
            var overrides = new PriceCurveDefinitionOverride();

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithPriceCurveDefinitionOverride(overrides)
                                                                                  .Build();

            var curveGroups = new List<CurveGroup>();

            var viewModel = new ManualCurveEditorViewModel
            {
                CurveTypes = [],
                CurveRegions = [],
                UnitsOfMeasure = [],
                ProductDefinitions = [],
                CurrencyCodes = [],
                ManualCurveOptionalFlags =
                               {
                                   ApplyOverrideUnitOfMeasure = true,
                                   ApplyOverrideLotSize = true,
                                   ApplyOverrideCurrency = true,
                                   ApplyOverrideCurrencyDenominationFactor = true,
                                   ApplyOverrideDensity = true
                               },
                ManualPriceCurve =
                               {
                                   OverrideUnitOfMeasure = UnitOfMeasure.BBL,
                                   OverrideLotSize = 1000,
                                   OverrideCurrencyCode = ccyItem1,
                                   OverrideCurrencyDenominationFactor = 2,
                                   OverrideDensityUnitOfVolume = UnitOfMeasure.BBL,
                                   OverrideDensityFactor = 1
                               }
            };

            var transformer = new ManualPriceCurveTransformer();

            // ACT  
            transformer.TransformPriceCurve(viewModel, priceCurveDefinition, curveGroups);

            // ASSERT  
            Assert.That(viewModel.ManualPriceCurve.OverrideUnitOfMeasure, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideLotSize, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideCurrencyCode, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideCurrencyDenominationFactor, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideDensityUnitOfVolume, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideDensityFactor, Is.Null);

            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyMaxPeriodCount, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideUnitOfMeasure, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideLotSize, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideCurrencyDenominationFactor, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideDensity, Is.False);
        }

        [Test]
        public void ShouldClearPriceCurve()
        {
            var product = new ProductDefinitionTestObjectBuilder().WithId(1).Build();

			var productItem = new ProductDefinitionItem(product);

            var ccy1 = new CurrencyCode(1, "EUR");
			var ccyItem1 = new CurrencyCodeItem(ccy1);

			var viewModel = new ManualCurveEditorViewModel
                            {
                                ManualCurveOptionalFlags =
                                {
                                    ApplyOverrideUnitOfMeasure = true,
                                    ApplyOverrideLotSize = true,
                                    ApplyOverrideCurrency = true,
                                    ApplyOverrideCurrencyDenominationFactor = true,
                                    ApplyOverrideDensity = true
                                },
				                ManualPriceCurve =
                                {
                                    Name = "name",
                                    Description = "desc",
                                    CurveType = CurveType.Crack,
                                    CurveRegion = CurveRegion.Europe,
                                    ProductDefinition = productItem,
                                    DsxUnitOfMeasure = UnitOfMeasure.MT,
                                    MaxPeriodCount = 10,
                                    IncludePremiums = false,
                                    DsxLotSize = 1500,
                                    OverrideUnitOfMeasure = UnitOfMeasure.M3,
                                    OverrideLotSize = 1250,
                                    OverrideCurrencyCode = ccyItem1,
                                    OverrideCurrencyDenominationFactor = 10,
                                    OverrideDensityUnitOfVolume = UnitOfMeasure.BBL,
                                    OverrideDensityFactor = 1.1d
                                },
                                ProductUnitOfMeasure = UnitOfMeasure.M3,
                                ProductLotSize = 1000,
                                ProductCurrencyCode = "USD",
                                ProductCurrencyDenominationFactor = 1,
                                ProductDensityUnitOfVolume = UnitOfMeasure.GAL,
                                ProductDensityFactor = 0.5d,
                                PricingTenorGroupType = PricingTenorGroupType.Monthly
                            };
            
            var transformer = new ManualPriceCurveTransformer();

            // ACT
            transformer.ClearPriceCurve(viewModel);

            // ASSERT
            Assert.That(viewModel.ManualPriceCurve.Name, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.Description, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.CurveType, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.CurveRegion, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.ProductDefinition, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.DsxUnitOfMeasure, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.MaxPeriodCount, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.IncludePremiums, Is.True);
            Assert.That(viewModel.ManualPriceCurve.DsxLotSize, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideUnitOfMeasure, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideLotSize, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideCurrencyCode, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideCurrencyDenominationFactor, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideDensityUnitOfVolume, Is.Null);
            Assert.That(viewModel.ManualPriceCurve.OverrideDensityFactor, Is.Null);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyMaxPeriodCount, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideUnitOfMeasure, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideLotSize, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideCurrency, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideCurrencyDenominationFactor, Is.False);
            Assert.That(viewModel.ManualCurveOptionalFlags.ApplyOverrideDensity, Is.False);
            Assert.That(viewModel.ProductUnitOfMeasure, Is.Null);
            Assert.That(viewModel.ProductLotSize, Is.Null);
            Assert.That(viewModel.ProductCurrencyCode, Is.Null);
            Assert.That(viewModel.ProductCurrencyDenominationFactor, Is.Null);
            Assert.That(viewModel.ProductDensityUnitOfVolume, Is.Null);
            Assert.That(viewModel.ProductDensityFactor, Is.Null);
            Assert.That(viewModel.PricingTenorGroupType, Is.Null);
        }
    }
}
