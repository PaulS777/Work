﻿using System.Collections.Generic;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services
{
    internal interface IManualPriceCurveDefinitionsSnapshotTestObjects
    {
		ISubject<IEnumerable<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        ManualPriceCurveDefinitionsSnapshot ManualPriceCurveDefinitionsSnapshot { get; }
	}

	[TestFixture]
	public class ManualPriceCurveDefinitionsSnapshotTests
	{
        private class ManualPriceCurveDefinitionsSnapshotTestObjectBuilder
        {
			public IManualPriceCurveDefinitionsSnapshotTestObjects Build()
            {
                var testObjects = new Mock<IManualPriceCurveDefinitionsSnapshotTestObjects>();

                var priceCurveDefinitions = new Subject<IEnumerable<PriceCurveDefinition>>();

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurveDefinitions);

                var provider = new Mock<IManualPriceCurveDefinitionProvider>();

                provider.Setup(p => p.PriceCurveDefinitions(It.IsAny<IScheduler>()))
                        .Returns(priceCurveDefinitions);

                var snapshot = new ManualPriceCurveDefinitionsSnapshot(provider.Object,
																	   TestMocks.GetSchedulerProvider().Object);

                testObjects.SetupGet(o => o.ManualPriceCurveDefinitionsSnapshot)
                           .Returns(snapshot);

                return testObjects.Object;
            }
		}

        [Test]
        public void ShouldReturnSnapshot_From_Latest_PriceCurveDefinitions()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .Build();

            var testObjects = new ManualPriceCurveDefinitionsSnapshotTestObjectBuilder().Build();

            // ARRANGE
            testObjects.PriceCurveDefinitions.OnNext([priceCurveDefinition]);

            // ACT
            var result = testObjects.ManualPriceCurveDefinitionsSnapshot.PriceCurveDefinitions;

            // ASSERT
            Assert.That(result.Count(), Is.EqualTo(1));
        }

        [Test]
        public void ShouldNotReturnLatest_With_PriceCurveDefinitions_After_Dispose()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .Build();

            var testObjects = new ManualPriceCurveDefinitionsSnapshotTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ManualPriceCurveDefinitionsSnapshot.Dispose();

            testObjects.PriceCurveDefinitions.OnNext([priceCurveDefinition]);

            // ACT
            var result = testObjects.ManualPriceCurveDefinitionsSnapshot.PriceCurveDefinitions;

            // ASSERT
            Assert.That(result, Is.Null);
		}

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
                                                                                  .Build();

            var testObjects = new ManualPriceCurveDefinitionsSnapshotTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ManualPriceCurveDefinitionsSnapshot.Dispose();
            testObjects.ManualPriceCurveDefinitionsSnapshot.Dispose();

			testObjects.PriceCurveDefinitions.OnNext([priceCurveDefinition]);

            // ACT
            var result = testObjects.ManualPriceCurveDefinitionsSnapshot.PriceCurveDefinitions;

            // ASSERT
            Assert.That(result, Is.Null);
        }
	}
}
