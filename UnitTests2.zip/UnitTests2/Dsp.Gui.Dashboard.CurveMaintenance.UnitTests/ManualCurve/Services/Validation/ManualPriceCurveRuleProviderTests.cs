﻿using System.Linq;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation.Rules;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation.Rules;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation
{
    internal interface IManualPriceCurveRuleProviderTestObjects
    {
		IDuplicateNameValidationRule DuplicateNameValidationRule { get; }
		ManualPriceCurveValidationRuleProvider ManualPriceCurveValidationRuleProvider { get; }
    }

    [TestFixture]
    public class ManualPriceCurveRuleProviderTests
    {
        private class ManualPriceCurveRuleProviderTestObjectBuilder
        {
			public IManualPriceCurveRuleProviderTestObjects Build()
            {
                var testObjects = new Mock<IManualPriceCurveRuleProviderTestObjects>();

                var duplicateNameValidationRule = new Mock<IDuplicateNameValidationRule>();

				testObjects.SetupGet(o => o.DuplicateNameValidationRule)
						   .Returns(duplicateNameValidationRule.Object);

                var duplicateNameValidationRuleFactory = new Mock<IServiceFactory<IDuplicateNameValidationRule>>();

                duplicateNameValidationRuleFactory.Setup(f => f.Create())
                                                  .Returns(duplicateNameValidationRule.Object);

                var ruleProvider = new ManualPriceCurveValidationRuleProvider(duplicateNameValidationRuleFactory.Object);

                testObjects.SetupGet(o => o.ManualPriceCurveValidationRuleProvider)
                           .Returns(ruleProvider);

				return testObjects.Object;
            }
		}

		[Test]
		public void ShouldInitializeDuplicateNameRule_With_PriceCurveDefinitionId_When_GetRules_With_Id()
		{
			var testObjects = new ManualPriceCurveRuleProviderTestObjectBuilder().Build();

			// ACT
			testObjects.ManualPriceCurveValidationRuleProvider.GetRules(101);

            // ASSERT
            Mock.Get(testObjects.DuplicateNameValidationRule)
				.Verify(r => r.Initialize(101));
		}

		[Test]
		public void ShouldInitializeDuplicateNameRule_With_Null_When_GetRules_With_Null()
		{
			var testObjects = new ManualPriceCurveRuleProviderTestObjectBuilder().Build();

			// ACT
			testObjects.ManualPriceCurveValidationRuleProvider.GetRules();

			// ASSERT
			Mock.Get(testObjects.DuplicateNameValidationRule)
				.Verify(r => r.Initialize(null));
		}

		[Test]
        public void ShouldProvideValidationRules()
        {
            var ruleProvider = new ManualPriceCurveRuleProviderTestObjectBuilder().Build()
                                                                                  .ManualPriceCurveValidationRuleProvider;

            // ACT
			var rules = ruleProvider.GetRules();

            // ASSERT
            Assert.That(rules.ContainsKey("Name"));
            Assert.That(rules["Name"].OfType<EmptyStringValidationRule>().Count(), Is.EqualTo(1));
            Assert.That(rules["Name"].OfType<NameValidationRule>().Count(), Is.EqualTo(1));
            Assert.That(rules["Name"].OfType<IDuplicateNameValidationRule>().Count(), Is.EqualTo(1));

			Assert.That(rules.ContainsKey("Description"));
            Assert.That(rules["Description"].OfType<EmptyStringValidationRule>().Count(), Is.EqualTo(1));

            Assert.That(rules.ContainsKey("CurveRegion"));
            Assert.That(rules["CurveRegion"].OfType<CurveRegionValidationRule>().Count(), Is.EqualTo(1));

            Assert.That(rules.ContainsKey("DsxLotSize"));
            Assert.That(rules["DsxLotSize"].OfType<LotSizeValidationRule>().Count(), Is.EqualTo(1));

            Assert.That(rules.ContainsKey("DsxUnitOfMeasure"));
            Assert.That(rules["DsxUnitOfMeasure"].OfType<UnitOfMeasureValidationRule>().Count(), Is.EqualTo(1));

            Assert.That(rules.ContainsKey("MaxPeriodCount"));
            Assert.That(rules["MaxPeriodCount"].OfType<PositiveIntegerValidationRule>().Count(), Is.EqualTo(1));

			Assert.That(rules.ContainsKey("OverrideUnitOfMeasure"));
            Assert.That(rules["OverrideUnitOfMeasure"].OfType<UnitOfMeasureValidationRule>().Count(), Is.EqualTo(1));

            Assert.That(rules.ContainsKey("OverrideLotSize"));
            Assert.That(rules["OverrideLotSize"].OfType<PositiveIntegerValidationRule>().Count(), Is.EqualTo(1));

            Assert.That(rules.ContainsKey("OverrideCurrencyCode"));
            Assert.That(rules["OverrideCurrencyCode"].OfType<CurrencyCodeValidationRule>().Count(), Is.EqualTo(1));

			Assert.That(rules.ContainsKey("OverrideCurrencyDenominationFactor"));
            Assert.That(rules["OverrideCurrencyDenominationFactor"].OfType<NonNegativeIntegerValidationRule>().Count(), Is.EqualTo(1));

            Assert.That(rules.ContainsKey("OverrideDensityUnitOfVolume"));
            Assert.That(rules["OverrideDensityUnitOfVolume"].OfType<UnitOfMeasureValidationRule>().Count(), Is.EqualTo(1));

            Assert.That(rules.ContainsKey("OverrideDensityFactor"));
            Assert.That(rules["OverrideDensityFactor"].OfType<PositiveDoubleValidationRule>().Count(), Is.EqualTo(1));
		}
    }
}
