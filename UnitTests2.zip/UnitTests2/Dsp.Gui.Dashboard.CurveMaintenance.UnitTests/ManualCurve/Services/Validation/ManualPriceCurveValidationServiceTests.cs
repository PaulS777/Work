﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation
{
    internal interface IManualPriceCurveValidationServiceTestObjects
    {
		IManualPriceCurveValidationRuleProvider RuleProvider { get; }
		IPropertyValidationService PropertyValidationService { get; }
        ManualCurveEditorViewModel ViewModel { get; }
        ManualPriceCurveValidationService ManualPriceCurveValidationService { get; }
    }

    [TestFixture]
    public class ManualPriceCurveValidationServiceTests
    {
        private class ManualPriceCurveValidationServiceTestObjectBuilder
        {
			private PriceCurveDefinitionStatusItem _selectedCurveDefinitionStatus;
			private Dictionary<string, IList<IValidationRule>> _validationRules;
            private readonly Dictionary<string, IList<string>> _viewModelErrors = new();
            private Exception _propertyValidationException;
            private IList<string> _nameValidationErrors;
			
            private bool _applyMaxPeriodCount;
            private bool _applyOverrideUnitOfMeasure;
            private bool _applyOverrideLotSize;
            private bool _applyOverrideCurrency;
            private bool _applyOverrideCurrencyDenominationFactor;
            private bool _applyOverrideDensity;

			public ManualPriceCurveValidationServiceTestObjectBuilder WithSelectedCurveDefinition(PriceCurveDefinitionStatusItem value)
			{
				_selectedCurveDefinitionStatus = value;
				return this;
			}

			public ManualPriceCurveValidationServiceTestObjectBuilder WithValidationRules(Dictionary<string, IList<IValidationRule>> values)
            {
                _validationRules = values;
                return this;
            }

            public ManualPriceCurveValidationServiceTestObjectBuilder WithViewModelErrors(string propertyName, IList<string> errors)
            {
                _viewModelErrors.Add(propertyName, errors);
                return this;
            }

            public ManualPriceCurveValidationServiceTestObjectBuilder WithPropertyValidationException(Exception value)
            {
                _propertyValidationException = value;
                return this;
            }

            public ManualPriceCurveValidationServiceTestObjectBuilder WithNameValidationErrors(IList<string> values)
            {
                _nameValidationErrors = values;
                return this;
            }

            public ManualPriceCurveValidationServiceTestObjectBuilder WithApplyMaxPeriodCount(bool value)
            {
                _applyMaxPeriodCount = value;
                return this;
            }

			public ManualPriceCurveValidationServiceTestObjectBuilder WithApplyOverrideUnitOfMeasure(bool value)
            {
                _applyOverrideUnitOfMeasure = value;
                return this;
            }

            public ManualPriceCurveValidationServiceTestObjectBuilder WithApplyOverrideLotSize(bool value)
            {
                _applyOverrideLotSize = value;
                return this;
            }

            public ManualPriceCurveValidationServiceTestObjectBuilder WithApplyOverrideCurrency(bool value)
            {
                _applyOverrideCurrency = value;
                return this;
            }

            public ManualPriceCurveValidationServiceTestObjectBuilder WithApplyOverrideCurrencyDenominationFactor(bool value)
            {
                _applyOverrideCurrencyDenominationFactor = value;
                return this;
            }

            public ManualPriceCurveValidationServiceTestObjectBuilder WithApplyOverrideDensity(bool value)
            {
                _applyOverrideDensity = value;
                return this;
            }

			public IManualPriceCurveValidationServiceTestObjects Build()
            {
                var testObjects = new Mock<IManualPriceCurveValidationServiceTestObjects>();

                var viewModel = new ManualCurveEditorViewModel
                                {
                                    ManualCurveOptionalFlags = 
                                    { 
                                        ApplyMaxPeriodCount = _applyMaxPeriodCount,
                                        ApplyOverrideUnitOfMeasure = _applyOverrideUnitOfMeasure,
                                        ApplyOverrideLotSize = _applyOverrideLotSize,
                                        ApplyOverrideCurrency = _applyOverrideCurrency,
                                        ApplyOverrideCurrencyDenominationFactor = _applyOverrideCurrencyDenominationFactor,
                                        ApplyOverrideDensity = _applyOverrideDensity
                                    },
                                    SelectedCurveDefinitionStatus = _selectedCurveDefinitionStatus
                                };

                if (_viewModelErrors != null)
                {
                    foreach (var kvp in _viewModelErrors)
                    {
						viewModel.ManualPriceCurve.Errors.Add(kvp.Key, kvp.Value);
					}
                }

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(viewModel);

                var ruleProvider = new Mock<IManualPriceCurveValidationRuleProvider>();

                ruleProvider.Setup(p => p.GetRules(It.IsAny<int?>()))
                            .Returns(_validationRules);

				testObjects.SetupGet(o => o.RuleProvider)
						   .Returns(ruleProvider.Object);

                var propertyValidationService = new Mock<IPropertyValidationService>();

                if (_propertyValidationException == null)
                {
                    propertyValidationService.Setup(p => p.Validate("Name", It.IsAny<string>()))
                                             .Returns(_nameValidationErrors);
                }
                else
                {
                    propertyValidationService.Setup(p => p.Validate(It.IsAny<string>(), It.IsAny<string>()))
                                             .Throws(_propertyValidationException);
                }

                testObjects.SetupGet(o => o.PropertyValidationService)
                           .Returns(propertyValidationService.Object);

                var manualPriceCurveValidationService = new ManualPriceCurveValidationService(ruleProvider.Object,
                                                                                              propertyValidationService.Object);

                testObjects.SetupGet(o => o.ManualPriceCurveValidationService)
                           .Returns(manualPriceCurveValidationService);

                return testObjects.Object;
            }
        }

        #region Initialize

        [Test]
        public void ShouldInitializePropertyValidationService_When_ObserveValidation()
        {
            var rules = new Dictionary<string, IList<IValidationRule>>();

            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithValidationRules(rules)
                                                                                      .Build();

            // ACT
			testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			// ASSERT
            Mock.Get(testObjects.RuleProvider)
				.Verify(rp => rp.GetRules(null));

			Mock.Get(testObjects.PropertyValidationService)
                .Verify(p => p.InitializeRules(rules));
        }

		[Test]
		public void ShouldInitializePropertyValidationService_When_ObserveValidation_With_SelectedPriceCurveItem()
		{
			var rules = new Dictionary<string, IList<IValidationRule>>();

			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithValidationRules(rules)
																					  .WithSelectedCurveDefinition(item)
																					  .Build();

			// ACT
			testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			// ASSERT
			Mock.Get(testObjects.RuleProvider)
				.Verify(rp => rp.GetRules(101));

			Mock.Get(testObjects.PropertyValidationService)
				.Verify(p => p.InitializeRules(rules));
		}

		#endregion

		#region Name - Validate => Errors, Publish, Clear, Execption

		[TestCase("Name")]
        public void ShouldValidateName_On_NameChanged(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                // ACT
                testObjects.ViewModel.ManualPriceCurve.Name = "value";

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, "value"));
            }
        }

		[TestCase("Name")]
		public void ShouldUpdateErrorsAndPublishProperty_On_NameChanged_With_ValidationErrors(string propertyName)
        {
            var errors = new[] { "error" };

            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithNameValidationErrors(errors)
                                                                                      .Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            string result = null;

            using (validation.Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.ManualPriceCurve.Name = "*!";

                // ASSERT
                Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors[propertyName].SequenceEqual(errors));
                Assert.That(result, Is.EqualTo(propertyName));
            }
        }

		[TestCase("Name")]
		public void ShouldClearErrorsAndPublishProperty_On_NameChanged_With_NoValidationErrors(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithViewModelErrors(propertyName, ["error"])
                                                                                      .WithNameValidationErrors([])
                                                                                      .Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            string result = null;

            using (validation.Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.ManualPriceCurve.Name = "value";

                // ASSERT
                Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors, Is.Empty);
                Assert.That(result, Is.EqualTo(propertyName));
            }
        }

        [Test]
        public void ShouldPublishError_On_NameChanged_With_ValidationException()
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithPropertyValidationException(new Exception())
                                                                                      .Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            Exception error = null;

            using (validation.Subscribe(_ => { }, ex => error = ex))
            {
                // ACT
                testObjects.ViewModel.ManualPriceCurve.Name = "x";

                // ASSERT
                Assert.That(error, Is.Not.Null);
            }
        }

        #endregion

        #region Curve properties

        [TestCase("Description")]
        public void ShouldValidateDescription_On_DescriptionChanged(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                // ACT
                testObjects.ViewModel.ManualPriceCurve.Description = "value";

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, "value"));
            }
        }

		[TestCase("CurveRegion")]
		public void ShouldValidateCurveRegion_On_CurveRegionChanged(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                // ACT
                testObjects.ViewModel.ManualPriceCurve.CurveRegion = CurveRegion.Asia;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, CurveRegion.Asia));
            }
        }

		[TestCase("DsxLotSize")]
		public void ShouldValidateDsxLotSize_On_DsxLotSizeChanged(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                // ACT
                testObjects.ViewModel.ManualPriceCurve.DsxLotSize = 1000;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, 1000));
            }
        }

		[TestCase("DsxUnitOfMeasure")]
		public void ShouldValidateDsxUnitOfMeasure_On_DsxUnitOfMeasureChanged(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                // ACT
                testObjects.ViewModel.ManualPriceCurve.DsxUnitOfMeasure = UnitOfMeasure.MT;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, UnitOfMeasure.MT));
            }
        }

        #endregion

		#region apply - MaxPerdiodCount

        [TestCase("MaxPeriodCount")]
		public void ShouldValidateMaxPeriodCount_On_ApplyMaxPeriodCount(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                // ACT
                testObjects.ViewModel.ManualCurveOptionalFlags.ApplyMaxPeriodCount = true;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, null));
            }
        }

        [TestCase("MaxPeriodCount")]
		public void ShouldValidateMaxPeriodCount_On_MaxPeriodCount_With_ApplyTrue(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                testObjects.ViewModel.ManualCurveOptionalFlags.ApplyMaxPeriodCount = true;
                testObjects.ViewModel.ManualPriceCurve.MaxPeriodCount =10;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, 10));
            }
        }

		[TestCase("MaxPeriodCount")]
		public void ShouldClearValidationErrors_On_ApplyMaxPeriodCountFalse(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithApplyMaxPeriodCount(true)
                                                                                      .WithViewModelErrors(propertyName, ["error"])
                                                                                      .Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            string result = null;

            using (validation.Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.ManualCurveOptionalFlags.ApplyMaxPeriodCount = false;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, It.IsAny<object>()), Times.Never);

                Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors, Is.Empty);
                Assert.That(result, Is.EqualTo(propertyName));
            }
        }

		#endregion

		#region overrides - UnitOfMeasure

		[TestCase("OverrideUnitOfMeasure")]
        public void ShouldValidateOverrideUnitOfMeasure_On_ApplyUnitOfMeasureTrue(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                // ACT
                testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideUnitOfMeasure = true;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, null));
            }
		}

		[TestCase("OverrideUnitOfMeasure")]
		public void ShouldValidateOverrideUnitOfMeasure_On_OverrideUnitOfMeasure_With_ApplyTrue(string propertyName)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            using (validation.Subscribe(_ => { }))
            {
                testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideUnitOfMeasure = true;
                testObjects.ViewModel.ManualPriceCurve.OverrideUnitOfMeasure = UnitOfMeasure.BBL;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, UnitOfMeasure.BBL));
            }
        }

		[TestCase("OverrideUnitOfMeasure")]
		public void ShouldClearValidationErrors_On_ApplyUnitOfMeasureFalse(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithApplyOverrideUnitOfMeasure(true)
                                                                                      .WithViewModelErrors(propertyName, ["error"])
                                                                                      .Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            string result = null;

			using (validation.Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideUnitOfMeasure = false;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName, It.IsAny<object>()), Times.Never);

                Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors, Is.Empty);
                Assert.That(result, Is.EqualTo(propertyName));
			}
		}

		#endregion

		#region overrides - LotSize

        [TestCase("OverrideLotSize")]
		public void ShouldValidateOverrideLotSize_On_ApplyLotSizeTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				// ACT
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideLotSize = true;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, null));
			}
		}

        [TestCase("OverrideLotSize")]
		public void ShouldValidateOverrideLotSize_On_OverrideLotSize_With_ApplyTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideLotSize = true;
				testObjects.ViewModel.ManualPriceCurve.OverrideLotSize = 100;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, 100));
			}
		}

		[TestCase("OverrideLotSize")]
		public void ShouldClearValidationErrors_On_ApplyLotSizeFalse(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithApplyOverrideLotSize(true)
																					  .WithViewModelErrors(propertyName, ["error"])
																					  .Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			string result = null;

			using (validation.Subscribe(value => result = value))
			{
				// ACT
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideLotSize = false;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, It.IsAny<object>()), Times.Never);

				Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors, Is.Empty);
				Assert.That(result, Is.EqualTo(propertyName));
			}
		}

		#endregion

		#region overrides - Currency

		[TestCase("OverrideCurrencyCode")]
		public void ShouldValidateOverrideCurrencyCode_On_ApplyCurrencyCodeTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				// ACT
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideCurrency = true;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, null));
			}
		}

		[TestCase("OverrideCurrencyCode")]
		public void ShouldValidateOverrideCurrencyCode_On_OverrideCurrencyCode_With_ApplyTrue(string propertyName)
        {
			var ccy = new CurrencyCode(1, "EUR");
			var ccyItem = new CurrencyCodeItem(ccy);

			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideCurrency = true;
				testObjects.ViewModel.ManualPriceCurve.OverrideCurrencyCode = ccyItem;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, ccyItem));
			}
		}

		[TestCase("OverrideCurrencyCode")]
		public void ShouldClearValidationErrors_On_ApplyCurrencyFalse(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithApplyOverrideCurrency(true)
																					  .WithViewModelErrors(propertyName, ["error"])
																					  .Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			string result = null;

			using (validation.Subscribe(value => result = value))
			{
				// ACT
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideCurrency = false;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, It.IsAny<object>()), Times.Never);

				Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors, Is.Empty);
				Assert.That(result, Is.EqualTo(propertyName));
			}
		}

		#endregion

		#region overrides - CurrencyDenominationFactor

		[TestCase("OverrideCurrencyDenominationFactor")]
		public void ShouldValidateOverrideCurrencyDenominationFactor_On_ApplyCurrencyDenominationFactorTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				// ACT
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideCurrencyDenominationFactor = true;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, null));
			}
		}

		[TestCase("OverrideCurrencyDenominationFactor")]
		public void ShouldValidateOverrideCurrencyDenominationFactor_On_OverrideCurrencyDenominationFactor_With_ApplyTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideCurrencyDenominationFactor = true;
				testObjects.ViewModel.ManualPriceCurve.OverrideCurrencyDenominationFactor = 2;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, 2));
			}
		}

		[TestCase("OverrideCurrencyDenominationFactor")]
		public void ShouldClearValidationErrors_On_ApplyCurrencyDenominationFactorFalse(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithApplyOverrideCurrencyDenominationFactor(true)
																					  .WithViewModelErrors(propertyName, ["error"])
																					  .Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			string result = null;

			using (validation.Subscribe(value => result = value))
			{
				// ACT
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideCurrencyDenominationFactor = false;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, It.IsAny<object>()), Times.Never);

				Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors, Is.Empty);
				Assert.That(result, Is.EqualTo(propertyName));
			}
		}

		#endregion

		#region overrides - Density

		[TestCase("OverrideDensityUnitOfVolume")]
		public void ShouldValidateOverrideDensityUnitOfVolume_On_ApplyDensityTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				// ACT
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideDensity = true;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, null));
			}
		}

		[TestCase("OverrideDensityUnitOfVolume")]
		public void ShouldValidateOverrideDensityUnitOfVolume_On_OverrideDensityUnitOfVolume_With_ApplyTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideDensity= true;
				testObjects.ViewModel.ManualPriceCurve.OverrideDensityUnitOfVolume = UnitOfMeasure.BBL;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, UnitOfMeasure.BBL));
			}
		}

		[TestCase("OverrideDensityFactor")]
		public void ShouldValidateOverrideDensityFactor_On_ApplyDensityTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				// ACT
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideDensity = true;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, null));
			}
		}

		[TestCase("OverrideDensityFactor")]
		public void ShouldValidateOverrideDensityFactor_On_OverrideDensityFactor_With_ApplyTrue(string propertyName)
		{
			var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().Build();

			var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

			using (validation.Subscribe(_ => { }))
			{
				testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideDensity = true;
				testObjects.ViewModel.ManualPriceCurve.OverrideDensityFactor = 10.0d;

				// ASSERT
				Mock.Get(testObjects.PropertyValidationService)
					.Verify(p => p.Validate(propertyName, 10.0d));
			}
		}

        [TestCase("OverrideDensityUnitOfVolume", "OverrideDensityFactor")]
        public void ShouldClearOverrideDensityErrors_On_ApplyDensityFalse(string propertyName1, string propertyName2)
        {
            var testObjects = new ManualPriceCurveValidationServiceTestObjectBuilder().WithApplyOverrideDensity(true)
                                                                                      .WithViewModelErrors(propertyName1, ["error"])
                                                                                      .WithViewModelErrors(propertyName2, ["error"])
																					  .Build();

            var validation = testObjects.ManualPriceCurveValidationService.ObserveValidation(testObjects.ViewModel);

            var results = new List<string>();

            using (validation.Subscribe(results.Add))
            {
                // ACT
                testObjects.ViewModel.ManualCurveOptionalFlags.ApplyOverrideDensity = false;

                // ASSERT
                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName1, It.IsAny<object>()), Times.Never);

                Mock.Get(testObjects.PropertyValidationService)
                    .Verify(p => p.Validate(propertyName2, It.IsAny<object>()), Times.Never);

				Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors, Is.Empty);
                Assert.That(results.Contains(propertyName1));
                Assert.That(results.Contains(propertyName2));
			}
        }

		#endregion
	}
}
