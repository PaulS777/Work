﻿using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation.Rules;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation.Rules
{
    [TestFixture]
    public class LotSizeValidationRuleTests
    {
        [Test]
        public void ShouldReturnTrue_When_Validate_With_LotSizeGreaterThanZero()
        {
            var rule = new LotSizeValidationRule();

            // ACT
            var result = rule.Validate(1000);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_LotSizeNull()
        {
            var rule = new LotSizeValidationRule();

            // ACT
            var result = rule.Validate(null);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_LotSizeZero()
        {
            var rule = new LotSizeValidationRule();

            // ACT
            var result = rule.Validate(0);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }
    }
}
