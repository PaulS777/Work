﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation.Rules;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation.Rules
{
	[TestFixture]
	public class CurrencyCodeValidationRuleTests
	{
        [Test]
        public void ShouldReturnTrue_When_Validate_With_CurrencyCodeNotNull()
        {
            var currency = new CurrencyCode(1,"EUR");
			var item = new CurrencyCodeItem(currency);

            var rule = new CurrencyCodeValidationRule();

            // ACT
            var result = rule.Validate(item);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_CurrencyCodeNull()
        {
            var rule = new CurrencyCodeValidationRule();

            // ACT
            var result = rule.Validate(null);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }
	}
}
