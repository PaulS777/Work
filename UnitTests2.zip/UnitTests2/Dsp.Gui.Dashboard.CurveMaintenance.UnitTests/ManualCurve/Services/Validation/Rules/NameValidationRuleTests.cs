﻿using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation.Rules;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation.Rules
{
    [TestFixture]
    public class NameValidationRuleTests
    {
        [Test]
        public void ShouldReturnTrue_When_Validate_With_StringNotEndsWithManual()
        {
            var rule = new NameValidationRule();

            // ACT
            var result = rule.Validate("text");

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_StringEndsWithManual()
        {
            var rule = new NameValidationRule();

            // ACT
            var result = rule.Validate("text_MANUAL  ");

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }

        [Test]
        public void ShouldReturnTrue_When_Validate_With_EmptyString()
        {
            var rule = new NameValidationRule();

            // ACT
            var result = rule.Validate(string.Empty);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }
    }
}
