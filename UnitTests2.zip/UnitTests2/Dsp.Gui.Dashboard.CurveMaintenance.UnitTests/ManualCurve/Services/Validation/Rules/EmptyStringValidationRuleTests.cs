﻿using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation.Rules;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation.Rules
{
    [TestFixture]
    public class EmptyStringValidationRuleTests
    {
        [Test]
        public void ShouldReturnTrue_When_Validate_With_String()
        {
            var rule = new EmptyStringValidationRule("error");

            // ACT
            var result = rule.Validate("text");

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_Null()
        {
            var rule = new EmptyStringValidationRule("error");

            // ACT
            var result = rule.Validate(null);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
            Assert.That(result.ErrorContent, Is.EqualTo("error"));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_EmptyString()
        {
            var rule = new EmptyStringValidationRule("error");

            // ACT
            var result = rule.Validate(string.Empty);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
            Assert.That(result.ErrorContent, Is.EqualTo("error"));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_WhitespaceOnly()
        {
            var rule = new EmptyStringValidationRule("error");

            // ACT
            var result = rule.Validate("  ");

            // ASSERT
            Assert.That(result.IsValid, Is.False);
            Assert.That(result.ErrorContent, Is.EqualTo("error"));
        }
    }
}
