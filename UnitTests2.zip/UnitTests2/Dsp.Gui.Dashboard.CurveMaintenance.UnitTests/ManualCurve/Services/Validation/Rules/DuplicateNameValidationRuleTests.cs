﻿using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation.Rules;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation.Rules
{
    internal interface IDuplicateNameValidationRuleTestObjects
    {
		IManualPriceCurveDefinitionsSnapshot ManualPriceCurveDefinitionsSnapshot { get; }
		DuplicateNameValidationRule ValidationRule { get; }
	}

	[TestFixture]
	public class DuplicateNameValidationRuleTests
	{
		private class DuplicateNameValidationRuleTestObjectBuilder
        {
            private IEnumerable<PriceCurveDefinition> _priceCurveDefinitions;

            public DuplicateNameValidationRuleTestObjectBuilder WithPriceCurveDefinitions(IEnumerable<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public IDuplicateNameValidationRuleTestObjects Build()
            {
                var testObjects = new Mock<IDuplicateNameValidationRuleTestObjects>();

                var snapshot = new Mock<IManualPriceCurveDefinitionsSnapshot>();

                snapshot.SetupGet(s => s.PriceCurveDefinitions)
                        .Returns(_priceCurveDefinitions);

				testObjects.SetupGet(o => o.ManualPriceCurveDefinitionsSnapshot)
						   .Returns(snapshot.Object);

                var validationRule = new DuplicateNameValidationRule(snapshot.Object);

                testObjects.SetupGet(o => o.ValidationRule)
                           .Returns(validationRule);

                return testObjects.Object;
            }
		}

        #region Validate with CurveId Initialized (Edit exisiting Curve from Snapshot)

        [Test]
        public void ShouldReturnTrue_When_Validate_With_CurveId_NotMatchesName_AgainstSnapshot()
        {
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-1").Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-2").Build();

			var curves = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new DuplicateNameValidationRuleTestObjectBuilder().WithPriceCurveDefinitions(curves)
                                                                                .Build();

            // ARRANGE
			testObjects.ValidationRule.Initialize(101);

			// ACT
			var result = testObjects.ValidationRule.Validate("curve-3");

            // ASSERT
            Assert.That(result.IsValid, Is.True);
			Assert.That(result.ErrorContent, Is.Null);
		}

		[Test]
		public void ShouldReturnTrue_When_Validate_With_CurveId_MatchesName_Against_MatchingSnapshotCurveById()
		{
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-1").Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-2").Build();

			var curves = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new DuplicateNameValidationRuleTestObjectBuilder().WithPriceCurveDefinitions(curves)
																				.Build();

			// ARRANGE
			testObjects.ValidationRule.Initialize(101);

			// ACT
			var result = testObjects.ValidationRule.Validate("curve-1");

			// ASSERT
			Assert.That(result.IsValid, Is.True);
			Assert.That(result.ErrorContent, Is.Null);
		}

		[Test]
		public void ShouldReturnFalse_When_Validate_MatchesName_Against_Snapshot_NotMatchingSnapshotCurveById()
		{
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-1").Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-2").Build();

			var curves = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new DuplicateNameValidationRuleTestObjectBuilder().WithPriceCurveDefinitions(curves)
																				.Build();

			// ARRANGE
			testObjects.ValidationRule.Initialize(101);

			// ACT
			var result = testObjects.ValidationRule.Validate("curve-2");

			// ASSERT
			Assert.That(result.IsValid, Is.False);
		}

		#endregion

		[Test]
		public void ShouldReturnTrue_When_Validate_With_NotMatchesName_NoCurveId()
		{
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-1").Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-2").Build();

			var curves = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new DuplicateNameValidationRuleTestObjectBuilder().WithPriceCurveDefinitions(curves)
																				.Build();

			// ARRANGE
			testObjects.ValidationRule.Initialize();

			// ACT
			var result = testObjects.ValidationRule.Validate("curve-3");

			// ASSERT
			Assert.That(result.IsValid, Is.True);
			Assert.That(result.ErrorContent, Is.Null);
		}

		[Test]
		public void ShouldReturnFalse_When_Validate_With_MatchesName_NoCurveId()
		{
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-1").Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-2").Build();

			var curves = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new DuplicateNameValidationRuleTestObjectBuilder().WithPriceCurveDefinitions(curves)
																				.Build();

			// ARRANGE
			testObjects.ValidationRule.Initialize();

			// ACT
			var result = testObjects.ValidationRule.Validate("curve-1");

			// ASSERT
			Assert.That(result.IsValid, Is.False);
			Assert.That(result.ErrorContent, Is.Not.Null);
		}

		[Test]
		public void ShouldReturnFalse_When_Validate_With_MatchesName_Trim_NoCurveId()
		{
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-1").Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-2").Build();

			var curves = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new DuplicateNameValidationRuleTestObjectBuilder().WithPriceCurveDefinitions(curves)
																				.Build();

			// ARRANGE
			testObjects.ValidationRule.Initialize();

			// ACT
			var result = testObjects.ValidationRule.Validate(" curve-1 ");

			// ASSERT
			Assert.That(result.IsValid, Is.False);
			Assert.That(result.ErrorContent, Is.Not.Null);
		}

		[Test]
        public void ShouldReturnTrue_When_Validate_With_EmptyString_NoCurveId()
        {
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-1").Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-2").Build();

			var curves = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new DuplicateNameValidationRuleTestObjectBuilder().WithPriceCurveDefinitions(curves)
																				.Build();

			// ARRANGE
			testObjects.ValidationRule.Initialize();

			// ACT
			var result = testObjects.ValidationRule.Validate(string.Empty);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

		#region Draft

		[Test]
		public void ShouldReturnFalse_When_Validate_With_Duplicate_Draft()
		{
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).WithName("curve-1").Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).WithName("curve-2_DRAFT").Build();

			var curves = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new DuplicateNameValidationRuleTestObjectBuilder().WithPriceCurveDefinitions(curves)
																				.Build();

			// ARRANGE
			testObjects.ValidationRule.Initialize();

			// ACT
			var result = testObjects.ValidationRule.Validate("curve-2");

			// ASSERT
			Assert.That(result.IsValid, Is.False);
			Assert.That(result.ErrorContent, Is.Not.Null);
		}

		#endregion
	}
}
