﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation.Rules;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation.Rules
{
    [TestFixture]
    public class UnitOfMeasureValidationRuleTests
    {
        [Test]
        public void ShouldReturnTrue_When_Validate_With_UnitOfMeasureNotNone()
        {
            var rule = new UnitOfMeasureValidationRule();

            // ACT
            var result = rule.Validate(UnitOfMeasure.MT);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UnitOfMeasureNull()
        {
            var rule = new UnitOfMeasureValidationRule();

            // ACT
            var result = rule.Validate(null);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_UnitOfMeasureNone()
        {
            var rule = new UnitOfMeasureValidationRule();

            // ACT
            var result = rule.Validate(UnitOfMeasure.None);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }
    }
}
