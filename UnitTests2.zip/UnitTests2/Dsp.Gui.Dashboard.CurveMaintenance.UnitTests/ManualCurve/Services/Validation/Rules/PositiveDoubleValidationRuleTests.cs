﻿using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation.Rules;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services.Validation.Rules
{
	[TestFixture]
	public class PositiveDoubleValidationRuleTests
	{
        [Test]
        public void ShouldReturnTrue_When_Validate_With_Positive()
        {
            var rule = new PositiveDoubleValidationRule("error");

            // ACT
            var result = rule.Validate(1.0d);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_Zero()
        {
            var rule = new PositiveDoubleValidationRule("error");

            // ACT
            var result = rule.Validate(0);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }

		[Test]
        public void ShouldReturnFalse_When_Validate_With_Null()
        {
            var rule = new PositiveDoubleValidationRule("error");

            // ACT
            var result = rule.Validate(null);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }
	}
}
