﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Moq;
using NUnit.Framework;


namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Services
{
    internal interface IOptionalFieldsCheckServiceTestObjects
    {
        ManualCurveEditorViewModel ManualCurveEditor { get; }
        OptionalFieldsCheckService OptionalFieldsCheckService { get; }
    }

    [TestFixture]
    public class OptionalFieldsCheckServiceTests
    {
        private class OptionalFieldsCheckServiceTestObjectBuilder
        {
            private bool _applyMaxPeriodCount;
            private bool _applyOverrideUnitOfMeasure;
            private bool _applyOverrideLotSize;
            private bool _applyOverrideCurrency;
            private bool _applyOverrideCurrencyDenominationFactor;
            private bool _applyOverrideDensity;

            private int? _maxPeriodCount;
            private UnitOfMeasure? _overrideUnitOfMeasure;
            private int? _overrideLotSize;
            private CurrencyCodeItem _overrideCurrencyCode;
            private int? _overrideCurrencyDenominationFactor;
            private UnitOfMeasure? _overrideDensityUnitOfVolume;
            private double? _overrideDensityFactor;

            public OptionalFieldsCheckServiceTestObjectBuilder WithApplyMaxPeriodCount(bool value)
            {
                _applyMaxPeriodCount = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithApplyOverrideUnitOfMeasure(bool value)
            {
                _applyOverrideUnitOfMeasure = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithApplyOverrideLotSize(bool value)
            {
                _applyOverrideLotSize = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithApplyOverrideCurrency(bool value)
            {
                _applyOverrideCurrency = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithApplyOverrideCurrencyDenominationFactor(bool value)
            {
                _applyOverrideCurrencyDenominationFactor = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithApplyOverrideDensity(bool value)
            {
                _applyOverrideDensity = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithMaxPeriodCount(int? value)
            {
                _maxPeriodCount = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithOverrideUnitOfMeasure(UnitOfMeasure? value)
            {
                _overrideUnitOfMeasure = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithOverrideLotSize(int? value)
            {
                _overrideLotSize = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithOverrideCurrencyCode(CurrencyCodeItem value)
            {
                _overrideCurrencyCode = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithOverrideCurrencyDenominationFactor(int? value)
            {
                _overrideCurrencyDenominationFactor = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithOverrideDensityUnitOfVolume(UnitOfMeasure? value)
            {
                _overrideDensityUnitOfVolume = value;
                return this;
            }

            public OptionalFieldsCheckServiceTestObjectBuilder WithOverrideDensityFactor(double? value)
            {
                _overrideDensityFactor = value;
                return this;
            }

            public IOptionalFieldsCheckServiceTestObjects Build()
            {
                var testObjects = new Mock<IOptionalFieldsCheckServiceTestObjects>();

                var viewModel = new ManualCurveEditorViewModel
                                {
                                    ManualCurveOptionalFlags =
                                    {
                                        ApplyMaxPeriodCount = _applyMaxPeriodCount,
                                        ApplyOverrideUnitOfMeasure = _applyOverrideUnitOfMeasure,
                                        ApplyOverrideLotSize = _applyOverrideLotSize,
                                        ApplyOverrideCurrency = _applyOverrideCurrency,
                                        ApplyOverrideCurrencyDenominationFactor = _applyOverrideCurrencyDenominationFactor,
                                        ApplyOverrideDensity = _applyOverrideDensity
									},
                                    ManualPriceCurve =
                                    {
                                        MaxPeriodCount = _maxPeriodCount,
                                        OverrideUnitOfMeasure = _overrideUnitOfMeasure,
                                        OverrideLotSize = _overrideLotSize,
                                        OverrideCurrencyCode = _overrideCurrencyCode,
                                        OverrideCurrencyDenominationFactor = _overrideCurrencyDenominationFactor,
                                        OverrideDensityUnitOfVolume = _overrideDensityUnitOfVolume,
                                        OverrideDensityFactor = _overrideDensityFactor
                                    }
                                };

                testObjects.SetupGet(o => o.ManualCurveEditor)
                           .Returns(viewModel);

                var optionalFieldsCheckService = new OptionalFieldsCheckService();

                testObjects.SetupGet(o => o.OptionalFieldsCheckService)
                           .Returns(optionalFieldsCheckService);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldClearMaxPeriodCount_When_SetApplyMaxPeriodCountFalse()
        {
            var testObjects = new OptionalFieldsCheckServiceTestObjectBuilder().WithApplyMaxPeriodCount(true)
                                                                               .WithMaxPeriodCount(60)
                                                                               .Build();
            // ARRANGE
            testObjects.OptionalFieldsCheckService.SubscribeOptionalFieldChecks(testObjects.ManualCurveEditor.ManualCurveOptionalFlags,
                                                                                testObjects.ManualCurveEditor.ManualPriceCurve);

            // ACT
            testObjects.ManualCurveEditor.ManualCurveOptionalFlags.ApplyMaxPeriodCount = false;

            // ASSERT
            Assert.That(testObjects.ManualCurveEditor.ManualPriceCurve.MaxPeriodCount, Is.Null);
        }

        [Test]
        public void ShouldClearOverrideUnitOfMeasure_When_SetApplyOverrideUnitOfMeasureFalse()
        {
            var testObjects = new OptionalFieldsCheckServiceTestObjectBuilder().WithApplyOverrideUnitOfMeasure(true)
                                                                               .WithOverrideUnitOfMeasure(UnitOfMeasure.BBL)
                                                                               .Build();
            // ARRANGE
            testObjects.OptionalFieldsCheckService.SubscribeOptionalFieldChecks(testObjects.ManualCurveEditor.ManualCurveOptionalFlags,
                                                                                testObjects.ManualCurveEditor.ManualPriceCurve);

            // ACT
            testObjects.ManualCurveEditor.ManualCurveOptionalFlags.ApplyOverrideUnitOfMeasure = false;

            // ASSERT
            Assert.That(testObjects.ManualCurveEditor.ManualPriceCurve.OverrideUnitOfMeasure, Is.Null);
        }

        [Test]
        public void ShouldClearOverrideLotSize_When_SetApplyOverrideLotSize_False()
        {
            var testObjects = new OptionalFieldsCheckServiceTestObjectBuilder().WithApplyOverrideLotSize(true)
                                                                               .WithOverrideLotSize(1000)
                                                                               .Build();
            // ARRANGE
            testObjects.OptionalFieldsCheckService.SubscribeOptionalFieldChecks(testObjects.ManualCurveEditor.ManualCurveOptionalFlags,
                                                                                testObjects.ManualCurveEditor.ManualPriceCurve);

            // ACT
            testObjects.ManualCurveEditor.ManualCurveOptionalFlags.ApplyOverrideLotSize = false;

            // ASSERT
            Assert.That(testObjects.ManualCurveEditor.ManualPriceCurve.OverrideLotSize, Is.Null);
        }

        [Test]
        public void ShouldClearOverrideCurrencyCode_When_SetApplyOverrideCurrency_False()
        {
            var ccy = new CurrencyCode(1, "EUR");
			var ccyItem = new CurrencyCodeItem(ccy);

			var testObjects = new OptionalFieldsCheckServiceTestObjectBuilder().WithApplyOverrideCurrency(true)
                                                                               .WithOverrideCurrencyCode(ccyItem)
                                                                               .Build();
            // ARRANGE
            testObjects.OptionalFieldsCheckService.SubscribeOptionalFieldChecks(testObjects.ManualCurveEditor.ManualCurveOptionalFlags,
                                                                                testObjects.ManualCurveEditor.ManualPriceCurve);

            // ACT
            testObjects.ManualCurveEditor.ManualCurveOptionalFlags.ApplyOverrideCurrency = false;

            // ASSERT
            Assert.That(testObjects.ManualCurveEditor.ManualPriceCurve.OverrideCurrencyCode, Is.Null);
        }

        [Test]
        public void ShouldClearOverrideCurrencyDenominationFactor_When_SetApplyOverrideCurrencyDenominationFactor_False()
        {
            var testObjects = new OptionalFieldsCheckServiceTestObjectBuilder().WithApplyOverrideCurrencyDenominationFactor(true)
                                                                               .WithOverrideCurrencyDenominationFactor(2)
                                                                               .Build();
            // ARRANGE
            testObjects.OptionalFieldsCheckService.SubscribeOptionalFieldChecks(testObjects.ManualCurveEditor.ManualCurveOptionalFlags,
                                                                                testObjects.ManualCurveEditor.ManualPriceCurve);

            // ACT
            testObjects.ManualCurveEditor.ManualCurveOptionalFlags.ApplyOverrideCurrencyDenominationFactor = false;

            // ASSERT
            Assert.That(testObjects.ManualCurveEditor.ManualPriceCurve.OverrideCurrencyDenominationFactor, Is.Null);
        }

        [Test]
        public void ShouldClearOverrideDensity_When_SetApplyOverrideDensity_False()
        {
            var testObjects = new OptionalFieldsCheckServiceTestObjectBuilder().WithApplyOverrideDensity(true)
                                                                               .WithOverrideDensityUnitOfVolume(UnitOfMeasure.BBL)
                                                                               .WithOverrideDensityFactor(1.0d)
                                                                               .Build();
            // ARRANGE
            testObjects.OptionalFieldsCheckService.SubscribeOptionalFieldChecks(testObjects.ManualCurveEditor.ManualCurveOptionalFlags,
                                                                                testObjects.ManualCurveEditor.ManualPriceCurve);

            // ACT
            testObjects.ManualCurveEditor.ManualCurveOptionalFlags.ApplyOverrideDensity = false;

            // ASSERT
            Assert.That(testObjects.ManualCurveEditor.ManualPriceCurve.OverrideDensityUnitOfVolume, Is.Null);
            Assert.That(testObjects.ManualCurveEditor.ManualPriceCurve.OverrideDensityFactor, Is.Null);
        }
    }
}
