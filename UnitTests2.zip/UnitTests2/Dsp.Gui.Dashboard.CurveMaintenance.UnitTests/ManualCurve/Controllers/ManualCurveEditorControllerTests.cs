﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using System.Windows.Data;
using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ManualCurve.Controllers
{
    internal interface IManualCurveEditorControllerTestObjects
    {
        IManualCurveEditorToolBarService ToolBarService { get; }
        ISubject<Unit> ToolBarUndo { get; }
        ISubject<Unit> ToolBarUpdate { get; }
		ISubject<Unit> ToolBarCancelDraft { get; }
        ICurveControlService CurveControlService { get; }
        IManualPriceCurveDefinitionProvider ManualPriceCurveDefinitionProvider { get; }
        IManualPriceCurveTransformer ManualPriceCurveTransformer { get; }
		IPriceCurveDefinitionItemCollectionFactory ItemCollectionFactory { get; }
		IDraftCurveChangesService DraftCurveChangesService { get; }
		IDraftCurveChangesParser DraftCurveChangesParser { get; }
        IManualPriceCurveEditChangesService ManualPriceCurveEditChangesService { get; }
        ISubject<Unit> EditChanges { get; }
        IManualPriceCurveValidationService ManualPriceCurveValidationService { get; }
        ISubject<string> ManualPriceCurveValidation { get; }
        IOptionalFieldsCheckService OptionalFieldsCheckService { get; }
        IManualPriceCurveUnsetFieldsService UnsetFieldsService { get; }
        ISubject<Unit> UnsetFields { get; }
		ISubject<IEnumerable<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        ISubject<List<ProductDefinition>> ProductDefinitions { get; }
        ISubject<List<CurveGroup>> CurveGroups { get; }
        ISubject<List<CurrencyCode>> CurrencyCodes { get; }
        IManualPriceCurveUpdateService ManualPriceCurveUpdateService { get; }
		ISubject<AdminApiActionCompleted> ManualPriceCurveUpdateResponse { get; }
        ICurveDeletionService CurveDeletionService { get; }
		ISubject<AdminApiActionCompleted> CurveDeletionResponse { get; }
		ISubject<AdminApiActionCompleted> DraftCancellationResponse { get; }
		IDraftCurveItemMatchingService DraftCurveItemMatchingService { get; }
		ISubject<PriceCurveDefinitionStatusItem> ActiveCurveMatchingDraftItem { get; }
		ISubject<PriceCurveDefinitionStatusItem> ExistingDraftMatchingDraftItem { get; }
		ISubject<PriceCurveDefinitionStatusItem> NewCurveMatchingDraftItem { get; }
		IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        ILogger Logger { get; }
		ManualCurveEditorViewModel ViewModel { get; }
        ManualCurveEditorController Controller { get; }
    }

    [TestFixture]
    public class ManualCurveEditorControllerTests
    {
        private class ManualCurveEditorControllerTestObjectBuilder
        {
            private IEnumerable<PriceCurveDefinition> _priceCurveDefinitions;
			private List<ProductDefinition> _productDefinitions;
            private List<CurveGroup> _curveGroups;
            private bool _isCreateNewCurve;
            private User _currentUser;
			private List<PriceCurveDefinitionStatusItem> _itemCollectionFactoryResult = [];
			private Dictionary<string, object> _serviceDraftCurveChanges;
			private Dictionary<string, object> _parsedDraftCurveChanges;
			private Dictionary<string, object> _draftCurveChanges;
			
            public ManualCurveEditorControllerTestObjectBuilder WithPriceCurveDefinitions(IEnumerable<PriceCurveDefinition> values)
            {
                _priceCurveDefinitions = values;
                return this;
            }

            public ManualCurveEditorControllerTestObjectBuilder WithCurveGroups(List<CurveGroup> values)
            {
                _curveGroups = values;
                return this;
            }

            public ManualCurveEditorControllerTestObjectBuilder WithProductDefinitions(List<ProductDefinition> values)
            {
                _productDefinitions = values;
                return this;
            }

			public ManualCurveEditorControllerTestObjectBuilder WithIsCreateNewCurve(bool value)
            {
                _isCreateNewCurve = value;
                return this;
            }

            public ManualCurveEditorControllerTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

			public ManualCurveEditorControllerTestObjectBuilder WithItemCollectionFactoryResult(List<PriceCurveDefinitionStatusItem> values)
			{
				_itemCollectionFactoryResult = values;
				return this;
			}

			public ManualCurveEditorControllerTestObjectBuilder WithServiceDraftCurveChanges(Dictionary<string, object> values)
			{
				_serviceDraftCurveChanges = values;
				return this;
			}

			public ManualCurveEditorControllerTestObjectBuilder WithParsedDraftCurveChanges(Dictionary<string, object> values)
			{
				_parsedDraftCurveChanges = values;
				return this;
			}

			public ManualCurveEditorControllerTestObjectBuilder WithDraftCurveChanges(Dictionary<string, object> values)
			{
				_draftCurveChanges = values;
				return this;
			}

			public IManualCurveEditorControllerTestObjects Build()
            {
                var testObjects = new Mock<IManualCurveEditorControllerTestObjects>();

                var toolBarUpdate = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUpdate)
                           .Returns(toolBarUpdate);

                var toolBarUndo = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUndo)
                           .Returns(toolBarUndo);

				var toolBarCancel = new Subject<Unit>();

				testObjects.SetupGet(o => o.ToolBarCancelDraft)
						   .Returns(toolBarCancel);

                var toolBarService = new Mock<IManualCurveEditorToolBarService>();

                toolBarService.SetupGet(tb => tb.Update)
                              .Returns(toolBarUpdate);

                toolBarService.SetupGet(tb => tb.UndoChanges)
                              .Returns(toolBarUndo);

				toolBarService.SetupGet(tb => tb.CancelDraft)
							  .Returns(toolBarCancel);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBarService.Object);

                var productDefinitions = new BehaviorSubject<List<ProductDefinition>>(_productDefinitions);

                testObjects.SetupGet(o => o.ProductDefinitions)
                           .Returns(productDefinitions);

                var currencyCodes = new Subject<List<CurrencyCode>>();

                testObjects.SetupGet(o => o.CurrencyCodes)
                           .Returns(currencyCodes);
                
                var curveGroups = new BehaviorSubject<List<CurveGroup>>(_curveGroups);

                testObjects.SetupGet(o => o.CurveGroups)
                           .Returns(curveGroups);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ProductDefinitions)
                                   .Returns(productDefinitions);

                curveControlService.SetupGet(c => c.CurrencyCodes)
                                   .Returns(currencyCodes);

                curveControlService.SetupGet(c => c.CurveGroups)
                                  .Returns(curveGroups);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService.Object);

                curveControlService.SetupGet(c => c.ProductDefinitions)
                                   .Returns(productDefinitions);

                curveControlService.Setup(c => c.GetProductDefinitionsSnapshot())
                                   .Returns(_productDefinitions);

				curveControlService.Setup(c => c.GetPriceCurveDefinitionsSnapshot())
								   .Returns(_priceCurveDefinitions);

				curveControlService.SetupGet(c => c.CurrentUser)
								   .Returns(Observable.Return(_currentUser));

                var priceCurveDefinitions = new BehaviorSubject<IEnumerable<PriceCurveDefinition>>(_priceCurveDefinitions);

                testObjects.SetupGet(o => o.PriceCurveDefinitions)
                           .Returns(priceCurveDefinitions);

                var manualPriceCurveDefinitionProvider = new Mock<IManualPriceCurveDefinitionProvider>();

                manualPriceCurveDefinitionProvider.Setup(p => p.PriceCurveDefinitions(It.IsAny<IScheduler>()))
                                                  .Returns(priceCurveDefinitions);

                testObjects.SetupGet(o => o.ManualPriceCurveDefinitionProvider)
                           .Returns(manualPriceCurveDefinitionProvider.Object);

                var transformer = new Mock<IManualPriceCurveTransformer>();

                testObjects.SetupGet(o => o.ManualPriceCurveTransformer)
                           .Returns(transformer.Object);

				var itemCollectionFactory = new Mock<IPriceCurveDefinitionItemCollectionFactory>();

				testObjects.SetupGet(o => o.ItemCollectionFactory)
						   .Returns(itemCollectionFactory.Object);

				itemCollectionFactory.Setup(f => f.CreateCollection(It.IsAny<IList<PriceCurveDefinition>>(), It.IsAny<int>()))
									 .Returns(_itemCollectionFactoryResult);

				var editChanges = new Subject<Unit>();

				testObjects.SetupGet(o => o.EditChanges)
						   .Returns(editChanges);

				var editChangesService = new Mock<IManualPriceCurveEditChangesService>();

                editChangesService.Setup(c => c.ObserveChanged(It.IsAny<ManualPriceCurveViewModel>(),
															   It.IsAny<PriceCurveDefinition>(),
															   It.IsAny<ICollection<string>>()))
								  .Returns(editChanges);

				testObjects.SetupGet(o => o.ManualPriceCurveEditChangesService)
						   .Returns(editChangesService.Object);
					
				var validation = new Subject<string>();

                testObjects.SetupGet(o => o.ManualPriceCurveValidation)
                           .Returns(validation);

                var validationService = new Mock<IManualPriceCurveValidationService>();

                validationService.Setup(v => v.ObserveValidation(It.IsAny<ManualCurveEditorViewModel>()))
                                 .Returns(validation);

                testObjects.SetupGet(o => o.ManualPriceCurveValidationService)
                           .Returns(validationService.Object);

                var optionalFieldsCheckService = new Mock<IOptionalFieldsCheckService>();

                optionalFieldsCheckService.Setup(o => o.SubscribeOptionalFieldChecks(It.IsAny<ManualCurveOptionalFlags>(),
                                                                                     It.IsAny<ManualPriceCurveViewModel>()))
                                          .Returns(Disposable.Empty);

                testObjects.SetupGet(o => o.OptionalFieldsCheckService)
                           .Returns(optionalFieldsCheckService.Object);

                #region WorkflowAction Services

                var manualPriceCurveUpdateResponse = new Subject<AdminApiActionCompleted>();

                testObjects.SetupGet(o => o.ManualPriceCurveUpdateResponse)
                           .Returns(manualPriceCurveUpdateResponse);

                var manualPriceCurveUpdateService = new Mock<IManualPriceCurveUpdateService>();

                manualPriceCurveUpdateService.Setup(m => m.UpdateManualPriceCurveDefinition(It.IsAny<ManualPriceCurveViewModel>(),
                                                                                            It.IsAny<ManualCurveOptionalFlags>(),
                                                                                            It.IsAny<int>(),
																							It.IsAny<IScheduler>()))
                                             .Returns(manualPriceCurveUpdateResponse);

                manualPriceCurveUpdateService.Setup(m => m.CreateManualPriceCurveDefinition(It.IsAny<ManualPriceCurveViewModel>(),
                                                                                            It.IsAny<ManualCurveOptionalFlags>(),
																							It.IsAny<IScheduler>()))
                                             .Returns(manualPriceCurveUpdateResponse);

				testObjects.SetupGet(o => o.ManualPriceCurveUpdateService)
                           .Returns(manualPriceCurveUpdateService.Object);

				var curveDeletionResponse = new Subject<AdminApiActionCompleted>();

				testObjects.SetupGet(o => o.CurveDeletionResponse)
						   .Returns(curveDeletionResponse);

				var draftCancellationResponse = new Subject<AdminApiActionCompleted>();

				testObjects.SetupGet(o => o.DraftCancellationResponse)
						   .Returns(draftCancellationResponse);

				var curveDeletionService = new Mock<ICurveDeletionService>();

				curveDeletionService.Setup(d => d.DeleteCurve(It.IsAny<int>(), 
															  It.IsAny<AdminCurveType>(), 
															  It.IsAny<IScheduler>()))
									.Returns(curveDeletionResponse);

				curveDeletionService.Setup(d => d.CancelCurve(It.IsAny<int>(),
															  It.IsAny<AdminCurveType>(),
															  It.IsAny<IScheduler>()))
									.Returns(draftCancellationResponse);

				testObjects.SetupGet(o => o.CurveDeletionService)
						   .Returns(curveDeletionService.Object);

                #endregion

                #region Draft Item Matching

				var activeCurveMatchingDraftItem = new Subject<PriceCurveDefinitionStatusItem>();

				testObjects.SetupGet(o => o.ActiveCurveMatchingDraftItem)
						   .Returns(activeCurveMatchingDraftItem);


				var existingDraftMatchingDraftItem = new Subject<PriceCurveDefinitionStatusItem>();

				testObjects.SetupGet(o => o.ExistingDraftMatchingDraftItem)
						   .Returns(existingDraftMatchingDraftItem);


				var newCurveMatchingDraftItem = new Subject<PriceCurveDefinitionStatusItem>();

				testObjects.SetupGet(o => o.NewCurveMatchingDraftItem)
						   .Returns(newCurveMatchingDraftItem);


				var draftCurveItemMatchingService = new Mock<IDraftCurveItemMatchingService>();

				draftCurveItemMatchingService.Setup(d => d.ActiveCurveMatchingDraftItem(It.IsAny<IObservable<IList<PriceCurveDefinitionStatusItem>>>(),
																						It.IsAny<int>()))
											 .Returns(activeCurveMatchingDraftItem);

				draftCurveItemMatchingService.Setup(d => d.ExistingDraftMatchingDraftItem(It.IsAny<IObservable<IList<PriceCurveDefinitionStatusItem>>>(),
																						  It.IsAny<int>()))
											 .Returns(existingDraftMatchingDraftItem);


				draftCurveItemMatchingService.Setup(d => d.NewCurveMatchingDraftItem(It.IsAny<IObservable<IList<PriceCurveDefinitionStatusItem>>>(),
																					 It.IsAny<string>()))
											 .Returns(newCurveMatchingDraftItem);

				testObjects.SetupGet(o => o.DraftCurveItemMatchingService)
						   .Returns(draftCurveItemMatchingService.Object);

                #endregion

                var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialog = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialog.Object);

                var unsetFields = new Subject<Unit>();

                testObjects.SetupGet(o => o.UnsetFields)
						   .Returns(unsetFields);

                var unsetFieldsService = new Mock<IManualPriceCurveUnsetFieldsService>();

                unsetFieldsService.Setup(u => u.ObserveUnsetFields(It.IsAny<ManualPriceCurveViewModel>(),
                                                                   It.IsAny<IList<string>>()))
                                  .Returns(unsetFields);

                testObjects.SetupGet(o => o.UnsetFieldsService)
                           .Returns(unsetFieldsService.Object);

				var draftCurveChangesService = new Mock<IDraftCurveChangesService>();

				draftCurveChangesService.Setup(d => d.GetDraftCurveChanges(It.IsAny<ManualPriceCurveViewModel>(),
																		   It.IsAny<PriceCurveDefinition>()))
										.Returns(_serviceDraftCurveChanges);

				testObjects.SetupGet(o => o.DraftCurveChangesService)
						   .Returns(draftCurveChangesService.Object);

				var draftCurveChangesParser = new Mock<IDraftCurveChangesParser>();

				draftCurveChangesParser.Setup(p => p.ParseChanges(It.IsAny<Dictionary<string, object>>()))
									   .Returns(_parsedDraftCurveChanges);

				testObjects.SetupGet(o => o.DraftCurveChangesParser)
						   .Returns(draftCurveChangesParser.Object);

				var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

                var controller = new ManualCurveEditorController(manualPriceCurveDefinitionProvider.Object,
                                                                 curveControlService.Object,
                                                                 toolBarService.Object,
                                                                 TestMocks.GetSchedulerProvider().Object,
                                                                 TestMocks.GetLoggerFactory(logger).Object)
                                 {
                                     ItemCollectionFactory = itemCollectionFactory.Object,
                                     EditChangesService = editChangesService.Object,
                                     ValidationService = validationService.Object,
                                     OptionalFieldsCheckService = optionalFieldsCheckService.Object,
                                     UnsetFieldsService = unsetFieldsService.Object,
                                     Transformer = transformer.Object,
									 ManualPriceCurveUpdateService = manualPriceCurveUpdateService.Object,
                                     CurveDeletionService = curveDeletionService.Object,
                                     DraftCurveItemMatchingService = draftCurveItemMatchingService.Object,
                                     DraftCurveChangesService = draftCurveChangesService.Object,
                                     DraftCurveChangesParser = draftCurveChangesParser.Object,
									 PopupNotificationService = popupNotificationService.Object,
									 ErrorMessageDialogService = errorMessageDialog.Object
                                 };

                controller.ViewModel.IsCreateNewCurve = _isCreateNewCurve;
				controller.ViewModel.DraftChanges = _draftCurveChanges;

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region Construction

        [Test]
        public void ShouldPopulateViewModel()
        {
            // ACT
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.True);

            Assert.That(testObjects.ViewModel.UnsetFields, Is.Not.Null);
            Assert.That(testObjects.ViewModel.EditChanges, Is.Not.Null);
            Assert.That(testObjects.ViewModel.CurveTypes, Is.Not.Null);

            Assert.That(testObjects.ViewModel.CurveRegions, Is.Not.Null);
            Assert.That(testObjects.ViewModel.CurveRegions.Contains(CurveRegion.None), Is.False);

            Assert.That(testObjects.ViewModel.UnitsOfMeasure, Is.Not.Null);
            Assert.That(testObjects.ViewModel.UnitsOfMeasure.Contains(UnitOfMeasure.None), Is.False);
        }

        #endregion

        #region Initialize

        [Test]
        public void ShouldShowLoading_And_SubscribeComboItemsSources_On_InitializeCommand()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);

            Mock.Get(testObjects.CurveControlService)
                .Verify(c => c.SubscribeProductDefinitions());

            Mock.Get(testObjects.CurveControlService)
                .Verify(c => c.SubscribeCurrencyCodes());

            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.ProductDefinitions);

            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.CurveGroups);

            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.CurrencyCodes);

            Mock.Get(testObjects.ManualPriceCurveDefinitionProvider)
                .Verify(p => p.PriceCurveDefinitions(It.IsAny<IScheduler>()));
        }

        [Test]
        public void ShouldNotInitialize_When_Initialized()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsBusy = false;

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

		#endregion

		#region Populate Combos

		[Test]
		public void ShouldPopulatePriceCurveCombo_On_Initialize_With_PriceCurveDefinitions_And_CurrentUser()
		{
			var user = new UserBuilder().WithId(10).User();

			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().Build();
			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().Build();

			var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var items = new List<PriceCurveDefinitionStatusItem>
						{
							new(priceCurveDefinition1),
							new(priceCurveDefinition2)
						};

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithCurrentUser(user)
																				.WithPriceCurveDefinitions(priceCurveDefinitions)
																				.WithItemCollectionFactoryResult(items)
																				.Build();

            // ACT
			testObjects.ViewModel.InitializeCommand.Execute();

			// ASSERT
			Mock.Get(testObjects.ItemCollectionFactory)
				.Verify(f => f.CreateCollection(It.Is<List<PriceCurveDefinition>>(c => c.Count == 2), 10));

			var sourceCollection = testObjects.ViewModel.PriceCurveDefinitions.SourceCollection.Cast<PriceCurveDefinitionStatusItem>();

			Assert.That(sourceCollection.Count, Is.EqualTo(2));

			Assert.That(testObjects.ViewModel.PriceCurveDefinitions.GroupDescriptions.Count, Is.EqualTo(1));

			var description = testObjects.ViewModel.PriceCurveDefinitions.GroupDescriptions[0] as PropertyGroupDescription;

			Assert.That(description, Is.Not.Null);
			Assert.That(description.PropertyName, Is.EqualTo("IsDraftCurrentUser"));
		}

		[Test]
        public void ShouldPopulatePriceCurveCombo_On_PriceCurveDefinitions_With_CurrentUser()
		{
			var user = new UserBuilder().WithId(10).User();

            var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().Build();
            var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().Build();

			var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var items = new List<PriceCurveDefinitionStatusItem>
						{
							new(priceCurveDefinition1),
							new(priceCurveDefinition2)
						};

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithCurrentUser(user)
																				.WithItemCollectionFactoryResult(items)
																				.Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.PriceCurveDefinitions.OnNext(priceCurveDefinitions);

            // ASSERT
            Mock.Get(testObjects.ItemCollectionFactory)
                .Verify(f => f.CreateCollection(It.Is<List<PriceCurveDefinition>>(c => c.Count == 2), 10));

			var sourceCollection = testObjects.ViewModel.PriceCurveDefinitions.SourceCollection.Cast<PriceCurveDefinitionStatusItem>();

			Assert.That(sourceCollection.Count, Is.EqualTo(2));

            Assert.That(testObjects.ViewModel.PriceCurveDefinitions.GroupDescriptions.Count, Is.EqualTo(1));

			var description = testObjects.ViewModel.PriceCurveDefinitions.GroupDescriptions[0] as PropertyGroupDescription;

            Assert.That(description, Is.Not.Null);
            Assert.That(description.PropertyName, Is.EqualTo("IsDraftCurrentUser"));
		}

        [Test]
        public void ShouldPopulateCurrencyCodesCombo_On_CurrencyCodes()
        {
			var ccy1 = new CurrencyCode(1, "EUR");
			var ccy2 = new CurrencyCode(2, "USD");

			var currencies = new List<CurrencyCode> { ccy1, ccy2 };


            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.CurrencyCodes.OnNext(currencies);

            // ASSERT
            Assert.That(testObjects.ViewModel.CurrencyCodes.Count , Is.EqualTo(2));
        }

        [Test]
        public void ShouldPopulateProductsCombo_On_Products()
        {
            var product1 = new ProductDefinitionTestObjectBuilder().WithName("product-1").Build();
            var product2 = new ProductDefinitionTestObjectBuilder().WithName("product-2").Build();

            var products = new List<ProductDefinition> { product1, product2 };

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ProductDefinitions.OnNext(products);

            // ASSERT
            Assert.That(testObjects.ViewModel.ProductDefinitions.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldHideLoading_On_CombosLoaded()
        {
			var user = new UserBuilder().WithId(10).User();
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();
            var currencyCode = new CurrencyCode(1, "USD");
            var product = new ProductDefinitionTestObjectBuilder().Build();
			
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithCurrentUser(user)
																				.Build();
            var curveGroup = new CurveGroup();
           
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.PriceCurveDefinitions.OnNext([priceCurveDefinition]);
            testObjects.CurrencyCodes.OnNext([currencyCode]);
            testObjects.ProductDefinitions.OnNext([product]);
            testObjects.CurveGroups.OnNext([curveGroup]);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
        }

        #endregion

        #region Toggle Create New

        [Test]
        public void ShouldRestoreDefaultsAndEnableEditors_On_CreateNewCurve()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
            Assert.That(testObjects.ViewModel.IsReadonly, Is.False);

            Assert.That(testObjects.ViewModel.ManualPriceCurve.DsxLotSize, Is.EqualTo(1000));

            Mock.Get(testObjects.ManualPriceCurveValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel));

            Mock.Get(testObjects.OptionalFieldsCheckService)
                .Verify(o => o.SubscribeOptionalFieldChecks(testObjects.ViewModel.ManualCurveOptionalFlags,
                                                            testObjects.ViewModel.ManualPriceCurve));
        }

        [Test]
        public void ShouldRestoreAndSubscribeUnsetFields_On_CreateNewCurve()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            var expected = new[]
                           {
                               nameof(ManualPriceCurveViewModel.Name),
                               nameof(ManualPriceCurveViewModel.Description),
                               nameof(ManualPriceCurveViewModel.CurveType),
                               nameof(ManualPriceCurveViewModel.ProductDefinition),
                               nameof(ManualPriceCurveViewModel.CurveRegion),
                               nameof(ManualPriceCurveViewModel.DsxUnitOfMeasure)
                           };

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.UnsetFields.SequenceEqual(expected));

            Mock.Get(testObjects.UnsetFieldsService)
                .Verify(u => u.ObserveUnsetFields(testObjects.ViewModel.ManualPriceCurve,
                                                  testObjects.ViewModel.UnsetFields));
		}

		[Test]
        public void ShouldClearPriceCurve_On_CreateNewCurve_With_SelectedPriceCurveEditChanges()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
            testObjects.ViewModel.EditChanges.Add(nameof(ManualPriceCurveViewModel.DsxLotSize));

            // ACT
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedCurveDefinitionStatus, Is.Null);
            Assert.That(testObjects.ViewModel.EditChanges, Is.Empty);

            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.ClearPriceCurve(testObjects.ViewModel));
		}

		[Test]
		public void ShouldSetIsDeleteCurveFalse_On_CreateNewCurve_With_SelectedPriceCurve_IsDeleteCurveTrue()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.IsDeleteCurve = true;

			// ACT
			testObjects.ViewModel.IsCreateNewCurve = true;

			// ASSERT
			Assert.That(testObjects.ViewModel.CanDeleteCurve, Is.False);
			Assert.That(testObjects.ViewModel.IsDeleteCurve, Is.False);
		}

		[Test]
        public void ShouldDisableEditors_On_CreateNewCurveFalse()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithIsCreateNewCurve(true)
                                                                                .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.IsCreateNewCurve = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.False);
            Assert.That(testObjects.ViewModel.IsReadonly, Is.True);

            Mock.Get(testObjects.ManualPriceCurveValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel), Times.Never);

            Mock.Get(testObjects.OptionalFieldsCheckService)
                .Verify(o => o.SubscribeOptionalFieldChecks(testObjects.ViewModel.ManualCurveOptionalFlags,
                                                            testObjects.ViewModel.ManualPriceCurve), Times.Never);
        }

		#endregion

		#region Maintain Existing - Selected Price Curve Definition

		[Test]
        public void ShouldEnableEditPriceCurveBehaviors_On_PriceCurveDefinitionSelected_With_ActiveCurve()
        {
            var curveGroups = new List<CurveGroup>();
          
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();
          
            var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
                                                                                .WithProductDefinitions([])
                                                                                .WithCurveGroups([]) 
                                                                                .Build();
            // ARRANGE  
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT  
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ASSERT  
            Assert.That(testObjects.ViewModel.CanDeleteCurve, Is.True);

            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel, item.CurveDefinition, curveGroups)); 

            Mock.Get(testObjects.ManualPriceCurveEditChangesService)
                .Verify(o => o.ObserveChanged(testObjects.ViewModel.ManualPriceCurve,
                                              item.CurveDefinition,
                                              testObjects.ViewModel.EditChanges));

            Mock.Get(testObjects.ManualPriceCurveValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel));

            Mock.Get(testObjects.OptionalFieldsCheckService)
                .Verify(o => o.SubscribeOptionalFieldChecks(testObjects.ViewModel.ManualCurveOptionalFlags,
                                                            testObjects.ViewModel.ManualPriceCurve));

            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
        }

		[Test]
        public void ShouldEnableEditPriceCurveBehaviors_On_CurveGroupUpdate()
        {
            var curveGroups = new List<CurveGroup>();
            var curveGroups2 = new List<CurveGroup>();
            
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();
            var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
                                                                                .WithProductDefinitions([])
                                                                                .WithCurveGroups(curveGroups)
                                                                                .Build();
            // ARRANGE  
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            Mock.Get(testObjects.ManualPriceCurveTransformer).Invocations.Clear();
            Mock.Get(testObjects.ManualPriceCurveEditChangesService).Invocations.Clear();
            Mock.Get(testObjects.ManualPriceCurveEditChangesService).Invocations.Clear();
            Mock.Get(testObjects.ManualPriceCurveValidationService).Invocations.Clear();
            Mock.Get(testObjects.OptionalFieldsCheckService).Invocations.Clear();
            Mock.Get(testObjects.OptionalFieldsCheckService).Invocations.Clear();

            // ACT  

            testObjects.CurveGroups.OnNext(curveGroups2);

            // ASSERT  
            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel, item.CurveDefinition, curveGroups));

            Mock.Get(testObjects.ManualPriceCurveEditChangesService)
                .Verify(o => o.ObserveChanged(testObjects.ViewModel.ManualPriceCurve,
                                              item.CurveDefinition,
                                              testObjects.ViewModel.EditChanges));

            Mock.Get(testObjects.ManualPriceCurveValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel));

            Mock.Get(testObjects.OptionalFieldsCheckService)
                .Verify(o => o.SubscribeOptionalFieldChecks(testObjects.ViewModel.ManualCurveOptionalFlags,
                                                            testObjects.ViewModel.ManualPriceCurve));

            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
        }

        [Test]
        public void ShouldNotTransformPriceCurve_WhenSelectCurveDefinition_With_CurveGroupsNull()
        {

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();
            var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
                                                                                .WithProductDefinitions([])
                                                                                .WithCurveGroups(null)
                                                                                .Build();
            // ARRANGE  
            testObjects.ViewModel.InitializeCommand.Execute();

            //ACT
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
                    
            // ASSERT  
            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel, item.CurveDefinition, It.IsAny<List<CurveGroup>>()) , Times.Never);

        }

        [Test]
		public void ShouldClearEditChanges_On_PriceCurveDefinitionSelected_With_EditChanges()
		{
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().Build();
			var item1 = new PriceCurveDefinitionStatusItem(priceCurveDefinition1);

			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().Build();
			var item2 = new PriceCurveDefinitionStatusItem(priceCurveDefinition2);

			var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurveDefinitions)
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item1;
            testObjects.ViewModel.EditChanges.Add(nameof(ManualPriceCurveViewModel.DsxLotSize));

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item2;

			// ASSERT
            Assert.That(testObjects.ViewModel.EditChanges, Is.Empty);
		}

		[Test]
		public void ShouldResetIsDeleteCurve_On_PriceCurveDefinitionSelected_With_IsDeleteCurveTrue()
		{
			var priceCurveDefinition1 = new PriceCurveDefinitionTestObjectBuilder().Build();
			var item1 = new PriceCurveDefinitionStatusItem(priceCurveDefinition1);

			var priceCurveDefinition2 = new PriceCurveDefinitionTestObjectBuilder().Build();
			var item2 = new PriceCurveDefinitionStatusItem(priceCurveDefinition2);

			var priceCurveDefinitions = new[] { priceCurveDefinition1, priceCurveDefinition2 };

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions(priceCurveDefinitions)
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item1;

			testObjects.ViewModel.IsDeleteCurve = true;

			Mock.Get(testObjects.ToolBarService).Invocations.Clear();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item2;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsDeleteCurve, Is.False);

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUndoChanges(false));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUpdate(false));
		}

		[Test]
		public void ShouldSetIsReadyOnlyTrue_On_OtherUserDraftCurveSelected()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, false, true);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsReadonly, Is.True);
		}

        [Test]
		public void ShouldSetIsReadyOnlyTrue_On_ActivePendingApprovalCurveSelected()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, false, false, true);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsReadonly, Is.True);
		}

		[Test]
		public void ShouldSetIsReadyOnlyFalse_On_CurrentUserDraftCurveSelected()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, true);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsReadonly, Is.False);
		}

		[Test]
		public void ShouldSetIsReadyOnlyFalse_On_ActiveNonPendingApprovalCurveSelected()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsReadonly, Is.False);
		}

		[Test]
		public void ShouldSetIsReadyOnlyFalse_And_IsDraftSelectedTrue_On_CurrentUserDraftCurveSelected()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, true);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ASSERT
            Assert.That(testObjects.ViewModel.IsReadonly, Is.False);
            Assert.That(testObjects.ViewModel.IsDraftSelected, Is.True);
		}

		[TestCase(true, false)]
		[TestCase(false, true)]
		public void ShouldSetIsDraftSelectedTrue_On_DraftCurveSelected(bool isCurrentUserDraft, bool isOtherUserDraft)
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, isCurrentUserDraft, isOtherUserDraft);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsDraftSelected, Is.True);
		}

        [Test]
		public void ShouldSetIsDraftSelectedFalse_On_ActiveCurveSelected()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsDraftSelected, Is.False);
		}

		[Test]
        public void ShouldFilterProductsByPricingTenorGroup_On_PriceCurveDefinitionSelected()
        {
           
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                                  .Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

            var product1 = new ProductDefinitionTestObjectBuilder().WithPricingTenorGroupType(PricingTenorGroupType.Monthly)
                                                                   .Build();
            			
			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
                                                                                .WithProductDefinitions([product1])
                                                                                .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ASSERT
            Assert.That(testObjects.ViewModel.ProductDefinitions.Count, Is.EqualTo(1));
			Assert.That(testObjects.ViewModel.ProductDefinitions[0].ProductDefinition, Is.SameAs(product1));
		}

        [TestCase(true, false, false)]
		[TestCase(false, false, false)]
		public void ShouldObserveChanges_On_Editable_SelectedPriceCurve(bool isDraftCurrentUser, bool isDraftOtherUser, bool isActivePendingApproval)
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, isDraftCurrentUser, isDraftOtherUser, isActivePendingApproval);

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithProductDefinitions([])
																				.WithPriceCurveDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ASSERT
            Mock.Get(testObjects.ManualPriceCurveEditChangesService)
                .Verify(o => o.ObserveChanged(testObjects.ViewModel.ManualPriceCurve, 
											  item.CurveDefinition, 
											  testObjects.ViewModel.EditChanges));
        }

		[TestCase(false, true, false)]
		[TestCase(false, false, true)]
		public void ShouldNotObserveChanges_On_NonEditable_SelectedPriceCurve(bool isDraftCurrentUser, bool isDraftOtherUser, bool isActivePendingApproval)
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, isDraftCurrentUser, isDraftOtherUser, isActivePendingApproval);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithProductDefinitions([])
																				.WithPriceCurveDefinitions([])
																				.Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT
			Mock.Get(testObjects.ManualPriceCurveEditChangesService)
				.Verify(o => o.ObserveChanged(testObjects.ViewModel.ManualPriceCurve, 
											  item.CurveDefinition, 
											  testObjects.ViewModel.EditChanges), Times.Never);
		}

		#endregion

		#region Display Draft Changes

		[Test]
		public void ShouldSetDraftChanges_On_SelectedDraftCurve_With_ActiveCurve()
		{
			var activeCurve = new PriceCurveDefinitionTestObjectBuilder().WithPendingCurveId(103).Build();
			var otherCurve = new PriceCurveDefinitionTestObjectBuilder().Build();
			var draftCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(103).Build();

			var priceCurveDefinitions = new[] { draftCurve, otherCurve, activeCurve };

			var item = new PriceCurveDefinitionStatusItem(draftCurve, true, false, true);

			var draftChanges = new Dictionary<string, object> { { "CcyCode", 1 } };
			var parsedDraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .WithPriceCurveDefinitions(priceCurveDefinitions)
																				.WithServiceDraftCurveChanges(draftChanges)
																				.WithParsedDraftCurveChanges(parsedDraftChanges)
																				.Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ASSERT
            Mock.Get(testObjects.DraftCurveChangesService)
				.Verify(d => d.GetDraftCurveChanges(testObjects.ViewModel.ManualPriceCurve, activeCurve));

            Mock.Get(testObjects.DraftCurveChangesParser)
				.Verify(p => p.ParseChanges(draftChanges));

            Assert.That(testObjects.ViewModel.DraftChanges, Is.SameAs(parsedDraftChanges));
		}

		[Test]
		public void ShouldClearDraftChanges_On_SelectedDraftCurve_With_CreateNew()
		{
			var otherCurve = new PriceCurveDefinitionTestObjectBuilder().Build();
			var draftCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(103).Build();

			var priceCurveDefinitions = new[] { draftCurve, otherCurve };

			var item = new PriceCurveDefinitionStatusItem(draftCurve, true, false, true);

			var draftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .WithPriceCurveDefinitions(priceCurveDefinitions)
																				.WithDraftCurveChanges(draftChanges)
																				.Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT
			Mock.Get(testObjects.DraftCurveChangesService)
				.Verify(d => d.GetDraftCurveChanges(testObjects.ViewModel.ManualPriceCurve, It.IsAny<PriceCurveDefinition>()), Times.Never());

            Assert.That(testObjects.ViewModel.DraftChanges, Is.Empty);
		}

		[Test]
		public void ShouldClearDraftChanges_On_CreateNew_With_SelectedDraftActiveCurve()
		{
			var activeCurve = new PriceCurveDefinitionTestObjectBuilder().WithPendingCurveId(103).Build();
			var otherCurve = new PriceCurveDefinitionTestObjectBuilder().Build();
			var draftCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(103).Build();

			var priceCurveDefinitions = new[] { draftCurve, otherCurve, activeCurve };

			var item = new PriceCurveDefinitionStatusItem(draftCurve, true, false, true);

			var parsedDraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithProductDefinitions([])
																				.WithPriceCurveDefinitions(priceCurveDefinitions)
																				.WithServiceDraftCurveChanges([])
																				.WithParsedDraftCurveChanges(parsedDraftChanges)
																				.Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ACT
			testObjects.ViewModel.IsCreateNewCurve = true;

			// ASSERT
			Assert.That(testObjects.ViewModel.DraftChanges, Is.Empty);
		}

		#endregion

		#region Cancel Draft

		[Test]
		public void ShouldHideCancelButton_On_PriceCurveDefinitionSelected_With_NonDraft()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();
			// ARRANGE  
			testObjects.ViewModel.InitializeCommand.Execute();

			Mock.Get(testObjects.ToolBarService).Invocations.Clear();

			// ACT  
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT  
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetShowCancelButton(false));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanCancelDraft(false));

		}

		[Test]
		public void ShouldShowCancelButton_On_CurrentUserDraftPriceCurveDefinitionSelected_With_IsDraftCurrentUser()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition)
			{
				IsDraftCurrentUser = true
			};

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();
			// ARRANGE  
			testObjects.ViewModel.InitializeCommand.Execute();

			Mock.Get(testObjects.ToolBarService).Invocations.Clear();

			// ACT  
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ASSERT  
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetShowCancelButton(true));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanCancelDraft(true));

		}

		[Test]
		public void ShouldDisableEditor_And_ShowDialog_On_ToolBarCancelDraft()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition)
			{
				IsDraftCurrentUser = true
			};

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();
			// ARRANGE  
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.DraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };

			// ACT
			testObjects.ToolBarCancelDraft.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.CancelDraftDialogPrompt.ShowDialog, Is.True);
			Assert.That(testObjects.ViewModel.DraftChanges, Is.Empty);
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.False);
		}

		[Test]
		public void ShouldHideDialog_And_RestoreEditor_OnCancelDraftNo()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition)
			{
				IsDraftCurrentUser = true
			};

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();
			// ARRANGE  
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.DraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };

			testObjects.ToolBarCancelDraft.OnNext(Unit.Default);

			// ACT
			testObjects.ViewModel.CancelDraftDialogPrompt.DialogNoCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.CancelDraftDialogPrompt.ShowDialog, Is.False);
			Assert.That(testObjects.ViewModel.DraftChanges.Count, Is.EqualTo(1));
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);

		}

		[Test]
		public void ShouldHideDialog_And_CancelDraft_OnCancelDraftYes()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition)
			{
				IsDraftCurrentUser = true
			};

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();
			// ARRANGE  
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.DraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };

			testObjects.ToolBarCancelDraft.OnNext(Unit.Default);

			// ACT
			testObjects.ViewModel.CancelDraftDialogPrompt.DialogYesCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.CancelDraftDialogPrompt.ShowDialog, Is.False);
			Assert.That(testObjects.ViewModel.IsBusy, Is.True);

			Mock.Get(testObjects.CurveDeletionService)
				.Verify(m => m.CancelCurve(101, AdminCurveType.Manual, It.IsAny<IScheduler>()));
		}

		[Test]
		public void ShouldShowErrorDialog_And_RestoreEditor_OnCancelDraftError()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition)
					   {
						   IsDraftCurrentUser = true
					   };

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();
			// ARRANGE  
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.DraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };
			testObjects.ToolBarCancelDraft.OnNext(Unit.Default);

			testObjects.ViewModel.CancelDraftDialogPrompt.DialogYesCommand.Execute();

			// ACT
			testObjects.DraftCancellationResponse.OnError(new Exception());

			// ASSERT
			Mock.Get(testObjects.ErrorMessageDialogService)
				.Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));

			Assert.That(testObjects.ViewModel.IsBusy, Is.False);
			Assert.That(testObjects.ViewModel.DraftChanges.Count, Is.EqualTo(1));
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
		}

		[Test]
		public void ShouldShowPopup_And_ClearEditor_OnCancelDraftCompleted()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition)
					   {
						   IsDraftCurrentUser = true
					   };

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();
			// ARRANGE  
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.DraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };
			testObjects.ToolBarCancelDraft.OnNext(Unit.Default);

			testObjects.ViewModel.CancelDraftDialogPrompt.DialogYesCommand.Execute();

			// ACT
			testObjects.DraftCancellationResponse.OnNext(new AdminApiActionCompleted());

			// ASSERT
			Mock.Get(testObjects.PopupNotificationService)
				.Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));

			Assert.That(testObjects.ViewModel.CancelDraftDialogPrompt.ShowDialog, Is.False);

			Assert.That(testObjects.ViewModel.DraftChanges, Is.Empty);

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetShowCancelButton(false));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanCancelDraft(false));

			Mock.Get(testObjects.ManualPriceCurveTransformer)
				.Verify(t => t.ClearPriceCurve(testObjects.ViewModel));

			Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.True);
			Assert.That(testObjects.ViewModel.SelectedCurveDefinitionStatus, Is.Null);
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.False);
		}

		[Test]
		public void ShouldShowMessageDialog_OnCancelDraftCompleted_With_Warnings()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition)
					   {
						   IsDraftCurrentUser = true
					   };

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();
			// ARRANGE  
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.DraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };
			testObjects.ToolBarCancelDraft.OnNext(Unit.Default);

			testObjects.ViewModel.CancelDraftDialogPrompt.DialogYesCommand.Execute();

			// ACT
			testObjects.DraftCancellationResponse.OnNext(new AdminApiActionCompleted("warning"));

			// ASSERT
			Mock.Get(testObjects.ErrorMessageDialogService)
				.Verify(p => p.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
		}

		#endregion

		#region Selected Price Curve - Edit Changes

		[Test]
        public void ShouldEnableToolbarUndoAndUpdate_On_EditChanges_With_NoErrors()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
            testObjects.ViewModel.EditChanges.Add(nameof(ManualPriceCurveViewModel.DsxLotSize));

            // ACT
            testObjects.EditChanges.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
            Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.False);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(true));

			Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldDisableToolbarUndoAndUpdate_On_EditChangesEmpty_With_NoErrors()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ACT
            testObjects.EditChanges.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
            Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.True);

			Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(false));

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
		}

		#endregion

		#region Selected Price Curve - Delete

		[Test]
		public void ShouldEnableToolbarUndoAndUpdate_And_SetCurveFieldsEnabledFalse_When_DeleteCurve_With_Selected()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ACT
			testObjects.ViewModel.IsDeleteCurve = true;

			// ASSERT
			Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.True);
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.False);
		
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUndoChanges(true));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUpdate(true));
		}

		[Test]
		public void ShouldDisableToolbarUndoAndUpdate_And_SetCurveFieldsEnabledTrue_When_RevertDeleteCurve_With_Selected()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.IsDeleteCurve = true;

			Mock.Get(testObjects.ToolBarService).Invocations.Clear();

			// ACT
			testObjects.ViewModel.IsDeleteCurve = false;

			// ASSERT
			Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.True);
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUndoChanges(false));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUpdate(false));
		}

		#endregion

		#region Validation - Errors and ToolBarUndo

		[Test]
        public void ShouldInvokeViewModelErrors_On_Validation()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

			string result = null;

            // ARRANGE
            testObjects.ViewModel.ManualPriceCurve.ErrorsChanged += (_, args) => { result = args.PropertyName; };

            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ASSERT
            testObjects.ManualPriceCurveValidation.OnNext("Name");

            // ASSERT
            Assert.That(result, Is.EqualTo("Name"));
        }

        [Test]
        public void ShouldEnableToolBarUndo_On_ManualPriceCurveValidation_With_SelectedCurveErrors()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			
			testObjects.ViewModel.ManualPriceCurve.Errors.Add("Name", ["error"]);

            // ACT
            testObjects.ManualPriceCurveValidation.OnNext("Name");

			// ASSERT
			Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.False);

			Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(true));
		}

        [Test]
        public void ShouldDisableToolBarUndo_On_ManualPriceCurveValidation_With_SelectedCurveNoErrors()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            testObjects.ViewModel.ManualPriceCurve.Errors.Clear();

            // ACT
            testObjects.ManualPriceCurveValidation.OnNext("Name");

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.True);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(false));
        }

        [Test]
        public void ShouldEnableToolBarUndo_On_ManualPriceCurveValidation_With_NewCurveErrors()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;

            testObjects.ViewModel.ManualPriceCurve.Errors.Add("Name", ["error"]);

            // ACT
            testObjects.ManualPriceCurveValidation.OnNext("Name");

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.False);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(true));
        }

        [Test]
        public void ShouldDisableToolBarUndo_On_ManualPriceCurveValidation_With_NewCurveNoErrors()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;

            testObjects.ViewModel.ManualPriceCurve.Errors.Clear();

            // ACT
            testObjects.ManualPriceCurveValidation.OnNext("Name");

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.True);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(false));
        }

        [Test]
        public void ShouldLogError_On_ManualPriceCurveValidation_ExceptionError()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ACT
            testObjects.ManualPriceCurveValidation.OnError(new Exception("error"));

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(l => l.Error(It.Is<string>(e => e.Contains("error"))));
        }

		#endregion

		#region Validation - Enable Selected Curve ToolBarUpdate

		[Test]
        public void ShouldDisableToolBarUpdate_On_ManualPriceCurveValidation_With_SelectedCurveErrors_HasChangedTrue()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
            testObjects.ViewModel.HasChanged = true;
            testObjects.ViewModel.ManualPriceCurve.Errors.Add("Name", ["error"]);

            // ACT
            testObjects.ManualPriceCurveValidation.OnNext("Name");

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.False);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
        }

        [Test]
        public void ShouldEnableToolBarUpdate_On_ManualPriceCurveValidation_With_SelectedCurveNoErrors_HasChangedTrue()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
            testObjects.ViewModel.HasChanged = true;
            testObjects.ViewModel.ManualPriceCurve.Errors.Clear();

            // ACT
            testObjects.ManualPriceCurveValidation.OnNext("Name");

            // ASSERT
            Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.False);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

		#endregion

		#region Product Changed Handler

		[Test]
        public void ShouldUpdatePricingTenorGroup_When_ProductChanged()
        {
            var product1 = new ProductDefinitionTestObjectBuilder().WithName("product-1")
                                                                   .Build();

            var product2 = new ProductDefinitionTestObjectBuilder().WithName("product-2")
                                                                   .Build();

            var item2 = new ProductDefinitionItem(product2);

            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithProductDefinition(product1)
                                                                                  .Build();

            var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

            var curveGroups = new List<CurveGroup>();

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithProductDefinitions([])
                                                                                .WithPriceCurveDefinitions([])
                                                                                .WithCurveGroups(curveGroups)
                                                                                .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ACT
            testObjects.ViewModel.ManualPriceCurve.ProductDefinition = item2;

            // ASSERT
            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.TransformProduct(testObjects.ViewModel, product2, curveGroups));
        }

        #endregion

        #region UnsetFields - ToolBarService

        [Test]
        public void ShouldSetHasChangesTrue_And_Enable_ToolBarUndo_On_UnsetFields()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ACT
            testObjects.UnsetFields.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(true));
		}

        [Test]
        public void ShouldNotEnableToolBarUpdate_On_UnsetFields_With_UnsetFieldsAny()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ACT
            testObjects.UnsetFields.OnNext(Unit.Default);

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true), Times.Never);
		}

        [Test]
        public void ShouldEnableToolBarUpdate_On_UnsetFields_With_UnsetFieldsEmpty()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;

            testObjects.ViewModel.UnsetFields.Clear();

            // ACT
            testObjects.UnsetFields.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldDisableToolBarUpdate_On_Error_With_UnsetFieldsEmpty()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;

            testObjects.ViewModel.UnsetFields.Clear();
            testObjects.UnsetFields.OnNext(Unit.Default);

			Mock.Get(testObjects.ToolBarService).Invocations.Clear();

			testObjects.ViewModel.ManualPriceCurve.Errors.Add("Name", ["error"]);

            // ACT
            testObjects.ManualPriceCurveValidation.OnNext("Name");

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
		}

		#endregion

		#region ToolBar Undo Changes

        [Test]
        public void ShouldResetChanges_And_ToolBar_On_ToolbarUndoChanges()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.HasChanged = true;

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.False);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(false));

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
		}

        [Test]
        public void ShouldClearValidationErrors_On_ToolbarUndoChanges_With_Errors()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            string result = null;

            // ARRANGE
            testObjects.ViewModel.ManualPriceCurve.ErrorsChanged += (_, args) => { result = args.PropertyName; };

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.ManualPriceCurve.Errors.Add("Name", ["error"]);

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualPriceCurve.Errors, Is.Empty);
            Assert.That(result, Is.EqualTo("Name"));
        }

		#endregion

		#region ToolBar Undo Changes - Create New Curve

		[Test]
		public void ShouldClearFields_And_RestoreDefaults_On_ToolbarUndoChanges_With_CreateNewCurve()
		{
			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.ManualPriceCurve.DsxLotSize = 1500;

			// ACT
			testObjects.ToolBarUndo.OnNext(Unit.Default);

			// ASSERT
            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.ClearPriceCurve(testObjects.ViewModel));

            Mock.Get(testObjects.ManualPriceCurveTransformer)
				.Verify(t => t.ClearPriceCurve(testObjects.ViewModel));

			Assert.That(testObjects.ViewModel.ManualPriceCurve.DsxLotSize, Is.EqualTo(1000));
		}

		[Test]
		public void ShouldRestoreAndSubscribeUnsetFields_On_On_ToolbarUndoChanges_With_CreateNewCurve()
		{
			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.IsCreateNewCurve = true;

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.UnsetFields.Clear();

			// ACT
			testObjects.ToolBarUndo.OnNext(Unit.Default);

			var expected = new[]
						   {
							   nameof(ManualPriceCurveViewModel.Name),
							   nameof(ManualPriceCurveViewModel.Description),
							   nameof(ManualPriceCurveViewModel.CurveType),
							   nameof(ManualPriceCurveViewModel.ProductDefinition),
							   nameof(ManualPriceCurveViewModel.CurveRegion),
							   nameof(ManualPriceCurveViewModel.DsxUnitOfMeasure)
						   };

			// ASSERT
			Assert.That(testObjects.ViewModel.UnsetFields.SequenceEqual(expected));

			Mock.Get(testObjects.UnsetFieldsService)
				.Verify(u => u.ObserveUnsetFields(testObjects.ViewModel.ManualPriceCurve,
												  testObjects.ViewModel.UnsetFields));
		}


		#endregion

		#region ToolBar Undo Changes - Modify Selected Curve

		[Test]
        public void ShouldUndoChanges_On_ToolbarUndoChanges_With_SelectedPriceCurve_EditChanges()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

            var curveGroups = new List<CurveGroup>();

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
            testObjects.ViewModel.EditChanges.Add(nameof(ManualPriceCurveViewModel.DsxLotSize));
            testObjects.ViewModel.HasChanged = true;

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.SelectedCurveDefinitionStatus, Is.Not.Null);
			Assert.That(testObjects.ViewModel.HasChanged, Is.False);
            Assert.That(testObjects.ViewModel.EditChanges, Is.Empty);

            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel,
                                                   testObjects.ViewModel.SelectedCurveDefinitionStatus.CurveDefinition, 
                                                   curveGroups));

            Mock.Get(testObjects.ManualPriceCurveEditChangesService)
                .Verify(o => o.ObserveChanged(testObjects.ViewModel.ManualPriceCurve,
                                              item.CurveDefinition,
											  testObjects.ViewModel.EditChanges));

            Mock.Get(testObjects.ManualPriceCurveValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel));

            Mock.Get(testObjects.OptionalFieldsCheckService)
                .Verify(o => o.SubscribeOptionalFieldChecks(testObjects.ViewModel.ManualCurveOptionalFlags,
                                                            testObjects.ViewModel.ManualPriceCurve));

            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
		}

		#endregion

		#region ToolBar Undo Changes - Delete Selected Curve

		[Test]
		public void ShouldUndoChanges_On_ToolbarUndoChanges_With_SelectedPriceCurve_DeleteCurve()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.IsDeleteCurve = true;

			// ACT
			testObjects.ToolBarUndo.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.CanDeleteCurve, Is.True);
			Assert.That(testObjects.ViewModel.IsDeleteCurve, Is.False);
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
		}

		#endregion

		#region ToolBar Update - New Curve

		[Test]
		public void ShouldDisableFields_And_ShowBusyIndicator_When_ToolBarUpdate_CreateNewCurve()
        {
            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsCreateNewCurve = true;
            testObjects.ViewModel.IsReadonly = false;
            testObjects.ViewModel.CurveFieldsEnabled = true;

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.IsReadonly, Is.True);
            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.False);
        }

        [Test]
		public void ShouldCreateAction_And_SubscribeMatchingDraftUpdate_When_ToolBarUpdate_CreateNewCurve()
		{
			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.ManualPriceCurve.Name = "name";

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Mock.Get(testObjects.DraftCurveItemMatchingService)
				.Verify(m => m.NewCurveMatchingDraftItem(It.IsAny<IObservable<IList<PriceCurveDefinitionStatusItem>>>(),
														 "name"));

			Mock.Get(testObjects.ManualPriceCurveUpdateService)
				.Verify(m => m.CreateManualPriceCurveDefinition(testObjects.ViewModel.ManualPriceCurve,
																testObjects.ViewModel.ManualCurveOptionalFlags,
																It.IsAny<IScheduler>()));
		}

		[Test]
		public void ShouldSetSelectedPriceCurveDefinition_OnMatchingDraftUpdate_SelectedCurve_CreateNewCurve()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var draft = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithProductDefinitions([])
																				.WithPriceCurveDefinitions([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.ManualPriceCurve.Name = "name";

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ACT
			testObjects.NewCurveMatchingDraftItem.OnNext(draft);

			// ASSERT
			Assert.That(testObjects.ViewModel.SelectedCurveDefinitionStatus, Is.SameAs(draft));
		}

		[Test]
		public void ShouldResetChangesAndToolBar_And_ShowPopup_On_CreateManualPriceCurveCompleted_With_NoWarnings()
		{
			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.CanSelectCurveAction = false;
			testObjects.ViewModel.HasChanged = true;

			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ACT
			testObjects.ManualPriceCurveUpdateResponse.OnNext(new AdminApiActionCompleted());

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.False);
			Assert.That(testObjects.ViewModel.CanSelectCurveAction, Is.True);
			Assert.That(testObjects.ViewModel.HasChanged, Is.False);

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUndoChanges(false));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUpdate(false));

			Mock.Get(testObjects.PopupNotificationService)
				.Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
		}

		[Test]
		public void ShouldSetSelectedCurve_On_CreateManualPriceCurve_MatchingDraft()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();
			var draftItem = new PriceCurveDefinitionStatusItem(priceCurveDefinition, true);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithProductDefinitions([])
																				.WithPriceCurveDefinitions([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;

			testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.NewCurveMatchingDraftItem.OnNext(draftItem);

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedCurveDefinitionStatus, Is.SameAs(draftItem));
		}

		#endregion

		#region ToolBar Update - Selected Curve Update

		[Test]
        public void ShouldDisableFields_And_ShowBusyIndicator_When_ToolBarUpdate_SelectedCurveActive()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
            testObjects.ViewModel.CurveFieldsEnabled = true;
            
			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.IsReadonly, Is.True);
            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.False);
        }

		[Test]
		public void ShouldCreateAction_When_ToolBarUpdate_SelectedCurve()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Mock.Get(testObjects.ManualPriceCurveUpdateService)
				.Verify(m => m.UpdateManualPriceCurveDefinition(testObjects.ViewModel.ManualPriceCurve,
																testObjects.ViewModel.ManualCurveOptionalFlags,
																101,
																It.IsAny<IScheduler>()));
		}

		[Test]
		public void ShouldCreateAction_And_SubscribeMatchingDraftUpdate_When_ToolBarUpdate_SelectedCurve_Active()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Mock.Get(testObjects.DraftCurveItemMatchingService)
				.Verify(m => m.ActiveCurveMatchingDraftItem(It.IsAny<IObservable<IList<PriceCurveDefinitionStatusItem>>>(),
															101));
		}

		[Test]
		public void ShouldSubscribeMatchingDraftUpdate_When_ToolBarUpdate_SelectedCurve_ExistingDraft()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, true);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Mock.Get(testObjects.DraftCurveItemMatchingService)
				.Verify(m => m.ExistingDraftMatchingDraftItem(It.IsAny<IObservable<IList<PriceCurveDefinitionStatusItem>>>(),
															  101));
		}

		[Test]
		public void ShouldSetSelectedPriceCurveDefinition_OnMatchingDraftUpdate_SelectedCurve_Active()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var draft = new PriceCurveDefinitionStatusItem(priceCurveDefinition, true);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ActiveCurveMatchingDraftItem.OnNext(draft);

			// ASSERT
			Assert.That(testObjects.ViewModel.SelectedCurveDefinitionStatus, Is.SameAs(draft));
		}

		[Test]
		public void ShouldSetSelectedPriceCurveDefinition_OnMatchingDraftUpdate_SelectedCurve_ExistingDraft()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition, true);

			var draft = new PriceCurveDefinitionStatusItem(priceCurveDefinition, true);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
                                                                                .WithCurveGroups([])
                                                                                .Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ACT
			testObjects.ExistingDraftMatchingDraftItem.OnNext(draft);

			// ASSERT
			Assert.That(testObjects.ViewModel.SelectedCurveDefinitionStatus, Is.SameAs(draft));
		}

		[Test]
        public void ShouldEnableFields_And_ShowErrorMessageDialog_On_CreateManualPriceCurveCompleted_With_Warnings()
        {
			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;
            testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ManualPriceCurveUpdateResponse.OnNext(new AdminApiActionCompleted("warning"));

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldEnableFields_And_ShowErrorMessageDialog_On_CreateManualPriceCurveError()
        {
			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ACT
            testObjects.ManualPriceCurveUpdateResponse.OnError(new Exception());

            // ASSERT
            Assert.That(testObjects.ViewModel.IsReadonly, Is.False);
            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);

            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

        [Test]
        public void ShouldEnableFields_And_ShowErrorMessageDialog_On_ToolBarUpdateWithMissingSelectedCurve()
        {
			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.SelectedCurveDefinitionStatus = null;

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.IsReadonly, Is.False);
            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);

			Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(p => p.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
        }

		#endregion

		#region ToolBar Update - Selected Curve Name

		[Test]
		public void ShouldShowWarningDialog_When_ToolBarUpdate_CurveNameChange()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();

			// ARRANGE

			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.HasChanged = true;
			testObjects.ViewModel.EditChanges.Add(nameof(testObjects.ViewModel.ManualPriceCurve.Name));
			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.MessageDialogPrompt.ShowDialog, Is.True);
		}

		[Test]
		public void ShouldNotShowWarningDialog_When_ToolBarUpdate_CurveNameChange_IsDeleteCurveTrue()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.HasChanged = true;
			testObjects.ViewModel.EditChanges.Add(nameof(testObjects.ViewModel.ManualPriceCurve.Name));

			testObjects.ViewModel.IsDeleteCurve = true;

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.MessageDialogPrompt.ShowDialog, Is.False);
		}

		[Test]
		public void ShouldUpdateManualCurve_On_WarningDialog_YesCommand()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.HasChanged = true;
			testObjects.ViewModel.EditChanges.Add(nameof(testObjects.ViewModel.ManualPriceCurve.Name));

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);
			testObjects.ViewModel.MessageDialogPrompt.DialogYesCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.MessageDialogPrompt.ShowDialog, Is.False);
			Mock.Get(testObjects.ManualPriceCurveUpdateService)
				.Verify(m => m.UpdateManualPriceCurveDefinition(testObjects.ViewModel.ManualPriceCurve,
																testObjects.ViewModel.ManualCurveOptionalFlags,
																item.Id,
																It.IsAny<IScheduler>()));
		}

		[Test]
		public void ShouldNotUpdateManualCurve_On_DsxWarningDialog_NoCommand()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.HasChanged = true;
			testObjects.ViewModel.EditChanges.Add(nameof(testObjects.ViewModel.ManualPriceCurve.Name));

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);
			testObjects.ViewModel.MessageDialogPrompt.DialogNoCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.MessageDialogPrompt.ShowDialog, Is.False);

			Mock.Get(testObjects.ManualPriceCurveUpdateService)
				.Verify(m => m.UpdateManualPriceCurveDefinition(testObjects.ViewModel.ManualPriceCurve,
																testObjects.ViewModel.ManualCurveOptionalFlags,
																item.Id,
																It.IsAny<IScheduler>()), Times.Never);
		}

		[Test]
		public void ShouldNotShowWarningDialog_When_ToolBarUpdate_NoCurveNameChange()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.WithCurveGroups([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;
			testObjects.ViewModel.HasChanged = true;
			testObjects.ViewModel.EditChanges.Add(nameof(testObjects.ViewModel.ManualPriceCurve.DsxLotSize));

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.MessageDialogPrompt.ShowDialog, Is.False);

			Mock.Get(testObjects.ManualPriceCurveUpdateService)
				.Verify(m => m.UpdateManualPriceCurveDefinition(testObjects.ViewModel.ManualPriceCurve,
																testObjects.ViewModel.ManualCurveOptionalFlags,
																item.Id,
																It.IsAny<IScheduler>()));
		}

		#endregion

		#region ToolBar Update - Selected Curve Delete

		[Test]
		public void ShouldCreateAction_When_ToolBarUpdate_SelectedCurve_With_IsDeleteCurveTrue()
		{
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();
			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();
			testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

			testObjects.ViewModel.IsDeleteCurve = true;

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Mock.Get(testObjects.CurveDeletionService)
				.Verify(m => m.DeleteCurve(101, AdminCurveType.Manual, It.IsAny<IScheduler>()));
		}

		[Test]
		public void ShouldNotPromptMessage_When_ToolBarUpdate_With_IsDeleteCurveTrue_NameChanged()
		{

		}

		#endregion

		#region Dispose

		[Test]
        public void ShouldNotTransformFromPriceCurve_When_Disposed()
        {
            var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

            var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ASSERT
            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel,
												   It.IsAny<PriceCurveDefinition>(), 
                                                   It.IsAny<List<CurveGroup>>()), 
                                                   Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
			var priceCurveDefinition = new PriceCurveDefinitionTestObjectBuilder().Build();

			var item = new PriceCurveDefinitionStatusItem(priceCurveDefinition);

			var testObjects = new ManualCurveEditorControllerTestObjectBuilder().WithPriceCurveDefinitions([priceCurveDefinition])
																				.WithProductDefinitions([])
																				.Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            testObjects.ViewModel.SelectedCurveDefinitionStatus = item;

            // ASSERT
            Mock.Get(testObjects.ManualPriceCurveTransformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel,
                                                   It.IsAny<PriceCurveDefinition>(), 
                                                   It.IsAny<List<CurveGroup>>()),
                                                   Times.Never);
        }

        #endregion
    }
}
