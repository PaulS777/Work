﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ApprovalDrafts.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.ApprovalDrafts.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services.Changes;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ApprovalDrafts.Controllers
{
	public interface IManualCurveDraftControllerTestObjects
	{
		ICurveApprovalsNavigationService CurveApprovalsNavigationService { get; }
		ICurveControlService CurveControlService { get; }
		ISubject<IList<PriceCurveDefinition>> PriceCurveDefinitions { get; }
		ISubject<List<ProductDefinition>> ProductDefinitions { get; }
        ISubject<List<CurveGroup>> CurveGroups { get; }
        ISubject<List<CurrencyCode>> CurrencyCodes { get; }
		IManualPriceCurveTransformer Transformer { get; }
		IDraftCurveChangesService DraftCurveChangesService { get; }
		IDraftCurveChangesParser DraftCurveChangesParser { get; }
		ManualCurveDraftViewModel ViewModel { get; }
		ManualCurveDraftController Controller { get; }
	}

	[TestFixture]
	public class ManualCurveDraftControllerTests
	{
		private class ManualCurveDraftControllerTestObjectBuilder
		{
			private IList<PriceCurveDefinition> _priceCurveDefinitions;
			private List<ProductDefinition> _productDefinitions; 
			private List<CurveGroup> _curveGroups; 
			private List<CurrencyCode> _currencyCodes;
			private CurveApprovalNavigationParams _navigationParams;
			private bool _useDefaultNavigationParams;
			private Dictionary<string, object> _serviceDraftCurveChanges;
			private Dictionary<string, object> _parsedDraftCurveChanges;

			public ManualCurveDraftControllerTestObjectBuilder WithPriceCurveDefinitions(IList<PriceCurveDefinition> values)
			{
				_priceCurveDefinitions = values;
				return this;
			}

			public ManualCurveDraftControllerTestObjectBuilder WithProductDefinitions(List<ProductDefinition> values)
			{
				_productDefinitions = values;
				return this;
			}

			public ManualCurveDraftControllerTestObjectBuilder WithCurrencyCodes(List<CurrencyCode> values)
			{
				_currencyCodes = values;
				return this;
			}

            public ManualCurveDraftControllerTestObjectBuilder WithCurveGroups(List<CurveGroup> values)
            {
                _curveGroups = values;
                return this;
            }
            public ManualCurveDraftControllerTestObjectBuilder WithNavigationParams(CurveApprovalNavigationParams value)
			{
				_navigationParams = value;
				return this;
			}

			public ManualCurveDraftControllerTestObjectBuilder WithUseDefaultNavigationParams()
			{
				_useDefaultNavigationParams = true;
				return this;
			}

			public ManualCurveDraftControllerTestObjectBuilder WithServiceDraftCurveChanges(Dictionary<string, object> values)
			{
				_serviceDraftCurveChanges = values;
				return this;
			}

			public ManualCurveDraftControllerTestObjectBuilder WithParsedDraftCurveChanges(Dictionary<string, object> values)
			{
				_parsedDraftCurveChanges = values;
				return this;
			}

			public IManualCurveDraftControllerTestObjects Build()
			{
				var testObjects = new Mock<IManualCurveDraftControllerTestObjects>();

				var navigationService = new Mock<ICurveApprovalsNavigationService>();

				if (_useDefaultNavigationParams)
				{
					var defaultNavigationParams = new CurveApprovalNavigationParams(0, string.Empty);

					navigationService.SetupGet(n => n.ManualCurveDraftParams)
									 .Returns(defaultNavigationParams);
				}
				else
				{
					navigationService.SetupGet(n => n.ManualCurveDraftParams)
									 .Returns(_navigationParams);
				}

				testObjects.SetupGet(o => o.CurveApprovalsNavigationService)
						   .Returns(navigationService.Object);

				var productDefinitions = new BehaviorSubject<List<ProductDefinition>>(_productDefinitions);
                
                testObjects.SetupGet(o => o.ProductDefinitions)
						   .Returns(productDefinitions);

                var curveGroups = new BehaviorSubject<List<CurveGroup>>(_curveGroups);

				testObjects.SetupGet(o => o.CurveGroups)
						   .Returns(curveGroups);

                var currencyCodes = new BehaviorSubject<List<CurrencyCode>>(_currencyCodes);

				testObjects.SetupGet(o => o.CurrencyCodes)
						   .Returns(currencyCodes);

				var priceCurveDefinitions = new BehaviorSubject<IList<PriceCurveDefinition>>(_priceCurveDefinitions);

				testObjects.SetupGet(o => o.PriceCurveDefinitions)
						   .Returns(priceCurveDefinitions);

				var curveControlService = new Mock<ICurveControlService>();

				curveControlService.SetupGet(c => c.ProductDefinitions)
								   .Returns(productDefinitions);

				curveControlService.SetupGet(c => c.CurrencyCodes)
								   .Returns(currencyCodes);

				curveControlService.SetupGet(c => c.PriceCurveDefinitions)
								   .Returns(priceCurveDefinitions);

                curveControlService.SetupGet(c => c.CurveGroups)
                               .Returns(curveGroups);

                testObjects.SetupGet(o => o.CurveControlService)
						   .Returns(curveControlService.Object);

			
                curveControlService.Setup(c => c.GetProductDefinitionsSnapshot())
								   .Returns(_productDefinitions);

				curveControlService.Setup(c => c.GetPriceCurveDefinitionsSnapshot())
								   .Returns(_priceCurveDefinitions);

				var transformer = new Mock<IManualPriceCurveTransformer>();

				testObjects.SetupGet(o => o.Transformer)
						   .Returns(transformer.Object);

				var draftCurveChangesService = new Mock<IDraftCurveChangesService>();

				draftCurveChangesService.Setup(d => d.GetDraftCurveChanges(It.IsAny<ManualPriceCurveViewModel>(),
																		   It.IsAny<PriceCurveDefinition>()))
										.Returns(_serviceDraftCurveChanges);

				testObjects.SetupGet(o => o.DraftCurveChangesService)
						   .Returns(draftCurveChangesService.Object);

				var draftCurveChangesParser = new Mock<IDraftCurveChangesParser>();

				draftCurveChangesParser.Setup(p => p.ParseChanges(It.IsAny<Dictionary<string, object>>()))
									   .Returns(_parsedDraftCurveChanges);

				testObjects.SetupGet(o => o.DraftCurveChangesParser)
						   .Returns(draftCurveChangesParser.Object);

				var controller = new ManualCurveDraftController(navigationService.Object,
																curveControlService.Object,
																TestMocks.GetSchedulerProvider().Object)
								 {
									 Transformer = transformer.Object,
									 DraftCurveChangesService = draftCurveChangesService.Object,
									 DraftCurveChangesParser = draftCurveChangesParser.Object,
				};

				testObjects.SetupGet(o => o.Controller)
						   .Returns(controller);

				testObjects.SetupGet(o => o.ViewModel)
						   .Returns(controller.ViewModel);

				return testObjects.Object;
			}
		}

		#region Construction

		[Test]
		public void ShouldSetReadonly_ShowDialog_And_PopulateManualCurveEnumCombos()
		{
			// ACT
			var testObjects = new ManualCurveDraftControllerTestObjectBuilder().Build();

			// ASSERT
			Assert.That(testObjects.ViewModel.ManualCurve.IsReadonly, Is.True);

			Assert.That(testObjects.ViewModel.ManualCurve.UnsetFields, Is.Null);
			Assert.That(testObjects.ViewModel.ManualCurve.EditChanges, Is.Null);

			Assert.That(testObjects.ViewModel.ManualCurve.CurveTypes, Is.Not.Null);

			Assert.That(testObjects.ViewModel.ManualCurve.CurveRegions, Is.Not.Null);
			Assert.That(testObjects.ViewModel.ManualCurve.CurveRegions.Contains(CurveRegion.None), Is.False);

			Assert.That(testObjects.ViewModel.ManualCurve.UnitsOfMeasure, Is.Not.Null);
			Assert.That(testObjects.ViewModel.ManualCurve.UnitsOfMeasure.Contains(UnitOfMeasure.None), Is.False);

            Assert.That(testObjects.ViewModel.ManualCurve.MessageDialogPrompt.ShowDialog, Is.False);
        }

		#endregion

		#region Initialize Manual Curve Draft

		[Test]
		public void ShouldSetActionedBy_On_Initialize()
		{
			var navigationParams = new CurveApprovalNavigationParams(101, "user-1");

			var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(navigationParams)
																			   .Build();

			// ACT
			testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.ActionedBy, Is.EqualTo("user-1"));
		}

		[Test]
		public void ShouldClearDraftChanges_On_Initialize()
		{
			var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithUseDefaultNavigationParams()
																			   .Build();
			
			// ARRANGE
			testObjects.ViewModel.ManualCurve.DraftChanges = new Dictionary<string, object> { { "Name", "user" } };

			// ACT
			testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.ManualCurve.DraftChanges, Is.Empty);
		}

		[Test]
		public void ShouldPopulateCurrencyCodesCombo_On_CurrencyCodes_With_Initialized()
		{
			var currencyCode1 = new CurrencyCode(1, "USD");
			var currencyCode2 = new CurrencyCode(1, "EUR");

			var currencyCodes = new List<CurrencyCode> { currencyCode1, currencyCode2 };

			var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithUseDefaultNavigationParams()
																			   .Build();

			// ARRANGE
			testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

			// ACT
			testObjects.CurrencyCodes.OnNext(currencyCodes);

			// ASSERT
			Assert.That(testObjects.ViewModel.ManualCurve.CurrencyCodes.Count, Is.EqualTo(2));
		}

		[Test]
		public void ShouldPopulateProductsCombo_On_Products_With_Initialized()
		{
			var product1 = new ProductDefinitionTestObjectBuilder().WithId(1).Build();
			var product2 = new ProductDefinitionTestObjectBuilder().WithId(2).Build();

			var products = new List<ProductDefinition> { product1, product2 };

			var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithUseDefaultNavigationParams()
																			   .Build();

			// ARRANGE
			testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

			// ACT
			testObjects.ProductDefinitions.OnNext(products);

			// ASSERT
			Assert.That(testObjects.ViewModel.ManualCurve.ProductDefinitions.Count, Is.EqualTo(2));
		}

		[Test]
		public void ShouldSetPriceCurveDefinition_On_PriceCurveDefinitions_With_Initialized_Match_Id()
		{
			var navigationParams = new CurveApprovalNavigationParams(101, "user-1");

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();
			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102).Build();

			var priceCurves = new[] { priceCurve1, priceCurve2 };

			var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(navigationParams)
																			   .Build();

			// ARRANGE
			testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

			// ACT
			testObjects.PriceCurveDefinitions.OnNext(priceCurves);

			// ASSERT
			var sourceCollection = testObjects.ViewModel.ManualCurve.PriceCurveDefinitions.SourceCollection.Cast<PriceCurveDefinitionStatusItem>();

			Assert.That(sourceCollection.Count, Is.EqualTo(1));

			var item = testObjects.ViewModel.ManualCurve.SelectedCurveDefinitionStatus;

			Assert.That(item.CurveDefinition, Is.SameAs(priceCurve1));
			Assert.That(item.IsDraftCurrentUser, Is.False);
			Assert.That(item.IsDraftOtherUser, Is.True);
			Assert.That(item.IsActivePendingApproval, Is.True);
		}

		[Test]
		public void ShouldThrowInvalidOperationException_On_Initialize_With_NullNavigationParams()
		{
			var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(null)
																			   .Build();

			InvalidOperationException result = null;

			try
			{
				// ACT
				testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();
			}
			catch (InvalidOperationException exception)
			{
				result = exception;
			}

			// ASSERT
			Assert.That(result, Is.Not.Null);
		}

		#endregion

		#region Populate Curve

		[Test]
        public void ShouldPopulateCurve_On_PriceCurveDefinition_With_Dependencies_And_Match_Id()
        {
            var navigationParams = new CurveApprovalNavigationParams(101, "user-1");

            var currencyCode1 = new CurrencyCode(1, "USD");
            var currencyCodes = new List<CurrencyCode> { currencyCode1 };

            var curveGroups = new List<CurveGroup>();

            var product1 = new ProductDefinitionTestObjectBuilder().WithId(1).Build();
            var products = new List<ProductDefinition> { product1 };

            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();
            var priceCurves = new[] { priceCurve1 };

            var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(navigationParams)
                                                                               .WithCurrencyCodes(currencyCodes)
                                                                               .WithProductDefinitions(products)
                                                                               .WithCurveGroups(curveGroups)
                                                                               .WithPriceCurveDefinitions(priceCurves)
                                                                               .Build();
            // ACT  
            testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

            // ASSERT  
            Mock.Get(testObjects.Transformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel.ManualCurve, priceCurve1, curveGroups));
        }

    
		[Test]
		public void ShouldSetActionDescription_To_NewCurve_On_PriceCurveDefinition_With_NoActiveCurveMatch()
		{
			var navigationParams = new CurveApprovalNavigationParams(101, "user-1");

			var currencyCode1 = new CurrencyCode(1, "USD");
			var currencyCodes = new List<CurrencyCode> { currencyCode1 };

			var product1 = new ProductDefinitionTestObjectBuilder().WithId(1).Build();
			var products = new List<ProductDefinition> { product1 };

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();
			var priceCurves = new[] { priceCurve1 };
            
            var curveGroups = new List<CurveGroup>();

            var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(navigationParams)
																			   .WithCurrencyCodes(currencyCodes)
																			   .WithProductDefinitions(products)
																			   .WithPriceCurveDefinitions(priceCurves)
                                                                               .WithCurveGroups(curveGroups)
                                                                               .Build();
			// ACT
			testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.ActionDescription, Is.EqualTo("New Curve"));
		}

		[Test]
		public void ShouldSetActionDescription_To_Modification_On_PriceCurveDefinition_With_ActiveCurveMatch()
		{
			var navigationParams = new CurveApprovalNavigationParams(101, "user-1");

			var currencyCode1 = new CurrencyCode(1, "USD");
			var currencyCodes = new List<CurrencyCode> { currencyCode1 };

			var product1 = new ProductDefinitionTestObjectBuilder().WithId(1).Build();
			var products = new List<ProductDefinition> { product1 };

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																		 .WithPendingCurveId(101)
																		 .WithName("Active Curve")
																		 .Build();

			var priceCurves = new[] { priceCurve1, priceCurve2 };
            
            var curveGroups = new List<CurveGroup>();

            var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(navigationParams)
																			   .WithCurrencyCodes(currencyCodes)
                                                                               .WithCurveGroups(curveGroups)
                                                                               .WithProductDefinitions(products)
																			   .WithPriceCurveDefinitions(priceCurves)
																			   .Build();
			// ACT
			testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.ActionDescription, Is.EqualTo("Modification - Active Curve"));
		}

		[Test]
		public void ShouldSetDraftChanges_On_PriceCurveDefinition_With_ActiveCurveMatch()
		{
			var navigationParams = new CurveApprovalNavigationParams(101, "user-1");

			var currencyCode1 = new CurrencyCode(1, "USD");
			var currencyCodes = new List<CurrencyCode> { currencyCode1 };

			var product1 = new ProductDefinitionTestObjectBuilder().WithId(1).Build();
			var products = new List<ProductDefinition> { product1 };

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();

			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																		 .WithPendingCurveId(101)
																		 .WithName("Active Curve")
																		 .Build();

			var priceCurves = new[] { priceCurve1, priceCurve2 };

			var draftChanges = new Dictionary<string, object> { { "CcyCode", 1 } };
			var parsedDraftChanges = new Dictionary<string, object> { { "CcyCode", "EUR" } };
            
            var curveGroups = new List<CurveGroup>();

            var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(navigationParams)
																			   .WithCurrencyCodes(currencyCodes)
                                                                               .WithCurveGroups(curveGroups)
                                                                               .WithProductDefinitions(products)
																			   .WithPriceCurveDefinitions(priceCurves)
																			   .WithServiceDraftCurveChanges(draftChanges)
																			   .WithParsedDraftCurveChanges(parsedDraftChanges)
																			   .Build();
			// ACT
			testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

			// ASSERT
			Mock.Get(testObjects.DraftCurveChangesService)
				.Verify(d => d.GetDraftCurveChanges(testObjects.ViewModel.ManualCurve.ManualPriceCurve, priceCurve2));

			Mock.Get(testObjects.DraftCurveChangesParser)
				.Verify(p => p.ParseChanges(draftChanges));

			Assert.That(testObjects.ViewModel.ManualCurve.DraftChanges, Is.SameAs(parsedDraftChanges));
		}

		#endregion

		#region Navigation

		[Test]
		public void ShouldNavigateBack_On_NavigateBackCommand()
		{
			var testObjects = new ManualCurveDraftControllerTestObjectBuilder().Build();

			// ACT
			testObjects.ViewModel.NavigateBackCommand.Execute();

			// ASSERT
			Mock.Get(testObjects.CurveApprovalsNavigationService)
				.Verify(n => n.NavigateBack());
		}

		#endregion

		#region Dispose

		[Test]
        public void ShouldNotPopulateCurve_When_Disposed()
        {
            var navigationParams = new CurveApprovalNavigationParams(101, "user-1");

            var currencyCode1 = new CurrencyCode(1, "USD");
            var currencyCodes = new List<CurrencyCode> { currencyCode1 };

            var product1 = new ProductDefinitionTestObjectBuilder().WithId(1).Build();
            var products = new List<ProductDefinition> { product1 };

            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();
            var priceCurves = new[] { priceCurve1 };
            
            var curveGroups = new List<CurveGroup>();
            var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(navigationParams)
                                                                               .WithCurrencyCodes(currencyCodes)
                                                                               .WithProductDefinitions(products)
                                                                               .WithCurveGroups(curveGroups)
                                                                               .Build();

            // ARRANGE  
            testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

            testObjects.Controller.Dispose();

            // ACT  
            testObjects.PriceCurveDefinitions.OnNext(priceCurves);

            // ASSERT  
            Mock.Get(testObjects.Transformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel.ManualCurve, priceCurve1, curveGroups), Times.Never);
        }

    
		[Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var navigationParams = new CurveApprovalNavigationParams(101, "user-1");

            var currencyCode1 = new CurrencyCode(1, "USD");
            var currencyCodes = new List<CurrencyCode> { currencyCode1 };

            var product1 = new ProductDefinitionTestObjectBuilder().WithId(1).Build();
            var products = new List<ProductDefinition> { product1 };

            var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(101).Build();
            var priceCurves = new[] { priceCurve1 };

			var curveGroups = new List<CurveGroup>();

            var testObjects = new ManualCurveDraftControllerTestObjectBuilder().WithNavigationParams(navigationParams)
                                                                               .WithCurrencyCodes(currencyCodes)
                                                                               .WithProductDefinitions(products)
                                                                               .WithCurveGroups(curveGroups)
                                                                               .Build();

            // ARRANGE  
            testObjects.ViewModel.ManualCurve.InitializeCommand.Execute();

            testObjects.Controller.Dispose();

            // ACT  
            testObjects.Controller.Dispose();

            testObjects.PriceCurveDefinitions.OnNext(priceCurves);

            // ASSERT  
            Mock.Get(testObjects.Transformer)
                .Verify(t => t.TransformPriceCurve(testObjects.ViewModel.ManualCurve, priceCurve1, curveGroups), Times.Never);
        }

    
		#endregion


	}
}
