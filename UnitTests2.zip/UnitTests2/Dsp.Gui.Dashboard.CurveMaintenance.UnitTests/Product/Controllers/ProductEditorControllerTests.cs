﻿using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Product.Controller;
using Dsp.Gui.Dashboard.CurveMaintenance.Product.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Product.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Reactive.Subjects;


namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Product.Controllers
{
    internal interface IProductEditorEditorControllerTestObjects
    {
        IProductTransformer ProductTransformer { get; }
        ISubject<List<ProductDefinition>> ProductDefinitions { get; }
        ICurveControlService CurveControlService { get; }
        ISubject<List<CurveGroup>> CurveGroups { get; }
        ISubject<List<CurrencyCode>> CurrencyCodes { get; }
        ProductEditorViewModel ViewModel { get; }
        ProductEditorController Controller { get; }
    }

    [TestFixture]
    public class ProductEditorControllerTests
    {
        private class ProductEditorControllerTestObjectBuilder
        {
            private List<CurveGroup> _curveGroups;

            private List<ProductDefinition> _productDefinitions;

            private List<CurrencyCode> _currencyCodes;

            public ProductEditorControllerTestObjectBuilder WithCurveGroups(List<CurveGroup> values)
            {
                _curveGroups = values;
                return this;
            }

            public ProductEditorControllerTestObjectBuilder WithCurrencyCodes(List<CurrencyCode> values)
            {
                _currencyCodes = values;
                return this;
            }

            public ProductEditorControllerTestObjectBuilder WithProductDefinitions(List<ProductDefinition> values)
            {
                _productDefinitions = values;
                return this;
            }

            public IProductEditorEditorControllerTestObjects Build()
            {
                var testObjects = new Mock<IProductEditorEditorControllerTestObjects>();
                var productDefinitions = new BehaviorSubject<List<ProductDefinition>>(_productDefinitions);

                testObjects.SetupGet(o => o.ProductDefinitions)
                    .Returns(productDefinitions);


                var currencyCodes = new BehaviorSubject<List<CurrencyCode>>(_currencyCodes);

                testObjects.SetupGet(o => o.CurrencyCodes)
                           .Returns(currencyCodes);

                var curveGroups = new BehaviorSubject<List<CurveGroup>>(_curveGroups);

                testObjects.SetupGet(o => o.CurveGroups)
                           .Returns(curveGroups);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(c => c.ProductDefinitions)
                    .Returns(productDefinitions);

                curveControlService.SetupGet(c => c.CurrencyCodes)
                    .Returns(currencyCodes);

                curveControlService.SetupGet(c => c.CurveGroups)
                    .Returns(curveGroups);

                testObjects.SetupGet(o => o.CurveControlService)
                    .Returns(curveControlService.Object);

                curveControlService.SetupGet(c => c.ProductDefinitions)
                    .Returns(productDefinitions);

                curveControlService.Setup(c => c.GetProductDefinitionsSnapshot())
                    .Returns(_productDefinitions);

                var transformer = new Mock<IProductTransformer>();

                testObjects.SetupGet(o => o.ProductTransformer)
                    .Returns(transformer.Object);

                var controller = new ProductEditorController(curveControlService.Object,
                    TestMocks.GetSchedulerProvider().Object);

                controller.Transformer = transformer.Object;

                testObjects.SetupGet(o => o.Controller)
                    .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                    .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region Initialize

        [Test]
        public void ShouldNotInitialize_When_Initialized()
        {
            var testObjects = new ProductEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsBusy = false;

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }
        [Test]
        public void ShouldShowLoading_And_SubscribeComboItemsSources_On_InitializeCommand()
        {
            var testObjects = new ProductEditorControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);

            Mock.Get(testObjects.CurveControlService)
                .Verify(c => c.SubscribeProductDefinitions());

            Mock.Get(testObjects.CurveControlService)
                .Verify(c => c.SubscribeCurrencyCodes());

            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.ProductDefinitions);

            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.CurveGroups);

            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.CurrencyCodes);
            
        }
        #endregion

        #region Populate Combos

        [Test]
        public void ShouldPopulateAllCombos_When_Initialized()
        {
            var product1 = new ProductDefinitionTestObjectBuilder().WithName("product-1")
                .Build();
            var product2 = new ProductDefinitionTestObjectBuilder().WithName("product-2")
                .Build();

            var curveGroups = new List<CurveGroup>([
                new CurveGroupTestObjectBuilder().Crude(),
                new CurveGroupTestObjectBuilder().FxCurveGroup()
            ]);
            var currencyCodes = new List<CurrencyCode>(
            [
                new CurrencyCode(1, "USD"),
                new CurrencyCode(2, "EUR")
            ]);
            var testObjects = new ProductEditorControllerTestObjectBuilder()
                .WithCurveGroups(curveGroups)
                .WithCurrencyCodes(currencyCodes)
                .WithProductDefinitions([product1, product2])
                .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.ProductDefinitions, Is.Not.Null);
            Assert.That(testObjects.ViewModel.ProductDefinitions.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.CurrencyCodes.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.CurveGroups.Count, Is.EqualTo(2));

            Assert.That(testObjects.ViewModel.PricingTenorGroups.Count, Is.EqualTo(System.Enum.GetValues<PricingTenorGroupType>().Length));
            Assert.That(testObjects.ViewModel.UnitsOfMeasure.Count, Is.EqualTo(System.Enum.GetValues<UnitOfMeasure>().Length));
            Assert.That(testObjects.ViewModel.PricingTenorGroups.Count, Is.EqualTo(System.Enum.GetValues<PricingTenorGroupType>().Length));
        }

        #endregion

        #region Populate Product Details on Product Change

        [Test]
        public void ShouldPopulateProduct_When_ProductDefinitionSelected()
        {
            var product1 = new ProductDefinitionTestObjectBuilder().WithName("product-1")
                                                                   .WithCurveGroup(new CurveGroupTestObjectBuilder().Crude())
                                                                   .WithCurrency(1)
                                                                   .Build();
            var product2 = new ProductDefinitionTestObjectBuilder().WithName("product-2")
                                                                   .WithCurveGroup(new CurveGroupTestObjectBuilder().MoGas())
                                                                   .WithCurrency(2)
                                                                   .Build();

            var curveGroups = new List<CurveGroup>([
                new CurveGroupTestObjectBuilder().Crude(),
                new CurveGroupTestObjectBuilder().FxCurveGroup()
            ]);

            var currencyCodes = new List<CurrencyCode>(
            [
                new CurrencyCode(1, "USD"),
                new CurrencyCode(2, "EUR")
            ]);

            var testObjects = new ProductEditorControllerTestObjectBuilder().WithCurveGroups(curveGroups)
                                                                            .WithCurrencyCodes(currencyCodes)
                                                                            .WithProductDefinitions([product1, product2])
                                                                            .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            //ACT
            testObjects.ViewModel.SelectedProductDefinition = new ProductDefinitionItem(product1);


            // ASSERT

            Mock.Get(testObjects.ProductTransformer)
                .Verify(t => t.TransformProduct(testObjects.ViewModel, product1,curveGroups,currencyCodes));


        }

        #endregion

        #region Dispose

        [Test]
        public void ShouldNotTransformFromPriceCurve_When_Disposed()
        {
            var productDefinition = new ProductDefinitionTestObjectBuilder().Build();

            var item = new ProductDefinitionItem(productDefinition);

            var testObjects = new ProductEditorControllerTestObjectBuilder().WithProductDefinitions([productDefinition])
                                                                                .WithProductDefinitions([])
                                                                                .Build();
            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.SelectedProductDefinition = item;

            // ASSERT
            Mock.Get(testObjects.ProductTransformer)
                .Verify(t => t.TransformProduct(testObjects.ViewModel,
                                                   It.IsAny<ProductDefinition>(),
                                                   It.IsAny<List<CurveGroup>>(),
                                                   It.IsAny<List<CurrencyCode>>()),
                                                   Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var productDefinition = new ProductDefinitionTestObjectBuilder().Build();

            var item = new ProductDefinitionItem(productDefinition);

            var testObjects = new ProductEditorControllerTestObjectBuilder().WithProductDefinitions([productDefinition])
                .WithProductDefinitions([])
                .Build();
            // ARRANGE

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            testObjects.ViewModel.SelectedProductDefinition = item;

            // ASSERT
            Mock.Get(testObjects.ProductTransformer)
                .Verify(t => t.TransformProduct(testObjects.ViewModel,
                        It.IsAny<ProductDefinition>(),
                        It.IsAny<List<CurveGroup>>(),
                        It.IsAny<List<CurrencyCode>>()),
                    Times.Never);
        }
    
        #endregion
    }
}