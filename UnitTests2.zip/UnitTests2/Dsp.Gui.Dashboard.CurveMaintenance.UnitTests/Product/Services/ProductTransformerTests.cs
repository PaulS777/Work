﻿using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.CurveMaintenance.Product.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Product.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;
using System.Collections.Generic;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Product.Services
{
    [TestFixture]
    public class ProductTransformerTests
    {
        [Test]
        public void ShouldTransformProduct()
        {
            var unitsOfMeasure = new[] { UnitOfMeasure.BBL, UnitOfMeasure.MT, UnitOfMeasure.M3 };

            var ccy1 = new CurrencyCode(1, "EUR");
            var ccy2 = new CurrencyCode(2, "USD");

            var ccyItem1 = new CurrencyCodeItem(ccy1);
            var ccyItem2 = new CurrencyCodeItem(ccy2);

            var currencyItems = new[] { ccyItem1, ccyItem2 };

            var currencies = new List<CurrencyCode>() { ccy1, ccy2 };

            var curveGroup1 = new CurveGroupTestObjectBuilder().Crude();
            var curveGroup2 = new CurveGroupTestObjectBuilder().FxCurveGroup();
            var curveGroups = new List<CurveGroup>([
                curveGroup1,
                curveGroup2
            ]);
          
            var curveGroupItem1 = new CurveGroupItem(curveGroup1);
            var curveGroupItem2 = new CurveGroupItem(curveGroup2);

            var curveGroupItems = new 
                List<CurveGroupItem>([
                    curveGroupItem1,
                    curveGroupItem2
            ]);
            var product = new ProductDefinitionTestObjectBuilder().WithId(1)
                .WithPricingTenorGroupType(PricingTenorGroupType.Monthly)
                .WithUnitOfMeasure(UnitOfMeasure.M3)
                .WithLotSize(1000)
                .WithCurveGroup(curveGroup1)
                .WithCurrency(2)
                .WithCurrencyDenominationFactor(1)
                .WithDensity(new Density(UnitOfMeasure.GAL, 0.5d))
                .Build();

            var viewModel = new ProductEditorViewModel
            {
                UnitsOfMeasure = unitsOfMeasure,
                CurrencyCodes = currencyItems,
                CurveGroups = curveGroupItems

            };

            var transformer = new ProductTransformer();

            // ACT
            transformer.TransformProduct(viewModel, product, curveGroups, currencies);

            // ASSERT
            Assert.That(viewModel.Product.Name, Is.EqualTo(product.Name));
            Assert.That(viewModel.Product.Description, Is.EqualTo(product.Description));
            Assert.That(viewModel.Product.UnitOfMeasure, Is.EqualTo(product.UnitOfMeasure));
            Assert.That(viewModel.Product.LotSize, Is.EqualTo(product.LotSize));
            Assert.That(viewModel.Product.CurveGroup, Is.EqualTo(curveGroupItem1));
            Assert.That(viewModel.Product.CurrencyCode, Is.EqualTo(ccyItem2));
            Assert.That(viewModel.Product.CurrencyDenominationFactor, Is.EqualTo(product.CurrencyDenominationFactor));
            Assert.That(viewModel.Product.DensityUnitOfMeasure, Is.EqualTo(product.Density.UnitOfVolume));
            Assert.That(viewModel.Product.DensityFactor, Is.EqualTo(product.Density.Factor));
            Assert.That(viewModel.Product.PricingTenorGroup, Is.EqualTo(product.PricingTenorGroup));
            Assert.That(viewModel.Product.PriceStep, Is.EqualTo(product.PriceStep));
            Assert.That(viewModel.Product.Precision, Is.EqualTo(product.Precision));
        }
        
        [Test]
        public void ShouldClearPriceCurve()
        {
            var unitsOfMeasure = new[] { UnitOfMeasure.BBL, UnitOfMeasure.MT, UnitOfMeasure.M3 };

            var ccy1 = new CurrencyCode(1, "EUR");
            var ccy2 = new CurrencyCode(2, "USD");

            var ccyItem1 = new CurrencyCodeItem(ccy1);
            var ccyItem2 = new CurrencyCodeItem(ccy2);

            var currencyItems = new[] { ccyItem1, ccyItem2 };

            var currencies = new List<CurrencyCode>() { ccy1, ccy2 };

            var curveGroups = new List<CurveGroup>([
                new CurveGroupTestObjectBuilder().Crude(),
                new CurveGroupTestObjectBuilder().FxCurveGroup()
            ]);

            var product = new ProductDefinitionTestObjectBuilder().WithId(1)
                .WithPricingTenorGroupType(PricingTenorGroupType.Monthly)
                .WithUnitOfMeasure(UnitOfMeasure.M3)
                .WithLotSize(1000)
                .WithCurrency(2)
                .WithCurrencyDenominationFactor(1)
                .WithDensity(new Density(UnitOfMeasure.GAL, 0.5d))
                .Build();

            var viewModel = new ProductEditorViewModel
            {
                UnitsOfMeasure = unitsOfMeasure,
                CurrencyCodes = currencyItems,

            };

            var transformer = new ProductTransformer();

            // ARRANGE
            transformer.TransformProduct(viewModel, product, curveGroups, currencies);

            // ACT
            transformer.ClearProduct(viewModel);

            // ASSERT
            Assert.That(viewModel.Product.Name, Is.Null);
            Assert.That(viewModel.Product.Description, Is.Null);
            Assert.That(viewModel.Product.UnitOfMeasure, Is.Null);
            Assert.That(viewModel.Product.LotSize, Is.Null);
            Assert.That(viewModel.Product.CurveGroup, Is.Null);
            Assert.That(viewModel.Product.CurrencyCode, Is.Null);
            Assert.That(viewModel.Product.CurrencyDenominationFactor, Is.Null);
            Assert.That(viewModel.Product.DensityUnitOfMeasure, Is.Null);
            Assert.That(viewModel.Product.DensityFactor, Is.Null);
            Assert.That(viewModel.Product.PricingTenorGroup, Is.Null);
            Assert.That(viewModel.Product.PriceStep, Is.Null);
            Assert.That(viewModel.Product.Precision, Is.Null);



        }
    }
}
