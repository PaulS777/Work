﻿using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.ViewModels
{
	[TestFixture]
	public class NavigationViewModelTests
	{
		[Test]
		public void ShouldReturnNavigationServiceExtension()
		{
			var viewModel = new NavigationViewModel();

			// ACT
			var result = viewModel.GetNavigationService();

			// ASSERT
			Assert.That(result, Is.TypeOf<NavigationServiceExtension>());
		}
	}
}
