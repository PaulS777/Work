﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.ViewModels;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services
{
	[TestFixture]
	public class FxCurveTransformerTests
	{
        [Test]
        public void ShouldTransformFxCurve()
        {
            var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
            var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

            var currencies = new[] { ccy1, ccy2 };

            var viewModel = new FxCurveEditorViewModel
                            {
                                BaseCurrencyCodes = currencies,
                                QuoteCurrencyCodes = currencies
                            };

            var fxCurve = new FxCurveDefinitionTestObjectBuilder().WithName("name")
                                                                  .WithBaseCurrencyId(1)
                                                                  .WithQuoteCurrencyId(2)
                                                                  .WithPeriodCount(20)
                                                                  .Build();

            var transformer = new FxCurveTransformer();

            // ACT
            transformer.TransformFxCurve(viewModel, fxCurve);

            // ASSERT
            Assert.That(viewModel.FxCurve.Name, Is.EqualTo("name"));
            Assert.That(viewModel.FxCurve.BaseCurrencyCode.Id, Is.EqualTo(1));
            Assert.That(viewModel.FxCurve.QuoteCurrencyCode.Id, Is.EqualTo(2));
            Assert.That(viewModel.FxCurve.PeriodCount, Is.EqualTo(3));
		}

        [Test]
        public void ShouldClearFxCurve()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var viewModel = new FxCurveEditorViewModel
                            {
                                FxCurve =
                                {
                                    Name = "name",
                                    BaseCurrencyCode = ccy1,
                                    QuoteCurrencyCode = ccy2,
                                    PeriodCount = 3
                                }
                            };

            var transformer = new FxCurveTransformer();

            // ACT
            transformer.ClearFxCurve(viewModel.FxCurve);

            // ASSERT
            Assert.That(viewModel.FxCurve.Name, Is.Null);
            Assert.That(viewModel.FxCurve.BaseCurrencyCode, Is.Null);
            Assert.That(viewModel.FxCurve.QuoteCurrencyCode, Is.Null);
            Assert.That(viewModel.FxCurve.PeriodCount, Is.Null);
		}
	}
}
