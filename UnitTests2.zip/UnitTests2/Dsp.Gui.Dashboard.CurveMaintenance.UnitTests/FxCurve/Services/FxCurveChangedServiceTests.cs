﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.ViewModels;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services
{
	[TestFixture]
    public class FxCurveChangedServiceTests
    {
        [Test]
        public void ShouldPublishTrue_On_BaseCurrency_Changed()
        {
            var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
            var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));
			var ccy3 = new CurrencyCodeItem(new CurrencyCode(3, "GBP"));

			var viewModel = new FxCurveViewModel
                            {
                                BaseCurrencyCode = ccy1,
                                QuoteCurrencyCode = ccy2
                            };

            var service = new FxCurveChangedService();

            var result = new bool?();

            using (service.ObserveChanged(viewModel, ccy1.Id, ccy2.Id, 10)
                          .Subscribe(value => result = value))
            {
                // ACT
                viewModel.BaseCurrencyCode = ccy3;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_BaseCurrency_Not_Changed()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var viewModel = new FxCurveViewModel
                            {
                                BaseCurrencyCode = ccy1,
                                QuoteCurrencyCode = ccy2
                            };

			var service = new FxCurveChangedService();

            var result = new bool?();

            using (service.ObserveChanged(viewModel, ccy1.Id, ccy2.Id, 10)
                          .Subscribe(value => result = value))
            {
                // ACT
                viewModel.BaseCurrencyCode = ccy1;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_QuoteCurrency_Changed()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));
			var ccy3 = new CurrencyCodeItem(new CurrencyCode(3, "GBP"));

			var viewModel = new FxCurveViewModel
                            {
                                BaseCurrencyCode = ccy1,
                                QuoteCurrencyCode = ccy2
                            };

            var service = new FxCurveChangedService();

            var result = new bool?();

            using (service.ObserveChanged(viewModel, ccy1.Id, ccy2.Id, 10)
                          .Subscribe(value => result = value))
            {
                // ACT
                viewModel.QuoteCurrencyCode = ccy3;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_QuoteCurrency_NotChanged()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var viewModel = new FxCurveViewModel
                            {
                                BaseCurrencyCode = ccy1,
                                QuoteCurrencyCode = ccy2
                            };

			var service = new FxCurveChangedService();

            var result = new bool?();

            using (service.ObserveChanged(viewModel, ccy1.Id, ccy2.Id, 10)
                          .Subscribe(value => result = value))
            {
                // ACT
                viewModel.QuoteCurrencyCode = ccy2;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

		[Test]
        public void ShouldPublishTrue_On_PeriodCount_Changed()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var viewModel = new FxCurveViewModel
                            {
                                BaseCurrencyCode = ccy1,
                                QuoteCurrencyCode = ccy2
                            };

            var service = new FxCurveChangedService();

            var result = new bool?();

            using (service.ObserveChanged(viewModel, ccy1.Id, ccy2.Id, 10)
                          .Subscribe(value => result = value))
			{
                // ACT
                viewModel.PeriodCount = 9;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_PeriodCount_Not_Changed()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var viewModel = new FxCurveViewModel
                            {
                                BaseCurrencyCode = ccy1,
                                QuoteCurrencyCode = ccy2
                            };

            var service = new FxCurveChangedService();

            var result = new bool?();

            using (service.ObserveChanged(viewModel, ccy1.Id, ccy2.Id, 10)
                          .Subscribe(value => result = value))
			{
                // ACT
                viewModel.PeriodCount = 10;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
	}
}
