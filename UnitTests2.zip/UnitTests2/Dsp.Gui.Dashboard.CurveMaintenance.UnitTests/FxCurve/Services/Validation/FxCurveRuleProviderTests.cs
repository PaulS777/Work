﻿using System.Linq;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation.Rules;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation.Rules;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services.Validation
{
    internal interface IFxCurveRuleProviderTestObjects
    {
        FxCurveRuleProvider FxCurveRuleProvider { get; }
	}

	[TestFixture]
	public class FxCurveRuleProviderTests
	{
        private class FxCurveRuleProviderTestObjectBuilder
        {
            public IFxCurveRuleProviderTestObjects Build()
            {
                var testObjects = new Mock<IFxCurveRuleProviderTestObjects>();

                var duplicateCcyPairRule = new Mock<IDuplicateCcyPairValidationRule>();

                var duplicateCcyPairRuleFactory = new Mock<IServiceFactory<IDuplicateCcyPairValidationRule>>();

                duplicateCcyPairRuleFactory.Setup(f => f.Create())
                                           .Returns(duplicateCcyPairRule.Object);

                var ruleProvider = new FxCurveRuleProvider(duplicateCcyPairRuleFactory.Object);

                testObjects.SetupGet(o => o.FxCurveRuleProvider)
                           .Returns(ruleProvider);

				return testObjects.Object;
            }
		}

		[Test]
        public void ShouldProvideValidationRules()
        {
            var testObjects = new FxCurveRuleProviderTestObjectBuilder().Build();

            // ACT
            var rules = testObjects.FxCurveRuleProvider.ValidationRules;

			// ASSERT
			Assert.That(rules.ContainsKey("QuoteCurrencyCode"));
            Assert.That(rules["QuoteCurrencyCode"].OfType<CcyPairValidationRule>().Count(), Is.EqualTo(1));
            Assert.That(rules["QuoteCurrencyCode"].OfType<IDuplicateCcyPairValidationRule>().Count(), Is.EqualTo(1));

			Assert.That(rules.ContainsKey("PeriodCount"));
            Assert.That(rules["PeriodCount"].OfType<PositiveIntegerValidationRule>().Count(), Is.EqualTo(1));
        }
	}
}
