﻿using System;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation.Rules;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services.Validation.Rules
{
	[TestFixture]
	public class CcyPairValidationRuleTests
	{
        [Test]
        public void ShouldReturnTrue_When_Validate_With_Null()
        {
            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(null);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [TestCase("USD", null)]
        [TestCase(null, "USD")]
		public void ShouldReturnTrue_When_Validate_With_BaseCcy_Or_QuoteCcy_Null(string baseCcy, string quoteCcy)
        {
            var ccyPair = new Tuple<string, string>(baseCcy, quoteCcy);

            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

			// ASSERT
			Assert.That(result.IsValid, Is.True);
		}

        [Test]
        public void ShouldReturnFalse_When_Validate_With_BaseCcy_SameAs_QuoteCcy()
        {
            var ccyPair = new Tuple<string, string>("USD", "USD");

			var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
            Assert.That(result.ErrorContent, Is.EqualTo(CcyPairValidationRule.DuplicateCurrencies));
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_Missing_Usd()
        {
            var ccyPair = new Tuple<string, string>("EUR", "GBP");

            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
            Assert.That(result.ErrorContent, Is.EqualTo(CcyPairValidationRule.MustBeQuotedAgainstUsd));
        }

        [TestCase("CAD")]
        [TestCase("CHF")]
        [TestCase("JPY")]

		public void ShouldReturnFalse_When_Validate_With_Invalid_QuoteUsdCcyConvention(string ccy)
        {
            var ccyPair = new Tuple<string, string>(ccy, "USD");

            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

			// ASSERT
			Assert.That(result.IsValid, Is.False);
            Assert.That(result.ErrorContent, Is.EqualTo(CcyPairValidationRule.InvalidCurrencyConvention));
		}

        [TestCase("CAD")]
        [TestCase("CHF")]
        [TestCase("JPY")]

        public void ShouldReturnTrue_When_Validate_With_Valid_BaseUsdCcyConvention(string ccy)
        {
            var ccyPair = new Tuple<string, string>("USD", ccy);

            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [TestCase("EUR")]
        [TestCase("GBP")]
        [TestCase("AUD")]

        public void ShouldReturnFalse_When_Validate_With_Invalid_BaseUsdCcyConvention(string ccy)
        {
            var ccyPair = new Tuple<string, string>("USD", ccy);

            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
            Assert.That(result.ErrorContent, Is.EqualTo(CcyPairValidationRule.InvalidCurrencyConvention));
        }

        [TestCase("EUR")]
        [TestCase("GBP")]
        [TestCase("AUD")]

        public void ShouldReturnTrue_When_Validate_With_Valid_QuoteUsdCcyConvention(string ccy)
        {
            var ccyPair = new Tuple<string, string>(ccy, "USD");

            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

		[Test]
        public void ShouldReturnTrue_When_Validate_With_BaseCcyUsd_QuoteNonMajorCcy()
        {
            var ccyPair = new Tuple<string, string>("USD", "NZD");

            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
		}

        [Test]
        public void ShouldReturnFalse_When_Validate_With_BaseNonMajorCcy()
        {
            var ccyPair = new Tuple<string, string>("NZD", "USD");

            var rule = new CcyPairValidationRule();

            // ACT
            var result = rule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
            Assert.That(result.ErrorContent, Is.EqualTo(CcyPairValidationRule.InvalidCurrencyConvention));
		}
	}
}
