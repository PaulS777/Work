﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation.Rules;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services.Validation.Rules
{
    public interface IDuplicateCcyPairValidationRuleTestObjects
    {
        DuplicateCcyPairValidationRule ValidationRule { get; }
	}

	[TestFixture]
	public class DuplicateCcyPairValidationRuleTests
	{
        private class DuplicateCcyPairValidationRuleTestObjectBuilder
        {
            private IEnumerable<CurrencyCode> _currencyCodes;
            private IEnumerable<FxCurveDefinition> _fxCurveDefinitions;

            public DuplicateCcyPairValidationRuleTestObjectBuilder WithCurrencyCodes(IEnumerable<CurrencyCode> values)
            {
                _currencyCodes = values;
                return this;
            }

            public DuplicateCcyPairValidationRuleTestObjectBuilder WithFxCurveDefinitions(IEnumerable<FxCurveDefinition> values)
            {
                _fxCurveDefinitions = values;
                return this;
            }

			public IDuplicateCcyPairValidationRuleTestObjects Build()
            {
                var testObjects = new Mock<IDuplicateCcyPairValidationRuleTestObjects>();

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.Setup(c => c.GetCurrencyCodesSnapshot())
                                   .Returns(_currencyCodes);

                curveControlService.Setup(c => c.GetFxCurveDefinitionsSnapshot())
                                   .Returns(_fxCurveDefinitions);

                var validationRule = new DuplicateCcyPairValidationRule(curveControlService.Object);

                testObjects.SetupGet(o => o.ValidationRule)
                           .Returns(validationRule);

                return testObjects.Object;
            }
		}

        [Test]
        public void ShouldReturnTrue_When_Validate_With_Null()
        {
            var testObjects = new DuplicateCcyPairValidationRuleTestObjectBuilder().Build();

            // ACT
            var result = testObjects.ValidationRule.Validate(null);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
		}

        [TestCase("USD", null)]
        [TestCase(null, "USD")]
        public void ShouldReturnTrue_When_Validate_With_BaseCcy_Or_QuoteCcy_Null(string baseCcy, string quoteCcy)
        {
            var ccyPair = new Tuple<string, string>(baseCcy, quoteCcy);

            var testObjects = new DuplicateCcyPairValidationRuleTestObjectBuilder().Build();

			// ACT
			var result = testObjects.ValidationRule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Validate_With_CcyPair_Matches_ExistingCurve()
        {
            var currencyCodes = new[]
                                {
                                    new CurrencyCode(1, "EUR"),
                                    new CurrencyCode(2, "USD")
								};

            var fxCurves = new[]
                           {
                               new FxCurveDefinitionTestObjectBuilder().WithBaseCurrencyId(1).WithQuoteCurrencyId(2).Build()
                           };

            var ccyPair = new Tuple<string, string>("EUR", "USD");

            var testObjects = new DuplicateCcyPairValidationRuleTestObjectBuilder().WithCurrencyCodes(currencyCodes)
                                                                                   .WithFxCurveDefinitions(fxCurves)
                                                                                   .Build();

            // ACT
            var result = testObjects.ValidationRule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.False);
        }

        [Test]
        public void ShouldReturnTrue_When_Validate_With_CcyPair_NotMatches_ExistingCurve()
        {
            var currencyCodes = new[]
                                {
                                    new CurrencyCode(1, "EUR"),
                                    new CurrencyCode(2, "USD")
                                };

            var fxCurves = new[]
                           {
                               new FxCurveDefinitionTestObjectBuilder().WithBaseCurrencyId(1).WithQuoteCurrencyId(2).Build()
                           };

            var ccyPair = new Tuple<string, string>("EUR", "GBP");

            var testObjects = new DuplicateCcyPairValidationRuleTestObjectBuilder().WithCurrencyCodes(currencyCodes)
                                                                                   .WithFxCurveDefinitions(fxCurves)
                                                                                   .Build();

            // ACT
            var result = testObjects.ValidationRule.Validate(ccyPair);

            // ASSERT
            Assert.That(result.IsValid, Is.True);
        }
	}
}
