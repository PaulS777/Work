﻿using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation.Rules;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services.Validation.Rules
{
	[TestFixture]
	public class CcyLengthValidationRuleTests
	{
		[Test]
		public void ShouldReturnTrue_When_Validate_With_Null()
		{
			var rule = new CcyLengthValidationRule();

			// ACT
			var result = rule.Validate(null);

			// ASSERT
			Assert.That(result.IsValid, Is.True);
		}

		[Test]
		public void ShouldReturnTrue_When_Validate_With_CorrectLength()
		{
			var rule = new CcyLengthValidationRule();

			// ACT
			var result = rule.Validate("JPY");

			// ASSERT
			Assert.That(result.IsValid, Is.True);
		}

		[TestCase("JP")]
		[TestCase(" JP")]
		[TestCase("JPY_")]
		public void ShouldReturnFalse_When_Validate_With_IncorrectLength(string value)
		{
			var rule = new CcyLengthValidationRule();

			// ACT
			var result = rule.Validate(value);

			// ASSERT
			Assert.That(result.IsValid, Is.False);
		}
	}
}
