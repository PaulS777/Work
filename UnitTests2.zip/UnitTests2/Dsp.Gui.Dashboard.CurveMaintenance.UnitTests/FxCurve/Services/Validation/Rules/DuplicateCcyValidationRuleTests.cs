﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation.Rules;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services.Validation.Rules
{
	public interface IDuplicateCcyValidationRuleTestObjects
	{
		DuplicateCcyValidationRule ValidationRule { get; }
	}

	[TestFixture]
	public class DuplicateCcyValidationRuleTests
	{
		private class DuplicateCcyValidationRuleTestObjectBuilder
		{
			private IEnumerable<CurrencyCode> _currencyCodes;

			public DuplicateCcyValidationRuleTestObjectBuilder WithCurrencyCodes(IEnumerable<CurrencyCode> values)
			{
				_currencyCodes = values;
				return this;
			}

			public IDuplicateCcyValidationRuleTestObjects Build()
			{
				var testObjects = new Mock<IDuplicateCcyValidationRuleTestObjects>();

				var curveControlService = new Mock<ICurveControlService>();

				curveControlService.Setup(c => c.GetCurrencyCodesSnapshot())
								   .Returns(_currencyCodes);

				var validationRule = new DuplicateCcyValidationRule(curveControlService.Object);

				testObjects.SetupGet(o => o.ValidationRule)
						   .Returns(validationRule);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldReturnTrue_When_Validate_With_Null()
		{
			var testObjects = new DuplicateCcyValidationRuleTestObjectBuilder().Build();

			// ACT
			var result = testObjects.ValidationRule.Validate(null);

			// ASSERT
			Assert.That(result.IsValid, Is.True);
		}

		[Test]
		public void ShouldReturnFalse_When_Validate_With_Ccy_Matches_Existing()
		{
			var currencyCodes = new[]
								{
									new CurrencyCode(1, "EUR"),
									new CurrencyCode(2, "USD")
								};

			var testObjects = new DuplicateCcyValidationRuleTestObjectBuilder().WithCurrencyCodes(currencyCodes)
																			   .Build();

			// ACT
			var result = testObjects.ValidationRule.Validate("EUR");

			// ASSERT
			Assert.That(result.IsValid, Is.False);
		}

		[Test]
		public void ShouldReturnTrue_When_Validate_With_Ccy_NotMatches_Existing()
		{
			var currencyCodes = new[]
								{
									new CurrencyCode(1, "EUR"),
									new CurrencyCode(2, "USD")
								};

			var testObjects = new DuplicateCcyValidationRuleTestObjectBuilder().WithCurrencyCodes(currencyCodes)
																			   .Build();

			// ACT
			var result = testObjects.ValidationRule.Validate("AUD");

			// ASSERT
			Assert.That(result.IsValid, Is.True);
		}
	}
}
