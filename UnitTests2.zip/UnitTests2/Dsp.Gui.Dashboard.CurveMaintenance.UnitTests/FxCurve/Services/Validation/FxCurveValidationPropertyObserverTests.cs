﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services.Validation
{
	[TestFixture]
	public class FxCurveValidationPropertyObserverTests
	{
        [Test]
        public void ShouldObserveQuoteCurrencyCode_With_BaseCurrencyCode()
        {
            var ccyCode = new CurrencyCodeItem(new CurrencyCode(1, "USD"));

            var viewModel = new FxCurveViewModel();

            var propertyObserver = new FxCurveValidationPropertyObserver();

            ValidationProperty result = null;

            var expected = new Tuple<string, string>("USD", null);

            using (propertyObserver.ObserveValidationProperties(viewModel)
                                   .Subscribe(value => result = value))
            {
                // ACT
                viewModel.BaseCurrencyCode = ccyCode;

                // ASSERT
                Assert.That(result, Is.Not.Null);
                Assert.That(result.PropertyName, Is.EqualTo("QuoteCurrencyCode"));
                Assert.That(result.RequiresValidation, Is.True);

                Assert.That(result.Value.Equals(expected));
            }
        }

        [Test]
        public void ShouldObserveQuoteCurrencyCode_With_Base_And_QuoteCurrencyCode()
        {
            var ccyCode1 = new CurrencyCodeItem(new CurrencyCode(1, "USD"));
            var ccyCode2 = new CurrencyCodeItem(new CurrencyCode(2, "CHF"));

			var viewModel = new FxCurveViewModel
                            {
                                BaseCurrencyCode = ccyCode1
                            };

            var propertyObserver = new FxCurveValidationPropertyObserver();

            ValidationProperty result = null;

            var expected = new Tuple<string, string>("USD", "CHF");

            

            using (propertyObserver.ObserveValidationProperties(viewModel)
                                   .Subscribe(value => result = value))
            {
                // ACT
                viewModel.QuoteCurrencyCode = ccyCode2;

                // ASSERT
                Assert.That(result, Is.Not.Null);
                Assert.That(result.PropertyName, Is.EqualTo("QuoteCurrencyCode"));
                Assert.That(result.RequiresValidation, Is.True);

                Assert.That(result.Value.Equals(expected));
            }
        }

		[Test]
        public void ShouldObservePeriodCount()
        {
            var viewModel = new FxCurveViewModel();

            var propertyObserver = new FxCurveValidationPropertyObserver();

            ValidationProperty result = null;

            using (propertyObserver.ObserveValidationProperties(viewModel)
                                   .Subscribe(value => result = value))
            {
                // ACT
                viewModel.PeriodCount = 1;

                // ASSERT
                Assert.That(result, Is.Not.Null);
                Assert.That(result.PropertyName, Is.EqualTo("PeriodCount"));
                Assert.That(result.RequiresValidation, Is.True);
                Assert.That(result.Value, Is.EqualTo(1));
            }
        }
	}
}
