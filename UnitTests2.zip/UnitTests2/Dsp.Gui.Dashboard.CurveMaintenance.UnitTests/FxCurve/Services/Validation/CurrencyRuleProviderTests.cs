﻿using System.Linq;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation.Rules;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services.Validation
{
	internal interface ICurrencyRuleProviderTestObjects
	{
		CurrencyRuleProvider CurrencyRuleProvider { get; }
	}

	[TestFixture]
	public class CurrencyRuleProviderTests
	{
		private class CurrencyRuleProviderTestObjectBuilder
		{
			public ICurrencyRuleProviderTestObjects Build()
			{
				var testObjects = new Mock<ICurrencyRuleProviderTestObjects>();

				var duplicateCcyRule = new Mock<IDuplicateCcyValidationRule>();

				var duplicateCcyRuleFactory = new Mock<IServiceFactory<IDuplicateCcyValidationRule>>();

				duplicateCcyRuleFactory.Setup(f => f.Create())
									   .Returns(duplicateCcyRule.Object);

				var ruleProvider = new CurrencyRuleProvider(duplicateCcyRuleFactory.Object);

				testObjects.SetupGet(o => o.CurrencyRuleProvider)
						   .Returns(ruleProvider);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldProvideValidationRules()
		{
			var testObjects = new CurrencyRuleProviderTestObjectBuilder().Build();

			// ACT
			var rules = testObjects.CurrencyRuleProvider.ValidationRules;

			// ASSERT
			Assert.That(rules.ContainsKey("Currency"));
			Assert.That(rules["Currency"].OfType<CcyLengthValidationRule>().Count(), Is.EqualTo(1));
			Assert.That(rules["Currency"].OfType<IDuplicateCcyValidationRule>().Count(), Is.EqualTo(1));
		}
	}
}
