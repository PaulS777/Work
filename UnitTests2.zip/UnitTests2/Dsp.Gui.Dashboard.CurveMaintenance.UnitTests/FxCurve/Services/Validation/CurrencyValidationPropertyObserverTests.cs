﻿using System;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.Validation;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services.Validation
{
	[TestFixture]
	public class CurrencyValidationPropertyObserverTests
	{
		[Test]
		public void ShouldObserveCurrency()
		{
			var viewModel = new CurrencyEditorViewModel();

			var propertyObserver = new CurrencyValidationPropertyObserver();

			ValidationProperty result = null;

			using (propertyObserver.ObserveValidationProperties(viewModel)
								   .Subscribe(value => result = value))
			{
				// ACT
				viewModel.Currency = "JPY";

				// ASSERT
				Assert.That(result, Is.Not.Null);
				Assert.That(result.PropertyName, Is.EqualTo("Currency"));
				Assert.That(result.RequiresValidation, Is.True);

				Assert.That(result.Value, Is.EqualTo("JPY"));
			}
		}
	}
}
