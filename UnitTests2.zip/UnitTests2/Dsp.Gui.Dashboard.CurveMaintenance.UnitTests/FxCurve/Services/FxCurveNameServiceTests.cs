﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services
{
    internal interface IFxCurveNameServiceTestObjects
    {
        FxCurveViewModel ViewModel { get; }
		FxCurveNameService FxCurveNameService { get; }
	}

	[TestFixture]
	public class FxCurveNameServiceTests
	{
        private class FxCurveNameServiceTestObjectBuilder
        {
            private CurrencyCodeItem _baseCurrencyCode;
            private CurrencyCodeItem _quoteCurrencyCode;

            public FxCurveNameServiceTestObjectBuilder WithBaseCurrencyCode(CurrencyCodeItem value)
            {
                _baseCurrencyCode = value;
                return this;
            }
            public FxCurveNameServiceTestObjectBuilder WithQuoteCurrencyCode(CurrencyCodeItem value)
            {
                _quoteCurrencyCode = value;
                return this;
            }

			public IFxCurveNameServiceTestObjects Build()
            {
                var testObjects = new Mock<IFxCurveNameServiceTestObjects>();

                var viewModel = new FxCurveViewModel
                                {
                                    BaseCurrencyCode = _baseCurrencyCode,
                                    QuoteCurrencyCode = _quoteCurrencyCode
                                };

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(viewModel);

                var service = new FxCurveNameService();

                testObjects.SetupGet(o => o.FxCurveNameService)
                           .Returns(service);

                return testObjects.Object;
            }
		}

		[Test]
        public void ShouldPublishName_On_QuoteCcy_With_BaseCcyChanged()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var testObjects = new FxCurveNameServiceTestObjectBuilder().WithBaseCurrencyCode(ccy1)
                                                                       .Build();

            string result = null;

            using (testObjects.FxCurveNameService.ObserveCurrencies(testObjects.ViewModel)
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.QuoteCurrencyCode = ccy2;

                // ASSERT
                Assert.That(result, Is.EqualTo("FX_EURUSD"));
            }
        }

        [Test]
        public void ShouldPublishName_On_BaseCcy_With_QuoteCcyChanged()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var testObjects = new FxCurveNameServiceTestObjectBuilder().WithQuoteCurrencyCode(ccy2)
                                                                       .Build();

            string result = null;

            using (testObjects.FxCurveNameService.ObserveCurrencies(testObjects.ViewModel)
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.BaseCurrencyCode = ccy1;

                // ASSERT
                Assert.That(result, Is.EqualTo("FX_EURUSD"));
            }
        }

        [Test]
        public void ShouldPublishEmptyString_On_QuoteCcy_With_BaseCcyNotSet()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));

			var testObjects = new FxCurveNameServiceTestObjectBuilder().Build();

            string result = null;

            using (testObjects.FxCurveNameService.ObserveCurrencies(testObjects.ViewModel)
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.QuoteCurrencyCode = ccy1;

                // ASSERT
                Assert.That(result, Is.EqualTo(string.Empty));
            }
        }

		[Test]
        public void ShouldPublishEmptyString_On_BaseCcy_With_QuoteCcyNotSet()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));

			var testObjects = new FxCurveNameServiceTestObjectBuilder().Build();

            string result = null;

            using (testObjects.FxCurveNameService.ObserveCurrencies(testObjects.ViewModel)
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.BaseCurrencyCode = ccy1;

                // ASSERT
                Assert.That(result, Is.EqualTo(string.Empty));
            }
        }
	}
}
