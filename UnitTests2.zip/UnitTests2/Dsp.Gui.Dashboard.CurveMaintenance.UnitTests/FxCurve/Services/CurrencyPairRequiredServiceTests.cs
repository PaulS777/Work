﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Services
{
    internal interface ICurrencyPairRequiredServiceTestObjects
    {
        FxCurveViewModel ViewModel { get; }
		CurrencyPairRequiredService CurrencyPairRequiredService { get; }
	}

	[TestFixture]
	public class CurrencyPairRequiredServiceTests
	{
        private class CurrencyPairRequiredServiceTestObjectBuilder
		{
            private CurrencyCodeItem _baseCurrencyCode;
            private CurrencyCodeItem _quoteCurrencyCode;

            public CurrencyPairRequiredServiceTestObjectBuilder WithBaseCurrencyCode(CurrencyCodeItem value)
            {
                _baseCurrencyCode = value;
                return this;
            }
            public CurrencyPairRequiredServiceTestObjectBuilder WithQuoteCurrencyCode(CurrencyCodeItem value)
            {
                _quoteCurrencyCode = value;
                return this;
            }

            public ICurrencyPairRequiredServiceTestObjects Build()
            {
                var testObjects = new Mock<ICurrencyPairRequiredServiceTestObjects>();

                var viewModel = new FxCurveViewModel
                                {
                                    BaseCurrencyCode = _baseCurrencyCode,
                                    QuoteCurrencyCode = _quoteCurrencyCode
                                };

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(viewModel);

                var service = new CurrencyPairRequiredService();

                testObjects.SetupGet(o => o.CurrencyPairRequiredService)
                           .Returns(service);

                return testObjects.Object;
            }
        }

		[Test]
        public void ShouldPublishTrue_On_BaseCurrency_With_QuoteCurrencyNull()
        {
            var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));

            var testObjects = new CurrencyPairRequiredServiceTestObjectBuilder().Build();

            var result = new bool?();

            using (testObjects.CurrencyPairRequiredService
                              .ObserveCurrencyPairRequired(testObjects.ViewModel)
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.BaseCurrencyCode = ccy1;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishTrue_On_QuoteCurrency_With_BaseCurrencyNull()
        {
            var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));

			var testObjects = new CurrencyPairRequiredServiceTestObjectBuilder().Build();

            var result = new bool?();

            using (testObjects.CurrencyPairRequiredService
                              .ObserveCurrencyPairRequired(testObjects.ViewModel)
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.QuoteCurrencyCode = ccy1;

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_QuoteCurrency_With_BaseCurrencySet()
        {
            var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var testObjects = new CurrencyPairRequiredServiceTestObjectBuilder().WithBaseCurrencyCode(ccy1)
                                                                                .Build();

            var result = new bool?();

            using (testObjects.CurrencyPairRequiredService
                              .ObserveCurrencyPairRequired(testObjects.ViewModel)
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.QuoteCurrencyCode = ccy2;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }

        [Test]
        public void ShouldPublishFalse_On_BaseCurrency_With_QuoteCurrencySet()
        {
			var ccy1 = new CurrencyCodeItem(new CurrencyCode(1, "EUR"));
			var ccy2 = new CurrencyCodeItem(new CurrencyCode(2, "USD"));

			var testObjects = new CurrencyPairRequiredServiceTestObjectBuilder().WithQuoteCurrencyCode(ccy2)
                                                                                .Build();

            var result = new bool?();

            using (testObjects.CurrencyPairRequiredService
                              .ObserveCurrencyPairRequired(testObjects.ViewModel)
                              .Subscribe(value => result = value))
            {
                // ACT
                testObjects.ViewModel.BaseCurrencyCode = ccy1;

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
	}
}
