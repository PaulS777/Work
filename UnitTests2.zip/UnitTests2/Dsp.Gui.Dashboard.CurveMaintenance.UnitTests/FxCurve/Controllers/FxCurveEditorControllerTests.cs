﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using System.Windows.Data;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Services.CurveUpdate;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation;
using Dsp.Gui.TestObjects;
using Dsp.ServiceContracts;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Controllers
{
    internal interface IFxCurveEditorControllerTestObjects
    {
        ICurrencyEditorController CurrencyEditor { get; }
        ICurveControlService CurveControlService { get; }
        ISubject<IList<FxCurveDefinition>> FxCurveDefinitions { get; }
		ISubject<List<CurrencyCode>> CurrencyCodes { get; }
        ICompositeDisposableEnvelope CompositeDisposable { get; }
        IFxCurveEditorToolBarService ToolBarService { get; }
        ISubject<Unit> ToolBarUndo { get; }
		ISubject<Unit> ToolBarUpdate { get; }
		IFxCurveTransformer FxCurveTransformer { get; }
		IFxCurveDefinitionItemCollectionFactory ItemCollectionFactory { get; }
		IFxCurveNameService FxCurveNameService { get; }
		ISubject<string> FxCurveName { get; }
		IFxCurveChangedService FxCurveChangedService { get; }
        ISubject<bool> FxCurveChanged { get; }
		IValidationService<FxCurveViewModel> ValidationService { get; }
        ISubject<Unit> Validation { get; }
        ICurrencyPairRequiredService CurrencyPairRequiredService { get; }
        ISubject<bool> CurrencyPairRequired { get; }
        IFxCurveUpdateService FxCurveUpdateService { get; }
        ISubject<AdminApiActionCompleted> FxCurveUpdateServiceResponse { get; }
		IPopupNotificationService PopupNotificationService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        ILogger Logger { get; }
		FxCurveEditorViewModel ViewModel { get; }
		FxCurveEditorController Controller { get; }
	}

    [TestFixture]
    public class FxCurveEditorControllerTests
    {
        private class FxCurveEditorControllerTestObjectBuilder
        {
            private IList<FxCurveDefinition> _fxCurveDefinitions;
            private List<CurrencyCode> _currencyCodes;
			private User _currentUser;
			private List<FxCurveDefinitionStatusItem> _itemCollectionFactoryResult = [];

			public FxCurveEditorControllerTestObjectBuilder WithFxCurveDefinitions(IList<FxCurveDefinition> values)
            {
                _fxCurveDefinitions = values;
                return this;
            }

            public FxCurveEditorControllerTestObjectBuilder WithCurrencyCodes(List<CurrencyCode> values)
            {
                _currencyCodes = values;
                return this;
            }

			public FxCurveEditorControllerTestObjectBuilder WithCurrentUser(User value)
			{
				_currentUser = value;
				return this;
			}

			public FxCurveEditorControllerTestObjectBuilder WithItemCollectionFactoryResult(List<FxCurveDefinitionStatusItem> values)
			{
				_itemCollectionFactoryResult = values;
				return this;
			}

			public IFxCurveEditorControllerTestObjects Build()
            {
                var testObjects = new Mock<IFxCurveEditorControllerTestObjects>();

				var currencyEditorController = new Mock<ICurrencyEditorController>();

				var currencyEditor = new CurrencyEditorViewModel();

				currencyEditorController.SetupGet(c => c.ViewModel)
										.Returns(currencyEditor);

				testObjects.SetupGet(o => o.CurrencyEditor)
						   .Returns(currencyEditorController.Object);

                var fxCurveDefinitions = new BehaviorSubject<IList<FxCurveDefinition>>(_fxCurveDefinitions);

                testObjects.SetupGet(o => o.FxCurveDefinitions)
                           .Returns(fxCurveDefinitions);

                var currencyCodes = new BehaviorSubject<List<CurrencyCode>>(_currencyCodes);

                testObjects.SetupGet(o => o.CurrencyCodes)
                           .Returns(currencyCodes);

                var curveControlService = new Mock<ICurveControlService>();

				curveControlService.SetupGet(c => c.CurrentUser)
								   .Returns(Observable.Return(_currentUser));

				curveControlService.SetupGet(c => c.FxCurveDefinitions)
                                   .Returns(fxCurveDefinitions);

                curveControlService.SetupGet(c => c.CurrencyCodes)
                                   .Returns(currencyCodes);

				curveControlService.Setup(c => c.GetCurrencyCodesSnapshot())
								   .Returns(_currencyCodes);

                testObjects.SetupGet(o => o.CurveControlService)
                           .Returns(curveControlService.Object);

                var toolBarUndo = new Subject<Unit>();

                testObjects.SetupGet(o => o.ToolBarUndo)
                           .Returns(toolBarUndo);

				var toolBarUpdate = new Subject<Unit>();

				testObjects.SetupGet(o => o.ToolBarUpdate)
						   .Returns(toolBarUpdate);

                var toolBar = new Mock<IFxCurveEditorToolBarService>();

                toolBar.SetupGet(t => t.UndoChanges)
                       .Returns(toolBarUndo);

				toolBar.SetupGet(t => t.Update)
					   .Returns(toolBarUpdate);

                testObjects.SetupGet(o => o.ToolBarService)
                           .Returns(toolBar.Object);

                var transformer = new Mock<IFxCurveTransformer>();

                testObjects.SetupGet(o => o.FxCurveTransformer)
                           .Returns(transformer.Object);

                var fxCurveName = new Subject<string>();

                testObjects.SetupGet(o => o.FxCurveName)
                           .Returns(fxCurveName);

                var fxCurveNameService = new Mock<IFxCurveNameService>();

                fxCurveNameService.Setup(f => f.ObserveCurrencies(It.IsAny<FxCurveViewModel>()))
                                  .Returns(fxCurveName);

                testObjects.SetupGet(o => o.FxCurveNameService)
                           .Returns(fxCurveNameService.Object);

                var fxCurveChanged = new Subject<bool>();

                testObjects.SetupGet(o => o.FxCurveChanged)
                           .Returns(fxCurveChanged);

                var fxCurveChangedService = new Mock<IFxCurveChangedService>();

                fxCurveChangedService.Setup(f => f.ObserveChanged(It.IsAny<FxCurveViewModel>(), 
                                                                  It.IsAny<int?>(),
                                                                  It.IsAny<int?>(),
                                                                  It.IsAny<int>()))
                                     .Returns(fxCurveChanged);

                testObjects.SetupGet(o => o.FxCurveChangedService)
                           .Returns(fxCurveChangedService.Object);

                var validation = new Subject<Unit>();

                testObjects.SetupGet(o => o.Validation)
                           .Returns(validation);

                var validationService = new Mock<IValidationService<FxCurveViewModel>>();

                validationService.Setup(v => v.ObserveValidation(It.IsAny<FxCurveViewModel>()))
                                 .Returns(validation);

                testObjects.SetupGet(o => o.ValidationService)
                           .Returns(validationService.Object);

                var currencyPairRequired = new Subject<bool>();

                testObjects.SetupGet(o => o.CurrencyPairRequired)
                           .Returns(currencyPairRequired);

                var currencyPairRequiredService = new Mock<ICurrencyPairRequiredService>();

                currencyPairRequiredService.Setup(r => r.ObserveCurrencyPairRequired(It.IsAny<FxCurveViewModel>()))
                                           .Returns(currencyPairRequired);

                testObjects.SetupGet(o => o.CurrencyPairRequiredService)
                           .Returns(currencyPairRequiredService.Object);

				var itemCollectionFactory = new Mock<IFxCurveDefinitionItemCollectionFactory>();

				testObjects.SetupGet(o => o.ItemCollectionFactory)
						   .Returns(itemCollectionFactory.Object);

				itemCollectionFactory.Setup(f => f.CreateCollection(It.IsAny<IList<FxCurveDefinition>>(), It.IsAny<int>()))
									  .Returns(_itemCollectionFactoryResult);

				var popupNotificationService = new Mock<IPopupNotificationService>();

                testObjects.SetupGet(o => o.PopupNotificationService)
                           .Returns(popupNotificationService.Object);

                var errorMessageDialog = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialog.Object);

                var logger = new Mock<ILogger>();

                testObjects.SetupGet(o => o.Logger)
                           .Returns(logger.Object);

				var fxCurveUpdateResponse = new Subject<AdminApiActionCompleted>();

				testObjects.SetupGet(o => o.FxCurveUpdateServiceResponse)
						   .Returns(fxCurveUpdateResponse);

				var fxCurveUpdateService = new Mock<IFxCurveUpdateService>();

				fxCurveUpdateService.Setup(u => u.CreateFxCurveDefinition(It.IsAny<FxCurveViewModel>(),
																		  It.IsAny<CurrencyCode>(),
																		  It.IsAny<IScheduler>()))
									.Returns(fxCurveUpdateResponse);

				testObjects.SetupGet(o => o.FxCurveUpdateService)
						   .Returns(fxCurveUpdateService.Object);

				var controller = new FxCurveEditorController(currencyEditorController.Object,
															 curveControlService.Object,
                                                             toolBar.Object,
                                                             fxCurveUpdateService.Object,
                                                             TestMocks.GetSchedulerProvider().Object,
                                                             TestMocks.GetLoggerFactory(logger).Object)
                                 {
                                     FxCurveTransformer = transformer.Object,
                                     ItemCollectionFactory = itemCollectionFactory.Object,
                                     FxCurveNameService = fxCurveNameService.Object,
                                     FxCurveChangedService = fxCurveChangedService.Object,
                                     ValidationService = validationService.Object,
                                     CurrencyPairRequiredService = currencyPairRequiredService.Object,
                                     PopupNotificationService = popupNotificationService.Object,
                                     ErrorMessageDialog = errorMessageDialog.Object
                                 };

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        #region Initialize

        [Test]
        public void ShouldShowLoading_And_SubscribeComboItemsSources_On_InitializeCommand()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);
            Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);

            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.FxCurveDefinitions);

            Mock.Get(testObjects.CurveControlService)
                .VerifyGet(c => c.CurrencyCodes);

            Mock.Get(testObjects.CurveControlService)
                .Verify(c => c.SubscribeCurrencyCodes());
        }

        [Test]
        public void ShouldNotInitialize_When_Initialized()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            // ARRANGE
            testObjects.ViewModel.InitializeCommand.Execute();
            testObjects.ViewModel.IsBusy = false;

            // ACT
            testObjects.ViewModel.InitializeCommand.Execute();

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
        }

        #endregion

        #region Populate Combos

        [Test]
        public void ShouldPopulateFxCurveCombo_With_MarketDataFeed_On_FxCurveDefinitions()
        {
			var user = new UserBuilder().WithId(10).User();

			var fxCurve1 = new FxCurveDefinitionTestObjectBuilder().WithId(101)
                                                                   .WithIsMarketDataFeed(true)
                                                                   .Build();

            var fxCurve2 = new FxCurveDefinitionTestObjectBuilder().WithId(102)
                                                                   .Build();

			var items = new List<FxCurveDefinitionStatusItem>
						{
							new(fxCurve1)
						};

            var testObjects = new FxCurveEditorControllerTestObjectBuilder().WithCurrentUser(user)
																			.WithItemCollectionFactoryResult(items)
																			.Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.FxCurveDefinitions.OnNext([fxCurve1, fxCurve2]);

			// ASSERT
			Mock.Get(testObjects.ItemCollectionFactory)
				.Verify(f => f.CreateCollection(It.Is<List<FxCurveDefinition>>(c => c.Count == 1 && c[0].Id == 101), 10));

			var sourceCollection = testObjects.ViewModel.FxCurveDefinitions.SourceCollection.Cast<FxCurveDefinitionStatusItem>();

			Assert.That(sourceCollection.Count, Is.EqualTo(1));

			Assert.That(testObjects.ViewModel.FxCurveDefinitions.GroupDescriptions.Count, Is.EqualTo(1));

			var description = testObjects.ViewModel.FxCurveDefinitions.GroupDescriptions[0] as PropertyGroupDescription;

			Assert.That(description, Is.Not.Null);
			Assert.That(description.PropertyName, Is.EqualTo("IsDraftCurrentUser"));
		}

        [Test]
        public void ShouldPopulateCurrencyCodeCombos_ExcludeNonCcy_On_CurrencyCodes()
        {
            var ccy1 = new CurrencyCode(1, "EUR");
            var ccy2 = new CurrencyCode(2, "USD");
            var ccy3 = new CurrencyCode(2, "XXX");

            var currencies = new List<CurrencyCode> { ccy1, ccy2, ccy3 };

            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.CurrencyCodes.OnNext(currencies);

            // ASSERT
            Assert.That(testObjects.ViewModel.BaseCurrencyCodes.Count, Is.EqualTo(2));
            Assert.That(testObjects.ViewModel.QuoteCurrencyCodes.Count, Is.EqualTo(2));
        }

        [Test]
        public void ShouldHideLoading_On_CombosLoaded()
        {
			var user = new UserBuilder().WithId(10).User();

			var fxCurve1 = new FxCurveDefinitionTestObjectBuilder().WithId(1)
                                                                   .WithIsMarketDataFeed(true)
                                                                   .Build();

            var ccy1 = new CurrencyCode(1, "EUR");

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().WithCurrentUser(user)
																			.Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.FxCurveDefinitions.OnNext([fxCurve1]);
            testObjects.CurrencyCodes.OnNext([ccy1]);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);
            Assert.That(testObjects.ViewModel.BusyText, Is.Null);
		}

		#endregion

		#region Toggle Create New

        [Test]
        public void ShouldRestoreDefaults_And_EnableEditors_With_Validation_On_CreateNewCurve()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ASSERT
            Mock.Get(testObjects.FxCurveTransformer)
                .Verify(t => t.ClearFxCurve(testObjects.ViewModel.FxCurve));

            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ClearErrors(testObjects.ViewModel.FxCurve));

            Mock.Get(testObjects.FxCurveChangedService)
                .Verify(c => c.ObserveChanged(testObjects.ViewModel.FxCurve, null, null, 3));

            Mock.Get(testObjects.FxCurveNameService)
                .Verify(n => n.ObserveCurrencies(testObjects.ViewModel.FxCurve));

            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel.FxCurve));

            Mock.Get(testObjects.CurrencyPairRequiredService)
                .Verify(u => u.ObserveCurrencyPairRequired(testObjects.ViewModel.FxCurve));

            Assert.That(testObjects.ViewModel.FxCurve.PeriodCount, Is.EqualTo(3));
            Assert.That(testObjects.ViewModel.CurrencyPairRequired, Is.True);
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
            Assert.That(testObjects.ViewModel.CanAddCurrency, Is.True);
			Assert.That(testObjects.ViewModel.ShowCurrencyEditorCommand.CanExecute(), Is.True);
		}

        [Test]
        public void ShouldClearFxCurve_On_CreateNewCurve_With_SelectedFxCurve()
        {
            var fxCurve = new FxCurveDefinitionTestObjectBuilder().Build();

			var item = new FxCurveDefinitionStatusItem(fxCurve);

            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.FxCurveDefinitionItem = item;

            // ACT
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.FxCurveDefinitionItem, Is.Null);
        }

        [Test]
        public void ShouldDisableEditors_On_CreateNewCurveFalse()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.IsCreateNewCurve = true;

			// ACT
			testObjects.ViewModel.IsCreateNewCurve = false;

			// ASSERT
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.False);
			Assert.That(testObjects.ViewModel.CanAddCurrency, Is.False);
            Assert.That(testObjects.ViewModel.ShowCurrencyEditorCommand.CanExecute(), Is.False);
		}

        #endregion

        #region Select Fx Curve

        [Test]
        public void ShouldTransformCurve_And_EnabledEditors_With_Validation_On_FxCurveSelected()
        {
            var fxCurve = new FxCurveDefinitionTestObjectBuilder().WithBaseCurrencyId(1)
																  .WithQuoteCurrencyId(2)
																  .WithPeriodCount(10)
																  .Build();

			var item = new FxCurveDefinitionStatusItem(fxCurve);

            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

            // ACT
            testObjects.ViewModel.FxCurveDefinitionItem = item;

			// ASSERT
			Mock.Get(testObjects.FxCurveTransformer)
                .Verify(t => t.TransformFxCurve(testObjects.ViewModel, fxCurve));

            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ClearErrors(testObjects.ViewModel.FxCurve));

            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel.FxCurve));

			Mock.Get(testObjects.FxCurveChangedService)
                .Verify(f => f.ObserveChanged(testObjects.ViewModel.FxCurve, 1, 2, 10));

            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
		}

		[TestCase(true, false)]
		[TestCase(false, true)]
		public void ShouldSetIsDraftSelectedTrue_On_DraftCurveSelected(bool isDraftCurrentUser, bool isDraftOtherUser)
		{
			var fxCurve = new FxCurveDefinitionTestObjectBuilder().Build();

			var item = new FxCurveDefinitionStatusItem(fxCurve, isDraftCurrentUser, isDraftOtherUser);

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.FxCurveDefinitionItem = item;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsDraftSelected, Is.True);
		}

		[Test]
		public void ShouldSetIsDraftSelectedFalse_On_ActiveCurveSelected()
		{
			var fxCurve = new FxCurveDefinitionTestObjectBuilder().Build();

			var item = new FxCurveDefinitionStatusItem(fxCurve);

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.FxCurveDefinitionItem = item;

			// ASSERT
			Assert.That(testObjects.ViewModel.IsDraftSelected, Is.False);
		}

		#endregion

		#region Create New Curve - Observe Changes

		[Test]
        public void ShouldUpdateFxCurveName_On_FxCurveName_CreateNewCurve()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ACT
            testObjects.FxCurveName.OnNext("name");

            // ASSERT
            Assert.That(testObjects.ViewModel.FxCurve.Name, Is.EqualTo("name"));
		}

		[Test]
        public void ShouldEnableToolBarUpdate_On_CurrencyPairRequiredFalse_With_HasChanges_NoErrors()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsCreateNewCurve = true;
            testObjects.ViewModel.HasChanged = true;

            // ACT
            testObjects.CurrencyPairRequired.OnNext(false);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUndoChanges(true));
        }

        [Test]
        public void ShouldDisableToolBarUpdate_On_CurrencyPairRequiredTrue_With_HasChanges_NoErrors()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsCreateNewCurve = true;
            testObjects.ViewModel.HasChanged = true;

            // ACT
            testObjects.CurrencyPairRequired.OnNext(true);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdate(false));
        }

		#endregion

		#region SelectedCurve - Observe Changes

		[Test]
        public void ShouldSetHasChangedTrue_On_PeriodCountChanged_With_SelectedCurve()
        {
            var fxCurve = new FxCurveDefinitionTestObjectBuilder().Build();

			var item = new FxCurveDefinitionStatusItem(fxCurve);

            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.FxCurveDefinitionItem = item;

            // ACT
            testObjects.FxCurveChanged.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.HasChanged, Is.True);
            Assert.That(testObjects.ViewModel.IsInEdit, Is.True);

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUndoChanges(true));

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUpdate(true));
		}
        
        #endregion

        #region Validation

        [Test]
        public void ShouldEnableToolBarUndoChanges_On_ValidationErrors()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsCreateNewCurve = true;
            testObjects.ViewModel.FxCurve.Errors.Add("property", ["error"]);

            // ACT
            testObjects.Validation.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsInEdit, Is.True);

            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUndoChanges(true));
		}

        [Test]
        public void ShouldDisableToolBarUpdate_On_ValidationErrors_With_Changes()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsCreateNewCurve = true;

            testObjects.ViewModel.HasChanged = true;
			testObjects.ViewModel.FxCurve.Errors.Add("property", ["error"]);

            // ACT
            testObjects.Validation.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(false));
        }

        [Test]
        public void ShouldEnableToolBarUpdate_On_ValidationNoErrors_With_Changes_CreateNewCurve()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsCreateNewCurve = true;

            testObjects.ViewModel.HasChanged = true;
            testObjects.ViewModel.CurrencyPairRequired = false;
            testObjects.ViewModel.FxCurve.Errors.Clear();

            // ACT
            testObjects.Validation.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

        [Test]
        public void ShouldEnableToolBarUpdate_On_ValidationNoErrors_With_Changes_SelectedCurve()
        {
            var fxCurve = new FxCurveDefinitionTestObjectBuilder().Build();

			var item = new FxCurveDefinitionStatusItem(fxCurve);

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.FxCurveDefinitionItem = item;

            testObjects.ViewModel.HasChanged = true;
            testObjects.ViewModel.FxCurve.Errors.Clear();

            // ACT
            testObjects.Validation.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ToolBarService)
                .Verify(tb => tb.SetCanUpdate(true));
        }

		[Test]
        public void ShouldLogError_On_Validation_Exception()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ACT
            testObjects.Validation.OnError(new Exception());

            // ASSERT
            Mock.Get(testObjects.Logger)
                .Verify(l => l.Error(It.IsAny<string>()));
		}

		#endregion

		#region Currency Editor

		[Test]
		public void ShouldShowCurrencyEditor_On_ShowCurrencyCommand()
		{
			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			// ARRANGE
			testObjects.ViewModel.IsCreateNewCurve = true;

			// ACT
			testObjects.ViewModel.ShowCurrencyEditorCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.CurrencyEditor.IsVisible, Is.True);
		}

		[Test]
		public void ShouldDisableHeader_And_ToolBarCommands_On_ShowCurrencyCommand_With_Changes()
		{
			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.CurrencyPairRequired = false;
			testObjects.ViewModel.HasChanged = true;

			// ACT
			testObjects.ViewModel.ShowCurrencyEditorCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.IsInEdit, Is.True);

			Mock.Get(testObjects.ToolBarService)
				.Verify(t => t.SetCanUndoChanges(false));

			Mock.Get(testObjects.ToolBarService)
				.Verify(t => t.SetCanUpdate(false));
		}

		[Test]
		public void Should_EnableToolBarCommands_NotEnableHeader_On_CloseCurrencyEditor_With_Changes()
		{
			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.CurrencyPairRequired = false;
			testObjects.ViewModel.HasChanged = true;
			testObjects.ViewModel.ShowCurrencyEditorCommand.Execute();

			// ACT
			testObjects.ViewModel.CurrencyEditor.IsVisible = false;

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
				.Verify(t => t.SetCanUndoChanges(true));

			Mock.Get(testObjects.ToolBarService)
				.Verify(t => t.SetCanUpdate(true));

			Assert.That(testObjects.ViewModel.IsInEdit, Is.True);
		}

		[Test]
		public void Should_UpdateCurrencyCodeCombos_On_NewCurrencyCode()
		{
			var ccy1 = new CurrencyCode(1, "EUR");
			var ccy2 = new CurrencyCode(2, "USD");
			var ccy3 = new CurrencyCode(3, "XXX");

			var newCcy = new CurrencyCode(0, "AUD");

			var currencies = new List<CurrencyCode> { ccy1, ccy2, ccy3 };

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().WithCurrencyCodes(currencies)
																			.Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ViewModel.IsCreateNewCurve = true;

			// ACT
			testObjects.ViewModel.CurrencyEditor.CurrencyCode = newCcy;

			// ASSERT
			Assert.That(testObjects.ViewModel.BaseCurrencyCodes.Count, Is.EqualTo(3));
			Assert.That(testObjects.ViewModel.BaseCurrencyCodes[0].CurrencyCode, Is.SameAs(newCcy));
			Assert.That(testObjects.ViewModel.BaseCurrencyCodes[0].IsNew, Is.True);

			Assert.That(testObjects.ViewModel.QuoteCurrencyCodes.Count, Is.EqualTo(3));
		}

		[Test]
		public void Should_IncludeNewCurrencyCode_On_CurrencyCodes()
		{
			var ccy1 = new CurrencyCode(1, "EUR");
			var ccy2 = new CurrencyCode(2, "USD");
			var ccy3 = new CurrencyCode(2, "XXX");

			var newCcy = new CurrencyCode(0, "AUD");

			var currencies = new List<CurrencyCode> { ccy1, ccy2, ccy3 };

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.CurrencyEditor.CurrencyCode = newCcy;

			// ACT
			testObjects.CurrencyCodes.OnNext(currencies);

			// ASSERT
			Assert.That(testObjects.ViewModel.BaseCurrencyCodes.Count, Is.EqualTo(3));
			Assert.That(testObjects.ViewModel.BaseCurrencyCodes[0].CurrencyCode, Is.SameAs(newCcy));
			Assert.That(testObjects.ViewModel.BaseCurrencyCodes[0].IsNew, Is.True);

			Assert.That(testObjects.ViewModel.QuoteCurrencyCodes.Count, Is.EqualTo(3));
		}

		#endregion

		#region Undo Changes

		[Test]
        public void ShouldResetAll_On_UndoChanges_With_CreateNew()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.IsCreateNewCurve = true;

            testObjects.ViewModel.HasChanged = true;
            testObjects.ViewModel.CurrencyPairRequired = false;

            // ACT
            testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT - Generic
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ClearErrors(testObjects.ViewModel.FxCurve));

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUndoChanges(false));

            // ASSERT
            Mock.Get(testObjects.FxCurveTransformer)
                .Verify(t => t.ClearFxCurve(testObjects.ViewModel.FxCurve));

            Assert.That(testObjects.ViewModel.FxCurve.PeriodCount, Is.EqualTo(3));

            Mock.Get(testObjects.FxCurveChangedService)
                .Verify(c => c.ObserveChanged(testObjects.ViewModel.FxCurve, null, null, 3));

			Mock.Get(testObjects.FxCurveNameService)
                .Verify(n => n.ObserveCurrencies(testObjects.ViewModel.FxCurve));

			Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel.FxCurve));

			Assert.That(testObjects.ViewModel.HasChanged, Is.False);
            Assert.That(testObjects.ViewModel.CurrencyPairRequired, Is.True);
            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
		}

		[Test]
		public void ShouldRemoveNewCurrency_On_UndoChanges_With_CreateNew()
		{
			var ccy1 = new CurrencyCode(1, "EUR");
			var ccy2 = new CurrencyCode(2, "USD");
			var ccy3 = new CurrencyCode(3, "XXX");

			var newCcy = new CurrencyCode(0, "AUD");

			var currencies = new List<CurrencyCode> { ccy1, ccy2, ccy3 };

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().WithCurrencyCodes(currencies)
																			.Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.CurrencyEditor.Currency = newCcy.Code;
			testObjects.ViewModel.CurrencyEditor.CurrencyCode = newCcy;

			// ACT
			testObjects.ToolBarUndo.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.CurrencyEditor.Currency, Is.Null);
			Assert.That(testObjects.ViewModel.CurrencyEditor.CurrencyCode, Is.Null);

			Assert.That(testObjects.ViewModel.BaseCurrencyCodes.Count, Is.EqualTo(2));
			Assert.That(testObjects.ViewModel.BaseCurrencyCodes[0].CurrencyCode, Is.Not.SameAs(newCcy));

			Assert.That(testObjects.ViewModel.QuoteCurrencyCodes.Count, Is.EqualTo(2));
		}

		[Test]
        public void ShouldResetAll_On_UndoChanges_With_ModifyExisting_SelectedCurve()
        {
            var fxCurve = new FxCurveDefinitionTestObjectBuilder().WithBaseCurrencyId(1)
                                                                  .WithQuoteCurrencyId(2)
                                                                  .WithPeriodCount(10)
                                                                  .Build();

			var item = new FxCurveDefinitionStatusItem(fxCurve);

            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.ViewModel.FxCurveDefinitionItem = item;

            Mock.Get(testObjects.FxCurveTransformer).Invocations.Clear();
            Mock.Get(testObjects.ValidationService).Invocations.Clear();

            testObjects.ViewModel.HasChanged = true;

			// ACT
			testObjects.ToolBarUndo.OnNext(Unit.Default);

			// ASSERT
			Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ClearErrors(testObjects.ViewModel.FxCurve));

            Mock.Get(testObjects.ToolBarService)
                .Verify(t => t.SetCanUndoChanges(false));

			Mock.Get(testObjects.FxCurveTransformer)
                .Verify(t => t.TransformFxCurve(testObjects.ViewModel, fxCurve));

            Mock.Get(testObjects.FxCurveChangedService)
                .Verify(f => f.ObserveChanged(testObjects.ViewModel.FxCurve, 1, 2, 10));

            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel.FxCurve));

            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
            Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.True);
		}

        [Test] 
        public void ShouldNotEnableFields_On_UndoChanges_With_CurveNotSelected()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            testObjects.ViewModel.HasChanged = true;

			// ACT
			testObjects.ToolBarUndo.OnNext(Unit.Default);

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ClearErrors(testObjects.ViewModel.FxCurve));

            Assert.That(testObjects.ViewModel.HasChanged, Is.False);
			Assert.That(testObjects.ViewModel.CurveFieldsEnabled, Is.False);
        }

		#endregion

		#region ToolBar Update

		[Test]
		public void ShouldSetIsBusy_And_UpdateCurve_On_ToolBarUpdate_With_CreateNew()
		{
			var currency = new CurrencyCode(0, "AUD");

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.CurrencyEditor.CurrencyCode = currency;

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.True);

            Mock.Get(testObjects.FxCurveUpdateService)
				.Verify(u => u.CreateFxCurveDefinition(testObjects.ViewModel.FxCurve, currency, It.IsAny<IScheduler>()));
		}

		[Test]
		public void ShouldClearIsBusy_And_ShowPopup_On_ToolBarUpdate_Success()
		{
			var currency = new CurrencyCode(0, "AUD");

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.CurrencyEditor.CurrencyCode = currency;

			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ACT
            testObjects.FxCurveUpdateServiceResponse.OnNext(new AdminApiActionCompleted());

            // ASSERT
            Assert.That(testObjects.ViewModel.IsBusy, Is.False);

            Mock.Get(testObjects.PopupNotificationService)
				.Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
		}

		[Test]
		public void ShouldClearIsBusy_And_ShowDialog_On_ToolBarUpdate_Error()
		{
			var currency = new CurrencyCode(0, "AUD");

			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			testObjects.ViewModel.IsCreateNewCurve = true;
			testObjects.ViewModel.CurrencyEditor.CurrencyCode = currency;

			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ACT
			testObjects.FxCurveUpdateServiceResponse.OnError(new Exception());

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.False);

			Mock.Get(testObjects.ErrorMessageDialogService)
				.Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
		}

		#endregion

		#region Dispose

		[Test]
		public void ShouldDisposeCurrencyEditor_When_Dispose()
		{
			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.CurrencyEditor)
				.Verify(c => c.Dispose());
		}

		[Test]
        public void ShouldNotObserveValidation_On_CreateNewCurve_When_Disposed()
        {
            var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

            testObjects.ViewModel.InitializeCommand.Execute();

            // ARRANGE
            testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.IsCreateNewCurve = true;

            // ASSERT
            Mock.Get(testObjects.ValidationService)
                .Verify(v => v.ObserveValidation(testObjects.ViewModel.FxCurve), Times.Never);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
			var testObjects = new FxCurveEditorControllerTestObjectBuilder().Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.Controller.Dispose();

			// ACT
			testObjects.Controller.Dispose();

			// ASSERT
			Mock.Get(testObjects.CurrencyEditor)
				.Verify(c => c.Dispose(), Times.Once);
		}

		#endregion
	}
}
