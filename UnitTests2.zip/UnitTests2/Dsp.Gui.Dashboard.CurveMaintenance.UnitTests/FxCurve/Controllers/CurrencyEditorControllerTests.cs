﻿using System.Reactive;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.FxCurve.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.Services.Validation;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FxCurve.Controllers
{
	internal interface ICurrencyEditorControllerTestObjects
	{
		IValidationService<CurrencyEditorViewModel> ValidationService { get; }
		ISubject<Unit> Validation { get; }
		CurrencyEditorViewModel ViewModel { get; }
		CurrencyEditorController Controller { get; }
	}

	[TestFixture]
	public class CurrencyEditorControllerTests
	{
		private class CurrencyEditorControllerTestObjectBuilder
		{
			private bool _isVisible;
			private bool _hasChanged;
			private CurrencyCode _currencyCode;

			public CurrencyEditorControllerTestObjectBuilder WithIsVisible(bool value)
			{
				_isVisible = value;
				return this;
			}

			public CurrencyEditorControllerTestObjectBuilder WithHasChanged(bool value)
			{
				_hasChanged = value;
				return this;
			}

			public CurrencyEditorControllerTestObjectBuilder WithCurrencyCode(CurrencyCode value)
			{
				_currencyCode = value;
				return this;
			}

			public ICurrencyEditorControllerTestObjects Build()
			{
				var testObjects = new Mock<ICurrencyEditorControllerTestObjects>();

				var validation = new Subject<Unit>();

				testObjects.SetupGet(o => o.Validation)
						   .Returns(validation);

				var validationService = new Mock<IValidationService<CurrencyEditorViewModel>>();

				validationService.Setup(v => v.ObserveValidation(It.IsAny<CurrencyEditorViewModel>()))
								 .Returns(validation);

				testObjects.SetupGet(o => o.ValidationService)
						   .Returns(validationService.Object);

				var controller = new CurrencyEditorController(validationService.Object);

				controller.ViewModel.IsVisible = _isVisible;
				controller.ViewModel.CurrencyCode = _currencyCode;
				controller.ViewModel.HasChanged = _hasChanged;
				
				testObjects.SetupGet(o => o.Controller)
						   .Returns(controller);

				testObjects.SetupGet(o => o.ViewModel)
						   .Returns(controller.ViewModel);

				return testObjects.Object;
			}
		}

		#region Validation

		[Test]
		public void ShouldObserveValidation_On_IsVisible()
		{
			var testObjects = new CurrencyEditorControllerTestObjectBuilder().Build();

			// ACT
			testObjects.ViewModel.IsVisible = true;

			// ASSERT
			Mock.Get(testObjects.ValidationService)
				.Verify(v => v.ObserveValidation(testObjects.ViewModel));
		}

		[Test]
		public void ShouldDisableUpdate_OnValidationErrors_With_Changes()
		{
			// todo : add changes
			var testObjects = new CurrencyEditorControllerTestObjectBuilder().WithIsVisible(true)
																			 .WithHasChanged(true)
																			 .Build();

			// ARRANGE
			testObjects.ViewModel.Errors.Add("currency", ["error"]);

			// ACT
			testObjects.Validation.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.UpdateCommand.CanExecute(), Is.False);
		}

		[Test]
		public void ShouldEnableUpdate_OnValidationNoErrors_With_Changes()
		{
			// todo : add changes
			var testObjects = new CurrencyEditorControllerTestObjectBuilder().WithIsVisible(true)
																			 .WithHasChanged(true)
																			 .Build();

			// ACT
			testObjects.Validation.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.UpdateCommand.CanExecute(), Is.True);
		}

		#endregion

		#region Update Command

		[Test]
		public void ShouldUpdateCurrencyCode_And_HideEditor_On_UpdateCommand()
		{
			var testObjects = new CurrencyEditorControllerTestObjectBuilder().WithIsVisible(true)
																			 .Build();

			// ARRANGE
			testObjects.ViewModel.Currency = "JPY";

			// ACT
			testObjects.ViewModel.UpdateCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.CurrencyCode, Is.Not.Null);
			Assert.That(testObjects.ViewModel.CurrencyCode.Code, Is.EqualTo("JPY"));
			Assert.That(testObjects.ViewModel.IsVisible, Is.False);
		}

		#endregion

		#region Cancel Command

		[Test]
		public void ShouldResetCurrency_And_HideEditor_On_CancelCommand_With_CurrencyCode()
		{
			var usd = new CurrencyCode(0, "USD");

			var testObjects = new CurrencyEditorControllerTestObjectBuilder().WithIsVisible(true)
																			 .WithCurrencyCode(usd)
																			 .Build();

			testObjects.ViewModel.Currency = "JPY";

			// ACT
			testObjects.ViewModel.CancelCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.CurrencyCode, Is.SameAs(usd));
			Assert.That(testObjects.ViewModel.Currency, Is.EqualTo("USD"));
		}

		[Test]
		public void ShouldClearCurrency_And_HideEditor_On_CancelCommand_With_NullCurrencyCode()
		{
			var testObjects = new CurrencyEditorControllerTestObjectBuilder().WithIsVisible(true)
																			 .WithCurrencyCode(null)
																			 .Build();

			testObjects.ViewModel.Currency = "JPY";

			// ACT
			testObjects.ViewModel.CancelCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.Currency, Is.Null);
		}

		#endregion

		#region Dispose

		[Test]
		public void ShouldNotObserveValidation_When_Disposed()
		{
			var testObjects = new CurrencyEditorControllerTestObjectBuilder().Build();

			// ARRANGE
			testObjects.Controller.Dispose();

			// ACT
			testObjects.ViewModel.IsVisible = true;

			// ASSERT
			Mock.Get(testObjects.ValidationService)
				.Verify(v => v.ObserveValidation(testObjects.ViewModel), Times.Never);
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var testObjects = new CurrencyEditorControllerTestObjectBuilder().Build();

			// ARRANGE
			testObjects.Controller.Dispose();

			// ACT
			testObjects.Controller.Dispose();
			testObjects.ViewModel.IsVisible = true;

			// ASSERT
			Mock.Get(testObjects.ValidationService)
				.Verify(v => v.ObserveValidation(testObjects.ViewModel), Times.Never);
		}

		#endregion
	}
}
