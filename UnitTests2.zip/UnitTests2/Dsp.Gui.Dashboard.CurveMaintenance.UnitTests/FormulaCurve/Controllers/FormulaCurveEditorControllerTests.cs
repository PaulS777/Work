﻿using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.CurveMaintenance.FormulaCurve.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.FormulaCurve.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.FormulaCurve.Controllers
{
	internal interface IFormulaCurveEditorControllerTestObjects
	{
		IFormulaCurveEditorToolBarService ToolBar { get; }
		FormulaCurveEditorViewModel ViewModel { get; }
		FormulaCurveEditorController Controller { get; }
	}

	[TestFixture]
	public class FormulaCurveEditorControllerTests
	{
		private class FormulaCurveEditorControllerTestBuilder
		{
			public IFormulaCurveEditorControllerTestObjects Build()
			{
				var testObjects = new Mock<IFormulaCurveEditorControllerTestObjects>();

				var toolBar = new Mock<IFormulaCurveEditorToolBarService>();

				testObjects.SetupGet(o => o.ToolBar)
						   .Returns(toolBar.Object);

				var controller = new FormulaCurveEditorController(toolBar.Object, TestMocks.GetLoggerFactory().Object);

				testObjects.SetupGet(o => o.Controller)
						   .Returns(controller);

				testObjects.SetupGet(o => o.ViewModel)
						   .Returns(controller.ViewModel);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldSetViewModel()
		{
			var testObjects = new FormulaCurveEditorControllerTestBuilder().Build();

			// ASSERT
			Assert.That(testObjects.ViewModel, Is.Not.Null);
		}
	}
}
