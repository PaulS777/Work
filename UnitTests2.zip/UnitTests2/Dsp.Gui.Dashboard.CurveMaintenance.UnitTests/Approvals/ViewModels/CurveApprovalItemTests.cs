﻿using System;
using NUnit.Framework;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.ViewModels;
using Moq;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Approvals.ViewModels
{
	[TestFixture]
	public class CurveApprovalItemTests
	{
		[Test]
		public void ShouldDisposeController_When_Dispose()
		{
			var controller = new Mock<IDisposable>();

			var item = new CurveApprovalItem(controller.Object);

			// ACT
			item.Dispose();

			// ASSERT
			controller.Verify(c => c.Dispose());
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var controller = new Mock<IDisposable>();

			var item = new CurveApprovalItem(controller.Object);

			// ARRANGE
			item.Dispose();

			// ACT
			item.Dispose();

			// ASSERT
			controller.Verify(c => c.Dispose(), Times.Once);
		}
	}
}
