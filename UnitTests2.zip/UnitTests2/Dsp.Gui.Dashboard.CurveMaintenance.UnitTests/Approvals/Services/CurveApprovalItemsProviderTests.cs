﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Enum;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.ViewModels;
using Dsp.Gui.Dashboard.CurveMaintenance.ManualCurve.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Approvals.Services
{
	internal interface ICurveApprovalItemsProviderTestObjects
	{
		ISubject<List<User>> Users { get; }
		ICurveControlService CurveControlService { get; }
		IManualPriceCurveDefinitionProvider ManualPriceCurveDefinitionProvider { get; }
		ISubject<IEnumerable<PriceCurveDefinition>> PriceCurveDefinitions { get; }
		ISubject<IList<FxCurveDefinition>> FxCurveDefinitions { get; }
		ICurveApprovalItemsDataSource DataSource { get; }
		CurveApprovalItemsProvider CurveApprovalItemsProvider { get; }
	}

	[TestFixture]
	public class CurveApprovalItemsProviderTests
	{
		private class CurveApprovalItemsProviderTestObjectBuilder
		{
			private List<User> _users;
			private IEnumerable<PriceCurveDefinition> _priceCurveDefinitions;
			private IList<FxCurveDefinition> _fxCurveDefinitions;
			private IEnumerable<CurveApprovalItem> _curveApprovalItems;

			public CurveApprovalItemsProviderTestObjectBuilder WithUsers(List<User> values)
			{
				_users = values;
				return this;
			}

			public CurveApprovalItemsProviderTestObjectBuilder WithPriceCurveDefinitions(IEnumerable<PriceCurveDefinition> values)
			{
				_priceCurveDefinitions = values;
				return this;
			}

			public CurveApprovalItemsProviderTestObjectBuilder WithFxCurveDefinitions(IList<FxCurveDefinition> values)
			{
				_fxCurveDefinitions = values;
				return this;
			}

			public CurveApprovalItemsProviderTestObjectBuilder WithCurveApprovalItems(IEnumerable<CurveApprovalItem> values)
			{
				_curveApprovalItems = values;
				return this;
			}

			public ICurveApprovalItemsProviderTestObjects Build()
			{
				var testObjects = new Mock<ICurveApprovalItemsProviderTestObjects>();

				var dataSource = new Mock<ICurveApprovalItemsDataSource>();

				dataSource.Setup(d => d.Items())
						  .Returns(_curveApprovalItems);

				testObjects.SetupGet(o => o.DataSource)
						   .Returns(dataSource.Object);

				var users = new BehaviorSubject<List<User>>(_users);

				testObjects.SetupGet(o => o.Users)
						   .Returns(users);

				var fxCurveDefinitions = new BehaviorSubject<IList<FxCurveDefinition>>(_fxCurveDefinitions);

				testObjects.SetupGet(o => o.FxCurveDefinitions)
						   .Returns(fxCurveDefinitions);

				var curveControlService = new Mock<ICurveControlService>();

				curveControlService.SetupGet(c => c.Users)
								   .Returns(users);

				curveControlService.Setup(c => c.GetUsersSnapshot())
								   .Returns(_users);

				curveControlService.SetupGet(c => c.FxCurveDefinitions)
								   .Returns(fxCurveDefinitions);

				testObjects.SetupGet(o => o.CurveControlService)
						   .Returns(curveControlService.Object);

				var priceCurveDefinitions = new BehaviorSubject<IEnumerable<PriceCurveDefinition>>(_priceCurveDefinitions);

				testObjects.SetupGet(o => o.PriceCurveDefinitions)
						   .Returns(priceCurveDefinitions);

				var manualPriceCurveDefinitionProvider = new Mock<IManualPriceCurveDefinitionProvider>();

				manualPriceCurveDefinitionProvider.Setup(p => p.PriceCurveDefinitions(It.IsAny<IScheduler>()))
												  .Returns(priceCurveDefinitions);

				testObjects.SetupGet(o => o.ManualPriceCurveDefinitionProvider)
						   .Returns(manualPriceCurveDefinitionProvider.Object);

				var factory = new Mock<IServiceFactory<ICurveApprovalItemController>>();

				factory.Setup(f => f.Create())
					   .Returns(() =>
								{
									var controller = new Mock<ICurveApprovalItemController>();

									var item = new CurveApprovalItem(controller.Object);

									controller.SetupGet(c => c.ViewModel).Returns(item);

									return controller.Object;
								});


				var curveApprovalItemsProvider = new CurveApprovalItemsProvider(curveControlService.Object,
																				manualPriceCurveDefinitionProvider.Object,
																				factory.Object,
																				TestMocks.GetSchedulerProvider().Object);

				testObjects.SetupGet(o => o.CurveApprovalItemsProvider)
						   .Returns(curveApprovalItemsProvider);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldSubscribeCurveDefinitions_On_Users()
		{
			var users = new List<User> { new UserBuilder().User() };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().Build();

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(_ => { }))
			{
				// ACT
				testObjects.Users.OnNext(users);

				// ASSERT
				Mock.Get(testObjects.ManualPriceCurveDefinitionProvider)
					.Verify(p => p.PriceCurveDefinitions(It.IsAny<IScheduler>()));

				Mock.Get(testObjects.CurveControlService)
					.VerifyGet(c => c.FxCurveDefinitions);
			}
		}

		[Test]
		public void ShouldNotPublishItems_On_ManualCurves_MissingFxCurves()
		{
			var users = new List<User> { new UserBuilder().User() };

			var priceCurves = new[] { new PriceCurveDefinitionTestObjectBuilder().Build() };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().WithUsers(users)
																			   .Build();

			List<CurveApprovalItem> result = null;

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(values => result = values))
			{
				// ACT
				testObjects.PriceCurveDefinitions.OnNext(priceCurves);

				// ASSERT
				Assert.That(result, Is.Null);
			}
		}

		[Test]
		public void ShouldNotPublishItems_On_ManualCurves_MissingManualCurves()
		{
			var users = new List<User> { new UserBuilder().User() };

			var fxCurve = new[]
						  {
							  new FxCurveDefinitionTestObjectBuilder().WithIsMarketDataFeed(true).Build()
						  };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().WithUsers(users)
																			   .Build();

			List<CurveApprovalItem> result = null;

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(values => result = values))
			{
				// ACT
				testObjects.FxCurveDefinitions.OnNext(fxCurve);

				// ASSERT
				Assert.That(result, Is.Null);
			}
		}

		[TestCase(EntityStatus.PendingNew, CurveApprovalActionType.Create)]
		[TestCase(EntityStatus.PendingUpdate, CurveApprovalActionType.Update)]
		[TestCase(EntityStatus.PendingDelete, CurveApprovalActionType.Delete)]
		public void ShouldPublishDraftItems_Mapped_ActionType_On_PriceCurves_IgnoreNonDrafts(EntityStatus status, CurveApprovalActionType expectedActionType)
		{
			var user1 = new UserBuilder().WithId(10).WithName("user-1").User();

			var users = new List<User> { user1 };

			FxCurveDefinition[] fxCurves = [];

			var draftCurve = new PriceCurveDefinitionTestObjectBuilder().WithName("price-curve")
																		.WithId(101)
																		.WithStatus(status)
																		.WithActionedByUserId(10)
																		.Build();

			var deletedCurve = new PriceCurveDefinitionTestObjectBuilder().WithStatus(EntityStatus.Deleted)
																		  .Build();

			var activeCurve = new PriceCurveDefinitionTestObjectBuilder().WithStatus(EntityStatus.Active)
																		 .Build();

			var priceCurves = new[] { activeCurve, deletedCurve, draftCurve };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().WithUsers(users)
																			   .WithFxCurveDefinitions(fxCurves)
																			   .Build();

			List<CurveApprovalItem> result = null;

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(values => result = values))
			{
				// ACT
				testObjects.PriceCurveDefinitions.OnNext(priceCurves);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(1));

				Assert.That(result[0].ItemType, Is.EqualTo(CurveApprovalItemType.Manual));
				Assert.That(result[0].CurveName, Is.EqualTo("price-curve"));
				Assert.That(result[0].Id, Is.EqualTo(101));
				Assert.That(result[0].ActionedByUserName, Is.EqualTo("user-1"));
				Assert.That(result[0].ActionType, Is.EqualTo(expectedActionType));
				Assert.That(result[0].Status, Is.EqualTo(CurveApprovalStatus.ApprovalRequired));
			}
		}

		[TestCase(CurveApprovalStatus.ApprovalPending, CurveApprovalStatus.Approved)]
		[TestCase(CurveApprovalStatus.DeletionPending, CurveApprovalStatus.Deleted)]
		[TestCase(CurveApprovalStatus.RejectionPending, CurveApprovalStatus.Rejected)]
		public void ShouldUpdatePendingDraftItem_On_UserApproval_With_CurveDeletionUpdate(CurveApprovalStatus pendingStatus, CurveApprovalStatus expectedStatus)
		{
			var user1 = new UserBuilder().WithId(10).WithName("user-1").User();
			var users = new List<User> { user1 };

			var item = new CurveApprovalItem(Mock.Of<IDisposable>())
			{
				Id = 101,
				CurveName = "price-curve",
				ActionedByUserName = "user",
				ItemType = CurveApprovalItemType.Manual,
				Status = pendingStatus,
				ActionType = CurveApprovalActionType.Create,
				HasChanged = true,
				IsReadOnly = false
			};

			var items = new[] { item };

			var deletedCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																		  .WithStatus(EntityStatus.Deleted)
																		  .WithActionedByUserId(10)
																		  .Build();

			var update = new[] { deletedCurve };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().WithUsers(users)
																			   .WithPriceCurveDefinitions([])
																			   .WithFxCurveDefinitions([])
																			   .WithCurveApprovalItems(items)
																			   .Build();

			List<CurveApprovalItem> result = null;

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(values => result = values))
			{
				// ACT
				testObjects.PriceCurveDefinitions.OnNext(update);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(1));

				Assert.That(result[0], Is.Not.SameAs(item));
				Assert.That(result[0].Status, Is.EqualTo(expectedStatus));
				Assert.That(result[0].ActionType, Is.EqualTo(CurveApprovalActionType.None));
				Assert.That(result[0].IsReadOnly, Is.True);
				Assert.That(result[0].HasChanged, Is.False);
				Assert.That(result[0].CurveName, Is.EqualTo("price-curve"));
				Assert.That(result[0].ActionedByUserName, Is.EqualTo("user"));
			}
		}

		[TestCase(CurveApprovalActionType.Create)]
		[TestCase(CurveApprovalActionType.Update)]
		[TestCase(CurveApprovalActionType.Delete)]
		public void ShouldUpdateDraftItemApprovalRequired_On_OtherUserApproval_With_CurveDeleted(CurveApprovalActionType actionType)
		{
			var user1 = new UserBuilder().WithId(10).WithName("user-1").User();
			var users = new List<User> { user1 };

			var item = new CurveApprovalItem(Mock.Of<IDisposable>())
			{
				Id = 101,
				Status = CurveApprovalStatus.ApprovalRequired,
				ActionType = actionType,
				HasChanged = true
			};

			var items = new[] { item };

			var deletedCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																		  .WithStatus(EntityStatus.Deleted)
																		  .WithActionedByUserId(10)
																		  .Build();

			var update = new[] { deletedCurve };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().WithUsers(users)
																			   .WithPriceCurveDefinitions([])
																			   .WithFxCurveDefinitions([])
																			   .WithCurveApprovalItems(items)
																			   .Build();

			List<CurveApprovalItem> result = null;

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(values => result = values))
			{
				// ACT
				testObjects.PriceCurveDefinitions.OnNext(update);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(1));

				Assert.That(result[0].Id, Is.EqualTo(101));
				Assert.That(result[0].Status, Is.EqualTo(CurveApprovalStatus.Completed));
				Assert.That(result[0].ActionType, Is.EqualTo(CurveApprovalActionType.None));
				Assert.That(result[0].IsReadOnly, Is.True);
				Assert.That(result[0].HasChanged, Is.False);
			}
		}

		[TestCase(CurveApprovalStatus.ApprovalRequired, EntityStatus.PendingNew)]
		[TestCase(CurveApprovalStatus.ApprovalRequired, EntityStatus.PendingUpdate)]
		[TestCase(CurveApprovalStatus.ApprovalRequired, EntityStatus.PendingDelete)]
		public void ShouldRetainExistingDraftItem_On_CurveUpdateNotDeleted(CurveApprovalStatus approvalStatus, EntityStatus entityStatus)
		{
			var user1 = new UserBuilder().WithId(10).WithName("user-1").User();
			var users = new List<User> { user1 };

			var item = new CurveApprovalItem(Mock.Of<IDisposable>())
					   {
						   Id = 101,
						   Status = approvalStatus,
						   ActionType = CurveApprovalActionType.Create
					   };

			var items = new[] { item };

			var curve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																   .WithStatus(entityStatus)
																   .Build();

			var update = new[] { curve };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().WithUsers(users)
																			   .WithPriceCurveDefinitions([])
																			   .WithFxCurveDefinitions([])
																			   .WithCurveApprovalItems(items)
																			   .Build();

			List<CurveApprovalItem> result = null;

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(values => result = values))
			{
				// ACT
				testObjects.PriceCurveDefinitions.OnNext(update);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(1));

				Assert.That(result[0].Id, Is.EqualTo(101));
				Assert.That(result[0].Status, Is.EqualTo(approvalStatus));
			}
		}

		[TestCase(CurveApprovalStatus.Approved)]
		[TestCase(CurveApprovalStatus.Rejected)]
		[TestCase(CurveApprovalStatus.Deleted)]
		[TestCase(CurveApprovalStatus.Cancelled)]
		public void ShouldRetainExistingCompletedItem_On_CurveUpdateDeleted(CurveApprovalStatus approvalStatus)
		{
			var user1 = new UserBuilder().WithId(10).WithName("user-1").User();
			var users = new List<User> { user1 };

			var item = new CurveApprovalItem(Mock.Of<IDisposable>())
					   {
						   Id = 101,
						   Status = approvalStatus,
						   ActionType = CurveApprovalActionType.Create
					   };

			var items = new[] { item };

			var deletedCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																		  .WithStatus(EntityStatus.Deleted)
																		  .Build();

			var update = new[] { deletedCurve };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().WithUsers(users)
																			   .WithPriceCurveDefinitions([])
																			   .WithFxCurveDefinitions([])
																			   .WithCurveApprovalItems(items)
																			   .Build();

			List<CurveApprovalItem> result = null;

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(values => result = values))
			{
				// ACT
				testObjects.PriceCurveDefinitions.OnNext(update);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(1));

				Assert.That(result[0].Id, Is.EqualTo(101));
				Assert.That(result[0].Status, Is.EqualTo(approvalStatus));
			}
		}

		[Test]
		public void ShouldPublishManualItemsSortedByCompletedAndName_On_ApprovalCurveUpdates_With_NewDraft()
		{
			var user1 = new UserBuilder().WithId(10).WithName("user-1").User();
			var users = new List<User> { user1 };

			var item1 = new CurveApprovalItem(Mock.Of<IDisposable>())
						{
							Id = 101,
							CurveName = "C-Curve",
							Status = CurveApprovalStatus.ApprovalPending,
							ActionType = CurveApprovalActionType.Create
						};

			var item2 = new CurveApprovalItem(Mock.Of<IDisposable>())
						{
							Id = 102,
							CurveName = "D-Curve",
							Status = CurveApprovalStatus.ApprovalRequired,
							ActionType = CurveApprovalActionType.Create
						};

			var item3 = new CurveApprovalItem(Mock.Of<IDisposable>())
						{
							Id = 103,
							CurveName = "A-Curve",
							Status = CurveApprovalStatus.ApprovalPending,
							ActionType = CurveApprovalActionType.Update
						};

			var items = new[] { item1, item2, item3, };

			var curve1Approved = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																			.WithStatus(EntityStatus.Deleted)
																			.Build();

			var curve2Required = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																			.WithStatus(EntityStatus.PendingNew)
																			.Build();

			var curve3Approved = new PriceCurveDefinitionTestObjectBuilder().WithId(103)
																			.WithStatus(EntityStatus.Deleted)
																			.Build();

			var curve4NewDraft = new PriceCurveDefinitionTestObjectBuilder().WithId(104)
																			.WithName("B-Curve")
																			.WithStatus(EntityStatus.PendingUpdate)
																			.Build();

			var update = new[] { curve1Approved, curve2Required, curve3Approved, curve4NewDraft };

			var testObjects = new CurveApprovalItemsProviderTestObjectBuilder().WithUsers(users)
																			   .WithPriceCurveDefinitions([])
																			   .WithFxCurveDefinitions([])
																			   .WithCurveApprovalItems(items)
																			   .Build();

			List<CurveApprovalItem> result = null;

			using (testObjects.CurveApprovalItemsProvider.CurveApprovalItems(testObjects.DataSource).Subscribe(values => result = values))
			{
				// ACT
				testObjects.PriceCurveDefinitions.OnNext(update);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(4));

				Assert.That(result[0].CurveName, Is.EqualTo("B-Curve"));
				Assert.That(result[0].Status, Is.EqualTo(CurveApprovalStatus.ApprovalRequired));

				Assert.That(result[1].CurveName, Is.EqualTo("D-Curve"));
				Assert.That(result[1].Status, Is.EqualTo(CurveApprovalStatus.ApprovalRequired));

				Assert.That(result[2].CurveName, Is.EqualTo("A-Curve"));
				Assert.That(result[2].Status, Is.EqualTo(CurveApprovalStatus.Approved));

				Assert.That(result[3].CurveName, Is.EqualTo("C-Curve"));
				Assert.That(result[3].Status, Is.EqualTo(CurveApprovalStatus.Approved));
			}
		}
	}
}
