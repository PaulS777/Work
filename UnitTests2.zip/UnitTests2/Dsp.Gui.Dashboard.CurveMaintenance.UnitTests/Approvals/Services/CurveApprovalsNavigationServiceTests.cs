﻿using DevExpress.Mvvm;
using Dsp.Gui.Dashboard.Common.Services.Navigation;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.CurveMaintenance.ApprovalDrafts.Views;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Views;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Approvals.Services
{
	internal interface ICurveApprovalsNavigationServiceTestObjects
	{
		INavigationMenuEnabledService NavigationMenuEnabledService { get; }
		ICurveApprovalsToolBarService ToolBarService { get; }
		NavigationViewModelBase ViewModel { get; }
		INavigationServiceExtension NavigationService { get; }
		CurveApprovalsNavigationService CurveApprovalsNavigationService { get; }
	}

	[TestFixture]
	public class CurveApprovalsNavigationServiceTests
	{
		private class CurveApprovalsNavigationServiceTestObjectBuilder
		{
			public ICurveApprovalsNavigationServiceTestObjects Build()
			{
				var testObjects = new Mock<ICurveApprovalsNavigationServiceTestObjects>();

				var viewModel = new NavigationViewModel();

				testObjects.SetupGet(o => o.ViewModel)
						   .Returns(viewModel);

				var navigationMenuEnabledService = new Mock<INavigationMenuEnabledService>();

				testObjects.SetupGet(o => o.NavigationMenuEnabledService)
						   .Returns(navigationMenuEnabledService.Object);

				var toolBarService = new Mock<ICurveApprovalsToolBarService>();

				testObjects.SetupGet(o => o.ToolBarService)
						   .Returns(toolBarService.Object);

				var navigationService = new Mock<INavigationServiceExtension>();

				testObjects.SetupGet(o => o.NavigationService)
						   .Returns(navigationService.Object);

				var navigationViewModel = new Mock<INavigationViewModel>();

				navigationViewModel.Setup(vm => vm.GetNavigationService())
								   .Returns(navigationService.Object);

				var service = new CurveApprovalsNavigationService(navigationMenuEnabledService.Object,
																  toolBarService.Object,
																  navigationViewModel.Object);

				testObjects.SetupGet(o => o.CurveApprovalsNavigationService)
						   .Returns(service);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldEnableToolBar_And_NavigateCurveApprovals_When_NavigateToApprovals()
		{
			var testObjects = new CurveApprovalsNavigationServiceTestObjectBuilder().Build();

			// ACT
			testObjects.CurveApprovalsNavigationService.NavigateToApprovals();

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetToolBarEnabled(true));

			Mock.Get(testObjects.NavigationService)
				.Verify(n => n.Navigate(nameof(CurveApprovalsPage)));
		}

		[Test]
		public void ShouldDisableToolBar_And_MenuNavigation_When_NavigateToManualCurveDraft()
		{
			var testObjects = new CurveApprovalsNavigationServiceTestObjectBuilder().Build();

			// ACT
			testObjects.CurveApprovalsNavigationService.NavigateToManualCurveDraft(101, "user");

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetToolBarEnabled(false));

			Mock.Get(testObjects.NavigationMenuEnabledService)
				.Verify(n => n.SetNavigationEnabled(false));
		}

		[Test]
		public void ShouldNavigate_To_ManualCurveDraft_With_Params_When_NavigateToManualCurveDraft()
		{
			var testObjects = new CurveApprovalsNavigationServiceTestObjectBuilder().Build();

			// ACT
			testObjects.CurveApprovalsNavigationService.NavigateToManualCurveDraft(101, "user");

			// ASSERT
			Mock.Get(testObjects.NavigationService)
				.Verify(n => n.Navigate(nameof(ManualCurveDraftPage)));

			Assert.That(testObjects.CurveApprovalsNavigationService.ManualCurveDraftParams.Id, Is.EqualTo(101));
			Assert.That(testObjects.CurveApprovalsNavigationService.ManualCurveDraftParams.UserName, Is.EqualTo("user"));
		}

		[Test]
		public void ShouldEnableToolBar_And_MenuNavigation_When_NavigateBack()
		{
			var testObjects = new CurveApprovalsNavigationServiceTestObjectBuilder().Build();

			// ACT
			testObjects.CurveApprovalsNavigationService.NavigateBack();

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetToolBarEnabled(true));

			Mock.Get(testObjects.NavigationMenuEnabledService)
				.Verify(n => n.SetNavigationEnabled(true));
		}

		[Test]
		public void ShouldGoBack_When_NavigateBack()
		{
			var testObjects = new CurveApprovalsNavigationServiceTestObjectBuilder().Build();

			// ACT
			testObjects.CurveApprovalsNavigationService.NavigateBack();

			// ASSERT
			Mock.Get(testObjects.NavigationService)
				.Verify(n => n.GoBack());
		}
	}
}
