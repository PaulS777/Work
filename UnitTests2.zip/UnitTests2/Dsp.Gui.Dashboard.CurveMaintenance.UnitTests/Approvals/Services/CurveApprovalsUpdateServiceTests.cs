﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.AdminActions;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Enum;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.ViewModels;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Approvals.Services
{
	public interface ICurveApprovalsUpdateServiceTestObjects
	{
		ICurveWorkflowActionService ActionService { get; }
		IObservable<AdminApiActionCompleted> ActionServiceResponse { get; }
		IScheduler Scheduler { get; }
		CurveApprovalsUpdateService CurveApprovalsUpdateService { get; }
	}

	[TestFixture]
	public class CurveApprovalsUpdateServiceTests
	{
		private class CurveApprovalsUpdateServiceTestObjectBuilder
		{
			public ICurveApprovalsUpdateServiceTestObjects Build()
			{
				var testObjects = new Mock<ICurveApprovalsUpdateServiceTestObjects>();

				var scheduler = new Mock<IScheduler>();

				testObjects.SetupGet(o => o.Scheduler)
						   .Returns(scheduler.Object);

				var actionServiceResponse = new Subject<AdminApiActionCompleted>();

				testObjects.SetupGet(o => o.ActionServiceResponse)
						   .Returns(actionServiceResponse);

				var actionService = new Mock<ICurveWorkflowActionService>();

				actionService.Setup(a => a.Update(It.IsAny<IList<CurveWorkflowAction>>(),
												  It.IsAny<IScheduler>()))
							 .Returns(actionServiceResponse);

				testObjects.SetupGet(o => o.ActionService)
						   .Returns(actionService.Object);

				var updateService = new CurveApprovalsUpdateService(actionService.Object);

				testObjects.SetupGet(o => o.CurveApprovalsUpdateService)
						   .Returns(updateService);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldInvokeActionService_When_Update()
		{
			var item1 = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 1, Status = CurveApprovalStatus.ApprovalPending };
			var item2 = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 2, Status = CurveApprovalStatus.RejectionPending };

			var items = new[] { item1, item2 };

			var testObjects = new CurveApprovalsUpdateServiceTestObjectBuilder().Build();

			var expected = new CurveWorkflowAction[]
						   {
							   new(WorkflowOperationType.Approve, AdminCurveType.Manual, 1),
							   new(WorkflowOperationType.Reject, AdminCurveType.Manual, 2)
						   };

			// ACT
			var response = testObjects.CurveApprovalsUpdateService.UpdateCurveApprovals(items,
																						testObjects.Scheduler);

			// ASSERT
			Mock.Get(testObjects.ActionService)
				.Verify(a => a.Update(It.Is<IList<CurveWorkflowAction>>(i => i.SequenceEqual(expected, new CurveWorkflowActionComparer())),
									  testObjects.Scheduler));

			Assert.That(response, Is.SameAs(testObjects.ActionServiceResponse));
		}

		[Test]
		public void ShouldThrowInvalidOperationException_When_Update_With_NonPendingItem()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 1, Status = CurveApprovalStatus.Approved };

			var testObjects = new CurveApprovalsUpdateServiceTestObjectBuilder().Build();

			Exception result = null;

			// ACT
			try
			{
				testObjects.CurveApprovalsUpdateService.UpdateCurveApprovals([item],testObjects.Scheduler);
			}
			catch (Exception ex)
			{
				result = ex;
			}

			// ASSERT
			Assert.That(result, Is.TypeOf<InvalidOperationException>());
		}
	}
}
