﻿using NUnit.Framework;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Enum;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.ViewModels;
using Moq;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.TestObjects;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Approvals.Controllers
{
	internal interface ICurveApprovalItemControllerTestObjects
	{
		ICurveApprovalsNavigationService NavigationService { get; }
		CurveApprovalItem ViewModel { get; }
		CurveApprovalItemController Controller { get; }
	}

	[TestFixture]
	public class CurveApprovalItemControllerTests
	{
		private class CurveApprovalItemControllerTestObjectBuilder
		{
			private bool _isReadOnly;
			private CurveApprovalStatus _status;
			private CurveApprovalItemType _itemType;
			private int _id;
			private string _actionedByUserName;

			public CurveApprovalItemControllerTestObjectBuilder WithIsReadOnly(bool value)
			{
				_isReadOnly = value;
				return this;
			}

			public CurveApprovalItemControllerTestObjectBuilder WithStatus(CurveApprovalStatus value)
			{
				_status = value;
				return this;
			}

			public CurveApprovalItemControllerTestObjectBuilder WithItemType(CurveApprovalItemType value)
			{
				_itemType = value;
				return this;
			}

			public CurveApprovalItemControllerTestObjectBuilder WithId(int value)
			{
				_id = value;
				return this;
			}

			public CurveApprovalItemControllerTestObjectBuilder WithActionedByUserName(string value)
			{
				_actionedByUserName = value;
				return this;
			}


			public ICurveApprovalItemControllerTestObjects Build()
			{
				var testObjects = new Mock<ICurveApprovalItemControllerTestObjects>();

				var navigationService = new Mock<ICurveApprovalsNavigationService>();

				testObjects.SetupGet(o => o.NavigationService)
						   .Returns(navigationService.Object);

				var controller = new CurveApprovalItemController(navigationService.Object, 
																 TestMocks.GetSchedulerProvider().Object);

				controller.ViewModel.IsReadOnly = _isReadOnly;
				controller.ViewModel.Status = _status;
				controller.ViewModel.ItemType = _itemType;
				controller.ViewModel.Id = _id;
				controller.ViewModel.ActionedByUserName = _actionedByUserName;

				testObjects.SetupGet(o => o.Controller)
						   .Returns(controller);

				testObjects.SetupGet(o => o.ViewModel)
						   .Returns(controller.ViewModel);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldDisableApprove_On_IsReadyOnlyTrue()
		{
			var testObjects = new CurveApprovalItemControllerTestObjectBuilder().Build();

			// ACT
			testObjects.Controller.ViewModel.IsReadOnly = true;

			// ASSERT
			Assert.That(testObjects.ViewModel.ApproveCommand.CanExecute(), Is.False);
		}

		[Test]
		public void ShouldEnableApprove_On_IsReadyOnlyFalse()
		{
			var testObjects = new CurveApprovalItemControllerTestObjectBuilder().WithIsReadOnly(true)
																				.Build();

			// ACT
			testObjects.Controller.ViewModel.IsReadOnly = false;

			// ASSERT
			Assert.That(testObjects.ViewModel.ApproveCommand.CanExecute(), Is.True);
		}

		[Test]
		public void ShouldSetStatusApprovalPending_And_UpdateCommands_OnApprove()
		{
			var testObjects = new CurveApprovalItemControllerTestObjectBuilder().WithIsReadOnly(false)
																				.WithStatus(CurveApprovalStatus.ApprovalRequired)
																				.Build();

			// ACT
			testObjects.Controller.ViewModel.ApproveCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.Status, Is.EqualTo(CurveApprovalStatus.ApprovalPending));
			Assert.That(testObjects.ViewModel.HasChanged , Is.True);
			Assert.That(testObjects.ViewModel.ApproveCommand.CanExecute(), Is.False);
			Assert.That(testObjects.ViewModel.RejectCommand.CanExecute(), Is.False);
			Assert.That(testObjects.ViewModel.UndoCommand.CanExecute(), Is.True);
		}

		[Test]
		public void ShouldSetStatusApprovalPending_And_UpdateCommands_OnReject()
		{
			var testObjects = new CurveApprovalItemControllerTestObjectBuilder().WithIsReadOnly(false)
																				.WithStatus(CurveApprovalStatus.ApprovalRequired)
																				.Build();

			// ACT
			testObjects.Controller.ViewModel.RejectCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.Status, Is.EqualTo(CurveApprovalStatus.RejectionPending));
			Assert.That(testObjects.ViewModel.HasChanged, Is.True);
			Assert.That(testObjects.ViewModel.ApproveCommand.CanExecute(), Is.False);
			Assert.That(testObjects.ViewModel.RejectCommand.CanExecute(), Is.False);
			Assert.That(testObjects.ViewModel.UndoCommand.CanExecute(), Is.True);
		}

		[Test]
		public void ShouldUndoChanges_OnUndo()
		{
			var testObjects = new CurveApprovalItemControllerTestObjectBuilder().WithIsReadOnly(false)
																				.WithStatus(CurveApprovalStatus.ApprovalRequired)
																				.Build();

			// ARRANGE
			testObjects.Controller.ViewModel.ApproveCommand.Execute();

			// ACT
			testObjects.Controller.ViewModel.UndoCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.Status, Is.EqualTo(CurveApprovalStatus.ApprovalRequired));
			Assert.That(testObjects.ViewModel.HasChanged, Is.False);
			Assert.That(testObjects.ViewModel.ApproveCommand.CanExecute(), Is.True);
			Assert.That(testObjects.ViewModel.RejectCommand.CanExecute(), Is.True);
			Assert.That(testObjects.ViewModel.UndoCommand.CanExecute(), Is.False);
		}

		[Test]
		public void ShouldNavigateToManualCurveDraft_ViewDraftCommand_With_ManualItemType()
		{
			var testObjects = new CurveApprovalItemControllerTestObjectBuilder().WithItemType(CurveApprovalItemType.Manual)
																				.WithId(101)
																				.WithActionedByUserName("user-1")
																				.Build();

			// ACT
			testObjects.ViewModel.ViewDraftCommand.Execute();

			// ASSERT
			Mock.Get(testObjects.NavigationService)
				.Verify(n => n.NavigateToManualCurveDraft(101, "user-1"));
		}

		#region Dispose

		[Test]
		public void ShouldNotUpdateCommands_When_Disposed()
		{
			var testObjects = new CurveApprovalItemControllerTestObjectBuilder().WithIsReadOnly(false)
																				.WithStatus(CurveApprovalStatus.ApprovalRequired)
																				.Build();

			// ARRANGE
			testObjects.Controller.Dispose();

			// ACT
			testObjects.Controller.ViewModel.ApproveCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.HasChanged, Is.False);
			Assert.That(testObjects.ViewModel.ApproveCommand.CanExecute(), Is.True);
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var testObjects = new CurveApprovalItemControllerTestObjectBuilder().WithIsReadOnly(false)
																				.WithStatus(CurveApprovalStatus.ApprovalRequired)
																				.Build();

			// ARRANGE
			testObjects.Controller.Dispose();

			// ACT
			testObjects.Controller.Dispose();
			testObjects.Controller.ViewModel.ApproveCommand.Execute();

			// ASSERT
			Assert.That(testObjects.ViewModel.HasChanged, Is.False);
			Assert.That(testObjects.ViewModel.ApproveCommand.CanExecute(), Is.True);
		}

		#endregion
	}
}
