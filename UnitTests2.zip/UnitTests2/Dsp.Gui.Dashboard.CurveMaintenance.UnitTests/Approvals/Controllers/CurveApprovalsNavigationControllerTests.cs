﻿using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Approvals.Controllers
{
	interface ICurveApprovalsNavigationControllerTestObjects
	{
		ICurveApprovalsNavigationService NavigationService { get; }
		INavigationViewModel ViewModel { get; }
		CurveApprovalsNavigationController Controller { get; }
	}

	[TestFixture]
	public class CurveApprovalsNavigationControllerTests
	{
		private class CurveApprovalsNavigationControllerTestObjects
		{
			public ICurveApprovalsNavigationControllerTestObjects Build()
			{
				var testObjects = new Mock<ICurveApprovalsNavigationControllerTestObjects>();


				var viewModel = new NavigationViewModel();

				testObjects.SetupGet(o => o.ViewModel)
						   .Returns(viewModel);

				var navigationService = new Mock<ICurveApprovalsNavigationService>();

				navigationService.SetupGet(n => n.ViewModel)
								 .Returns(viewModel);

				testObjects.SetupGet(o => o.NavigationService)
						   .Returns(navigationService.Object);

				var controller = new CurveApprovalsNavigationController(navigationService.Object);

				testObjects.SetupGet(o => o.Controller)
						   .Returns(controller);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldNavigateToApprovals_On_ViewLoaded()
		{
			var testObjects = new CurveApprovalsNavigationControllerTestObjects().Build();

			// ACT
			testObjects.ViewModel.ViewLoadedCommand.Execute();

			// ASSERT
			Mock.Get(testObjects.NavigationService)
				.Verify(n => n.NavigateToApprovals());
		}
	}
}
