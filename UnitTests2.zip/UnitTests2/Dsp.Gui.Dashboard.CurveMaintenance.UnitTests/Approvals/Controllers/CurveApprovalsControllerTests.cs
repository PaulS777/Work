﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Controllers;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Enum;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.Services;
using Dsp.Gui.Dashboard.CurveMaintenance.Approvals.ViewModels;
using Dsp.Gui.TestObjects;
using DynamicData;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Approvals.Controllers
{
	internal interface ICurveApprovalsControllerTestObjects
	{
		ICurveApprovalItemsProvider CurveApprovalItemsProvider { get; }
		ISubject<List<CurveApprovalItem>> CurveApprovalItems { get; }
		ICurveApprovalItemsDataSource DataSource { get; }
		ICurveApprovalsToolBarService ToolBarService { get; }
		ISubject<Unit> ToolBarUndo { get; }
		ISubject<Unit> ToolBarUpdate { get; }
		ICurveApprovalsUpdateService CurveApprovalsUpdateService { get; }
		ISubject<AdminApiActionCompleted> CurveApprovalsUpdateResponse { get; }
		IPopupNotificationService PopupNotificationService { get; }
		IErrorMessageDialogService ErrorMessageDialogService { get; }
		CurveApprovalsViewModel ViewModel { get; }
		CurveApprovalsController Controller { get; }
	}

	[TestFixture]
	public class CurveApprovalsControllerTests
	{
		private class CurveApprovalsControllerTestObjectBuilder
		{
			private List<CurveApprovalItem> _curveApprovalItems;
			private ObservableCollection<CurveApprovalItem> _dataSourceItems = [];
			private Exception _updateServiceException;

			public CurveApprovalsControllerTestObjectBuilder WithCurveApprovalItems(IEnumerable<CurveApprovalItem> values)
			{
				_curveApprovalItems = [..values];
				return this;
			}

			public CurveApprovalsControllerTestObjectBuilder WithDataSourceItems(IEnumerable<CurveApprovalItem> values)
			{
				_dataSourceItems = new ObservableCollection<CurveApprovalItem>(values);
				return this;
			}

			public CurveApprovalsControllerTestObjectBuilder WithUpdateServiceException(Exception value)
			{
				_updateServiceException = value;
				return this;
			}

			public ICurveApprovalsControllerTestObjects Build()
			{
				var testObjects = new Mock<ICurveApprovalsControllerTestObjects>();

				var curveApprovalItems = new BehaviorSubject<List<CurveApprovalItem>>(_curveApprovalItems);

				testObjects.SetupGet(o => o.CurveApprovalItems)
						   .Returns(curveApprovalItems);

				var itemsProvider = new Mock<ICurveApprovalItemsProvider>();

				itemsProvider.Setup(p => p.CurveApprovalItems(It.IsAny<ICurveApprovalItemsDataSource>()))
							 .Returns(curveApprovalItems);

				testObjects.SetupGet(o => o.CurveApprovalItemsProvider)
						   .Returns(itemsProvider.Object);

				var changeSet = new ChangeSet<CurveApprovalItem>([new Change<CurveApprovalItem>(ListChangeReason.AddRange,
																								_dataSourceItems)]);

				var connect = new BehaviorSubject<IChangeSet<CurveApprovalItem>>(changeSet);

				var dataSource = new Mock<ICurveApprovalItemsDataSource>();

				dataSource.Setup(d => d.InitializeDataSource(It.IsAny<IList<CurveApprovalItem>>()))
						  .Returns(new ReadOnlyObservableCollection<CurveApprovalItem>(_dataSourceItems));

				dataSource.Setup(d => d.Connect(It.IsAny<Func<CurveApprovalItem, bool>>()))
						  .Returns(connect);

				dataSource.Setup(d => d.Items())
						  .Returns(_dataSourceItems);

				testObjects.SetupGet(o => o.DataSource)
						   .Returns(dataSource.Object);

				var toolBarUpdate = new Subject<Unit>();

				testObjects.SetupGet(o => o.ToolBarUpdate)
						   .Returns(toolBarUpdate);

				var toolBarUndo = new Subject<Unit>();

				testObjects.SetupGet(o => o.ToolBarUndo)
						   .Returns(toolBarUndo);

				var toolBarService = new Mock<ICurveApprovalsToolBarService>();

				toolBarService.SetupGet(t => t.Update)
							  .Returns(toolBarUpdate);

				toolBarService.SetupGet(T => T.UndoChanges)
							  .Returns(toolBarUndo);

				testObjects.SetupGet(o => o.ToolBarService)
						   .Returns(toolBarService.Object);

				var actionCompleted = new Subject<AdminApiActionCompleted>();

				testObjects.SetupGet(o => o.CurveApprovalsUpdateResponse)
						   .Returns(actionCompleted);

				var curveApprovalsUpdateService = new Mock<ICurveApprovalsUpdateService>();

				if (_updateServiceException == null)
				{
					curveApprovalsUpdateService.Setup(a => a.UpdateCurveApprovals(It.IsAny<IList<CurveApprovalItem>>(),
																				  It.IsAny<IScheduler>()))
											   .Returns(actionCompleted);
				}
				else
				{
					curveApprovalsUpdateService.Setup(a => a.UpdateCurveApprovals(It.IsAny<IList<CurveApprovalItem>>(),
																				  It.IsAny<IScheduler>()))
											   .Throws(_updateServiceException);
				}

				testObjects.SetupGet(o => o.CurveApprovalsUpdateService)
						   .Returns(curveApprovalsUpdateService.Object);

				var popupNotificationService = new Mock<IPopupNotificationService>();

				testObjects.SetupGet(o => o.PopupNotificationService)
						   .Returns(popupNotificationService.Object);

				var errorMessageDialog = new Mock<IErrorMessageDialogService>();

				testObjects.SetupGet(o => o.ErrorMessageDialogService)
						   .Returns(errorMessageDialog.Object);

				var controller = new CurveApprovalsController(itemsProvider.Object,
															  dataSource.Object,
															  toolBarService.Object,
															  curveApprovalsUpdateService.Object,
															  TestMocks.GetSchedulerProvider().Object,
															  TestMocks.GetLoggerFactory().Object)
								 {
									 PopupNotificationService = popupNotificationService.Object,
									 ErrorMessageDialogService = errorMessageDialog.Object
								 };

				testObjects.SetupGet(o => o.Controller)
						   .Returns(controller);

				testObjects.SetupGet(o => o.ViewModel)
						   .Returns(controller.ViewModel);

				return testObjects.Object;
			}
		}

		#region Initialize

		[Test]
		public void ShouldSetIsBusyTrue()
		{
			var testObjects = new CurveApprovalsControllerTestObjectBuilder().Build();

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.True);
			Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);
		}

		[Test]
		public void ShouldSetIsBusyFalse_And_SubscribeCurveApprovalItems_On_Initialize()
		{
			var testObjects = new CurveApprovalsControllerTestObjectBuilder().Build();

			// ACT
			testObjects.ViewModel.InitializeCommand.Execute();
			
			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.False);
			Assert.That(testObjects.ViewModel.BusyText, Is.Null);

			Mock.Get(testObjects.CurveApprovalItemsProvider)
				.Verify(p => p.CurveApprovalItems(testObjects.DataSource));
		}

		[Test]
		public void ShouldNotInitialize_When_Already_Initialized()
		{
			var testObjects = new CurveApprovalsControllerTestObjectBuilder().Build();

			// ARRANGE
			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ViewModel.InitializeCommand.Execute();

			// ASSERT
			Mock.Get(testObjects.CurveApprovalItemsProvider)
				.Verify(p => p.CurveApprovalItems(testObjects.DataSource), Times.Once);
		}

		#endregion

		#region DataSource

		[Test]
		public void ShouldInitializeDataSource_On_FirstCurveApprovalItems()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>());

			var items = new List<CurveApprovalItem> { item };
			
			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.CurveApprovalItems.OnNext(items);

			// ASSERT
			Mock.Get(testObjects.DataSource)
				.Verify(d => d.InitializeDataSource(items));

			Assert.That(testObjects.ViewModel.CurveApprovalItems.Count, Is.EqualTo(1));
		}

		[Test]
		public void ShouldRefreshDataSource_On_FirstCurveApprovalItems()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>());

			var items = new List<CurveApprovalItem> { item };

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([])
																			 .WithCurveApprovalItems([])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.CurveApprovalItems.OnNext(items);

			// ASSERT
			Mock.Get(testObjects.DataSource)
				.Verify(d => d.RefreshItems(items));
		}

		#endregion

		#region Items Changed 

		[Test]
		public void ShouldEnableToolbarUpdateUndo_On_DataSourceItemChanged()
		{
			var item1 = new CurveApprovalItem(Mock.Of<IDisposable>());
			var item2 = new CurveApprovalItem(Mock.Of<IDisposable>());

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item1, item2])
																			 .WithCurveApprovalItems([item1, item2])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			item1.HasChanged = true;

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUpdate(true));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUndoChanges(true));
		}

		[Test]
		public void ShouldDisableToolbarUpdateUndo_On_DataSourceItemChangedFalse()
		{
			var item1 = new CurveApprovalItem(Mock.Of<IDisposable>()) { HasChanged = true };
			var item2 = new CurveApprovalItem(Mock.Of<IDisposable>());

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item1, item2])
																			 .WithCurveApprovalItems([item1, item2])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			Mock.Get(testObjects.ToolBarService).Invocations.Clear();

			// ACT
			item1.HasChanged = false;

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUpdate(false));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUndoChanges(false));
		}

		#endregion

		#region ToolBar Undo

		[Test]
		public void ShouldResetItemsStatus_And_ToolBarCommands_On_ToolBarUndo_With_Changes()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>()) { Status = CurveApprovalStatus.ApprovalRequired };

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item])
																			 .WithCurveApprovalItems([item])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			item.Status = CurveApprovalStatus.RejectionPending;
			item.HasChanged = true;

			Mock.Get(testObjects.ToolBarService).Invocations.Clear();

			// ACT
			testObjects.ToolBarUndo.OnNext(Unit.Default);

			// ASSERT
			Assert.That(item.Status, Is.EqualTo(CurveApprovalStatus.ApprovalRequired));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUpdate(false));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUndoChanges(false));

		}

		[Test]
		public void ShouldResubscribeItemChanges_On_ToolBarUndo()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>()) { Status = CurveApprovalStatus.ApprovalRequired };

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item])
																			 .WithCurveApprovalItems([item])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			item.Status = CurveApprovalStatus.RejectionPending;
			item.HasChanged = true;

			testObjects.ToolBarUndo.OnNext(Unit.Default);

			Mock.Get(testObjects.ToolBarService).Invocations.Clear();

			// ACT
			item.HasChanged = true;

			// ASSERT
			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUpdate(true));

			Mock.Get(testObjects.ToolBarService)
				.Verify(tb => tb.SetCanUndoChanges(true));
		}

		#endregion

		#region ToolBar Update

		[Test]
		public void ShouldShowBusyIndicator_And_InvokeApprovalUpdate_On_ToolBarUpdate_With_ItemsPending()
		{
			var item1 = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 1, Status = CurveApprovalStatus.Approved };
			var item2 = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 2, Status = CurveApprovalStatus.ApprovalPending };
			var item3 = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 2, Status = CurveApprovalStatus.RejectionPending };

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item1, item2, item3])
																			 .WithCurveApprovalItems([item1, item2, item3])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			var expected = new[] { item2, item3 };

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.True);
			Assert.That(testObjects.ViewModel.BusyText, Is.Not.Null);

			Mock.Get(testObjects.CurveApprovalsUpdateService)
				.Verify(u => u.UpdateCurveApprovals(It.Is<IList<CurveApprovalItem>>(items => items.SequenceEqual(expected)),
													It.IsAny<IScheduler>()));
		}

		// todo : clear changes
		[Test]
		public void ShouldClearBusyIndicator_And_ShowPopup_On_ApprovalUpdate_Completed()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 2, Status = CurveApprovalStatus.ApprovalPending };

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item])
																			 .WithCurveApprovalItems([item])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ACT
			testObjects.CurveApprovalsUpdateResponse.OnNext(new AdminApiActionCompleted());

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.False);
			Assert.That(testObjects.ViewModel.BusyText, Is.Null);

			Mock.Get(testObjects.PopupNotificationService)
				.Verify(p => p.SendPopupNotification(It.IsAny<string>(), It.IsAny<string>()));
		}

		[Test]
		public void ShouldClearBusyIndicator_And_ShowDialog_On_ApprovalUpdate_Completed_With_Warning()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 2, Status = CurveApprovalStatus.ApprovalPending };

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item])
																			 .WithCurveApprovalItems([item])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ACT
			testObjects.CurveApprovalsUpdateResponse.OnNext(new AdminApiActionCompleted("warning"));

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.False);
			Assert.That(testObjects.ViewModel.BusyText, Is.Null);

			Mock.Get(testObjects.ErrorMessageDialogService)
				.Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
		}

		[Test]
		public void ShouldClearBusyIndicator_And_ShowDialog_On_ApprovalUpdate_Error()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 2, Status = CurveApprovalStatus.ApprovalPending };

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item])
																			 .WithCurveApprovalItems([item])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ACT
			testObjects.CurveApprovalsUpdateResponse.OnError(new Exception());

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.False);
			Assert.That(testObjects.ViewModel.BusyText, Is.Null);

			Mock.Get(testObjects.ErrorMessageDialogService)
				.Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
		}

		[Test]
		public void ShouldClearBusyIndicator_And_ShowDialog_On_ApprovalUpdate_Exception()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>()) { Id = 2, Status = CurveApprovalStatus.ApprovalPending };

			var error = new Exception("error");

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([item])
																			 .WithCurveApprovalItems([item])
																			 .WithUpdateServiceException(error)
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ACT
			testObjects.ToolBarUpdate.OnNext(Unit.Default);

			// ASSERT
			Assert.That(testObjects.ViewModel.IsBusy, Is.False);
			Assert.That(testObjects.ViewModel.BusyText, Is.Null);

			Mock.Get(testObjects.ErrorMessageDialogService)
				.Verify(d => d.ShowDialog(It.IsAny<ErrorMessageDialogArgs>()));
		}

		#endregion

		#region Dispose

		[Test]
		public void ShouldNotRefreshDataSource_When_Disposed()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>());

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([])
																			 .WithCurveApprovalItems([])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.Controller.Dispose();

			// ACT
			testObjects.CurveApprovalItems.OnNext([item]);

			// ASSERT
			Mock.Get(testObjects.DataSource)
				.Verify(d => d.RefreshItems(It.IsAny<List<CurveApprovalItem>>()), Times.Never());
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var item = new CurveApprovalItem(Mock.Of<IDisposable>());

			var testObjects = new CurveApprovalsControllerTestObjectBuilder().WithDataSourceItems([])
																			 .WithCurveApprovalItems([])
																			 .Build();

			testObjects.ViewModel.InitializeCommand.Execute();

			// ARRANGE
			testObjects.Controller.Dispose();

			// ACT
			testObjects.Controller.Dispose();
			testObjects.CurveApprovalItems.OnNext([item]);

			// ASSERT
			Mock.Get(testObjects.DataSource)
				.Verify(d => d.RefreshItems(It.IsAny<List<CurveApprovalItem>>()), Times.Never());
		}

		#endregion
	}
}
