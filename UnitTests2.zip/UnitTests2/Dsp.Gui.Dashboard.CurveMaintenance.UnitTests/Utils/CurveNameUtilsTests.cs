﻿using Dsp.Gui.Dashboard.CurveMaintenance.Utils;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.CurveMaintenance.UnitTests.Utils
{
	[TestFixture]
	public class CurveNameUtilsTests
	{
		[Test]
		public void ShouldReturnTrue_And_SetParsed_When_TryParseDraft_With_Draft()
		{
			var name = "CURVE_DRAFT";

			// ACT
			var result = CurveNameUtils.TryParseDraft(name, out var parsed);

			// ASSERT
			Assert.That(result, Is.True);
			Assert.That(parsed, Is.EqualTo("CURVE"));
		}

		[Test]
		public void ShouldReturnFalse_And_NotSetParsed_When_TryParseDraft_With_NonDraft()
		{
			var name = "CURVE";

			// ACT
			var result = CurveNameUtils.TryParseDraft(name, out var parsed);

			// ASSERT
			Assert.That(result, Is.False);
			Assert.That(parsed, Is.Null);
		}

		[Test]
		public void ShouldAppendDraft()
		{
			var name = "CURVE";

			// ACT
			var result = CurveNameUtils.AppendDraft(name);

			// ASSERT
			Assert.That(result, Is.EqualTo("CURVE_DRAFT"));
		}
	}
}
