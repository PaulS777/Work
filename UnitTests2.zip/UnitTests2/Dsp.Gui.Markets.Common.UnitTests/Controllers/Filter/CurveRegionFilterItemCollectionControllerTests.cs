﻿using Castle.Components.DictionaryAdapter;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Controllers;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Controllers.Filter
{
    [TestFixture]
    public class CurveRegionFilterItemCollectionControllerTests
    {
        [Test]
        public void ShouldSetItemIsSelectedTrue_WhenRegionIsSelected()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = false, CanSelect = true},
                                       new(curveItem2){IsSelected = false, CanSelect = true}
                                   };

            // ACT
            viewModel.RegionHeader.IsSelected = true;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.True);
            Assert.That(viewModel.Items[1].IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetItemIsSelectedFalse_WhenRegionIsSelectedFalse()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = true };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-1",
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = true, CanSelect = true},
                                       new(curveItem2){IsSelected = true, CanSelect = true}
                                   };

            // ACT
            viewModel.RegionHeader.IsSelected = false;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.False);
            Assert.That(viewModel.Items[1].IsSelected, Is.False);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToIntermediateState_WhenSingleItemSelected()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = false, CanSelect = true},
                                       new(curveItem2){IsSelected = false, CanSelect = true}
                                   };

            // ACT
            viewModel.Items[0].IsSelected = true;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.Null);
        }

        [Test]
        public void ShouldInitializeRegionIsSelected_ToTrue_WhenInitializedWithCurveFilterItems()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-2", 
                                                     2);

            // ACT
            viewModel.Items = new EditableList<MarketsFilterItem>
            {
                new(curveItem1){IsSelected = true, CanSelect = true},
                new(curveItem2){IsSelected = true, CanSelect = true}
            };

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToTrue_WhenAllItemsSelected()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = false, CanSelect = true},
                                       new(curveItem2){IsSelected = false, CanSelect = true}
                                   };

            // ACT
            viewModel.Items[0].IsSelected = true;
            viewModel.Items[1].IsSelected = true;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToIntermediateState_WhenItemDeSelected()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = true };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = true, CanSelect = true},
                                       new(curveItem2){IsSelected = true, CanSelect = true}
                                   };

            // ACT
            viewModel.Items[0].IsSelected = false;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.Null);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToFalse_WhenAllItemsDeSelected()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = true };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = true, CanSelect = true},
                                       new(curveItem2){IsSelected = true, CanSelect = true}
                                   };

            // ACT
            viewModel.Items[0].IsSelected = false;
            viewModel.Items[1].IsSelected = false;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.False);
        }

        [Test]
        public void ShouldNotUpdateDisabledItems_WhenRegionIsSelected()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = false, CanSelect = true},
                                       new(curveItem2){IsSelected = false, CanSelect = false}
                                   };

            // ACT
            viewModel.RegionHeader.IsSelected = true;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.True);
            Assert.That(viewModel.Items[1].IsSelected, Is.False);
        }

        [Test]
        public void ShouldNotUpdateDisabledItems_WhenRegionIsDeSelected()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = true };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = true, CanSelect = true},
                                       new(curveItem2){IsSelected = true, CanSelect = false}
                                   };

            // ACT
            viewModel.RegionHeader.IsSelected = false;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.False);
            Assert.That(viewModel.Items[1].IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToTrue_WhenAllItemsSelected_ExcludingDisabledItems()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-1",
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = false, CanSelect = true},
                                       new(curveItem2){IsSelected = false, CanSelect = false}
                                   };

            // ACT
            viewModel.Items[0].IsSelected = true;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToFalse_WhenAllItemsDeSelected_ExcludingDisabledItems()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = true };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = true, CanSelect = true},
                                       new(curveItem2){IsSelected = true, CanSelect = false}
                                   };

            // ACT
            viewModel.Items[0].IsSelected = false;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.False);
        }

        [Test]
        public void ShouldSetCurveGroupIsSelected_ToIntermediateState_WhenSelectedItem()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = false, CanSelect = true},
                                       new(curveItem2){IsSelected = false, CanSelect = true}
                                   };

            // ACT
            viewModel.Items[0].IsSelected = true;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected,Is.Null);
        }

        [Test]
        public void ShouldSetCurveGroupIsSelected_ToFalse_WhenSelectedItem_Disabled()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = null };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = false, CanSelect = true},
                                       new(curveItem2){IsSelected = true, CanSelect = true}
                                   };

            // ACT
            viewModel.Items[1].CanSelect = false;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.False);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToTrue_WhenUnSelectedItem_Disabled()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = null };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-1", 
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-2",
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = true, CanSelect = true},
                                       new(curveItem2){IsSelected = false, CanSelect = true}
                                   };

            // ACT
            viewModel.Items[1].CanSelect = false;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.True);
        }

        [Test]
        public void ShouldSetRegionIsSelected_ToNull_WhenDisabledSelectedItem_Enabled()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = true };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1",
                                                     2);

            var curveItem2 = new CurveItemDefinition(new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve),
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-2", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){IsSelected = true, CanSelect = true},
                                       new(curveItem2){IsSelected = false, CanSelect = false}
                                   };

            // ACT
            viewModel.Items[1].CanSelect = true;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.Null);
        }

        [Test]
        public void ShouldNotUpdateHeader_WhenDisposed()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1)
                                       {
                                           CanSelect = true
                                       }
                                   };

            // ARRANGE
            controller.Dispose();

            // ACT
            viewModel.Items[0].IsSelected = true;

            // ASSERT
            Assert.That(viewModel.RegionHeader.IsSelected, Is.False);
        }


        [Test]
        public void ShouldNotUpdateItems_WhenDisposed()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(),
                                                     "curve-1",
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
                                   {
                                       new(curveItem1){CanSelect = true }
                                   };

            // ARRANGE
            controller.Dispose();

            // ACT
            viewModel.RegionHeader.IsSelected = true;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.False);
        }


        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var controller = new CurveRegionFilterItemCollectionController(TestMocks.GetSchedulerProvider().Object);

            var viewModel = controller.CurveRegionFilterItemCollection;

            viewModel.RegionHeader = new CurveRegionFilterHeader(CurveRegion.Europe) { IsSelected = false };

            var curveItem1 = new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
                                                     new CurveGroupTestObjectBuilder().Default(), 
                                                     "curve-1", 
                                                     2);

            viewModel.Items = new EditableList<MarketsFilterItem>
            {
                new(curveItem1){CanSelect = true }
            };

            // ARRANGE
            controller.Dispose();

            // ACT
            controller.Dispose();
            viewModel.RegionHeader.IsSelected = true;

            // ASSERT
            Assert.That(viewModel.Items[0].IsSelected, Is.False);
        }
    }
}
