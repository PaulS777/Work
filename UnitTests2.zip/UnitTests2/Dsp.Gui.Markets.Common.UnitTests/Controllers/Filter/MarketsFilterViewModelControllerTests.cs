﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.ToolBar.Markets.ViewModels;
using Dsp.Gui.Markets.Common.Controllers;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.UnitTest.Helpers.Builders;
using DynamicData;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Controllers.Filter
{
    public interface IMarketsFilterViewModelControllerTestObjects
    {
        ICurveGroupRegionsDataSource DataSource { get; }
		IUserMarketsWithSettingsService UserMarketsWithSettingsService { get; }
        IUserMarketsUpdateReasonService IUserMarketsUpdateReasonService { get; }
        IManualFilterChangedService ManualFilterChangedService { get; }

		ICurveGroupRegionCollectionBuilder CurveGroupRegionCollectionBuilder { get; }
        ISubject<List<UserMarket>> UserMarkets { get; }
        ISubject<LinkedCurve> RemovePriceBand { get; }
        TestScheduler TestScheduler { get; }
        long ThrottleInterval { get; }
        MarketsFilterViewModel ViewModel { get; }
        MarketsFilterViewModelController Controller { get; }
    }

    [TestFixture]
    public class MarketsFilterViewModelControllerTests
    {
        private class MarketsFilterViewModelControllerTestObjectBuilder
        {
            private List<UserMarket> _userMarkets;
			private Queue<List<CurveGroupRegionCollection>> _curveGroupRegions;
            private ReadOnlyObservableCollection<CurveGroupRegionCollection> _initializeDataSourceResult;
			private IEnumerable<MarketsFilterItem> _dataSourceMarketsFilterItems;
            private ChangeSet<CurveGroupRegionCollection> _dataSourceConnect;

            public MarketsFilterViewModelControllerTestObjectBuilder WithUserMarkets(List<UserMarket> values)
            {
                _userMarkets = values;
                return this;
            }

			public MarketsFilterViewModelControllerTestObjectBuilder WithCurveGroupRegions(IList<List<CurveGroupRegionCollection>> values)
			{
				_curveGroupRegions = new Queue<List<CurveGroupRegionCollection>>(values);
				return this;
			}


			public MarketsFilterViewModelControllerTestObjectBuilder WithInitializeDataSourceResult(IList<CurveGroupRegionCollection> values)
			{
				_initializeDataSourceResult = new ReadOnlyObservableCollection<CurveGroupRegionCollection>(new ObservableCollection<CurveGroupRegionCollection>(values));
				return this;
			}

			public MarketsFilterViewModelControllerTestObjectBuilder WithDataSourceMarketFilterItems(IEnumerable<MarketsFilterItem> values)
			{
				_dataSourceMarketsFilterItems = values;
				return this;
			}

			public MarketsFilterViewModelControllerTestObjectBuilder WithDataSourceConnect(ChangeSet<CurveGroupRegionCollection> values)
            {
                _dataSourceConnect = values;
                return this;
            }

            public IMarketsFilterViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IMarketsFilterViewModelControllerTestObjects>();

                testObjects.SetupGet(o => o.ThrottleInterval)
                           .Returns(TimeSpan.FromMilliseconds(51).Ticks);

                var removePriceBand = new Subject<LinkedCurve>();

                testObjects.SetupGet(o => o.RemovePriceBand)
                           .Returns(removePriceBand);

                var dataSource = new Mock<ICurveGroupRegionsDataSource>();

                dataSource.Setup(d => d.InitializeDataSource(It.IsAny<IList<CurveGroupRegionCollection>>()))
                          .Returns(_initializeDataSourceResult);

                dataSource.Setup(d => d.GetMarketsFilterItems())
                          .Returns(_dataSourceMarketsFilterItems);

                var dataSourceConnect = new BehaviorSubject<ChangeSet<CurveGroupRegionCollection>>(_dataSourceConnect);

                dataSource.Setup(d => d.Connect(It.IsAny<Func<CurveGroupRegionCollection, bool>>()))
                          .Returns(dataSourceConnect);

                testObjects.SetupGet(o => o.DataSource)
                           .Returns(dataSource.Object);

                var userMarkets = new BehaviorSubject<List<UserMarket>>(_userMarkets);

                testObjects.SetupGet(o => o.UserMarkets)
                           .Returns(userMarkets);

                var userMarketsWithSettingsService = new Mock<IUserMarketsWithSettingsService>();

                userMarketsWithSettingsService.SetupGet(p => p.UserMarkets)
											  .Returns(userMarkets);

                testObjects.SetupGet(o => o.UserMarketsWithSettingsService)
                           .Returns(userMarketsWithSettingsService.Object);

                var userMarketsFilterService = new Mock<IUserMarketsUpdateReasonService>();

                testObjects.SetupGet(o => o.IUserMarketsUpdateReasonService)
                           .Returns(userMarketsFilterService.Object);

				var manualFilterSettingsUpdateService = new Mock<IManualFilterChangedService>();

				testObjects.SetupGet(o => o.ManualFilterChangedService)
						   .Returns(manualFilterSettingsUpdateService.Object);

                var curveGroupRegionCollectionBuilder = new Mock<ICurveGroupRegionCollectionBuilder>();

                if (_curveGroupRegions != null)
				{
					curveGroupRegionCollectionBuilder.Setup(b => b.GetCurveGroupRegions(It.IsAny<IEnumerable<UserMarket>>()))
													 .Returns(_curveGroupRegions.Dequeue);
				}

				testObjects.SetupGet(o => o.CurveGroupRegionCollectionBuilder)
                           .Returns(curveGroupRegionCollectionBuilder.Object);

                var testScheduler = new TestScheduler();

                testObjects.SetupGet(o => o.TestScheduler)
                           .Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();

                schedulerProvider.SetupGet(p => p.TaskPool)
                                 .Returns(testScheduler);

                schedulerProvider.SetupGet(p => p.Dispatcher)
                                 .Returns(Scheduler.Immediate);

                var controller = new MarketsFilterViewModelController(dataSource.Object,
                                                                      curveGroupRegionCollectionBuilder.Object,
                                                                      schedulerProvider.Object);

                controller.ViewModel.ToolBar = new PriceGridToolBarViewModel(Mock.Of<IDisposable>());

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldInitializeDataSource_On_FirstUserMarkets()
        {
            var curveGroupRegions = new CurveGroupRegionCollectionTestObjectBuilder().Build();

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithCurveGroupRegions([curveGroupRegions])
                                                                                     .WithInitializeDataSourceResult(curveGroupRegions)
																					 .WithDataSourceMarketFilterItems([])
                                                                                     .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			var userMarkets = new List<UserMarket>();

            // ACT
            testObjects.UserMarkets.OnNext(userMarkets);

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.InitializeDataSource(It.Is<IList<CurveGroupRegionCollection>>(c => c.SequenceEqual(curveGroupRegions))));


            Assert.That(testObjects.ViewModel.CurveGroupRegions.SequenceEqual(curveGroupRegions));
		}

        [Test]
        public void ShouldRefreshDataSource_On_NextUserMarkets()
        {
            var curveGroupRegions1 = new CurveGroupRegionCollectionTestObjectBuilder().Build();
            var curveGroupRegions2 = new CurveGroupRegionCollectionTestObjectBuilder().Build();

            var userMarkets = new List<UserMarket>();

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithCurveGroupRegions([curveGroupRegions1, curveGroupRegions2])
                                                                                     .WithUserMarkets(userMarkets)
                                                                                     .WithInitializeDataSourceResult(curveGroupRegions1)
																					 .WithDataSourceMarketFilterItems([])
																					 .Build();

            testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			Mock.Get(testObjects.ManualFilterChangedService).Invocations.Clear();

			// ACT
			testObjects.UserMarkets.OnNext(userMarkets);

            // ASSERT
            Mock.Get(testObjects.DataSource)
                .Verify(d => d.RefreshItems(It.Is<IList<CurveGroupRegionCollection>>(c => c.SequenceEqual(curveGroupRegions2))));

			Mock.Get(testObjects.ManualFilterChangedService)
				.Verify(f => f.RaiseFilterChanged(), Times.Never);
		}

        [Test]
        public void ShouldShowMarketsFilter_On_MarketsLoaded_With_NoItemsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve, 
                                                                           new CurveGroupTestObjectBuilder().Default(),
                                                                           "curve-1", 
                                                                           2))
                             {
                                 IsSelected = false, CanSelect = true
                             };


            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithDataSourceMarketFilterItems([filterItem])
                                                                                     .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			var userMarkets = new List<UserMarket>();

            // ACT
            testObjects.UserMarkets.OnNext(userMarkets);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldNotShowMarketsFilter_On_MarketsLoaded_With_ItemSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve, 
                                                                           new CurveGroupTestObjectBuilder().Default(),
                                                                           "curve-1", 
                                                                           2))
                             {
                                 IsSelected = true, CanSelect = true
                             };

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithDataSourceMarketFilterItems([filterItem])
																					 .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			var userMarkets = new List<UserMarket>();

            // ACT
            testObjects.UserMarkets.OnNext(userMarkets);

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldSetItemsOriginalIsSelected_On_MarketsLoaded_With_ItemSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve,
                                                                           new CurveGroupTestObjectBuilder().Default(),
                                                                           "curve-1", 
                                                                           2))
                             {
                                 IsSelected = true, CanSelect = true
                             };

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithDataSourceMarketFilterItems([filterItem])
																					 .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			var userMarkets = new List<UserMarket>();

            // ACT
            testObjects.UserMarkets.OnNext(userMarkets);

            // ASSERT
            Assert.That(filterItem.OriginalIsSelected, Is.True);
        }

        [Test]
        public void ShouldShowMarketsFilter_On_ToolBarShowMarketsFilterTrue()
        {
            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithDataSourceMarketFilterItems([])
																					 .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			// ACT
			testObjects.ViewModel.ToolBar.ShowMarketsFilter = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.True);
        }

        [Test]
        public void ShouldHideMarketsFilter_On_ToolBarShowMarketsFilterFalse()
        {
            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithDataSourceMarketFilterItems([])
																					 .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			// ACT
			testObjects.ViewModel.ToolBar.ShowMarketsFilter = false;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldDisableApplyAndCancelFilterChanges_When_Connect_With_NoItemsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve, 
                                                                           new CurveGroupTestObjectBuilder().Default(), 
                                                                           "curve-1", 
                                                                           2))
                             {
                                 IsSelected = false, CanSelect = true, OriginalIsSelected = false
                             };

            var curveGroupRegions = new CurveGroupRegionCollectionTestObjectBuilder().WithMarketsFilterItem(filterItem)
                                                                                     .Build();
            var userMarkets = new List<UserMarket>();

            var changeSet = new ChangeSet<CurveGroupRegionCollection>([new(ListChangeReason.AddRange, curveGroupRegions)]);

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithCurveGroupRegions([curveGroupRegions])
                                                                                     .WithUserMarkets(userMarkets)
                                                                                     .WithInitializeDataSourceResult(curveGroupRegions)
																					 .WithDataSourceMarketFilterItems([])
																					 .WithDataSourceConnect(changeSet)
                                                                                     .Build();

			// ACT
			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			testObjects.TestScheduler.AdvanceBy(testObjects.ThrottleInterval);

            // ASSERT
            Assert.That(testObjects.ViewModel.ApplyFilterChangesCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.CancelColumnFilterChangesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableApplyAndCancelFilterChanges_When_Connect_With_ItemsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve, 
                                                                           new CurveGroupTestObjectBuilder().Default(),
                                                                           "curve-1", 
                                                                           2))
                             {
                                 IsSelected = true, CanSelect = true, OriginalIsSelected = true
                             };

            var curveGroupRegions = new CurveGroupRegionCollectionTestObjectBuilder().WithMarketsFilterItem(filterItem)
                                                                                     .Build();

            var userMarkets = new List<UserMarket>();

            var changeSet = new ChangeSet<CurveGroupRegionCollection>([new(ListChangeReason.AddRange, curveGroupRegions)]);

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithCurveGroupRegions([curveGroupRegions])
                                                                                     .WithUserMarkets(userMarkets)
                                                                                     .WithInitializeDataSourceResult(curveGroupRegions)
																					 .WithDataSourceMarketFilterItems([])
																					 .WithDataSourceConnect(changeSet)
                                                                                     .Build();

			// ACT
			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			testObjects.TestScheduler.AdvanceBy(testObjects.ThrottleInterval);

            // ASSERT
            Assert.That(testObjects.ViewModel.ApplyFilterChangesCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.CancelColumnFilterChangesCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableApplyAndCancelFilterChanges_When_CurveItemsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve,
                                                                           new CurveGroupTestObjectBuilder().Default(), 
                                                                           "curve-1", 
                                                                           2))
                             {
                                 IsSelected = false, CanSelect = true, OriginalIsSelected = false
                             };

            var curveGroupRegions = new CurveGroupRegionCollectionTestObjectBuilder().WithMarketsFilterItem(filterItem)
                                                                                     .Build();

            var userMarkets = new List<UserMarket>();

            var changeSet = new ChangeSet<CurveGroupRegionCollection>([new Change<CurveGroupRegionCollection>(ListChangeReason.AddRange, curveGroupRegions)]);

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithCurveGroupRegions([curveGroupRegions])
                                                                                     .WithUserMarkets(userMarkets)
                                                                                     .WithInitializeDataSourceResult(curveGroupRegions)
																					 .WithDataSourceMarketFilterItems([])
																					 .WithDataSourceConnect(changeSet)
                                                                                     .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			// ACT
			filterItem.IsSelected = true;
            testObjects.TestScheduler.AdvanceBy(testObjects.ThrottleInterval);

            // ASSERT
            Assert.That(testObjects.ViewModel.ApplyFilterChangesCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.CancelColumnFilterChangesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableApplyAndCancelFilterChanges_When_Item_CanSelectFalse()
        {
            var filterItem = new MarketsFilterItem(new CurveItemDefinition(new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
                                                                           new CurveGroupTestObjectBuilder().Default(),
                                                                           "curve-1",
                                                                           2))
            {
                IsSelected = true,
                CanSelect = true,
                OriginalIsSelected = true
            };

            var curveGroupRegions = new CurveGroupRegionCollectionTestObjectBuilder().WithMarketsFilterItem(filterItem)
                                                                                     .Build();

            var userMarkets = new List<UserMarket>();

            var changeSet = new ChangeSet<CurveGroupRegionCollection>([new Change<CurveGroupRegionCollection>(ListChangeReason.AddRange, curveGroupRegions)]);

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithCurveGroupRegions([curveGroupRegions])
                                                                                     .WithUserMarkets(userMarkets)
                                                                                     .WithInitializeDataSourceResult(curveGroupRegions)
																					 .WithDataSourceMarketFilterItems([])
																					 .WithDataSourceConnect(changeSet)
                                                                                     .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			// ACT
			filterItem.CanSelect = false;
            testObjects.TestScheduler.AdvanceBy(testObjects.ThrottleInterval);

            // ASSERT
            Assert.That(testObjects.ViewModel.ApplyFilterChangesCommand.CanExecute(), Is.False);
            Assert.That(testObjects.ViewModel.CancelColumnFilterChangesCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableApplyAndCancelFilterChanges_When_DialogOpened_With_ItemsSelected()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve,
                                                                           new CurveGroupTestObjectBuilder().Default(), 
                                                                           "curve-1", 
                                                                           2))
            {
                IsSelected = true,
                CanSelect = true,
                OriginalIsSelected = true
            };

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithDataSourceMarketFilterItems([filterItem])
																					 .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			// ACT
			testObjects.ViewModel.ToolBar.ShowMarketsFilter = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ApplyFilterChangesCommand.CanExecute(), Is.True);
            Assert.That(testObjects.ViewModel.CancelColumnFilterChangesCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldUpdateFilter_And_CloseDialog_When_ApplyChanges()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var curveItemDefinition = new CurveItemDefinition(linkedCurve,
															  new CurveGroupTestObjectBuilder().Default(),
															  "curve-1",
															  2);

			var filterItem = new MarketsFilterItem(curveItemDefinition)
            {
                IsSelected = false,
                CanSelect = true,
                OriginalIsSelected = false
            };

            var curveGroupRegions = new CurveGroupRegionCollectionTestObjectBuilder().WithMarketsFilterItem(filterItem)
                                                                                     .Build();

            var userMarkets = new List<UserMarket>();

            var changeSet = new ChangeSet<CurveGroupRegionCollection>([new Change<CurveGroupRegionCollection>(ListChangeReason.AddRange, curveGroupRegions)]);

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithCurveGroupRegions([curveGroupRegions])
                                                                                     .WithUserMarkets(userMarkets)
																					 .WithDataSourceMarketFilterItems([filterItem])
																					 .WithDataSourceConnect(changeSet)
                                                                                     .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			filterItem.IsSelected = true;
            testObjects.TestScheduler.AdvanceBy(testObjects.ThrottleInterval);

			Mock.Get(testObjects.ManualFilterChangedService).Invocations.Clear();

			// ACT
			testObjects.ViewModel.ApplyFilterChangesCommand.Execute();

            // ASSERT
            Assert.That(filterItem.OriginalIsSelected, Is.True);

            Mock.Get(testObjects.ManualFilterChangedService)
				.Verify(f => f.RaiseFilterChanged());


            Assert.That(testObjects.ViewModel.ToolBar.ShowMarketsFilter, Is.False);
        }

        [Test]
        public void ShouldUndoChanges_And_CloseDialog_When_CancelChanges()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve, 
                                                                           new CurveGroupTestObjectBuilder().Default(),
                                                                           "curve-1", 
                                                                           2))
            {
                IsSelected = false,
                CanSelect = true,
                OriginalIsSelected = false
            };

            var curveGroupRegions = new CurveGroupRegionCollectionTestObjectBuilder().WithMarketsFilterItem(filterItem)
                                                                                     .Build();

            var userMarkets = new List<UserMarket>();

            var changeSet = new ChangeSet<CurveGroupRegionCollection>([new Change<CurveGroupRegionCollection>(ListChangeReason.AddRange, curveGroupRegions)]);

            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithCurveGroupRegions([curveGroupRegions])
                                                                                     .WithUserMarkets(userMarkets)
																					 .WithDataSourceMarketFilterItems([filterItem])
																					 .WithDataSourceConnect(changeSet)
                                                                                     .Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			filterItem.IsSelected = true;
            testObjects.TestScheduler.AdvanceBy(testObjects.ThrottleInterval);

            // ACT
            testObjects.ViewModel.CancelColumnFilterChangesCommand.Execute();

            // ASSERT
            Assert.That(filterItem.IsSelected, Is.False);
            Assert.That(testObjects.ViewModel.ToolBar.ShowMarketsFilter, Is.False);
        }

        //[Test]
        //public void ShouldDeselectItem_And_UpdateFilter_On_RemovePriceBand()
        //{
        //    var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
        //    var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

        //    var filterItem1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1,
        //                                                                    new CurveGroupTestObjectBuilder().Default(), 
        //                                                                    "curve-1",
        //                                                                    2))
        //                      {
        //                          OriginalIsSelected = true,
        //                          IsSelected = true,
        //                          CanSelect = true
        //                      };

        //    var filterItem2 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve2, 
        //                                                                    new CurveGroupTestObjectBuilder().Default(),
        //                                                                    "curve-2",
        //                                                                    2))
        //                      {
        //                          OriginalIsSelected = true,
        //                          IsSelected = true,
        //                          CanSelect = true
        //                      };

        //    var filterItems = new List<MarketsFilterItem> { filterItem1, filterItem2 };

        //    var dataSourceItems = new CurveGroupRegionCollectionTestObjectBuilder().WithMarketsFilterItems(filterItems)
        //                                                                           .Build();

        //    var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().WithDataSourceItems(dataSourceItems)
        //                                                                             .Build();

        //    testObjects.Controller.Initialize(testObjects.UserMarketsFilterService,
        //                                      testObjects.UserMarketsProviderService,
								//			  testObjects.ManualFilterChangedService,
								//			  testObjects.RemovePriceBand);

        //    var expectedFilter = new[] { linkedCurve2 }; 

        //    // ACT
        //    testObjects.RemovePriceBand.OnNext(linkedCurve1);

        //    // ASSERT
        //    Assert.That(filterItem1.IsSelected, Is.False);
        //    Assert.That(filterItem1.OriginalIsSelected, Is.False);

        //    Mock.Get(testObjects.UserMarketsFilterService)
        //        .Verify(f => f.UpdateFromRemovedCurve(It.Is<IEnumerable<LinkedCurve>>(l => l.SequenceEqual(expectedFilter))));
        //}

        [Test]
        public void ShouldNotShowMarketsFilter_When_Disposed()
        {
            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			testObjects.Controller.Dispose();

            // ACT
            testObjects.ViewModel.ToolBar.ShowMarketsFilter = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var testObjects = new MarketsFilterViewModelControllerTestObjectBuilder().Build();

			testObjects.Controller.Initialize(testObjects.UserMarketsWithSettingsService,
											  testObjects.ManualFilterChangedService);

			testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.ViewModel.ToolBar.ShowMarketsFilter = true;

            // ASSERT
            Assert.That(testObjects.ViewModel.ShowDialog, Is.False);
        }
    }
}
