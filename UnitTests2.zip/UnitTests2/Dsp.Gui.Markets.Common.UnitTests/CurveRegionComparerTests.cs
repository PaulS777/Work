﻿using System.Linq;
using Dsp.DataContracts.Curve;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests
{
    [TestFixture]
    public class CurveRegionComparerTests
    {
        [Test]
        public void ShouldOrderRegions()
        {
            var regions = new[]
                          {
                              CurveRegion.MiddleEast,
                              CurveRegion.Asia,
                              CurveRegion.Europe,
                              CurveRegion.UnitedStates,
                              CurveRegion.Europe,
                              CurveRegion.Asia,
                              CurveRegion.MiddleEast
                          };

            var expectedSequence = new[]
                                   {
                                      CurveRegion.Europe,
                                      CurveRegion.Europe,
                                      CurveRegion.UnitedStates,
                                      CurveRegion.Asia,
                                      CurveRegion.Asia,
                                      CurveRegion.MiddleEast,
                                      CurveRegion.MiddleEast
                                   };

            var result = regions.OrderBy(r => r, new CurveRegionComparer())
                                .ToList();

            // ASSERT
            Assert.That(result.SequenceEqual(expectedSequence));
        }
    }
}
