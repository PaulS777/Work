﻿using System.Collections.Generic;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.UnitTest.Helpers.Builders;

namespace Dsp.Gui.Markets.Common.UnitTests
{
    public class CurveGroupRegionCollectionTestObjectBuilder
    {
        private List<MarketsFilterItem> _marketsFilterItems;

        public CurveGroupRegionCollectionTestObjectBuilder WithMarketsFilterItem(MarketsFilterItem value)
        {
            _marketsFilterItems = new List<MarketsFilterItem> { value };
            return this;
        }

        public CurveGroupRegionCollectionTestObjectBuilder WithMarketsFilterItems(List<MarketsFilterItem> values)
        {
            _marketsFilterItems = values;
            return this;
        }

        public List<CurveGroupRegionCollection> Build()
        {
            var curveGroupRegionCollection = new List<CurveGroupRegionCollection>
                                             {
                                                 new(new CurveGroupTestObjectBuilder().Default())
                                                 {
                                                     CurveRegionFilters = [new() { Items = _marketsFilterItems }]
                                                 }
                                             };

            return curveGroupRegionCollection;
        }
    }
}
