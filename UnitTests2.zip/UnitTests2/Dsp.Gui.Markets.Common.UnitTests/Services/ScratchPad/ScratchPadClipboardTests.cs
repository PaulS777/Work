﻿using System;
using System.Collections.Generic;
using Castle.Components.DictionaryAdapter;
using Dsp.DataContracts;
using Dsp.Gui.Markets.Common.Services.ScratchPad;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using Dsp.Gui.TestObjects;
using NUnit.Framework;
using Moq;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.ScratchPad
{
    [TestFixture]
    public class ScratchPadClipboardTests
    {
        [Test]
        public void ShouldCopyClipboardPriceCurves()
        {
            var priceCurves = new List<List<TenorPriceCell>>
                              {
                                  new EditableList<TenorPriceCell> { Defaults.TenorPriceCell()}
                              };

            var clipboard = new ScratchPadClipboard();

            // ACT
            clipboard.CopyToClipboard(priceCurves, new List<ITenor>(), new List<string>());

            var result = clipboard.GetClipboardPrices();

            // ASSERT
            Assert.That(result, Is.SameAs(priceCurves));
        }

        [Test]
        public void ShouldGetClipboardTenors()
        {
            var tenors = new[] { Mock.Of<ITenor>() };

            var clipboard = new ScratchPadClipboard();

            // ACT
            clipboard.CopyToClipboard(new List<List<TenorPriceCell>>(), tenors, new List<string>());

            var result = clipboard.GetClipboardTenors();

            // ASSERT
            Assert.That(result, Is.SameAs(tenors));
        }

        [Test]
        public void ShouldGetClipboardHeaders()
        {
            var headers = new[] { "curve-1" };

            var clipboard = new ScratchPadClipboard();

            // ACT
            clipboard.CopyToClipboard(new List<List<TenorPriceCell>>(), new List<ITenor>(), headers);

            var result = clipboard.GetClipboardHeaders();

            // ASSERT
            Assert.That(result, Is.SameAs(headers));
        }

        [Test]
        public void ShouldPublishHasPricesTrue_When_CopyPricesToClipboard()
        {
            var priceCurves = new List<List<TenorPriceCell>>
                              {
                                  new EditableList<TenorPriceCell> { Defaults.TenorPriceCell()}
                              };

            var clipboard = new ScratchPadClipboard();

            var result = false;

            using (clipboard.HasPrices.Subscribe(value => result = value))
            {
                // ACT
                clipboard.CopyToClipboard(priceCurves, new List<ITenor>(), new List<string>());

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishHasPricesTrue_When_CopyTenorsToClipboard()
        {
            var tenors = new[] { Mock.Of<ITenor>() };

            var clipboard = new ScratchPadClipboard();

            var result = false;

            using (clipboard.HasPrices.Subscribe(value => result = value))
            {
                // ACT
                clipboard.CopyToClipboard(new List<List<TenorPriceCell>>(), tenors, null);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishHasPricesTrue_When_CopyHeadersToClipboard()
        {
            var headers = new[] { "curve-1" };

            var clipboard = new ScratchPadClipboard();

            var result = false;

            using (clipboard.HasPrices.Subscribe(value => result = value))
            {
                // ACT
                clipboard.CopyToClipboard(new List<List<TenorPriceCell>>(), new List<ITenor>(), headers);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishHasPricesFalse_When_CopyPricesToClipboard_With_Empty()
        {
            var clipboard = new ScratchPadClipboard();

            var result = false;

            using (clipboard.HasPrices.Subscribe(value => result = value))
            {
                // ACT
                clipboard.CopyToClipboard(new List<List<TenorPriceCell>>(), new List<ITenor>(), new List<string>());

                // ASSERT
                Assert.That(result, Is.False);
            }
        }
    }
}
