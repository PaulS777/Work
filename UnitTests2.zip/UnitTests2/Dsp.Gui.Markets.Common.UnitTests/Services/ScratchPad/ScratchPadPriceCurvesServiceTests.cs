﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Services.ScratchPad;
using Dsp.Gui.Markets.Common.ViewModels.Price;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.ScratchPad
{
    [TestFixture]
    public class ScratchPadPriceCurvesServiceTests
    {
        [Test]
        public void ShouldPublishIsLoadingTrue_When_UpdateIsLoadingTrue()
        {
            var result = false;

            var service = new ScratchPadPriceCurvesService();

            using (service.IsLoading.Subscribe(value => result = value))
            {
                // ACT
                service.UpdateIsLoading(true);

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishPriceCurves_When_UpdateScratchPad()
        {
            var priceCurves = new Dictionary<LinkedCurve, List<TenorPriceCell>>();

            Dictionary<LinkedCurve, List<TenorPriceCell>> result = null;

            var service = new ScratchPadPriceCurvesService();

            using (service.PriceCurves.Subscribe(value => result = value))
            {
                // ACT
                service.UpdatePriceCurves(priceCurves);

                // ASSERT
                Assert.That(result, Is.SameAs(priceCurves));
            }
        }

        [Test]
        public void ShouldPublishClearBindings_When_NotifyClearBindings()
        {
            var result = false;

            var service = new ScratchPadPriceCurvesService();

            using (service.ClearBindings.Subscribe(_ => result = true))
            {
                // ACT
                service.NotifyClearBindings();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }

        [Test]
        public void ShouldPublishRestoreBindings_When_NotifyRestoreBindings()
        {
            var result = false;

            var service = new ScratchPadPriceCurvesService();

            using (service.RestoreBindings.Subscribe(_ => result = true))
            {
                // ACT
                service.NotifyRestoreBindings();

                // ASSERT
                Assert.That(result, Is.True);
            }
        }
    }
}
