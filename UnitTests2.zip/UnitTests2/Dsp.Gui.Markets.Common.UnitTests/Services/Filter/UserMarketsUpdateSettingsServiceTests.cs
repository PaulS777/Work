﻿using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.UnitTests.Helpers;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	internal interface IUserMarketsUpdateSettingsServiceTestObjects
	{
		IUserMarketsUpdateReasonService IUserMarketsUpdateReasonService { get; }
		ISubject<UserMarketsFilterArgs> UserMarketsFilter { get; }
		IDashboardSettingsService DashboardSettingsService { get; }
		UserMarketsUpdateSettingsService UserMarketsUpdateSettingsService { get; }
	}

	public class UserMarketsUpdateSettingsServiceTests
	{
		private class UserMarketsUpdateSettingsServiceTestObjectBuilder
		{
			public IUserMarketsUpdateSettingsServiceTestObjects Build()
			{
				var testObjects = new Mock<IUserMarketsUpdateSettingsServiceTestObjects>();

				var userMarketsFilter = new Subject<UserMarketsFilterArgs>();

				testObjects.SetupGet(o => o.UserMarketsFilter)
						   .Returns(userMarketsFilter);

				var userMarketsFilterUpdateReasonService = new Mock<IUserMarketsUpdateReasonService>();

				userMarketsFilterUpdateReasonService.SetupGet(f => f.UserMarketsFilter)
												.Returns(userMarketsFilter);

				testObjects.SetupGet(o => o.IUserMarketsUpdateReasonService)
						   .Returns(userMarketsFilterUpdateReasonService.Object);

				var dashboardSettingsService = new Mock<IDashboardSettingsService>();

				testObjects.SetupGet(o => o.DashboardSettingsService)
						   .Returns(dashboardSettingsService.Object);

				var userMarketsUpdateSettingsService = new UserMarketsUpdateSettingsService(dashboardSettingsService.Object);

				testObjects.SetupGet(o => o.UserMarketsUpdateSettingsService)
						   .Returns(userMarketsUpdateSettingsService);

				return testObjects.Object;
			}
		}

		[TestCase(UserMarketsFilterUpdateReason.ManualSelection)]
		[TestCase(UserMarketsFilterUpdateReason.ManualSelectionRemovedCurvesOnly)]
		[TestCase(UserMarketsFilterUpdateReason.PublicationSettings)]
		[TestCase(UserMarketsFilterUpdateReason.SelectedCurveDefinitionRemoved)]
		public void ShouldUpdateSettings_Where_FilteredIsSelected_With_Reason_NotLoaded(UserMarketsFilterUpdateReason reason)
		{
			var linkedCurve1 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);
			var linkedCurve2 = new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithPriceCurveId(101).WithIsSelected(true).Build();
			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2).WithPriceCurveId(102).WithIsSelected(false).Build();

			var userMarkets = new List<UserMarket>{ userMarket1, userMarket2 };
			var args = new UserMarketsFilterArgs(userMarkets, reason);

			var testObjects = new UserMarketsUpdateSettingsServiceTestObjectBuilder().Build();

			testObjects.UserMarketsUpdateSettingsService.Initialize(testObjects.IUserMarketsUpdateReasonService, 2);

			// ACT
			testObjects.UserMarketsFilter.OnNext(args);

			// ASSERT
			Mock.Get(testObjects.DashboardSettingsService)
				.Verify(d => d.UpdateFilterSettings(It.Is<IList<FilterSettingsItem>>(i => i.Count == 1 
																					   && i[0].LinkedCurve == linkedCurve1
																					   && i[0].PriceCurveId == 101), 
													2, 
													false));
		}

		[Test]
		public void ShouldNotUpdateSettings_Where_FilteredIsSelected_With_Reason_Loaded()
		{
			var linkedCurve1 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);
		
			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithPriceCurveId(101).WithIsSelected(true).Build();

			var userMarkets = new List<UserMarket> { userMarket1};
			var args = new UserMarketsFilterArgs(userMarkets, UserMarketsFilterUpdateReason.MarketsLoaded);

			var testObjects = new UserMarketsUpdateSettingsServiceTestObjectBuilder().Build();

			testObjects.UserMarketsUpdateSettingsService.Initialize(testObjects.IUserMarketsUpdateReasonService, 2);

			// ACT
			testObjects.UserMarketsFilter.OnNext(args);

			// ASSERT
			Mock.Get(testObjects.DashboardSettingsService)
				.Verify(d => d.UpdateFilterSettings(It.IsAny<IList<FilterSettingsItem>>(),
													2,
													false), Times.Never);
		}

		[Test]
		public void ShouldNotUpdateSettings_When_Disposed()
		{
			var linkedCurve1 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithPriceCurveId(101).WithIsSelected(true).Build();

			var userMarkets = new List<UserMarket> { userMarket1 };
			var args = new UserMarketsFilterArgs(userMarkets, UserMarketsFilterUpdateReason.ManualSelection);

			var testObjects = new UserMarketsUpdateSettingsServiceTestObjectBuilder().Build();

			testObjects.UserMarketsUpdateSettingsService.Initialize(testObjects.IUserMarketsUpdateReasonService, 2);

			// ARRANGE
			testObjects.UserMarketsUpdateSettingsService.Dispose();

			// ACT
			testObjects.UserMarketsFilter.OnNext(args);

			// ASSERT
			Mock.Get(testObjects.DashboardSettingsService)
				.Verify(d => d.UpdateFilterSettings(It.IsAny<IList<FilterSettingsItem>>(),
													2,
													false), Times.Never);
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var linkedCurve1 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1).WithPriceCurveId(101).WithIsSelected(true).Build();

			var userMarkets = new List<UserMarket> { userMarket1 };
			var args = new UserMarketsFilterArgs(userMarkets, UserMarketsFilterUpdateReason.ManualSelection);

			var testObjects = new UserMarketsUpdateSettingsServiceTestObjectBuilder().Build();

			testObjects.UserMarketsUpdateSettingsService.Initialize(testObjects.IUserMarketsUpdateReasonService, 2);

			// ARRANGE
			testObjects.UserMarketsUpdateSettingsService.Dispose();

			// ACT
			testObjects.UserMarketsUpdateSettingsService.Dispose();
			testObjects.UserMarketsFilter.OnNext(args);

			// ASSERT
			Mock.Get(testObjects.DashboardSettingsService)
				.Verify(d => d.UpdateFilterSettings(It.IsAny<IList<FilterSettingsItem>>(),
													2,
													false), Times.Never);
		}
	}
}
