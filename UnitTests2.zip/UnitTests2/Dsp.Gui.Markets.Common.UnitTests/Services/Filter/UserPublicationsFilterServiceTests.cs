﻿using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Reactive.Subjects;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	internal interface IUserPublicationsFilterServiceTestObjects
	{
		ISubject<IList<int>> PublicationCurveIds { get; }
		ICurveGroupRegionsDataSource DataSource { get; }
		UserPublicationsFilterService UserPublicationsFilterService { get; }
	}

	[TestFixture]
	public class UserPublicationsFilterServiceTests
	{
		private class UserPublicationsFilterServiceTestObjectBuilder
		{
			private IList<int> _publicationCurveIds;
			private IEnumerable<MarketsFilterItem> _marketsFilterItems;

			public UserPublicationsFilterServiceTestObjectBuilder WithPublicationCurveIds(IList<int> values)
			{
				_publicationCurveIds = values;
				return this;
			}

			public UserPublicationsFilterServiceTestObjectBuilder WithMarketsFilterItems(IEnumerable<MarketsFilterItem> values)
			{
				_marketsFilterItems = values;
				return this;
			}

			public IUserPublicationsFilterServiceTestObjects Build()
			{
				var testObjects = new Mock<IUserPublicationsFilterServiceTestObjects>();

				var publicationCurveIds = new BehaviorSubject<IList<int>>(_publicationCurveIds);

				testObjects.SetupGet(o => o.PublicationCurveIds)
						   .Returns(publicationCurveIds);

				var dataSource = new Mock<ICurveGroupRegionsDataSource>();

				dataSource.Setup(d => d.GetMarketsFilterItems())
						  .Returns(_marketsFilterItems);

				testObjects.SetupGet(o => o.DataSource)
						   .Returns(dataSource.Object);

				var service = new UserPublicationsFilterService();

				testObjects.SetupGet(o => o.UserPublicationsFilterService)
						   .Returns(service);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldNotPublish_On_Subscribe()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2))
			{
				CanSelect = true,
				IsSelected = true
			};

			var items = new[] { item1 };

			var ids = new[] { linkedCurve1.Id };

			var testObjects = new UserPublicationsFilterServiceTestObjectBuilder().WithMarketsFilterItems(items)
																				  .WithPublicationCurveIds(ids)
																				  .Build();

			IList<MarketsFilterItemArgs> results = null;

			var publicationsFilter = testObjects.UserPublicationsFilterService.PublicationsFilter(testObjects.DataSource,
																								  testObjects.PublicationCurveIds);

			// ACT
			using (publicationsFilter.Subscribe(args => results = args))
			{
				// ASSERT
				Assert.That(results, Is.Null );
			}
		}

		[Test]
		public void ShouldSetManualCurve_CanSelect_And_IsSelected_On_CurveMatchesPublisher_Previous_CanSelectFalse()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2));

			var item2 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve2, crude, "name", 2, 101))
			{
				CanSelect = false,
				IsSelected = false
			};

			var items = new[] { item1, item2 };

			var ids = new[] { linkedCurve1.Id };

			var testObjects = new UserPublicationsFilterServiceTestObjectBuilder().WithMarketsFilterItems(items)
																				  .WithPublicationCurveIds([])
																				  .Build();

			IList<MarketsFilterItemArgs> results = null;

			var publicationsFilter = testObjects.UserPublicationsFilterService.PublicationsFilter(testObjects.DataSource,
																								  testObjects.PublicationCurveIds);

			using (publicationsFilter.Subscribe(args => results = args))
			{

				// ACT
				testObjects.PublicationCurveIds.OnNext(ids);

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(2));

				Assert.That(results[1].Id, Is.EqualTo(linkedCurve2));
				Assert.That(results[1].CanSelect, Is.True);
				Assert.That(results[1].IsSelected, Is.True);
			}
		}

		[Test]
		public void ShouldNotSetManualCurve_IsSelected_On_CurveMatchesPublisher_Previous_CanSelectTrue()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2));

			var item2 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve2, crude, "name", 2, 101))
						{
							CanSelect = true,
							IsSelected = false
						};

			var items = new[] { item1, item2 };

			var ids = new[] { linkedCurve1.Id };

			var testObjects = new UserPublicationsFilterServiceTestObjectBuilder().WithMarketsFilterItems(items)
																				  .WithPublicationCurveIds([])
																				  .Build();

			IList<MarketsFilterItemArgs> results = null;

			var publicationsFilter = testObjects.UserPublicationsFilterService.PublicationsFilter(testObjects.DataSource,
																								  testObjects.PublicationCurveIds);

			using (publicationsFilter.Subscribe(args => results = args))
			{

				// ACT
				testObjects.PublicationCurveIds.OnNext(ids);

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(2));

				Assert.That(results[1].Id, Is.EqualTo(linkedCurve2));
				Assert.That(results[1].CanSelect, Is.True);
				Assert.That(results[1].IsSelected, Is.False);
			}
		}

		[Test]
		public void ShouldSetManualCurve_CanSelectFalse_Retain_IsSelected_On_CurveNotMatchesPublisher()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2));

			var item2 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve2, crude, "name", 2, 101))
						{
							CanSelect = true,
							IsSelected = true
						};

			var items = new[] { item1, item2 };

			var ids = new[] { linkedCurve1.Id };

			var testObjects = new UserPublicationsFilterServiceTestObjectBuilder().WithMarketsFilterItems(items)
																				  .WithPublicationCurveIds(ids)
																				  .Build();

			IList<MarketsFilterItemArgs> results = null;

			var publicationsFilter = testObjects.UserPublicationsFilterService.PublicationsFilter(testObjects.DataSource,
																								  testObjects.PublicationCurveIds);

			using (publicationsFilter.Subscribe(args => results = args))
			{

				// ACT
				testObjects.PublicationCurveIds.OnNext([]);

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(2));

				Assert.That(results[1].Id, Is.EqualTo(linkedCurve2));
				Assert.That(results[1].CanSelect, Is.False);
				Assert.That(results[1].IsSelected, Is.True);
			}
		}

		#region Dispose

		[Test]
		public void ShouldNotPublish_When_Disposed()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2));

			var item2 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve2, crude, "name", 2, 101))
						{
							CanSelect = true,
							IsSelected = false
						};

			var items = new[] { item1, item2 };

			var ids = new[] { linkedCurve1.Id };

			var testObjects = new UserPublicationsFilterServiceTestObjectBuilder().WithMarketsFilterItems(items)
																				  .WithPublicationCurveIds([])
																				  .Build();

			IList<MarketsFilterItemArgs> results = null;

			var publicationsFilter = testObjects.UserPublicationsFilterService.PublicationsFilter(testObjects.DataSource,
																								  testObjects.PublicationCurveIds);

			using (publicationsFilter.Subscribe(args => results = args))
			{

				testObjects.UserPublicationsFilterService.Dispose();

				// ACT
				testObjects.PublicationCurveIds.OnNext(ids);

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2));

			var item2 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve2, crude, "name", 2, 101))
						{
							CanSelect = true,
							IsSelected = false
						};

			var items = new[] { item1, item2 };

			var ids = new[] { linkedCurve1.Id };

			var testObjects = new UserPublicationsFilterServiceTestObjectBuilder().WithMarketsFilterItems(items)
																				  .WithPublicationCurveIds([])
																				  .Build();

			IList<MarketsFilterItemArgs> results = null;

			var publicationsFilter = testObjects.UserPublicationsFilterService.PublicationsFilter(testObjects.DataSource,
																								  testObjects.PublicationCurveIds);

			using (publicationsFilter.Subscribe(args => results = args))
			{

				testObjects.UserPublicationsFilterService.Dispose();

				// ACT
				testObjects.PublicationCurveIds.OnNext(ids);

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}

		#endregion
	}
}
