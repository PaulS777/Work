﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	internal interface IUserPublicationsProviderTestObjects
	{
		ISubject<User> CurrentUser { get; }
		ISubject<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
		UserPublicationsProvider UserPublicationsProvider { get; }
	}

	public class UserPublicationsProviderTests 
	{
		private class UserPublicationsProviderTestObjectBuilder
		{
			private User _currentUser;
			private Dictionary<int, PriceCurveSetting> _priceCurveSettings = new();

			public UserPublicationsProviderTestObjectBuilder WithCurrentUser(User value)
			{
				_currentUser = value;
				return this;
			}

			public UserPublicationsProviderTestObjectBuilder WithPriceCurveSettings(Dictionary<int, PriceCurveSetting> value)
			{
				_priceCurveSettings = value;
				return this;
			}

			public IUserPublicationsProviderTestObjects Build()
			{
				var testObjects = new Mock<IUserPublicationsProviderTestObjects>();

				var user = new BehaviorSubject<User>(_currentUser);

				testObjects.SetupGet(o => o.CurrentUser)
						   .Returns(user);

				var curveControlService = new Mock<ICurveControlService>();

				curveControlService.SetupGet(c => c.CurrentUser)
								   .Returns(user);

				var priceCurveSettings = new BehaviorSubject<Dictionary<int, PriceCurveSetting>>(_priceCurveSettings);

				testObjects.SetupGet(o => o.PriceCurveSettings)
						   .Returns(priceCurveSettings);

				var priceCurveSettingsProvider = new Mock<IPriceCurveSettingsProvider>();

				priceCurveSettingsProvider.SetupGet(p => p.PriceCurveSettings)
										  .Returns(priceCurveSettings);

				var userPublicationsProvider = new UserPublicationsProvider(curveControlService.Object,
																			priceCurveSettingsProvider.Object);

				testObjects.SetupGet(o => o.UserPublicationsProvider)
						   .Returns(userPublicationsProvider);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldPublishUserPublicationIds_On_Subscribe()
		{
			var user = new UserBuilder().WithId(10).User();

			var priceCurveSetting1 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
																			 .WithPublisherId(10)
																			 .Build();

			var priceCurveSetting2 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																			 .WithPublisherId(11)
																			 .Build();

			var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
									 {
										 { 101, priceCurveSetting1 },
										 { 102, priceCurveSetting2 }
									 };

			var testObjects = new UserPublicationsProviderTestObjectBuilder().WithCurrentUser(user)
																			 .WithPriceCurveSettings(priceCurveSettings)
																			 .Build();

			IList<int> results = null;

			var expected = new[] { 101 };

			// ACT
			using (testObjects.UserPublicationsProvider.PublicationCurveIds.Subscribe(values => results = values))
			{
				// ASSERT
				Assert.That(results.SequenceEqual(expected));
			}
		}

		[Test]
		public void ShouldPublishUpdatedUserPublicationIds_On_PriceCurveSetting_With_UserAsPublisherId()
		{
			var user = new UserBuilder().WithId(10).User();

			var priceCurveSetting1 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
																			 .WithPublisherId(10)
																			 .Build();

			var priceCurveSetting2 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																			 .WithPublisherId(11)
																			 .Build();


			var priceCurveSetting2Update = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																				   .WithPublisherId(10)
																				   .Build();

			var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
									 {
										 { 101, priceCurveSetting1 },
										 { 102, priceCurveSetting2 }
									 };

			var update = new Dictionary<int, PriceCurveSetting>
									 {
										 { 101, priceCurveSetting1 },
										 { 102, priceCurveSetting2Update }
									 };

			var testObjects = new UserPublicationsProviderTestObjectBuilder().WithCurrentUser(user)
																			 .WithPriceCurveSettings(priceCurveSettings)
																			 .Build();

			IList<int> results = null;

			var expected = new[] { 101, 102 };

			using (testObjects.UserPublicationsProvider.PublicationCurveIds.Subscribe(values => results = values))
			{
				// ACT
				testObjects.PriceCurveSettings.OnNext(update);

				// ASSERT
				Assert.That(results.SequenceEqual(expected));
			}
		}

		[Test]
		public void ShouldNotPublish_On_PriceCurveSettings_With_UserPublisherIsUnchanged()
		{
			var user = new UserBuilder().WithId(10).User();

			var priceCurveSetting1 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
																			 .WithPublisherId(10)
																			 .Build();

			var priceCurveSetting2 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																			 .WithPublisherId(11)
																			 .Build();

			var priceCurveSetting2Update = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																				   .WithPublisherId(12)
																				   .Build();

			var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
									 {
										 { 101, priceCurveSetting1 },
										 { 102, priceCurveSetting2 }
									 };

			var update = new Dictionary<int, PriceCurveSetting>
						 {
							 { 101, priceCurveSetting1 },
							 { 102, priceCurveSetting2Update }
						 };

			var testObjects = new UserPublicationsProviderTestObjectBuilder().WithCurrentUser(user)
																			 .WithPriceCurveSettings(priceCurveSettings)
																			 .Build();

			IList<int> results = null;

			using (testObjects.UserPublicationsProvider.PublicationCurveIds.Subscribe(values => results = values))
			{
				// ARRANGE
				results = null;

				// ACT
				testObjects.PriceCurveSettings.OnNext(update);

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}

		[Test]
		public void ShouldNotPublish_When_Disposed()
		{
			var user = new UserBuilder().WithId(10).User();

			var priceCurveSetting1 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
																			 .WithPublisherId(10)
																			 .Build();

			var priceCurveSetting2 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																			 .WithPublisherId(11)
																			 .Build();


			var priceCurveSetting2Update = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																				   .WithPublisherId(10)
																				   .Build();

			var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
									 {
										 { 101, priceCurveSetting1 },
										 { 102, priceCurveSetting2 }
									 };

			var update = new Dictionary<int, PriceCurveSetting>
						 {
							 { 101, priceCurveSetting1 },
							 { 102, priceCurveSetting2Update }
						 };

			var testObjects = new UserPublicationsProviderTestObjectBuilder().WithCurrentUser(user)
																			 .WithPriceCurveSettings(priceCurveSettings)
																			 .Build();

			IList<int> results = null;

			using (testObjects.UserPublicationsProvider.PublicationCurveIds.Subscribe(values => results = values))
			{
				// ARRANGE
				results = null;
				testObjects.UserPublicationsProvider.Dispose();

				// ACT
				testObjects.PriceCurveSettings.OnNext(update);

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var user = new UserBuilder().WithId(10).User();

			var priceCurveSetting1 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(101)
																			 .WithPublisherId(10)
																			 .Build();

			var priceCurveSetting2 = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																			 .WithPublisherId(11)
																			 .Build();


			var priceCurveSetting2Update = new PriceCurveSettingTestObjectBuilder().WithPriceCurveDefinitionId(102)
																				   .WithPublisherId(10)
																				   .Build();

			var priceCurveSettings = new Dictionary<int, PriceCurveSetting>
									 {
										 { 101, priceCurveSetting1 },
										 { 102, priceCurveSetting2 }
									 };

			var update = new Dictionary<int, PriceCurveSetting>
						 {
							 { 101, priceCurveSetting1 },
							 { 102, priceCurveSetting2Update }
						 };

			var testObjects = new UserPublicationsProviderTestObjectBuilder().WithCurrentUser(user)
																			 .WithPriceCurveSettings(priceCurveSettings)
																			 .Build();

			IList<int> results = null;

			using (testObjects.UserPublicationsProvider.PublicationCurveIds.Subscribe(values => results = values))
			{
				// ARRANGE
				results = null;
				testObjects.UserPublicationsProvider.Dispose();

				// ACT
				testObjects.UserPublicationsProvider.Dispose();
				testObjects.PriceCurveSettings.OnNext(update);

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}
	}
}
