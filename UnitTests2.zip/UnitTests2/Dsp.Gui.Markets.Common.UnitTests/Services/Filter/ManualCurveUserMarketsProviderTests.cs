﻿using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.UnitTests.Helpers;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	[TestFixture]
	public class ManualCurveUserMarketsProviderTests
	{
		[Test]
		public void ShouldConstructAndPublishUserMarket_On_PriceCurveUserMarket_With_MatchCurveId_And_UserUpdatePermissions()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, true) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, true) };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																		.WithProductCurveGroup(crude)
																		.WithCurveRegion(CurveRegion.Europe)
																		.WithProductPrecision(2)
																		.WithStatus(EntityStatus.Active)
																		.WithPendingCurveId(301)
																		.Build();

			var priceCurves = new[] { priceCurve };

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(linkedCurve.Id)
																			  .WithCurveId(101)
																			  .WithName("name")
																			  .Build();

			var manualCurves = new[] { manualCurve };

			var provider = new ManualCurveUserMarketsProvider();

			// ACT
			var results = provider.GetManualCurveUserMarkets(user, priceCurves, manualCurves);

			// ASSERT
			Assert.That(results.Count, Is.EqualTo(1));

			var userMarket = results[0];

			Assert.That(userMarket.LinkedCurve, Is.EqualTo(linkedCurve));
			Assert.That(userMarket.Name, Is.EqualTo("name"));
			Assert.That(userMarket.CurveGroup.Id, Is.EqualTo(crude.Id));
			Assert.That(userMarket.CurveRegion, Is.EqualTo(CurveRegion.Europe));
			Assert.That(userMarket.Precision, Is.EqualTo(2));
			Assert.That(userMarket.PriceCurveDetails().PriceCurveType, Is.EqualTo(PriceCurveType.Manual));
			Assert.That(userMarket.CanSelect, Is.False);
			Assert.That(userMarket.IsDraft, Is.False);
			Assert.That(userMarket.PriceCurveId, Is.EqualTo(101));
			Assert.That(userMarket.PendingCurveId, Is.EqualTo(301));
		}

		[Test]
		public void ShouldFilterUserMarkets_On_CurveGroupUpdatePermission()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var curveGroups = new[]
							  {
								  new AuthorisationCurveGroup(crude, true, true),
								  new AuthorisationCurveGroup(fuelOil, true, false)
							  };

			var curveRegions = new[]
							   {
								   new AuthorisationCurveRegion(CurveRegion.Europe, true, true)
							   };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve1.Id)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithProductPrecision(2)
																		 .Build();

			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																		 .WithProductCurveGroup(fuelOil)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithProductPrecision(2)
																		 .Build();
			var priceCurves = new[] {
										priceCurve1, priceCurve2
									};

			var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(linkedCurve2.Id)
																			   .WithCurveId(linkedCurve1.Id)
																			   .Build();

			var manualCurve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202)
																			   .WithCurveId(102)
																			   .Build();
			var manualCurves = new[] {
										 manualCurve1, manualCurve2
									 };

			var expected = new[]
						   {
							   new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2).Build()
						   };

			var provider = new ManualCurveUserMarketsProvider();

			// ACT
			var results = provider.GetManualCurveUserMarkets(user, priceCurves, manualCurves);

			// ASSERT
			Assert.That(results.SequenceEqual(expected, new UserMarketIdEqualityComparer()));
		}

		[Test]
		public void ShouldFilterUserMarkets_On_CurveRegionReadPermission()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			
			var curveGroups = new[]
							  {
								  new AuthorisationCurveGroup(crude, true, true)
							  };

			var curveRegions = new[]
							   {
								   new AuthorisationCurveRegion(CurveRegion.Europe, true, true),
								   new AuthorisationCurveRegion(CurveRegion.Asia, true, false)
							   };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve1.Id)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithProductPrecision(2)
																		 .Build();

			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Asia)
																		 .WithProductPrecision(2)
																		 .Build();
			var priceCurves = new[] {
										priceCurve1, priceCurve2
									};

			var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(linkedCurve2.Id)
																			   .WithCurveId(linkedCurve1.Id)
																			   .Build();

			var manualCurve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202)
																			   .WithCurveId(102)
																			   .Build();

			var manualCurves = new[]
							   {
								   manualCurve1, manualCurve2
							   };

			var expected = new[]
						   {
							   new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2).Build()
						   };

			var provider = new ManualCurveUserMarketsProvider();

			// ACT
			var results = provider.GetManualCurveUserMarkets(user, priceCurves, manualCurves);

			// ASSERT
			Assert.That(results.SequenceEqual(expected, new UserMarketIdEqualityComparer()));
		}

		[Test]
		public void ShouldFilterManualUserMarkets_On_DeletedStatus()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var curveGroups = new[]
							  {
								  new AuthorisationCurveGroup(crude, true, true),
								  new AuthorisationCurveGroup(fuelOil, true, false)
							  };

			var curveRegions = new[]
							   {
								   new AuthorisationCurveRegion(CurveRegion.Europe, true, true)
							   };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve1.Id)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithProductPrecision(2)
																		 .WithStatus(EntityStatus.Deleted)
																		 .Build();

			var priceCurves = new[] {
										priceCurve1
									};

			var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(linkedCurve2.Id)
																			   .WithCurveId(linkedCurve1.Id)
																			   .Build();

			var manualCurves = new[] { manualCurve1 };

			var provider = new ManualCurveUserMarketsProvider();

			// ACT
			var results = provider.GetManualCurveUserMarkets(user, priceCurves, manualCurves);

			// ASSERT
			Assert.That(results, Is.Empty);
		}

		[Test]
		public void ShouldPublishEmpty_On_NoMatchingManualCurves()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[]
							  {
								  new AuthorisationCurveGroup(crude, true, true)
							  };

			var curveRegions = new[]
							   {
								   new AuthorisationCurveRegion(CurveRegion.Europe, true, true)
							   };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve1.Id)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithProductPrecision(2)
																		 .Build();

			var priceCurves = new[] { priceCurve1 };

			var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202)
																			   .WithCurveId(99)
																			   .Build();

			var manualCurves = new[] { manualCurve1 };

			var provider = new ManualCurveUserMarketsProvider();

			// ACT
			var results = provider.GetManualCurveUserMarkets(user, priceCurves, manualCurves);

			// ASSERT
			Assert.That(results, Is.Empty);
		}

		[TestCase(EntityStatus.PendingNew)]
		[TestCase(EntityStatus.PendingUpdate)]
		public void ShouldSetIsDraftTrue_OnPriceCurveIdDraft_ActionedByUser(EntityStatus status)
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, true) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, true) };

			var user = new UserBuilder().WithId(10)
										.WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																		.WithProductCurveGroup(crude)
																		.WithCurveRegion(CurveRegion.Europe)
																		.WithStatus(status)
																		.WithActionedByUserId(10)
																		.Build();

			var priceCurves = new[] { priceCurve };

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(linkedCurve.Id)
																			  .WithCurveId(101)
																			  .WithName("name")
																			  .Build();

			var manualCurves = new[] { manualCurve };

			var provider = new ManualCurveUserMarketsProvider();

			// ACT
			var results = provider.GetManualCurveUserMarkets(user, priceCurves, manualCurves);

			// ASSERT
			var userMarket = results[0];

			Assert.That(userMarket.IsDraft, Is.True);
		}

		[TestCase(EntityStatus.PendingNew)]
		[TestCase(EntityStatus.PendingUpdate)]
		public void ShouldExcludeCurve_OnPriceCurveIdDraft_ActionedByOtherUser(EntityStatus status)
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, true) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, true) };

			var user = new UserBuilder().WithId(10)
										.WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(101)
																		.WithProductCurveGroup(crude)
																		.WithCurveRegion(CurveRegion.Europe)
																		.WithStatus(status)
																		.WithActionedByUserId(99)
																		.Build();

			var priceCurves = new[] { priceCurve };

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(linkedCurve.Id)
																			  .WithCurveId(101)
																			  .WithName("name")
																			  .Build();

			var manualCurves = new[] { manualCurve };

			var provider = new ManualCurveUserMarketsProvider();

			// ACT
			var results = provider.GetManualCurveUserMarkets(user, priceCurves, manualCurves);

			// ASSERT
			Assert.That(results, Is.Empty);
		}
	}
}
