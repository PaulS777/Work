﻿using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	internal interface IManualFilterChangedServiceTestObjects
	{
		ICurveGroupRegionsDataSource DataSource { get; }
		ManualFilterChangedService ManualFilterChangedService { get; }
	}

	[TestFixture]
	public class ManualFilterChangedServiceTests
	{
		private class ManualFilterChangedServiceTestObjectBuilder
		{
			private IEnumerable<MarketsFilterItem> _marketsFilterItems;

			public ManualFilterChangedServiceTestObjectBuilder WithMarketsFilterItems(IEnumerable<MarketsFilterItem> values)
			{
				_marketsFilterItems = values;
				return this;
			}

			public IManualFilterChangedServiceTestObjects Build()
			{
				var testObjects = new Mock<IManualFilterChangedServiceTestObjects>();

				var dataSource = new Mock<ICurveGroupRegionsDataSource>();

				dataSource.Setup(d => d.GetMarketsFilterItems())
						  .Returns(_marketsFilterItems);

				testObjects.SetupGet(o => o.DataSource)
						   .Returns(dataSource.Object);

				var service = new ManualFilterChangedService();

				testObjects.SetupGet(o => o.ManualFilterChangedService)
						   .Returns(service);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldNotPublishFilterItems_On_Subscribe()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2))
						{
							CanSelect = true,
							IsSelected = true
						};

			var items = new[] { item1 };

			var testObjects = new ManualFilterChangedServiceTestObjectBuilder().WithMarketsFilterItems(items)
																			   .Build();

			var filterChanged = testObjects.ManualFilterChangedService.FilterChanged(testObjects.DataSource);

			IList<MarketsFilterItemArgs> results = null;

			// ACT
			using (filterChanged.Subscribe(args => results = args))
			{
				// ASSERT
				Assert.That(results, Is.Null);
			}
		}

		[Test]
		public void ShouldPublishFilterItems_On_RaiseFilterChanged_With_DataSource_MarketsFilterItems()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2))
						{
							CanSelect = true,
							IsSelected = true
						};

			var items = new[] { item1 };

			var testObjects = new ManualFilterChangedServiceTestObjectBuilder().WithMarketsFilterItems(items)
																			   .Build();

			var filterChanged = testObjects.ManualFilterChangedService.FilterChanged(testObjects.DataSource);

			IList<MarketsFilterItemArgs> results = null;

			using (filterChanged.Subscribe(args => results = args))
			{
				// ACT
				testObjects.ManualFilterChangedService.RaiseFilterChanged();

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(1));

				Assert.That(results[0].Id, Is.EqualTo(linkedCurve1));
				Assert.That(results[0].CanSelect, Is.True);
				Assert.That(results[0].IsSelected, Is.True);
			}
		}

		[Test]
		public void ShouldNotPublishFilterItems_When_Disposed()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2))
						{
							CanSelect = true,
							IsSelected = true
						};

			var items = new[] { item1 };

			var testObjects = new ManualFilterChangedServiceTestObjectBuilder().WithMarketsFilterItems(items)
																			   .Build();

			var filterChanged = testObjects.ManualFilterChangedService.FilterChanged(testObjects.DataSource);

			IList<MarketsFilterItemArgs> results = null;

			using (filterChanged.Subscribe(args => results = args))
			{
				testObjects.ManualFilterChangedService.Dispose();

				// ACT
				testObjects.ManualFilterChangedService.RaiseFilterChanged();

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2))
						{
							CanSelect = true,
							IsSelected = true
						};

			var items = new[] { item1 };

			var testObjects = new ManualFilterChangedServiceTestObjectBuilder().WithMarketsFilterItems(items)
																			   .Build();

			var filterChanged = testObjects.ManualFilterChangedService.FilterChanged(testObjects.DataSource);

			IList<MarketsFilterItemArgs> results = null;

			using (filterChanged.Subscribe(args => results = args))
			{
				testObjects.ManualFilterChangedService.Dispose();

				// ACT
				testObjects.ManualFilterChangedService.Dispose();
				testObjects.ManualFilterChangedService.RaiseFilterChanged();

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}
	}
}
