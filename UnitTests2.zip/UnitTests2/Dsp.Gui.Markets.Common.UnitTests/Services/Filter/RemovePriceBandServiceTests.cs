﻿using System;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Services.Filter;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
    [TestFixture]
    public class RemovePriceBandServiceTests
    {
        [Test]
        public void ShouldPublishRemovePriceBand()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            LinkedCurve? result = null;

            var service = new RemovePriceBandService();

            using (service.OnRemovePriceBand.Subscribe(value => result = value))
            {
                // ACT
                service.RemovePriceBand(linkedCurve);

                // ASSERT
                Assert.That(result, Is.EqualTo(linkedCurve));
            }
        }

        [Test]
        public void ShouldThrowException_When_RemovePriceBand_With_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            Exception result = null;

            var service = new RemovePriceBandService();

            using (service.OnRemovePriceBand.Subscribe(_ => {}))
            {
                service.Dispose();

                try
                {
                    // ACT
                    service.RemovePriceBand(linkedCurve);
                }
                catch (Exception ex)
                {
                    result = ex;
                }
                
                // ASSERT
                Assert.That(result, Is.TypeOf<ObjectDisposedException>());
            }
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

            Exception result = null;

            var service = new RemovePriceBandService();

            using (service.OnRemovePriceBand.Subscribe(_ => { }))
            {
                service.Dispose();

                try
                {
                    // ACT
                    service.Dispose();
                    service.RemovePriceBand(linkedCurve);
                }
                catch (Exception ex)
                {
                    result = ex;
                }

                // ASSERT
                Assert.That(result, Is.TypeOf<ObjectDisposedException>());
            }
        }
    }
}
