﻿using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.UnitTests.Helpers;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Dsp.Gui.UnitTest.Helpers.Comparers;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	[TestFixture]
	public class PriceCurveUserMarketsProviderTests
	{
		[Test]
		public void ShouldGetUserMarket_With_StatusActive_And_ReadOnlyPermissions()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, false) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, false) };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve.Id)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithStatus(EntityStatus.Active)
																		 .WithName("name")
																		 .WithProductPrecision(2)
																		 .WithPendingCurveId(301)
																		 .Build();

			var priceCurves = new[] { priceCurve1 };

			var provider = new PriceCurveUserMarketsProvider();

			// ACT
			var results = provider.GetPriceCurveUserMarkets(user, priceCurves);

			// ASSERT
			Assert.That(results.Count == 1);

			var userMarket = results[0];

			Assert.That(userMarket.LinkedCurve, Is.EqualTo(linkedCurve));
			Assert.That(userMarket.Name, Is.EqualTo("name"));
			Assert.That(userMarket.CurveGroup.Id, Is.EqualTo(crude.Id));
			Assert.That(userMarket.CurveRegion, Is.EqualTo(CurveRegion.Europe));
			Assert.That(userMarket.Precision, Is.EqualTo(2));
			Assert.That(userMarket.PriceCurveDetails().PriceCurveType, Is.EqualTo(PriceCurveType.Live));
			Assert.That(userMarket.PriceCurveId, Is.Null);
			Assert.That(userMarket.CanSelect , Is.True);
			Assert.That(userMarket.PendingCurveId, Is.EqualTo(301));
		}

		[TestCase(EntityStatus.Deleted)]
		[TestCase(EntityStatus.PendingDelete)]
		[TestCase(EntityStatus.PendingNew)]
		[TestCase(EntityStatus.PendingUpdate)]
		public void ShouldFilterUserMarkets_OnEntityStatus_IgnoreNonActive(EntityStatus status)
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, false) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, false) };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve.Id)
																		 .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithStatus(status)
																		 .Build();
			var priceCurves = new[] { priceCurve1 };

			var provider = new PriceCurveUserMarketsProvider();

			// ACT
			var results = provider.GetPriceCurveUserMarkets(user, priceCurves);

			// ASSERT 
			Assert.That(results, Is.Empty);
		}

		[Test]
		public void ShouldFilterUserMarkets_On_CurveGroupReadPermission()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, false) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, false) };


			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve.Id)
																		 .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithStatus(EntityStatus.Active)
																		 .Build();

			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																		 .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .WithProductCurveGroup(fuelOil)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithStatus(EntityStatus.Active)
																		 .Build();

			var priceCurves = new[] { priceCurve1, priceCurve2 };

			var provider = new PriceCurveUserMarketsProvider();

			var expected = new[]
						   {
							   new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve).Build()
						   };

			// ACT
			var results = provider.GetPriceCurveUserMarkets(user, priceCurves);

			// ASSERT 
			Assert.That(results.SequenceEqual(expected, new UserMarketIdEqualityComparer()));
		}

		[Test]
		public void ShouldFilterUserMarkets_On_CurveRegionReadPermission()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, false) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, false) };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve.Id)
																		 .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Europe)
																		 .WithStatus(EntityStatus.Active)
																		 .Build();

			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																		 .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .WithProductCurveGroup(crude)
																		 .WithCurveRegion(CurveRegion.Asia)
																		 .WithStatus(EntityStatus.Active)
																		 .Build();

			var priceCurves = new[] { priceCurve1, priceCurve2 };

			var provider = new PriceCurveUserMarketsProvider();

			var expected = new[]
						   {
							   new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve).Build()
						   };

			// ACT
			var results = provider.GetPriceCurveUserMarkets(user, priceCurves);

			// ASSERT 
			Assert.That(results.SequenceEqual(expected, new UserMarketIdEqualityComparer()));
		}

		[TestCase(EntityStatus.PendingNew)]
		[TestCase(EntityStatus.PendingUpdate)]
		public void ShouldFilterUserMarkets_On_Draft_With_UserIsCurveActionedByUser(EntityStatus entityStatus)
		{
			var user = new UserBuilder().WithId(10).User();

			var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var draftCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve.Id)
																		.WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		.WithStatus(entityStatus)
																		.WithActionedByUserId(10)
																		.Build();

			var draftCurveOtherUser = new PriceCurveDefinitionTestObjectBuilder().WithId(102)
																				 .WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																				 .WithStatus(entityStatus)
																				 .WithActionedByUserId(99)
																				 .Build();

			var priceCurves = new[] { draftCurve, draftCurveOtherUser };

			var provider = new PriceCurveUserMarketsProvider();

			var expected = new[]
						   {
							   new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve).Build()
						   };

			// ACT
			var results = provider.GetPriceCurveUserMarkets(user, priceCurves);

			// ASSERT 
			Assert.That(results.SequenceEqual(expected, new UserMarketIdEqualityComparer()));
		}

		[TestCase(EntityStatus.PendingNew)]
		[TestCase(EntityStatus.PendingUpdate)]
		public void ShouldFilterUserMarkets_On_Draft_With_UserIsCurveApprover(EntityStatus entityStatus)
		{
			var adminApprover = new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 10, true);

			var user = new UserBuilder().WithId(10)
										.WithAuthorisationUserPermissions([adminApprover])
										.User();

			var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var draftCurve = new PriceCurveDefinitionTestObjectBuilder().WithId(linkedCurve.Id)
																		.WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		.WithStatus(entityStatus)
																		.WithActionedByUserId(99)
																		.Build();

			var priceCurves = new[] { draftCurve };

			var provider = new PriceCurveUserMarketsProvider();

			var expected = new[]
						   {
							   new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve).Build()
						   };

			// ACT
			var results = provider.GetPriceCurveUserMarkets(user, priceCurves);

			// ASSERT 
			Assert.That(results.SequenceEqual(expected, new UserMarketIdEqualityComparer()));
		}
	}
}
