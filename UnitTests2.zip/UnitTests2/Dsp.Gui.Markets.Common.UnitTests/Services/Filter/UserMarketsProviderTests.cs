﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.UnitTests.Helpers;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	internal interface IUserMarketsProviderTestObjects
	{
		ISubject<User> User { get; }
		ISubject<IList<PriceCurveDefinition>> PriceCurveDefinitions { get; }
		ISubject<IList<ManualCurveDefinition<MonthlyTenor>>> ManualCurveDefinitions { get; }
		IPriceCurveUserMarketsProvider PriceCurveUserMarketsProvider { get; }
		IManualCurveUserMarketsProvider ManualCurveUserMarketsProvider { get; }
		TestScheduler TestScheduler { get; }
		UserMarketsProvider UserMarketsProvider { get; }
	}

	[TestFixture]
	public class UserMarketsProviderTests
	{
		private class UserMarketsProviderTestObjectBuilder
		{
			private User _user;
			private IList<PriceCurveDefinition> _priceCurveDefinitions;
			private IList<ManualCurveDefinition<MonthlyTenor>> _manualCurveDefinitions;
			private Queue<IList<UserMarket>> _priceCurveUserMarkets;
			private Queue<IList<UserMarket>> _manualCurveUserMarkets;

			public UserMarketsProviderTestObjectBuilder WithUser(User value)
			{
				_user = value;
				return this;
			}

			public UserMarketsProviderTestObjectBuilder WithPriceCurveDefinitions(IList<PriceCurveDefinition> values)
			{
				_priceCurveDefinitions = values;
				return this;
			}

			public UserMarketsProviderTestObjectBuilder WithManualCurveDefinitions(IList<ManualCurveDefinition<MonthlyTenor>> values)
			{
				_manualCurveDefinitions = values;
				return this;
			}

			public UserMarketsProviderTestObjectBuilder WithPriceCurveUserMarkets(IList<UserMarket> values)
			{
				_priceCurveUserMarkets = new Queue<IList<UserMarket>>();
				_priceCurveUserMarkets.Enqueue(values);
				return this;
			}

			public UserMarketsProviderTestObjectBuilder WithPriceCurveUserMarketsNext(IList<UserMarket> values)
			{
				_priceCurveUserMarkets.Enqueue(values);
				return this;
			}

			public UserMarketsProviderTestObjectBuilder WithManualCurveUserMarkets(IList<UserMarket> values)
			{
				_manualCurveUserMarkets = new Queue<IList<UserMarket>>();
				_manualCurveUserMarkets.Enqueue(values);
				return this;
			}

			public UserMarketsProviderTestObjectBuilder WithManualCurveUserMarketsNext(IList<UserMarket> values)
			{
				_manualCurveUserMarkets.Enqueue(values);
				return this;
			}

			public IUserMarketsProviderTestObjects Build()
			{
				var testObjects = new Mock<IUserMarketsProviderTestObjects>();

				var user = new BehaviorSubject<User>(_user);

				testObjects.SetupGet(o => o.User)
						   .Returns(user);

				var priceCurveDefinitions = new BehaviorSubject<IList<PriceCurveDefinition>>(_priceCurveDefinitions);

				testObjects.SetupGet(o => o.PriceCurveDefinitions)
						   .Returns(priceCurveDefinitions);

				var manualCurveDefinitions = new BehaviorSubject<IList<ManualCurveDefinition<MonthlyTenor>>>(_manualCurveDefinitions);

				testObjects.SetupGet(o => o.ManualCurveDefinitions)
						   .Returns(manualCurveDefinitions);

				var curveControlService = new Mock<ICurveControlService>();

				curveControlService.SetupGet(c => c.CurrentUser)
								   .Returns(user);

				curveControlService.SetupGet(c => c.PriceCurveDefinitions)
								   .Returns(priceCurveDefinitions);

				curveControlService.SetupGet(c => c.ManualCurveDefinitions)
								   .Returns(manualCurveDefinitions);

				var priceCurveUserMarketsProvider = new Mock<IPriceCurveUserMarketsProvider>();

				priceCurveUserMarketsProvider.Setup(p => p.GetPriceCurveUserMarkets(It.IsAny<User>(), 
																					It.IsAny<IEnumerable<PriceCurveDefinition>>()))
											 .Returns(_priceCurveUserMarkets.Dequeue);

				testObjects.SetupGet(o => o.PriceCurveUserMarketsProvider)
						   .Returns(priceCurveUserMarketsProvider.Object);

				var manualCurveUserMarketsProvider = new Mock<IManualCurveUserMarketsProvider>();

				manualCurveUserMarketsProvider.Setup(p => p.GetManualCurveUserMarkets(It.IsAny<User>(),
																					  It.IsAny<IEnumerable<PriceCurveDefinition>>(),
																					  It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>()))
											  .Returns(_manualCurveUserMarkets.Dequeue);

				testObjects.SetupGet(o => o.ManualCurveUserMarketsProvider)
						   .Returns(manualCurveUserMarketsProvider.Object);

				var testScheduler = new TestScheduler();

				testObjects.SetupGet(o => o.TestScheduler)
						   .Returns(testScheduler);

				var schedulerProvider = new Mock<ISchedulerProvider>();

				schedulerProvider.SetupGet(p => p.TaskPool)
								 .Returns(testScheduler);

				schedulerProvider.SetupGet(p => p.Dispatcher)
								 .Returns(Scheduler.Immediate);

				var userMarketsProvider = new UserMarketsProvider(curveControlService.Object,
																  priceCurveUserMarketsProvider.Object,
																  manualCurveUserMarketsProvider.Object,
																  schedulerProvider.Object);

				testObjects.SetupGet(o => o.UserMarketsProvider)
						   .Returns(userMarketsProvider);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldGetUserMarkets_On_Connect_With_TimerInterval()
		{
			var user = new UserBuilder().User();

			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		.Build();

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var priceCurves = new[] { priceCurve };
			var manualCurves = new[] { manualCurve };

			var priceCurveUserMarket = new UserMarketTestObjectBuilder().Build();
			var manualCurveUserMarket = new UserMarketTestObjectBuilder().Build();

			var priceCurveUserMarkets = new[] { priceCurveUserMarket };
			var manualCurveUserMarkets = new[] { manualCurveUserMarket };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions(priceCurves)
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets(priceCurveUserMarkets)
																		.WithManualCurveUserMarkets(manualCurveUserMarkets)
																		.Build();

			// ACT
			testObjects.UserMarketsProvider.Connect();

			testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

			// ASSERT
			Mock.Get(testObjects.PriceCurveUserMarketsProvider)
				.Verify(p => p.GetPriceCurveUserMarkets(user, priceCurves), Times.Once);

			Mock.Get(testObjects.ManualCurveUserMarketsProvider)
				.Verify(p => p.GetManualCurveUserMarkets(user, priceCurves, manualCurves), Times.Once);
		}

		[Test]
		public void ShouldFilter_PriceCurves_On_PricingTenorGroupTypeMonthly()
		{
			var user = new UserBuilder().User();

			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Daily)
																		.Build();

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var priceCurves = new[] { priceCurve };
			var manualCurves = new[] { manualCurve };

			var priceCurveUserMarket = new UserMarketTestObjectBuilder().Build();
			var manualCurveUserMarket = new UserMarketTestObjectBuilder().Build();

			var priceCurveUserMarkets = new[] { priceCurveUserMarket };
			var manualCurveUserMarkets = new[] { manualCurveUserMarket };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions(priceCurves)
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets(priceCurveUserMarkets)
																		.WithManualCurveUserMarkets(manualCurveUserMarkets)
																		.Build();
			// ACT
			testObjects.UserMarketsProvider.Connect();

			testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

			// ASSERT
			Mock.Get(testObjects.PriceCurveUserMarketsProvider)
				.Verify(p => p.GetPriceCurveUserMarkets(user, It.Is<IList<PriceCurveDefinition>>(c => c.Count == 0)), Times.Once);

			Mock.Get(testObjects.ManualCurveUserMarketsProvider)
				.Verify(p => p.GetManualCurveUserMarkets(user, It.Is<IList<PriceCurveDefinition>>(c => c.Count == 0), manualCurves), Times.Once);
		}

		[Test]
		public void ShouldPublish_UserMarkets_On_TimerInterval_When_Subscribed()
		{
			var user = new UserBuilder().User();

			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		.Build();

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var priceCurves = new[] { priceCurve };
			var manualCurves = new[] { manualCurve };

			var priceCurveUserMarket = new UserMarketTestObjectBuilder().Build();
			var manualCurveUserMarket = new UserMarketTestObjectBuilder().Build();

			var priceCurveUserMarkets = new[] { priceCurveUserMarket };
			var manualCurveUserMarkets = new[] { manualCurveUserMarket };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions(priceCurves)
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets(priceCurveUserMarkets)
																		.WithManualCurveUserMarkets(manualCurveUserMarkets)
																		.Build();
			// ARRANGE
			testObjects.UserMarketsProvider.Connect();

			IList<UserMarket> result = null;

			using (testObjects.UserMarketsProvider.UserMarkets.Subscribe(values => result = values))
			{
				// ACT
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(2));

				Assert.That(result[0], Is.SameAs(priceCurveUserMarket));
				Assert.That(result[1], Is.SameAs(manualCurveUserMarket));
			}
		}

		[Test]
		public void ShouldBufferCurveUpdates()
		{
			var user = new UserBuilder().User();

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		.Build();

			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .Build();

			var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();
			var manualCurve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var priceCurves = new[] { priceCurve1 };
			var manualCurves = new[] { manualCurve1 };

			var priceCurveUpdates = new[] { priceCurve1, priceCurve2 };
			var manualCurveUpdates = new[] { manualCurve1, manualCurve2 };

			var priceCurveUserMarket1 = new UserMarketTestObjectBuilder().Build();
			var priceCurveUserMarket2 = new UserMarketTestObjectBuilder().Build();

			var manualCurveUserMarket1 = new UserMarketTestObjectBuilder().Build();
			var manualCurveUserMarket2 = new UserMarketTestObjectBuilder().Build();

			var priceCurveUserMarkets = new[] { priceCurveUserMarket1 };
			var manualCurveUserMarkets = new[] { manualCurveUserMarket1 };

			var priceCurveUserMarketsNext = new[] { priceCurveUserMarket1, priceCurveUserMarket2 };
			var manualCurveUserMarketsNext = new[] { manualCurveUserMarket1, manualCurveUserMarket2 };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions(priceCurves)
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets(priceCurveUserMarkets)
																		.WithManualCurveUserMarkets(manualCurveUserMarkets)
																		.WithPriceCurveUserMarketsNext(priceCurveUserMarketsNext)
																		.WithManualCurveUserMarketsNext(manualCurveUserMarketsNext)
																		.Build();
			
			testObjects.UserMarketsProvider.Connect();

			IList<UserMarket> result = null;

			using (testObjects.UserMarketsProvider.UserMarkets.Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				testObjects.PriceCurveDefinitions.OnNext(priceCurveUpdates);
				testObjects.ManualCurveDefinitions.OnNext(manualCurveUpdates);

				// ACT
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(4));

				Assert.That(result[0], Is.SameAs(priceCurveUserMarket1));
				Assert.That(result[1], Is.SameAs(priceCurveUserMarket2));
				Assert.That(result[2], Is.SameAs(manualCurveUserMarket1));
				Assert.That(result[3], Is.SameAs(manualCurveUserMarket2));

				Mock.Get(testObjects.PriceCurveUserMarketsProvider)
					.Verify(p => p.GetPriceCurveUserMarkets(user, priceCurveUpdates), Times.Once);

				Mock.Get(testObjects.ManualCurveUserMarketsProvider)
					.Verify(p => p.GetManualCurveUserMarkets(user, priceCurveUpdates, manualCurveUpdates), Times.Once);
			}
		}

		#region User Permissions Update

		[Test]
		public void ShouldPublishUserMarkets_On_UserPermissionsChanged()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();
			var fuelOil = new CurveGroupTestObjectBuilder().FuelOil();

			var curveGroups1 = new[] { new AuthorisationCurveGroup(crude, true, true) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, true) };

			var curveGroups2 = new[]
							   {
								   new AuthorisationCurveGroup(crude, true, true),
								   new AuthorisationCurveGroup(fuelOil, true, true)
							   };

			var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups1)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var update = new UserBuilder().WithAuthorizationCurveGroups(curveGroups2)
										  .WithAuthorizationCurveRegions(curveRegions)
										  .User();

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .WithProductCurveGroup(crude)
																		 .Build();

			var priceCurve2 = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .WithProductCurveGroup(fuelOil)
																		 .Build();

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var priceCurves = new[] { priceCurve1, priceCurve2 };
			var manualCurves = new[] { manualCurve };

			var priceCurveUserMarket1 = new UserMarketTestObjectBuilder().WithCurveGroup(crude).Build();
			var priceCurveUserMarket2 = new UserMarketTestObjectBuilder().WithCurveGroup(fuelOil).Build();

			var priceCurveUserMarkets = new[] { priceCurveUserMarket1 };
			var priceCurveUserMarketsNext = new[] { priceCurveUserMarket1, priceCurveUserMarket2 };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions(priceCurves)
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets(priceCurveUserMarkets)
																		.WithManualCurveUserMarkets([])
																		.WithPriceCurveUserMarketsNext(priceCurveUserMarketsNext)
																		.WithManualCurveUserMarketsNext([])
																		.Build();
			
			testObjects.UserMarketsProvider.Connect();

			IList<UserMarket> result = null;

			using (testObjects.UserMarketsProvider.UserMarkets.Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				Mock.Get(testObjects.PriceCurveUserMarketsProvider).Invocations.Clear();
				Mock.Get(testObjects.ManualCurveUserMarketsProvider).Invocations.Clear();
				result = null;

				// ACT
				testObjects.User.OnNext(update);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Mock.Get(testObjects.PriceCurveUserMarketsProvider)
					.Verify(p => p.GetPriceCurveUserMarkets(update, priceCurves), Times.Once);

				Mock.Get(testObjects.ManualCurveUserMarketsProvider)
					.Verify(p => p.GetManualCurveUserMarkets(update, priceCurves, manualCurves), Times.Once);

				Assert.That(result, Is.Not.Null);
				Assert.That(result.Count, Is.EqualTo(2));
			}
		}

		[Test]
		public void ShouldNotPublishUserMarkets_On_UserUpdate_With_PermissionsNotChanged()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, true) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, true) };


			var user = new UserBuilder().WithName("name")
										.WithAuthorizationCurveGroups(curveGroups)
										.WithAuthorizationCurveRegions(curveRegions)
										.User();

			var update = new UserBuilder().WithName("name-2")
										  .WithAuthorizationCurveGroups(curveGroups)
										  .WithAuthorizationCurveRegions(curveRegions)
										  .User();

			var priceCurve1 = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		 .WithProductCurveGroup(crude)
																		 .Build();

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var priceCurves = new[] { priceCurve1 };
			var manualCurves = new[] { manualCurve };

			var priceCurveUserMarket = new UserMarketTestObjectBuilder().WithCurveGroup(crude).Build();

			var priceCurveUserMarkets = new[] { priceCurveUserMarket };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions(priceCurves)
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets(priceCurveUserMarkets)
																		.WithManualCurveUserMarkets([])
																		.Build();

			testObjects.UserMarketsProvider.Connect();

			IList<UserMarket> result = null;

			using (testObjects.UserMarketsProvider.UserMarkets.Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				Mock.Get(testObjects.PriceCurveUserMarketsProvider).Invocations.Clear();
				Mock.Get(testObjects.ManualCurveUserMarketsProvider).Invocations.Clear();
				result = null;

				// ACT
				testObjects.User.OnNext(update);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Mock.Get(testObjects.PriceCurveUserMarketsProvider)
					.Verify(p => p.GetPriceCurveUserMarkets(update, priceCurves), Times.Never);

				Mock.Get(testObjects.ManualCurveUserMarketsProvider)
					.Verify(p => p.GetManualCurveUserMarkets(update, priceCurves, manualCurves), Times.Never);

				Assert.That(result, Is.Null);
			}
		}

		#endregion

		#region ManualCurves

		[Test]
		public void ShouldPublishOnManualCurveAdded()
		{
			var user = new UserBuilder().User();

			var manualCurve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();
			var manualCurve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var manualCurves = new[] { manualCurve1 };
			var manualCurveUpdates = new[] { manualCurve1, manualCurve2 };

			var manualCurveUserMarket1 = new UserMarketTestObjectBuilder().Build();
			var manualCurveUserMarket2 = new UserMarketTestObjectBuilder().Build();

			var manualCurveUserMarkets = new[] { manualCurveUserMarket1 };

			var manualCurveUserMarketsNext = new[] { manualCurveUserMarket1, manualCurveUserMarket2 };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions([])
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets([])
																		.WithPriceCurveUserMarketsNext([])
																		.WithManualCurveUserMarkets(manualCurveUserMarkets)
																		.WithManualCurveUserMarketsNext(manualCurveUserMarketsNext)
																		.Build();

			testObjects.UserMarketsProvider.Connect();

			IList<UserMarket> result = null;

			using (testObjects.UserMarketsProvider.UserMarkets.Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ACT
				testObjects.ManualCurveDefinitions.OnNext(manualCurveUpdates);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result.Count, Is.EqualTo(2));

				Assert.That(result[0], Is.SameAs(manualCurveUserMarket1));
				Assert.That(result[1], Is.SameAs(manualCurveUserMarket2));

				Mock.Get(testObjects.ManualCurveUserMarketsProvider)
					.Verify(p => p.GetManualCurveUserMarkets(user, It.IsAny<IEnumerable<PriceCurveDefinition>>(), manualCurveUpdates));
			}
		}

		[Test]
		public void ShouldNotPublishOnManualCurveOverridesChanged()
		{
			var user = new UserBuilder().User();

			// ARRANGE
			var tenor = new MonthlyTenor(2018, 1);

			var curvePoints1 = new List<CurvePoint<MonthlyTenor>> { new(tenor, 1.1) };
			var curvePoints2= new List<CurvePoint<MonthlyTenor>> { new(tenor, 1.2) };

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithOverrides(curvePoints1).Build();
			var manualCurveUpdate = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithOverrides(curvePoints2).Build();

			var manualCurves = new[] { manualCurve };
			var update = new[] { manualCurveUpdate };

			var manualCurveUserMarket1 = new UserMarketTestObjectBuilder().Build();

			var manualCurveUserMarkets = new[] { manualCurveUserMarket1 };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions([])
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets([])
																		.WithManualCurveUserMarkets(manualCurveUserMarkets)
																		.Build();

			testObjects.UserMarketsProvider.Connect();

			IList<UserMarket> result = null;

			using (testObjects.UserMarketsProvider.UserMarkets.Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				result = null;
				Mock.Get(testObjects.ManualCurveUserMarketsProvider).Invocations.Clear();

				// ACT
				testObjects.ManualCurveDefinitions.OnNext(update);
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result, Is.Null);

				Mock.Get(testObjects.ManualCurveUserMarketsProvider)
					.Verify(p => p.GetManualCurveUserMarkets(user, 
															 It.IsAny<IEnumerable<PriceCurveDefinition>>(), 
															 It.IsAny<IList<ManualCurveDefinition<MonthlyTenor>>>()), Times.Never);
			}
		}

		#endregion

		#region Dispose

		[Test]
		public void ShouldNotPublish_When_Disposed()
		{
			var user = new UserBuilder().User();

			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		.Build();

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var priceCurves = new[] { priceCurve };
			var manualCurves = new[] { manualCurve };

			var priceCurveUserMarket = new UserMarketTestObjectBuilder().Build();
			var manualCurveUserMarket = new UserMarketTestObjectBuilder().Build();

			var priceCurveUserMarkets = new[] { priceCurveUserMarket };
			var manualCurveUserMarkets = new[] { manualCurveUserMarket };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions(priceCurves)
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets(priceCurveUserMarkets)
																		.WithManualCurveUserMarkets(manualCurveUserMarkets)
																		.Build();
			// ARRANGE
			testObjects.UserMarketsProvider.Connect();

			IList<UserMarket> result = null;

			using (testObjects.UserMarketsProvider.UserMarkets.Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.UserMarketsProvider.Dispose();

				// ACT
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result, Is.Null);
			}
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var user = new UserBuilder().User();

			var priceCurve = new PriceCurveDefinitionTestObjectBuilder().WithProductPricingTenorGroupType(PricingTenorGroupType.Monthly)
																		.Build();

			var manualCurve = new ManualCurveDefinitionBuilder<MonthlyTenor>().Build();

			var priceCurves = new[] { priceCurve };
			var manualCurves = new[] { manualCurve };

			var priceCurveUserMarket = new UserMarketTestObjectBuilder().Build();
			var manualCurveUserMarket = new UserMarketTestObjectBuilder().Build();

			var priceCurveUserMarkets = new[] { priceCurveUserMarket };
			var manualCurveUserMarkets = new[] { manualCurveUserMarket };

			var testObjects = new UserMarketsProviderTestObjectBuilder().WithUser(user)
																		.WithPriceCurveDefinitions(priceCurves)
																		.WithManualCurveDefinitions(manualCurves)
																		.WithPriceCurveUserMarkets(priceCurveUserMarkets)
																		.WithManualCurveUserMarkets(manualCurveUserMarkets)
																		.Build();
			// ARRANGE
			testObjects.UserMarketsProvider.Connect();

			IList<UserMarket> result = null;

			using (testObjects.UserMarketsProvider.UserMarkets.Subscribe(values => result = values))
			{
				// ARRANGE
				testObjects.UserMarketsProvider.Dispose();

				// ACT
				testObjects.UserMarketsProvider.Dispose();
				testObjects.TestScheduler.AdvanceBy(TimeSpan.FromMilliseconds(1010).Ticks);

				// ASSERT
				Assert.That(result, Is.Null);
			}
		}

		#endregion
	}
}
