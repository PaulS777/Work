﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.UnitTests.Helpers;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	internal interface IUserMarketsUpdateReasonServiceTestObjects
	{
		IUserMarketsWithSettingsService UserMarketsWithSettingsService { get; }
		ISubject<IList<UserMarket>> UserMarkets { get; }
		UserMarketsUpdateReasonService IUserMarketsUpdateReasonService { get; }
	}

	[TestFixture]
	public class UserMarketsUpdateReasonServiceTests
	{
		private class UserMarketsUpdateReasonServiceTestObjectBuilder
		{
			private IList<UserMarket> _userMarkets;

			public UserMarketsUpdateReasonServiceTestObjectBuilder WithUserMarkets(IList<UserMarket> values)
			{
				_userMarkets = values;
				return this;
			}

			public IUserMarketsUpdateReasonServiceTestObjects Build()
			{
				var testObjects = new Mock<IUserMarketsUpdateReasonServiceTestObjects>();

				var userMarkets = new BehaviorSubject<IList<UserMarket>>(_userMarkets);

				testObjects.SetupGet(o => o.UserMarkets)
						   .Returns(userMarkets);

				var userMarketsWithSettingsService = new Mock<IUserMarketsWithSettingsService>();

				userMarketsWithSettingsService.SetupGet(p => p.UserMarkets)
											  .Returns(userMarkets);

				testObjects.SetupGet(o => o.UserMarketsWithSettingsService)
						   .Returns(userMarketsWithSettingsService.Object);

				var marketsUpdateReasonService = new UserMarketsUpdateReasonService(TestMocks.GetLoggerFactory().Object);

				testObjects.SetupGet(o => o.IUserMarketsUpdateReasonService)
						   .Returns(marketsUpdateReasonService);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldPublishSelectedMarkets_With_ReasonLoaded_On_UserMarketsLoaded()
		{
			var details1 = new PriceCurveDetails(PriceCurveType.Live, new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 2);

			var userMarket1 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details1)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var details2 = new PriceCurveDetails(PriceCurveType.Live, new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 2);

			var userMarket2 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details2)
															   .WithCanSelect(true)
															   .WithIsSelected(false)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				// ACT
				testObjects.UserMarkets.OnNext(userMarkets);

				// ASSERT
				Assert.That(result.Reason, Is.EqualTo(UserMarketsFilterUpdateReason.MarketsLoaded));
				Assert.That(result.UserMarkets.Count, Is.EqualTo(1));
			}
		}

		[Test]
		public void ShouldPublish_With_ReasonSelectedCurveDefinitionRemoved_On_UserMarkets_MissingPreviousSelected()
		{
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			// ARRANGE - Selected
			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var update = new[] { userMarket1 };

			var expected = new[] { userMarket1 };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().WithUserMarkets(userMarkets).Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				// ACT
				testObjects.UserMarkets.OnNext(update);

				// ASSERT
				Assert.That(result.Reason, Is.EqualTo(UserMarketsFilterUpdateReason.SelectedCurveDefinitionRemoved));
				Assert.That(result.UserMarkets.SequenceEqual(expected));
			}
		}

		#region Manual Filter

		[Test]
		public void ShouldPublish_With_ReasonManualSelection_On_UserMarkets_WithAnySelectedChangedToTrue()
		{
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithCanSelect(true)
															   .WithIsSelected(false)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var update1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
														   .WithCanSelect(true)
														   .WithIsSelected(true)
														   .Build();

			var update2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
														   .WithCanSelect(true)
														   .WithIsSelected(false)
														   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var updates = new[] { update1, update2 };

			var expected = new[] { update1 };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().WithUserMarkets(userMarkets).Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				// ACT
				testObjects.UserMarkets.OnNext(updates);

				// ASSERT
				Assert.That(result.Reason, Is.EqualTo(UserMarketsFilterUpdateReason.ManualSelection));
				Assert.That(result.UserMarkets.SequenceEqual(expected));
			}
		}

		[Test]
		public void ShouldPublish_With_ReasonManualSelectionRemovedCurvesOnly_On_UserMarkets_WithAllSelectedChangedToFalse()
		{
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var update1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
														   .WithCanSelect(true)
														   .WithIsSelected(false)
														   .Build();

			var update2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
														   .WithCanSelect(true)
														   .WithIsSelected(true)
														   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var updates = new[] { update1, update2 };

			var expected = new[] { update2 };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().WithUserMarkets(userMarkets).Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				// ACT
				testObjects.UserMarkets.OnNext(updates);

				// ASSERT
				Assert.That(result.Reason, Is.EqualTo(UserMarketsFilterUpdateReason.ManualSelectionRemovedCurvesOnly));
				Assert.That(result.UserMarkets.SequenceEqual(expected));
			}
		}

		#endregion

		#region Puiblication Settings

		[Test]
		public void ShouldNotPublish_On_UserMarkets_MissingPreviousNotSelected()
		{
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			// ARRANGE - Not Selected
			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithCanSelect(true)
															   .WithIsSelected(false)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var update = new[] { userMarket1 };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().WithUserMarkets(userMarkets).Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				result = null;

				// ACT
				testObjects.UserMarkets.OnNext(update);

				// ASSERT
				Assert.That(result, Is.Null);
			}
		}

		[Test]
		public void ShouldPublishUserMarketAdded_With_ReasonPublicationSettings_On_UserMarkets_With_IsSelected_And_SelectEnabled()
		{
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithCanSelect(false)
															   .WithIsSelected(true)
															   .Build();

			var update = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
														  .WithCanSelect(true)
														  .WithIsSelected(true)
														  .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var updates = new[] { userMarket1, update };

			var expected = new[] { userMarket1, update };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().WithUserMarkets(userMarkets).Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				// ACT
				testObjects.UserMarkets.OnNext(updates);

				// ASSERT
				Assert.That(result.Reason, Is.EqualTo(UserMarketsFilterUpdateReason.PublicationSettings));
				Assert.That(result.UserMarkets.SequenceEqual(expected));
			}
		}

		[Test]
		public void ShouldPublishUserMarketRemoved_With_ReasonPublicationSettings_On_UserMarkets_With_IsSelected_And_SelectDisabled()
		{
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var update = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
														  .WithCanSelect(false)
														  .WithIsSelected(true)
														  .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var updates = new[] { userMarket1, update };

			var expected = new[] { userMarket1 };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().WithUserMarkets(userMarkets).Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				// ACT
				testObjects.UserMarkets.OnNext(updates);

				// ASSERT
				Assert.That(result.Reason, Is.EqualTo(UserMarketsFilterUpdateReason.PublicationSettings));
				Assert.That(result.UserMarkets.SequenceEqual(expected));
			}
		}

		#endregion

		#region Dispose

		[Test]
		public void ShouldNotPublish_When_Disposed()
		{
			var details1 = new PriceCurveDetails(PriceCurveType.Live, new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 2);

			var userMarket1 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details1)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var details2 = new PriceCurveDetails(PriceCurveType.Live, new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 2);

			var userMarket2 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details2)
															   .WithCanSelect(true)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var userMarket1Update = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details1)
																	 .WithCanSelect(true)
																	 .Build();

			var userMarket2Update = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details2)
																	 .WithIsSelected(true)
																	 .Build();

			var userMarketsUpdate = new[] { userMarket1Update, userMarket2Update };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().WithUserMarkets(userMarkets)
																				   .Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				result = null;

				testObjects.IUserMarketsUpdateReasonService.Dispose();

				// ACT
				testObjects.UserMarkets.OnNext(userMarketsUpdate);

				// ASSERT
				Assert.IsNull(result);
			}
		}

		[Test]
		public void ShouldNotDispose_When_Disposed()
		{
			var details1 = new PriceCurveDetails(PriceCurveType.Live, new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 2);

			var userMarket1 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details1)
															   .WithCanSelect(true)
															   .WithIsSelected(true)
															   .Build();

			var details2 = new PriceCurveDetails(PriceCurveType.Live, new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve), 2);

			var userMarket2 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details2)
															   .WithCanSelect(true)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var userMarket1Update = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details1)
																	 .WithCanSelect(true)
																	 .Build();

			var userMarket2Update = new UserMarketTestObjectBuilder().WithPriceCurveDetails(details2)
																	 .WithIsSelected(true)
																	 .Build();

			var userMarketsUpdate = new[] { userMarket1Update, userMarket2Update };

			var testObjects = new UserMarketsUpdateReasonServiceTestObjectBuilder().WithUserMarkets(userMarkets)
																				   .Build();

			UserMarketsFilterArgs result = null;

			testObjects.IUserMarketsUpdateReasonService.Initialize(testObjects.UserMarketsWithSettingsService);

			using (testObjects.IUserMarketsUpdateReasonService.UserMarketsFilter.Subscribe(args => result = args))
			{
				result = null;

				testObjects.IUserMarketsUpdateReasonService.Dispose();

				// ACT
				testObjects.IUserMarketsUpdateReasonService.Dispose();
				testObjects.UserMarkets.OnNext(userMarketsUpdate);

				// ASSERT
				Assert.IsNull(result);
			}
		}

		#endregion
	}
}
