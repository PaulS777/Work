﻿using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Markets.Common.Controllers;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.UnitTests.Helpers;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
    public interface ICurveGroupRegionCollectionBuilderTestObjects
    {
        CurveGroupRegionCollectionBuilder CurveGroupRegionCollectionBuilder { get; }
	}

	[TestFixture]
    public class CurveGroupRegionCollectionBuilderTests
    {
        private class CurveGroupRegionCollectionBuilderTestObjectBuilder
        {

            public ICurveGroupRegionCollectionBuilderTestObjects Build()
            {
                var testObjects = new Mock<ICurveGroupRegionCollectionBuilderTestObjects>();

                var factory = new Mock<IServiceFactory<ICurveRegionFilterItemCollectionController>>();

                factory.Setup(f => f.Create())
                       .Returns(GetController);

                var builder = new CurveGroupRegionCollectionBuilder
                              {
                                  ServiceFactory = factory.Object
                              };

                testObjects.SetupGet(o => o.CurveGroupRegionCollectionBuilder)
                           .Returns(builder);

				return testObjects.Object;
            }

            private static ICurveRegionFilterItemCollectionController GetController()
            {
                var controller = new Mock<ICurveRegionFilterItemCollectionController>();

                var regionCollection = new CurveRegionFilterItemCollection();

                controller.SetupGet(c => c.CurveRegionFilterItemCollection)
                          .Returns(regionCollection);

                return controller.Object;
            }
		}

        public CurveGroup Crude() => new CurveGroupTestObjectBuilder().Crude();
        public CurveGroup FuelOil() => new CurveGroupTestObjectBuilder().FuelOil();
        public CurveGroup TestCurves() => new CurveGroupTestObjectBuilder().TestCurves();

		[Test]
		public void ShouldReturnCollection_GroupedBy_CurveGroups_And_Regions_OrderedBy_Region()
		{
			var userMarket1 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																										   new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
																										   2))
															  .WithCurveGroup(Crude())
															  .WithCurveRegion(CurveRegion.Europe)
															  .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																											new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .Build();

			var userMarket3 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																											new LinkedCurve(103, PriceCurveDefinitionType.PriceCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Asia)
															   .Build();

			var userMarket4 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																											new LinkedCurve(104, PriceCurveDefinitionType.PriceCurve),
																											2))
															   .WithCurveGroup(FuelOil())
															   .WithCurveRegion(CurveRegion.Europe)
															   .Build();


			var userMarkets = new List<UserMarket>
			{
				userMarket1, userMarket2, userMarket3, userMarket4
			};

			var testObjects = new CurveGroupRegionCollectionBuilderTestObjectBuilder().Build();

			// ACT
			var result = testObjects.CurveGroupRegionCollectionBuilder.GetCurveGroupRegions(userMarkets);

			// ASSERT
			Assert.That(result.Count, Is.EqualTo(2));

			// ASSERT - CRUDE
			Assert.That(result[0].GroupHeader, Is.EqualTo(CurveGroupNames.Crude));
			Assert.That(result[0].CurveGroup.Id, Is.EqualTo(Crude().Id));

			Assert.That(result[0].CurveRegionFilters.Count, Is.EqualTo(2));

			Assert.That(result[0].CurveRegionFilters[0].RegionHeader.Region, Is.EqualTo(CurveRegion.Europe));
			Assert.That(result[0].CurveRegionFilters[0].Items.Count, Is.EqualTo(2));

			Assert.That(result[0].CurveRegionFilters[1].RegionHeader.Region, Is.EqualTo(CurveRegion.Asia));
			Assert.That(result[0].CurveRegionFilters[1].Items.Count, Is.EqualTo(1));

			// ASSERT - FUEL OIL
			Assert.That(result[1].GroupHeader, Is.EqualTo(CurveGroupNames.FuelOil));
			Assert.That(result[1].CurveGroup.Id, Is.EqualTo(FuelOil().Id));

			Assert.That(result[1].CurveRegionFilters.Count, Is.EqualTo(1));

			Assert.That(result[1].CurveRegionFilters[0].RegionHeader.Region, Is.EqualTo(CurveRegion.Europe));
			Assert.That(result[1].CurveRegionFilters[0].Items.Count, Is.EqualTo(1));
		}

        [Test]
        public void ShouldSetDetails_Name_And_Selected_With_LivePriceCurveType()
        {
			var userMarket = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																										   new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
																										   2))
															  .WithCurveGroup(Crude())
															  .WithCurveRegion(CurveRegion.Europe)
															  .WithName("CURVE")
															  .Build();

			userMarket.CanSelect = true;
            userMarket.IsSelected = true;

            var testObjects = new CurveGroupRegionCollectionBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.CurveGroupRegionCollectionBuilder.GetCurveGroupRegions([userMarket]);

            // ASSERT
            var item = result[0].CurveRegionFilters[0].Items[0];

			Assert.That(item.Name, Is.EqualTo("CURVE"));
            Assert.That(item.IsSelected, Is.True);
            Assert.That(item.OriginalIsSelected, Is.True);
            Assert.That(item.CanSelect, Is.True);
            Assert.That(item.IsManual, Is.False);
		}

        [Test]
        public void ShouldDisplayTestCurves_LastItem()
        {
			var userMarket1 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																											new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve),
																											2))
															   .WithCurveGroup(TestCurves())
															   .WithCurveRegion(CurveRegion.Europe)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																											new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .Build();

            var userMarkets = new[] { userMarket2, userMarket1};

            var testObjects = new CurveGroupRegionCollectionBuilderTestObjectBuilder().Build();

            // ACT
            var result = testObjects.CurveGroupRegionCollectionBuilder.GetCurveGroupRegions(userMarkets);

            // ASSERT
            Assert.That(result[1].CurveGroup.Id, Is.EqualTo(TestCurves().Id));
		}

		[Test]
		public void ShouldOrderItems_By_CurveName_Type_And_Draft()
		{
			var userMarket1 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live, 
																											new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve), 
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .WithName("AAA_CURVE")
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																											new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .WithName("BBB_CURVE").WithPendingCurveId(301)
															   .Build();

			var userMarket3 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Manual,
																											new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .WithName("BBB_CURVE_MANUAL")
															   .WithPriceCurveId(102) // add
															   .WithPendingCurveId(302)
															   .Build();

			var userMarket4 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																											new LinkedCurve(301, PriceCurveDefinitionType.PriceCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .WithName("BBB_CURVE_DRAFT")
															   .WithIsDraft(true)
															   .Build();

			var userMarket5 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Manual,
																											new LinkedCurve(302, PriceCurveDefinitionType.DerivedCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .WithName("BBB_CURVE_MANUAL_DRAFT")
															   .WithPriceCurveId(301) //
															   .WithIsDraft(true)
															   .Build();

			var userMarket6 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Live,
																											new LinkedCurve(103, PriceCurveDefinitionType.PriceCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .WithName("CCC_CURVE")
															
															   .Build();

			var userMarket7 = new UserMarketTestObjectBuilder().WithPriceCurveDetails(new PriceCurveDetails(PriceCurveType.Manual,
																											new LinkedCurve(203, PriceCurveDefinitionType.DerivedCurve),
																											2))
															   .WithCurveGroup(Crude())
															   .WithCurveRegion(CurveRegion.Europe)
															   .WithName("CCC_CURVE_MANUAL")
															   .WithPriceCurveId(103)
															   .Build();

			var userMarkets = new[] {userMarket7, userMarket6, userMarket5, userMarket4, userMarket3, userMarket2, userMarket1 };

			var testObjects = new CurveGroupRegionCollectionBuilderTestObjectBuilder().Build();

			// ACT
			var result = testObjects.CurveGroupRegionCollectionBuilder.GetCurveGroupRegions(userMarkets);

			// ASSERT
			Assert.That(result[0].CurveRegionFilters[0].Items[0].Name, Is.EqualTo("AAA_CURVE"));
			Assert.That(result[0].CurveRegionFilters[0].Items[1].Name, Is.EqualTo("BBB_CURVE"));
			Assert.That(result[0].CurveRegionFilters[0].Items[2].Name, Is.EqualTo("BBB_CURVE_MANUAL"));
			Assert.That(result[0].CurveRegionFilters[0].Items[3].Name, Is.EqualTo("BBB_CURVE_DRAFT"));
			Assert.That(result[0].CurveRegionFilters[0].Items[3].Definition().IsDraft, Is.True);
			Assert.That(result[0].CurveRegionFilters[0].Items[4].Name, Is.EqualTo("BBB_CURVE_MANUAL_DRAFT"));
			Assert.That(result[0].CurveRegionFilters[0].Items[4].Definition().IsDraft, Is.True);
			Assert.That(result[0].CurveRegionFilters[0].Items[5].Name, Is.EqualTo("CCC_CURVE"));
			Assert.That(result[0].CurveRegionFilters[0].Items[6].Name, Is.EqualTo("CCC_CURVE_MANUAL"));
		}
    }
}
