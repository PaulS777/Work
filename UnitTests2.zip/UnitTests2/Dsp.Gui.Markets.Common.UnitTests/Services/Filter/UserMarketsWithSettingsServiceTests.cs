﻿using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.UnitTests.Helpers;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Reactive.Subjects;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	internal interface IUserMarketsWithSettingsServiceTestObjects
	{
		ICurveGroupRegionsDataSource DataSource { get; }
		ISubject<DashboardSettingsCollection> DashboardSettings { get; }
		ISubject<IList<int>> PublicationCurveIds { get; }
		IManualFilterChangedService ManualFilterChangedService { get; }
		ISubject<IList<MarketsFilterItemArgs>> ManualFilter { get; }
		IRemovePriceBandService RemovePriceBandService { get; }
		ISubject<LinkedCurve> RemovePriceBand { get; }
		ISubject<IList<MarketsFilterItemArgs>> PublicationsFilter { get; }
		IUserMarketsProvider UserMarketsProvider { get; }
		ISubject<IList<UserMarket>> UserMarkets { get; }
		UserMarketsWithSettingsService UserMarketsWithSettingsService { get; }
	}

	public class UserMarketsWithSettingsServiceTests
	{
		private class UserMarketsWithSettingsProviderTestObjectBuilder
		{
			private DashboardSettingsCollection _dashboardSettings;
			private IList<int> _publicationCurveIds;
			private IList<UserMarket> _userMarkets;
			private IEnumerable<MarketsFilterItem> _marketsFilterItems;

			public UserMarketsWithSettingsProviderTestObjectBuilder WithDashboardSettings(DashboardSettingsCollection values)
			{
				_dashboardSettings = values;
				return this;
			}

			public UserMarketsWithSettingsProviderTestObjectBuilder WithPublicationCurveIds(IList<int> values)
			{
				_publicationCurveIds = values;
				return this;
			}

			public UserMarketsWithSettingsProviderTestObjectBuilder WithUserMarkets(IList<UserMarket> values)
			{
				_userMarkets = values;
				return this;
			}

			public UserMarketsWithSettingsProviderTestObjectBuilder WithMarketsFilterItems(IEnumerable<MarketsFilterItem> values)
			{
				_marketsFilterItems = values;
				return this;
			}

			public IUserMarketsWithSettingsServiceTestObjects Build()
			{
				var testObjects = new Mock<IUserMarketsWithSettingsServiceTestObjects>();

				var dataSource = new Mock<ICurveGroupRegionsDataSource>();

				dataSource.Setup(d => d.GetMarketsFilterItems())
						  .Returns(_marketsFilterItems);

				testObjects.SetupGet(o => o.DataSource)
						   .Returns(dataSource.Object);

				var settings = new BehaviorSubject<DashboardSettingsCollection>(_dashboardSettings);

				testObjects.SetupGet(o => o.DashboardSettings)
						   .Returns(settings);

				var dashBoardSettingsService = new Mock<IDashboardSettingsService>();

				dashBoardSettingsService.SetupGet(d => d.DashboardSettings)
										.Returns(settings);

				var publicationCurveIds = new BehaviorSubject<IList<int>>(_publicationCurveIds);

				testObjects.SetupGet(o => o.PublicationCurveIds)
						   .Returns(publicationCurveIds);

				var userPublicationsProvider = new Mock<IUserPublicationsProvider>();

				userPublicationsProvider.SetupGet(p => p.PublicationCurveIds)
										.Returns(publicationCurveIds);

				var userMarkets = new BehaviorSubject<IList<UserMarket>>(_userMarkets);

				testObjects.SetupGet(o => o.UserMarkets)
						   .Returns(userMarkets);

				var userMarketsProvider = new Mock<IUserMarketsProvider>();

				userMarketsProvider.SetupGet(p => p.UserMarkets)
								   .Returns(userMarkets);

				testObjects.SetupGet(o => o.UserMarketsProvider)
						   .Returns(userMarketsProvider.Object);

				var publicationsFilter = new Subject<IList<MarketsFilterItemArgs>>();

				testObjects.SetupGet(o => o.PublicationsFilter)
						   .Returns(publicationsFilter);

				var userPublicationsFilterService = new Mock<IUserPublicationsFilterService>();

				userPublicationsFilterService.Setup(f => f.PublicationsFilter(It.IsAny<ICurveGroupRegionsDataSource>(), 
																			  It.IsAny<IObservable<IList<int>>>()))
											 .Returns(publicationsFilter);

				var manualFilterChanged = new Subject<IList<MarketsFilterItemArgs>>();

				testObjects.SetupGet(o => o.ManualFilter)
						   .Returns(manualFilterChanged);

				var manualFilterChangedService = new Mock<IManualFilterChangedService>();

				manualFilterChangedService.Setup(f => f.FilterChanged(It.IsAny<ICurveGroupRegionsDataSource>()))
										  .Returns(manualFilterChanged);

				testObjects.SetupGet(o => o.ManualFilterChangedService)
						   .Returns(manualFilterChangedService.Object);

				var removePriceBand = new Subject<LinkedCurve>();

				testObjects.SetupGet(o => o.RemovePriceBand)
						   .Returns(removePriceBand);

				var removePriceBandService = new Mock<IRemovePriceBandService>();

				removePriceBandService.SetupGet(r => r.OnRemovePriceBand)
									  .Returns(removePriceBand);

				testObjects.SetupGet(o => o.RemovePriceBandService)
						   .Returns(removePriceBandService.Object);

				var userMarketsWithSettingsService = new UserMarketsWithSettingsService(dashBoardSettingsService.Object,
																						userPublicationsProvider.Object,
																						userMarketsProvider.Object,
																						userPublicationsFilterService.Object,
																						TestMocks.GetSchedulerProvider().Object);

				testObjects.SetupGet(o => o.UserMarketsWithSettingsService)
						   .Returns(userMarketsWithSettingsService);

				return testObjects.Object;
			}
		}

		[Test]
		public void ShouldApplyDashboard_And_PublicationSettings_When_Initialize()
		{
			var priceColumnSettings = new List<PriceColumnSetting>
									  {
										  new() { Id = 101, DefinitionType = PriceCurveDefinitionType.PriceCurve },
										  new() { Id = 201, DefinitionType = PriceCurveDefinitionType.DerivedCurve }
									  };

			var dashboardSettings = new DashboardSettingsCollection
									{
										DashboardSettings =
										[
											new DashboardSettings
											{
												PageNumber = 2,
												PriceGridSettings = new DashboardPriceGridSettings
																	{
																		PriceColumnSettings = priceColumnSettings
																	}
											}
										]
									};

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve3 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);
			var linkedCurve4 = new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarket3 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve3)
															   .WithPriceCurveType(PriceCurveType.Manual)
															   .WithPriceCurveId(linkedCurve1.Id)
															   .Build();

			var userMarket4 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve4)
															   .WithPriceCurveType(PriceCurveType.Manual)
															   .WithPriceCurveId(linkedCurve2.Id)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2, userMarket3, userMarket4 };

			var curveIds = new[] { 101 };

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds(curveIds)
																					.Build();

			// ACT
			testObjects.UserMarketsWithSettingsService.Initialize(2, 
																  testObjects.DataSource, 
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			// ASSERT
			Mock.Get(testObjects.UserMarketsProvider)
				.Verify(p => p.Connect());

			Assert.That(userMarket1.CanSelect, Is.True);
			Assert.That(userMarket1.IsSelected, Is.True);

			Assert.That(userMarket2.CanSelect, Is.True);
			Assert.That(userMarket2.IsSelected, Is.False);

			Assert.That(userMarket3.CanSelect, Is.True);
			Assert.That(userMarket3.IsSelected, Is.True);

			Assert.That(userMarket4.CanSelect, Is.False);
			Assert.That(userMarket4.IsSelected, Is.False);
		}

		[Test]
		public void ShouldPublishUserMarkets_On_Subscribe()
		{
			var priceColumnSettings = new List<PriceColumnSetting>
									  {
										  new() { Id = 101, DefinitionType = PriceCurveDefinitionType.PriceCurve }
									  };

			var dashboardSettings = new DashboardSettingsCollection
									{
										DashboardSettings =
										[
											new DashboardSettings
											{
												PageNumber = 2,
												PriceGridSettings = new DashboardPriceGridSettings
																	{
																		PriceColumnSettings = priceColumnSettings
																	}
											}
										]
									};

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarkets = new[] { userMarket1 };

			int[] curveIds = [];

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds(curveIds)
																					.Build();

			testObjects.UserMarketsWithSettingsService.Initialize(2,
																  testObjects.DataSource,
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			IList<UserMarket> results = null;

			using (testObjects.UserMarketsWithSettingsService.UserMarkets.Subscribe(values => results = values))
			{
				// ASSERT
				Assert.That(results, Is.Not.Null);
				Assert.That(results.Count, Is.EqualTo(1));
				Assert.That(results[0], Is.Not.SameAs(userMarket1));
				Assert.That(results[0].LinkedCurve, Is.EqualTo(linkedCurve1));
				Assert.That(results[0].CanSelect, Is.True);
				Assert.That(results[0].IsSelected, Is.True);
			}
		}

		[Test]
		public void ShouldApplyFilter_And_PublishUpdate_On_MarketsFilter()
		{
			var dashboardSettings = new DashboardSettingsCollection();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var manualFilterUpdate = new[]
									 {
										 new MarketsFilterItemArgs(linkedCurve1, true, false),
										 new MarketsFilterItemArgs(linkedCurve2, true, true)
									 };

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds([])
																					.Build();

			testObjects.UserMarketsWithSettingsService.Initialize(2,
																  testObjects.DataSource,
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			IList<UserMarket> results = null;

			using (testObjects.UserMarketsWithSettingsService.UserMarkets.Subscribe(values => results = values))
			{
				// ACT
				testObjects.ManualFilter.OnNext(manualFilterUpdate);

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(2));
				Assert.That(results[0].LinkedCurve, Is.EqualTo(linkedCurve1));
				Assert.That(results[0].CanSelect, Is.True);
				Assert.That(results[0].IsSelected, Is.False);

				Assert.That(results[1].LinkedCurve, Is.EqualTo(linkedCurve2));
				Assert.That(results[1].CanSelect, Is.True);
				Assert.That(results[1].IsSelected, Is.True);
			}
		}

		[Test]
		public void ShouldApplyFilter_And_PublishUpdate_On_PublicationsFilter()
		{
			var dashboardSettings = new DashboardSettingsCollection();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var publicationsFilterUpdate = new[]
											 {
												 new MarketsFilterItemArgs(linkedCurve1, true, false),
												 new MarketsFilterItemArgs(linkedCurve2, true, true)
											 };

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds([])
																					.Build();

			testObjects.UserMarketsWithSettingsService.Initialize(2,
																  testObjects.DataSource,
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			IList<UserMarket> results = null;

			using (testObjects.UserMarketsWithSettingsService.UserMarkets.Subscribe(values => results = values))
			{
				// ACT
				testObjects.PublicationsFilter.OnNext(publicationsFilterUpdate);

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(2));
				Assert.That(results[0].LinkedCurve, Is.EqualTo(linkedCurve1));
				Assert.That(results[0].CanSelect, Is.True);
				Assert.That(results[0].IsSelected, Is.False);

				Assert.That(results[1].LinkedCurve, Is.EqualTo(linkedCurve2));
				Assert.That(results[1].CanSelect, Is.True);
				Assert.That(results[1].IsSelected, Is.True);
			}
		}

		[Test]
		public void ShouldApplyFilter_And_PublishUpdate_On_UserMarkets()
		{
			var dashboardSettings = new DashboardSettingsCollection();

			var crude = new CurveGroupTestObjectBuilder().Crude();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var item1 = new MarketsFilterItem(new CurveItemDefinition(linkedCurve1, crude, "name", 2))
						{
							IsSelected = true,
							CanSelect = true
						};

			var items = new[] { item1 };

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarkets = new[] { userMarket1 };
			var update = new[] { userMarket1, userMarket2 };

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds([])
																					.WithMarketsFilterItems(items)
																					.Build();

			testObjects.UserMarketsWithSettingsService.Initialize(2,
																  testObjects.DataSource,
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			IList<UserMarket> results = null;

			using (testObjects.UserMarketsWithSettingsService.UserMarkets.Subscribe(values => results = values))
			{
				// ACT
				testObjects.UserMarkets.OnNext(update);

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(2));
				Assert.That(results[0].LinkedCurve, Is.EqualTo(linkedCurve1));
				Assert.That(results[0].CanSelect, Is.True);
				Assert.That(results[0].IsSelected, Is.True);

				Assert.That(results[1].LinkedCurve, Is.EqualTo(linkedCurve2));
				Assert.That(results[1].CanSelect, Is.False);
				Assert.That(results[1].IsSelected, Is.False);
			}
		}

		[Test]
		public void ShouldRemoveBand_And_PublishUpdate_On_RemoveBand()
		{
			var dashboardSettings = new DashboardSettingsCollection();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarkets = new List<UserMarket> { userMarket1, userMarket2 };

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds([])
																					.Build();

			testObjects.UserMarketsWithSettingsService.Initialize(2,
																  testObjects.DataSource,
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			IList<UserMarket> results = null;

			using (testObjects.UserMarketsWithSettingsService.UserMarkets.Subscribe(values => results = values))
			{
				// ACT
				testObjects.RemovePriceBand.OnNext(linkedCurve1);

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(1));
				Assert.That(results[0].LinkedCurve, Is.EqualTo(linkedCurve2));
			}
		}

		[Test]
		public void ShouldSetCanSelectTrue_On_UserMarkets_With_NewDraftManual()
		{
			var dashboardSettings = new DashboardSettingsCollection();

			var linkedCurve1 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);
			var linkedCurve2 = new LinkedCurve(202, PriceCurveDefinitionType.DerivedCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Manual)
															   .WithIsDraft(true)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithPriceCurveType(PriceCurveType.Manual)
															   .Build();

			var userMarkets = new[] { userMarket1 };
			var update = new[] { userMarket1, userMarket2 };

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds([])
																					.WithMarketsFilterItems([])
																					.Build();

			testObjects.UserMarketsWithSettingsService.Initialize(2,
																  testObjects.DataSource,
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			IList<UserMarket> results = null;

			using (testObjects.UserMarketsWithSettingsService.UserMarkets.Subscribe(values => results = values))
			{
				// ACT
				testObjects.UserMarkets.OnNext(update);

				// ASSERT
				Assert.That(results.Count, Is.EqualTo(2));
				Assert.That(results[0].LinkedCurve, Is.EqualTo(linkedCurve1));
				Assert.That(results[0].CanSelect, Is.True);

				Assert.That(results[1].LinkedCurve, Is.EqualTo(linkedCurve2));
				Assert.That(results[1].CanSelect, Is.False);
			}
		}

		[Test]
		public void ShouldNot_PublishUpdate_When_Disposed()
		{
			var dashboardSettings = new DashboardSettingsCollection();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var manualFilterUpdate = new[]
									 {
										 new MarketsFilterItemArgs(linkedCurve1, true, false),
										 new MarketsFilterItemArgs(linkedCurve2, true, true)
									 };

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds([])
																					.Build();

			testObjects.UserMarketsWithSettingsService.Initialize(2,
																  testObjects.DataSource,
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			IList<UserMarket> results = null;

			using (testObjects.UserMarketsWithSettingsService.UserMarkets.Subscribe(values => results = values))
			{
				testObjects.UserMarketsWithSettingsService.Dispose();

				results = null;

				// ACT
				testObjects.ManualFilter.OnNext(manualFilterUpdate);

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}

		[Test]
		public void ShouldNot_Dispose_When_Disposed()
		{
			var dashboardSettings = new DashboardSettingsCollection();

			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(102, PriceCurveDefinitionType.PriceCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2)
															   .WithPriceCurveType(PriceCurveType.Live)
															   .Build();

			var userMarkets = new[] { userMarket1, userMarket2 };

			var manualFilterUpdate = new[]
									 {
										 new MarketsFilterItemArgs(linkedCurve1, true, false),
										 new MarketsFilterItemArgs(linkedCurve2, true, true)
									 };

			var testObjects = new UserMarketsWithSettingsProviderTestObjectBuilder().WithDashboardSettings(dashboardSettings)
																					.WithUserMarkets(userMarkets)
																					.WithPublicationCurveIds([])
																					.Build();

			testObjects.UserMarketsWithSettingsService.Initialize(2,
																  testObjects.DataSource,
																  testObjects.ManualFilterChangedService,
																  testObjects.RemovePriceBandService);

			IList<UserMarket> results = null;

			using (testObjects.UserMarketsWithSettingsService.UserMarkets.Subscribe(values => results = values))
			{
				testObjects.UserMarketsWithSettingsService.Dispose();

				results = null;

				// ACT
				testObjects.UserMarketsWithSettingsService.Dispose();
				testObjects.ManualFilter.OnNext(manualFilterUpdate);

				// ASSERT
				Assert.That(results, Is.Null);
			}
		}
	}
}
