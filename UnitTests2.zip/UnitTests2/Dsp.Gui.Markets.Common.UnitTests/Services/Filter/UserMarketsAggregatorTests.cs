﻿using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Services.Filter;
using Dsp.Gui.Markets.Common.UnitTests.Helpers;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.Filter
{
	[TestFixture]
	public class UserMarketsAggregatorTests
	{
		[Test]
		public void ShouldReturnAggregatedListCloned()
		{
			var linkedCurve1 = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);
			var linkedCurve2 = new LinkedCurve(201, PriceCurveDefinitionType.DerivedCurve);

			var userMarket1 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve1).Build();
			var userMarket2 = new UserMarketTestObjectBuilder().WithLinkedCurve(linkedCurve2).Build();

			var aggregator = new UserMarketsAggregator();

			// ACT
			var result = aggregator.AggregateMarkets([userMarket1], [userMarket2]);

			// ASSERT
			Assert.That(result.Count, Is.EqualTo(2));

			Assert.That(result[0], Is.Not.SameAs(userMarket1));
			Assert.That(result[0].LinkedCurve, Is.EqualTo(linkedCurve1));

			Assert.That(result[1], Is.Not.SameAs(userMarket2));
			Assert.That(result[1].LinkedCurve, Is.EqualTo(linkedCurve2));

		}
	}
}
