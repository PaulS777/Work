﻿using System.Linq;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Markets.Common.Models;
using Dsp.Gui.Markets.Common.Services.DataSource;
using Dsp.Gui.Markets.Common.ViewModels.Filter;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Services.DataSource
{
	[TestFixture]
	public class CurveGroupRegionsDataSourceTests
	{
		[Test]
		public void ShouldReturnFilterItems_When_GetMarketsFilterItems()
		{
			var linkedCurve = new LinkedCurve(101, PriceCurveDefinitionType.PriceCurve);

			var filterItem = new MarketsFilterItem(new CurveItemDefinition(linkedCurve,
																		   new CurveGroupTestObjectBuilder().Default(),
																		   "curve-1",
																		   2))
							 {
								 IsSelected = true,
								 CanSelect = true
							 };

			var curveGroupRegions = new CurveGroupRegionCollectionTestObjectBuilder().WithMarketsFilterItem(filterItem)
																					 .Build();

			var dataSource = new CurveGroupRegionsDataSource();

			dataSource.InitializeDataSource(curveGroupRegions);

			var expected = new[] { filterItem };

			// ACT
			var result = dataSource.GetMarketsFilterItems();

			// ASSERT
			Assert.That(result.SequenceEqual(expected));
		}
	}
}
