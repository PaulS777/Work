﻿using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Markets.Common.Models;

namespace Dsp.Gui.Markets.Common.UnitTests.Helpers
{
    public class UserMarketTestObjectBuilder
    {
        private PriceCurveDetails _details;

        private PriceCurveType _priceCurveType;
        private LinkedCurve _linkedCurve;
        private int _precision;
        private string _name;
        private CurveGroup _curveGroup;
        private CurveRegion _curveRegion;
        private int? _priceCurveId;
		private int? _pendingCurveId;
		private bool _isDraft;
        private bool _canSelect;
        private bool _isSelected;

        public UserMarketTestObjectBuilder WithPriceCurveDetails(PriceCurveDetails value)
        {
            _details = value;
            return this;
        }

        public UserMarketTestObjectBuilder WithPriceCurveType(PriceCurveType value)
        {
            _priceCurveType = value;
            return this;
        }

        public UserMarketTestObjectBuilder WithLinkedCurve(LinkedCurve value)
        {
            _linkedCurve = value;
            return this;
        }

        public UserMarketTestObjectBuilder WithPrecision(int value)
        {
            _precision = value;
            return this;
        }

        public UserMarketTestObjectBuilder WithName(string value)
        {
            _name = value;
            return this;
        }

        public UserMarketTestObjectBuilder WithCurveGroup(CurveGroup value)
        {
            _curveGroup = value;
            return this;
        }

        public UserMarketTestObjectBuilder WithCurveRegion(CurveRegion value)
        {
            _curveRegion = value;
            return this;
        }

        public UserMarketTestObjectBuilder WithPriceCurveId(int value)
        {
            _priceCurveId = value;
            return this;
        }

		public UserMarketTestObjectBuilder WithPendingCurveId(int? value)
		{
			_pendingCurveId = value;
			return this;
		}

		public UserMarketTestObjectBuilder WithIsDraft(bool value)
		{
			_isDraft = value;
			return this;
		}

		public UserMarketTestObjectBuilder WithCanSelect(bool value)
        {
            _canSelect = value;
            return this;
        }

        public UserMarketTestObjectBuilder WithIsSelected(bool value)
        {
            _isSelected = value;
            return this;
        }

        public UserMarket Build()
        {
            var details = _details ?? new PriceCurveDetails(_priceCurveType, _linkedCurve, _precision);

            return new UserMarket(details, _name, _curveGroup, _curveRegion, _priceCurveId)
            {
				PendingCurveId = _pendingCurveId,
				IsDraft = _isDraft,
				CanSelect = _canSelect,
                IsSelected = _isSelected
            };
        }
    }
}
