﻿using Dsp.DataContracts.Curve;
using Dsp.DataContracts;
using Dsp.Gui.Markets.Common.Comparers;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Comparers
{
	[TestFixture]
	public class UserCurvePermissionsComparerTests
	{
		[Test]
		public void ShouldReturnTrue_When_Compare_Users_With_SamePermissions()
		{
			var crude = new CurveGroupTestObjectBuilder().Crude();

			var curveGroups = new[] { new AuthorisationCurveGroup(crude, true, true) };
			var curveRegions = new[] { new AuthorisationCurveRegion(CurveRegion.Europe, true, true) };

			var user1 = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										 .WithAuthorizationCurveRegions(curveRegions)
										 .User();

			var user2 = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
										 .WithAuthorizationCurveRegions(curveRegions)
										 .User();

			var comparer = new UserCurvePermissionsComparer();

			// ACT
			var result = comparer.Equals(user1, user2);

			// ASSERT
			Assert.That(result, Is.True);
		}
	}
}
