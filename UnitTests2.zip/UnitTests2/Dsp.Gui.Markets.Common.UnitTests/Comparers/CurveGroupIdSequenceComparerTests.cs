﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Markets.Common.Comparers;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Comparers
{
	[TestFixture]
	public class CurveGroupIdSequenceComparerTests
	{
		[Test]
		public void ShouldGetOrderBySequence()
		{
			var curveGroup1 = new CurveGroup(1, "name", string.Empty, false);
			var curveGroup2 = new CurveGroup(2, "name", string.Empty, false);
			var curveGroup3 = new CurveGroup(3, "name", string.Empty, false);

			var curveGroup4 = new CurveGroup(4, "name", string.Empty, false);
			var curveGroup5 = new CurveGroup(5, "name", string.Empty, false);

			var sequence = new[] { 3, 2, 1 };

			var comparer = new CurveGroupIdSequenceComparer(sequence);

			var curveGroups = new[] { curveGroup5, curveGroup4, curveGroup1, curveGroup2, curveGroup3 };

			// ACT
			var result = curveGroups.OrderBy(cg => cg, comparer).ToList();

			// ASSERT
			Assert.That(result[0].Id, Is.EqualTo(3));
			Assert.That(result[1].Id, Is.EqualTo(2));
			Assert.That(result[2].Id, Is.EqualTo(1));
			Assert.That(result[3].Id, Is.EqualTo(4));
			Assert.That(result[4].Id, Is.EqualTo(5));
		}
	}
}
