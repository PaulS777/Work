﻿using Dsp.DataContracts;
using Dsp.Gui.Markets.Common.Comparers;
using Dsp.Gui.TestObjects;
using NUnit.Framework;

namespace Dsp.Gui.Markets.Common.UnitTests.Comparers
{
    [TestFixture]
    public class ManualCurveDefinitionsComparerTests
    {
		[Test]
		public void ShouldReturnTrue_When_Compare_Curves_With_SamesIds_And_Name()
		{
			var curve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name").Build();

			var curves1 = new[] { curve1 };

			var curve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name").Build();

			var curves2 = new[] { curve2 };

			var comparer = new ManualCurveDefinitionsComparer();

			// ACT
			var result = comparer.Equals(curves1, curves2);

			// ASSERT
			Assert.That(result, Is.True);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_Curves_With_AddedCurve()
		{
			var curve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name").Build();

			var curves1 = new[] { curve1 };

			var curve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202).WithCurveId(201).WithName("name-2").Build();

			var curves2 = new[] { curve1, curve2 };

			var comparer = new ManualCurveDefinitionsComparer();

			// ACT
			var result = comparer.Equals(curves1, curves2);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_Curves_With_Ids_NotEqual()
		{
			var curve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name").Build();

			var curves1 = new[] { curve1 };

			var curve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(202).WithCurveId(101).WithName("name").Build();

			var curves2 = new[] { curve2 };

			var comparer = new ManualCurveDefinitionsComparer();

			// ACT
			var result = comparer.Equals(curves1, curves2);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_Curves_With_CurveIds_NotEqual()
		{
			var curve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name").Build();

			var curves1 = new[] { curve1 };

			var curve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(102).WithName("name").Build();

			var curves2 = new[] { curve2 };

			var comparer = new ManualCurveDefinitionsComparer();

			// ACT
			var result = comparer.Equals(curves1, curves2);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_Curves_With_Names_NotEqual()
		{
			var curve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name").Build();

			var curves1 = new[] { curve1 };

			var curve2 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name-2").Build();

			var curves2 = new[] { curve2 };

			var comparer = new ManualCurveDefinitionsComparer();

			// ACT
			var result = comparer.Equals(curves1, curves2);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_Curves_With_Null()
		{
			var curve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name").Build();

			var curves1 = new[] { curve1 };

			var comparer = new ManualCurveDefinitionsComparer();

			// ACT
			var result = comparer.Equals(curves1, null);

			// ASSERT
			Assert.That(result, Is.False);
		}

		[Test]
		public void ShouldReturnFalse_When_Compare_Curves_With_OtherNull()
		{
			var curve1 = new ManualCurveDefinitionBuilder<MonthlyTenor>().WithId(201).WithCurveId(101).WithName("name").Build();

			var curves1 = new[] { curve1 };

			var comparer = new ManualCurveDefinitionsComparer();

			// ACT
			var result = comparer.Equals(null, curves1);

			// ASSERT
			Assert.That(result, Is.False);
		}
	}
}
