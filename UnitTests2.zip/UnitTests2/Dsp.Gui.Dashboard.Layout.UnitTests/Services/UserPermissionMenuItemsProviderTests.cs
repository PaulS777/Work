﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Layout.Enum;
using Dsp.Gui.Dashboard.Layout.Services;
using Dsp.Gui.Dashboard.Layout.ViewModels;
using Dsp.Gui.Dashboard.Layout.Views;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Services
{
    internal interface IUserPermissionsMenuItemProviderTestObjects
    {
        ISubject<User> CurrentUser { get; }
        UserPermissionMenuItemsProvider UserPermissionMenuItemsProvider { get; }
    }

    [TestFixture]
    public class UserPermissionMenuItemsProviderTests
    {
        private class UserPermissionsMenuItemProviderTestObjectBuilder
        {
            public IUserPermissionsMenuItemProviderTestObjects Build()
            {
                var testObjects = new Mock<IUserPermissionsMenuItemProviderTestObjects>();

                var currentUser = new Subject<User>();

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

				var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.CurrentUser)
                                   .Returns(currentUser);

				var userPermissionMenuItemsProvider = new UserPermissionMenuItemsProvider(curveControlService.Object);

				testObjects.SetupGet(o => o.UserPermissionMenuItemsProvider)
                           .Returns(userPermissionMenuItemsProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPublishAllMenuItems_When_UserHasFullPermissions()
        {
            var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 0, true)])
                                        .WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 0, true)])
                                        .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)])
                                        .WithAuthorizationFxCurve([new AuthorisationFxCurve(99, true, true)])
                                        .WithIsAdmin(true)
										.User();

			var testObjects = new UserPermissionsMenuItemProviderTestObjectBuilder().Build();

            IList<NavigationMenuItemGroupViewModel> results = null;

            using (testObjects.UserPermissionMenuItemsProvider.MenuItems().Subscribe(r => results = r))
            {
                testObjects.CurrentUser.OnNext(user);

                // ASSERT
                Assert.That(results.Count, Is.EqualTo(6));

                // ASSERT - Publication
                Assert.That(results[0].MenuGroupType, Is.EqualTo(MenuGroupType.PublicationControls));
                Assert.That(results[0].Caption, Is.EqualTo(MenuHeaders.Publication));
                Assert.That(results[0].MenuItems.Count, Is.EqualTo(1));

                Assert.That(results[0].MenuItems[0].Caption, Is.EqualTo(MenuHeaders.CurveSettings));
                Assert.That(results[0].MenuItems[0].MenuType, Is.EqualTo(MenuType.PublicationControls));
                Assert.That(results[0].MenuItems[0].ShowInPreview, Is.True);
                Assert.That(results[0].MenuItems[0].PageName, Is.EqualTo(nameof(PublicationControlPage)));

                // ASSERT - Fees and Premiums
                Assert.That(results[1].MenuGroupType, Is.EqualTo(MenuGroupType.FeesAndPremiums));
                Assert.That(results[1].Caption, Is.EqualTo(MenuHeaders.FeesAndPremiums));
                Assert.That(results[1].MenuItems.Count, Is.EqualTo(1));

                Assert.That(results[1].MenuItems[0].Caption, Is.EqualTo(MenuHeaders.FeesAndPremiums));
                Assert.That(results[1].MenuItems[0].MenuType, Is.EqualTo(MenuType.FeesAndPremiums));
                Assert.That(results[1].MenuItems[0].ShowInPreview, Is.False);
                Assert.That(results[1].MenuItems[0].PageName, Is.EqualTo(nameof(PremiumsEditorPage)));

                // ASSERT - Curve Maintenance
                Assert.That(results[2].MenuItems.Count, Is.EqualTo(8));

                Assert.That(results[2].MenuGroupType, Is.EqualTo(MenuGroupType.CurveMaintenance));
				Assert.That(results[2].Caption, Is.EqualTo(MenuHeaders.CurveMaintenance));

				Assert.That(results[2].MenuItems[0].Caption, Is.EqualTo(MenuHeaders.CurveApprovals));
				Assert.That(results[2].MenuItems[0].MenuType, Is.EqualTo(MenuType.CurveApprovals));
				Assert.That(results[2].MenuItems[0].ShowInPreview, Is.False);
				Assert.That(results[2].MenuItems[0].PageName, Is.EqualTo(nameof(CurveApprovalsNavigationPage)));

				Assert.That(results[2].MenuItems[1].Caption, Is.EqualTo(MenuHeaders.ManualCurveMaintenance));
                Assert.That(results[2].MenuItems[1].MenuType, Is.EqualTo(MenuType.ManualCurveMaintenance));
                Assert.That(results[2].MenuItems[1].ShowInPreview, Is.False);
                Assert.That(results[2].MenuItems[1].PageName, Is.EqualTo(nameof(ManualCurveMaintenancePage)));

				Assert.That(results[2].MenuItems[2].Caption, Is.EqualTo(MenuHeaders.FormulaCurveMaintenance));
				Assert.That(results[2].MenuItems[2].MenuType, Is.EqualTo(MenuType.FormulaCurveMaintenance));
				Assert.That(results[2].MenuItems[2].ShowInPreview, Is.False);
				Assert.That(results[2].MenuItems[2].PageName, Is.EqualTo(nameof(FormulaCurveMaintenancePage)));

				Assert.That(results[2].MenuItems[3].Caption, Is.EqualTo(MenuHeaders.FxCurveMaintenance));
                Assert.That(results[2].MenuItems[3].MenuType, Is.EqualTo(MenuType.FxCurveMaintenance));
                Assert.That(results[2].MenuItems[3].ShowInPreview, Is.False);
                Assert.That(results[2].MenuItems[3].PageName, Is.EqualTo(nameof(FxCurveMaintenancePage)));


                Assert.That(results[2].MenuItems[4].Caption, Is.EqualTo(MenuHeaders.ProductMaintenance));
                Assert.That(results[2].MenuItems[4].MenuType, Is.EqualTo(MenuType.ProductMaintenance));
                Assert.That(results[2].MenuItems[4].ShowInPreview, Is.False);
                Assert.That(results[2].MenuItems[4].PageName, Is.EqualTo(nameof(ProductMaintenancePage)));


                Assert.That(results[2].MenuItems[5].Caption, Is.EqualTo(MenuHeaders.FlatPriceCurveBuilder));
                Assert.That(results[2].MenuItems[5].MenuType, Is.EqualTo(MenuType.FlatPriceCurveBuilder));
                Assert.That(results[2].MenuItems[5].ShowInPreview, Is.False);
                Assert.That(results[2].MenuItems[5].PageName, Is.EqualTo(nameof(FlatPriceCurveBuilderPage)));

                Assert.That(results[2].MenuItems[6].Caption, Is.EqualTo(MenuHeaders.PartitionCurveEditor));
                Assert.That(results[2].MenuItems[6].MenuType, Is.EqualTo(MenuType.PartitionCurveEditor));
                Assert.That(results[2].MenuItems[6].ShowInPreview, Is.False);
                Assert.That(results[2].MenuItems[6].PageName, Is.EqualTo(nameof(PartitionCurveEditorPage)));

                Assert.That(results[2].MenuItems[7].Caption, Is.EqualTo(MenuHeaders.PartitionCurveShift));
                Assert.That(results[2].MenuItems[7].MenuType, Is.EqualTo(MenuType.PartitionShift));
                Assert.That(results[2].MenuItems[7].ShowInPreview, Is.False);
                Assert.That(results[2].MenuItems[7].PageName, Is.EqualTo(nameof(PartitionCurveShiftPage)));

                // ASSERT - Chat Maintenance
                Assert.That(results[3].MenuGroupType, Is.EqualTo(MenuGroupType.ChatScraper));
                Assert.That(results[3].Caption, Is.EqualTo(MenuHeaders.ChatMaintenance));
                Assert.That(results[3].MenuItems.Count, Is.EqualTo(6));

                Assert.That(results[3].MenuItems[0].Caption, Is.EqualTo(MenuHeaders.ChatBrokerAdmin));
                Assert.That(results[3].MenuItems[0].MenuType, Is.EqualTo(MenuType.ChatScraperBrokerAdmin));
                Assert.That(results[3].MenuItems[0].ShowInPreview, Is.False);
                Assert.That(results[3].MenuItems[0].PageName, Is.EqualTo(nameof(ChatScraperBrokersPage)));

                Assert.That(results[3].MenuItems[1].Caption, Is.EqualTo(MenuHeaders.ChatMarketAdmin));
                Assert.That(results[3].MenuItems[1].MenuType, Is.EqualTo(MenuType.ChatScraperMarketAdmin));
                Assert.That(results[3].MenuItems[1].ShowInPreview, Is.False);
                Assert.That(results[3].MenuItems[1].PageName, Is.EqualTo(nameof(ChatScraperMarketsPage)));

                Assert.That(results[3].MenuItems[2].Caption, Is.EqualTo(MenuHeaders.ChatProductAdmin));
                Assert.That(results[3].MenuItems[2].MenuType, Is.EqualTo(MenuType.ChatScraperProductAdmin));
                Assert.That(results[3].MenuItems[2].ShowInPreview, Is.False);
                Assert.That(results[3].MenuItems[2].PageName, Is.EqualTo(nameof(ChatScraperProductsPage)));

                Assert.That(results[3].MenuItems[3].Caption, Is.EqualTo(MenuHeaders.ChatShortcutsAdmin));
                Assert.That(results[3].MenuItems[3].MenuType, Is.EqualTo(MenuType.ChatScraperShortcutsAdmin));
                Assert.That(results[3].MenuItems[3].ShowInPreview, Is.False);
                Assert.That(results[3].MenuItems[3].PageName, Is.EqualTo(nameof(ChatScraperShortcutsPage)));

                Assert.That(results[3].MenuItems[4].Caption, Is.EqualTo(MenuHeaders.ChatMessageAdmin));
                Assert.That(results[3].MenuItems[4].MenuType, Is.EqualTo(MenuType.ChatScraperMessageAdmin));
                Assert.That(results[3].MenuItems[4].ShowInPreview, Is.False);
                Assert.That(results[3].MenuItems[4].PageName, Is.EqualTo(nameof(ChatScraperMessagesPage)));

                Assert.That(results[3].MenuItems[5].Caption, Is.EqualTo(MenuHeaders.ChatPriceSummary));
                Assert.That(results[3].MenuItems[5].MenuType, Is.EqualTo(MenuType.ChatPriceSummary));
                Assert.That(results[3].MenuItems[5].ShowInPreview, Is.False);
                Assert.That(results[3].MenuItems[5].PageName, Is.EqualTo(nameof(ChatScraperPriceSummaryPage)));

                // ASSERT - FX 
                Assert.That(results[4].MenuGroupType, Is.EqualTo(MenuGroupType.Fx));
                Assert.That(results[4].Caption, Is.EqualTo(MenuHeaders.Fx));
                Assert.That(results[4].MenuItems.Count, Is.EqualTo(2));

                Assert.That(results[4].MenuItems[0].Caption, Is.EqualTo(MenuHeaders.FxPrices));
                Assert.That(results[4].MenuItems[0].MenuType, Is.EqualTo(MenuType.FxPrices));
                Assert.That(results[4].MenuItems[0].ShowInPreview, Is.False);
                Assert.That(results[4].MenuItems[0].PageName, Is.EqualTo(nameof(FxPricesPage)));

                Assert.That(results[4].MenuItems[1].Caption, Is.EqualTo(MenuHeaders.FxPremiums));
                Assert.That(results[4].MenuItems[1].MenuType, Is.EqualTo(MenuType.FxPremiums));
                Assert.That(results[4].MenuItems[1].ShowInPreview, Is.False);
                Assert.That(results[4].MenuItems[1].PageName, Is.EqualTo(nameof(FxPremiumsPage)));

                // ASSERT - Administration
                Assert.That(results[5].MenuGroupType, Is.EqualTo(MenuGroupType.Admin));
                Assert.That(results[5].Caption, Is.EqualTo(MenuHeaders.Administration));
                Assert.That(results[5].MenuItems.Count, Is.EqualTo(2));

                Assert.That(results[5].MenuItems[0].Caption, Is.EqualTo(MenuHeaders.UserAdmin));
                Assert.That(results[5].MenuItems[0].MenuType, Is.EqualTo(MenuType.UserAdmin));
                Assert.That(results[5].MenuItems[0].ShowInPreview, Is.False);
                Assert.That(results[5].MenuItems[0].PageName, Is.EqualTo(nameof(UserAdminPage)));

                Assert.That(results[5].MenuItems[1].Caption, Is.EqualTo(MenuHeaders.CalendarAdmin));
                Assert.That(results[5].MenuItems[1].MenuType, Is.EqualTo(MenuType.CalendarAdmin));
                Assert.That(results[5].MenuItems[1].ShowInPreview, Is.False);
                Assert.That(results[5].MenuItems[1].PageName, Is.EqualTo(nameof(CalendarAdminPage)));
            }
        }

		[Test]
		public void ShouldPublishCurveMaintenanceWithoutApprovals_With_CurveAdmin_Not_CurveApprovals()
		{
			var user = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 0, true)])
										.WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)])
										.User();


			var testObjects = new UserPermissionsMenuItemProviderTestObjectBuilder().Build();

			IList<NavigationMenuItemGroupViewModel> results = null;

			using (testObjects.UserPermissionMenuItemsProvider.MenuItems().Subscribe(r => results = r))
			{
				testObjects.CurrentUser.OnNext(user);

				// ASSERT - Curve Maintenance
				Assert.That(results[2].MenuItems.Count, Is.EqualTo(7));

				Assert.That(results[2].MenuGroupType, Is.EqualTo(MenuGroupType.CurveMaintenance));
				Assert.That(results[2].Caption, Is.EqualTo(MenuHeaders.CurveMaintenance));

				Assert.That(results[2].MenuItems[0].Caption, Is.EqualTo(MenuHeaders.ManualCurveMaintenance));
				Assert.That(results[2].MenuItems[0].MenuType, Is.EqualTo(MenuType.ManualCurveMaintenance));
				Assert.That(results[2].MenuItems[0].ShowInPreview, Is.False);
				Assert.That(results[2].MenuItems[0].PageName, Is.EqualTo(nameof(ManualCurveMaintenancePage)));

				Assert.That(results[2].MenuItems[1].Caption, Is.EqualTo(MenuHeaders.FormulaCurveMaintenance));
				Assert.That(results[2].MenuItems[1].MenuType, Is.EqualTo(MenuType.FormulaCurveMaintenance));
				Assert.That(results[2].MenuItems[1].ShowInPreview, Is.False);
				Assert.That(results[2].MenuItems[1].PageName, Is.EqualTo(nameof(FormulaCurveMaintenancePage)));

				Assert.That(results[2].MenuItems[2].Caption, Is.EqualTo(MenuHeaders.FxCurveMaintenance));
				Assert.That(results[2].MenuItems[2].MenuType, Is.EqualTo(MenuType.FxCurveMaintenance));
				Assert.That(results[2].MenuItems[2].ShowInPreview, Is.False);
				Assert.That(results[2].MenuItems[2].PageName, Is.EqualTo(nameof(FxCurveMaintenancePage)));
			}
		}

        [Test]
        public void ShouldPublishFxGroupOnly_With_FxPricesOnly_When_User_HasNoPermissions()
        {
            var user = new UserBuilder().User();

            var testObjects = new UserPermissionsMenuItemProviderTestObjectBuilder().Build();

            IList<NavigationMenuItemGroupViewModel> results = null;

            using (testObjects.UserPermissionMenuItemsProvider.MenuItems().Subscribe(r => results = r))
            {
                testObjects.CurrentUser.OnNext(user);

                // ASSERT
                Assert.That(results.Count, Is.EqualTo(1));
                Assert.That(results[0].MenuGroupType, Is.EqualTo(MenuGroupType.Fx));

                Assert.That(results[0].MenuItems.Count, Is.EqualTo(1));
				Assert.That(results[0].MenuItems[0].PageName, Is.EqualTo(nameof(FxPricesPage)));
			}
		}

        [Test]
        public void ShouldPublish_On_UserUpdate_With_MenuPermissionChanged()
        {
            var user = new UserBuilder().User();
            var update = new UserBuilder().WithIsAdmin(true).User();

            var testObjects = new UserPermissionsMenuItemProviderTestObjectBuilder().Build();

            IList<NavigationMenuItemGroupViewModel> results = null;

            using (testObjects.UserPermissionMenuItemsProvider.MenuItems().Subscribe(r => results = r))
            {
                // ARRANGE
                testObjects.CurrentUser.OnNext(user);

                // ACT
                testObjects.CurrentUser.OnNext(update);

                // ASSERT
                Assert.That(results.Count, Is.EqualTo(2));
                Assert.That(results[1].MenuGroupType, Is.EqualTo(MenuGroupType.Admin));
            }
        }

        [Test]
        public void ShouldNotPublish_On_UserUpdate_With_NonMenuPermissionChanged()
        {
            var user = new UserBuilder().User();
            var update = new UserBuilder().WithSpreadMultiplier(1.1d).User();

            var testObjects = new UserPermissionsMenuItemProviderTestObjectBuilder().Build();

            IList<NavigationMenuItemGroupViewModel> results = null;

            using (testObjects.UserPermissionMenuItemsProvider.MenuItems().Subscribe(r => results = r))
            {
                // ARRANGE
                testObjects.CurrentUser.OnNext(user);

                results = null;

                // ACT
                testObjects.CurrentUser.OnNext(update);

                // ASSERT
                Assert.That(results, Is.Null);
            }
        }
	}
}
