﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common;
using Dsp.Gui.Dashboard.Common.Services.Settings;
using Dsp.Gui.Dashboard.Common.Settings;
using Dsp.Gui.Dashboard.Layout.Enum;
using Dsp.Gui.Dashboard.Layout.Services;
using Dsp.Gui.Dashboard.Layout.ViewModels;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Services
{
    internal interface IDashboardMenuProviderTestObjects
    {
        ISubject<User> CurrentUser { get; }
		ISubject<DashboardSettingsCollection> DashboardSettings { get; }
        DashboardMenuProvider DashboardMenuProvider { get; }
    }

    [TestFixture]
    public class DashboardMenuProviderTests
    {
        private class DashboardMenuProviderTestObjectBuilder
        {
            private User _currentUser;
            private DashboardSettingsCollection _dashboardSettings;

			public DashboardMenuProviderTestObjectBuilder WithCurrentUser(User value)
            {
                _currentUser = value;
                return this;
            }

            public DashboardMenuProviderTestObjectBuilder WithDashboardSettings(DashboardSettingsCollection value)
            {
                _dashboardSettings = value;
                return this;
            }

			public IDashboardMenuProviderTestObjects Build()
            {
                var testObjects = new Mock<IDashboardMenuProviderTestObjects>();

                var currentUser = new BehaviorSubject<User>(_currentUser);

                testObjects.SetupGet(o => o.CurrentUser)
                           .Returns(currentUser);

                var curveControlService = new Mock<ICurveControlService>();

                curveControlService.SetupGet(o => o.CurrentUser)
                                   .Returns(currentUser);

				var dashboardSettings = new BehaviorSubject<DashboardSettingsCollection>(_dashboardSettings);

                testObjects.SetupGet(o => o.DashboardSettings)
                           .Returns(dashboardSettings);

                var dashboardSettingsService = new Mock<IDashboardSettingsService>();

                dashboardSettingsService.SetupGet(o => o.DashboardSettings)
                                        .Returns(dashboardSettings);

                var dashboardMenuProvider = new DashboardMenuProvider(curveControlService.Object,
                                                                      dashboardSettingsService.Object);

                testObjects.SetupGet(o => o.DashboardMenuProvider).Returns(dashboardMenuProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldReturnDefaultMenuItems_WithoutDailyPricing_When_NoSettings_And_UserIsNotPublisher()
        {
			var user = new UserBuilder().User();

			var settings = new DashboardSettingsCollection();

            var testObjects = new DashboardMenuProviderTestObjectBuilder().WithDashboardSettings(settings)
                                                                          .Build();

            IList<NavigationMenuItemViewModel> result = null;

            using (testObjects.DashboardMenuProvider.MenuItems().Subscribe(items => result = items))
            {
                // ACT
                testObjects.CurrentUser.OnNext(user);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(1));
                Assert.That(result[0].Caption, Is.EqualTo(Headers.PriceDashboard));
                Assert.That(result[0].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[0].PageName, Is.EqualTo("DashboardPage1"));
                Assert.That(result[0].PageNumber, Is.EqualTo(1));
                Assert.That(result[0].ShowInPreview, Is.True);
            }
        }

        [Test]
        public void ShouldReturnDefaultMenuItems_WithDailyPricing_When_NoSettings_And_UserIsCrudePublisher()
        {
			var curveGroups = new[] { new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), true, false) };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

			var settings = new DashboardSettingsCollection();

            var testObjects = new DashboardMenuProviderTestObjectBuilder().WithDashboardSettings(settings)
                                                                          .Build();

            IList<NavigationMenuItemViewModel> result = null;

            using (testObjects.DashboardMenuProvider.MenuItems().Subscribe(items => result = items))
            {
                // ACT
                testObjects.CurrentUser.OnNext(user);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));

                Assert.That(result[0].Caption, Is.EqualTo(Headers.PriceDashboard));
                Assert.That(result[0].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[0].PageName, Is.EqualTo("DashboardPage1"));
                Assert.That(result[0].ShowInPreview, Is.True);

                Assert.That(result[1].Caption, Is.EqualTo(MenuHeaders.DatedBrent));
                Assert.That(result[1].MenuType, Is.EqualTo(MenuType.MarketsDaily));
                Assert.That(result[1].PageName, Is.EqualTo("DailyPricingPage"));
                Assert.That(result[1].ShowInPreview, Is.True);
            }
        }

        [Test]
        public void ShouldGenerateMarketsMenuItems_From_DashboardSettings()
        {
            var curveGroups = new[] { new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), true, false) };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

			var settings =  new DashboardSettingsCollection 
                            {
                                DashboardSettings =
                                [
                                    new() { Name = "Dashboard-1", PageNumber = 1 },
                                    new() { Name = "Dashboard-2", PageNumber = 2 },
                                    new() { Name = "Dashboard-3", PageNumber = 3 },
                                    new() { Name = "Dashboard-4", PageNumber = 4 },
                                    new() { Name = "Dashboard-5", PageNumber = 5 },
                                    new() { Name = "Dashboard-6", PageNumber = 6 },
                                    new() { Name = "Dashboard-7", PageNumber = 7 },
                                    new() { Name = "Dashboard-8", PageNumber = 8 },
                                    new() { Name = "Dashboard-9", PageNumber = 9 },
                                    new() { Name = "Dashboard-10", PageNumber = 10 }
                                ]
                            };

            var testObjects = new DashboardMenuProviderTestObjectBuilder().WithCurrentUser(user)
                                                                          .Build();

            IList<NavigationMenuItemViewModel> result = null;

            using (testObjects.DashboardMenuProvider.MenuItems().Subscribe(items => result = items))
            {
                // ACT
                testObjects.DashboardSettings.OnNext(settings);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(11));

                Assert.That(result[0].Caption, Is.EqualTo("Dashboard-1"));
                Assert.That(result[0].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[0].PageName, Is.EqualTo("DashboardPage1"));
                Assert.That(result[0].ShowInPreview, Is.True);
                Assert.That(result[0].PageNumber, Is.EqualTo(1));

                Assert.That(result[1].Caption, Is.EqualTo("Dashboard-2"));
                Assert.That(result[1].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[1].PageName, Is.EqualTo("DashboardPage2"));
                Assert.That(result[1].ShowInPreview, Is.True);
                Assert.That(result[1].PageNumber, Is.EqualTo(2));

                Assert.That(result[2].Caption, Is.EqualTo("Dashboard-3"));
                Assert.That(result[2].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[2].PageName, Is.EqualTo("DashboardPage3"));
                Assert.That(result[2].ShowInPreview, Is.True);
                Assert.That(result[2].PageNumber, Is.EqualTo(3));

                Assert.That(result[3].Caption, Is.EqualTo("Dashboard-4"));
                Assert.That(result[3].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[3].PageName, Is.EqualTo("DashboardPage4"));
                Assert.That(result[3].ShowInPreview, Is.True);
                Assert.That(result[3].PageNumber, Is.EqualTo(4));

                Assert.That(result[4].Caption, Is.EqualTo("Dashboard-5"));
                Assert.That(result[4].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[4].PageName, Is.EqualTo("DashboardPage5"));
                Assert.That(result[4].ShowInPreview, Is.True);
                Assert.That(result[4].PageNumber, Is.EqualTo(5));

                Assert.That(result[5].Caption, Is.EqualTo("Dashboard-6"));
                Assert.That(result[5].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[5].PageName, Is.EqualTo("DashboardPage6"));
                Assert.That(result[5].ShowInPreview, Is.True);
                Assert.That(result[5].PageNumber, Is.EqualTo(6));

                Assert.That(result[6].Caption, Is.EqualTo("Dashboard-7"));
                Assert.That(result[6].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[6].PageName, Is.EqualTo("DashboardPage7"));
                Assert.That(result[6].ShowInPreview, Is.True);
                Assert.That(result[6].PageNumber, Is.EqualTo(7));

                Assert.That(result[7].Caption, Is.EqualTo("Dashboard-8"));
                Assert.That(result[7].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[7].PageName, Is.EqualTo("DashboardPage8"));
                Assert.That(result[7].ShowInPreview, Is.True);
                Assert.That(result[7].PageNumber, Is.EqualTo(8));

                Assert.That(result[8].Caption, Is.EqualTo("Dashboard-9"));
                Assert.That(result[8].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[8].PageName, Is.EqualTo("DashboardPage9"));
                Assert.That(result[8].ShowInPreview, Is.True);
                Assert.That(result[8].PageNumber, Is.EqualTo(9));

                Assert.That(result[9].Caption, Is.EqualTo("Dashboard-10"));
                Assert.That(result[9].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[9].PageName, Is.EqualTo("DashboardPage10"));
                Assert.That(result[9].ShowInPreview, Is.True);
                Assert.That(result[9].PageNumber, Is.EqualTo(10));

                Assert.That(result[10].Caption, Is.EqualTo(MenuHeaders.DatedBrent));
                Assert.That(result[10].MenuType, Is.EqualTo(MenuType.MarketsDaily));
                Assert.That(result[10].PageName, Is.EqualTo("DailyPricingPage"));
                Assert.That(result[10].ShowInPreview, Is.True);
            }
        }

        [Test]
        public void ShouldNotGenerateMarketsMenuItem_From_DashboardSettings_With_PageNumber_GreaterThanTen()
        {
            var curveGroups = new[] { new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Crude(), true, false) };

            var user = new UserBuilder().WithAuthorizationCurveGroups(curveGroups)
                                        .User();

			var settings = new DashboardSettingsCollection
                           {
                               DashboardSettings =
                               [
                                   new() { Name = "Dashboard-1", PageNumber = 1 },
                                   new() { Name = "Dashboard-11", PageNumber = 11 }
                               ]
                           };
            var testObjects = new DashboardMenuProviderTestObjectBuilder().WithCurrentUser(user)
                                                                          .Build();

            IList<NavigationMenuItemViewModel> result = null;

            using (testObjects.DashboardMenuProvider.MenuItems().Subscribe(items => result = items))
            {
                // ACT
                testObjects.DashboardSettings.OnNext(settings);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));

                Assert.That(result[0].Caption, Is.EqualTo("Dashboard-1"));
                Assert.That(result[0].MenuType, Is.EqualTo(MenuType.Markets));
                Assert.That(result[0].PageName, Is.EqualTo("DashboardPage1"));
                Assert.That(result[0].ShowInPreview, Is.True);

                Assert.That(result[1].Caption, Is.EqualTo(MenuHeaders.DatedBrent));
                Assert.That(result[1].MenuType, Is.EqualTo(MenuType.MarketsDaily));
                Assert.That(result[1].PageName, Is.EqualTo("DailyPricingPage"));
                Assert.That(result[1].ShowInPreview, Is.True);
            }
        }
    }
}
