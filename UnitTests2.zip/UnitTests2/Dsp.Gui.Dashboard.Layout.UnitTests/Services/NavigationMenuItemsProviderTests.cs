﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Layout.Enum;
using Dsp.Gui.Dashboard.Layout.Services;
using Dsp.Gui.Dashboard.Layout.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Services
{
    internal interface INavigationMenuItemsProviderTestObjects
    {
        ISubject<IList<NavigationMenuItemViewModel>> DashboardMenuItems { get; }
        ISubject<IList<NavigationMenuItemGroupViewModel>> UserMenuItems { get; }
        NavigationMenuItemsProvider NavigationMenuItemsProvider { get; }
    }

    [TestFixture]
    public class NavigationMenuItemsProviderTests
    {
        private class NavigationMenuItemsProviderTestObjectBuilder
        {
            public INavigationMenuItemsProviderTestObjects Build()
            {
                var testObjects = new Mock<INavigationMenuItemsProviderTestObjects>();

                var dashboardMenuItems = new Subject<IList<NavigationMenuItemViewModel>>();

                testObjects.SetupGet(o => o.DashboardMenuItems)
                           .Returns(dashboardMenuItems);

                var userMenuItems = new Subject<IList<NavigationMenuItemGroupViewModel>>();

                testObjects.SetupGet(o => o.UserMenuItems)
                           .Returns(userMenuItems);

                var dashBoardMenuProvider = new Mock<IDashboardMenuProvider>();

                dashBoardMenuProvider.Setup(d => d.MenuItems())
                                     .Returns(dashboardMenuItems);

                var userPermissionsProvider = new Mock<IUserPermissionMenuItemsProvider>();

                userPermissionsProvider.Setup(u => u.MenuItems())
                                       .Returns(userMenuItems);

                var navigationMenuItemsProvider = new NavigationMenuItemsProvider(dashBoardMenuProvider.Object, userPermissionsProvider.Object);

                testObjects.SetupGet(o => o.NavigationMenuItemsProvider).Returns(navigationMenuItemsProvider);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldGetMenuItemsFromDashboardAndUserMenuItems()
        {
            var dashboardMenuItems = new[]
            {
                new NavigationMenuItemViewModel("Dashboard", MenuType.Markets, "Page1")
                {
                    ShowInPreview = true
                }
            };

            var userMenuItems = new[]
            {
                new NavigationMenuItemGroupViewModel(
                    MenuHeaders.Publication,
                    MenuGroupType.PublicationControls,
                    [
                        new NavigationMenuItemViewModel(MenuHeaders.CurveSettings, 
                                                        MenuType.PublicationControls,
                                                        "Page2")
                                                        {
                                                            ShowInPreview = true
                                                        }
                    ])
            };

            var testObjects = new NavigationMenuItemsProviderTestObjectBuilder().Build();

            IList<NavigationMenuItemGroupViewModel> result = null;

            using (testObjects.NavigationMenuItemsProvider.MenuItems.Subscribe(menu => result = menu))
            {
                // ACT
                testObjects.DashboardMenuItems.OnNext(dashboardMenuItems);
                testObjects.UserMenuItems.OnNext(userMenuItems);

                // ASSERT
                Assert.That(result.Count, Is.EqualTo(2));
            }
        }

        [Test]
        public void ShouldNotPublishMenuItemsWhenDashboardMenuNotPublished()
        {
            var userMenuItems = new[]
            {
                new NavigationMenuItemGroupViewModel(
                    MenuHeaders.Publication,
                    MenuGroupType.PublicationControls,
                    [
                        new NavigationMenuItemViewModel(MenuHeaders.CurveSettings,
                                                        MenuType.PublicationControls,
                                                        "Page2")
                        {
                            ShowInPreview = true
                        }
                    ])
            };

            var testObjects = new NavigationMenuItemsProviderTestObjectBuilder().Build();

            IList<NavigationMenuItemGroupViewModel> result = null;

            using (testObjects.NavigationMenuItemsProvider.MenuItems.Subscribe(menu => result = menu))
            {
                // ACT
                testObjects.UserMenuItems.OnNext(userMenuItems);

                // ASSERT
                Assert.IsNull(result);
            }
        }

        [Test]
        public void ShouldNotPublishMenuItemsWhenUserMenuNotPublished()
        {
            var dashboardMenuItems = new[]
            {
                new NavigationMenuItemViewModel("Dashboard", MenuType.Markets, "Page1")
                {
                    ShowInPreview = true
                }
            };

            var testObjects = new NavigationMenuItemsProviderTestObjectBuilder().Build();

            IList<NavigationMenuItemGroupViewModel> result = null;

            using (testObjects.NavigationMenuItemsProvider.MenuItems.Subscribe(menu => result = menu))
            {
                // ACT
                testObjects.DashboardMenuItems.OnNext(dashboardMenuItems);

                // ASSERT
                Assert.IsNull(result);
            }
        }

    }
}
