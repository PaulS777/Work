﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.Layout.Services;
using Dsp.Gui.TestObjects;
using Dsp.Gui.UnitTest.Helpers.Builders;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Services
{
	[TestFixture]
	public class UserPermissionsComparerTests
	{
        [Test]
        public void ShouldReturnTrue_When_Equals_With_SameReference()
        {
            var user = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user, user);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Equals_With_User_And_Null()
        {
            var user = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user, null);

            // ASSERT
            Assert.That(result, Is.False);
		}

        [Test]
        public void ShouldReturnFalse_When_Equals_With_Null_And_User()
        {
            var user = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(null, user);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnTrue_When_Equals_With_BothUsers_PermissionsAll()
        {
            var user1 = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 0, true)])
                                         .WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 0, true)])
                                         .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)])
                                         .WithAuthorizationFxCurve([new AuthorisationFxCurve(99, true, true)])
                                         .WithIsAdmin(true)
                                         .User();

            var user2 = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 0, true)])
                                         .WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 0, true)])
                                         .WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)])
                                         .WithAuthorizationFxCurve([new AuthorisationFxCurve(99, true, true)])
                                         .WithIsAdmin(true)
                                         .User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user1, user2);

            // ASSERT
            Assert.That(result, Is.True);
		}

        [Test]
        public void ShouldReturnTrue_When_Equals_With_BothUsers_PermissionsNone()
        {
            var user1 = new UserBuilder().User();
            var user2 = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user1, user2);

            // ASSERT
            Assert.That(result, Is.True);
        }

        [Test]
        public void ShouldReturnFalse_When_Equals_With_IsAdmin_NotEqual()
        {
            var user1 = new UserBuilder().WithIsAdmin(true).User();
            var user2 = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user1, user2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Equals_With_IsPublisher_NotEqual()
        {
            var user1 = new UserBuilder().WithAuthorizationCurveGroups([new AuthorisationCurveGroup(new CurveGroupTestObjectBuilder().Default(), true, true)])
                                         .User();

            var user2 = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user1, user2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Equals_With_IsCurveAdmin_NotEqual()
        {
            var user1 = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdmin.ToString(), 0, true)])
                                         .User();

            var user2 = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user1, user2);

            // ASSERT
            Assert.That(result, Is.False);
        }

        [Test]
        public void ShouldReturnFalse_When_Equals_With_IsCurveAdminApprover_NotEqual()
        {
            var user1 = new UserBuilder().WithAuthorisationUserPermissions([new AuthorisationUserPermission(0, PermissionCategory.CurveAdminApprover.ToString(), 0, true)])
                                         .User();

            var user2 = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user1, user2);

            // ASSERT
            Assert.That(result, Is.False);
        }


        [Test]
        public void ShouldReturnFalse_When_Equals_With_IsFxPublisher_NotEqual()
        {
            var user1 = new UserBuilder().WithAuthorizationFxCurve([new AuthorisationFxCurve(99, true, true)])
                                         .User();

            var user2 = new UserBuilder().User();

            var comparer = new UserPermissionsComparer();

            // ACT
            var result = comparer.Equals(user1, user2);

            // ASSERT
            Assert.That(result, Is.False);
        }
	}
}
