﻿using System;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Controllers;
using Dsp.Gui.Dashboard.Common.ViewModels;
using Dsp.Gui.Dashboard.Layout.Controllers;
using Dsp.Gui.Dashboard.Layout.ViewModels;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Controllers
{
    internal interface IToolBarHeaderViewModelControllerTestObjects
    {
        ITestServiceProvider ServiceProvider { get; }
        ToolBarHeaderViewModel ViewModel { get; }
        ToolBarHeaderViewModelController Controller { get; }
    }

    public interface ITestServiceProvider : IServiceProvider, IAsyncDisposable
    {
    }

    [TestFixture]
    public class ToolBarHeaderViewModelControllerTests
    {
        private class ToolBarHeaderViewModelControllerTestObjectBuilder
        {
            private string _environmentName;
            private bool _isNetworkDeployment;
            private PackageVersion _packageVersion;

            public ToolBarHeaderViewModelControllerTestObjectBuilder WithEnvironmentName(string value)
            {
                _environmentName = value;
                return this;
            }

            public ToolBarHeaderViewModelControllerTestObjectBuilder WithIsNetworkDeployment(bool value)
            {
                _isNetworkDeployment = value;
                return this;
            }

            public ToolBarHeaderViewModelControllerTestObjectBuilder WithPackageVersion(PackageVersion value)
            {
                _packageVersion = value;
                return this;
            }

            public IToolBarHeaderViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IToolBarHeaderViewModelControllerTestObjects>();

                var serviceProvider = new Mock<ITestServiceProvider>();

                serviceProvider.Setup(p => p.DisposeAsync())
                               .Returns(ValueTask.CompletedTask);

                testObjects.SetupGet(o => o.ServiceProvider)
                           .Returns(serviceProvider.Object);

                var configProvider = new Mock<IConfigProvider>();

                var config = Mock.Of<ICommonConfiguration>(c => c.EnvironmentName == _environmentName);

                configProvider.SetupGet(p => p.Configuration)
                              .Returns(config);

                var statusViewModel = new DspSystemStatusViewModel();

                var dspSystemStatusViewModelController = new Mock<IDspSystemStatusViewModelController>();

                dspSystemStatusViewModelController.SetupGet(c => c.ViewModel)
                                                  .Returns(statusViewModel);

                var packageInfoProvider = new Mock<IPackageInfoProvider>();

                packageInfoProvider.SetupGet(p => p.IsNetworkDeployment)
                                   .Returns(_isNetworkDeployment);

                packageInfoProvider.SetupGet(p => p.PackageVersion)
                                   .Returns(_packageVersion);

                var controller = new ToolBarHeaderViewModelController(serviceProvider.Object,
                                                                      configProvider.Object,
                                                                      dspSystemStatusViewModelController.Object,
                                                                      packageInfoProvider.Object,
                                                                      TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.ViewModel)
                           .Returns(controller.ViewModel);

                testObjects.SetupGet(o => o.Controller)
                           .Returns(controller);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPopulateEnvironmentNameAndStatus()
        {
            var testObjects = new ToolBarHeaderViewModelControllerTestObjectBuilder().WithEnvironmentName("DEV")
                                                                                     .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.EnvironmentName, Is.EqualTo("DEV"));
            Assert.IsNotNull(testObjects.ViewModel.DspSystemStatus);
        }

        [Test]
        public void ShouldSetVersionInfo_From_Default_When_IsNetworkDeploymentFalse()
        {
            var testObjects = new ToolBarHeaderViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(false)
                                                                                     .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.Version, Is.EqualTo("Development Build"));
        }

        [Test]
        public void ShouldSetVersionInfo_From_ApplicationStartupInfo_When_IsNetworkDeployment()
        {
            var packageVersion = new PackageVersion(1, 2, 3, 4);

            var testObjects = new ToolBarHeaderViewModelControllerTestObjectBuilder().WithIsNetworkDeployment(true)
                                                                                     .WithPackageVersion(packageVersion)
                                                                                     .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.Version, Is.EqualTo("1.2.3.4"));
        }

        [Test]
        public void ShouldDisposeAsyncServiceProvider_On_WindowClosing()
        {
            var testObjects = new ToolBarHeaderViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.WindowClosingCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ServiceProvider)
                .Verify(s => s.DisposeAsync());
        }
    }
}
