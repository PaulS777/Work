﻿using System;
using System.Reactive.Concurrency;
using System.Reactive.Subjects;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Layout.Controllers;
using Dsp.Gui.Dashboard.Layout.ViewModels;
using Microsoft.Reactive.Testing;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Controllers
{
    internal interface IToolBarMenuProgressViewModelControllerTestObjects
    {
        ISubject<ProgressUpdateArgs> Progress { get; }
        TestScheduler TestScheduler { get; }
        ToolBarMenuProgressViewModelController Controller { get; }
        ToolBarMenuProgressViewModel ViewModel { get; }
    }

    public class ToolBarMenuProgressViewModelControllerTests
    {
        private class ToolBarMenuProgressViewModelControllerTestObjectBuilder
        {
            public IToolBarMenuProgressViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IToolBarMenuProgressViewModelControllerTestObjects>();

                var progress = new Subject<ProgressUpdateArgs>();
                testObjects.SetupGet(o => o.Progress).Returns(progress);

                var progressUpdateService = new Mock<IProgressUpdateService>();
                progressUpdateService.SetupGet(u => u.Progress).Returns(progress);

                var testScheduler = new TestScheduler();
                testObjects.SetupGet(o => o.TestScheduler).Returns(testScheduler);

                var schedulerProvider = new Mock<ISchedulerProvider>();
                schedulerProvider.SetupGet(p => p.Dispatcher).Returns(Scheduler.Immediate);
                schedulerProvider.SetupGet(p => p.TaskPool).Returns(testScheduler);

                var controller = new ToolBarMenuProgressViewModelController(progressUpdateService.Object, 
                                                                            schedulerProvider.Object);

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldShowProgressWithText_When_ProgressUpdated()
        {
            var progress = new ProgressUpdateArgs(true, "update");

            var testObjects = new ToolBarMenuProgressViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Progress.OnNext(progress);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsBusy);
            Assert.IsNotNull(testObjects.ViewModel.ProgressText);
        }

        [Test]
        public void ShouldNotCloseProgress_BeforePeriod()
        {
            var progress = new ProgressUpdateArgs(true, "update");
            var progressUpdate = new ProgressUpdateArgs(false);

            var testObjects = new ToolBarMenuProgressViewModelControllerTestObjectBuilder().Build();

            testObjects.Progress.OnNext(progress);

            // ACT
            testObjects.Progress.OnNext(progressUpdate);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.IsBusy);
        }

        [Test]
        public void ShouldCloseProgress_WhenIsBusyFalse_AfterPeriod()
        {
            var progress = new ProgressUpdateArgs(true, "update");
            var progressUpdate = new ProgressUpdateArgs(false);

            var testObjects = new ToolBarMenuProgressViewModelControllerTestObjectBuilder().Build();

            testObjects.Progress.OnNext(progress);
            testObjects.Progress.OnNext(progressUpdate);

            // ACT
            testObjects.TestScheduler.AdvanceBy(TimeSpan.FromSeconds(3).Ticks);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.IsBusy);
            Assert.IsNull(testObjects.ViewModel.ProgressText);
        }

        [Test]
        public void ShouldNotUpdateProgressWhenDisposed()
        {
            var progress = new ProgressUpdateArgs(true, "update");

            var testObjects = new ToolBarMenuProgressViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Progress.OnNext(progress);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.IsBusy);
        }

        [Test]
        public void ShouldNotDisposeWhenDisposed()
        {
            var progress = new ProgressUpdateArgs(true, "update");

            var testObjects = new ToolBarMenuProgressViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.Progress.OnNext(progress);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.IsBusy);
        }
    }
}
