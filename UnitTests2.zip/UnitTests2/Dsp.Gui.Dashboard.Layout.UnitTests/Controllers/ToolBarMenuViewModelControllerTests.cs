﻿using System;
using System.Reactive.Subjects;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Layout.Controllers;
using Dsp.Gui.Dashboard.Layout.Services;
using Dsp.Gui.Dashboard.Layout.ViewModels;
using Dsp.Gui.Dashboard.Mail.Services;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Controllers
{
    internal interface IToolBarMenuViewModelControllerTestObjects
    {
        IDashboardToolBarService DashboardToolBarService { get; }
        IPublicationControlsToolBarService PublicationControlsToolBarService { get; }
        IPremiumsEditorToolBarService PremiumsEditorToolBarService { get; }
        IUserAdminToolBarService UserAdminToolBarService { get; }
        ICalendarAdminToolBarService CalendarAdminToolBarService { get; }
		ICurveApprovalsToolBarService CurveApprovalsToolBarService { get; }
		IManualCurveEditorToolBarService ManualCurveEditorToolBarService { get; }
        IFormulaCurveEditorToolBarService FormulaCurveEditorToolBarService { get; }
		IFxCurveEditorToolBarService FxCurveEditorToolBarService { get; }
        IProductEditorToolBarService ProductEditorToolBarService { get; }
        IFlatPriceCurveEditorToolBarService FlatPriceCurveEditorToolBarService { get; }
        IPartitionCurveEditorToolBarService PartitionCurveEditorToolBarService { get; }
        IPartitionShiftToolBarService PartitionShiftToolBarService { get; }
        IFxPremiumsToolBarService FxPremiumsToolBarService { get; }
        IChatScraperBrokerAdminToolBarService ChatScraperBrokerAdminToolBarService { get; }
        IChatScraperMarketAdminToolBarService ChatScraperMarketAdminToolBarService { get; }
        IChatScraperProductAdminToolBarService ChatScraperProductAdminToolBarService { get; }
        IChatScraperShortcutsAdminToolBarService ChatScraperShortcutsAdminToolBarService { get; }
        IChatPriceSummaryToolBarService ChatPriceSummaryToolBarService { get; }
        IPublishersToolBarService SpreadAdjustmentToolBarService { get; }
        IPublishersToolBarService IndicativePricingToolBarService { get; }
        IStopTradingToolBarService StopTradingToolBarService { get; }
        IToolBarUpdateService ToolBarUpdateService { get; }
        IMailService MailService { get; }
        IInfoToolBarService InfoToolBarService { get; }
        IMonthEndRollToolBarService MonthEndRollToolBarService { get; }
        IErrorMessageDialogService ErrorMessageDialogService { get; }
        ISubject<SystemRunConnectState> SystemRunConnectState { get; }
        ISubject<bool> InfoOpenState { get; }
        ISubject<int> CurrentMarketsPageNumber { get; }
        ISubject<bool> ShowMarketsToolBar { get; }
        ISubject<bool> ShowPublicationControlToolBar { get; }
        ISubject<bool> ShowPremiumsEditorToolBar { get; }
        ISubject<bool> ShowUserAdminToolBar { get; }
        ISubject<bool> ShowCalendarAdminToolBar { get; }
        ISubject<bool> ShowFxPremiumsToolBar { get; }
		ISubject<bool> ShowCurveApprovalsToolBar { get; }
		ISubject<bool> ShowManualCurveEditorToolBar { get; }
        ISubject<bool> ShowFormulaCurveEditorToolBar { get; }
        ISubject<bool> ShowFxCurveEditorToolBar { get; }
        ISubject<bool> ShowProductCurveEditorToolBar { get; }
        ISubject<bool> ShowFlatPriceBuilderToolBar { get; }
        ISubject<bool> ShowPartitionCurveEditorToolBar { get; }
        ISubject<bool> ShowPartitionShiftToolBar { get; }
        ISubject<bool> ShowChatScraperBrokerAdminToolBar { get; }
        ISubject<bool> ShowChatScraperMarketAdminToolBar { get; }
        ISubject<bool> ShowChatScraperProductAdminToolBar { get; }
        ISubject<bool> ShowChatScraperShortcutsAdminToolBar { get; }
        ISubject<bool> ShowChatPriceSummaryToolBar { get; }
        ISubject<bool> ShowChatMessagesViewerToolBar { get; }
        ISubject<bool> ShowDailyPricingToolBar { get; }
        ISubject<bool> ShowMonthEndRollToolBar { get; }
        IToolBarMenuViewModelController Controller { get; }
        ToolBarMenuViewModel ViewModel { get; }
    }

    [TestFixture]
    public class ToolBarMenuViewModelControllerTests
    {
        private class ToolBarMenuViewModelControllerTestObjectBuilder
        {
            private SystemRunConnectState _connectionRunState;
            private bool _infoHomeOpenState;
            private string _mailDistribution;
            private string _mailDistributionSlack;
            private Exception _sendMailException;
            private string _environmentName;
            private string _logFilePath;
            
            public ToolBarMenuViewModelControllerTestObjectBuilder WithSystemRunConnectState(SystemRunConnectState value)
            {
                _connectionRunState = value;
                return this;
            }

            public ToolBarMenuViewModelControllerTestObjectBuilder WithInfoHomeOpenState(bool value)
            {
                _infoHomeOpenState = value;
                return this;
            }

            public ToolBarMenuViewModelControllerTestObjectBuilder WithMailDistribution(string value)
            {
                _mailDistribution = value;
                return this;
            }

            public ToolBarMenuViewModelControllerTestObjectBuilder WithMailDistributionSlack(string value)
            {
                _mailDistributionSlack = value;
                return this;
            }

            public ToolBarMenuViewModelControllerTestObjectBuilder WithSendMailException(Exception value)
            {
                _sendMailException = value;
                return this;
            }

            public ToolBarMenuViewModelControllerTestObjectBuilder WithLogFilePath(string value)
            {
                _logFilePath = value;
                return this;
            }

            public ToolBarMenuViewModelControllerTestObjectBuilder WithEnvironmentName(string value)
            {
                _environmentName = value;
                return this;
            }

            public IToolBarMenuViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IToolBarMenuViewModelControllerTestObjects>();

                var currentMarketsPageNumber = new BehaviorSubject<int>(0);
                testObjects.SetupGet(o => o.CurrentMarketsPageNumber).Returns(currentMarketsPageNumber);

                var showMarketsToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowMarketsToolBar).Returns(showMarketsToolBar);

                var showPublicationControlsToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowPublicationControlToolBar).Returns(showPublicationControlsToolBar);

                var showPremiumsEditorToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowPremiumsEditorToolBar).Returns(showPremiumsEditorToolBar);

                var showUserAdminToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowUserAdminToolBar).Returns(showUserAdminToolBar);

                var showCalendarAdminToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowCalendarAdminToolBar).Returns(showCalendarAdminToolBar);

                var showFxPremiumsToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowFxPremiumsToolBar).Returns(showFxPremiumsToolBar);

				var showCurveApprovalsToolBar = new BehaviorSubject<bool>(false);
				testObjects.SetupGet(o => o.ShowCurveApprovalsToolBar).Returns(showCurveApprovalsToolBar);

				var showManualCurveEditorToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowManualCurveEditorToolBar).Returns(showManualCurveEditorToolBar);

				var showFormulaCurveEditorToolBar = new BehaviorSubject<bool>(false);
				testObjects.SetupGet(o => o.ShowFormulaCurveEditorToolBar).Returns(showFormulaCurveEditorToolBar);

				var showFxCurveEditorToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowFxCurveEditorToolBar).Returns(showFxCurveEditorToolBar);

                var showProductEditorToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowProductCurveEditorToolBar).Returns(showProductEditorToolBar);

                var showFlatPriceCurveBuilderToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowFlatPriceBuilderToolBar).Returns(showFlatPriceCurveBuilderToolBar);

                var showPartitionCurveEditorToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowPartitionCurveEditorToolBar).Returns(showPartitionCurveEditorToolBar);

                var showPartitionShiftToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowPartitionShiftToolBar).Returns(showPartitionShiftToolBar);

                var showChatScraperBrokerAdminToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowChatScraperBrokerAdminToolBar).Returns(showChatScraperBrokerAdminToolBar);

                var showChatScraperMarketAdminToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowChatScraperMarketAdminToolBar).Returns(showChatScraperMarketAdminToolBar);

                var showChatScraperProductAdminToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowChatScraperProductAdminToolBar).Returns(showChatScraperProductAdminToolBar);

                var showChatScraperShortcutsAdminToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowChatScraperShortcutsAdminToolBar).Returns(showChatScraperShortcutsAdminToolBar);

                var showChatPriceSummaryToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowChatPriceSummaryToolBar).Returns(showChatPriceSummaryToolBar);

                var showChatMessagesToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowChatMessagesViewerToolBar).Returns(showChatMessagesToolBar);

                var showDailyPricingToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowDailyPricingToolBar).Returns(showDailyPricingToolBar);

                var showMonthEndRollToolBar = new BehaviorSubject<bool>(false);
                testObjects.SetupGet(o => o.ShowMonthEndRollToolBar).Returns(showMonthEndRollToolBar);

                var toolBarUpdateService = new Mock<IToolBarUpdateService>();

                toolBarUpdateService.SetupGet(o => o.OnSetCurrentMarketsPageNumber)
                                    .Returns(currentMarketsPageNumber);

                toolBarUpdateService.SetupGet(o => o.OnShowMarketsToolBar)
                                    .Returns(showMarketsToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowPublicationControlToolBar)
                                    .Returns(showPublicationControlsToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowPremiumsEditorToolBar)
                                    .Returns(showPremiumsEditorToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowUserAdminToolBar)
                                    .Returns(showUserAdminToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowCalendarAdminToolBar)
                                    .Returns(showCalendarAdminToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowFxPremiumsToolBar)
                                    .Returns(showFxPremiumsToolBar);

				toolBarUpdateService.SetupGet(o => o.OnShowCurveApprovalsToolBar)
									.Returns(showCurveApprovalsToolBar);

				toolBarUpdateService.SetupGet(o => o.OnShowManualCurveEditorToolBar)
                                    .Returns(showManualCurveEditorToolBar);

				toolBarUpdateService.SetupGet(o => o.OnShowFormulaCurveEditorToolBar)
									.Returns(showFormulaCurveEditorToolBar);

				toolBarUpdateService.SetupGet(o => o.OnShowFxCurveEditorToolBar)
                                    .Returns(showFxCurveEditorToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowProductEditorToolBar)
                                    .Returns(showProductEditorToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowFlatPriceCurveBuilderToolBar)
                                    .Returns(showFlatPriceCurveBuilderToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowPartitionCurveEditorToolBar)
                                    .Returns(showPartitionCurveEditorToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowPartitionShiftToolBar)
                                    .Returns(showPartitionShiftToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowChatScraperBrokerAdminToolBar)
                                    .Returns(showChatScraperBrokerAdminToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowChatScraperMarketAdminToolBar)
                                    .Returns(showChatScraperMarketAdminToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowChatScraperProductAdminToolBar)
                                    .Returns(showChatScraperProductAdminToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowChatScraperShortcutsAdminToolBar)
                                    .Returns(showChatScraperShortcutsAdminToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowChatPriceSummaryToolBar)
                                    .Returns(showChatPriceSummaryToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowChatScraperMessageAdminToolBar)
                                    .Returns(showChatMessagesToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowDailyPricingToolBar)
                                    .Returns(showDailyPricingToolBar);

                toolBarUpdateService.SetupGet(o => o.OnShowMonthEndRollToolBar)
                                    .Returns(showMonthEndRollToolBar);

                testObjects.SetupGet(o => o.ToolBarUpdateService)
                           .Returns(toolBarUpdateService.Object);

                var dashboardToolBarService = new Mock<IDashboardToolBarService>();

                testObjects.SetupGet(o => o.DashboardToolBarService)
                           .Returns(dashboardToolBarService.Object);

                var mailService = new Mock<IMailService>();

                testObjects.SetupGet(o => o.MailService)
                           .Returns(mailService.Object);

                if (_sendMailException != null)
                {
                    mailService.Setup(m => m.CreateFeedbackMail(It.IsAny<string>(),
                                                                It.IsAny<string>(), 
                                                                It.IsAny<string>(), 
                                                                It.IsAny<string>()))
                               .Throws(_sendMailException);
                }

                var publicationControlsToolBarService = new Mock<IPublicationControlsToolBarService>();

                testObjects.SetupGet(o => o.PublicationControlsToolBarService)
                           .Returns(publicationControlsToolBarService.Object);

                var premiumsEditorToolBarService = new Mock<IPremiumsEditorToolBarService>();

                testObjects.SetupGet(o => o.PremiumsEditorToolBarService)
                           .Returns(premiumsEditorToolBarService.Object);

                var userAdminToolBarService = new Mock<IUserAdminToolBarService>();

                testObjects.SetupGet(o => o.UserAdminToolBarService)
                           .Returns(userAdminToolBarService.Object);

                var calendarToolBarService = new Mock<ICalendarAdminToolBarService>();

                testObjects.SetupGet(o => o.CalendarAdminToolBarService)
                           .Returns(calendarToolBarService.Object);

				var curveApprovalsToolBarService = new Mock<ICurveApprovalsToolBarService>();

				testObjects.SetupGet(o => o.CurveApprovalsToolBarService)
						   .Returns(curveApprovalsToolBarService.Object);

                var manualCurveEditorToolBarService = new Mock<IManualCurveEditorToolBarService>();

                testObjects.SetupGet(o => o.ManualCurveEditorToolBarService)
                           .Returns(manualCurveEditorToolBarService.Object);

				var formulaCurveEditorToolBarService = new Mock<IFormulaCurveEditorToolBarService>();

				testObjects.SetupGet(o => o.FormulaCurveEditorToolBarService)
						   .Returns(formulaCurveEditorToolBarService.Object);

				var fxCurveEditorToolBarService = new Mock<IFxCurveEditorToolBarService>();

                testObjects.SetupGet(o => o.FxCurveEditorToolBarService)
                           .Returns(fxCurveEditorToolBarService.Object);

                var productEditorToolBarService = new Mock<IProductEditorToolBarService>();

                testObjects.SetupGet(o => o.ProductEditorToolBarService)
                    .Returns(productEditorToolBarService.Object);

                var flatPriceToolBarService = new Mock<IFlatPriceCurveEditorToolBarService>();

                testObjects.SetupGet(o => o.FlatPriceCurveEditorToolBarService)
                           .Returns(flatPriceToolBarService.Object);

                var partitionCurveEditorToolBarService = new Mock<IPartitionCurveEditorToolBarService>();

                testObjects.SetupGet(o => o.PartitionCurveEditorToolBarService)
                           .Returns(partitionCurveEditorToolBarService.Object);

                var partitionShiftToolBarService = new Mock<IPartitionShiftToolBarService>();

                testObjects.SetupGet(o => o.PartitionShiftToolBarService)
                           .Returns(partitionShiftToolBarService.Object);

                var fxPremiumsToolBarService = new Mock<IFxPremiumsToolBarService>();

                testObjects.SetupGet(o => o.FxPremiumsToolBarService)
                           .Returns(fxPremiumsToolBarService.Object);

                var chatScraperBrokerAdminToolBarService = new Mock<IChatScraperBrokerAdminToolBarService>();

                testObjects.SetupGet(o => o.ChatScraperBrokerAdminToolBarService)
                           .Returns(chatScraperBrokerAdminToolBarService.Object);

                var chatScraperMarketAdminToolBarService = new Mock<IChatScraperMarketAdminToolBarService>();

                testObjects.SetupGet(o => o.ChatScraperMarketAdminToolBarService)
                           .Returns(chatScraperMarketAdminToolBarService.Object);

                var chatScraperProductAdminToolBarService = new Mock<IChatScraperProductAdminToolBarService>();

                testObjects.SetupGet(o => o.ChatScraperProductAdminToolBarService)
                           .Returns(chatScraperProductAdminToolBarService.Object);

                var chatScraperShortcutsAdminToolBarService = new Mock<IChatScraperShortcutsAdminToolBarService>();

                testObjects.SetupGet(o => o.ChatScraperShortcutsAdminToolBarService)
                           .Returns(chatScraperShortcutsAdminToolBarService.Object);

                var chatPriceSummaryToolBarService = new Mock<IChatPriceSummaryToolBarService>();

                testObjects.SetupGet(o => o.ChatPriceSummaryToolBarService)
                           .Returns(chatPriceSummaryToolBarService.Object);

                var spreadAdjustmentToolBarService = new Mock<IPublishersToolBarService>();

                testObjects.SetupGet(o => o.SpreadAdjustmentToolBarService)
                           .Returns(spreadAdjustmentToolBarService.Object);

                var indicativePricingToolBarService = new Mock<IPublishersToolBarService>();

                testObjects.SetupGet(o => o.IndicativePricingToolBarService)
                           .Returns(indicativePricingToolBarService.Object);

                var stopTradingToolBarService = new Mock<IStopTradingToolBarService>();

                testObjects.SetupGet(o => o.StopTradingToolBarService)
                           .Returns(stopTradingToolBarService.Object);

                var monthEndRollToolBarService = new Mock<IMonthEndRollToolBarService>();

                testObjects.SetupGet(o => o.MonthEndRollToolBarService)
                           .Returns(monthEndRollToolBarService.Object);

                var runState = new BehaviorSubject<SystemRunConnectState>(_connectionRunState);

                testObjects.SetupGet(o => o.SystemRunConnectState)
                           .Returns(runState);

                var connectionRunStateMonitor = new Mock<IConnectionRunStateMonitor>();

                connectionRunStateMonitor.SetupGet(c => c.RunState)
                                         .Returns(runState);

                var infoOpenState = new BehaviorSubject<bool>(_infoHomeOpenState);

                testObjects.SetupGet(o => o.InfoOpenState)
                           .Returns(infoOpenState);

                var infoToolBarService = new Mock<IInfoToolBarService>();

                infoToolBarService.SetupGet(i => i.InfoOpenState)
                                  .Returns(infoOpenState);

                testObjects.SetupGet(o => o.InfoToolBarService)
                           .Returns(infoToolBarService.Object);

                var configProvider = new Mock<IConfigProvider>();

                var commonConfig = Mock.Of<ICommonConfiguration>(c => c.HelpDistribution == _mailDistribution
                                                                      && c.HelpDistributionSlack == _mailDistributionSlack
                                                                      && c.EnvironmentName == _environmentName);

                configProvider.SetupGet(c => c.Configuration)
                              .Returns(commonConfig);

                var errorMessageDialogService = new Mock<IErrorMessageDialogService>();

                testObjects.SetupGet(o => o.ErrorMessageDialogService)
                           .Returns(errorMessageDialogService.Object);

                var logFilePathService = new Mock<ILogFilePathService>();

                logFilePathService.Setup(l => l.GetLogFilePath(It.IsAny<string>()))
                                  .Returns(_logFilePath);

                var toolBarService = new Mock<IToolBarService>();

                toolBarService.SetupGet(tb => tb.Dashboard).Returns(dashboardToolBarService.Object);
                toolBarService.SetupGet(tb => tb.PublicationControls).Returns(publicationControlsToolBarService.Object);
                toolBarService.SetupGet(tb => tb.PremiumsEditor).Returns(premiumsEditorToolBarService.Object);
                toolBarService.SetupGet(tb => tb.UserAdmin).Returns(userAdminToolBarService.Object);
                toolBarService.SetupGet(tb => tb.CalendarAdmin).Returns(calendarToolBarService.Object);
				toolBarService.SetupGet(tb => tb.CurveApprovals).Returns(curveApprovalsToolBarService.Object);
                toolBarService.SetupGet(tb => tb.ManualCurveEditor).Returns(manualCurveEditorToolBarService.Object);
				toolBarService.SetupGet(tb => tb.FormulaCurveEditor).Returns(formulaCurveEditorToolBarService.Object);
				toolBarService.SetupGet(tb => tb.FxCurveEditor).Returns(fxCurveEditorToolBarService.Object);
                toolBarService.SetupGet(tb => tb.ProductEditor).Returns(productEditorToolBarService.Object);
                toolBarService.SetupGet(tb => tb.FlatPriceCurveEditor).Returns(flatPriceToolBarService.Object);
                toolBarService.SetupGet(tb => tb.PartitionCurveEditor).Returns(partitionCurveEditorToolBarService.Object);
                toolBarService.SetupGet(tb => tb.PartitionShift).Returns(partitionShiftToolBarService.Object);
                toolBarService.SetupGet(tb => tb.FxPremiums).Returns(fxPremiumsToolBarService.Object);
                toolBarService.SetupGet(tb => tb.ChatPriceBrokerAdmin).Returns(chatScraperBrokerAdminToolBarService.Object);
                toolBarService.SetupGet(tb => tb.ChatScraperMarketAdmin).Returns(chatScraperMarketAdminToolBarService.Object);
                toolBarService.SetupGet(tb => tb.ChatScraperProductAdmin).Returns(chatScraperProductAdminToolBarService.Object);
                toolBarService.SetupGet(tb => tb.ChatScraperShortcutsAdmin).Returns(chatScraperShortcutsAdminToolBarService.Object);
                toolBarService.SetupGet(tb => tb.ChatPriceSummary).Returns(chatPriceSummaryToolBarService.Object);
                toolBarService.SetupGet(tb => tb.SpreadAdjustment).Returns(spreadAdjustmentToolBarService.Object);
                toolBarService.SetupGet(tb => tb.IndicativePricing).Returns(indicativePricingToolBarService.Object);
                toolBarService.SetupGet(tb => tb.StopTrading).Returns(stopTradingToolBarService.Object);
                toolBarService.SetupGet(tb => tb.MonthEndRoll).Returns(monthEndRollToolBarService.Object);
                toolBarService.SetupGet(tb => tb.Mail).Returns(mailService.Object);
                toolBarService.SetupGet(tb => tb.Info).Returns(infoToolBarService.Object);

                var controller = new ToolBarMenuViewModelController(toolBarService.Object, 
                                                                    configProvider.Object,
                                                                    toolBarUpdateService.Object,
                                                                    connectionRunStateMonitor.Object,
                                                                    errorMessageDialogService.Object,
                                                                    logFilePathService.Object,
                                                                    TestMocks.GetSchedulerProvider().Object, 
                                                                    TestMocks.GetLoggerFactory().Object);

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldDisableMenuItems_When_Connecting_With_InfoClosed()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Reconnecting)
                                                                                   .WithInfoHomeOpenState(false)
                                                                                   .Build();

            // ASSERT
            Assert.That(testObjects.ViewModel.MenuItemsEnabled, Is.False);
        }

        [Test]
        public void ShouldEnableMenuItems_On_Connected_With_InfoClosed()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.NotSet)
                                                                                   .WithInfoHomeOpenState(false)
                                                                                   .Build();

            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.Connected);

            // ASSERT
            Assert.That(testObjects.ViewModel.MenuItemsEnabled, Is.True);
        }

        [Test]
        public void ShouldEnableMenuItems_On_Reconnected_With_InfoClosed()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Reconnecting)
                                                                                   .WithInfoHomeOpenState(false)
                                                                                   .Build();

            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.Reconnected);

            // ASSERT
            Assert.That(testObjects.ViewModel.MenuItemsEnabled, Is.True);
        }

        [Test]
        public void ShouldDisableMenuItems_When_InfoOpen_With_Connected()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                   .WithInfoHomeOpenState(false)
                                                                                   .Build();

            // ACT
            testObjects.InfoOpenState.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.MenuItemsEnabled, Is.False);
        }

        [Test]
        public void ShouldEnableMenuItems_When_InfoClosed_With_Connected()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.Connected)
                                                                                   .WithInfoHomeOpenState(true)
                                                                                   .Build();
            // ACT
            testObjects.InfoOpenState.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.MenuItemsEnabled, Is.True);
        }

        [Test]
        public void ShouldNotEnableMenuItems_On_Connected_With_InfoOpen()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().WithSystemRunConnectState(SystemRunConnectState.NotSet)
                                                                                   .WithInfoHomeOpenState(true)
                                                                                   .Build();
            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.Connected);

            // ASSERT
            Assert.That(testObjects.ViewModel.MenuItemsEnabled, Is.False);
        }

        [Test]
        public void ShouldDisableMenuItems_On_FailedStartup()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.NotSet);

            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.FailedStartup);

            // ASSERT
            Assert.That(testObjects.ViewModel.MenuItemsEnabled, Is.False);
        }

        [Test]
        public void ShouldAttachToolBars_On_FirstConnected()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.SystemRunConnectState.OnNext(SystemRunConnectState.Connected);

            // ASSERT
            Mock.Get(testObjects.DashboardToolBarService).Verify(c => c.Attach(testObjects.ViewModel.DashboardToolBar));
            Mock.Get(testObjects.PublicationControlsToolBarService).Verify(c => c.Attach(testObjects.ViewModel.PublicationControlsToolBar));
            Mock.Get(testObjects.PremiumsEditorToolBarService).Verify(c => c.Attach(testObjects.ViewModel.PremiumsEditorToolBar));
            Mock.Get(testObjects.UserAdminToolBarService).Verify(c => c.Attach(testObjects.ViewModel.UserAdminToolBar));
            Mock.Get(testObjects.CalendarAdminToolBarService).Verify(c => c.Attach(testObjects.ViewModel.CalendarAdminToolBar));
			Mock.Get(testObjects.CurveApprovalsToolBarService).Verify(c => c.Attach(testObjects.ViewModel.CurveApprovalsToolBar));
			Mock.Get(testObjects.ManualCurveEditorToolBarService).Verify(c => c.Attach(testObjects.ViewModel.ManualCurveEditorToolBar));
			Mock.Get(testObjects.FormulaCurveEditorToolBarService).Verify(c => c.Attach(testObjects.ViewModel.FormulaCurveEditorToolBar));
			Mock.Get(testObjects.FxCurveEditorToolBarService).Verify(c => c.Attach(testObjects.ViewModel.FxCurveEditorToolBar));
			Mock.Get(testObjects.FlatPriceCurveEditorToolBarService).Verify(c => c.Attach(testObjects.ViewModel.FlatPriceCurveBuilderToolBar));
            Mock.Get(testObjects.ProductEditorToolBarService).Verify(c => c.Attach(testObjects.ViewModel.ProductEditorToolBar));
            Mock.Get(testObjects.PartitionCurveEditorToolBarService).Verify(c => c.Attach(testObjects.ViewModel.PartitionCurveEditorToolBar));
            Mock.Get(testObjects.PartitionShiftToolBarService).Verify(c => c.Attach(testObjects.ViewModel.PartitionShiftToolBar));
            Mock.Get(testObjects.FxPremiumsToolBarService).Verify(c => c.Attach(testObjects.ViewModel.FxPremiumsToolBar));
            Mock.Get(testObjects.ChatScraperBrokerAdminToolBarService).Verify(c => c.Attach(testObjects.ViewModel.ChatScraperBrokerAdminToolBar));
            Mock.Get(testObjects.ChatScraperMarketAdminToolBarService).Verify(c => c.Attach(testObjects.ViewModel.ChatScraperMarketAdminToolBar));
            Mock.Get(testObjects.ChatScraperProductAdminToolBarService).Verify(c => c.Attach(testObjects.ViewModel.ChatScraperProductAdminToolBar));
            Mock.Get(testObjects.ChatScraperShortcutsAdminToolBarService).Verify(c => c.Attach(testObjects.ViewModel.ChatScraperShortcutsAdminToolBar));
            Mock.Get(testObjects.ChatPriceSummaryToolBarService).Verify(c => c.Attach(testObjects.ViewModel.ChatPriceSummaryToolBar));
            Mock.Get(testObjects.SpreadAdjustmentToolBarService).Verify(c => c.Attach(testObjects.ViewModel.SpreadAdjustmentToolBar));
            Mock.Get(testObjects.IndicativePricingToolBarService).Verify(c => c.Attach(testObjects.ViewModel.IndicativePricingToolBar));
            Mock.Get(testObjects.StopTradingToolBarService).Verify(c => c.Attach(testObjects.ViewModel.StopTradingToolBar));
            Mock.Get(testObjects.MonthEndRollToolBarService).Verify(c => c.Attach(testObjects.ViewModel.MonthEndRollToolBar));
        }

        [Test]
        public void ShouldSendMail_OnSendMailCommand()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().WithMailDistribution("mail")
                                                                                   .WithMailDistributionSlack("slack")
                                                                                   .WithEnvironmentName("DEV")
                                                                                   .WithLogFilePath("log.txt")
                                                                                   .Build();

            // ACT
            testObjects.ViewModel.SendMailCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.MailService).Verify(ms => ms.CreateFeedbackMail("mail", "slack", "log.txt", "DEV"));
        }

        [Test]
        public void ShouldShowErrorDialog_OnSendMailException()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().WithSendMailException(new Exception("error"))
                                                                                   .Build();

            // ACT
            testObjects.ViewModel.SendMailCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.ErrorMessageDialogService)
                .Verify(d => d.ShowDialog(It.Is<ErrorMessageDialogArgs>(args => args.ShowSendFeedback == false)));
        }

        [Test]
        public void ShouldShowReleaseNotesMenu_On_Show()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ViewModel.ShowInfoCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.InfoToolBarService).Verify(i => i.SetShowInfo());
        }

        [Test]
        public void ShouldShowMarketsToolBarItems_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowMarketsToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.MarketsToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideMarketsToolBarItems_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.MarketsToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowMarketsToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.MarketsToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowPublicationControlToolBarItems_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowPublicationControlToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.PublicationControlsToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldShowUserAdminToolBarItems_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowUserAdminToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.UserAdminToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldShowCalendarAdminToolBarItems_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowCalendarAdminToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.CalendarAdminToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideUserAdminToolBarItems_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.UserAdminToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowUserAdminToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.UserAdminToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowFxPremiumsToolBarItems_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowFxPremiumsToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.FxPremiumsToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideFxPremiumsToolBarItems_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.FxPremiumsToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowFxPremiumsToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.FxPremiumsToolBar.ShowToolBar, Is.False);
        }

		[Test]
		public void ShouldShowCurveApprovalsToolBar_OnToolBarServicePublishTrue()
		{
			var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

			// ACT
			testObjects.ShowCurveApprovalsToolBar.OnNext(true);

			// ASSERT
			Assert.That(testObjects.ViewModel.CurveApprovalsToolBar.ShowToolBar, Is.True);
		}

		[Test]
		public void ShouldHideCurveApprovalsToolBar_OnToolBarServicePublishFalse()
		{
			var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

			testObjects.ViewModel.CurveApprovalsToolBar.ShowToolBar = true;

			// ACT
			testObjects.ShowCurveApprovalsToolBar.OnNext(false);

			// ASSERT
			Assert.That(testObjects.ViewModel.CurveApprovalsToolBar.ShowToolBar, Is.False);
		}

		[Test]
        public void ShouldShowManualCurveEditorToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowManualCurveEditorToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualCurveEditorToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideManualCurveEditorToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ManualCurveEditorToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowManualCurveEditorToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualCurveEditorToolBar.ShowToolBar, Is.False);
        }

		[Test]
		public void ShouldShowFormulaCurveEditorToolBar_OnToolBarServicePublishTrue()
		{
			var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

			// ACT
			testObjects.ShowFormulaCurveEditorToolBar.OnNext(true);

			// ASSERT
			Assert.That(testObjects.ViewModel.FormulaCurveEditorToolBar.ShowToolBar, Is.True);
		}

		[Test]
		public void ShouldHideFormulaCurveEditorToolBar_OnToolBarServicePublishFalse()
		{
			var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

			testObjects.ViewModel.FormulaCurveEditorToolBar.ShowToolBar = true;

			// ACT
			testObjects.ShowFormulaCurveEditorToolBar.OnNext(false);

			// ASSERT
			Assert.That(testObjects.ViewModel.FormulaCurveEditorToolBar.ShowToolBar, Is.False);
		}

		[Test]
        public void ShouldShowFxCurveEditorToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowFxCurveEditorToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.FxCurveEditorToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideFxCurveEditorToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.FxCurveEditorToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowFxCurveEditorToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ManualCurveEditorToolBar.ShowToolBar, Is.False);
        }
        [Test]
        public void ShouldShowProductEditorToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowProductCurveEditorToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ProductEditorToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideProductEditorToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ProductEditorToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowProductCurveEditorToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ProductEditorToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowFlatPriceCurveBuilderToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowFlatPriceBuilderToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.FlatPriceCurveBuilderToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideFlatPriceCurveBuilderToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.FlatPriceCurveBuilderToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowFlatPriceBuilderToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.FlatPriceCurveBuilderToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowPartitionCurveEditorToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowPartitionCurveEditorToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.PartitionCurveEditorToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHidePartitionCurveEditorToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.PartitionCurveEditorToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowPartitionCurveEditorToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.PartitionCurveEditorToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowPartitionShiftToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowPartitionShiftToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.PartitionShiftToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHidePartitionShiftToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.PartitionShiftToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowPartitionShiftToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.PartitionShiftToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowChatScraperBrokerAdminToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowChatScraperBrokerAdminToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperBrokerAdminToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideChatScraperBrokerAdminToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ChatScraperBrokerAdminToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowChatScraperBrokerAdminToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperBrokerAdminToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowChatScraperMarketAdminToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowChatScraperMarketAdminToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperMarketAdminToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideChatScraperMarketAdminToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ChatScraperMarketAdminToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowChatScraperMarketAdminToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperMarketAdminToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowChatScraperProductAdminToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowChatScraperProductAdminToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperProductAdminToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideChatScraperProductAdminToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ChatScraperProductAdminToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowChatScraperProductAdminToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperProductAdminToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowChatScraperShortcutsAdminToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowChatScraperShortcutsAdminToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperShortcutsAdminToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideChatScraperShortcutsAdminToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ChatScraperShortcutsAdminToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowChatScraperShortcutsAdminToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperShortcutsAdminToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowChatPriceSummaryToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowChatPriceSummaryToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatPriceSummaryToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideChatPriceSummaryToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ChatPriceSummaryToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowChatPriceSummaryToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatPriceSummaryToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowChatMessagesViewerToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowChatMessagesViewerToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperMessageAdminToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideChatMessagesViewerToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.ChatScraperMessageAdminToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowChatMessagesViewerToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.ChatScraperMessageAdminToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowDailyPriceToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowDailyPricingToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.DailyPricingToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideDailyPriceToolBar_OnDailyPriceServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.DailyPricingToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowDailyPricingToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.DailyPricingToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowMonthEndRollToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowMonthEndRollToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHideShowMonthEndRollToolBar_OnToolBarServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.MonthEndRollToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowMonthEndRollToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.MonthEndRollToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldShowPremiumsEditorToolBar_OnToolBarServicePublishTrue()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.ShowPremiumsEditorToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.PremiumsEditorToolBar.ShowToolBar, Is.True);
        }

        [Test]
        public void ShouldHidePremiumsEditorToolBar_OnDailyPriceServicePublishFalse()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.ViewModel.PremiumsEditorToolBar.ShowToolBar = true;

            // ACT
            testObjects.ShowPremiumsEditorToolBar.OnNext(false);

            // ASSERT
            Assert.That(testObjects.ViewModel.PremiumsEditorToolBar.ShowToolBar, Is.False);
        }

        [Test]
        public void ShouldDisposeToolBarServices_On_Dispose()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.DashboardToolBarService).Verify(t => t.Dispose());
            Mock.Get(testObjects.PublicationControlsToolBarService).Verify(t => t.Dispose());
            Mock.Get(testObjects.SpreadAdjustmentToolBarService).Verify(t => t.Dispose());
            Mock.Get(testObjects.IndicativePricingToolBarService).Verify(t => t.Dispose());
            Mock.Get(testObjects.StopTradingToolBarService).Verify(t => t.Dispose());
            Mock.Get(testObjects.MonthEndRollToolBarService).Verify(t => t.Dispose());
        }

        [Test]
        public void ShouldNotDisposeToolBarServices_When_Disposed()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();

            // ASSERT
            Mock.Get(testObjects.DashboardToolBarService).Verify(t => t.Dispose(), Times.Once);
            Mock.Get(testObjects.PublicationControlsToolBarService).Verify(t => t.Dispose(), Times.Once);
            Mock.Get(testObjects.SpreadAdjustmentToolBarService).Verify(t => t.Dispose(), Times.Once);
            Mock.Get(testObjects.IndicativePricingToolBarService).Verify(t => t.Dispose(), Times.Once);
            Mock.Get(testObjects.StopTradingToolBarService).Verify(t => t.Dispose(), Times.Once);
            Mock.Get(testObjects.MonthEndRollToolBarService).Verify(t => t.Dispose(), Times.Once);
        }

        [Test]
        public void ShouldNotShowToolBars_When_Disposed()
        {
            var testObjects = new ToolBarMenuViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.ShowMarketsToolBar.OnNext(true);
            testObjects.ShowUserAdminToolBar.OnNext(true);
            testObjects.ShowPublicationControlToolBar.OnNext(true);
            testObjects.ShowPremiumsEditorToolBar.OnNext(true);
            testObjects.ShowFxPremiumsToolBar.OnNext(true);
            testObjects.ShowFlatPriceBuilderToolBar.OnNext(true);
            testObjects.ShowPartitionCurveEditorToolBar.OnNext(true);
            testObjects.ShowPartitionShiftToolBar.OnNext(true);
            testObjects.ShowChatScraperBrokerAdminToolBar.OnNext(true);
            testObjects.ShowChatScraperMarketAdminToolBar.OnNext(true);
            testObjects.ShowChatScraperProductAdminToolBar.OnNext(true);
            testObjects.ShowChatScraperShortcutsAdminToolBar.OnNext(true);
            testObjects.ShowChatPriceSummaryToolBar.OnNext(true);
            testObjects.ShowDailyPricingToolBar.OnNext(true);
            testObjects.ShowMonthEndRollToolBar.OnNext(true);

            // ASSERT
            Assert.That(testObjects.ViewModel.MarketsToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.UserAdminToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.PublicationControlsToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.PremiumsEditorToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.FxPremiumsToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.FlatPriceCurveBuilderToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.PartitionCurveEditorToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.PartitionShiftToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.ChatScraperBrokerAdminToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.ChatScraperMarketAdminToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.ChatScraperProductAdminToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.ChatScraperShortcutsAdminToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.ChatPriceSummaryToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.DailyPricingToolBar.ShowToolBar, Is.False);
            Assert.That(testObjects.ViewModel.MonthEndRollToolBar.ShowToolBar, Is.False);
        }
    }
}
