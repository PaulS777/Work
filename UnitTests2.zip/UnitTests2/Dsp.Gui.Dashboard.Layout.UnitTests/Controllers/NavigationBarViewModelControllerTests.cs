﻿using System;
using System.Collections.Generic;
using System.Reactive.Subjects;
using System.Windows.Threading;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Navigation;
using Dsp.Gui.Dashboard.Layout.Controllers;
using Dsp.Gui.Dashboard.Layout.Enum;
using Dsp.Gui.Dashboard.Layout.Services;
using Dsp.Gui.Dashboard.Layout.ViewModels;
using Dsp.Gui.Dashboard.Layout.Views;
using Dsp.Gui.TestObjects;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Controllers
{
    internal interface INavigationBarViewModelControllerTestObjects
    {
        IToolBarUpdateService ToolBarUpdateService { get; }
        IPagesLoadedService PagesLoadedService { get; }
        ISubject<IList<NavigationMenuItemGroupViewModel>> MenuItems { get; }
        INavigationMenuItemsProvider NavigationMenuItemsProvider { get; }
        INavigationMenuEnabledService NavigationMenuService { get; }
        IDispatcherService DispatcherService { get; }
        ISubject<bool> NavigationEnabled { get; }
        NavigationBarViewModel ViewModel { get; }
        NavigationBarViewModelController Controller { get; }
    }

    [TestFixture]
    public class NavigationBarViewModelControllerTests
    {
        private class NavigationBarViewModelControllerTestObjectBuilder
        {
            private bool _navigationEnabled;

            public NavigationBarViewModelControllerTestObjectBuilder WithNavigationEnabled(bool value)
            {
                _navigationEnabled = value;
                return this;
            }

            public INavigationBarViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<INavigationBarViewModelControllerTestObjects>();

                var marketsToolBarService = new Mock<IToolBarUpdateService>();

                testObjects.SetupGet(o => o.ToolBarUpdateService)
                           .Returns(marketsToolBarService.Object);

                var menuItems = new Subject<IList<NavigationMenuItemGroupViewModel>>();

                testObjects.SetupGet(o => o.MenuItems)
                           .Returns(menuItems);

                var navigationMenuItemsProvider = new Mock<INavigationMenuItemsProvider>();

                navigationMenuItemsProvider.SetupGet(p => p.MenuItems)
                                           .Returns(menuItems);

                testObjects.SetupGet(o => o.NavigationMenuItemsProvider)
                           .Returns(navigationMenuItemsProvider.Object);

                var navigationEnabled = new Subject<bool>();

                testObjects.SetupGet(o => o.NavigationEnabled)
                           .Returns(navigationEnabled);

                var navigationMenuService = new Mock<INavigationMenuEnabledService>();

                navigationMenuService.SetupGet(n => n.NavigationEnabled)
                                     .Returns(navigationEnabled);

                testObjects.SetupGet(o => o.NavigationMenuService)
                           .Returns(navigationMenuService.Object);

                var toolBarUpdateService = new Mock<IToolBarUpdateService>();

                testObjects.SetupGet(o => o.ToolBarUpdateService)
                           .Returns(toolBarUpdateService.Object);

                var dispatcher = new Mock<IDispatcherService>();

                dispatcher.Setup(d => d.BeginInvoke(It.IsAny<Dispatcher>(), It.IsAny<Action>(), It.IsAny<DispatcherPriority>()))
                          .Callback<Dispatcher, Action, DispatcherPriority>((_, action, _) => action());

                testObjects.SetupGet(o => o.DispatcherService).Returns(dispatcher.Object);

                var pagesLoadedService = new Mock<IPagesLoadedService>();

                testObjects.SetupGet(o => o.PagesLoadedService)
                           .Returns(pagesLoadedService.Object);

                var controller = new NavigationBarViewModelController(navigationMenuItemsProvider.Object,
                                                                      navigationMenuService.Object,
                                                                      toolBarUpdateService.Object,
                                                                      pagesLoadedService.Object,
                                                                      dispatcher.Object,
                                                                      TestMocks.GetSchedulerProvider().Object);

                controller.ViewModel.NavigationEnabled = _navigationEnabled;

                testObjects.SetupGet(o => o.Controller).Returns(controller);
                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShouldPopulateMenuFromProvider()
        {
            var menu = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets, 
                    new List<NavigationMenuItemViewModel>())
            };

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MenuItems.OnNext(menu);

            // ASSERT
            Assert.That(testObjects.ViewModel.GroupMenuItems.Count, Is.EqualTo(1));
        }

        [Test]
        public void ShouldSetSelectedMenuItemAsFirstMarketsDashboard_On_MenuItemsLoadedFirstTime()
        {
            var menu = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>
                    {
                        new("Dashboard1", MenuType.Markets, "Page1"),
                        new("Dashboard2", MenuType.Markets, "Page2")
                    }),

                new("Controls",
                    MenuGroupType.PublicationControls,
                    new List<NavigationMenuItemViewModel>())
            };

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.MenuItems.OnNext(menu);

            // ASSERT
            Mock.Get(testObjects.DispatcherService)
                .Verify(ds => ds.BeginInvoke(It.IsAny<Dispatcher>(), It.IsAny<Action>(), DispatcherPriority.Loaded));

            Assert.That(testObjects.ViewModel.SelectedMenuItem.Caption, Is.EqualTo("Dashboard1"));
        }

        [Test]
        public void ShouldSetSelectedMenuItemAsLastMarketsDashboard_On_MenuItemsUpdated_With_DashboardAdded()
        {
            var loaded = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>
                    {
                        new("Dashboard1", MenuType.Markets, "Page1")
                    })
            };

            var updated = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>
                    {
                        new("Dashboard1", MenuType.Markets, "Page1"),
                        new("Dashboard2", MenuType.Markets, "Page2")
                    })
            };

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.MenuItems.OnNext(loaded);
            Mock.Get(testObjects.DispatcherService).Invocations.Clear();

            // ACT
            testObjects.MenuItems.OnNext(updated);

            // ASSERT
            Mock.Get(testObjects.DispatcherService)
                .Verify(ds => ds.BeginInvoke(It.IsAny<Dispatcher>(), It.IsAny<Action>(), DispatcherPriority.Loaded));

            Assert.That(testObjects.ViewModel.SelectedMenuItem.Caption, Is.EqualTo("Dashboard2"));
        }

        [Test]
        public void ShouldSetSelectedMenuItemAsFirstMarketsDashboard_On_MenuItemsUpdated_With_DashboardRemoved()
        {
            var loaded = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>
                    {
                        new("Dashboard1", MenuType.Markets, "Page1"),
                        new("Dashboard2", MenuType.Markets, "Page2"),
                        new("Dashboard3", MenuType.Markets, "Page3")
                    })
            };

            var updated = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>
                    {
                        new("Dashboard1", MenuType.Markets, "Page1"),
                        new("Dashboard2", MenuType.Markets, "Page2")
                    })
            };

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.MenuItems.OnNext(loaded);

            testObjects.ViewModel.SelectedMenuItem = testObjects.ViewModel.GroupMenuItems[0].MenuItems[1];

            Mock.Get(testObjects.DispatcherService).Invocations.Clear();

            // ACT
            testObjects.MenuItems.OnNext(updated);

            // ASSERT
            Assert.That(testObjects.ViewModel.SelectedMenuItem.Caption, Is.EqualTo("Dashboard1"));
        }

        [Test]
        public void ShouldNotSetSelectedMenuItem_On_MenuItemsUpdated_With_SameDashboards()
        {
            var loaded = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>
                    {
                        new("Dashboard1", MenuType.Markets, "Page1"),
                        new("Dashboard2", MenuType.Markets, "Page2")
                    }),

                new("Controls",
                    MenuGroupType.PublicationControls,
                    new List<NavigationMenuItemViewModel>())
            };

            var updated = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>
                    {
                        new("Dashboard1", MenuType.Markets, "Page1"),
                        new("Dashboard2", MenuType.Markets, "Page2")
                    }),

                new("Controls",
                    MenuGroupType.PublicationControls,
                    new List<NavigationMenuItemViewModel>())
            };

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.MenuItems.OnNext(loaded);
            Mock.Get(testObjects.DispatcherService).Invocations.Clear();

            // ACT
            testObjects.MenuItems.OnNext(updated);

            // ASSERT
            Mock.Get(testObjects.DispatcherService)
                .Verify(ds => ds.BeginInvoke(It.IsAny<Dispatcher>(), It.IsAny<Action>(), DispatcherPriority.Loaded), Times.Never);

            Assert.That(testObjects.ViewModel.SelectedMenuItem.Caption, Is.EqualTo("Dashboard1"));
        }

        [Test]
        public void ShouldSetCurrentMarketsPage_And_ShowMarketsToolBar_When_MarketsMenuItemSelected()
        {
            var marketsItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                              MenuType.Markets,
                                                              nameof(DashboardPage1),
                                                              1);

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();
      
            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = marketsItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.SetCurrentMarketsPageNumber(1), Times.Once);

            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowMarketsToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideMarketsToolBar_When_OtherMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                           MenuType.Markets,
                                                           nameof(DashboardPage1),
                                                           1);

            var otherItem = new NavigationMenuItemViewModel(MenuHeaders.CurveSettings,
                                                            MenuType.PublicationControls,
                                                            nameof(PublicationControlPage));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowMarketsToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldNotSetCurrentMarketsPage_When_OtherMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                           MenuType.Markets,
                                                           nameof(DashboardPage1));

            var otherItem = new NavigationMenuItemViewModel(MenuHeaders.CurveSettings,
                                                            MenuType.PublicationControls,
                                                            nameof(PublicationControlPage));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            Mock.Get(testObjects.ToolBarUpdateService).Invocations.Clear();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.SetCurrentMarketsPageNumber(It.IsAny<int>()), Times.Never);
        }

        [Test]
        public void ShouldShowPublicationControlToolBar_When_PublicationControlsMenuItemSelected()
        {
            var publisherItem = new NavigationMenuItemViewModel(MenuHeaders.CurveSettings,
                                                                MenuType.PublicationControls,
                                                                nameof(PublicationControlPage));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = publisherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService).Verify(tb => tb.ShowPublicationControlToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHidePublicationControlToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var publisherItem = new NavigationMenuItemViewModel(MenuHeaders.CurveSettings,
                                                                MenuType.PublicationControls,
                                                                nameof(PublicationControlPage));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = publisherItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowPublicationControlToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowPremiumsEditorToolBar_When_PremiumsEditorMenuItemSelected()
        {
            var premiumsItem = new NavigationMenuItemViewModel(MenuHeaders.FeesAndPremiums,
                                                               MenuType.FeesAndPremiums,
                                                               nameof(PremiumsEditorPage));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = premiumsItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService).Verify(tb => tb.ShowPremiumsEditorToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHidePremiumsEditorToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var premiumsItem = new NavigationMenuItemViewModel(MenuHeaders.FeesAndPremiums,
                                                               MenuType.FeesAndPremiums,
                                                               nameof(PremiumsEditorPage));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = premiumsItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService).Verify(tb => tb.ShowPremiumsEditorToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowChatScraperBrokerToolBar_When_ChatScraperBrokerMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatScraperBrokerAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperBrokerAdminToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideChatScraperBrokerToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatScraperBrokerAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperBrokerAdminToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowChatScraperMarketToolBar_When_ChatScraperMarketMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatScraperMarketAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperMarketAdminToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideChatScraperMarketToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatScraperMarketAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperMarketAdminToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowChatScraperProductToolBar_When_ChatScraperProductMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatScraperProductAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperProductAdminToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideChatScraperProductToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatScraperProductAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperProductAdminToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowChatScraperShortcutsToolBar_When_ChatScraperShortcutsMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatScraperShortcutsAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperShortcutsAdminToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideChatScraperShortcutsToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatScraperShortcutsAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperShortcutsAdminToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowChatPriceSummaryToolBar_When_ChatPriceSummaryMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatPriceSummary,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatPriceSummaryToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideChatPriceSummaryToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance,
                                                           MenuType.ChatPriceSummary,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatPriceSummaryToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowMarketsDailyToolBar_When_MarketsDailyMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.DatedBrent,
                                                           MenuType.MarketsDaily,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowDailyPricingToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideMarketsDailyToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(Headers.PriceDashboard,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.DatedBrent,
                                                           MenuType.MarketsDaily,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowDailyPricingToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowChatScraperMessagesToolBar_When_ChatScraperMessagesMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance, 
                                                           MenuType.ChatScraperMessageAdmin, 
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperMessageAdminToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideChatScraperMessagesToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance, 
                                                            MenuType.ChatScraperMessageAdmin, 
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ChatMaintenance, 
                                                           MenuType.ChatPriceSummary, 
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowChatScraperMessageAdminToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowUserAdminToolBar_When_userAdminMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.Administration,
                                                           MenuType.UserAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowUserAdminToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideUserAdminToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(MenuHeaders.Markets,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.Administration,
                                                           MenuType.UserAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowUserAdminToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowCalendarAdminToolBar_When_UserAdminMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.Administration,
                                                           MenuType.CalendarAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowCalendarAdminToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideCalendarAdminToolBar_When_OtherMenuItemSelected()
        {
            var otherItem = new NavigationMenuItemViewModel(MenuHeaders.Markets,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.Administration,
                                                           MenuType.CalendarAdmin,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowCalendarAdminToolBar(false), Times.Once);
        }

		[Test]
		public void ShouldShowCurveApprovalsToolBar_When_CurveApprovalsMenuItemSelected()
		{
			var menuItem = new NavigationMenuItemViewModel(MenuHeaders.CurveApprovals,
														   MenuType.CurveApprovals,
														   "page");

			var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

			// ACT
			testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

			// ASSERT
			Mock.Get(testObjects.ToolBarUpdateService)
				.Verify(tb => tb.ShowCurveApprovalsToolBar(true), Times.Once);
		}

		[Test]
        public void ShouldShowManualCurveEditorToolBar_When_ManualCurveEditorMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ManualCurveMaintenance,
                                                           MenuType.ManualCurveMaintenance,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowManualCurveEditorToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideManualCurveEditorToolBar_When_OtherMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ManualCurveMaintenance,
                                                           MenuType.ManualCurveMaintenance,
                                                           "page");

            var otherItem = new NavigationMenuItemViewModel(MenuHeaders.Markets,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowManualCurveEditorToolBar(false), Times.Once);
        }

		[Test]
		public void ShouldShowFormulaCurveEditorToolBar_When_FormulaCurveEditorMenuItemSelected()
		{
			var menuItem = new NavigationMenuItemViewModel(MenuHeaders.FormulaCurveMaintenance,
														   MenuType.FormulaCurveMaintenance,
														   "page");

			var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

			// ACT
			testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

			// ASSERT
			Mock.Get(testObjects.ToolBarUpdateService)
				.Verify(tb => tb.ShowFormulaCurveEditorToolBar(true), Times.Once);
		}

		[Test]
		public void ShouldHideFormulaCurveEditorToolBar_When_OtherMenuItemSelected()
		{
			var menuItem = new NavigationMenuItemViewModel(MenuHeaders.FormulaCurveMaintenance,
														   MenuType.FormulaCurveMaintenance,
														   "page");

			var otherItem = new NavigationMenuItemViewModel(MenuHeaders.Markets,
															MenuType.Markets,
															nameof(DashboardPage1));

			var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

			testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

			// ACT
			testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

			// ASSERT
			Mock.Get(testObjects.ToolBarUpdateService)
				.Verify(tb => tb.ShowFormulaCurveEditorToolBar(false), Times.Once);
		}

		[Test]
        public void ShouldShowFxCurveEditorToolBar_When_FxCurveEditorMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.FxCurveMaintenance,
                                                           MenuType.FxCurveMaintenance,
                                                           "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowFxCurveEditorToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideFxCurveEditorToolBar_When_OtherMenuItemSelected()
        {
			var menuItem = new NavigationMenuItemViewModel(MenuHeaders.FxCurveMaintenance,
                                                           MenuType.FxCurveMaintenance,
                                                           "page");

			var otherItem = new NavigationMenuItemViewModel(MenuHeaders.Markets,
                                                            MenuType.Markets,
                                                            nameof(DashboardPage1));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowFxCurveEditorToolBar(false), Times.Once);
        }

        [Test]
        public void ShouldShowProductEditorToolBar_When_FxCurveEditorMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ProductMaintenance,
                MenuType.ProductMaintenance,
                "page");

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowProductEditorToolBar(true), Times.Once);
        }

        [Test]
        public void ShouldHideProductEditorToolBar_When_OtherMenuItemSelected()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.ProductMaintenance,
                MenuType.ProductMaintenance,
                "page");

            var otherItem = new NavigationMenuItemViewModel(MenuHeaders.Markets,
                MenuType.Markets,
                nameof(DashboardPage1));

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.Controller.ViewModel.SelectedMenuItem = otherItem;

            // ASSERT
            Mock.Get(testObjects.ToolBarUpdateService)
                .Verify(tb => tb.ShowProductEditorToolBar(false), Times.Once);
        }

        #region Navigation Commands

        [Test]
        public void ShouldEnableNavigateBackCommand_OnCommandTrue_WithNavigationEnabled()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().WithNavigationEnabled(true)
                                                                                     .Build();

            // ACT
            testObjects.Controller.ViewModel.EnableNavigateBackCommand.Execute(true);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateBackCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableNavigateBackCommand_OnCommandFalse_WithNavigationEnabled()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().WithNavigationEnabled(true)
                                                                                     .Build();

            // ACT
            testObjects.Controller.ViewModel.EnableNavigateBackCommand.Execute(false);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateBackCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableNavigateForwardCommand_OnCommandFalse_WithNavigationEnabled()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().WithNavigationEnabled(true)
                                                                                     .Build();

            // ACT
            testObjects.Controller.ViewModel.EnableNavigateForwardCommand.Execute(true);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateForwardCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldDisableNavigateForwardCommand_OnCommandFalse_WithNavigationEnabled()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().WithNavigationEnabled(true)
                                                                                     .Build();

            // ACT
            testObjects.Controller.ViewModel.EnableNavigateForwardCommand.Execute(false);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateForwardCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableNavigateBackCommand_WhenNavigationDisabled()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().WithNavigationEnabled(true)
                                                                                     .Build();

            testObjects.Controller.ViewModel.EnableNavigateBackCommand.Execute(true);

            // ACT
            testObjects.NavigationEnabled.OnNext(false);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateBackCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldDisableNavigateForwardCommand_WhenNavigationDisabled()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().WithNavigationEnabled(true)
                                                                                     .Build();

            testObjects.Controller.ViewModel.EnableNavigateForwardCommand.Execute(true);

            // ACT
            testObjects.NavigationEnabled.OnNext(false);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateForwardCommand.CanExecute(), Is.False);
        }

        [Test]
        public void ShouldEnableNavigateBackCommand_WhenNavigationEnabled()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().WithNavigationEnabled(false)
                                                                                     .Build();

            testObjects.Controller.ViewModel.EnableNavigateBackCommand.Execute(true);

            // ACT
            testObjects.NavigationEnabled.OnNext(true);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateBackCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldEnableNavigateForwardCommand_WhenNavigationEnabled()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().WithNavigationEnabled(false)
                                                                                     .Build();

            testObjects.Controller.ViewModel.EnableNavigateForwardCommand.Execute(true);

            // ACT
            testObjects.NavigationEnabled.OnNext(true);

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateForwardCommand.CanExecute(), Is.True);
        }

        [Test]
        public void ShouldPublishInverseValueOnNavigateBack()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.NavigateBackPage = false;

            // ACT
            testObjects.Controller.ViewModel.NavigateBackCommand.Execute();

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateBackPage, Is.True);
        }

        [Test]
        public void ShouldPublishInverseValueOnNavigateForward()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.NavigateForwardPage = false;

            // ACT
            testObjects.Controller.ViewModel.NavigateForwardCommand.Execute();

            // ASSERT
            Assert.That(testObjects.Controller.ViewModel.NavigateForwardPage, Is.True);
        }

        #endregion

        [Test]
        public void ShouldSetPageLoadedFromSelectedMenuItem_On_PageLoadedCommand()
        {
            var menuItem = new NavigationMenuItemViewModel(MenuHeaders.Markets,
                                                           MenuType.Markets,
                                                           nameof(DashboardPage2),
                                                           2);

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = menuItem;

            // ACT
            testObjects.ViewModel.PageLoadedCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.PagesLoadedService).Verify(p => p.SetPageLoaded(2));
        }

        [Test]
        public void ShouldNotSetPageLoaded_On_PageLoadedCommand_With_SelectedItemNull()
        {
            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.ViewModel.SelectedMenuItem = null;

            // ACT
            testObjects.ViewModel.PageLoadedCommand.Execute();

            // ASSERT
            Mock.Get(testObjects.PagesLoadedService).Verify(p => p.SetPageLoaded(It.IsAny<int>()), Times.Never);
        }

        [Test]
        public void ShouldNotAddMenuItems_When_Disposed()
        {
            var menu = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>())
            };

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.MenuItems.OnNext(menu);

            // ASSERT
            Assert.That(testObjects.ViewModel.GroupMenuItems.Count, Is.EqualTo(0));
        }

        [Test]
        public void ShouldNotDispose_When_Disposed()
        {
            var menu = new List<NavigationMenuItemGroupViewModel>
            {
                new("Markets",
                    MenuGroupType.Markets,
                    new List<NavigationMenuItemViewModel>())
            };

            var testObjects = new NavigationBarViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.MenuItems.OnNext(menu);

            // ASSERT
            Assert.That(testObjects.ViewModel.GroupMenuItems.Count, Is.EqualTo(0));
        }
    }
}
