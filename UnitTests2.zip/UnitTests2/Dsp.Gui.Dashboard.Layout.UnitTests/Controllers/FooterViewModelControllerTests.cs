﻿using System.Reactive.Subjects;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Layout.Controllers;
using Dsp.Gui.Dashboard.Layout.ViewModels;
using Moq;
using NUnit.Framework;

namespace Dsp.Gui.Dashboard.Layout.UnitTests.Controllers
{
    internal interface IFooterViewModelControllerTestObjects
    {
        ISubject<PopupNotificationArgs> PopupNotification { get; }
        FooterViewModel ViewModel { get; }
        FooterViewModelController Controller { get; }
    }

    public class FooterViewModelControllerTests
    {
        private class FooterViewModelControllerTestObjectBuilder
        {
            public IFooterViewModelControllerTestObjects Build()
            {
                var testObjects = new Mock<IFooterViewModelControllerTestObjects>();

                var popupNotification = new Subject<PopupNotificationArgs>();
                testObjects.SetupGet(o => o.PopupNotification).Returns(popupNotification);

                var popupService = new Mock<IPopupNotificationService>();

                popupService.SetupGet(p => p.OnPopupNotification)
                                   .Returns(popupNotification);

                var controller = new FooterViewModelController(popupService.Object);
                testObjects.SetupGet(o => o.Controller).Returns(controller);

                testObjects.SetupGet(o => o.ViewModel).Returns(controller.ViewModel);

                return testObjects.Object;
            }
        }

        [Test]
        public void ShowShowPopupNotification()
        {
            var popup = new PopupNotificationArgs("line-1", "line-2");

            var testObjects = new FooterViewModelControllerTestObjectBuilder().Build();

            // ACT
            testObjects.PopupNotification.OnNext(popup);

            // ASSERT
            Assert.IsTrue(testObjects.ViewModel.ShowPopupNotification);
            Assert.AreEqual("line-1", testObjects.ViewModel.PopupMessageLine1);
            Assert.AreEqual("line-2", testObjects.ViewModel.PopupMessageLine2);
        }

        [Test]
        public void ShouldNotShowPopupWhenDisposed()
        {
            var popup = new PopupNotificationArgs("line-1", "line-2");

            var testObjects = new FooterViewModelControllerTestObjectBuilder().Build();
            
            testObjects.Controller.Dispose();

            // ACT
            testObjects.PopupNotification.OnNext(popup);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowPopupNotification);
        }

        [Test]
        public void ShouldNotDisposeWhenDisposed()
        {
            var popup = new PopupNotificationArgs("line-1", "line-2");

            var testObjects = new FooterViewModelControllerTestObjectBuilder().Build();

            testObjects.Controller.Dispose();

            // ACT
            testObjects.Controller.Dispose();
            testObjects.PopupNotification.OnNext(popup);

            // ASSERT
            Assert.IsFalse(testObjects.ViewModel.ShowPopupNotification);
        }
    }
}
