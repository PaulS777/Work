﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.ServiceContracts
{
    public interface IDataManagementService : IDspService
    {
        DataUpdateResult Add<T>(List<T> items, string userName) where T : IIdentifiable;
        DataUpdateResult Update<T>(List<T> updates, string userName) where T : IIdentifiable;
        DataUpdateResult Delete<T>(T item, string userName) where T : IIdentifiable;
        DataUpdateResult ShiftPartitions(PartitionShiftRequest request);
        List<T> Get<T>() where T : IIdentifiable;
        void Refresh(Type type);
        void Refresh();
        DataUpdateResult ExecuteActions<T>(List<T> adminActions, string auditUser) where T : AdminAction;
    }
}
