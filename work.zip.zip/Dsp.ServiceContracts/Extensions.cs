﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;

namespace Dsp.ServiceContracts
{
    public static class Extensions
    {
        public static List<FuturesExpiry> GetValidExpiries(this BaseCurveDefinition definition, DateTime today)
        {
            var result = definition.FuturesExpiries.Where(x => x.Expiry >= today)
                .Take(definition.PeriodCount).OrderBy(x => x.ContractMonth).ToList();

            if(result.Count < 1)
            {
                throw new ArgumentException($"There must be at least one future contract expiry later than {today:d}");
            }

            return result;
        }
    }
}