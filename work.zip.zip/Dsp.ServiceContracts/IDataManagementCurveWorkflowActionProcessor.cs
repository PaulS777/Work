﻿using Dsp.DataContracts;

namespace Dsp.ServiceContracts;

public interface IDataManagementCurveWorkflowActionProcessor

{
    DataUpdateResult Approve(int draftCurveDefinitionId);
    DataUpdateResult Reject(int draftCurveDefinitionId);
    DataUpdateResult Cancel(int draftCurveDefinitionId);
    DataUpdateResult Delete(int priceCurveDefinitionId, int userId);
}