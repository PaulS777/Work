﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;

namespace Dsp.ServiceContracts
{
    public interface ISubscription<out T>: IDisposable where T : IIdentifiable
    {
        void Subscribe(Action<IEnumerable<T>> messagesReceived, Action<ConnectionStatus, IEnumerable<T>> statusChanged);
        void Unsubscribe();
    }
}