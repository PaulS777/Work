﻿namespace Dsp.ServiceContracts
{
    public interface IRepositoryFactory
    {
        IEnumTableValidator GetEnumValidator<T>() where T : struct;
        IRepository<T> GetRepository<T>();
        void ValidateDbConnection();
    }
}
