﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.ServiceContracts.MonthEndRoll
{
    public interface IMonthEndRollValidationService
    {
        DateOnly GetCurrentRollMonth(DateTime today);

        bool CanMonthEndRoll(DateOnly rollMonth, RollStatus monthEndRollStatus, DateTime today, int eomRollWindow = 5);

        List<string> ValidateFlatPriceCurves(List<ManualCurveDefinition<MonthlyTenor>> manualCurvesDefinitions);

        List<string>  ValidateManualCurvesLength(List<ManualCurveDefinition<MonthlyTenor>> manualCurvesDefinitions);
    }
}
