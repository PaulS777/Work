﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.ServiceContracts.MonthEndRoll
{
    public class MonthEndRollValidationService : IMonthEndRollValidationService
    {
        private readonly ILogger _log;

        public MonthEndRollValidationService(ILoggerFactory loggerFactory)
        {
            ArgumentNullException.ThrowIfNull(loggerFactory);

            _log = loggerFactory.Create(GetType());
        }

        public bool CanMonthEndRoll(DateOnly rollMonth, RollStatus monthEndRollStatus, DateTime today, int eomRollWindow = 5)
        {
            // purpose 
            // Checks if month end roll can be performed.
            // if the month end roll is valid true is returned otherwise false.
            var currentRollMonth = GetCurrentRollMonth(today);

            if (currentRollMonth != rollMonth)
            {
                var message = $"Month end roll not allowed: Attempt to roll {rollMonth:MMM yyyy} which is not the current month ({currentRollMonth:MMM yyyy}).";
                _log.Warn(message);
                return false;
            }
            
            if (monthEndRollStatus == RollStatus.Completed)
            {
                _log.Info("Month end roll not allowed: Month End Roll already completed.");
                return false;
            }

            if (Math.Abs((today - rollMonth.ToUtcDateTime()).Days)> eomRollWindow)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Get the roll month to be used in all operations
        /// </summary>
        /// <returns></returns>
        public DateOnly GetCurrentRollMonth(DateTime today)
        {
            if (today.Day < 15)
            {
                return today.FirstDayOfMonth().ToDateOnly();
            }
            return today.FirstDayOfMonth().AddMonths(1).ToDateOnly();
        }


        public List<string> ValidateFlatPriceCurves(List<ManualCurveDefinition<MonthlyTenor>> manualCurvesDefinitions)
        {
            ArgumentNullException.ThrowIfNull(manualCurvesDefinitions);

            var flatPriceList = new List<string>();
            var badCurves = manualCurvesDefinitions.FindAll(s => s.Overrides.Count > 1);

            if (badCurves.Count <= 0)
            {
                return flatPriceList;
            }

            flatPriceList.AddRange(badCurves.Select(c => c.Name));

            return flatPriceList;
        }

        public List<string> ValidateManualCurvesLength(List<ManualCurveDefinition<MonthlyTenor>> manualCurvesDefinitions)
        {
            // purpose 
            // Checks the number of overrides in non flat price curves.
            // Will flag curves which have 3 or less overrides. This can lead to issues in calculating
            // time spread curves.
            // requires 
            // manualCurvesDefinitions - this is required to verify existing overrides in manual curves 
            // guarantees 
            // We will not run out of overrides for the month end roll process.

            ArgumentNullException.ThrowIfNull(manualCurvesDefinitions);

            var overridesList = new List<string>();
            var badCurves = manualCurvesDefinitions.FindAll(s => s.Overrides.Count < 1);

            if (badCurves.Count <= 0)
            {
                return overridesList;
            }

            overridesList.AddRange(badCurves.Select(c => c.Name));

            return overridesList;
        }
    }
}
