﻿using Dsp.DataContracts.Configuration;

namespace Dsp.ServiceContracts
{
    public class DspCommonUtilities
    {
        public IDateTimeProvider DateTimeProvider { get; init; }
        public ILoggerFactory LoggerFactory { get; init; }
        public IConfigProvider ConfigProvider { get; init; }
        public ITimerProvider TimerProvider { get; init; }
        public ITaskHandlerServiceFactory TaskHandlerServiceFactory { get; init; }
        public IDataManagementServiceClient DataManagementServiceClient { get; set; }

        public DspCommonUtilities()
        { }

        public DspCommonUtilities(IDateTimeProvider dateTimeProvider,
            ILoggerFactory loggerFactory,
            IConfigProvider configProvider,
            ITimerProvider timerProvider,
            ITaskHandlerServiceFactory taskHandlerServiceFactory,
            IDataManagementServiceClient dataManagementServiceClient)
        {
            DateTimeProvider = dateTimeProvider;
            LoggerFactory = loggerFactory;
            ConfigProvider = configProvider;
            TimerProvider = timerProvider;
            TaskHandlerServiceFactory = taskHandlerServiceFactory;
            DataManagementServiceClient = dataManagementServiceClient;
        }

        public DspCommonUtilities SetInstance(int instance)
        {
            return new DspCommonUtilities(DateTimeProvider, LoggerFactory.SetInstance(instance), ConfigProvider, TimerProvider, TaskHandlerServiceFactory.SetInstance(instance), DataManagementServiceClient);
        }
    }
}