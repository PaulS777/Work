﻿using System.Security.Claims;

namespace Dsp.ServiceContracts
{
    /// <summary>
    /// Authenticate users and/or API keys
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IAuthenticationService<T>
    {
        bool TryGetCredentials(ClaimsPrincipal claimsPrincipal, out string userName);
        bool TryAuthenticate(string clientId, out T client, out string failureMessage);
    }
}
