﻿namespace Dsp.ServiceContracts
{
    public interface IValidatorFactory
    {
        IDerivedCurveDefinitionValidator GetDerivedCurveDefinitionValidator();
    }
}
