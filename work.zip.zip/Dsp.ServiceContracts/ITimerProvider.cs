﻿using System;
using System.Threading;

namespace Dsp.ServiceContracts
{
    public interface ITimerProvider
    {
        Timer GetTimer(TimerCallback callback);
        ISimpleTimer GetSimpleTimer(IDateTimeProvider clock, TimerCallback callback);
    }

    public interface ISimpleTimer
    {
        void SetNextEventTime(DateTime newTime);
    }
}