﻿using System;

namespace Dsp.ServiceContracts
{
    public interface IDateTimeProvider
    {
        DateTime UtcNow { get; }
        DateTime Now { get; }
        DateTime Today { get; }
    }
}