﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;

namespace Dsp.ServiceContracts
{
    /// <summary>
    /// User Authentication and Access Control methods
    /// </summary>
    public interface IAccessManagementService : IAuthorisationService, IAuthenticationService<User>
    {
        bool CanAction<T>(int dspUserId, WebSocketClientType requestFromClientType, List<T> adminActions, out string failureMessage) where T : AdminAction;
        bool IsLatestConnection(User dspUser, long connectTime);
    }
}
