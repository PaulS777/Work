﻿namespace Dsp.ServiceContracts
{
    public interface IKeyGenerator
    {
        long NextKey();
    }
}
