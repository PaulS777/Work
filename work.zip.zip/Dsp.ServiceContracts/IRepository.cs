﻿using System.Collections.Generic;
using System.Data;

namespace Dsp.ServiceContracts
{
    public interface IRepository<T>
    {
        IEnumerable<T> GetAll();
        IEnumerable<T> GetAll(IDbConnection connection);

        T GetById(int id, bool isOptional = false);
        T GetById(IDbConnection connection, int id, bool isOptional = false);

        T Add(T item);

        IEnumerable<T> Add(IEnumerable<T> items);

        
        T Update(T item);

        IEnumerable<T> Update(IEnumerable<T> items);

        void Delete(T item);

        void Delete(IEnumerable<T> items);
    }
}
