﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Dsp.DataContracts.Curve;

namespace Dsp.ServiceContracts
{
    public interface IPriceCurveNotificationService
    {
        Task BroadcastPriceCurves(IEnumerable<PriceCurve> updates);

        Task BroadcastFxCurves(IEnumerable<FxPriceCurve> updates);

        Task RequestSubscribeToPriceCurves(string connectionId, IEnumerable<int> curveIds, IEnumerable<PriceCurve> priceCurves);

        Task RequestUnsubscribeFromPriceCurves(string connectionId, IEnumerable<int> curveIds);

        Task RequestSubscribeToFxCurves(string connectionId, IEnumerable<int> curveIds, IEnumerable<FxPriceCurve> fxCurves);

        Task RequestUnsubscribeFromFxCurves(string connectionId, IEnumerable<int> curveIds);
        int UserCount { get; }
    }
}