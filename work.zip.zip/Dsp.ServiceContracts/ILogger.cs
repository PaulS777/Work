﻿using System;

namespace Dsp.ServiceContracts
{
    public interface ILogger
    {
        bool IsDebugEnabled { get; }
        void Debug(string message);
        void Debug(string format, params object[] args);

        void Info(string message);
        void Info(string format, params object[] args);

        void Warn(string message);
        void Warn(string format, params object[] args);

        void Error(string message);
        void Error(string message, Exception exception);
        void Error(string format, params object[] args);

        string SetCorrelationId(string correlationId = null);
        string GetCorrelationId();
    }
}