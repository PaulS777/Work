﻿namespace Dsp.ServiceContracts
{
    public interface IDataSubscriptionService : IDspService
    {
    }
}
