﻿using Dsp.DataContracts.Curve;

namespace Dsp.ServiceContracts
{
    public interface IPriceCurveProvider
    {
        PriceCurveBase GetById(int id);
    }
}
