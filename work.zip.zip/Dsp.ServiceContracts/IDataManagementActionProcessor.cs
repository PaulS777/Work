﻿// /***********************************************************************************************************************
// IDataManagementActionProcessor.cs
// 
// (c) 2023 - Shell.  Created by Hughes, Tim DW SITILTD-PTIY/TCD, 2023/05/16.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;

namespace Dsp.ServiceContracts;

public interface IDataManagementActionProcessor
{
    void Start();

    void Stop();

    void Refresh();
}

public interface IDataManagementActionProcessor<in T> where T : AdminAction
{
    DataUpdateResult ExecuteAction(T adminAction, string userName);
}