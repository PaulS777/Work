﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Configuration;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.ServiceContracts
{
    public interface IDataNotificationService
    {
        Task BroadcastPriceCurveDefinitions(IEnumerable<PriceCurveDefinition> updates);

        Task BroadcastFxCurveDefinitions(IEnumerable<FxCurveDefinition> updates);

        Task BroadcastDerivedCurveDefinitions(IEnumerable<DerivedCurveDefinition> updates);

        Task BroadcastUsers(IEnumerable<User> updates);

        Task BroadcastPriceCurveSettings(IEnumerable<PriceCurveSetting> updates);

        Task BroadcastFxCurveSettings(IEnumerable<FxCurveSetting> updates);

        Task BroadcastPriceCurvePremiums(IEnumerable<PriceCurvePremium> updates);

        Task BroadcastPublisherTenorPremiums(IEnumerable<PublisherTenorPremium> updates);

        Task BroadcastFxCurvePipsBuffer(IEnumerable<FxCurvePipsBuffer> updates);

        Task BroadcastChatUser(IEnumerable<ChatUser> updates);

        Task BroadcastChatMarket(IEnumerable<ChatMarket> updates);

        Task BroadcastServiceStatusNotification(IEnumerable<ServiceStatusNotification> updates);
                
        Task BroadcastChatMessageHistory(IEnumerable<ChatMessageHistory> updates);

        Task BroadcastChatVariableShortcut(IEnumerable<ChatVariableShortcut> updates);

        Task BroadcastChatIceMap(IEnumerable<ChatIceMap> updates);
        
        Task BroadcastChatPriceSummary(IEnumerable<ChatPriceSummary> updates);

        Task BroadcastCalendar(IEnumerable<Calendar> updates);

        Task BroadcastMonthEndRollStatus(IEnumerable<MonthEndRollStatus> updates);

        Task BroadcastConfiguration(IEnumerable<DynamicConfiguration> updates);

        Task BroadcastSystemDate(IEnumerable<SystemDate> updates);
        Task BroadcastProductDefinitions(IEnumerable<ProductDefinition> updates);
        Task BroadcastClientApiKeys(IEnumerable<ClientApiKey> updates);
        Task BroadcastCurrencyCodes(IEnumerable<CurrencyCode> updates);
        Task BroadcastCurveGroups(IEnumerable<CurveGroup> updates);
        Task BroadcastValidatePriceCurveFormulaResponses(IEnumerable<ValidatePriceCurveFormulaResponse> updates);

        Task RequestSubscribeToPriceCurves(string connectionId,
            IEnumerable<int> curveIds,
            IEnumerable<PriceCurveSetting> curveSettings,
            IEnumerable<PriceCurvePremium> curvePremiums,
            IEnumerable<PublisherTenorPremium> publisherTenorPremiums);

        Task RequestUnsubscribeFromPriceCurves(string connectionId, IEnumerable<int> curveIds);

        Task RequestSubscribeToFxCurves(string connectionId, IEnumerable<int> curveIds, IEnumerable<FxCurveSetting> curveSettings, IEnumerable<FxCurvePipsBuffer> curvePips);

        Task RequestUnsubscribeFromFxCurves(string connectionId, IEnumerable<int> curveIds);

        Task RequestSubscribeToPriceCurveDefinitions(string connectionId, IEnumerable<PriceCurveDefinition> snapshot);

        Task RequestUnSubscribeFromPriceCurveDefinitions(string connectionId, IEnumerable<PriceCurveDefinition> snapshot);

        Task RequestSubscribeToFxCurveDefinitions(string connectionId, IEnumerable<FxCurveDefinition> snapshot);

        Task RequestUnSubscribeFromFxCurveDefinitions(string connectionId, IEnumerable<FxCurveDefinition> snapshot);

        Task RequestSubscribeToUsers(string connectionId, IEnumerable<User> snapshot);

        Task RequestUnSubscribeFromUsers(string connectionId);

        Task RequestSubscribeToDerivedCurveDefinitions(string connectionId, IEnumerable<DerivedCurveDefinition> snapshot);

        Task RequestUnSubscribeFromDerivedCurveDefinitions(string connectionId, IEnumerable<DerivedCurveDefinition> snapshot);

        Task RequestSubscribeToChatUsers(string connectionId, IEnumerable<ChatUser> snapshot);

        Task RequestUnSubscribeFromChatUsers(string connectionId);

        Task RequestSubscribeToChatMarkets(string connectionId, IEnumerable<ChatMarket> snapshot);

        Task RequestUnSubscribeFromChatMarkets(string connectionId);

        Task RequestSubscribeToChatMessageHistory(string connectionId, IEnumerable<ChatMessageHistory> snapshot);

        Task RequestUnSubscribeFromChatMessageHistory(string connectionId);

        Task RequestSubscribeToChatVariableShortcut(string connectionId, IEnumerable<ChatVariableShortcut> snapshot);

        Task RequestUnSubscribeFromChatVariableShortcut(string connectionId);

        Task RequestSubscribeToChatIceMap(string connectionId, IEnumerable<ChatIceMap> snapshot);

        Task RequestUnSubscribeFromChatIceMap(string connectionId);
        
        Task RequestSubscribeToChatPriceSummary(string connectionId, IEnumerable<ChatPriceSummary> snapshot);

        Task RequestUnSubscribeFromChatPriceSummary(string connectionId);

        Task RequestSubscribeToServiceStatusNotification(string connectionId, IEnumerable<ServiceStatusNotification> snapshot);

        Task RequestUnSubscribeFromServiceStatusNotification(string connectionId);

        Task RequestSubscribeToCalendar(string connectionId, IEnumerable<Calendar> snapshot);

        Task RequestUnSubscribeFromCalendar(string connectionId);
        Task RequestSubscribeToMonthEndRollStatus(string connectionId, IEnumerable<MonthEndRollStatus> snapshot);

        Task RequestUnSubscribeFromMonthEndRollStatus(string connectionId);

        Task RequestSubscribeToConfiguration(string connectionId, IEnumerable<DynamicConfiguration> snapshot);

        Task RequestUnSubscribeFromConfiguration(string connectionId);

        Task RequestSubscribeToSystemDate(string connectionId, IEnumerable<SystemDate> snapshot);
        Task RequestUnSubscribeFromSystemDate(string connectionId); 
        Task RequestSubscribeToProductDefinition(string connectionId, IEnumerable<ProductDefinition> snapshot);
        Task RequestUnSubscribeFromProductDefinition(string connectionId);
        Task RequestSubscribeToClientApiKey(string connectionId, IEnumerable<ClientApiKey> snapshot);
        Task RequestUnSubscribeFromClientApiKey(string connectionId);
        Task RequestSubscribeToCurrencyCodes(string connectionId, IEnumerable<CurrencyCode> snapshot);
        Task RequestUnSubscribeFromCurrencyCodes(string connectionId);
        Task RequestSubscribeToCurveGroups(string connectionId, IEnumerable<CurveGroup> snapshot);
        Task RequestUnSubscribeFromCurveGroups(string connectionId);
        Task RequestSubscribeToValidatePriceCurveFormulaResponses(string connectionId, IEnumerable<ValidatePriceCurveFormulaResponse> snapshot);
        Task RequestUnSubscribeFromValidatePriceCurveFormulaResponses(string connectionId);
        int UserCount { get; }
    }
}