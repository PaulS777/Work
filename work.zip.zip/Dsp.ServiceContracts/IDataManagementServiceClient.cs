﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Dsp.DataContracts.AdminActions;
using Dsp.DataContracts;

namespace Dsp.ServiceContracts
{
    public interface IDataManagementServiceClient
    {
        Task<HttpResponseMessage> Add<T>(IEnumerable<T> values, string userName) where T : IIdentifiable;

        Task<HttpResponseMessage> Update<T>(IEnumerable<T> values, string userName) where T : IIdentifiable;

        Task<HttpResponseMessage> Delete<T>(T item, string userName) where T : IIdentifiable; 

        Task<HttpResponseMessage> ExecuteActions<T>(List<T> adminActions, string userName) where T : AdminAction;

        Task<HttpResponseMessage> RunActionAsync<T>(T request, string userName);

        Task<DataManagementServiceResponse<T>> Get<T>(string userName);
        Task<HttpResponseMessage> Refresh(Type type=null);
    }

    public class DataManagementServiceResponse<T>
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; }
        public List<T> Content { get; } = new();
    }
}