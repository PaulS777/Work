﻿// /***********************************************************************************************************************
// ITaskHandlerService.cs
// 
// (c) 2022 - Shell.  Created by Hughes, Tim DW SITI-PTIY/BBJ, 2022/10/05.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:  Abstraction of task/event handling enabling support of both asynchronous processing and deterministic
//           processing.  The latter is mainly required to allow us to test reliably.
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System;

namespace Dsp.ServiceContracts
{
    /// <summary>
    /// Contract for services that allow the registering of handlers for any number of different tasks, and provide a common point for submitting those tasks.
    /// Implementations may be either synchronous or asynchronous via some internal queueing mechanism.
    /// </summary>
    public interface ITaskHandlerService
    {
        /// <summary>
        /// Configure any options
        /// </summary>
        /// <param name="idleTimeWarningSecs"></param>
        /// <param name="idleCallback"></param>
        /// <param name="queueSizeWarning"></param>
        void ConfigureOptions(int? idleTimeWarningSecs = null, Action<int> idleCallback = null, int? queueSizeWarning = null);
        /// <summary>
        /// Add a new task to be handled
        /// </summary>
        /// <param name="item"></param>
        void AddTask<T>(T item);

        /// <summary>
        /// Register a handler method that will process all tasks with type T
        /// </summary>
        /// <param name="callback"></param>
        /// <param name="onException"></param>
        void RegisterTaskHandler<T>(Action<T> callback, Action<T, Exception> onException = null);
        /// <summary>
        /// Stop processing and exit
        /// </summary>
        void Stop();
        /// <summary>
        /// Pause processing
        /// </summary>
        void Pause();
        /// <summary>
        /// Pause processing
        /// </summary>
        void Resume();
        /// <summary>
        /// Are there any tasks that have been added and are still to be processed
        /// </summary>
        /// <returns></returns>
        bool IsBusy();
        /// <summary>
        /// Is the passed task already in the queue to be processed
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        bool IsTaskPending<T>(T item);
        /// <summary>
        /// The number of tasks still waiting to be processed
        /// </summary>
        /// <returns></returns>
        int PendingTasksCount();
    }
    /// <summary>
    /// Strongly-typed contract for services that allow the registering of handlers for any number of different tasks, and provide a common point for submitting those tasks.
    /// Implementations should be faster than the non-typed interface.
    /// Implementations may be either synchronous or asynchronous via some internal queueing mechanism.
    /// </summary>
    public interface ITaskHandlerService<T>
    {
        /// <summary>
        /// Configure any options
        /// </summary>
        /// <param name="idleTimeWarningSecs"></param>
        /// <param name="idleCallback"></param>
        /// <param name="queueSizeWarning"></param>
        void ConfigureOptions(int? idleTimeWarningSecs = null,  Action<int> idleCallback = null, int? queueSizeWarning = null);
        /// <summary>
        /// Add a new task to be handled
        /// </summary>
        /// <param name="item"></param>
        void AddTask(T item);

        /// <summary>
        /// Register a handler method that will process all tasks 
        /// </summary>
        /// <param name="callback"></param>
        /// <param name="onException"></param>
        void RegisterTaskHandler(Action<T> callback, Action<T, Exception> onException = null);
        /// <summary>
        /// Stop processing and exit
        /// </summary>
        void Stop();
        /// <summary>
        /// Are there any tasks that have been added and are still to be processed
        /// </summary>
        /// <returns></returns>
        /// <summary>
        /// Pause processing
        /// </summary>
        void Pause();
        /// <summary>
        /// Pause processing
        /// </summary>
        void Resume();
        /// <summary>
        /// Are there any tasks that have been added and are still to be processed
        /// </summary>
        /// <returns></returns>
        bool IsBusy();
        /// <summary>
        /// Is the passed task already in the queue to be processed
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        bool IsTaskPending(T item);
        /// <summary>
        /// The number of tasks still waiting to be processed
        /// </summary>
        /// <returns></returns>
        int PendingTasksCount();
    }
}