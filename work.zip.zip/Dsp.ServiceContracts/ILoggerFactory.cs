﻿using Dsp.DataContracts;
using System;

namespace Dsp.ServiceContracts
{
    public interface ILoggerFactory
    {
        ILogger Create(Type type);
        ILogger Create(string loggerName);
        IServiceStatusLogger CreateServiceStatusLogger(Type type, string statusKey = null, ServiceStatus initialState = ServiceStatus.Ok);
        IServiceStatusLogger CreateServiceStatusLogger(string loggerName, string statusKey = null, ServiceStatus initialState = ServiceStatus.Ok);
        ILoggerFactory SetInstance(int instance);
    }
}