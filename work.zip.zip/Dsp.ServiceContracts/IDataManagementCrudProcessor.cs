﻿// /***********************************************************************************************************************
// IDataManagementCrudProcessor.cs
// 
// (c) 2023 - Shell.  Created by Hughes, Tim DW SITILTD-PTIY/TCD, 2023/05/16.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System.Collections.Generic;
using Dsp.DataContracts;

namespace Dsp.ServiceContracts;

public interface IDataManagementCrudProcessor
{
    void Start();

    void Stop();

    void Refresh();

}

public interface IDataManagementCrudProcessor<T> where T : IIdentifiable
{
    DataUpdateResult Add(List<T> inserts);
    DataUpdateResult Update(List<T> updates);
    void UpdateRelatedEntity<TE>(TE update) where TE : IIdentifiable;
    DataUpdateResult Delete(T item);
    List<T> Get();
    bool LogActivity { get; }
    Dictionary<int, T> Cache { get; }
    List<T> PendingInserts { get; }
    string SerializeForAudit(T item);
}