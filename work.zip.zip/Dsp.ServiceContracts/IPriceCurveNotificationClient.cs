﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.WebApi;

namespace Dsp.ServiceContracts
{
    public interface IPriceCurveNotificationClient
    {
        Task DisconnectClient();

        Task HandleConnectionStatus(ApiConnectionStatus status, User user);

        Task SubscribeToPriceCurves(IList<int> curveIds);

        Task SubscribeToPriceCurvesByName(IList<string> curveNames);

        Task UnsubscribeFromPriceCurves(IList<int> curveIds);

        Task UnsubscribeFromPriceCurvesByName(IList<string> curveNames);

        Task HandlePriceCurveNotification(PriceCurve priceCurve);

        Task HandleFxCurveNotification(FxPriceCurve fxCurve);

        Task HandlePriceCurvesSnapshot(IList<PriceCurve> priceCurves);

        Task HandleFxCurvesSnapshot(IList<FxPriceCurve> fxCurves);
        
        Task SubscribeToFxCurves(IList<int> curveIds);

        Task SubscribeToFxCurvesByName(IList<string> curveNames);

        Task UnsubscribeFromFxCurves(IList<int> curveIds);

        Task UnsubscribeFromFxCurvesByName(IList<string> curveNames);

        Task HandleAuthFailures(IList<PriceCurve> priceCurves);
    }
}