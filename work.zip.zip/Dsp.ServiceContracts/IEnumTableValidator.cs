﻿namespace Dsp.ServiceContracts
{
    public interface IEnumTableValidator
    {
        void ValidateAgainstSqlTable(string tableName, string nameColumn);
    }
}