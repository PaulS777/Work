﻿// /***********************************************************************************************************************
// IServiceStatusLogger.cs
// 
// (c) 2022 - Shell.  Created by Hughes, Tim DW SITI-PTIY/BBJ, 2022/10/28.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using Dsp.DataContracts;
using System;

namespace Dsp.ServiceContracts
{
    public interface IServiceStatusLogger : ILogger
    {
        string StatusKey { get; set; }
        ServiceStatus Status { get; }
        void WarnFutureActionRequired(string message);
        /// <summary>
        /// Log a warning but explicitly do not set any status, even as a transient warning - by using this you are suppressing notifications to DSX et al
        /// </summary>
        /// <param name="message"></param>
        void WarnToLogOnly(string message);
        /// <summary>
        /// Log Info and reset any error/warning status associated with this logger
        /// </summary>
        /// <param name="message"></param>
        void InfoAndResetStatus(string message);
        /// <summary>
        /// reset any error/warning status associated with this logger
        /// </summary>
        void ResetStatus();
        /// <summary>
        /// Log error and set service status to Error until cleared by call to InfoAndResetStatus in this logger
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exc"></param>
        void ErrorAndSetStatus(string message, Exception exc = null);
        /// <summary>
        /// Log error and set service status to Unavailable.  This indicates that there is no recovery from this error, and the service is down.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exc"></param>
        void FatalError(string message, Exception exc = null);

        /// <summary>
        /// Log warning and set service status to WarningServiceDegraded until cleared by call to InfoAndResetStatus in this logger
        /// </summary>
        /// <param name="message"></param>
        void WarnAndSetStatus(string message);
        /// <summary>
        /// Log warning and set service status to WarningFutureActionRequired until cleared by call to InfoAndResetStatus in this logger
        /// </summary>
        /// <param name="message"></param>
        void WarnFutureActionRequiredAndSetStatus(string message);

        IActivityLogger CreateActivityLogger(int reportFrequencySecs = 60);
        IActivityLogger CreateActivityLogger(string metricName, string units = "msg/s", int reportFrequencySecs = 60, bool divideMetricByPeriod = true);
    }

    public interface IActivityLogger
    {
        void Add(int increment = 1);
        void Add(string metricName, int increment = 1);
        void Reset(int newValue = 0);
        void Reset(string metricName, int newValue = 0);
        void Set(string metricName, int newValue);
        IActivityLogger AddMetric(string metricName, string units = "msg/s", bool divideMetricByPeriod = true, bool resetOnLog = true);
        IActivityLogger AddStatusMetric(string metricName);
    }
}