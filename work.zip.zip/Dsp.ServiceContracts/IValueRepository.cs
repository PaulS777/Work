﻿using System.Collections.Generic;

namespace Dsp.ServiceContracts
{
    public interface IValueRepository<T>
    {
        IEnumerable<T> GetByParentId(int parentId);

        T Add(int parentId, T item);

        IEnumerable<T> Add(int parentId, IEnumerable<T> items);

        T Update(int parentId, T item);

        IEnumerable<T> Update(int parentId, IEnumerable<T> items);

        void Delete(int parentId, T item);

        void Delete(int parentId, IEnumerable<T> items);
    }
}