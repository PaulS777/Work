﻿using System;
using Dsp.DataContracts;

namespace Dsp.ServiceContracts
{
    public interface ISubscriptionFactory : IDisposable
    {
        ISubscription<T> Create<T>() where T : IIdentifiable;
    }
}