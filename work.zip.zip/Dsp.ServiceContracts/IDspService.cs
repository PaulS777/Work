﻿using System.Threading;
using System.Threading.Tasks;

namespace Dsp.ServiceContracts
{
    public interface IDspService
    {
        /// <summary>
        /// Triggered when the application host is ready to start the service.
        /// </summary>
        /// <param name="cancellationToken">Indicates that the start process has been aborted.</param>
        Task StartAsync(CancellationToken cancellationToken);

        /// <summary>
        /// Triggered when the application host is performing a graceful shutdown.
        /// </summary>
        /// <param name="cancellationToken">Indicates that the shutdown process should no longer be graceful.</param>
        Task StopAsync(CancellationToken cancellationToken);

        /// <summary>
        /// All subscriptions have succeeded and data is available.
        /// </summary>
        bool IsRunningSuccessfully { get; }

        /// <summary>
        /// Stop has been called for the service
        /// </summary>
        bool IsStopCalled { get; }

    }
}