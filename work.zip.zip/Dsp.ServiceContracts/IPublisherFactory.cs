﻿using System;
using Dsp.DataContracts;

namespace Dsp.ServiceContracts
{
    public interface IPublisherFactory : IDisposable
    {
        
        IPublisher<T> Create<T>() where T:IIdentifiable;
     }
}