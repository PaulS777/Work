﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.ServiceContracts
{
    public interface IDerivedCurveDefinitionValidator
    {
        //below 3 properties should be refactored to remove coupling with PartitionedCurveSelector
        IReadOnlyDictionary<int, DerivedCurveDefinitionBase<MonthlyTenor>> MonthlyCurves { get; }
        IReadOnlyDictionary<int, DerivedCurveDefinitionBase<DailyTenor>> DailyCurves { get; }
        Dictionary<int, Calendar> Calendars { get; }

        IReadOnlyList<PricingFailure> Validate(IEnumerable<DerivedCurveDefinition> updates);

        IReadOnlyList<PricingFailure> Submit(IEnumerable<DerivedCurveDefinition> updates);
    }
}
