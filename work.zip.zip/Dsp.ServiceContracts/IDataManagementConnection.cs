﻿namespace Dsp.ServiceContracts
{
    /// <summary>
    /// A single method to determine whether the Data Management Service is connected
    /// </summary>
    public interface IDataManagementConnection
    {
        bool IsConnected();
    }
}
