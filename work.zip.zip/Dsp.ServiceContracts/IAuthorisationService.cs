﻿using System.Collections.Generic;
using Dsp.DataContracts;

namespace Dsp.ServiceContracts
{
    /// <summary>
    /// Read/write authorisation methods.
    /// <br></br>
    /// Update Handler methods.
    /// </summary>
    public interface IAuthorisationService
    {
        void HandleDataUpdateNotification<T>(RefDataUpdate<T> refDataUpdate) where T : IIdentifiable;
        
        bool CanUpdate<T>(int userId, List<T> items, out string failureMessage) where T : IIdentifiable;
        bool CanRead<T>(int userId, List<int> items) where T : IIdentifiable;
        bool CanDelete<T>(int userId, int id, out string failureMessage) where T : IIdentifiable;

        IList<int> GetPriceCurvesWithReadAccess(int userId, IEnumerable<int> priceCurveIds);

        IList<int> GetPriceCurvesWithUpdateAccess(int userId, IEnumerable<int> priceCurveIds);

        IList<int> GetFxCurvesWithReadAccess(int userId, IEnumerable<int> fxCurveIds);
    }
}