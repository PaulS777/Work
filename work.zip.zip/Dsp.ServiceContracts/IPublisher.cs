﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;

namespace Dsp.ServiceContracts
{
    public interface IPublisher<in T>: IDisposable where T : IIdentifiable
    {
        void Publish(T message);
        void Publish(IEnumerable<T> messages);
    }
}