﻿
namespace Dsp.ServiceContracts
{
    public interface ITaskHandlerServiceFactory
    {
        ITaskHandlerService Create();
        ITaskHandlerService<T> Create<T>();
        ITaskHandlerServiceFactory SetInstance(int instance);
    }
}
