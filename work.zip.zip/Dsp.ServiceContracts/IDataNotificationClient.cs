﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.DataContracts.AdminActions;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Configuration;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.DataContracts.WebApi;

namespace Dsp.ServiceContracts
{
    public interface IDataNotificationClient
    {
        Task DisconnectClient();

        Task HandleConnectionStatus(ApiConnectionStatus status, User user);

        Task SubscribePriceCurveDefinitions();

        Task UnsubscribePriceCurveDefinitions();

        Task SubscribeFxCurveDefinitions();

        Task UnsubscribeFxCurveDefinitions();

        Task SubscribeDerivedCurveDefinitions();

        Task UnsubscribeDerivedCurveDefinitions();

        Task SubscribeUsers();

        Task UnsubscribeUsers();
        Task SubscribePriceCurves(IEnumerable<int> curveIds);

        Task UnsubscribePriceCurves(IEnumerable<int> curveIds);

        Task SubscribeFxCurves(IEnumerable<int> curveIds);

        Task UnsubscribeFxCurves(IEnumerable<int> curveIds);
        Task SubscribeProductDefinitions(IEnumerable<int> productDefinitionIds);
        Task UnsubscribeProductDefinitions(IEnumerable<int> productDefinitionIds);
        Task SubscribeClientApiKeys(IEnumerable<int> clientApiKeys);
        Task UnsubscribeClientApiKeys(IEnumerable<int> clientApiKeys);
        Task SubscribeCurrencyCodes(IEnumerable<int> currencyCodes);
        Task UnsubscribeCurrencyCodes(IEnumerable<int> currencyCodes);
        Task SubscribeChatUsers();

        Task UnsubscribeChatUsers();

        Task SubscribeChatMarkets();

        Task UnsubscribeChatMarkets();

        Task SubscribeChatMessageHistory();

        Task UnsubscribeChatMessageHistory();

        Task SubscribeChatVariableShortcut();

        Task UnsubscribeChatVariableShortcut();

        Task SubscribeChatIceMap();

        Task UnsubscribeChatIceMap();
        Task SubscribeChatPriceSummary();
        Task UnsubscribeChatPriceSummary();

        Task SubscribeServiceStatusNotification();
        
        Task UnsubscribeServiceStatusNotification();

        Task SubscribeCalendars();
        Task UnsubscribeCalendars();

        Task SubscribeMonthEndRollStatus();

        Task UnsubscribeMonthEndRollStatus();

        Task SubscribeConfiguration();

        Task UnsubscribeConfiguration();

        Task SubscribeSystemDate();

        Task UnsubscribeSystemDate();

        Task SubscribeCurveGroup();

        Task UnsubscribeCurveGroup();

        Task HandleUsersNotification(IEnumerable<User> models, string correlationId);

        Task HandlePriceCurveDefinitionsNotification(IEnumerable<PriceCurveDefinition> models, string correlationId);

        Task HandleFxCurveDefinitionsNotification(IEnumerable<FxCurveDefinition> models, string correlationId);

        Task HandleDerivedCurveDefinitionsNotification(IEnumerable<DerivedCurveDefinition> models, string correlationId);

        Task HandlePriceCurveSettingNotification(PriceCurveSetting model, string correlationId);

        Task HandleFxCurveSettingNotification(FxCurveSetting model, string correlationId);

        Task HandleFxCurveSnapshotNotification(IEnumerable<FxCurveSetting> curveSettings, IEnumerable<FxCurvePipsBuffer> curvePips, string correlationId);

        Task HandlePriceCurvePremiumNotification(PriceCurvePremium model, string correlationId);

        Task HandlePublisherTenorPremiumNotification(PublisherTenorPremium model, string correlationId);

        Task HandleFxCurvePipsBufferNotification(FxCurvePipsBuffer model, string correlationId);

        Task HandlePriceCurveSnapshotNotification(IEnumerable<PriceCurveSetting> curveSettings,
                                                  IEnumerable<PriceCurvePremium> priceCurvePremiums,
                                                  IEnumerable<PublisherTenorPremium> publisherTenorPremiums, string correlationId);

        Task HandlePriceCurveDefinitionsSnapshot(IEnumerable<PriceCurveDefinition> models, string correlationId);

        Task HandleFxCurveDefinitionsSnapshot(IEnumerable<FxCurveDefinition> models, string correlationId);

        Task HandleUsersSnapshot(IEnumerable<User> models, string correlationId);

        Task HandleDerivedCurveDefinitionsSnapshot(IEnumerable<DerivedCurveDefinition> models, string correlationId);

        Task HandleChatUsersSnapshot(IEnumerable<ChatUser> models, string correlationId);

        Task HandleChatUsersNotification(IEnumerable<ChatUser> models, string correlationId);

        Task HandleChatMarketsSnapshot(IEnumerable<ChatMarket> models, string correlationId);

        Task HandleChatMarketsNotification(IEnumerable<ChatMarket> models, string correlationId);

        Task HandleChatMessageHistorySnapshot(IEnumerable<ChatMessageHistory> models, string correlationId);

        Task HandleChatMessageHistoryNotification(IEnumerable<ChatMessageHistory> models, string correlationId);

        Task HandleChatVariableShortcutSnapshot(IEnumerable<ChatVariableShortcut> models, string correlationId);

        Task HandleChatVariableShortcutNotification(IEnumerable<ChatVariableShortcut> models, string correlationId);

        Task HandleChatIceMapSnapshot(IEnumerable<ChatIceMap> models, string correlationId);

        Task HandleChatIceMapNotification(IEnumerable<ChatIceMap> models, string correlationId);

        Task HandleChatPriceSummarySnapshot(IEnumerable<ChatPriceSummary> models, string correlationId);

        Task HandleChatPriceSummaryNotification(IEnumerable<ChatPriceSummary> models, string correlationId);

        Task HandleServiceStatusNotificationSnapshot(IEnumerable<ServiceStatusNotification> models, string correlationId);

        Task HandleServiceStatusNotification(IEnumerable<ServiceStatusNotification> models, string correlationId);

        Task HandleCalendarSnapshot(IEnumerable<Calendar> models, string correlationId);

        Task HandleCalendarNotification(IEnumerable<Calendar> models, string correlationId);
        
        Task HandleMonthEndRollStatusSnapshot(IEnumerable<MonthEndRollStatus> models, string correlationId);

        Task HandleMonthEndRollStatusNotification(IEnumerable<MonthEndRollStatus> models, string correlationId);

        Task HandleConfigurationSnapshot(IEnumerable<DynamicConfiguration> models, string correlationId);

        Task HandleConfigurationNotification(IEnumerable<DynamicConfiguration> models, string correlationId);

        Task HandleSystemDateSnapshot(SystemDate model, string correlationId);
        Task HandleSystemDateNotification(SystemDate model, string correlationId);
        Task HandleProductDefinitionSnapshot(IEnumerable<ProductDefinition> models, string correlationId);
        Task HandleProductDefinitionNotification(IEnumerable<ProductDefinition> models, string correlationId);
        Task HandleClientApiKeySnapshot(IEnumerable<ClientApiKey> models, string correlationId);
        Task HandleClientApiKeyNotification(IEnumerable<ClientApiKey> models, string correlationId);
        Task HandleCurrencyCodeSnapshot(IEnumerable<CurrencyCode> models, string correlationId);
        Task HandleCurrencyCodeNotification(IEnumerable<CurrencyCode> models, string correlationId);
        Task HandleCurveGroupSnapshot(IEnumerable<CurveGroup> models, string correlationId);
        Task HandleCurveGroupNotification(IEnumerable<CurveGroup> models, string correlationId);
        Task HandleValidatePriceCurveFormulaResponseSnapshot(IEnumerable<ValidatePriceCurveFormulaResponse> models, string correlationId);
        Task HandleValidatePriceCurveFormulaResponseNotification(IEnumerable<ValidatePriceCurveFormulaResponse> models, string correlationId);
    }
}