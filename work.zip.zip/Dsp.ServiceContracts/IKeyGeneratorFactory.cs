﻿namespace Dsp.ServiceContracts
{
    public interface IKeyGeneratorFactory
    {
        IKeyGenerator GetKeyGenerator<T>();
    }
}
