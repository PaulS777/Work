﻿namespace Dsp.Serialization
{
    public enum SerializerFormat
    {
        Protobuf = 1,
        Json = 2
    }
}
