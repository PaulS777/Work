﻿using System;
using Dsp.DataContracts;
using Google.Protobuf.WellKnownTypes;

namespace Dsp.Serialization
{
    public static class ProtoConverter
    {
        public static int ToProto(this TimeSpan input)
        {
            return input.Hours * 10000 + input.Minutes * 100 + input.Seconds;
        }
        public static TimeSpan FromProtoToTimeSpan(int input)
        {
            return new TimeSpan(input / 10000, input / 100 % 100, input % 100);
        }
        public static int ToProto(this int? input)
        {
            return input ?? 0;
        }
        public static int? FromProtoToNullableInt(int input)
        {
            return input == 0 ? null : input;
        }

        public static double ToProto(this double? input)
        {
            return input ?? double.NaN;
        }

        public static double? FromProtoToNullableDouble(double input)
        {
            return double.IsNaN(input) ? null : input;
        }

        public static string ToProto(this string input)
        {
            return input ?? string.Empty;
        }

        public static string FromProtoToNullableString(string input)
        {
            return string.IsNullOrEmpty(input) ? null : input;
        }

        public static Timestamp ToProto(this DateTime input)
        {
            return Timestamp.FromDateTime(DateTime.SpecifyKind(input, DateTimeKind.Utc));
        }

        public static Timestamp ToProto(this DateTime ?input)
        {
            return input!=null ? Timestamp.FromDateTime(DateTime.SpecifyKind( (DateTime) input, DateTimeKind.Utc)) : null;
        }

        public static DateTime FromProtoToDateTime(Timestamp input)
        {
            return input.ToDateTime();
        }

        public static DateTime FromProtoToDate(Timestamp input)
        {
            return DateTime.SpecifyKind(input.ToDateTime().Date, DateTimeKind.Unspecified);
        }

        public static DateTime? FromProtoToNullableDateTime(Timestamp input)
        {
            return input?.ToDateTime();
        }

        public static Timestamp FromProtoToTimeStamp(DateTime input)
        {
            return input.ToTimestamp();
        }

        public static Timestamp FromProtoToUtcToTimeStamp(DateTime input)
        {
            return TimeZoneInfo.ConvertTimeToUtc(input).ToTimestamp();
        }
        
        public static T FromProtoToEnum<T>(int input) where T: struct
        {
            return (T)(object)input;
        }

        public static DateTime ConvertIntToDate(int packedDate)
        {
            return new DateTime(packedDate / 10000 % 10000, packedDate / 100 % 100, packedDate % 100);
        }

        public static int ConvertTimeToInt(TimeSpan time)
        {
            return int.Parse(time.ToString("hhmmss"));
        }

        public static int ToProto(this ITenor input)
        {
            return input?.ConvertToInt() ?? -1;
        }
    }
}