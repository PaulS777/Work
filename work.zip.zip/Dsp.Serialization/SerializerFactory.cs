﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;

namespace Dsp.Serialization
{
    public class SerializerFactory : ISerializerFactory
    {
        public ISerializer<T> Create<T>(SerializerFormat format = SerializerFormat.Protobuf)
        {
            switch (format)
            {
                case SerializerFormat.Protobuf:
                    return CreateProtobuf<T>();

                case SerializerFormat.Json:
                    return CreateJson<T>();

                default:
                    throw new ArgumentException($"{typeof(T)} has no serializers defined for {format}");
            }
        }

        /// <summary>
        /// Create a Protobuf serializer for the given type.
        ///
        /// NB Only the high frequency types are actually Protobuf serialised - the rest simply use JSON as there is no need for the performance gain.
        ///
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        private static ISerializer<T> CreateProtobuf<T>()
        {
            var argType = typeof(T);

            if (typeof(MarketDataUpdate) == argType)
            {
                return (ISerializer<T>)new MarketDataUpdateSerializer();
            }

            if (typeof(PriceCurve) == argType)
            {
                return (ISerializer<T>)new PriceCurveSerializer();
            }

            if (typeof(FxPriceCurve) == argType)
            {
                return (ISerializer<T>)new FxPriceCurveSerializer();
            }

            return CreateJson<T>();
        }

        private static ISerializer<T> CreateJson<T>()
        {
            return new JsonSerializer<T>();
        }
    }
}