﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Google.Protobuf;

namespace Dsp.Serialization
{
    public class PriceCurveSerializer : ISerializer<PriceCurve>
    {
        public byte[] Serialize(PriceCurve input)
        {
            var dailyPrices = SerializeTenorPrices(input.DailyPrices);
            
            var weeklyPrices = SerializeTenorPrices(input.WeeklyPrices);
            var monthlyPrices = SerializeTenorPrices(input.MonthlyPrices);
            var quarterlyPrices = SerializeTenorPrices(input.QuarterlyPrices);
            var halfYearPrices = SerializeTenorPrices(input.HalfYearPrices);
            var annualPrices = SerializeTenorPrices(input.AnnualPrices);
            var pricingFailure = SerializePricingFailure(input.PricingFailure);

            var price = new PriceCurveProto
            {
                Id = input.Id,
                ProductName = input.ProductName,
                PublisherId = input.PublisherId,
                Publisher = input.Publisher,
                Timestamp = input.Timestamp.ToProto(),
                Tradeable = input.Tradeable,
                Validity = (int)input.Validity,
                DailyPrices =  dailyPrices,
                WeeklyPrices = weeklyPrices,
                MonthlyPrices = monthlyPrices,
                QuarterlyPrices = quarterlyPrices,
                HalfYearPrices = halfYearPrices,
                AnnualPrices = annualPrices,
                PricingFailure = pricingFailure
            };
            
            var pa = price.ToByteArray();
            var paz = Compress(pa);
            return paz;
        }

        public string SerializeToString(PriceCurve input)
        {
            throw new NotSupportedException();
        }

        private static byte[] Compress(byte[] data)
        {
            using var compressedStream = new MemoryStream();
            using (var zipStream = new GZipStream(compressedStream, CompressionMode.Compress))
            {
                zipStream.Write(data, 0, data.Length);
            }

            return compressedStream.ToArray();
        }

        private static byte[] Decompress(byte[] data)
        {
            using var compressedStream = new MemoryStream(data);
            using var zipStream = new GZipStream(compressedStream, CompressionMode.Decompress);
            using var resultStream = new MemoryStream();
            zipStream.CopyTo(resultStream);
            return resultStream.ToArray();
        }
        private static byte[] Decompress(ArraySegment<byte> contents)
        {
            // ReSharper disable once AssignNullToNotNullAttribute
            using var compressedStream = new MemoryStream(contents.Array, contents.Offset, contents.Count);
            using var zipStream = new GZipStream(compressedStream, CompressionMode.Decompress);
            using var resultStream = new MemoryStream();
            zipStream.CopyTo(resultStream);
            return resultStream.ToArray();
        }

        private static PricingFailureProto SerializePricingFailure(PricingFailure input)
        {
            if (input == null)
            {
                return null;
            }

            return new PricingFailureProto
            {
                PriceCurveId = input.PriceCurveId,
                DerivedCurveId = input.DerivedCurveId,
                Reason = (int)input.Reason,
                RelatedCurveId = !input.LinkedCurve.HasValue ? null : new Reference
                {
                    Id = input.LinkedCurve.Value.Id,
                    CurveType = (int)input.LinkedCurve.Value.DefinitionType
                },
                Details = input.Details
            };
        }

        public string SerializeToString(MarketDataUpdate input)
        {
            throw new NotSupportedException();
        }

        public PriceCurve Deserialize(byte[] contents)
        {
            var proto = PriceCurveProto.Parser.ParseFrom(Decompress(contents));
            return MakePriceCurve(proto);
        }

        public PriceCurve Deserialize(ArraySegment<byte> contents)
        {
            var proto = PriceCurveProto.Parser.ParseFrom(Decompress(contents));
            return MakePriceCurve(proto);
        }

        private static PriceCurve MakePriceCurve(PriceCurveProto proto)
        {
            var dailyPrices = TenorPricesFromProto(proto.DailyPrices, DailyTenor.ConvertFromInt);
            var weeklyPrices = TenorPricesFromProto(proto.WeeklyPrices, WeeklyTenor.ConvertFromInt);
            var monthlyPrices = TenorPricesFromProto(proto.MonthlyPrices, MonthlyTenor.ConvertFromInt);
            var quarterlyPrices = TenorPricesFromProto(proto.QuarterlyPrices, QuarterlyTenor.ConvertFromInt);
            var halfYearPrices = TenorPricesFromProto(proto.HalfYearPrices, HalfYearTenor.ConvertFromInt);
            var annualPrices = TenorPricesFromProto(proto.AnnualPrices, AnnualTenor.ConvertFromInt);

            var pricingFailure = DeserializePricingFailure(proto.PricingFailure);

            return new PriceCurve(proto.Id, proto.ProductName, proto.PublisherId, proto.Publisher, proto.Timestamp.ToDateTime(), 
                proto.Tradeable, (ValidityIndicator)proto.Validity, dailyPrices, weeklyPrices, monthlyPrices, quarterlyPrices, halfYearPrices, annualPrices, pricingFailure);
        }

        public static TenorPrices<T> TenorPricesFromProto<T>(TenorPricesProto protoPrices, Func<int,T> intConverter) where T : ITenor
        {
            return protoPrices != null
                ? new TenorPrices<T>(
                    protoPrices.Tenors.Select(intConverter).ToArray(),
                    protoPrices.BidPrices.Select(ProtoConverter.FromProtoToNullableDouble).ToArray(),
                    protoPrices.MidPrices.Select(ProtoConverter.FromProtoToNullableDouble).ToArray(),
                    protoPrices.AskPrices.Select(ProtoConverter.FromProtoToNullableDouble).ToArray(),
                    protoPrices.PrevClosePrices.Select(ProtoConverter.FromProtoToNullableDouble).ToArray(),
                    EfpMonthsFromProto(protoPrices),
                    EfpValuesFromProto(protoPrices)
                )
                : null;
        }

        private static List<double?> EfpValuesFromProto(TenorPricesProto protoPrices)
        {
            return protoPrices.EfpValues.Count == 0 ? null : protoPrices.EfpValues.Select(ProtoConverter.FromProtoToNullableDouble).ToList();
        }

        private static List<MonthlyTenor?> EfpMonthsFromProto(TenorPricesProto protoPrices)
        {
            return protoPrices.EfpMonths.Count == 0 
                ? null 
                : protoPrices.EfpMonths.Select(x => x == -1 ? (MonthlyTenor?)null : MonthlyTenor.ConvertFromInt(x)).ToList();
        }

        public static TenorPricesProto SerializeTenorPrices<T>(TenorPrices<T> source) where T : ITenor
        {
            if (source == null)
            {
                return null;
            }

            var prices = new TenorPricesProto();
            prices.Tenors.AddRange(source.Tenors.Select(x => x.ConvertToInt()));
            prices.BidPrices.AddRange(source.BidPrices.Select(ProtoConverter.ToProto));
            prices.MidPrices.AddRange(source.MidPrices.Select(ProtoConverter.ToProto));
            prices.AskPrices.AddRange(source.AskPrices.Select(ProtoConverter.ToProto));
            prices.PrevClosePrices.AddRange(source.PrevClosePrices.Select(ProtoConverter.ToProto));
            if (source.EfpMonths?.Count > 0)
            {
                prices.EfpMonths.AddRange(source.EfpMonths.Select(x=> x.ToProto()));
            }
            if (source.EfpValues?.Count > 0)
            {
                prices.EfpValues.AddRange(source.EfpValues.Select(ProtoConverter.ToProto));
            }

            return prices;
        }

        private static PricingFailure DeserializePricingFailure(PricingFailureProto proto)
        {
            if(proto == null)
            {
                return null;
            }

            return new PricingFailure(proto.PriceCurveId, proto.DerivedCurveId, (PricingFailureReason) proto.Reason,
                proto.RelatedCurveId == null
                    ? null
                    : new LinkedCurve(proto.RelatedCurveId.Id,
                        (PriceCurveDefinitionType) proto.RelatedCurveId.CurveType),
                proto.Details);

        }
    }
}