﻿using System;
using Dsp.DataContracts;
using Google.Protobuf;

namespace Dsp.Serialization
{
    public class MarketDataUpdateSerializer : ISerializer<MarketDataUpdate>
    {
        public byte[] Serialize(MarketDataUpdate input)
        {
            var proto = new MarketDataProto
            {
                BaseCurveId = input.BaseCurveId,
                MarketDataUpdateType = (int) input.MarketDataUpdateType,
                ContractDate = int.Parse(input.ContractDate.ToString("yyyyMMdd"))
            };

            if (input.SpreadDate.HasValue)
            {
                proto.SpreadDate = int.Parse(input.SpreadDate.Value.ToString("yyyyMMdd"));
            }

            if (input.ExpiryDate.HasValue)
            {
                proto.ExpiryDate = int.Parse(input.ExpiryDate.Value.ToString("yyyyMMdd"));
            }

            if (input.Close.HasValue)
            {
                proto.HistClose = input.Close.Value;
            }

            if (input.Low.HasValue)
            {
                proto.Low = input.Low.Value;
            }

            if (input.High.HasValue)
            {
                proto.High = input.High.Value;
            }

            if (input.Last.HasValue)
            {
                proto.Last = input.Last.Value;
            }

            if (input.Bid.HasValue)
            {
                proto.Bid = input.Bid.Value;
            }

            if (input.Ask.HasValue)
            {
                proto.Ask = input.Ask.Value;
            }

            if (input.Volume.HasValue)
            {
                proto.TotalVolume = input.Volume.Value;
            }

            if (input.AskSize.HasValue)
            {
                proto.AskSize = input.AskSize.Value;
            }

            if (input.BidSize.HasValue)
            {
                proto.BidSize = input.BidSize.Value;
            }

            return proto.ToByteArray();
        }

        public string SerializeToString(MarketDataUpdate input)
        {
            throw new NotSupportedException();
        }

        public MarketDataUpdate Deserialize(byte[] contents)
        {
            var proto = MarketDataProto.Parser.ParseFrom(contents);
            return MakeMarketDataUpdate(proto);
        }

        public MarketDataUpdate Deserialize(ArraySegment<byte> contents)
        {
            var proto = MarketDataProto.Parser.ParseFrom(contents.Array, contents.Offset, contents.Count);
            return MakeMarketDataUpdate(proto);
        }

        private static MarketDataUpdate MakeMarketDataUpdate(MarketDataProto proto)
        {
            return new MarketDataUpdate(
                proto.BaseCurveId,
                (MarketDataUpdateType) proto.MarketDataUpdateType,
                ProtoConverter.ConvertIntToDate(proto.ContractDate),
                proto.SpreadDateFieldCase.HasFlag(MarketDataProto.SpreadDateFieldOneofCase.SpreadDate)
                    ? ProtoConverter.ConvertIntToDate(proto.SpreadDate)
                    : null,
                proto.ExpiryDateFieldCase.HasFlag(MarketDataProto.ExpiryDateFieldOneofCase.ExpiryDate)
                    ? ProtoConverter.ConvertIntToDate(proto.ExpiryDate)
                    : null,
                proto.HistCloseFieldCase.HasFlag(MarketDataProto.HistCloseFieldOneofCase.HistClose)
                    ? proto.HistClose
                    : null,
                proto.LowFieldCase.HasFlag(MarketDataProto.LowFieldOneofCase.Low) ? proto.Low : null,
                proto.HighFieldCase.HasFlag(MarketDataProto.HighFieldOneofCase.High) ? proto.High : null,
                proto.LastFieldCase.HasFlag(MarketDataProto.LastFieldOneofCase.Last) ? proto.Last : null,
                proto.BidFieldCase.HasFlag(MarketDataProto.BidFieldOneofCase.Bid) ? proto.Bid : null,
                proto.AskFieldCase.HasFlag(MarketDataProto.AskFieldOneofCase.Ask) ? proto.Ask : null,
                proto.BidSizeFieldCase.HasFlag(MarketDataProto.BidSizeFieldOneofCase.BidSize) ? proto.BidSize : null,
                proto.AskSizeFieldCase.HasFlag(MarketDataProto.AskSizeFieldOneofCase.AskSize) ? proto.AskSize : null,
                proto.TotalVolumeFieldCase.HasFlag(MarketDataProto.TotalVolumeFieldOneofCase.TotalVolume)
                    ? proto.TotalVolume
                    : null
            );
        }
    }
}