﻿using System;
using System.Text;
using Dsp.DataContracts;
using Dsp.DataContracts.JsonConverters;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Dsp.Serialization
{
    /// <summary>
    /// Default serialiser for DSP - uses custom resolvers for some types
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class JsonSerializer<T> : ISerializer<T>
    {
        static JsonSerializer()
        {
            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
                {ContractResolver = CustomContractResolver.Instance};
        }
        public byte[] Serialize(T input)
        {
            return Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(input, Formatting.None));
        }

        public string SerializeToString(T input)
        {
            return JsonConvert.SerializeObject(input, Formatting.None);
        }

        public T Deserialize(byte[] contents)
        {
            return JsonConvert.DeserializeObject<T>(Encoding.UTF8.GetString(contents));
        }

        public T Deserialize(ArraySegment<byte> contents)
        {
            // ReSharper disable once AssignNullToNotNullAttribute
            return JsonConvert.DeserializeObject<T>(Encoding.UTF8.GetString(contents.Array, contents.Offset, contents.Count));
        }
    }

    /// <summary>
    /// Custom contracts for JSON serialisation of Tenors
    /// </summary>
    public class CustomContractResolver : DefaultContractResolver
    {
        public static readonly CustomContractResolver Instance = new();

        protected override JsonContract CreateContract(Type objectType)
        {
            var contract = base.CreateContract(objectType);

            if (objectType == typeof(ITenor))
            {
                contract.Converter = new TenorJsonConverter();
            }
            else if (objectType == typeof(DailyTenor))
            {
                contract.Converter = new DailyTenorConverter();
            }
            else if (objectType == typeof(WeeklyTenor))
            {
                contract.Converter = new WeeklyTenorConverter();
            }
            else if (objectType == typeof(MonthlyTenor))
            {
                contract.Converter = new MonthlyTenorJsonConverter();
            }
            else if (objectType == typeof(QuarterlyTenor))
            {
                contract.Converter = new QuarterlyTenorJsonConverter();
            }
            else if(objectType == typeof(HalfYearTenor))
            {
                contract.Converter = new HalfYearTenorJsonConverter();
            }
            else if (objectType == typeof(AnnualTenor))
            {
                contract.Converter = new AnnualTenorJsonConverter();
            }
            else if (objectType.IsEnum)
            {
                contract.Converter = new StringEnumConverter();
            }

            return contract;
        }
    }
}
