﻿using System;

namespace Dsp.Serialization
{
    public interface ISerializer<T>
    {
        byte[] Serialize(T input);
        string SerializeToString(T input);

        T Deserialize(byte[] contents);

        T Deserialize(ArraySegment<byte> contents);
    }
}
