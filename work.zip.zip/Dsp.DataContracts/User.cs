﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record User : DeletableEntity
    {
        [JsonProperty]
        [Required]
        public string UserName { get; init; }

        [JsonProperty]
        [Required]
        public string DisplayName { get; init; }

        [JsonProperty]
        [Required]
        public bool IsAdmin { get; init; }

        [JsonProperty]
        [Required]
        public bool IsEnabled { get; init; }

        [JsonProperty]
        [Required]
        public double SpreadMultiplier { get; init; }

        [JsonProperty]
        [Required]
        public int WarnAfterInactivityMinutes { get; init; }

        [JsonProperty]
        [Required]
        public int ErrorAfterInactivityMinutes { get; init; }

        [JsonProperty]
        [Required]
        public IList<AuthorisationCurveGroup> CurveGroupPermissions { get; init; }

        [JsonProperty]
        [Required]
        public IList<AuthorisationCurveRegion> CurveRegionPermissions { get; init; }

        [JsonProperty]
        [Required]
        public IList<AuthorisationFxCurve> FxCurvePermissions { get; init; }

        [JsonProperty]
        [Required]
        public IList<UserChatTenorSelection> ChatTenorSelections { get; init; }

        [JsonProperty]
        [Required]
        public IList<AuthorisationUserPermission> AuthorisationUserPermissions { get; init; }

        [JsonIgnore]
        public bool IsPublisher => CurveGroupPermissions.Any(x => x.CanUpdate) ||
                                   CurveRegionPermissions.Any(x => x.CanUpdate);

        [JsonIgnore]
        public bool IsEomRoll => AuthorisationUserPermissions.Any(x => x.CategoryName == PermissionCategory.EomRoll.ToString() && x.Value);

        public bool HasPrivilege(PermissionCategory permissionCategory)
        {
            var userPermission = AuthorisationUserPermissions.FirstOrDefault(p => p.CategoryName == permissionCategory.ToString());

            return userPermission is { Value: true };
        }

        // for testing/builders only
        public User() : base(int.MinValue, EntityStatus.Active)
        { }


        public User(int id,
            string userName,
            string displayName,
            bool isAdmin,
            bool isEnabled,
            double spreadMultiplier,
            int warnAfterInactivityMinutes,
            int errorAfterInactivityMinutes,
            IEnumerable<AuthorisationCurveGroup> curveGroupPermissions,
            IEnumerable<AuthorisationCurveRegion> curveRegionPermissions,
            IEnumerable<AuthorisationFxCurve> fxCurvePermissions,
            IEnumerable<UserChatTenorSelection> chatTenorSelections,
            IEnumerable<AuthorisationUserPermission> authorisationUserPermissions,
            EntityStatus status = EntityStatus.Active) : base(id, status)
        {
            DisplayName = displayName;
            UserName = userName;
            IsAdmin = isAdmin;
            IsEnabled = isEnabled;
            SpreadMultiplier = spreadMultiplier;
            WarnAfterInactivityMinutes = warnAfterInactivityMinutes;
            ErrorAfterInactivityMinutes = errorAfterInactivityMinutes;
            CurveGroupPermissions = curveGroupPermissions.ToList();
            CurveRegionPermissions = curveRegionPermissions.ToList();
            FxCurvePermissions = fxCurvePermissions.ToList();
            ChatTenorSelections = chatTenorSelections.ToList();
            AuthorisationUserPermissions = authorisationUserPermissions.ToList();
        }

        public override string ToString()
        {
            return
                $"{nameof(Id)}: {Id}, {nameof(UserName)}: {UserName}, {nameof(DisplayName)}: {DisplayName}, {nameof(IsAdmin)}: {IsAdmin}, " +
                $"{nameof(IsEnabled)}: {IsEnabled}, {nameof(SpreadMultiplier)}: {SpreadMultiplier}, " +
                $"{nameof(WarnAfterInactivityMinutes)}: {WarnAfterInactivityMinutes}, " +
                $"{nameof(ErrorAfterInactivityMinutes)}: {ErrorAfterInactivityMinutes}, " +
                $"{nameof(CurveGroupPermissions)}: [{string.Join(",", CurveGroupPermissions)}], " +
                $"{nameof(CurveRegionPermissions)}: [{string.Join(",", CurveRegionPermissions)}], " +
                $"{nameof(FxCurvePermissions)}: [{string.Join(",", FxCurvePermissions)}], " +
                $"{nameof(ChatTenorSelections)}: [{string.Join(",", ChatTenorSelections)}], " +
                $"{nameof(IsPublisher)}: {IsPublisher}, " +
                $"{nameof(AuthorisationUserPermissions)}: [{string.Join(",", AuthorisationUserPermissions)}]";
        }
    }
}