﻿/*====================================================================================
 *
 * WARNING: THIS ENUM FORMS PART OF THE VERSIONED API WITH DSX.
 *
 * Changing it will require a new API version (and potentially filtering new values
 * out of any previous API version to avoid breaking DSX)
 *
 =====================================================================================
*/
namespace Dsp.DataContracts.Quote
{
    public enum TriggerDirection
    {
        Above = 1,
        Below = 2
    }
}
