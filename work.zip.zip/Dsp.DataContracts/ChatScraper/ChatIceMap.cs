﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public record ChatIceMap : DeletableEntity
    {
        [JsonProperty]
        [Required]
        public string PriceCurveName { get; init; }

        [JsonProperty]
        [Required]
        public int ChatMarketId { get; init; }

        [JsonProperty]
        public int? PriceCurveDefinitionId { get; init; }

        [JsonProperty]
        public string Shortcuts { get; init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public ChatIceMap() : base(int.MinValue, EntityStatus.Active)
        { }

        public ChatIceMap(int id, EntityStatus status, string priceCurveName, int chatMarketId, int? priceCurveDefinitionId, string shortcuts) : base(id, status)
        {
            PriceCurveName = priceCurveName;
            ChatMarketId = chatMarketId;
            PriceCurveDefinitionId = priceCurveDefinitionId;
            Shortcuts = shortcuts;
        }

        public override string ToString()
        {
            return $"{nameof(PriceCurveName)}: {PriceCurveName}, {nameof(ChatMarketId)}: {ChatMarketId}, {nameof(PriceCurveDefinitionId)}: {PriceCurveDefinitionId}, {nameof(Shortcuts)}: {Shortcuts}";
        }
    }
}
