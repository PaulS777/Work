﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public record ChatPriceSummary : DeletableEntity
    {
        [JsonProperty] 
        public string PriceCurveName { get; init; }
        [JsonProperty] 
        public string Name { get; init; }
        [JsonProperty] 
        public List<ChatPriceTenor> MonthlyTenors { get; init; }
        [JsonProperty] 
        public List<ChatPriceTenor> QuarterlyTenors { get; init; }
        [JsonProperty] 
        public List<ChatPriceTenor> AnnualTenors { get; init; }
        [JsonProperty] 
        public List<ChatPriceTenor> CustomTenors { get; init; }


        public class ChatPriceTenor
        {
            [JsonProperty] 
            public string TenorKey { get; init; }

            [JsonProperty] 
            public string TenorName { get; init; }

            [JsonConverter(typeof(IsoDateTimeConverter))]
            [JsonProperty]
            public DateTime? BidTime { get; set; }

            [JsonProperty] 
            public double? BidPrice { get; set; }

            [JsonProperty] 
            public string BidBroker { get; set; }

            [JsonConverter(typeof(IsoDateTimeConverter))]
            [JsonProperty]
            public DateTime? AskTime { get; set; }

            [JsonProperty] 
            public double? AskPrice { get; set; }

            [JsonProperty] 
            public string AskBroker { get; set; }

            public ChatPriceTenor(string tenorKey, string tenorName, DateTime? bidTime, double? bidPrice, string bidBroker, DateTime? askTime, double? askPrice, string askBroker)
            {
                TenorKey = tenorKey;
                TenorName = tenorName;
                BidTime = bidTime;
                BidPrice = bidPrice;
                BidBroker = bidBroker ?? string.Empty;
                AskTime = askTime;
                AskPrice = askPrice;
                AskBroker = askBroker ?? string.Empty;
            }

            public ChatPriceTenor()
            {

            }

            public override string ToString()
            {
                return $"{TenorName}({TenorKey}):  Bid {BidPrice} by {BidBroker} at {BidTime}, Ask {AskPrice} by {AskBroker} at {AskTime}";
            }
        }

        public ChatPriceSummary(int id,
            string priceCurveName,
            string name,
            List<ChatPriceTenor> monthlyTenors,
            List<ChatPriceTenor> quarterlyTenors,
            List<ChatPriceTenor> annualTenors,
            List<ChatPriceTenor> customTenors) : base(id, EntityStatus.Active)
        {
            PriceCurveName = priceCurveName;
            Name = name;
            MonthlyTenors = monthlyTenors;
            QuarterlyTenors = quarterlyTenors;
            AnnualTenors = annualTenors;
            CustomTenors = customTenors;
        }
        
        public override string ToString()
        {
            return
                $@"{Id}/{PriceCurveName}/{Name}: {nameof(MonthlyTenors)}: [{string.Join(",",
                    MonthlyTenors)
                }], {nameof(QuarterlyTenors)}: [{string.Join(",",
                    QuarterlyTenors)
                }], {nameof(AnnualTenors)}: [{string.Join(",",
                    AnnualTenors)
                }], {nameof(CustomTenors)}: [{string.Join(",",
                    CustomTenors)
                }]";
        }
    }
}