﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public record ChatMessageHistory : DeletableEntity
    {
        [JsonConverter(typeof(IsoDateTimeConverter))]
        [JsonProperty]
        public DateTime TimeStamp { get; init; }

        [JsonProperty]
        public string SenderExternalRef { get; init; }

        [JsonProperty]
        public string ReceiverExternalRef { get; init; }

        [JsonProperty]
        public string PriceCurveName { get; init; }

        [JsonProperty]
        public string TenorString { get; init; }

        [JsonProperty]
        public string TenorClassified { get; init; }

        [JsonProperty]
        public DateTime? TenorStart { get; init; }

        [JsonProperty]
        public DateTime? TenorEnd { get; init; }

        [JsonProperty]
        public string PriceString { get; init; }

        [JsonProperty]
        public double? Bid { get; init; }

        [JsonProperty]
        public double? Offer { get; init; }

        [JsonProperty]
        public double? TradedPrice { get; init; }

        [JsonProperty]
        public string TradedVolume { get; init; }

        [JsonProperty]
        public int IsManuallyCorrected { get; init; }

        [JsonProperty]
        public int IsCommodityEstimated { get; init; }

        [JsonProperty]
        public int IsUnknownUser { get; init; }


        public ChatMessageHistory(int id,
            DateTime timeStamp,
            string senderExternalRef,
            string receiverExternalRef,
            string priceCurveName,
            string tenorString,
            string tenorClassified,
            DateTime? tenorStart,
            DateTime? tenorEnd,
            string priceString,
            double? bid,
            double? offer,
            double? tradedPrice,
            string tradedVolume,
            int isManuallyCorrected,
            int isCommodityEstimated,
            int isUnknownUser,
            EntityStatus status) : base(id, status)
        {
            TimeStamp = timeStamp;
            SenderExternalRef = senderExternalRef;
            ReceiverExternalRef = receiverExternalRef;
            PriceCurveName = priceCurveName;
            TenorString = tenorString;
            TenorClassified = tenorClassified;
            TenorStart = tenorStart;
            TenorEnd = tenorEnd;
            PriceString = priceString;
            Bid = bid;
            Offer = offer;
            TradedPrice = tradedPrice;
            TradedVolume = tradedVolume;
            IsManuallyCorrected = isManuallyCorrected;
            IsCommodityEstimated = isCommodityEstimated;
            IsUnknownUser = isUnknownUser;
        }

       public override string ToString()
        {
            return
                $@"{nameof(Id)}: {Id}, {nameof(TimeStamp)}: {TimeStamp}, {nameof(SenderExternalRef)}: {SenderExternalRef}, {nameof(ReceiverExternalRef)}: {ReceiverExternalRef}, {nameof(PriceCurveName)
                }: {PriceCurveName}, {nameof(TenorString)}: {TenorString}, {nameof(TenorClassified)}: {TenorClassified}, {nameof(TenorStart)}: {TenorStart}, {nameof(TenorEnd)}: {TenorEnd}, {
                    nameof(PriceString)
                }: {PriceString}, {nameof(Bid)}: {Bid}, {nameof(Offer)}: {Offer}, {nameof(TradedPrice)}: {TradedPrice}, {nameof(TradedVolume)}: {TradedVolume}, {
                        nameof(IsManuallyCorrected)
                }: {IsManuallyCorrected}, {nameof(IsCommodityEstimated)}: {IsCommodityEstimated}, {nameof(IsUnknownUser)}: {IsUnknownUser}";
        }
    }
}