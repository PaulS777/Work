﻿using System;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.DataContracts.Curve
{
    public class PriceCurve : PriceCurveBase
    {
        public PriceCurve(int id, string productName, int publisherId, string publisher, DateTime timestamp, bool tradeable, ValidityIndicator validity,
            TenorPrices<DailyTenor> dailyPrices,
            TenorPrices<WeeklyTenor> weeklyPrices,
            TenorPrices<MonthlyTenor> monthlyPrices,
            TenorPrices<QuarterlyTenor> quarterlyPrices,
            TenorPrices<HalfYearTenor> halfYearPrices,
            TenorPrices<AnnualTenor> annualPrices,
            PricingFailure pricingFailure = null) 
            : base(id,
            productName,
            publisherId,
            publisher,
            timestamp,
            tradeable,
            validity,
            dailyPrices,
            weeklyPrices,
            monthlyPrices,
            quarterlyPrices,
            halfYearPrices,
            annualPrices,
            pricingFailure)
        {
        }
        public PriceCurve()
        {
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}";
        }
    }
}