﻿/*====================================================================================
 *
 * WARNING: THIS ENUM FORMS PART OF THE VERSIONED API WITH DSX.
 *
 * Changing it will require a new API version (and potentially filtering new values
 * out of any previous API version to avoid breaking DSX)
 *
 =====================================================================================
*/

using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record CurveGroup : DeletableEntity
    {
        [JsonProperty]
        public string Name { get; init; }

        [JsonProperty]
        public string Colour { get; init; }

        [JsonProperty]
        public bool IsPublishable { get; init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public CurveGroup() : base(int.MinValue, EntityStatus.Active)
        { }

        public CurveGroup(int id, string name, string colour, bool isPublishable, EntityStatus status = EntityStatus.Active) : base(id, status)
        {
            Name = name;
            Colour = colour;
            IsPublishable = isPublishable;
        }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Name)}: {Name}, {nameof(Colour)}: {Colour}";
        }
    }
}