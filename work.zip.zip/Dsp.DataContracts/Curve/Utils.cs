﻿using System;

namespace Dsp.DataContracts.Curve
{
    public static class Utils
    {
        /// <summary>
        /// Returns validity of a curve base on publisher settings.
        /// </summary>
        /// <param name="utcNow">The current UTC time</param>
        /// <param name="utcLastModified">last modified time of curve</param>
        /// <param name="publisher">the curve publisher</param>
        /// <param name="forceInvalid">optional override to force the result to be Invalid</param>
        /// <returns></returns>
        public static ValidityIndicator DetermineValidity(DateTime utcNow, DateTime utcLastModified,
            User publisher, bool forceInvalid = false)
        {
            if (forceInvalid || publisher.ErrorAfterInactivityMinutes > 0 && utcLastModified.AddMinutes(publisher.ErrorAfterInactivityMinutes) < utcNow)
            {
                return ValidityIndicator.Invalid;
            }

            if (publisher.WarnAfterInactivityMinutes > 0 && utcLastModified.AddMinutes(publisher.WarnAfterInactivityMinutes) < utcNow)
            {
                return ValidityIndicator.Warning;
            }

            return ValidityIndicator.Valid;
        }
        public static ValidityIndicator ValidityFromBoolean(bool isValid)
        {
            return isValid ? ValidityIndicator.Valid : ValidityIndicator.Invalid;
        }
    }
}
