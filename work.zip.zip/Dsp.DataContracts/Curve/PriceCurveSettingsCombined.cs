﻿using System;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public sealed class PriceCurveSettingsCombined: IIdentifiable, IEquatable<PriceCurveSettingsCombined>
    {
        public int Id => Settings.Id;
        public PriceCurveSetting Settings { get; }
        public User User { get; }
        public PublisherTenorPremium PublisherTenorPremiums { get; }
        public PriceCurveSettingsCombined(PriceCurveSetting settings, User publisher, PublisherTenorPremium premiums)
        {
            Settings = settings;
            User = publisher;
            PublisherTenorPremiums = premiums;

            if (Settings.PriceCurveDefinitionId != PublisherTenorPremiums.PriceCurveId)
            {
                throw new ArgumentException($"Settings curve Id {Settings.PriceCurveDefinitionId} should be the same as publisher tenor premiums {PublisherTenorPremiums.PriceCurveId}",
                    nameof(settings));
            }

            if (Settings.PublisherId != User.Id)
            {
                throw new ArgumentException($"Settings publisher Id {Settings.PublisherId} should match user Id {User.Id}", nameof(settings));
            }

            if (PublisherTenorPremiums.PublisherId != User.Id)
            {
                throw new ArgumentException($"PublisherTenorPremium publisher Id {PublisherTenorPremiums.PublisherId} should match user id {User.Id}", nameof(premiums));
            }
        }

        /// <inheritdoc />
        public bool Equals(PriceCurveSettingsCombined other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }

            if (ReferenceEquals(this, other))
            {
                return true;
            }

            return Equals(Settings, other.Settings) && Equals(User, other.User) && Equals(PublisherTenorPremiums, other.PublisherTenorPremiums);
        }

        /// <inheritdoc />
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }

            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (obj.GetType() != GetType())
            {
                return false;
            }

            return Equals((PriceCurveSettingsCombined)obj);
        }

        /// <inheritdoc />
        public override int GetHashCode()
        {
            return HashCode.Combine(Settings, User, PublisherTenorPremiums);
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Settings)}: {Settings}, {nameof(User)}: {User}, {nameof(PublisherTenorPremiums)}: {PublisherTenorPremiums}";
        }
    }
}