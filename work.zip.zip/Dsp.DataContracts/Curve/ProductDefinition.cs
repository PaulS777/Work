﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.ValidationAttributes;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record ProductDefinition : DeletableEntity
    {
        private double? _tickSize;

        [JsonProperty]
        [Required]
        public string Name { get; init; }
        
        [JsonProperty]
        [Required]
        public string Description { get; init; }
                
        [JsonProperty(ItemConverterType = typeof(StringEnumConverter))]
        public IList<CurveRegion> MocRegions { get; init; }

        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        [Required]
        [EnumDataType(typeof(UnitOfMeasure) )]
        public UnitOfMeasure UnitOfMeasure { get; init; }

        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int LotSize { get; init; }

        [JsonProperty]
        [Required]
        public int PriceStep { get; init; }

        [JsonProperty]
        [Required]
        public int Precision { get; init; }

        [JsonProperty]
        public double TickSize
        {
            get
            {
                _tickSize ??= CalculateTickSize(Id, PriceStep, Precision);
                return _tickSize.Value;
            }
        }

        [JsonProperty]
        [Required]
        public int Currency { get; init; }

        [JsonProperty]
        [Required]
        public CurveGroup CurveGroup { get; init; }

        [JsonProperty]
        [Required]
        public int CurrencyDenominationFactor { get; init; }

        [JsonProperty]
        public Density Density { get; init; }

        [JsonProperty]
        [Required]
        public PricingTenorGroupType PricingTenorGroup { get; init; }

        // for testing/builders/serialization
        public ProductDefinition() : base(int.MinValue, EntityStatus.Active)
        { }

        public ProductDefinition(
            int id,
            string name,
            string description,
            IList<CurveRegion> mocRegions,
            CurveGroup curveGroup,
            int currency,
            UnitOfMeasure unitOfMeasure,
            int lotSize,
            int priceStep,
            int precision,
            Density density,
            int currencyDenominationFactor,
            PricingTenorGroupType pricingTenorGroupType = PricingTenorGroupType.Monthly,
            EntityStatus status = EntityStatus.Active) : base(id, status)
        {
            Name = name;
            Description = description;
            MocRegions = mocRegions;
            CurveGroup = curveGroup;
            Currency = currency;
            UnitOfMeasure = unitOfMeasure;
            LotSize = lotSize;
            PriceStep = priceStep;
            Precision = precision;
            Density = density;
            CurrencyDenominationFactor = currencyDenominationFactor;
            PricingTenorGroup = pricingTenorGroupType;

            Initialise();
        }

        public void Initialise()
        {
            if (UnitOfMeasure.IsUnitOfWeight() && Density == null)
            {
                throw new ArgumentNullException(nameof(Density),$"Density must be specified for product {Id} defined in unit of weight {UnitOfMeasure}");
            }
        }

        public static double CalculateTickSize(int priceCurveDefinitionId, int priceStep, int precision)
        {
            try
            {
                if (precision < 0)
                {
                    throw new ArgumentException($"PriceCurveDefinition:'{priceCurveDefinitionId}' the precision '{precision}' must be equal or greater than 0.", nameof(precision));
                }

                if (priceStep / (int)Math.Pow(10, precision) > 0 && precision != 0)
                {
                    throw new ArgumentException($"PriceCurveDefinition:'{priceCurveDefinitionId}' the precision '{precision}' is smaller than the length of the price step '{priceStep}'.", 
                        nameof(precision));
                }

                if (precision > 7)
                {
                    throw new ArgumentException($"PriceCurveDefinition:'{priceCurveDefinitionId}' has a precision of '{precision}' which is too big.", nameof(precision));
                }

                return priceStep / Math.Pow(10, precision);
            }
            catch (OverflowException e)
            {
                throw new OverflowException($"PriceCurveDefinition:'{priceCurveDefinitionId}' has a precision of '{precision}' which is too big.", e.InnerException);
            }
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(_tickSize)}: {_tickSize}, {nameof(Name)}: {Name}, {nameof(Description)}: {Description}, {nameof(MocRegions)}: {MocRegions}, {nameof(UnitOfMeasure)}: {
                UnitOfMeasure}, {nameof(LotSize)}: {LotSize}, {nameof(PriceStep)}: {PriceStep}, {nameof(Precision)}: {Precision}, {nameof(TickSize)}: {TickSize}, {nameof(Currency)}: {Currency}, {
                    nameof(CurveGroup)}: {CurveGroup}, {nameof(CurrencyDenominationFactor)}: {CurrencyDenominationFactor}, {nameof(Density)}: {Density}, {nameof(PricingTenorGroup)}: {PricingTenorGroup
                    }";
        }
    }
}
