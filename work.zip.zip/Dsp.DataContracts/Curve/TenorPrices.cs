﻿using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    public class TenorPrices<T> where T: ITenor
    {
        [JsonProperty]
        public IList<T> Tenors { get; init; }

        [JsonProperty]
        public IList<double?> BidPrices { get; init; }

        [JsonProperty]
        public IList<double?> MidPrices { get; init; }

        [JsonProperty]
        public IList<double?> AskPrices { get; init; }

        [JsonProperty]
        public IList<double?> PrevClosePrices { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public IList<MonthlyTenor?> EfpMonths { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public IList<double?> EfpValues { get; init; }

        public TenorPrices()
        {}

        public TenorPrices(IList<T> tenors,
            IList<double?> bidPrices,
            IList<double?> midPrices,
            IList<double?> askPrices,
            IList<double?> prevClosePrices,
            IList<MonthlyTenor?> efpMonths = null,
            IList<double?> efpValues = null)
        {
            Tenors = tenors;
            BidPrices = bidPrices;
            MidPrices = midPrices;
            AskPrices = askPrices;
            PrevClosePrices = prevClosePrices ?? [];
            EfpMonths = efpMonths;
            EfpValues = efpValues;
        }
        public TenorPrices(IList<T> tenors,
            IList<double> bidPrices,
            IList<double> midPrices,
            IList<double> askPrices,
            IList<double?> prevClosePrices,
            IList<MonthlyTenor?> efpMonths = null,
            IList<double?> efpValues = null)
        {
            Tenors = tenors;
            BidPrices = bidPrices?.Cast<double?>().ToList();
            MidPrices = midPrices?.Cast<double?>().ToList();
            AskPrices = askPrices?.Cast<double?>().ToList();
            PrevClosePrices = prevClosePrices ?? [];
            EfpMonths = efpMonths;
            EfpValues = efpValues;
        }
        public TenorPrices(IList<TenorPrice<T>> tenorPrices)
        {
            Tenors = tenorPrices.Select(x=>x.Tenor).ToList();
            BidPrices = tenorPrices.Select(x=>x.BidPrice).ToList();
            MidPrices = tenorPrices.Select(x=>x.MidPrice).ToList();
            AskPrices = tenorPrices.Select(x => x.AskPrice).ToList();
            PrevClosePrices = tenorPrices.Select(x => x.PrevClosePrice).ToList();

            if (tenorPrices.Select(x => x.EfpMonth).Any(x => x != null))
            {
                EfpMonths = tenorPrices.Select(x => x.EfpMonth).ToList();
            }

            if (tenorPrices.Select(x => x.EfpValue).Any(x => x != null))
            {
                EfpValues = tenorPrices.Select(x => x.EfpValue).ToList();
            }
        }

        public List<double?> ChangeOnDayPrices()
        {
            var prices = new List<double?>();

            for (var i = 0; i < MidPrices.Count; i++)
            {
                if (i < PrevClosePrices.Count && PrevClosePrices[i] != null && MidPrices[i] != null)
                {
                    prices.Add(MidPrices[i] - PrevClosePrices[i]);
                }
                else
                {
                    prices.Add(null);
                }
            }

            return prices;
        }
    }
}