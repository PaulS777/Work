﻿// /***********************************************************************************************************************
// PriceCurveBase.cs
// 
// (c) 2022 - Shell.  Created by Hughes, Tim DW SITI-PTIY/BBJ, 2022/07/19.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System;
using Dsp.DataContracts.DerivedCurves;
using Dsp.DataContracts.JsonConverters;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public class PriceCurveBase : IIdentifiable
    {
        [JsonProperty] public int Id { get; init; }

        [JsonProperty] public string ProductName { get; init; }

        [JsonProperty] public int PublisherId { get; init; }

        [JsonProperty] public string Publisher { get; init; }

        [JsonProperty, JsonConverter(typeof(DateTimeJsonConverter))]
        public DateTime Timestamp { get; init; }

        [JsonProperty] public bool Tradeable { get; init; }

        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        public ValidityIndicator Validity { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public TenorPrices<DailyTenor> DailyPrices { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public TenorPrices<WeeklyTenor> WeeklyPrices { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public TenorPrices<MonthlyTenor> MonthlyPrices { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public TenorPrices<QuarterlyTenor> QuarterlyPrices { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public TenorPrices<HalfYearTenor> HalfYearPrices { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public TenorPrices<AnnualTenor> AnnualPrices { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public PricingFailure PricingFailure { get; init; }

        protected PriceCurveBase()
        {
        }

        protected PriceCurveBase(
            int id,
            string productName,
            int publisherId,
            string publisher,
            DateTime timestamp,
            bool tradeable,
            ValidityIndicator validity,
            TenorPrices<DailyTenor> dailyPrices,
            TenorPrices<WeeklyTenor> weeklyPrices,
            TenorPrices<MonthlyTenor> monthlyPrices,
            TenorPrices<QuarterlyTenor> quarterlyPrices,
            TenorPrices<HalfYearTenor> halfYearPrices,
            TenorPrices<AnnualTenor> annualPrices,
            PricingFailure pricingFailure = null)
        {
            Id = id;
            ProductName = productName;
            PublisherId = publisherId;
            Publisher = publisher;
            Timestamp = timestamp;
            Tradeable = tradeable;
            Validity = validity;

            DailyPrices = dailyPrices;
            WeeklyPrices = weeklyPrices;
            MonthlyPrices = monthlyPrices;
            QuarterlyPrices = quarterlyPrices;
            HalfYearPrices = halfYearPrices;
            AnnualPrices = annualPrices;

            PricingFailure = pricingFailure;
        }

        protected PriceCurveBase(int id, string productName, int publisherId, string publisher, DateTime timestamp, bool tradeable, PricingFailure pricingFailure)
            : this(id, productName, publisherId, publisher, timestamp, tradeable, ValidityIndicator.Invalid, null, null, null, null, null, null, pricingFailure)
        {
        }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(ProductName)}: {ProductName}, {nameof(PublisherId)}: {PublisherId}, {nameof(Publisher)}: {Publisher}, {nameof(Timestamp)}: {Timestamp}, {
                nameof(Tradeable)
            }: {Tradeable}, {nameof(Validity)}: {Validity}, {nameof(DailyPrices)}: {DailyPrices?.Tenors.Count}, {nameof(WeeklyPrices)}: {WeeklyPrices?.Tenors.Count}, {
                    nameof(MonthlyPrices)
            }: {MonthlyPrices?.Tenors.Count}, {nameof(QuarterlyPrices)}: {QuarterlyPrices?.Tenors.Count}, {nameof(HalfYearPrices)}: {HalfYearPrices?.Tenors.Count}, {
                        nameof(AnnualPrices)
            }: {AnnualPrices?.Tenors.Count}, {nameof(PricingFailure)}: {PricingFailure?.Reason}";
        }
    }
}