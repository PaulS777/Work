﻿using System;
using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public sealed record PriceCurveSetting : DeletableEntity
    {
        private readonly int _priceCurveDefinitionId;

        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int PriceCurveDefinitionId
        {
            get => _priceCurveDefinitionId;
            init => _priceCurveDefinitionId = Id = value;
        }

        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int PublisherId { get; init; }

        [JsonProperty]
        [Required]
        public bool IsPublishable { get; init; }

        [JsonProperty]
        [Required]
        public bool IsTradeable { get; init; }

        [JsonProperty]
        [Required]
        public bool IsExcelSourced { get; init; }

        [JsonProperty]
        [Required]
        public bool UseInactivityTimeout { get; init; }

        /// <summary>
        /// Defines an optional parent curve - if set then publisher id is always inherited from the parent
        /// </summary>
        [JsonProperty]
        public int? ParentCurveDefinitionId { get; init; }

        public PriceCurveSetting() : base(int.MinValue, EntityStatus.Active)
        { }


        public PriceCurveSetting(
             int priceCurveDefinitionId,
             int publisherId,
             bool isPublishable,
             bool isTradeable,
             bool useInactivityTimeout,
             bool isExcelSourced,
             int? parentCurveDefinitionId,
             EntityStatus status = EntityStatus.Active) : base(priceCurveDefinitionId, status)
        {
            PriceCurveDefinitionId = priceCurveDefinitionId;
            PublisherId = publisherId;
            IsPublishable = isPublishable;
            IsTradeable = isTradeable;
            UseInactivityTimeout = useInactivityTimeout;
            IsExcelSourced = isExcelSourced;
            ParentCurveDefinitionId = parentCurveDefinitionId != priceCurveDefinitionId ? parentCurveDefinitionId
                : throw new ArgumentException("Parent cannot be self", nameof(parentCurveDefinitionId));
        }

        public override string ToString()
        {
            return
                $"{nameof(PriceCurveDefinitionId)}: {PriceCurveDefinitionId}, " +
                $"{nameof(PublisherId)}: {PublisherId}, " +
                $"{nameof(IsPublishable)}: {IsPublishable}, " +
                $"{nameof(IsTradeable)}: {IsTradeable}, " +
                $"{nameof(UseInactivityTimeout)}: {UseInactivityTimeout}, " +
                $"{nameof(IsExcelSourced)}: {IsExcelSourced}, " +
                $"{nameof(ParentCurveDefinitionId)}: {ParentCurveDefinitionId}";
        }

        /// <inheritdoc />
        public bool Equals(PriceCurveSetting other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }

            if (ReferenceEquals(this, other))
            {
                return true;
            }

            return PriceCurveDefinitionId == other.PriceCurveDefinitionId &&
                   PublisherId == other.PublisherId &&
                   IsPublishable == other.IsPublishable &&
                   IsTradeable == other.IsTradeable &&
                   IsExcelSourced == other.IsExcelSourced &&
                   UseInactivityTimeout == other.UseInactivityTimeout &&
                   ParentCurveDefinitionId == other.ParentCurveDefinitionId;
        }

        /// <inheritdoc />
        public override int GetHashCode()
        {
            return HashCode.Combine(PriceCurveDefinitionId, PublisherId, IsPublishable, IsTradeable, UseInactivityTimeout, IsExcelSourced, ParentCurveDefinitionId);
        }
    }
}