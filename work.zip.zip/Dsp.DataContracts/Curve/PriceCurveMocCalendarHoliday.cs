﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public class PriceCurveMocCalendarHoliday
    {
        [Required]
        public int MocCalendarId { get; }

        [Required]
        public DateTime Holiday { get; init; }

        public PriceCurveMocCalendarHoliday()
        {
        }

        public PriceCurveMocCalendarHoliday(int mocCalendarId, DateTime holiday)
        {
            MocCalendarId = mocCalendarId;
            Holiday = holiday;
        }

        public override string ToString()
        {
            return $"{nameof(MocCalendarId)}: {MocCalendarId}, {nameof(Holiday)}: {Holiday}";
        }
    }
}