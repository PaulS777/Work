﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record FxCurveSetting : DeletableEntity
    {
        private int _fxCurveDefinitionId;

        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int FxCurveDefinitionId
        {
            get => _fxCurveDefinitionId;
            init => _fxCurveDefinitionId = Id = value;
        }

        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int PublisherId { get; init; }

        [JsonProperty]
        [Required]
        [Range(1.0, 30.0)]
        public double SpreadMultiplier { get; init; }

        [JsonProperty]
        [Required]
        public bool IsPublishable { get; init; }

        [JsonProperty]
        [Required]
        public bool IsTradeable { get; init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public FxCurveSetting() : base(int.MinValue, EntityStatus.Active)
        { }

        public FxCurveSetting(
            int fxCurveDefinitionId,
            int publisherId,
            double spreadMultiplier,
            bool isPublishable,
            bool isTradeable,
            EntityStatus status = EntityStatus.Active) : base(fxCurveDefinitionId, status)
        {
            FxCurveDefinitionId = fxCurveDefinitionId;
            PublisherId = publisherId;
            SpreadMultiplier = spreadMultiplier;
            IsPublishable = isPublishable;
            IsTradeable = isTradeable;
        }

        public override string ToString()
        {
            return $"{{{nameof(FxCurveSetting)}: {nameof(FxCurveDefinitionId)}:{FxCurveDefinitionId}, {nameof(PublisherId)}:{PublisherId}, {nameof(SpreadMultiplier)}:{SpreadMultiplier}, {
                nameof(IsPublishable)
            }:{IsPublishable}, {nameof(IsTradeable)}:{IsTradeable}}}";
        }
    }
}