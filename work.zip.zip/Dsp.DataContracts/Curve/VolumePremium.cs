﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record VolumePremium
    {
        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int ThresholdInUoM { get; init; }

        [JsonProperty]
        [Required]
        public double BidMargin { get; init; }

        [JsonProperty]
        [Required]
        public double AskMargin { get; init; }

        public VolumePremium()
        {
        }

        public VolumePremium(int thresholdInUoM, double bidMargin, double askMargin)
        {
            ThresholdInUoM = thresholdInUoM;
            BidMargin = bidMargin;
            AskMargin = askMargin;
        }

        public override string ToString()
        {
            return $"Threshold In UOM:{ThresholdInUoM} BidMargin:{BidMargin} AskMargin:{AskMargin}";
        }
    }
}