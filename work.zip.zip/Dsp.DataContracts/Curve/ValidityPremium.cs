﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record ValidityPremium
    {
        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int ThresholdInSeconds { get; init; }
        [JsonProperty]
        [Required]
        public double BidMargin { get; init; }
        [JsonProperty]
        [Required]
        public double AskMargin { get; init; }
        public ValidityPremium()
        {
        }
        public ValidityPremium(int thresholdInSeconds, double bidMargin, double askMargin)
        {
            ThresholdInSeconds = thresholdInSeconds;
            BidMargin = bidMargin;
            AskMargin = askMargin;
        }
        public override string ToString()
        {
            return $"ThresholdInSeconds:{ThresholdInSeconds} BidMargin:{BidMargin} AskMargin:{AskMargin}";
        }
    }
}