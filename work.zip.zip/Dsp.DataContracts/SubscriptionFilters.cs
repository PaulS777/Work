﻿namespace Dsp.DataContracts;

public static class SubscriptionFilters
{
    public static bool All<T>(T _) where T : IIdentifiable
    {
        return true;
    }

    public static bool NotDeleted<T>(T item) where T : IIdentifiable
    {
        return (item as DeletableEntity)?.Status != EntityStatus.Deleted;
    }

    public static bool ActiveOnly<T>(T item) where T : DeletableEntity
    {
        return item.Status == EntityStatus.Active;
    }

    public static bool ShouldBeSubscribedTo<T>(T item) where T : DeletableEntity
    {
        return item.Status.ShouldBeSubscribedTo();
    }

    public static bool ShouldBeCalculated<T>(T item) where T : DeletableEntity
    {
        return item.Status.ShouldBeCalculated();
    }

}