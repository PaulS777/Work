﻿using System;

namespace Dsp.DataContracts
{
    public static class TenorConverter
    {
        public static ITenorConverter<T> GetInstance<T>() where T : ITenor
        {
            var type = typeof(T);
            if(type == typeof(MonthlyTenor))
            {
                return (ITenorConverter<T>)MonthlyTenor.ConverterInstance;
            }

            if(type == typeof(WeeklyTenor))
            {
                return (ITenorConverter<T>)WeeklyTenor.ConverterInstance;
            }

            if(type == typeof(QuarterlyTenor))
            {
                return (ITenorConverter<T>)QuarterlyTenor.ConverterInstance;
            }

            if(type == typeof(HalfYearTenor))
            {
                return (ITenorConverter<T>)HalfYearTenor.ConverterInstance;
            }

            if(type == typeof(AnnualTenor))
            {
                return (ITenorConverter<T>)AnnualTenor.ConverterInstance;
            }

            if (type == typeof(DailyTenor))
            {
                return (ITenorConverter<T>) DailyTenor.ConverterInstance;
            }

            throw new ArgumentException($"Unsupported tenor type {typeof(T)}");
        }

        public static ITenor CreateFromKey(string tenorKey)
        {
            var ukey = uint.Parse(tenorKey);
            var tenorType = (TenorType) (ukey / 100_000_000);
            var i = (int)(ukey % 100_000_000);

            switch (tenorType)
            {
                case TenorType.Day:
                    return new DailyTenor(i);
                case TenorType.Week:
                    return new WeeklyTenor(i);
                case TenorType.Month:
                    return new MonthlyTenor(i);
                case TenorType.Quarter:
                    return new QuarterlyTenor(i);
                case TenorType.HalfYear:
                    return new HalfYearTenor(i);
                case TenorType.Year:
                    return new AnnualTenor(i);
                default:
                    throw new ArgumentOutOfRangeException(nameof(tenorKey), tenorKey, null);
            }
        }
    }
}