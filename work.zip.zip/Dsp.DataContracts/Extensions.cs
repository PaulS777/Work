﻿namespace Dsp.DataContracts
{
    public static class Extensions
    {
        public static bool IsUnitOfWeight(this UnitOfMeasure unit)
        {
            return unit == UnitOfMeasure.MT;
        }
    }
}