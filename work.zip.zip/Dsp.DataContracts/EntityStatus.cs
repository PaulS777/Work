﻿namespace Dsp.DataContracts;

public enum EntityStatus
{
    Active = 0,
    Deleted = 1,
    PendingNew,
    PendingUpdate,
    PendingDelete
}

public static class EntityStatusExtensions
{
    public static bool IsPending(this EntityStatus status)
    {
        return status is EntityStatus.PendingDelete or EntityStatus.PendingNew or EntityStatus.PendingUpdate;
    }

    /// <summary>
    /// Entity Statuses that indicate that the entity should be subscribed to for any relevant external feeds.
    /// This is used for base/price curves and fx curves.
    /// </summary>
    /// <param name="status"></param>
    /// <returns></returns>
    public static bool ShouldBeSubscribedTo(this EntityStatus status)
    {
        return status is EntityStatus.Active or EntityStatus.PendingNew;
    }
    /// <summary>
    /// Entity Statuses that indicate that the entity should be used in calculation engines.
    /// This is used for base/price curves and fx curves.
    /// </summary>
    /// <param name="status"></param>
    /// <returns></returns>
    public static bool ShouldBeCalculated(this EntityStatus status)
    {
        return status is EntityStatus.Active or EntityStatus.PendingNew or EntityStatus.PendingUpdate;
    }
}