﻿namespace Dsp.DataContracts
{
    /// <summary>
    /// The result of an operation that updates the repository
    /// </summary>
    public class DataUpdateResult
    {
        public Status Status { get; }

        public string Message { get; }
       
        public DataUpdateResult(Status status, string message)
        {
            Status = status;
            Message = message;
        }

        public static DataUpdateResult Success()
        {
            return new DataUpdateResult(Status.Success, string.Empty);
        }
        public static DataUpdateResult Warning(string message)
        {
            return new DataUpdateResult(Status.Warning, message);
        }
        public static DataUpdateResult Error(string message)
        {
            return new DataUpdateResult(Status.Error, message);
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(Status)}: {Status}, {nameof(Message)}: {Message}";
        }
    }

    public enum Status
    {
        /// <summary>
        /// Operation succeeded
        /// </summary>
        Success = 0,
        /// <summary>
        /// Operation succeeded with warnings - see Message
        /// </summary>
        Warning,
        /// <summary>
        /// operation failed
        /// </summary>
        Error
    }
}
