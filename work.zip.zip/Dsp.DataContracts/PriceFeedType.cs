﻿namespace Dsp.DataContracts;

public enum FeedSource
{
    Elektron = 1,
    Aes = 2
}