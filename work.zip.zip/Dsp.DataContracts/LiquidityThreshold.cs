﻿using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public class LiquidityThreshold
    {
        public int FromMonthOffset { get; init; }

        public double SpreadThreshold { get; init; }

        public double SizeThresholdInLot { get; init; }

        public double TradedVolumeThresholdInLot { get; init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public LiquidityThreshold()
        {
        }

        [JsonConstructor]
        public LiquidityThreshold(int fromMonthOffset, double spreadThreshold, double sizeThresholdInLot, double tradedVolumeThresholdInLot)
        {
            FromMonthOffset = fromMonthOffset;
            SpreadThreshold = spreadThreshold;
            SizeThresholdInLot = sizeThresholdInLot;
            TradedVolumeThresholdInLot = tradedVolumeThresholdInLot;
        }
    }
}