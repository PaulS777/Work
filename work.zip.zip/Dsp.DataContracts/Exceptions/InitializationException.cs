﻿using System;

namespace Dsp.DataContracts.Exceptions;

/// <summary>
/// A class failed to initalise successfully
/// </summary>
public class InitializationException : Exception
{
    public InitializationException()
    { }

    public InitializationException(string message, Exception ex) : base(message, ex)
    { }

    public InitializationException(string message) : base(message)
    { }
 }