﻿using System;

namespace Dsp.DataContracts.Exceptions
{
    /// <summary>
    /// A logic error or incorrect usage of a function has been detected
    /// </summary>
    public class UsageLogicException : Exception
    {
        public UsageLogicException()
        {
            
        }
        public UsageLogicException(string message, Exception ex) : base(message, ex)
        {
        }

        public UsageLogicException(string message) : base(message)
        {
        }
    }
}