﻿using System;

namespace Dsp.DataContracts.Exceptions;

/// <summary>
/// A price formula execution
/// </summary>
public class FormulaExecutionException : Exception
{
    public FormulaExecutionException()
    {
    }
    public FormulaExecutionException(string message, Exception ex) : base(message, ex)
    {
    }

    public FormulaExecutionException(string message) : base(message)
    {
    }
}