﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public class SystemDate : IIdentifiable
    {
        public int Id { get; }

        public DateTime Today { get;}

        public List<BusinessDay> BusinessDays { get; init; }

        public SystemDate(List<BusinessDay> businessDays, DateTime today) 
        {
            Id = 1;
            Today = today;
            BusinessDays = businessDays;
        }

        public override string ToString()
        {
            return $"{nameof(Today)}: {Today}, {nameof(BusinessDays)}: [{string.Join(", ", BusinessDays)}]";
        }
    }
    public class BusinessDay
    {
        public int CalendarId { get; }

        [JsonProperty] public DateTime CurrentBusinessDay { get; }

        [JsonProperty] public DateTime NextBusinessDay { get; }

        [JsonProperty] public bool IsTodayBusinessDay { get; }

        public BusinessDay(int calendarId, DateTime currentBusinessDay, DateTime nextBusinessDay, bool isTodayBusinessDay)
        {
            CalendarId = calendarId;
            CurrentBusinessDay = currentBusinessDay;
            NextBusinessDay = nextBusinessDay;
            IsTodayBusinessDay = isTodayBusinessDay;
        }

        public override string ToString()
        {
            return $"{nameof(CalendarId)}: {CalendarId}, " +
                   $"{nameof(CurrentBusinessDay)}: {CurrentBusinessDay}, " +
                   $"{nameof(NextBusinessDay)}: {NextBusinessDay}, " +
                   $"{nameof(IsTodayBusinessDay)}: {IsTodayBusinessDay}";
        }
    }
}
