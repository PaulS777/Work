﻿namespace Dsp.DataContracts
{
    public enum ConnectionStatus
    {
        Connected,
        Disconnected,
        Closed
    }
}