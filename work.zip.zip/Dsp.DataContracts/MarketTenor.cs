using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts;

[JsonConverter(typeof(StringEnumConverter))]
public enum MarketTenor
{
    Spot = 1
}