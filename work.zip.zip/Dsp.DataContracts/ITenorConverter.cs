﻿using System;

namespace Dsp.DataContracts
{
    public interface ITenorConverter<T>
    {
        T FromInt(int token);
        int ToInt(T tenor);
        T FromDate(DateTime date);
        DateTime ToDate(T tenor);
    }
}