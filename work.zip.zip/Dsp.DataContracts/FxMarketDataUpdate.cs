﻿using System;

namespace Dsp.DataContracts
{
    public class FxMarketDataUpdate : IIdentifiable
    {
        public int Id { get; }

        public int FxCurveId { get; }

        public YearMonthDayOffset ContractDate { get; }

        public DateTime? ExpiryDate { get; set; }

        public double? Bid { get; set; }

        public double? Ask { get; set; }

        public FxMarketDataUpdate(int fxCurveId, YearMonthDayOffset contractDate, DateTime? expiryDate = null,
            double? bid = null, double? ask = null)
        {
            FxCurveId = fxCurveId;
            ContractDate = contractDate;
            ExpiryDate = expiryDate;
            Bid = bid;
            Ask = ask;
            Id = CalculateUniqueId(fxCurveId, contractDate);
        }

        public void Merge(FxMarketDataUpdate update)
        {
            if (update.ExpiryDate.HasValue)
            {
                ExpiryDate = update.ExpiryDate;
            }

            if (update.Bid.HasValue)
            {
                Bid = update.Bid;
            }

            if (update.Ask.HasValue)
            {
                Ask = update.Ask;
            }
        }


        // FxCurveId: bits 1-14 (14 bits)
        // DaysSinceBaseYear: bits 15-31 (18 bits)
        private static int CalculateUniqueId(int fxCurveId, YearMonthDayOffset contractDate)
        {
            const int daysInMonth = 31;
            const int daysInYear = daysInMonth * 12;
            const int baseYear = 2000;

            if (fxCurveId > 16383)
            {
                throw new OverflowException("The curve Id is limited to 16383 as there are only 14 bits available in this function.");
            }
                
            var daysSinceBaseYear = (contractDate.Year - baseYear) * daysInYear +
                                      contractDate.Month * daysInMonth +
                                      contractDate.Day;

            return fxCurveId | daysSinceBaseYear << 14;
        }

        public override string ToString()
        {
            return $"{nameof(FxCurveId)}: {FxCurveId}, {nameof(ContractDate)}: {ContractDate}, {nameof(ExpiryDate)}: {ExpiryDate}, {nameof(Bid)}: {Bid}, {nameof(Ask)}: {Ask}";
        }
    }
}