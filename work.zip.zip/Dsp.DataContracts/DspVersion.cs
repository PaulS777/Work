﻿namespace Dsp.DataContracts
{
    public static class DspVersion
    {
        public const string Release = "70";
        public const string Hotfix = "0";
        //Build and Branch values are tokens replaced by the build system. Do not change
        public const string Build = "0000";
        public const string Revision = "0";
        public const string Branch = "LOCAL";
        public const string Version = Release + "." + Hotfix + "." + Build + "." + Revision;
        public const string Label = Release + "." + Hotfix + "." + Branch;
    }
}
