﻿namespace Dsp.DataContracts
{
    public struct YearMonthDayOffset
    {
        public readonly int Year;

        public readonly int Month;

        public readonly int Day;

        public YearMonthDayOffset(int year, int month, int day)
        {
            Year = year;
            Month = month;
            Day = day;
        }

        public bool Equals(YearMonthDayOffset other)
        {
            return Year == other.Year && Month == other.Month && Day == other.Day;
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            return obj is YearMonthDayOffset month && Equals(month);
        }

        public override string ToString()
        {
            var years = Year == 0 ? string.Empty : $"{Year}Y";
            var months = Month == 0 ? string.Empty : $"{Month}M";
            var days = Day == 0 ? string.Empty : $"{Day}D";
            return $"{years} {months} {days}".Trim(' ');
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Year * 397) ^ Month ^ Day;
            }
        }

        public static bool operator ==(YearMonthDayOffset left, YearMonthDayOffset right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(YearMonthDayOffset left, YearMonthDayOffset right)
        {
            return !(left == right);
        }
    }
}