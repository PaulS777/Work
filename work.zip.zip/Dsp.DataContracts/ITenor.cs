﻿using System;

namespace Dsp.DataContracts
{
    public interface ITenor : IComparable<ITenor>
    {
        string Key { get; }

        int ConvertToInt();

        TenorType TenorType();

        DateTime StartDate();
        DateTime EndDate();

        bool Equals(object obj);
    }

}