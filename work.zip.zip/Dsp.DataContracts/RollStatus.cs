﻿namespace Dsp.DataContracts
{
    public enum RollStatus
    {
        Rolling = 1,
        Completed,
        Failed,
        AutoRollFailed,
        Reset,
        NotStarted
    }
}
