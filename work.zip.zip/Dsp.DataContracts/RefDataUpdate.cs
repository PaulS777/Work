﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Dsp.DataContracts;

public record RefDataUpdate(Type DataType)
{
    public static RefDataUpdate<T> Create<T>(IEnumerable<T> items)
    {
        return new RefDataUpdate<T>([.. items], []);
    }
    public static RefDataUpdate<T> Create<T>(IEnumerable<T> updates, IEnumerable<T> deletes)
    {
        return new RefDataUpdate<T>([.. updates], [.. deletes]);
    }
}
public record RefDataUpdate<T>(List<T> Updates, List<T> Deletes) : RefDataUpdate(typeof(T))
{
    public IEnumerable<T> Combined => Updates.Concat(Deletes);
}