﻿namespace Dsp.DataContracts
{
    public enum WebSocketClientType
    {
        Rtd,
        Wpf,
        Dashboard,
        Service,
        Excel
    }
}