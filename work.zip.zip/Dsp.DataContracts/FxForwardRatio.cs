﻿using System;

namespace Dsp.DataContracts
{
    public class FxForwardRatio
    {
        public DateTime Expiry { get; }

        public double Ratio { get; }

        public FxForwardRatio(DateTime expiry, double ratio)
        {
            Expiry = expiry;
            Ratio = ratio;
        }
    }
}
