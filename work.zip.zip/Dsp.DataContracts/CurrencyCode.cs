﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record CurrencyCode : DeletableEntity
    {
        [JsonProperty]
        [Required(AllowEmptyStrings =false)]
        [RegularExpression("^([A-Z]{3})$", ErrorMessage ="Currency Code should be a three-letter alphabetic code.")]
        public string Code { get; init; }

        public static int NoCurrency => 999;

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public CurrencyCode() : base(int.MinValue, EntityStatus.Active)
        { }

        public CurrencyCode(int id, string code, EntityStatus status = EntityStatus.Active) : base(id,status)
        {
            Code = code;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(Code)}: {Code}";
        }
    }
}
