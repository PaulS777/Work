﻿using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.JsonConverters
{
    public class DateJsonConverter : IsoDateTimeConverter
    {
        public DateJsonConverter()
        {
            DateTimeFormat = "yyyyMMdd";
        }
    }
}
