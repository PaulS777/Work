﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.Curve;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record AuthorisationCurveGroup
    {
        [JsonProperty]
        public int UserId { get; init; }

        [Required]
        [JsonProperty]
        public CurveGroup CurveGroup { get; init; }

        [JsonProperty]
        [Required]
        public bool CanRead { get; init; }

        [JsonProperty]
        [Required]
        public bool CanUpdate { get; init; }

        public AuthorisationCurveGroup()
        {
        }

        public AuthorisationCurveGroup(CurveGroup curveGroup, bool canRead, bool canUpdate)
        {
            CurveGroup = curveGroup;
            CanRead = canRead;
            CanUpdate = canUpdate;
        }

        public AuthorisationCurveGroup(int userId, CurveGroup curveGroup, bool canRead, bool canUpdate)
        {
            UserId = userId;
            CurveGroup = curveGroup;
            CanRead = canRead;
            CanUpdate = canUpdate;
        }

        public override string ToString()
        {
            return $"{{{nameof(CurveGroup)}:{CurveGroup}, {nameof(CanRead)}:{CanRead}, {nameof(CanUpdate)}:{CanUpdate}}}";
        }
    }
}