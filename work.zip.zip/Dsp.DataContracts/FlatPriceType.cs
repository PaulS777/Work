﻿namespace Dsp.DataContracts
{
    public enum FlatPriceType
    {
        Future = 1,
        Swap
    }
}