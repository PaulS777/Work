﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record AuthorisationFxCurve
    {
        [JsonProperty]
        [Required]
        public int FxCurveDefinitionId { get; init; }

        [JsonProperty]
        [Required]
        public bool CanRead { get; init; }

        [JsonProperty]
        [Required]
        public bool CanUpdate { get; init; }

        public AuthorisationFxCurve()
        {
        }

        public AuthorisationFxCurve(int fxCurveDefinitionId, bool canRead, bool canUpdate)
        {
            FxCurveDefinitionId = fxCurveDefinitionId;
            CanRead = canRead;
            CanUpdate = canUpdate;
        }

        public override string ToString()
        {
            return $"{{{nameof(FxCurveDefinitionId)}:{FxCurveDefinitionId}, {nameof(CanRead)}:{CanRead}, {nameof(CanUpdate)}:{CanUpdate}}}";
        }
    }
}