﻿namespace Dsp.DataContracts.Configuration
{
    public interface IWebApiConfiguration : IServiceConfiguration
    {
        int SecureApiPort { get; }
    }
}