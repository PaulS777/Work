﻿using System;
using System.ComponentModel;

namespace Dsp.DataContracts.Configuration
{
    public interface ICommonConfiguration
    {
        string EnvironmentName { get; set; }

        [DefaultValue(null)]
        string HelpDistribution { get; set; }

        [DefaultValue(null)]
        string HelpDistributionSlack { get; set; }

        [DefaultValue(null)]
        Uri DashboardInstallUrl { get; set; }

        [DefaultValue(null)]
        string DatabaseConnection { get; set; }

        IAdminWebApiConfiguration AdminWebApi { get; set; }
        
        [DefaultValue(null)]
        IServiceConfiguration DataManagementService { get; set; }

        [DefaultValue(null)]
        IPriceFeedServiceConfiguration PriceFeed { get; set; }

        [DefaultValue(null)]
        IServiceConfiguration PricingService { get; set; }

        [DefaultValue(null)]
        IServiceConfiguration FxService { get; set; }
        
        IServiceConfiguration CurvePublisherService { get; set; }

        [DefaultValue(null)]
        IChatScraperConfiguration ChatScraper { get; set; }

        [DefaultValue(null)]
        IChatScraperParserConfiguration ChatScraperParser { get; set; }
        
        [DefaultValue(null)]
        IShopfrontConfiguration ShopfrontService { get; set; }

        [DefaultValue(null)]
        IWebApiConfiguration WebApi { get; set; }

        [DefaultValue(null)]
        IServiceBusConfig ServiceBusApi { get; set; }

        [DefaultValue("")]
        string Options { get; set; }

        [DefaultValue("")]
        string LogLevel { get; set; }
    }
}