﻿using System;

namespace Dsp.DataContracts.Configuration
{
    public class ZmqPortConfiguration
    {
        public string Key { get; set; }
        public Uri Server { get; set; }
        public int Port { get; set; }
        public int ReqRepPort { get; set; }
    }
}