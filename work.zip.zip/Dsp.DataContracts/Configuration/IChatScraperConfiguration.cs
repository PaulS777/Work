﻿using System;

namespace Dsp.DataContracts.Configuration
{
    public interface IChatScraperConfiguration : IServiceConfiguration
    {
        Uri ChatServerUrl { get; set; }
        string ChatServerUserName { get; set; }
        string ChatServerPassword { get; set; }
        string ChatServerProxy { get; set; }
        string ChatTestMessageHook { get; set; }
    }

    public interface IChatScraperParserConfiguration : IServiceConfiguration
    {
        string RootPath { get; }
        string InterpreterPath { get; }
    }
}