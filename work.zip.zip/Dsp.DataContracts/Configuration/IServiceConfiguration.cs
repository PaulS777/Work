﻿using System;
using System.ComponentModel;

namespace Dsp.DataContracts.Configuration
{
    public interface IServiceConfiguration
    {
        [DefaultValue(false)]
        bool RedirectedToAnotherEnvironment { get; set; }

        Uri Uri { get; set; }
    }
}