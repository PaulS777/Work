﻿// ***********************************************************************************************************************
// SecureServiceConfiguration.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class WebApiConfiguration : ServiceConfiguration, IWebApiConfiguration
    {
        public WebApiConfiguration(EnvironmentVariableTarget target) : base(target, "WEB_API")
        { }

        public int SecureApiPort
        {
            get => GetEnvironmentVariableAsInt("SECURE_APIPORT");
        }
    }
}
