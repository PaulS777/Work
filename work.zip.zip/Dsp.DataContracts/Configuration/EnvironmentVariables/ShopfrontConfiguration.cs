﻿// ***********************************************************************************************************************
// ShopfrontConfiguration.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class ShopfrontConfiguration : ConfigurationBase, IShopfrontConfiguration
    {
        public ShopfrontConfiguration(EnvironmentVariableTarget target) : base(target,"SHOP_FRONT")
        {
        }
        public int PublishFrequencySeconds => GetEnvironmentVariableAsInt("PUBLISH_FREQUENCY_SECONDS");
        public int MaxPublishedMonths => GetEnvironmentVariableAsInt("MAX_PUBLISHED_MONTHS");

        public string ShopfrontDatabaseConnection => GetEnvironmentVariable("SERVICE_DATABASE_CONNECTION");
    }
}
