﻿// ***********************************************************************************************************************
// PriceFeedServiceConfiguration.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class PriceFeedServiceConfiguration : ServiceConfiguration, IPriceFeedServiceConfiguration
    {
        public PriceFeedServiceConfiguration(EnvironmentVariableTarget target) : base(target, "PRICE_FEED")
        {
            ElektronFeed = new ElektronConfiguration(target, "PRICE_FEED");
            AesFeed = new AesConfiguration(target, "PRICE_FEED");
        }

        public IElektronFeedConfiguration ElektronFeed { get; set; }

        public IAesFeedConfiguration AesFeed { get; set; }
        public class AesConfiguration : ConfigurationBase, IAesFeedConfiguration
        {
            protected internal AesConfiguration(EnvironmentVariableTarget target, string prefix) : base(target, $"{prefix}_AES")
            { }

            public string ConnectionString
            {
                get => GetEnvironmentVariable("CONNECTION_STRING");
                set => throw new NotSupportedException();
            }

            public string ApiKey
            {
                get => GetEnvironmentVariable("APIKEY");
                set => throw new NotSupportedException();
            }

            public string WebsocketAddress
            {
                get => GetEnvironmentVariable("WEBSOCKET_ADDRESS");
                set => throw new NotSupportedException();
            }
        }

        public class ElektronConfiguration : ConfigurationBase, IElektronFeedConfiguration
        {
            protected internal ElektronConfiguration(EnvironmentVariableTarget target, string prefix) : base(target, $"{prefix}_ELEKTRON")
            { }

            public bool UseRealTimeIdWatchList
            {
                get => GetEnvironmentVariableAsBool("USE_REAL_TIME_ID_WATCHLIST");
                set => throw new NotSupportedException();
            }

            public string FeedEndpoints
            {
                get => GetEnvironmentVariable("FEED_END_POINTS");
                set => throw new NotSupportedException();
            }

            public string UserName
            {
                get => GetEnvironmentVariable("USER_NAME");
                set => throw new NotSupportedException();
            }

            public string AppId
            {
                get => GetEnvironmentVariable("APPID");
                set => throw new NotSupportedException();
            }
            
            public Uri AuthenticationUrl
            {
                get => GetEnvironmentVariableAsUri("AUTHENTICATION_URL");
                set => throw new NotSupportedException();
            }

            public Uri ServiceDiscoveryUrl
            {
                get => GetEnvironmentVariableAsUri("SERVICE_DISCOVERY_URL");
                set => throw new NotSupportedException();
            }

            public string ClientId
            {
                get => GetEnvironmentVariable("CLIENT_ID");
                set => throw new NotSupportedException();
            }

            public string Secret
            {
                get => GetEnvironmentVariable("SECRET");
                set => throw new NotSupportedException();
            }

            public string Region
            {
                get => GetEnvironmentVariable("REGION");
                set => throw new NotSupportedException();
            }

            public string Scope
            {
                get => GetEnvironmentVariable("SCOPE");
                set => throw new NotSupportedException();
            }
        }
    }
}
