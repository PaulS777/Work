﻿using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]

    public record FxCurveDefinition : DeletableEntity
    {
        [JsonProperty]
        public string Name { get; init; }

        [JsonProperty]
        public string Description { get; init; }

        [JsonProperty]
        public int BaseCurrencyId { get; init; }

        [JsonProperty]
        public int QuoteCurrencyId { get; init; }

        [JsonProperty]
        public int? InvertFxCurveId { get; init; }

        [JsonProperty]
        public int PeriodCount { get; init; }

        [JsonProperty]
        public int PeriodCountInYears => PeriodCount - NoOfMarketTenorsInFirstYear;

        public static readonly int NoOfMarketTenorsInFirstYear = 17;

        [JsonProperty]
        public bool IsMarketDataFeed { get; init; }

        [JsonProperty]
        public string FeedProductCode { get; init; }

        public int? PendingCurveId { get; init; }

        [JsonProperty]
        public int? ActionedByUserId { get; init; }


        /// <summary>
        /// Required for Dapper
        /// </summary>
        public FxCurveDefinition() : base(int.MinValue, EntityStatus.Active)
        { }

        public FxCurveDefinition(int id, string name, string description, int baseCurrencyId, int quoteCurrencyId, int? invertFxCurveId, int periodCount, bool isMarketDataFeed, string feedProductCode,
            EntityStatus status, int? pendingCurveId = null,  int? actionedByUserId = null) : base(id, status)
        {
            Name = name;
            Description = description;
            BaseCurrencyId = baseCurrencyId;
            QuoteCurrencyId = quoteCurrencyId;
            InvertFxCurveId = invertFxCurveId;
            PeriodCount = periodCount;
            IsMarketDataFeed = isMarketDataFeed;
            FeedProductCode = feedProductCode;
            PendingCurveId = pendingCurveId;
            ActionedByUserId = actionedByUserId;
        }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Name)}: {Name}, {nameof(Description)}: {Description}," +
                   $" {nameof(BaseCurrencyId)}: {BaseCurrencyId}, {nameof(QuoteCurrencyId)}: {QuoteCurrencyId}," +
                   $" {nameof(InvertFxCurveId)}: {InvertFxCurveId}, {nameof(PeriodCount)}: {PeriodCount}, {nameof(PeriodCountInYears)}: {PeriodCountInYears}" +
                   $" {nameof(IsMarketDataFeed)}: {IsMarketDataFeed}, {nameof(FeedProductCode)}: {FeedProductCode}," +
                   $" {nameof(PendingCurveId)}: {PendingCurveId}, {nameof(Status)}: {Status}, {nameof(ActionedByUserId)}: {ActionedByUserId}";
        }
    }
}