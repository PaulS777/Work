﻿namespace Dsp.DataContracts
{
    public static class WebSocketHeaderType
    {
        public static readonly string Api = "API";
        public static readonly string Version = "VERSION";
    }
}