﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json;
using TenorTypeEnum = Dsp.DataContracts.TenorType;
// ReSharper disable UnusedParameter.Local

namespace Dsp.DataContracts
{
    public struct WeeklyTenor: IComparable<WeeklyTenor>, ITenor
    {
        public static readonly IComparer<WeeklyTenor> ComparerInstance = new WeeklyTenorComparer();
        public static readonly ITenorConverter<WeeklyTenor> ConverterInstance = new WeeklyTenorConverter();

        public int WeekNumber  { get; }
        public int Year  { get; }
        public DateTime Date  { get; }


        [JsonConstructor]
        public WeeklyTenor(DateTime date)
        {
            WeekNumber = GetIso8601WeekOfDate(date);
            Year = GetIso8601YearOfDate(date,WeekNumber);
            Date = Validate(Year, WeekNumber);
        }

        public WeeklyTenor(int value)
            :this(value / 10000 % 10000,value / 100 % 100)
        {}

        public WeeklyTenor(int year, int weekNumber)
        {
            Year = year;
            WeekNumber = weekNumber;
            Date = Validate(Year, WeekNumber);
        }

        public WeeklyTenor(string token)
        {
            if(token.Length < 6 || token.Length > 7)
            {
                throw new FormatException("Expected tenor string length 6-7");
            }

            var split = token.Split('W');
            if(split.Length != 2)
            {
                throw new FormatException("Expected tenor string format as '<year>W<weeknumber>'");
            }

            Year = int.Parse(split[0]);
            WeekNumber = int.Parse(split[1]);
            Date = Validate(Year, WeekNumber);
        }
        // This presumes that weeks start with Monday.
        // Week 1 is the 1st week of the year with a Thursday in it.
        public static int GetIso8601WeekOfDate(DateTime date)
        {
            // Seriously cheat.  If its Monday, Tuesday or Wednesday, then it'll 
            // be the same week# as whatever Thursday, Friday or Saturday are,
            // and we always get those right
            var day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(date);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                date = date.AddDays(3);
            }
            
            // Return the week of our adjusted day
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(date, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        } 
        public static int GetIso8601YearOfDate(DateTime date, int week)
        {
            var day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(date);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                date = date.AddDays(3);
            }
            if (week == 53 && date.Month == 1)
            {
                return date.Year - 1;
            }
            
            return date.Year;
        }

        public static DateTime GetFirstDateOfIso8601Week(int year, int weekOfYear)
        {
            var jan1 = new DateTime(year, 1, 1);
            var daysOffset = DayOfWeek.Thursday - jan1.DayOfWeek;

            // Use first Thursday in January to get first week of the year as
            // it will never be in Week 52/53
            var firstThursday = jan1.AddDays(daysOffset);
            var cal = CultureInfo.InvariantCulture.Calendar;
            var firstWeek = cal.GetWeekOfYear(firstThursday, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);

            var weekNum = weekOfYear;
            // As we're adding days to a date in Week 1,
            // we need to subtract 1 in order to get the right date for week #1
            if (firstWeek == 1)
            {
                weekNum -= 1;
            }

            // Using the first Thursday as starting week ensures that we are starting in the right year
            // then we add number of weeks multiplied with days
            var result = firstThursday.AddDays(weekNum * 7);

            // Subtract 3 days from Thursday to get Monday, which is the first weekday in ISO8601
            return result.AddDays(-3);
        }

        private static DateTime Validate(int year, int weekNumber)
        {
            if (weekNumber < 1 || weekNumber > 53)
            {
                throw new ArgumentException("Week number must be in the range 1 to 53.");
            }

            if (year < 2000 || year > 2100)
            {
                throw new ArgumentException("Year must be in the range 2000 to 2100.");
            }
            return GetFirstDateOfIso8601Week(year, weekNumber);
        }

        public bool Equals(WeeklyTenor other)
        {
            return Date == other.Date;
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            return obj is WeeklyTenor other && Equals(other);
        }

        public int CompareTo(ITenor other)
        {
            var typeComparison = TenorType().CompareTo(other.TenorType());
            return typeComparison != 0 ? typeComparison : CompareTo((WeeklyTenor)other);
        }

        public int CompareTo(WeeklyTenor other)
        {
            return Date.CompareTo(other.Date);
        }

        public static bool operator <(WeeklyTenor left, WeeklyTenor right)
        {
            return left.CompareTo(right) < 0;
        }

        public static bool operator >(WeeklyTenor left, WeeklyTenor right)
        {
            return left.CompareTo(right) > 0;
        }

        public static bool operator <=(WeeklyTenor left, WeeklyTenor right)
        {
            return left.CompareTo(right) <= 0;
        }

        public static bool operator >=(WeeklyTenor left, WeeklyTenor right)
        {
            return left.CompareTo(right) >= 0;
        }

        public static bool operator ==(WeeklyTenor left, WeeklyTenor right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(WeeklyTenor left, WeeklyTenor right)
        {
            return !left.Equals(right);
        }

        public string Key => $"{(int)TenorType()}{ConvertToInt()}";

        public int ConvertToInt()
        {
            return Year * 10000 + WeekNumber * 100;
        }

        public TenorTypeEnum TenorType()
        {
            return TenorTypeEnum.Week;
        }

        public DateTime StartDate()
        {
            return Date;
        }

        public DateTime EndDate()
        {
            return Date.AddDays(6);
        }
        public static WeeklyTenor ConvertFromInt(int value)
        {
            return new WeeklyTenor(value);
        }

        public override string ToString()
        {
            return $"{Year}W{WeekNumber}";
        }

        public override int GetHashCode()
        {
            return Date.GetHashCode();
        }

        private sealed class WeeklyTenorComparer : IComparer<WeeklyTenor>
        {
            public int Compare(WeeklyTenor x, WeeklyTenor y)
            {
                return x.CompareTo(y);
            }
        }

        private sealed class WeeklyTenorConverter: ITenorConverter<WeeklyTenor>
        {
            public WeeklyTenor FromInt(int token)
            {
                return new WeeklyTenor(token);
            }

            public int ToInt(WeeklyTenor tenor)
            {
                return tenor.ConvertToInt();
            }

            /// <inheritdoc />
            public WeeklyTenor FromDate(DateTime date)
            {
                return new WeeklyTenor(date);
            }

            /// <inheritdoc />
            public DateTime ToDate(WeeklyTenor tenor)
            {
                return tenor.StartDate();
            }
        }
    }
}