﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.DerivedCurves;
using Newtonsoft.Json;

namespace Dsp.DataContracts.AdminActions;

[JsonObject]
public class UpdateManualPrices : AdminAction
{
    public override string ActionName => GetType().Name;
    public override int Target => ManualCurveDefinitionId ?? -1;

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public int? ManualCurveDefinitionId { get; set; }

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public string CurveName { get; init; }

    [Required]
    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public List<GenericCurvePoint> Overrides { get; init; }

    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    public List<EfpNarrative<DailyTenor>> EfpNarratives { get; init; }

    public UpdateManualPrices(int? manualCurveDefinitionId, string curveName, List<GenericCurvePoint> overrides, List<EfpNarrative<DailyTenor>> efpNarratives = null)
    {
        if (manualCurveDefinitionId == null && string.IsNullOrWhiteSpace(curveName))
        {
            throw new ValidationException("Either ManualCurveDefinitionId or CurveName must be provided.");
        }

        ManualCurveDefinitionId = manualCurveDefinitionId;
        CurveName = curveName;
        Overrides = overrides;
        EfpNarratives = efpNarratives;
    }

    /// <inheritdoc />
    public override string ToString()
    {
        return $"{nameof(ManualCurveDefinitionId)}: {ManualCurveDefinitionId}, {nameof(CurveName)}: {CurveName}, {nameof(Overrides)}: {string.Join(", ",Overrides)}";
    }
}