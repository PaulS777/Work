﻿// /***********************************************************************************************************************
// SetCurvePublishingControls.cs
// 
// (c) 2023 - Shell.  Created by Hughes, Tim DW SITILTD-PTIY/TCD, 2023/07/10.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.AdminActions;

[JsonObject]
public class SetCurvePublishingControls : AdminAction
{
    public override string ActionName => GetType().Name;
    public override int Target => PriceCurveId;

    [JsonProperty]
    [Required]
    public ActionTargetType ActionTargetType { get; init; }

    [JsonProperty]
    [Required]
    public int PriceCurveId { get; init; }

    [JsonProperty]
    [Required]
    public bool IsPublishable { get; init; }

    [JsonProperty]
    [Required]
    public bool IsTradeable { get; init; }

    [JsonProperty]
    [Required]
    public bool IsExcelSourced { get; init; }

    /// <inheritdoc />
    public SetCurvePublishingControls(ActionTargetType actionTargetType, int priceCurveId, bool isPublishable, bool isTradeable, bool isExcelSourced)
    {
        ActionTargetType = actionTargetType;
        PriceCurveId = priceCurveId;
        IsPublishable = isPublishable;
        IsTradeable = isTradeable;
        IsExcelSourced = isExcelSourced;
    }

    /// <inheritdoc />
    public override string ToString()
    {
        return $"{nameof(ActionName)}: {ActionName}, {ActionTargetType} {nameof(PriceCurveId)}: " +
               $"{PriceCurveId}, {nameof(IsPublishable)}: {IsPublishable}, {nameof(IsTradeable)}: " +
               $"{IsTradeable}, {nameof(IsExcelSourced)}: {IsExcelSourced}";
    }
}