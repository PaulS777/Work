﻿
namespace Dsp.DataContracts.AdminActions;

public enum AdminCurveType
{
    Manual = 1,
    External = 2,
    Calculated = 3,
    Fx = 4

}
