﻿namespace Dsp.DataContracts.AdminActions;

public enum OperationType 
{
    Create,
    Update    

}