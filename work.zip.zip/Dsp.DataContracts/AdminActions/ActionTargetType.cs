﻿// /***********************************************************************************************************************
// PriceOrFx.cs
// 
// (c) 2023 - Shell.  Created by Hughes, Tim DW SITILTD-PTIY/TCD, 2023/07/19.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

namespace Dsp.DataContracts.AdminActions;

/// <summary>
/// Which entity is this action targeted at.  Generally used to distinguish between PriceCurve and FxCurve.
/// </summary>
public enum ActionTargetType {
    PriceCurve,
    FxCurve
}