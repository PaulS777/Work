﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace Dsp.DataContracts.AdminActions
{
    [JsonObject]
    public class CurveWorkflowAction : AdminAction
    {
        [JsonProperty]
        [Required]
        public override string ActionName => GetType().Name;

        public override int Target => CurveDefinitionId;
        [JsonProperty]
        [Required]
        public AdminCurveType AdminCurveType { get; init; }
        [JsonProperty]
        [Required]
        public WorkflowOperationType WorkflowOperationType { get; init; }

        [JsonProperty]
        [Required]
        public int CurveDefinitionId { get; init; }

        public CurveWorkflowAction(WorkflowOperationType workFlowOperationType, AdminCurveType adminCurveType, int curveDefinitionId)
        {
            WorkflowOperationType = workFlowOperationType;
            CurveDefinitionId = curveDefinitionId;
            AdminCurveType = adminCurveType;
        }
        public override string ToString()
        {
            return $"{nameof(WorkflowOperationType)}: {WorkflowOperationType.ToString()}, {nameof(CurveDefinitionId)}: {CurveDefinitionId}, {nameof(AdminCurveType)}: {AdminCurveType.ToString()}";

        }

    }
}
