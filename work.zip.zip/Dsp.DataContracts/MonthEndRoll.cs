﻿using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record MonthEndRoll : DeletableEntity
    {
        public bool IsOverride { get; init; }

        public bool IsReset { get; init; }

        public MonthEndRoll(int id, bool isOverride, bool isReset, EntityStatus status = EntityStatus.Active) : base(id, status)
        {
            IsOverride = isOverride;
            IsReset = isReset;
        }

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(IsOverride)}: {IsOverride}, {nameof(IsReset)}: {IsReset}";
        }
    }
}
