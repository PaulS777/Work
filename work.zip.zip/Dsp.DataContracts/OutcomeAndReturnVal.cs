﻿// /***********************************************************************************************************************
// SuccessAndReturnVal.cs
// 
// (c) 2022 - Shell.  Created by Hughes, Tim DW SITI-PTIY/BBJ, 2022/07/21.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:  returns a success indicator and message, plus a payload
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

namespace Dsp.DataContracts
{
    /// <summary>
    /// returns a success indicator and message, plus a payload
    /// </summary>
    /// <typeparam name="T">any class</typeparam>
    public struct OutcomeAndReturnVal<T> where T : class
    {
        public bool IsSuccess { get; }
        public string Reason { get; }
        public T ReturnValue { get; }

        /// <summary>
        /// Specify success indicator, message and object
        /// </summary>
        /// <param name="isSuccess"></param>
        /// <param name="reason"></param>
        /// <param name="returnValue"></param>
        public OutcomeAndReturnVal(bool isSuccess, string reason, T returnValue = null)
        {
            IsSuccess = isSuccess;
            Reason = reason;
            ReturnValue = returnValue;
        }

        /// <summary>
        /// Indicate success and return a payload
        /// </summary>
        /// <param name="returnVal"></param>
        /// <returns></returns>
        public static OutcomeAndReturnVal<T> Success(T returnVal)
        {
            return new OutcomeAndReturnVal<T>(true, null, returnVal);
        }

        /// <summary>
        /// Indicate failure and return a reason
        /// </summary>
        /// <param name="reason"></param>
        /// <returns></returns>
        public static OutcomeAndReturnVal<T> Fail(string reason)
        {
            return new OutcomeAndReturnVal<T>(false, reason);
        }
    }
}