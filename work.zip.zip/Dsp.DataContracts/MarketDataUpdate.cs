﻿using System;

namespace Dsp.DataContracts
{
    public class MarketDataUpdate : IIdentifiable
    {
        public int Id { get; }
        public int BaseCurveId { get; }
        public MarketDataUpdateType MarketDataUpdateType { get; }
        public DateTime ContractDate { get; }
        public DateTime? SpreadDate { get; }

        public DateTime? ExpiryDate { get; set; }

        public double? Close { get; set; }
        public double? Low { get; set; }
        public double? High { get; set; }
        public double? Last { get; set; }
        public double? Bid { get; set; }
        public double? Ask { get; set; }
        public double? BidSize { get; set; }
        public double? AskSize { get; set; }
        public double? Volume { get; set; }        

        public MarketDataUpdate(int baseCurveId, MarketDataUpdateType marketDataUpdateType, DateTime contractDate, DateTime? spreadDate = null, DateTime? expiryDate = null) 
            : this(baseCurveId, marketDataUpdateType, contractDate, spreadDate, expiryDate, null, null, null, null, null, null, null, null, null)
        { }

        public MarketDataUpdate(int baseCurveId, MarketDataUpdateType marketDataUpdateType, DateTime contractDate, DateTime? spreadDate, DateTime? expiryDate,
            double? close, double? low, double? high, double? last, double? bid, double? ask, double? bidSize, double? askSize, double? volume)
        {
            BaseCurveId = baseCurveId;
            MarketDataUpdateType = marketDataUpdateType;
            ContractDate = contractDate;
            SpreadDate = spreadDate;
            ExpiryDate = expiryDate;
            Close = close;
            Low = low;
            High = high;
            Last = last;
            Bid = bid;
            Ask = ask;
            BidSize = bidSize;
            AskSize = askSize;
            Volume = volume;
            Id = CalculateUniqueId(baseCurveId, marketDataUpdateType, contractDate, spreadDate);
        }

        public void Update(MarketDataUpdate newValues)
        {
            ExpiryDate = newValues.ExpiryDate;
            Close = newValues.Close;
            Low = newValues.Low;
            High = newValues.High;
            Last = newValues.Last;
            Bid = newValues.Bid;
            Ask = newValues.Ask;
            BidSize = newValues.BidSize;
            AskSize = newValues.AskSize;
            Volume = newValues.Volume;
        }


        // Curve Id: bits 1-8 (8 bits)
        // MarketDataUpdateType: bits 9-10 (2 bits)
        // MonthsSinceBaseYear: bits 11-22 (12 bits) (341 years)
        // SpreadDays: bits 23- 31 (9 bits) (512 day range)
        private static int CalculateUniqueId(int baseCurveId, MarketDataUpdateType marketDataUpdateType, DateTime contractDate, DateTime? spreadDate)
        {
            const int monthsInYear = 12;
            const int baseYear = 2000;

            var contractMonthsSinceBaseYear = (contractDate.Year - baseYear) * monthsInYear + contractDate.Month;
            var id = baseCurveId | ((int)marketDataUpdateType << 8) | (contractMonthsSinceBaseYear << 10);
            if (spreadDate.HasValue)
            {
                var spreadDays = (spreadDate.Value - contractDate).Days;
                 id |= spreadDays << 22;
            }

            return id;
        }

        public override string ToString()
        {
            return $@"{nameof(Id)}: {Id}, {nameof(BaseCurveId)}: {BaseCurveId}, {nameof(ContractDate)}: {ContractDate}, {nameof(SpreadDate)}: {SpreadDate}, {nameof(ExpiryDate)}: {ExpiryDate}, {
                nameof(Close)
            }: {Close}, {nameof(Low)}: {Low}, {nameof(High)}: {High}, {nameof(Last)}: {Last}, {nameof(Bid)}: {Bid}, {nameof(Ask)}: {Ask}, {nameof(BidSize)}: {BidSize}, {
                    nameof(AskSize)
            }: {AskSize}, {nameof(Volume)}: {Volume}";
        }
    }
}