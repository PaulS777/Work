﻿namespace Dsp.DataContracts
{
    public enum CurveBuilderType
    {
        FutureAndSpreadBuilder = 1,
        PassThroughBuilder
    }
}