﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public sealed class CurvePoint<T>: IComparable<CurvePoint<T>> where T : ITenor
    {
        public static readonly IComparer<CurvePoint<T>> Comparer = new CurvePointComparer();

        public static readonly IComparer<T> TenorComparer= DataContracts.TenorComparer.GetInstance<T>();

        [JsonProperty]
        [Required]
        public T Tenor { get; }

        [JsonProperty]
        [Required]
        public double? Value { get; }

        public CurvePoint(T tenor, double value)
        {
            Tenor = tenor;
            Value = value;
        }

        [JsonConstructor]
        public CurvePoint(T tenor, double? value)
        {
            Tenor = tenor;
            Value = value;
        }

        public int CompareTo(CurvePoint<T> other)
        {
            if (other is null)
            {
                return 1;
            }

            var tenorBalance = TenorComparer.Compare(Tenor, other.Tenor);
            if (tenorBalance != 0)
            {
                return tenorBalance;
            }

            return Value?.CompareTo(other.Value) ?? (other.Value.HasValue ? 1 : 0);
        }

        public override string ToString()
        {
            return $"{Tenor} {Value}";
        }

        private bool Equals(CurvePoint<T> other)
        {
            return TenorComparer.Compare(Tenor, other.Tenor) == 0 && Value.Equals(other.Value);
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (obj.GetType() != GetType())
            {
                return false;
            }

            return Equals((CurvePoint<T>) obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Tenor.GetHashCode() * 397) ^ Value.GetHashCode();
            }
        }

        public static bool operator ==(CurvePoint<T> left, CurvePoint<T> right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(CurvePoint<T> left, CurvePoint<T> right)
        {
            return !Equals(left, right);
        }

        private sealed class CurvePointComparer : IComparer<CurvePoint<T>>
        {
            public int Compare(CurvePoint<T> x, CurvePoint<T> y)
            {
                if (x == null)
                {
                    return -1;
                }

                return x.CompareTo(y);
            }
        }
    }
}