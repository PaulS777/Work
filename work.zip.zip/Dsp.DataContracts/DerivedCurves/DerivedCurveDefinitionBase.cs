﻿using System;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;

[assembly: InternalsVisibleTo("Dsp.Repository")]
namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public record DerivedCurveDefinitionBase<T> : IIdentifiable where T : ITenor
    {
        //negative order numbers to fix order in the derived types
        [JsonProperty(Required = Required.Always, Order = -100)]
        public int Id { get; internal set; }

        [JsonProperty(Order = -99)]
        public string Name { get; internal set; }

        [JsonProperty(Order = -98)]
        public string Description { get; internal set; }

        [JsonProperty(Order = -97)]
        public int PublisherId { get; internal set; }

        [JsonProperty(Order = -96)]
        public int PriceCurveDefinitionId { get; internal set; }

        protected DerivedCurveDefinitionBase(int id, string name, string description, int priceCurveDefinitionId, int publisherId)
        {
            Id = id;
            Name = name;
            Description = description;
            PriceCurveDefinitionId = priceCurveDefinitionId;
            PublisherId = publisherId;
            

            if(string.IsNullOrWhiteSpace(Name))
            {
                throw new ArgumentException(nameof(name));
            }
        }

        public override string ToString()
        {
            return $"{typeof(T)} {nameof(Id)}: {Id}, {nameof(Name)}: {Name}";
        }
    }
}