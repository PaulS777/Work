﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public sealed class EfpNarrative<T> where T : ITenor
    {
        [JsonProperty] [Required] public T Tenor { get; }

        [JsonProperty] public MonthlyTenor? EfpMonth { get; }

        [JsonProperty] public double? EfpValue { get; }

        public EfpNarrative(T tenor, MonthlyTenor? efpMonth, double? efpValue)
        {
            Tenor = tenor;
            EfpMonth = efpMonth;
            EfpValue = efpValue;
        }

        public override string ToString()
        {
            return $"{Tenor} {(EfpMonth.HasValue?EfpMonth:"null")}:{EfpValue:+#.##;-#.##;0;'null'}";
        }

    }
}