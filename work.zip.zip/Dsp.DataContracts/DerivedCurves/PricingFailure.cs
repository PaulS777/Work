﻿using System;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public sealed class PricingFailure : IEquatable<PricingFailure>
    {
        [JsonProperty]
        public int PriceCurveId { get; init; }
        [JsonProperty]
        public int DerivedCurveId { get; init; }

        [JsonProperty]
        public PricingFailureReason Reason { get; init; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public LinkedCurve? LinkedCurve { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Details { get; init; }

        public PricingFailure(int priceCurveId, int derivedCurveId, PricingFailureReason reason, LinkedCurve? linkedCurve, string details)
        {
            PriceCurveId = priceCurveId;
            DerivedCurveId = derivedCurveId;
            Reason = reason;
            LinkedCurve = linkedCurve;
            Details = details ?? string.Empty;
        }

        public bool Equals(PricingFailure other)
        {
            if (other is null)
            {
                return false;
            }

            if (ReferenceEquals(this, other))
            {
                return true;
            }

            return PriceCurveId == other.PriceCurveId
                   && DerivedCurveId == other.DerivedCurveId
                   && Reason == other.Reason
                   && LinkedCurve.Equals(other.LinkedCurve)
                   && string.Equals(Details, other.Details, StringComparison.OrdinalIgnoreCase);
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            return obj.GetType() == GetType() && Equals((PricingFailure) obj);
        }

        [SuppressMessage("ReSharper", "NonReadonlyMemberInGetHashCode")]
        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = PriceCurveId;
                hashCode = (hashCode * 397) ^ DerivedCurveId;
                hashCode = (hashCode * 397) ^ (int) Reason;
                hashCode = (hashCode * 397) ^ LinkedCurve.GetHashCode();
                hashCode = (hashCode * 397) ^ (Details != null ? Details.GetHashCode() : 0);
                return hashCode;
            }
        }

        public override string ToString()
        {
            var relatedCurveToString = LinkedCurve == null ? string.Empty : $" {nameof(LinkedCurve)}:{LinkedCurve},";
            return $"{{{nameof(PricingFailure)} {nameof(PriceCurveId)}:{PriceCurveId}, {nameof(DerivedCurveId)}:{DerivedCurveId}, {nameof(Reason)}:{Reason},{relatedCurveToString} {nameof(Details)}:{Details}}}";
        }
    }
}