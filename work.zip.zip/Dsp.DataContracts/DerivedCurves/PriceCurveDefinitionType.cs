﻿namespace Dsp.DataContracts.DerivedCurves
{
    public enum PriceCurveDefinitionType
    {
        PriceCurve = 1,
        DerivedCurve = 2
    }
}