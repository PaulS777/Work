﻿namespace Dsp.DataContracts.DerivedCurves
{
    public enum PricingFailureReason
    {
        Exception = 1,
        DependencyFailure,
        AnchorPointIndexExceedsSpreadCurveLength,
        AnchorPointTenorReferenceNotFound,
        DuplicateTenors,
        GapBetweenTenors,
        PartitionPriceCurveDefinitionMismatch,
        PartitionsResultInEmptyCurve,
        PartitionsResultInGapBetweenTenors,
        PartitionHasNoElements,
        CompoundCurveIsEmpty
    }
}