﻿using System;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public record DerivedCurveDefinition : DeletableEntity
    {
        private DerivedCurveDefinition<MonthlyTenor> _monthlyDefinition;
        private DerivedCurveDefinition<DailyTenor> _dailyDefinition;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
        public DerivedCurveDefinition<MonthlyTenor> MonthlyDefinition
        {
            get => _monthlyDefinition;
            init
            {
                _monthlyDefinition = value;
                if (value?.GetCurveDefinition() != null)
                {
                    PriceCurveDefinitionId = value.GetCurveDefinition().PriceCurveDefinitionId;
                    Id = value.GetCurveDefinition().Id;
                }
            }
        }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore)]
        public DerivedCurveDefinition<DailyTenor> DailyDefinition
        {
            get => _dailyDefinition;
            init
            {
                _dailyDefinition = value;
                if (value?.GetCurveDefinition() != null)
                {
                    PriceCurveDefinitionId = value.GetCurveDefinition().PriceCurveDefinitionId;
                    Id = value.GetCurveDefinition().Id;
                }
            }
        }

        [JsonProperty]
        public int PriceCurveDefinitionId { get; init; }

        [JsonIgnore]
        public bool IsManual => MonthlyDefinition?.ManualCurveDefinition != null || DailyDefinition?.ManualCurveDefinition != null;

        [JsonIgnore]
        public bool IsMonthly => MonthlyDefinition != null;
        [JsonIgnore]
        public bool IsDaily => DailyDefinition != null;

        public DerivedCurveDefinition() : base(int.MinValue, EntityStatus.Active)
        { }

        public DerivedCurveDefinition(DerivedCurveDefinition<MonthlyTenor> monthlyCurveDefinition, EntityStatus status = EntityStatus.Active)
            : base(monthlyCurveDefinition.GetCurveDefinition()?.Id ?? int.MinValue, status)
        {
            MonthlyDefinition = monthlyCurveDefinition;
            DailyDefinition = null;
        }

        public DerivedCurveDefinition(DerivedCurveDefinition<DailyTenor> dailyCurveDefinition, EntityStatus status = EntityStatus.Active)
            : base(dailyCurveDefinition.GetCurveDefinition()?.Id ?? int.MinValue, status)
        {
            MonthlyDefinition = null;
            DailyDefinition = dailyCurveDefinition;
        }

        public IDerivedCurveDefinitionProvider<T> GetDefinitionProvider<T>() where T : ITenor
        {
            if (typeof(T) == typeof(MonthlyTenor) && IsMonthly)
            {
                return (IDerivedCurveDefinitionProvider<T>)MonthlyDefinition;
            }

            if (typeof(T) == typeof(DailyTenor) && IsDaily)
            {
                return (IDerivedCurveDefinitionProvider<T>)DailyDefinition;
            }

            return null;
        }

        public override string ToString()
        {
            return MonthlyDefinition?.ToString() ?? DailyDefinition.ToString();
        }
    }

    public interface IDerivedCurveDefinitionProvider<T> where T : ITenor
    {
        DerivedCurveDefinitionBase<T> GetCurveDefinition();
    }

    [JsonObject]
    public record DerivedCurveDefinition<T> : IDerivedCurveDefinitionProvider<T> where T : ITenor
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public SpreadCurveDefinition<T> SpreadCurveDefinition { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]

        public ManualCurveDefinition<T> ManualCurveDefinition { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public PartitionedCurveDefinition<T> PartitionedCurveDefinition { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public FlatPriceCurveDefinition<T> FlatPriceCurveDefinition { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public CompoundCurveDefinition<T> CompoundCurveDefinition { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public CustomCurveDefinition<T> CustomCurveDefinition { get; init; }

        public DerivedCurveDefinition()
        {
        }

        public DerivedCurveDefinition(DerivedCurveDefinitionBase<T> derivedCurveDefinition)
        {
            switch (derivedCurveDefinition)
            {
                case ManualCurveDefinition<T> definition:
                    ManualCurveDefinition = definition;
                    break;
                case CompoundCurveDefinition<T> definition:
                    CompoundCurveDefinition = definition;
                    break;
                case FlatPriceCurveDefinition<T> definition:
                    FlatPriceCurveDefinition = definition;
                    break;
                case SpreadCurveDefinition<T> definition:
                    SpreadCurveDefinition = definition;
                    break;
                case PartitionedCurveDefinition<T> definition:
                    PartitionedCurveDefinition = definition;
                    break;
                case CustomCurveDefinition<T> definition:
                    CustomCurveDefinition = definition;
                    break;
                default:
                    throw new ArgumentException($"{derivedCurveDefinition.GetType().FullName} is not valid", nameof(derivedCurveDefinition));
            }
        }

        public DerivedCurveDefinitionBase<T> GetCurveDefinition()
        {
            return SpreadCurveDefinition ??
                   ManualCurveDefinition ??
                   PartitionedCurveDefinition ??
                   FlatPriceCurveDefinition ??
                   CustomCurveDefinition ??
                   (DerivedCurveDefinitionBase<T>)CompoundCurveDefinition;
        }

        public override string ToString()
        {
            return GetCurveDefinition().ToString();
        }
    }
}