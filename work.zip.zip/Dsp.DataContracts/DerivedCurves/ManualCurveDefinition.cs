﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.JsonConverters;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public record ManualCurveDefinition<T> : DerivedCurveDefinitionBase<T> where T : ITenor
    {

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public IReadOnlyList<CurvePoint<T>> Overrides { get; init; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public IReadOnlyList<EfpNarrative<T>> EfpNarratives { get; init; }

        [JsonProperty]
        public int? CalendarId { get; init; }

        [JsonProperty]
        public EomRollAction EomRollAction { get; init; }

        [JsonProperty]
        public int? EomRollAnchorReferenceCurve { get; init; }

        [JsonProperty, JsonConverter(typeof(DateTimeJsonConverter))]
        public DateTime Timestamp { get; init; }

        public ManualCurveDefinition(int id,
            string name,
            string description,
            int priceCurveDefinitionId,
            int publisherId,
            IReadOnlyList<CurvePoint<T>> overrides,
            IReadOnlyList<EfpNarrative<T>> efpNarratives,
            DateTime timestamp,
            EomRollAction eomRollAction,
            int? eomRollAnchorReferenceCurve = null,
            int? calendarId = null)
            : base(id, name, description, priceCurveDefinitionId, publisherId)
        {
            Overrides = overrides?.OrderBy(x => x, CurvePoint<T>.Comparer).ToList();
            EfpNarratives = efpNarratives?.Count > 0 && efpNarratives.Any(x => x != null) ? efpNarratives : null;
            Timestamp = timestamp;
            CalendarId = calendarId;
            EomRollAction = eomRollAction;
            EomRollAnchorReferenceCurve = eomRollAnchorReferenceCurve;
        }

        public override string ToString()
        {
            var overrideString = Overrides == null ? string.Empty : $", {nameof(Overrides)}: [{string.Join(", ", Overrides)}]";
            var efpString = EfpNarratives == null ? string.Empty : $", {nameof(EfpNarratives)}: [{string.Join(", ", EfpNarratives)}]";
            return $"{base.ToString()}{overrideString}{efpString} timestamp: {Timestamp:yyyy-MM-dd HH:mm:ss}";
        }
    }

    public enum EomRollAction
    {
        /// <summary>
        /// Maintains curve length by duplicating the last value
        /// </summary>
        ExtendCurve = 1,
        /// <summary>
        /// Moves anchor point to appropriate tenor, taking value from specified reference curve (or use existing value if null)
        /// </summary>
        ShiftAnchor = 2,
        /// <summary>
        /// Leaves curve unchanged unless this will result in a curve with no valid points, in which case last value is shifted to keep curve valid
        /// </summary>
        NoAction = 3,
        /// <summary>
        /// Allows curve to shrink, removing obsolete values until curve is just a single value - shifts single value as necessary to keep curve valid
        /// </summary>
        DontExtend = 4 
    }
}