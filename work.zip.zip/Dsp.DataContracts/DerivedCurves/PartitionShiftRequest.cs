﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public class PartitionShiftRequest
    {
        [JsonProperty]
        public List<int> PartitionedCurveDefinitionIds { get; }
        [JsonProperty]
        public int OneBasedPartitionId { get; }
        [JsonProperty]
        public int TenorAmountToShift { get; }

        public PartitionShiftRequest(IEnumerable<int> partitionedCurveDefinitionIds, int oneBasedPartitionId, int tenorAmountToShift)
        {
            PartitionedCurveDefinitionIds = partitionedCurveDefinitionIds.ToList();
            if(PartitionedCurveDefinitionIds.Count == 0)
            {
                throw new ArgumentException("At least one curve definition id expected", nameof(partitionedCurveDefinitionIds));
            }

            TenorAmountToShift = tenorAmountToShift;
            if(tenorAmountToShift == 0)
            {
                throw new ArgumentOutOfRangeException(nameof(tenorAmountToShift), "Expected non zero tenor amount to shift");
            }

            if(oneBasedPartitionId < 1)
            {
                throw new ArgumentOutOfRangeException(nameof(oneBasedPartitionId), "Partition id is one based index");
            }

            OneBasedPartitionId = oneBasedPartitionId;
        }

        public override string ToString()
        {
            return $@"PartitionShiftRequest {nameof(PartitionedCurveDefinitionIds)}: [{string.Join(", ",
                PartitionedCurveDefinitionIds)
            }], {nameof(OneBasedPartitionId)}: {OneBasedPartitionId}, {nameof(TenorAmountToShift)}: {TenorAmountToShift}";
        }
    }
}