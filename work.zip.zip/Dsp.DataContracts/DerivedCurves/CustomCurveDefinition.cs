﻿// ***********************************************************************************************************************
// CustomCurveDefinition.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// ----------------------------------------------------------------------------------------------------------------------------
// Purpose: This class is for Custom Curves. It will have all the necessary details for custom curves. CustomCurveCompilerType 
// denote type of Custom Curve and Parameter carries the necessary information for particular Custom curve in JSON format.
//
// Usage Notes:
//
// ****************************************************************************************************************************

namespace Dsp.DataContracts.DerivedCurves
{
    public record CustomCurveDefinition<T> : DerivedCurveDefinitionBase<T> where T : ITenor
    {
        public CustomCompilerType CustomCompilerType { get; init; }
        public string Parameter { get; init; }

        public CustomCurveDefinition(int id, string name, CustomCompilerType customCompilerType, string parameter, string description, int priceCurveDefinitionId, int publisherId
        )
            : base(id, name, description, priceCurveDefinitionId, publisherId)
        {
            CustomCompilerType = customCompilerType;
            Parameter = parameter;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(CustomCompilerType)}: {CustomCompilerType}, {nameof(Parameter)}: {Parameter}";
        }
    }
}
