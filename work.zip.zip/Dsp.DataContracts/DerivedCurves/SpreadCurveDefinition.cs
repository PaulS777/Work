﻿using Dsp.DataContracts.Exceptions;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public record SpreadCurveDefinition<T> : DerivedCurveDefinitionBase<T> where T : ITenor
    {
        [JsonProperty]
        public CurveContributionDefinition FlatPriceCurve { get; init; }

        public SpreadCurveDefinition(int id, string name, string description, int priceCurveDefinitionId, int publisherId, 
            CurveContributionDefinition flatPriceCurve)
            : base(id, name, description, priceCurveDefinitionId, publisherId)
        {
            if (id == flatPriceCurve?.LinkedCurve.Id)
            {
                throw new InitializationException($"Invalid Spread Curve Definition - Curve {id} is self-referential");
            }
            FlatPriceCurve = flatPriceCurve;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(FlatPriceCurve)}: {FlatPriceCurve}";
        }
    }
}