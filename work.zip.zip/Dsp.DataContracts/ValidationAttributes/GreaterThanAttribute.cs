﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Dsp.DataContracts.ValidationAttributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class GreaterThanAttribute : ValidationAttribute
    {
        private readonly double _greaterThan;

        public GreaterThanAttribute(int greaterThan)
        {
            _greaterThan = greaterThan;
        }

        public GreaterThanAttribute(double greaterThan)
        {
            _greaterThan = greaterThan;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            double number;
            try
            {
                number = Convert.ToDouble(value);
            }
            catch (InvalidCastException)
            {
                return new ValidationResult($"The {validationContext.DisplayName} field is invalid.");
            }

            return number > _greaterThan ? 
                ValidationResult.Success : 
                new ValidationResult($"The {validationContext.DisplayName} field should be greater than {_greaterThan}.");
        }
    }
}
