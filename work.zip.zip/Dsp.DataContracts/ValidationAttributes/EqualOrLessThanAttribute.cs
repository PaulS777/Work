﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Dsp.DataContracts.ValidationAttributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class EqualOrLessThanAttribute : ValidationAttribute
    {
        private readonly double _equalOrLessThan;

        public EqualOrLessThanAttribute(int equalOrLessThan)
        {
            _equalOrLessThan = equalOrLessThan;
        }

        public EqualOrLessThanAttribute(double equalOrlessThan)
        {
            _equalOrLessThan = equalOrlessThan;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            double number;
            try
            {
                number = Convert.ToDouble(value);
            }
            catch (InvalidCastException)
            {
                return new ValidationResult($"The {validationContext.DisplayName} field is invalid.");
            }

            return number <= _equalOrLessThan ?
                ValidationResult.Success :
                new ValidationResult($"The {validationContext.DisplayName} field should be equal or less than {_equalOrLessThan}.");
        }
    }
}

