﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.WebApi
{
    [JsonObject]
    public class OrderSubscription : IWebApiMessage
    {
        [JsonProperty("msg_type")]
        public string MsgType => "order_subscription";
    }
}
