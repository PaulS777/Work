﻿namespace Dsp.DataContracts.WebApi
{
    public interface IWebApiMessage
    {
        string MsgType { get; }
    }
}
