﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts
{
    public enum DspServiceName
    {
        [EnumMember(Value = "Admin Web API")]
        AdminWebApi = 1,
        [EnumMember(Value = "Chat Scraper")]
        ChatScraper,
        [EnumMember(Value = "Chat Scraper Message Parser")]
        ChatScraperParser,
        [EnumMember(Value = "Curve Publisher API")]
        CurvePublisherService,
        [EnumMember(Value = "Database Backup Service")]
        DatabaseBackupService,
        [EnumMember(Value = "Data Management Service")]
        DataManagementService,
        [EnumMember(Value = "Reuters Elektron Feed")]
        ElektronFeed,
        [EnumMember(Value = "FX Service")]
        FxService,
        [EnumMember(Value = "Pricing Service")]
        PricingService,
        [EnumMember(Value = "ServiceBus Publisher API")]
        ServiceBusPublisherApi,
        [EnumMember(Value = "Shopfront Service")]
        ShopfrontService,
        [EnumMember(Value = "Web API")]
        WebApi,
        [EnumMember(Value = "USE FOR UNIT TESTING ONLY")]
        Testing
    }

    public enum ServiceStatus
    {
        Ok = 1,  
        Initialising, 
        WarningFutureActionRequired,
        WarningServiceDegraded, 
        Error, 
        Unavailable 
    }

    /// <summary>
    /// The effective state of the subsystem
    /// </summary>
    public enum SubSystemStatus
    {
        Ok = 1,
        WarningFutureActionRequired,
        WarningServiceDegraded, 
        Unavailable
    }

    /// <summary>
    /// The DSP function that a particular service is part of.
    /// Essentially, this should be used to indicate which function will not work if this service is down.
    /// E.g. the PriceFeedToDsx will be down if any of these services are down: Data Management, Elektron Feed, Price Service, FX Service, WebApi
    /// </summary>
    public enum SubSystem
    {
        PriceFeedToDsx= 1,  // DataManagement, Elektron Feed, Price Service, FX Service, WebApi
        PriceFeedToOther,  // ServiceBusApi, Shopfront
        // ReSharper disable once InconsistentNaming
        GUI,  // Admin WebApi, Curve Publisher
        ChatScraper, // ChatScraper
        Other // Shopfront, RTD?, DB Backup
    }

    [JsonObject]
    public record ServiceStatusNotification : IIdentifiable
    {
        public int Id { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public DspServiceName ServiceName { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public SubSystem SubSystem { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public ServiceStatus ServiceStatus { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public SubSystemStatus SubSystemStatus { get; set; }

        public ReadOnlyCollection<string> StatusMessages { get; init; }

        public DateTime LastUpdate { get; set; }

        [JsonConstructor]
        public ServiceStatusNotification()
        { }

        public ServiceStatusNotification(DspServiceName serviceName,
            ServiceStatus serviceStatus,
            SubSystem subSystem,
            SubSystemStatus subSystemStatus,
            List<string> statusMessages,
            DateTime lastUpdate)
        {
            Id = (int)serviceName;
            ServiceName = serviceName;
            ServiceStatus = serviceStatus;
            SubSystem = subSystem;
            SubSystemStatus = subSystemStatus;
            StatusMessages = new(statusMessages ?? throw new ArgumentNullException(nameof(statusMessages)));
            LastUpdate = lastUpdate;
        }

        public override string ToString()
        {
            return $"{nameof(ServiceName)}: {ServiceName}, {nameof(ServiceStatus)}: {ServiceStatus}, {nameof(StatusMessages)}: {string.Join(", ", StatusMessages)}, {nameof(LastUpdate)}: {LastUpdate}";
        }
    }
}