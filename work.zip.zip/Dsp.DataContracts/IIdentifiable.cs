﻿namespace Dsp.DataContracts
{
    public interface IIdentifiable
    {
        int Id { get; }
    }
}