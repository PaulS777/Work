﻿// ***********************************************************************************************************************
// CalendarAdminModule.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.CalendarMaintenance.Controllers;
using Dsp.Gui.Admin.CalendarMaintenance.Rules;
using Dsp.Gui.Admin.CalendarMaintenance.Views;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Common.Extensions;
using Microsoft.Extensions.DependencyInjection;
using ServiceCollection.Extensions.Modules;

namespace Dsp.Gui.Admin.CalendarMaintenance
{
    [ExcludeFromCodeCoverage]
    public class CalendarAdminModule : Module
    {
        protected override void Load(IServiceCollection services)
        {
            services.AddSingleton<CalendarAdminView>();

            services.AddSingleton<ICalendarAdminViewModelController, CalendarAdminViewModelController>();
            services.AddSingleton<ICalendarViewModelBuilder, CalendarViewModelBuilder>();
            services.AddSingleton<ICalendarViewModelCollectionProvider, CalendarViewModelCollectionProvider>();
            services.AddSingleton<ICalendarBuilder, CalendarBuilder>();

            services.AddTransient<ICalendarDateRule, CalendarDateRule>();
            services.AddTransient<ICalendarDateItemValidationService, CalendarDateItemValidationService>();
            services.AddTransient<ICalendarDateDuplicateItemsService, CalendarDateDuplicateItemsService>();
            services.AddTransient<ICalendarDateItemCollectionService, CalendarDateItemCollectionService>();
            services.AddTransient<ICalendarViewModelController, CalendarViewModelController>();
            services.AddTransient<ICalendarDateItemViewModelController, CalendarDateItemViewModelController>();

            services.AddFactory<ICalendarViewModelController, CalendarViewModelController>();
            services.AddFactory<ICalendarDateItemViewModelController, CalendarDateItemViewModelController>();

            services.AddPropertyInjectedServices();
        }
    }
}
