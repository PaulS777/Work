﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Common.Extensions;
using Prism.Commands;

namespace Dsp.Gui.Admin.CalendarMaintenance.Controllers
{
    internal sealed class CalendarViewModelController : ICalendarViewModelController
    {
        private readonly ICalendarDateItemCollectionService _itemCollectionService;
        private readonly CompositeDisposable _disposables = new();
        private bool _disposed;

        public CalendarViewModelController(ICalendarDateItemCollectionService itemCollectionService)
        {
            ViewModel = new CalendarViewModel(this);

            _itemCollectionService = itemCollectionService;

            ViewModel.RefreshItemsCommand = new DelegateCommand(OnRefreshItemsCommand);
            ViewModel.AddItemCommand = new DelegateCommand<CalendarDateItemViewModel>(OnAddItemCommand);

            _itemCollectionService.CanExecuteUpdateCommand
                                  .Subscribe(value => ViewModel.CanExecuteUpdateCommand = value)
                                  .AddTo(_disposables);

            _itemCollectionService.CanExecuteUndoCommand
                                  .Subscribe(value => ViewModel.CanExecuteUndoCommand = value)
                                  .AddTo(_disposables);

            _itemCollectionService.ValidationErrors
                                  .Subscribe(values => ViewModel.ValidationErrors = values)
                                  .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~CalendarViewModelController()
        {
            Dispose(false);
        }

        public CalendarViewModel ViewModel { get; }

        private void OnRefreshItemsCommand()
        {
            _itemCollectionService.RefreshItems(ViewModel.CalendarDateItems);
        }

        private void OnAddItemCommand(CalendarDateItemViewModel item)
        {
            _itemCollectionService.AddNewItem(item, ViewModel.CalendarDateItems);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _itemCollectionService.Dispose();

                if (ViewModel.CalendarDateItems != null)
                {
                    foreach (var item in ViewModel.CalendarDateItems)
                    {
                        item.Dispose();
                    }
                }
            }

            _disposed = true;
        }
    }
}
