﻿using System;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;

namespace Dsp.Gui.Admin.CalendarMaintenance.Controllers
{
    public interface ICalendarDateItemViewModelController : IDisposable
    {
        CalendarDateItemViewModel ViewModel { get; }
    }
}
