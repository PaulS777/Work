﻿using System;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;

namespace Dsp.Gui.Admin.CalendarMaintenance.Controllers
{
    public interface ICalendarAdminViewModelController : IDisposable
    {
        CalendarAdminViewModel ViewModel { get; }
    }
}
