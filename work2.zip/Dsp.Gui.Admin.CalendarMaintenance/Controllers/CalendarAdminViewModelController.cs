﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.ServiceContracts;
using Microsoft.Extensions.DependencyInjection;
using Prism.Commands;

namespace Dsp.Gui.Admin.CalendarMaintenance.Controllers
{
    internal sealed class CalendarAdminViewModelController : ICalendarAdminViewModelController
    {
        private readonly ICurveControlService _curveControlService;
        private readonly CompositeDisposable _disposables = new();
        private readonly ICalendarViewModelCollectionProvider _calendarCollectionProvider;
        private readonly ICalendarAdminToolBarService _toolBarService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly ILogger _log;

        private CompositeDisposable _selectedCalendarDisposable;
        private int? _previousSelectedCalendarId;
        private bool _disposed;

        public CalendarAdminViewModelController(ICurveControlService curveControlService,
                                                ICalendarViewModelCollectionProvider calendarCollectionProvider,
                                                ICalendarAdminToolBarService toolBarService,
                                                ISchedulerProvider schedulerProvider,
                                                ILoggerFactory loggerFactory)
        {
            _curveControlService = curveControlService;
            _calendarCollectionProvider = calendarCollectionProvider;
            _toolBarService = toolBarService;
            _schedulerProvider = schedulerProvider;
            _log = loggerFactory.Create(GetType().Name);

            ViewModel.IsBusy = true;
            ViewModel.BusyText = "Loading Calendars...";

            ViewModel.AddHolidayCommand = new DelegateCommand(OnAddHolidayCommand);

            _toolBarService.Update
                           .Subscribe(_ => OnUpdateCommand())
                           .AddTo(_disposables);

            _toolBarService.Undo
                           .Subscribe(_ => OnUndoCalendarCommand())
                           .AddTo(_disposables);

            ViewModel.CalendarItems = new ObservableCollection<CalendarDateItemViewModel>();

            ViewModel.ObservePropertyChanged(vm => vm.SelectedCalendar)
                     .Subscribe(_ => OnSelectedCalendar())
                     .AddTo(_disposables);

            curveControlService.Calendars
                               .Where(calendars => calendars != null)
                               .ObserveOn(_schedulerProvider.Dispatcher)
                               .Subscribe(OnCalendars)
                               .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~CalendarAdminViewModelController()
        {
            Dispose(false);
        }

        public CalendarAdminViewModel ViewModel { get; } = new();

        [Inject]
        public IPopupNotificationService PopupNotificationService { get; set; }

        [Inject]
        public IErrorMessageDialogService ErrorMessageDialogService { get; set; }

        [Inject]
        public ICalendarViewModelBuilder CalendarViewModelBuilder { get; set; }

        [Inject]
        public ICalendarBuilder CalendarBuilder { get; set; }

        [Inject]
        public ICalendarAdminUpdateService CalendarAdminUpdateService { get; set; }

        private void OnSelectedCalendar()
        {
            _selectedCalendarDisposable?.Dispose();
            _selectedCalendarDisposable = new CompositeDisposable();

            if (ViewModel.SelectedCalendar == null)
            {
                ViewModel.CalendarItems = null;

                _toolBarService.SetCanUpdate(false);
                _toolBarService.SetCanUndo(false);
                _toolBarService.ClearValidation();

                return;
            }

            ViewModel.CalendarItems = ViewModel.SelectedCalendar.CalendarDateItems;

            ViewModel.SelectedCalendar
                     .ObservePropertyChanged(vm => vm.CanExecuteUpdateCommand)
                     .StartWith(ViewModel.SelectedCalendar)
                     .Subscribe(OnCanExecuteUpdateCommand)
                     .AddTo(_selectedCalendarDisposable);

            ViewModel.SelectedCalendar
                     .ObservePropertyChanged(vm => vm.CanExecuteUndoCommand)
                     .StartWith(ViewModel.SelectedCalendar)
                     .Subscribe(OnCanExecuteUndoCommand)
                     .AddTo(_selectedCalendarDisposable);

            ViewModel.SelectedCalendar
                     .ObservePropertyChanged(vm => vm.ValidationErrors)
                     .StartWith(ViewModel.SelectedCalendar)
                     .Subscribe(vm => OnValidationErrors(vm.ValidationErrors))
                     .AddTo(_selectedCalendarDisposable);
        }

        private void OnCanExecuteUpdateCommand(CalendarViewModel calendarViewModel)
        {
            _toolBarService.SetCanUpdate(calendarViewModel.CanExecuteUpdateCommand);
        }

        private void OnCanExecuteUndoCommand(CalendarViewModel calendarViewModel)
        {
            _toolBarService.SetCanUndo(calendarViewModel.CanExecuteUndoCommand);

            ViewModel.CanSelectCalendar = !calendarViewModel.CanExecuteUndoCommand;
        }

        private void OnAddHolidayCommand()
        {
            var row = CalendarViewModelBuilder.GetNewCalendarItem();

            ViewModel.SelectedCalendar?.AddItemCommand.Execute(row);

            ViewModel.SelectedItem = row;
        }

        private void OnUndoCalendarCommand()
        {
            _previousSelectedCalendarId = ViewModel.SelectedCalendar?.Id;

            var calendars = _curveControlService.GetCalendarsSnapshot().ToList();

            var calendarItems = _calendarCollectionProvider.GetCollectionReset(calendars,
                                                                               CalendarViewModelBuilder.CreateCalendar);

            UpdateCalendars(calendarItems);
        }

        private void OnCalendars(IList<DataContracts.Calendar> calendars)
        {
            var calendarItems
                = _calendarCollectionProvider.GetCollection(ViewModel.Calendars,
                                                            calendars,
                                                            (vm, calendar) => vm.Id == calendar.Id,
                                                            (vm, calendar) => CalendarViewModelBuilder.UpdateCalendar(vm, calendar),
                                                            calendar => CalendarViewModelBuilder.CreateCalendar(calendar));
            UpdateCalendars(calendarItems);

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;
        }

        private void UpdateCalendars(IEnumerable<CalendarViewModel> calendarViewModels)
        {
            ViewModel.Calendars = new ObservableCollection<CalendarViewModel>(calendarViewModels);

            if (ViewModel.Calendars.Count > 0)
            {
                ViewModel.SelectedCalendar = _previousSelectedCalendarId != null ? 
                    ViewModel.Calendars.FirstOrDefault(c => c.Id == _previousSelectedCalendarId) 
                    : ViewModel.Calendars[0];
            }

            foreach (var calendar in ViewModel.Calendars)
            {
                calendar.RefreshItemsCommand?.Execute();
            }
        }

        private void OnUpdateCommand()
        {
            ViewModel.IsBusy = true;
            ViewModel.BusyText = "Updating Calendars";

            _previousSelectedCalendarId = ViewModel.SelectedCalendar?.Id;

            var calendar = CalendarBuilder.GetCalendar(ViewModel.SelectedCalendar);

            var response = CalendarAdminUpdateService.Update(calendar, 
                                                             _schedulerProvider.Dispatcher);

            response.ObserveOn(_schedulerProvider.Dispatcher)
                    .Subscribe(_ => OnUpdateComplete(),
                               OnError)
                    .AddTo(_disposables);
        }

        private void OnUpdateComplete()
        {
            _log.Info("Calendar update completed !");

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;

            PopupNotificationService.SendPopupNotification("Calendars Updated");
        }

        private void OnValidationErrors(IList<string> validationErrors)
        {
            if (validationErrors == null || validationErrors.Count == 0)
            {
                _toolBarService.ClearValidation();
            }
            else
            {
                _toolBarService.SetValidationErrors(validationErrors);
            }
        }

        private void OnError(Exception ex)
        {
            ViewModel.IsBusy = false;
            ViewModel.BusyText = "";

            var messageArgs = new ErrorMessageDialogArgs("Calendar Update Failed",  ex.Message, true);
            
            ErrorMessageDialogService.ShowDialog(messageArgs);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
