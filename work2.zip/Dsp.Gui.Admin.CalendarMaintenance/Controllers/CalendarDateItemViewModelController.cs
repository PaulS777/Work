﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.Admin.CalendarMaintenance.Services;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Common.Extensions;
using Prism.Commands;

namespace Dsp.Gui.Admin.CalendarMaintenance.Controllers
{
    internal sealed class CalendarDateItemViewModelController : ICalendarDateItemViewModelController
    {
        private readonly ICalendarDateItemValidationService _validationService;
        private readonly CompositeDisposable _disposables = new();
        private CompositeDisposable _subscribedDisposable;
        private bool _disposed;

        public CalendarDateItemViewModelController(ICalendarDateItemValidationService validationService)
        {
            _validationService = validationService;

            ViewModel = new CalendarDateItemViewModel(this);

            ViewModel.DeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = true);
            ViewModel.UndoDeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = false);

            ViewModel.ObservePropertyChanged(vm => vm.SubscribeUpdates)
                     .Where(vm => vm.SubscribeUpdates)
                     .Subscribe(_ => SubscribeUpdates())
                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.SubscribeUpdates)
                     .Where(vm => !vm.SubscribeUpdates)
                     .Subscribe(_ => UnSubscribeUpdates())
                     .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~CalendarDateItemViewModelController()
        {
            Dispose(false);
        }

        public CalendarDateItemViewModel ViewModel { get; }

        private void SubscribeUpdates()
        {
            _subscribedDisposable = new CompositeDisposable();

            _validationService.Attach(ViewModel);

            ViewModel.ObservePropertyChanged(vm => vm.Date)
                     .Where(vm => !vm.NewRecord)
                     .Subscribe(_ => CalculateIsDirty())
                     .AddTo(_subscribedDisposable);

            CalculateIsDirty();
        }

        private void UnSubscribeUpdates()
        {
            _subscribedDisposable?.Dispose();
        }

        private void CalculateIsDirty()
        {
            if (ViewModel.NewRecord)
            {
                ViewModel.IsDirty = true;
                return;
            }

            if (ViewModel.Date != ViewModel.OriginalDate)
            {
                ViewModel.IsDirty = true;
                return;
            }

            ViewModel.IsDirty = false;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _subscribedDisposable?.Dispose();
                _validationService.Dispose();
            }

            _disposed = true;
        }
    }
}
