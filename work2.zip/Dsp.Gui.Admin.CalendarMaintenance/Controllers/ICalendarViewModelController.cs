﻿using System;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;

namespace Dsp.Gui.Admin.CalendarMaintenance.Controllers
{
    public interface ICalendarViewModelController : IDisposable
    {
        CalendarViewModel ViewModel { get; }
    }
}
