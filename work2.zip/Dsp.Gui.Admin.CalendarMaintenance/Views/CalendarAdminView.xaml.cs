﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.CalendarMaintenance.Controllers;

namespace Dsp.Gui.Admin.CalendarMaintenance.Views
{
    [ExcludeFromCodeCoverage]
    public partial class CalendarAdminView
    {
        public CalendarAdminView(ICalendarAdminViewModelController controller)
        {
            DataContext = controller.ViewModel;
            InitializeComponent();
        }
    }
}
