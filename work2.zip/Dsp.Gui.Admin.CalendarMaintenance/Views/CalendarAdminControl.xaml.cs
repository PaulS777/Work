﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.CalendarMaintenance.Views
{
    [ExcludeFromCodeCoverage]
    public partial class CalendarAdminControl
    {
        public CalendarAdminControl()
        {
            InitializeComponent();
        }
    }
}
