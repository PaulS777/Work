﻿using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    public interface ICalendarBuilder
    {
        DataContracts.Calendar GetCalendar(CalendarViewModel viewModel);
    }
}
