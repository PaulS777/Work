﻿using System;
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    internal sealed class CalendarDateDuplicateItemsService : DuplicateItemsService<CalendarDateItemViewModel, DateTime?>, 
                                                              ICalendarDateDuplicateItemsService
    {
        public CalendarDateDuplicateItemsService()
        : base(item => item.Date, 
               item => item.Date, 
               item => item.Date != null)
        {
        }

        [ExcludeFromCodeCoverage]
        ~CalendarDateDuplicateItemsService()
        {
            Dispose(false);
        }
    }
}
