﻿using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    public interface ICalendarViewModelBuilder
    {
        CalendarViewModel CreateCalendar(DataContracts.Calendar calendar);
        void UpdateCalendar(CalendarViewModel viewModel, DataContracts.Calendar calendar);
        CalendarDateItemViewModel GetNewCalendarItem();
    }
}
