﻿using Dsp.Gui.Admin.CalendarMaintenance.Rules;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    internal class CalendarDateItemValidationService : EditableItemValidationService<CalendarDateItemViewModel>
                                                       , ICalendarDateItemValidationService
    {
        public CalendarDateItemValidationService(ICalendarDateRule rule)
        :base(rule)
        {
        }

        public override string IsDuplicateText() => "Duplicate Date";
    }
}
