﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    [ExcludeFromCodeCoverage]
    internal class CalendarDateItemCollectionService : EditableItemCollectionService<CalendarDateItemViewModel>,
                                                       ICalendarDateItemCollectionService
    {
        public CalendarDateItemCollectionService(ICalendarDateDuplicateItemsService duplicateService)
        : base(duplicateService)
        {
        }

        ~CalendarDateItemCollectionService()
        {
            Dispose(false);
        }
    }
}
