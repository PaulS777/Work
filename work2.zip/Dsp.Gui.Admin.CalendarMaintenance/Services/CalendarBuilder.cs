﻿using System.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    internal class CalendarBuilder : ICalendarBuilder
    {
        public Calendar GetCalendar(CalendarViewModel viewModel)
        {
            var holidays = viewModel.CalendarDateItems
                                    .Where(item => !item.IsDeleted && item.Date != null)
                                    .Select(item => item.Date.Value)
                                    .ToList();

            return new Calendar(viewModel.GetCalendar().Id,
                                EntityStatus.Active,
                                viewModel.GetCalendar().Code,
                                viewModel.GetCalendar().Description,
                                viewModel.GetCalendar().CountyCode,
                                viewModel.GetCalendar().CountryCode,
                                viewModel.GetCalendar().HolidaysToAdd,
                                viewModel.GetCalendar().AutoPopulate,
                                holidays);
        }
    }
}
