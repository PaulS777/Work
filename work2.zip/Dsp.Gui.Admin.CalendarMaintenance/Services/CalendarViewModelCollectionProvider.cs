﻿using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    internal class CalendarViewModelCollectionProvider : EditableEntityCollectionProvider<CalendarViewModel, DataContracts.Calendar>
                                                         ,ICalendarViewModelCollectionProvider
    {
    }
}
