﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Admin.CalendarMaintenance.Controllers;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    internal class CalendarViewModelBuilder : ICalendarViewModelBuilder
    {
        private readonly ICurrentBusinessDateProvider _currentBusinessDateProvider;

        public CalendarViewModelBuilder(ICurrentBusinessDateProvider currentBusinessDateProvider)
        {
            _currentBusinessDateProvider = currentBusinessDateProvider;
        }

        [Inject]
        public IServiceFactory<ICalendarViewModelController> CalendarFactory { get; set; }

        [Inject]
        public IServiceFactory<ICalendarDateItemViewModelController> CalendarDateFactory { get; set; }

        public CalendarViewModel CreateCalendar(Calendar calendar)
        {
            var controller = CalendarFactory.Create();

            var viewModel = controller.ViewModel;

            UpdateCalendar(viewModel, calendar);

            return viewModel;
        }

        public void UpdateCalendar(CalendarViewModel viewModel, 
                                   Calendar calendar)
        {
            viewModel.Id = calendar.Id;
            viewModel.Description = calendar.Description;

            viewModel.SetCalendar(calendar);

            var calendarRows = calendar.Holidays
                                       .Where(dt => dt.Date >= _currentBusinessDateProvider.CurrentDate)
                                       .OrderBy(dt => dt)
                                       .Select(GetCalendarItem);

            viewModel.CalendarDateItems = new ObservableCollection<CalendarDateItemViewModel>(calendarRows);
        }

        public CalendarDateItemViewModel GetNewCalendarItem()
        {
            var controller = CalendarDateFactory.Create();

            controller.ViewModel.NewRecord = true;
            controller.ViewModel.SubscribeUpdates = true;

            return controller.ViewModel;
        }

        private CalendarDateItemViewModel GetCalendarItem(DateTime holiday)
        {
            var controller = CalendarDateFactory.Create();

            controller.ViewModel.Date = holiday;
            controller.ViewModel.OriginalDate = holiday;

            controller.ViewModel.SubscribeUpdates = true;

            return controller.ViewModel;
        }
    }
}
