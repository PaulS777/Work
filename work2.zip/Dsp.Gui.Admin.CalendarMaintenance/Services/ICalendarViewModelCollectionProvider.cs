﻿using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.CalendarMaintenance.Services
{
    public interface ICalendarViewModelCollectionProvider : IEditableEntityCollectionProvider<CalendarViewModel, DataContracts.Calendar>
    {
    }
}
