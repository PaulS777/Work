﻿using System;
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Commands;

namespace Dsp.Gui.Admin.CalendarMaintenance.ViewModels
{
    public sealed class CalendarDateItemViewModel : EditableItem
    {
        private readonly IDisposable _controller;

        private DateTime? _date;
        private bool _disposed;

        public CalendarDateItemViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        [ExcludeFromCodeCoverage]
        ~CalendarDateItemViewModel()
        {
            Dispose(false);
        }

        public DelegateCommand DeleteCommand { get; set; }
        public DelegateCommand UndoDeleteCommand { get; set; }

        public DateTime? Date
        {
            get => _date;
            set
            {
                _date = value;
                RaisePropertyChanged();
            }
        }

        public DateTime? OriginalDate { get; set; }

        protected override void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller?.Dispose();
            }

            _disposed = true;
        }
    }
}
