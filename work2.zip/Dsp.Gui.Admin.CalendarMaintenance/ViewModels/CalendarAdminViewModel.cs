﻿using System.Collections.ObjectModel;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.Admin.CalendarMaintenance.ViewModels
{
    public class CalendarAdminViewModel : BindableBase, IEditableItemCollectionDialog
    {
        private ObservableCollection<CalendarViewModel> _calendars;
        private CalendarViewModel _selectedCalendar;
        private bool _canSelectCalendar;

        private ObservableCollection<CalendarDateItemViewModel> _calendarItems;
        private IEditableItem _selectedItem;
        private bool _isBusy;
        private string _busyText;

        public ObservableCollection<CalendarViewModel> Calendars
        {
            get => _calendars;
            set
            {
                _calendars = value;
                RaisePropertyChanged();
            }
        }

        public CalendarViewModel SelectedCalendar
        {
            get => _selectedCalendar;
            set
            {
                _selectedCalendar = value;
                RaisePropertyChanged();
            }
        }

        public bool CanSelectCalendar
        {
            get => _canSelectCalendar;
            set
            {
                _canSelectCalendar = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<CalendarDateItemViewModel> CalendarItems
        {
            get => _calendarItems;
            set
            {
                _calendarItems = value;
                RaisePropertyChanged();
            }
        }

        public IEditableItem SelectedItem
        {
            get => _selectedItem;
            set
            {
                _selectedItem = value;
                RaisePropertyChanged();
            }
        }

        public DelegateCommand AddHolidayCommand { get; set; }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        public string BusyText
        {
            get => _busyText;
            set
            {
                _busyText = value;
                RaisePropertyChanged();
            }
        }
    }
}
