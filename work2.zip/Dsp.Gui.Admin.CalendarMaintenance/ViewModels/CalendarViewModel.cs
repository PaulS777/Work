﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.Admin.CalendarMaintenance.ViewModels
{
    public sealed class CalendarViewModel : BindableBase, IEditableEntity, IDisposable
    {
        private readonly IDisposable _controller;
        private int _id;
        private string _description;
        private ObservableCollection<CalendarDateItemViewModel> _calendarDateItems;
        private DataContracts.Calendar _calendar;
        private bool _canExecuteUpdateCommand;
        private bool _canExecuteUndoCommand;
        private IList<string> _validationErrors; 
        private bool _disposed;

        public CalendarViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        [ExcludeFromCodeCoverage]
        ~CalendarViewModel()
        {
            Dispose(false);
        }

        public void SetCalendar(DataContracts.Calendar value) => _calendar = value;
        public DataContracts.Calendar GetCalendar() => _calendar;

        public DelegateCommand RefreshItemsCommand { get; set; }
        public DelegateCommand<CalendarDateItemViewModel> AddItemCommand { get; set; }

        public int Id
        {
            get => _id;
            set
            {
                _id = value;
                RaisePropertyChanged();
            }
        }

        public bool NewRecord { get; set; }

        public string Description
        {
            get => _description;
            set
            {
                _description = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<CalendarDateItemViewModel> CalendarDateItems
        {
            get => _calendarDateItems;
            set
            {
                _calendarDateItems = value;
                RaisePropertyChanged();
            }
        }

        public bool CanExecuteUpdateCommand
        {
            get => _canExecuteUpdateCommand;
            set
            {
                _canExecuteUpdateCommand = value;
                RaisePropertyChanged();
            }
        }

        public bool CanExecuteUndoCommand
        {
            get => _canExecuteUndoCommand;
            set
            {
                _canExecuteUndoCommand = value;
                RaisePropertyChanged();
            }
        }

        public IList<string> ValidationErrors
        {
            get => _validationErrors;
            set
            {
                _validationErrors = value;
                RaisePropertyChanged();
            }
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller?.Dispose();
            }

            _disposed = true;
        }
    }
}
