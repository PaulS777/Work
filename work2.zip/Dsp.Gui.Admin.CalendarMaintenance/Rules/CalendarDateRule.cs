﻿using System;
using Dsp.Gui.Admin.CalendarMaintenance.ViewModels;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.Admin.CalendarMaintenance.Rules
{
    public class CalendarDateRule : ICalendarDateRule
    {
        private readonly ICurrentBusinessDateProvider _currentBusinessDateProvider;

        public CalendarDateRule(ICurrentBusinessDateProvider currentBusinessDateProvider)
        {
            _currentBusinessDateProvider = currentBusinessDateProvider;
        }

        public IObservable<CalendarDateItemViewModel> ObservePropertyChanged(CalendarDateItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => vm.Date);
        }

        public string Validate(CalendarDateItemViewModel viewModel)
        {
            if (viewModel.Date == null)
            {
                return "Missing Date";
            }

            return viewModel.Date < _currentBusinessDateProvider.CurrentDate ? "Date Cannot be Past" : string.Empty;
        }
    }
}
