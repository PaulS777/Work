﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.UserMaintenance.Controllers;

namespace Dsp.Gui.Admin.UserMaintenance.Views
{
    /// <summary>
    /// Interaction logic for UserAdminView.xaml
    /// </summary>
    [ExcludeFromCodeCoverage]
    public partial class UserAdminView
    {
        public UserAdminView(IUserAdminController controller)
        {
            DataContext = controller.ViewModel;
            InitializeComponent();
        }
    }
}
