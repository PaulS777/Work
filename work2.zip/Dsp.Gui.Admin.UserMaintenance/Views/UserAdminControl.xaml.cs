﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.UserMaintenance.Views
{
    [ExcludeFromCodeCoverage]
    public partial class UserAdminControl
    {
        public UserAdminControl()
        {
            InitializeComponent();
        }
    }
}
