﻿using System.Diagnostics;
using System.Linq;
using Dsp.DataContracts;

namespace Dsp.Gui.Admin.UserMaintenance.Extensions
{
    public static class UserExtensions
    {
        public static bool HasPermission(this User user, PermissionCategory permissionCategory)
        {
            Debug.Assert(user != null, nameof(user) + " != null");

            return user.AuthorisationUserPermissions.Any(a => a.CategoryName == permissionCategory.ToString() && a.Value);
        }
    }
}
