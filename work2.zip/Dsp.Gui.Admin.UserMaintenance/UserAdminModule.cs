﻿// ***********************************************************************************************************************
// UserAdminModule.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.UserMaintenance.Controllers;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.Views;
using Microsoft.Extensions.DependencyInjection;
using ServiceCollection.Extensions.Modules;

namespace Dsp.Gui.Admin.UserMaintenance
{
    [ExcludeFromCodeCoverage]
#pragma warning disable S1200
    public class UserAdminModule : Module
#pragma warning restore S1200
    {
        protected override void Load(IServiceCollection services)
        {
            base.Load(services);

            services.AddSingleton<UserAdminView>();
  
            services.AddTransient<ICurveGroupItemsDataSource, CurveGroupItemsDataSource>();
            services.AddTransient<ICurveRegionItemsDataSource, CurveRegionItemsDataSource>();
            services.AddTransient<IFxCurveItemsDataSource, FxCurveItemsDataSource>();
            services.AddTransient<IUserAdminDataSourceProvider, UserAdminDataSourceProvider>();

            services.AddSingleton<IUserAdminUpdateService, UserAdminUpdateService>();
            services.AddSingleton<IUserDetailsChangedService, UserDetailsChangedService>();
            services.AddSingleton<IUserPermissionsChangedService, UserPermissionsChangedService>();
            services.AddSingleton<ICurveGroupsChangedService, CurveGroupsChangedService>();
            services.AddSingleton<ICurveRegionsChangedService, CurveRegionsChangedService>();
            services.AddSingleton<IFxCurvesChangedService, FxCurvesChangedService>();
            services.AddSingleton<IUserAdminChangedService, UserAdminChangedService>();
            services.AddSingleton<ICopyFromUserService, CopyFromUserService>();
            services.AddSingleton<IClearUserPermissionsService, ClearUserPermissionsService>();
            services.AddSingleton<IUserNameValidationService, UserNameValidationService>();
            services.AddSingleton<IDisplayNameValidationService, DisplayNameValidationService>();
            services.AddSingleton<IDisplayNameParser, DisplayNameParser>();
            services.AddSingleton<IUserAdminBuilder, UserAdminBuilder>();
            services.AddSingleton<IUserAdminController, UserAdminController>();
        }
    }
}
