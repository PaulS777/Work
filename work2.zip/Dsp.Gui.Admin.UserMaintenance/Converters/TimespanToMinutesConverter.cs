﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows.Data;

namespace Dsp.Gui.Admin.UserMaintenance.Converters
{
    [ExcludeFromCodeCoverage]
    public class TimespanToMinutesConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is not int minutes ? Binding.DoNothing : TimeSpan.FromMinutes(minutes);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is not TimeSpan timespan)
            {
                return Binding.DoNothing;
            }

            return (int)timespan.TotalMinutes;
        }
    }
}
