﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using DynamicData;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal sealed class CurveGroupsChangedService : ICurveGroupsChangedService
    {
        public IObservable<bool> ObserveChanges(ICurveGroupItemsDataSource curveGroups)
        {
            var items = curveGroups.Connect();

            return items.AutoRefresh(i => i.CanRead)
                        .AutoRefresh(i => i.CanUpdate)
                        .ToCollection()
                        .Select(CalculateCurveGroupItemsChanged);
        }

        private static bool CalculateCurveGroupItemsChanged(IEnumerable<CurveGroupItem> items)
        {
            return items.Any(CurveGroupItemChanged);
        }

        private static bool CurveGroupItemChanged(CurveGroupItem item)
        {
            if (item.AuthorisationCurveGroup != null)
            {
                return item.CanRead != item.AuthorisationCurveGroup.CanRead
                    || item.CanUpdate != item.AuthorisationCurveGroup.CanUpdate;
            }

            return item.CanRead || item.CanUpdate;
        }
    }
}
