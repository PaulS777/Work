﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    public interface IUserAdminBuilder
    {
        User GetUser(UserDetailsViewModel userDetails, 
                     UserPermissionsViewModel userPermissions,
                     IEnumerable<CurveGroupItem> curveGroupItems,
                     IEnumerable<CurveRegionItem> curveRegionItems,
                     IEnumerable<FxCurveItem> fxCurveItems,
                     int userId);
    }
}
