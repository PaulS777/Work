﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface ICopyFromUserService
    {
        void CopyUserDetailsAndItems(User user, 
                                     UserPermissionsViewModel userPermissions, 
                                     IEnumerable<CurveGroupItem> curveGroupItems, 
                                     IEnumerable<CurveRegionItem> curveRegionItems, 
                                     IEnumerable<FxCurveItem> fxCurveItems);
    }
}
