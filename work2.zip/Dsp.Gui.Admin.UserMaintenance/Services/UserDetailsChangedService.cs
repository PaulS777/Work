﻿using System;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class UserDetailsChangedService : IUserDetailsChangedService
    {
        public IObservable<bool> ObserveChanges(UserAdminViewModel viewModel)
        {
            var userName = viewModel.UserDetails
                                    .ObservePropertiesChanged(vm => vm.UserName, vm => vm.DisplayName);

            return userName.Where(_ => viewModel.SelectedUser != null)
                           .Select(userDetails => CalculateUserDetailsChanged(userDetails, 
                                                                              viewModel.SelectedUser));
        }

        private static bool CalculateUserDetailsChanged(UserDetailsViewModel userDetails, User user)
        {
            return !string.Equals(userDetails.UserName, user.UserName, StringComparison.InvariantCulture)
                || !string.Equals(userDetails.DisplayName, user.DisplayName, StringComparison.InvariantCulture);
        }
    }
}
