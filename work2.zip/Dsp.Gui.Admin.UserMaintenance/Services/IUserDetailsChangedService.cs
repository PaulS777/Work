﻿using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using System;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface IUserDetailsChangedService
    {
        IObservable<bool> ObserveChanges(UserAdminViewModel viewModel);
    }
}
