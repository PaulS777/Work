﻿using Dsp.Gui.Admin.UserMaintenance.DataSource;
using System;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface ICurveRegionsChangedService
    {
        IObservable<bool> ObserveChanges(ICurveRegionItemsDataSource curveRegions);
    }
}
