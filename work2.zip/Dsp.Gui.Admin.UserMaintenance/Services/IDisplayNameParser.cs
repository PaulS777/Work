﻿namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface IDisplayNameParser
    {
        string ParseFromUserName(string userName);
    }
}
