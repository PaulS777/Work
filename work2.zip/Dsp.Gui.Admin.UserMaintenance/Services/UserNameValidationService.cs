﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal static class UserNameValidationError
    {
        public const string UserNameCannotBeBlank = "User Name Cannot be Blank";
        public const string InvalidFormatMustNotContainSpaces = "Invalid Format - must not contain spaces";
        public const string InvalidFormatMissingOrInvalidDelimiter = "Invalid Format - missing or invalid '.' delimiter";
        public const string DuplicateUser = "Duplicate User";
    }

    internal class UserNameValidationService : IUserNameValidationService
    {
        public bool ValidateUserName(string userName,
                                     bool isNewUser,
                                     int id,
                                     IList<User> users, 
                                     out string error)
        {
            var trim = userName?.Trim();

            if (string.IsNullOrEmpty(trim))
            {
                error = UserNameValidationError.UserNameCannotBeBlank;
                return false;
            }

            return ValidateFormat(trim, out error)
                && CheckDuplicates(trim, users, id, isNewUser, out error);
        }

        private static bool ValidateFormat(string userName, out string error)
        {
            if (userName.Contains(' '))
            {
                error = UserNameValidationError.InvalidFormatMustNotContainSpaces;
                return false;
            }

            if (!userName.Contains('.'))
            {
                error = UserNameValidationError.InvalidFormatMissingOrInvalidDelimiter;
                return false;
            }

            var split = userName.Split('.');

            if (split.Length == 0)
            {
                error = UserNameValidationError.InvalidFormatMissingOrInvalidDelimiter;
                return false;
            }

            if (Array.Exists(split, s => s.Length == 0))
            {
                error = UserNameValidationError.InvalidFormatMissingOrInvalidDelimiter;
                return false;
            }

            error = null;
            return true;
        }

        private static bool CheckDuplicates(string userName,
                                            IList<User> users,
                                            int id,
                                            bool isNewUser,
                                            out string error)
        {
            if (isNewUser && users.Any(u => string.Equals(u.UserName, userName, StringComparison.CurrentCultureIgnoreCase)))
            {
                error = UserNameValidationError.DuplicateUser;
                return false;
            }

            if (users.Any(u => u.Id != id
                            && string.Equals(u.UserName, userName, StringComparison.CurrentCultureIgnoreCase)))
            {
                error = UserNameValidationError.DuplicateUser;
                return false;
            }

            error = null;
            return true;
        }
    }
}
