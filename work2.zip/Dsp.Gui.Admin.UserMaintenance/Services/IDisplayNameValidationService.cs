﻿using System.Collections.Generic;
using Dsp.DataContracts;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface IDisplayNameValidationService
    {
        bool ValidateDisplayName(string displayName,
                                 bool isNewUser,
                                 int id,
                                 IList<User> users,
                                 out string error);
    }
}
