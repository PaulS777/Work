﻿using System;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class UserPermissionsChangedService : IUserPermissionsChangedService
    {
        public IObservable<bool> ObserveChanges(UserAdminViewModel viewModel)
        {
            var inactivityMins = viewModel.UserPermissions
                                          .ObservePropertiesChanged(vm => vm.WarnAfterInactivityMinutes,
                                                                    vm => vm.ErrorAfterInactivityMinutes);

            var permissions = viewModel.UserPermissions
                                       .ObservePropertiesChanged(vm => vm.IsEnabled,
                                                                 vm => vm.IsUserAdmin,
                                                                 vm => vm.IsCurveAdmin,
                                                                 vm => vm.IsCurveAdminApprover,
                                                                 vm => vm.IsEomRoll,
                                                                 vm => vm.IsBetaUser);

            return inactivityMins.Merge(permissions)
                                 .Where(_ => viewModel.SelectedUser != null)
                                 .Select(userPermissions => UserPermissionsChanged(userPermissions, viewModel.SelectedUser));
        }

        private static bool UserPermissionsChanged(UserPermissionsViewModel userPermissions, User user)
        {
            return userPermissions.IsEnabled != user.IsEnabled
                    || userPermissions.IsUserAdmin != user.IsAdmin
                    || userPermissions.IsCurveAdmin != user.IsCurveAdmin()
                    || userPermissions.IsCurveAdminApprover != user.IsCurveAdminApprover()
                    || userPermissions.IsBetaUser != user.IsBetaUser()
                    || userPermissions.IsEomRoll != user.IsEomRoll()
                    || userPermissions.WarnAfterInactivityMinutes != user.WarnAfterInactivityMinutes
                    || userPermissions.ErrorAfterInactivityMinutes != user.ErrorAfterInactivityMinutes;
        }
    }
}
