﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal static class DisplayNameValidationError
    {
        public const string DisplayNameCannotBeBlank = "Display Name Cannot be Blank";
        public const string DuplicateUser = "Duplicate User";
    }

    internal class DisplayNameValidationService : IDisplayNameValidationService
    {
        public bool ValidateDisplayName(string displayName, 
                                        bool isNewUser, 
                                        int id, 
                                        IList<User> users, 
                                        out string error)
        {
            var trim = displayName?.Trim();

            if (string.IsNullOrEmpty(trim))
            {
                error = DisplayNameValidationError.DisplayNameCannotBeBlank;
                return false;
            }

            return CheckDuplicates(displayName, users, id, isNewUser, out error);
        }

        private static bool CheckDuplicates(string displayName,
                                            IList<User> users,
                                            int id,
                                            bool isNewUser,
                                            out string error)
        {
            if (isNewUser
             && users.Any(u => string.Equals(u.DisplayName, displayName, StringComparison.CurrentCultureIgnoreCase)))
            {
                error = UserNameValidationError.DuplicateUser;
                return false;
            }

            if (users.Any(u => u.Id != id
                            && string.Equals(u.DisplayName, displayName, StringComparison.CurrentCultureIgnoreCase)))
            {
                error = DisplayNameValidationError.DuplicateUser;
                return false;
            }

            error = null;
            return true;
        }
    }
}
