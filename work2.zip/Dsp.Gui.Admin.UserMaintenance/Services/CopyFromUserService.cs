﻿using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using System.Collections.Generic;
using Dsp.Gui.Admin.UserMaintenance.Extensions;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class CopyFromUserService : ICopyFromUserService
    {
        public void CopyUserDetailsAndItems(User user, 
                                            UserPermissionsViewModel userPermissions, 
                                            IEnumerable<CurveGroupItem> curveGroupItems, 
                                            IEnumerable<CurveRegionItem> curveRegionItems, 
                                            IEnumerable<FxCurveItem> fxCurveItems)
        {
            CopyUserDetails(userPermissions, user);

            CopyUserCurveGroupPermissions(curveGroupItems, [.. user.CurveGroupPermissions]);

            CopyUserCurveRegionPermissions(curveRegionItems, [.. user.CurveRegionPermissions]);

            CopyUserFxCurvePermissions(fxCurveItems, [.. user.FxCurvePermissions]);
        }

        private static void CopyUserDetails(UserPermissionsViewModel userPermissions,
                                            User user)
        {
            userPermissions.IsUserAdmin = user.IsAdmin;
            userPermissions.IsCurveAdmin = user.HasPermission(PermissionCategory.CurveAdmin);
            userPermissions.IsCurveAdminApprover = user.HasPermission(PermissionCategory.CurveAdminApprover);
            userPermissions.IsEnabled = user.IsEnabled;
            userPermissions.WarnAfterInactivityMinutes = user.WarnAfterInactivityMinutes;
            userPermissions.ErrorAfterInactivityMinutes = user.ErrorAfterInactivityMinutes;
            userPermissions.IsEomRoll = user.HasPermission(PermissionCategory.EomRoll);
            userPermissions.IsBetaUser = user.HasPermission(PermissionCategory.BetaUser);
        }

        private static void CopyUserCurveGroupPermissions(IEnumerable<CurveGroupItem> curveGroupItems,
                                                          List<AuthorisationCurveGroup> userCurveGroups)
        {
            foreach (var item in curveGroupItems)
            {
                var authorisationCurveGroup = userCurveGroups.Find(u => u.CurveGroup.Id == item.CurveGroup.Id);

                if (authorisationCurveGroup != null)
                {
                    item.AuthorisationCurveGroup = authorisationCurveGroup;
                    item.CanRead = authorisationCurveGroup.CanRead;
                    item.CanUpdate = authorisationCurveGroup.CanUpdate;
                }
                else
                {
                    item.AuthorisationCurveGroup = null;
                    item.CanRead = false;
                    item.CanUpdate = false;
                }
            }
        }

        private static void CopyUserCurveRegionPermissions(IEnumerable<CurveRegionItem> curveRegionItems,
                                                           List<AuthorisationCurveRegion> userCurveRegions)
        {
            foreach (var item in curveRegionItems)
            {
                var authorisationCurveRegion = userCurveRegions.Find(u => u.CurveRegion == item.CurveRegion);

                if (authorisationCurveRegion != null)
                {
                    item.AuthorisationCurveRegion = authorisationCurveRegion;
                    item.CanRead = authorisationCurveRegion.CanRead;
                    item.CanUpdate = authorisationCurveRegion.CanUpdate;
                }
                else
                {
                    item.AuthorisationCurveRegion = null;
                    item.CanRead = false;
                    item.CanUpdate = false;
                }
            }
        }

        private static void CopyUserFxCurvePermissions(IEnumerable<FxCurveItem> fxCurveItems,
                                                       List<AuthorisationFxCurve> userFxCurves)
        {
            foreach (var item in fxCurveItems)
            {
                var authorisationFxCurve = userFxCurves.Find(u => u.FxCurveDefinitionId == item.Id);

                if (authorisationFxCurve != null)
                {
                    item.AuthorisationFxCurve = authorisationFxCurve;
                    item.CanRead = authorisationFxCurve.CanRead;
                    item.CanUpdate = authorisationFxCurve.CanUpdate;
                }
                else
                {
                    item.AuthorisationFxCurve = null;
                    item.CanRead = false;
                    item.CanUpdate = false;
                }
            }
        }
    }
}
