﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using DynamicData;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class FxCurvesChangedService : IFxCurvesChangedService
    {
        public IObservable<bool> ObserveChanges(IFxCurveItemsDataSource fxCurves)
        {
            var items = fxCurves.Connect();

            return items.AutoRefresh(i => i.CanRead)
                        .AutoRefresh(i => i.CanUpdate)
                        .ToCollection()
                        .Select(CalculateFxCurveItemsChanged);
        }

        private static bool CalculateFxCurveItemsChanged(IEnumerable<FxCurveItem> items)
        {
            return items.Any(FxCurveItemChanged);
        }

        private static bool FxCurveItemChanged(FxCurveItem item)
        {
            if (item.AuthorisationFxCurve != null)
            {
                return item.CanRead != item.AuthorisationFxCurve.CanRead
                    || item.CanUpdate != item.AuthorisationFxCurve.CanUpdate;
            }

            return item.CanRead || item.CanUpdate;
        }
    }
}
