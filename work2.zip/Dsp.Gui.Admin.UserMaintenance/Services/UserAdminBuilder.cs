﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class UserAdminBuilder : IUserAdminBuilder
    {
        private const int DefaultSpreadMultiplier = 1;

        public User GetUser(UserDetailsViewModel userDetails,
                            UserPermissionsViewModel userPermissions,
                            IEnumerable<CurveGroupItem> curveGroupItems,
                            IEnumerable<CurveRegionItem> curveRegionItems,
                            IEnumerable<FxCurveItem> fxCurveItems,
                            int userId)
        {
            var curveGroups = curveGroupItems.Select(i => new AuthorisationCurveGroup(i.CurveGroup, i.CanRead, i.CanUpdate));
            var curveRegions = curveRegionItems.Select(i => new AuthorisationCurveRegion(i.CurveRegion, i.CanRead, i.CanUpdate));
            var fxCurves = fxCurveItems.Select(i => new AuthorisationFxCurve(i.Id, i.CanRead, i.CanUpdate));

            var authorisationUserPermissions = GetAuthorizationUserPermissions(userId, 
                                                                               userPermissions.IsEomRoll, 
                                                                               userPermissions.IsBetaUser,
                                                                               userPermissions.IsCurveAdmin,
                                                                               userPermissions.IsCurveAdminApprover);

            return new User(userId,
                            userDetails.UserName,
                            userDetails.DisplayName,
                            userPermissions.IsUserAdmin,
                            userPermissions.IsEnabled,
                            DefaultSpreadMultiplier,
                            userPermissions.WarnAfterInactivityMinutes,
                            userPermissions.ErrorAfterInactivityMinutes,
                            curveGroups,
                            curveRegions,
                            fxCurves,
                            Array.Empty<UserChatTenorSelection>(),
                            authorisationUserPermissions);
        }

        private static List<AuthorisationUserPermission> GetAuthorizationUserPermissions(int userId, 
                                                                                         bool isEomRoll, 
                                                                                         bool isBetaUser,
                                                                                         bool isCurveAdmin,
                                                                                         bool isCurveAdminApprover)
        {
            var authorizationUserPermissions = new List<AuthorisationUserPermission>();

            if (isEomRoll)
            {
                authorizationUserPermissions.Add(new AuthorisationUserPermission(0, 
                                                                                 PermissionCategory.EomRoll.ToString(),
                                                                                 userId,
                                                                                 true));
            }

            if (isBetaUser)
            {
                authorizationUserPermissions.Add(new AuthorisationUserPermission(0,
                                                                                 PermissionCategory.BetaUser.ToString(),
                                                                                 userId,
                                                                                 true));
            }

            if (isCurveAdmin)
            {
				authorizationUserPermissions.Add(new AuthorisationUserPermission(0,
                                                                                 PermissionCategory.CurveAdmin.ToString(),
                                                                                 userId,
                                                                                 true));
			}

            if (isCurveAdminApprover)
            {
                authorizationUserPermissions.Add(new AuthorisationUserPermission(0,
                                                                                 PermissionCategory.CurveAdminApprover.ToString(),
                                                                                 userId,
                                                                                 true));
            }

			return authorizationUserPermissions;
        }
    }
}
