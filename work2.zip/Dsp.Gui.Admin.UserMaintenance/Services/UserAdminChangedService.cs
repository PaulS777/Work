﻿using System;
using System.Reactive.Linq;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class UserAdminChangedService : IUserAdminChangedService
    {
        private readonly IUserDetailsChangedService _userDetails;
        private readonly IUserPermissionsChangedService _userPermissions;
        private readonly ICurveGroupsChangedService _curveGroups;
        private readonly ICurveRegionsChangedService _curveRegions;
        private readonly IFxCurvesChangedService _fxCurves;

        public UserAdminChangedService(IUserDetailsChangedService userDetails,
                                       IUserPermissionsChangedService userPermissions,
                                       ICurveGroupsChangedService curveGroups,
                                       ICurveRegionsChangedService curveRegions,
                                       IFxCurvesChangedService fxCurves)
        {
            _userDetails = userDetails;
            _userPermissions = userPermissions;
            _curveGroups = curveGroups;
            _curveRegions = curveRegions;
            _fxCurves = fxCurves;
        }

        public IObservable<bool> ObserveChanges(UserAdminViewModel viewModel,
                                                ICurveGroupItemsDataSource curveGroupItems,
                                                ICurveRegionItemsDataSource curveRegionItems,
                                                IFxCurveItemsDataSource fxCurveItems)
        {
            var userDetails = _userDetails.ObserveChanges(viewModel).StartWith(false);

            var userPermissions = _userPermissions.ObserveChanges(viewModel).StartWith(false);

            var curveGroups = _curveGroups.ObserveChanges(curveGroupItems);

            var curveRegions = _curveRegions.ObserveChanges(curveRegionItems);

            var fxCurves = _fxCurves.ObserveChanges(fxCurveItems);

            return userDetails.CombineLatest(userPermissions,
                                             curveGroups, 
                                             curveRegions, 
                                             fxCurves, 
                                             CalculateHasChanged);
        }

        private static bool CalculateHasChanged(bool userDetails, 
                                                bool userPermissions,
                                                bool curveGroups, 
                                                bool curveRegions, 
                                                bool fxCurves)
        {
            return Any(userDetails, userPermissions, curveGroups, curveRegions, fxCurves);
        }

        private static bool Any(params bool[] list)
        {
            return Array.Exists(list, item => item);
        }
    }
}
