﻿using System;
using System.Globalization;
using System.Text;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class DisplayNameParser : IDisplayNameParser
    {
        public string ParseFromUserName(string userName)
        {
            try
            {
                var names = userName.Trim().Split('.', StringSplitOptions.TrimEntries);

                var sb = new StringBuilder();

                for (var idx = 0; idx < names.Length; idx++)
                {
                    var name = names[idx];

                    var parsed = string.Concat(name[0].ToString(CultureInfo.InvariantCulture).ToUpper(CultureInfo.InvariantCulture), name.AsSpan(1));

                    sb.Append(parsed);

                    if (idx < names.Length - 1)
                    {
                        sb.Append(' ');
                    }
                }

                return sb.ToString();
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
