﻿using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    [ExcludeFromCodeCoverage]
    public class UserAdminUpdateService(IAdminApiServiceClient adminApiServiceClient, 
                                        ILoggerFactory loggerFactory)
        : AdminUpdateService<User>(adminApiServiceClient, loggerFactory), 
          IUserAdminUpdateService;
}
