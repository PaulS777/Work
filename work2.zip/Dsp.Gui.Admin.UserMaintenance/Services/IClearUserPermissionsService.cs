﻿using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using System.Collections.Generic;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface IClearUserPermissionsService
    {
        void Clear(UserPermissionsViewModel userPermissions,
                   IEnumerable<CurveGroupItem> curveGroupItems,
                   IEnumerable<CurveRegionItem> curveRegionItems,
                   IEnumerable<FxCurveItem> fxCurveItems);
    }
}
