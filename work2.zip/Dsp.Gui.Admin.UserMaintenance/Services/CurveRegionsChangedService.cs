﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Linq;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using DynamicData;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class CurveRegionsChangedService : ICurveRegionsChangedService
    {
        public IObservable<bool> ObserveChanges(ICurveRegionItemsDataSource curveRegions)
        {
            var items = curveRegions.Connect();

            return items.AutoRefresh(i => i.CanRead)
                        .AutoRefresh(i => i.CanUpdate)
                        .ToCollection()
                        .Select(CalculateCurveRegionItemsChanged);
        }

        private static bool CalculateCurveRegionItemsChanged(IEnumerable<CurveRegionItem> items)
        {
            return items.Any(CurveRegionItemChanged);
        }

        private static bool CurveRegionItemChanged(CurveRegionItem item)
        {
            if (item.AuthorisationCurveRegion != null)
            {
                return item.CanRead != item.AuthorisationCurveRegion.CanRead
                    || item.CanUpdate != item.AuthorisationCurveRegion.CanUpdate;
            }

            return item.CanRead || item.CanUpdate;
        }
    }
}
