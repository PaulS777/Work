﻿using Dsp.DataContracts;
using Dsp.Gui.Dashboard.Common.Services.AdminUpdate;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    public interface IUserAdminUpdateService : IAdminUpdateService<User>
    {
    }
}
