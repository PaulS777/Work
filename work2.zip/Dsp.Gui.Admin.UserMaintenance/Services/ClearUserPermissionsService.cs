﻿using System.Collections.Generic;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal class ClearUserPermissionsService : IClearUserPermissionsService
    {
        public void Clear(UserPermissionsViewModel userPermissions,
                          IEnumerable<CurveGroupItem> curveGroupItems,
                          IEnumerable<CurveRegionItem> curveRegionItems,
                          IEnumerable<FxCurveItem> fxCurveItems)
        {
            userPermissions.IsEnabled = true;
            userPermissions.IsUserAdmin = false;
            userPermissions.IsCurveAdmin = false;
            userPermissions.IsCurveAdminApprover = false;
            userPermissions.IsEomRoll = false;
            userPermissions.IsBetaUser = false;
            userPermissions.WarnAfterInactivityMinutes = 0;
            userPermissions.ErrorAfterInactivityMinutes = 0;

            foreach (var item in curveGroupItems)
            {
                item.AuthorisationCurveGroup = null;
                item.CanRead = false;
                item.CanUpdate = false;
            }

            foreach (var item in curveRegionItems)
            {
                item.AuthorisationCurveRegion = null;
                item.CanRead = false;
                item.CanUpdate = false;
            }

            foreach (var item in fxCurveItems)
            {
                item.AuthorisationFxCurve = null;
                item.CanRead = false;
                item.CanUpdate = false;
            }
        }
    }
}
