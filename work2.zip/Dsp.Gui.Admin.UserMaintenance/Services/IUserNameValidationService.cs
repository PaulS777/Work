﻿using System.Collections.Generic;
using Dsp.DataContracts;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface IUserNameValidationService
    {
        bool ValidateUserName(string userName, 
                              bool isNewUser,
                              int id,
                              IList<User> users, 
                              out string error);
    }
}
