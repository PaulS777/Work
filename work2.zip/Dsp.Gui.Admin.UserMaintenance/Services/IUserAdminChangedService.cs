﻿using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using System;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface IUserAdminChangedService
    {
        IObservable<bool> ObserveChanges(UserAdminViewModel viewModel,
                                         ICurveGroupItemsDataSource curveGroupItems,
                                         ICurveRegionItemsDataSource curveRegionItems,
                                         IFxCurveItemsDataSource fxCurveItems);
    }
}
