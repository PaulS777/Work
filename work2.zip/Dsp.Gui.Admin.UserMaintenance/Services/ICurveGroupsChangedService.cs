﻿using System;
using Dsp.Gui.Admin.UserMaintenance.DataSource;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    internal interface ICurveGroupsChangedService
    {
        IObservable<bool> ObserveChanges(ICurveGroupItemsDataSource curveGroups);
    }
}
