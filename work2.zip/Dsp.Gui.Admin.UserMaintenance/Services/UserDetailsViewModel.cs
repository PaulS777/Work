﻿using Prism.Mvvm;

namespace Dsp.Gui.Admin.UserMaintenance.Services
{
    public class UserDetailsViewModel : BindableBase
    {
        private string _userName;
        private string _displayName;

        public string UserName
        {
            get => _userName;
            set
            {
                _userName = value;
                RaisePropertyChanged();
            }
        }

        public string DisplayName
        {
            get => _displayName;
            set
            {
                _displayName = value;
                RaisePropertyChanged();
            }
        }
    }
}
