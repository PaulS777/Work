﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DataSource;

namespace Dsp.Gui.Admin.UserMaintenance.DataSource
{    
    [ExcludeFromCodeCoverage]
    internal class CurveGroupItemsDataSource : DynamicDataSource<CurveGroupItem>, ICurveGroupItemsDataSource
    {
    }
}
