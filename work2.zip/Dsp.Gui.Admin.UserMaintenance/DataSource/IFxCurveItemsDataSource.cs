﻿using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DataSource;

namespace Dsp.Gui.Admin.UserMaintenance.DataSource
{
    internal interface IFxCurveItemsDataSource : IDynamicDataSource<FxCurveItem>
    {
    }
}
