﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Admin.UserMaintenance.DataSource
{
    [ExcludeFromCodeCoverage]
    internal class UserAdminDataSourceProvider : IUserAdminDataSourceProvider
    {
        [Inject]
        public ICurveGroupItemsDataSource CurveGroupItems { get; set; }

        [Inject]
        public ICurveRegionItemsDataSource CurveRegionItems { get; set; }

        [Inject]
        public IFxCurveItemsDataSource FxCurveItems { get; set; }
    }
}
