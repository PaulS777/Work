﻿using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DataSource;

namespace Dsp.Gui.Admin.UserMaintenance.DataSource
{
    public interface ICurveRegionItemsDataSource : IDynamicDataSource<CurveRegionItem>
    {
    }
}
