﻿namespace Dsp.Gui.Admin.UserMaintenance.DataSource
{
    internal interface IUserAdminDataSourceProvider
    {
        ICurveGroupItemsDataSource CurveGroupItems { get; }

        ICurveRegionItemsDataSource CurveRegionItems { get; }

        IFxCurveItemsDataSource FxCurveItems { get; }
    }
}
