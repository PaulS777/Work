﻿using System;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;

namespace Dsp.Gui.Admin.UserMaintenance.Controllers
{
    public interface IUserAdminController : IDisposable
    {
        UserAdminViewModel ViewModel { get; }
    }
}
