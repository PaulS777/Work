﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.UserMaintenance.DataSource;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Dsp.Gui.Admin.UserMaintenance.ViewModels;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.ServiceContracts;
using Microsoft.Extensions.DependencyInjection;
using Prism.Commands;
using Enum = System.Enum;

namespace Dsp.Gui.Admin.UserMaintenance.Controllers
{
    internal sealed class UserAdminController : IUserAdminController
    {
        private readonly ICurveControlService _curveControlService;
        private readonly IUserAdminDataSourceProvider _dataSourceProvider;
        private readonly IUserAdminChangedService _userAdminChangedService;
        private readonly IUserAdminToolBarService _toolBarService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly CompositeDisposable _disposables = new();
        private readonly ILogger _log;

        private bool _initialized;
        private bool _suspendUpdates;
        private bool _disposed;

        public UserAdminController(ICurveControlService curveControlService,
                                   IUserAdminDataSourceProvider dataSourceProvider,
                                   IUserAdminChangedService userAdminChangedService,
                                   IUserAdminToolBarService toolBarService,
                                   ISchedulerProvider schedulerProvider,
                                   ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _curveControlService = curveControlService;
            _dataSourceProvider = dataSourceProvider;
            _userAdminChangedService = userAdminChangedService;
            _toolBarService = toolBarService;
            _schedulerProvider = schedulerProvider;

            ViewModel.InitializeCommand = new DelegateCommand(Initialize);
        }

        [ExcludeFromCodeCoverage]
        ~UserAdminController()
        {
            Dispose(false);
        }

        public UserAdminViewModel ViewModel { get; } = new();

        [Inject]
        public ICopyFromUserService CopyFromUserService { get; set; }

        [Inject]
        public IClearUserPermissionsService ClearUserPermissionsService { get; set; }

        [Inject]
        public IUserNameValidationService UserNameValidationService { get; set; }

        [Inject]
        public IDisplayNameValidationService DisplayNameValidationService { get; set; }

        [Inject]
        public IDisplayNameParser DisplayNameParser { get; set; }

        [Inject]
        public IUserAdminBuilder UserAdminBuilder { get; set; }

        [Inject]
        public IUserAdminUpdateService UserAdminUpdateService { get; set; }

        [Inject]
        public IErrorMessageDialogService MessageDialogService { get; set; }

        [Inject]
        public IPopupNotificationService PopupNotificationService { get; set; }

        [Inject]
        public ISerialDisposableEnvelope ChangeSubscription { get; set; }

        private void Initialize()
        {
            if (_initialized)
            {
                return;
            }

            _initialized = true;

            ViewModel.IsBusy = true;

            ApplyAddNewUserDefaults();

            InitializeCurveRegionItemsDataSource();

            _curveControlService.CurveGroups
                                .Where(cg => cg != null)
                                .ObserveOn(_schedulerProvider.Dispatcher)
                                .Subscribe(OnCurveGroupItems)
                                .AddTo(_disposables);

			ViewModel.ObservePropertyChanged(vm => vm.IsAddNewUser)
                     .Select(vm => vm.IsAddNewUser)
                     .Subscribe(OnIsAddNewUser)
                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.SelectedUser)
                     .Where(_ => !_suspendUpdates)
                     .Select(vm => vm.SelectedUser)
                     .Subscribe(OnSelectedUser)
                     .AddTo(_disposables);

            ViewModel.UserDetails
                     .ObservePropertyChanged(vm => vm.UserName)
                     .Where(_ => !_suspendUpdates)
                     .Subscribe(_ => OnUserName())
                     .AddTo(_disposables);

            ViewModel.UserDetails
                     .ObservePropertyChanged(vm => vm.DisplayName)
                     .Where(_ => !_suspendUpdates)
                     .Subscribe(_ => OnDisplayName())
                     .AddTo(_disposables);

            _toolBarService.UpdateUser
                           .Subscribe(_ => OnToolbarUpdateUser())
                           .AddTo(_disposables);

            var users = _curveControlService.Users.Where(u => u != null);

            var fxCurveDefinitions = _curveControlService.FxCurveDefinitions.Where(fx => fx != null);

            users.CombineLatest(fxCurveDefinitions,
                                (u, fx) => new { Users = u, FxCurveDefinitions = fx })
                 .Take(1)
                 .ObserveOn(_schedulerProvider.Dispatcher)
                 .Subscribe(o => OnUsersAndCurvesLoaded(o.Users, o.FxCurveDefinitions))
                 .AddTo(_disposables);
        }

        #region Initialization Helpers

        private void ApplyAddNewUserDefaults()
        {
            ViewModel.IsAddNewUser = true;
            ViewModel.AddUserNameRequired = true;
            ViewModel.AddDisplayNameRequired = true;
            ViewModel.CanEditUserDetailsAndItems = true;
            ViewModel.UserPermissions.IsEnabled = true;
        }

        private void OnCurveGroupItems(IEnumerable<CurveGroup> curveGroups)
        {
            var curveGroupItems = curveGroups.Select(cg => new CurveGroupItem(cg)).ToList();

            if (ViewModel.CurveGroupItems == null)
            {
                ViewModel.CurveGroupItems = _dataSourceProvider.CurveGroupItems
                                                               .InitializeDataSource(curveGroupItems);
			}
            else
            {
                _dataSourceProvider.CurveGroupItems.RefreshItems(curveGroupItems);
            }
        }

        private void InitializeCurveRegionItemsDataSource()
        {
            var curveRegionItems = Enum.GetValues<CurveRegion>()
                                       .Select(r => new CurveRegionItem(r))
                                       .ToList();

            ViewModel.CurveRegionItems = _dataSourceProvider.CurveRegionItems
                                                            .InitializeDataSource(curveRegionItems);
        }

        #endregion

        #region Initialize on Users and FxCurves Loaded

        private void OnUsersAndCurvesLoaded(IEnumerable<User> users,
                                            IEnumerable<FxCurveDefinition> fxCurveDefinitions)
        {
            UpdateUsers(users);

            InitializeFxCurveItemsDataSource(fxCurveDefinitions);

            ValidateUserName();
            ValidateDisplayName();

            _curveControlService.Users
                                .Skip(1)
                                .ObserveOn(_schedulerProvider.Dispatcher)
                                .Subscribe(UpdateUsers)
                                .AddTo(_disposables);

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;
        }

        /// <summary>
        /// This could happen during an edit , caused by an external change
        /// </summary>
        /// <param name="users"></param>
        private void UpdateUsers(IEnumerable<User> users)
        {
            ViewModel.Users = users.OrderBy(u => u.UserName).ToList();
        }

        private void InitializeFxCurveItemsDataSource(IEnumerable<FxCurveDefinition> fxCurveDefinitions)
        {
            var fxCurveItems = fxCurveDefinitions.Where(fx => fx.QuoteCurrencyId == 1)
                                                 .Select(fx => new FxCurveItem(fx.Name, fx.Id))
                                                 .ToList();

            ViewModel.FxCurveItems = _dataSourceProvider.FxCurveItems
                                                        .InitializeDataSource(fxCurveItems);
        }

        #endregion

        #region Switch Add New User / Modify User

        private void OnIsAddNewUser(bool isAddNewUser)
        {
            _suspendUpdates = true;
            ChangeSubscription.DisposeSubscription();

            ClearAll();

            if (isAddNewUser)
            {
                ViewModel.AddUserNameRequired = true;
                ViewModel.AddDisplayNameRequired = true;
                ViewModel.CanEditUserDetailsAndItems = true;

                ValidateUserName();
                ValidateDisplayName();

                // required since we don't ObserveChanges
                ViewModel.HasChanged = false;
            }
            else
            {
                ViewModel.AddUserNameRequired = false;
                ViewModel.AddDisplayNameRequired = false;
                ViewModel.CanEditUserDetailsAndItems = false;
                ViewModel.IsUserNameValid = true;
                ViewModel.UserNameError = null;
                ViewModel.IsDisplayNameValid = true;
                ViewModel.DisplayNameError = null;

                // will cause HasChanges to Reset
                ChangeSubscription.ApplySubscription(ObserveChanges());
            }

            _toolBarService.SetCanUpdateUser(false);

            _suspendUpdates = false;
        }

        private void ClearAll()
        {
            ViewModel.SelectedUser = null;

            ViewModel.UserDetails.UserName = null;
            ViewModel.UserDetails.DisplayName = null;

            ClearUserPermissionsService.Clear(ViewModel.UserPermissions,
                                              _dataSourceProvider.CurveGroupItems.Items(),
                                              _dataSourceProvider.CurveRegionItems.Items(),
                                              _dataSourceProvider.FxCurveItems.Items());
        }

        #endregion

        #region Selected User Changed

        private void OnSelectedUser(User user)
        {
            _suspendUpdates = true;
            ChangeSubscription.DisposeSubscription();

            if (user != null)
            {
                CopyFromUserService.CopyUserDetailsAndItems(user, 
                                                            ViewModel.UserPermissions, 
                                                            _dataSourceProvider.CurveGroupItems.Items(), 
                                                            _dataSourceProvider.CurveRegionItems.Items(), 
                                                            _dataSourceProvider.FxCurveItems.Items());
            }

            if (!ViewModel.IsAddNewUser)
            {
                ViewModel.UserDetails.UserName = user?.UserName;
                ViewModel.UserDetails.DisplayName = user?.DisplayName;
                ViewModel.CanEditUserDetailsAndItems = true;
                ViewModel.IsUserNameValid = true;
                ViewModel.UserNameError = null;
                ViewModel.IsDisplayNameValid= true;
                ViewModel.DisplayNameError = null;

                ValidateUserName();

                ChangeSubscription.ApplySubscription(ObserveChanges());
            }

            UpdateToolBarCanUpdateUser();

            _suspendUpdates = false;
        }

        #endregion

        #region User Name Changed

        private void OnUserName()
        {
            CalculateAddUserNameNameRequired();

            ValidateUserName();

            if (ViewModel.IsUserNameValid)
            {
                ViewModel.UserDetails.DisplayName = DisplayNameParser.ParseFromUserName(ViewModel.UserDetails.UserName);
            }

            UpdateToolBarCanUpdateUser();
        }

        private void OnDisplayName()
        {
            CalculateAddDisplayNameRequired();

            ValidateDisplayName();

            UpdateToolBarCanUpdateUser();
        }

        private void CalculateAddUserNameNameRequired()
        {
            ViewModel.AddUserNameRequired = ViewModel.IsAddNewUser 
                                         && string.IsNullOrEmpty(ViewModel.UserDetails.UserName);

            ViewModel.AddDisplayNameRequired = ViewModel.IsAddNewUser 
                                            && string.IsNullOrEmpty(ViewModel.UserDetails.DisplayName);
        }

        private void CalculateAddDisplayNameRequired()
        {
            ViewModel.AddDisplayNameRequired = ViewModel.IsAddNewUser
                                            && string.IsNullOrEmpty(ViewModel.UserDetails.DisplayName);
        }

        private void ValidateUserName()
        {
            ViewModel.IsUserNameValid = UserNameValidationService.ValidateUserName(ViewModel.UserDetails.UserName, 
                                                                                   ViewModel.IsAddNewUser, 
                                                                                   ViewModel.SelectedUser?.Id ?? 0, 
                                                                                   ViewModel.Users, 
                                                                                   out var error);

            ViewModel.UserNameError = error;
        }

        private void ValidateDisplayName()
        {
            ViewModel.IsDisplayNameValid = DisplayNameValidationService.ValidateDisplayName(ViewModel.UserDetails.DisplayName, 
                                                                                            ViewModel.IsAddNewUser, 
                                                                                            ViewModel.SelectedUser?.Id ?? 0,
                                                                                            ViewModel.Users,
                                                                                            out var error);

            ViewModel.DisplayNameError = error;
        }

        #endregion

        #region Observe Changes

        private IDisposable ObserveChanges()
        {
            return _userAdminChangedService.ObserveChanges(ViewModel,
                                                           _dataSourceProvider.CurveGroupItems,
                                                           _dataSourceProvider.CurveRegionItems,
                                                           _dataSourceProvider.FxCurveItems)
                                           .Subscribe(OnUserAdminChanged);
        }

        private void OnUserAdminChanged(bool value)
        {
            ViewModel.HasChanged = value;

            UpdateToolBarCanUpdateUser();
        }

        private void UpdateToolBarCanUpdateUser()
        {
            var canUpdate = CalculateCanUpdateUser();

            _toolBarService.SetCanUpdateUser(canUpdate);
        }

        private bool CalculateCanUpdateUser()
        {
            if (ViewModel.IsAddNewUser)
            {
                return ViewModel.IsUserNameValid && ViewModel.IsDisplayNameValid;
            }

            return ViewModel.HasChanged && ViewModel.IsUserNameValid && ViewModel.IsDisplayNameValid;
        }

        #endregion

        #region Toolbar Update User

        private void OnToolbarUpdateUser()
        {
            _log.Info($"Updating User {ViewModel.UserDetails.UserName}");

            ViewModel.IsBusy = true;
            ViewModel.BusyText = ViewModel.IsAddNewUser ? "Adding New User.." : "Updating User...";

            if (ViewModel.IsAddNewUser)
            {
                AddNewUser();
            }
            else
            {
                UpdateUser();
            }
        }

        private void AddNewUser()
        {
            var user = UserAdminBuilder.GetUser(ViewModel.UserDetails,
                                                ViewModel.UserPermissions,
                                                ViewModel.CurveGroupItems,
                                                ViewModel.CurveRegionItems,
                                                ViewModel.FxCurveItems,
                                                0);

            UserAdminUpdateService.Add(new[]{user},
                                       _schedulerProvider.TaskPool)
                                  .ObserveOn(_schedulerProvider.Dispatcher)
                                  .Subscribe(_ => OnCompleted(true), 
                                             OnError)
                                  .AddTo(_disposables);
        }

        private void UpdateUser()
        {
            var user = UserAdminBuilder.GetUser(ViewModel.UserDetails, 
                                                ViewModel.UserPermissions,
                                                ViewModel.CurveGroupItems,
                                                ViewModel.CurveRegionItems,
                                                ViewModel.FxCurveItems,
                                                ViewModel.SelectedUser.Id);

            UserAdminUpdateService.Update(user,
                                          _schedulerProvider.TaskPool)
                                  .ObserveOn(_schedulerProvider.Dispatcher)
                                  .Subscribe(_ => OnCompleted(false),
                                             OnError)
                                  .AddTo(_disposables);
        }

        private void OnCompleted(bool isNewUser)
        {
            _log.Info("User Update Complete");

            _suspendUpdates = true;
            ChangeSubscription.DisposeSubscription();

            ClearAll();

            ApplyAddNewUserDefaults();

            ValidateUserName();

            ViewModel.HasChanged = false;

            _toolBarService.SetCanUpdateUser(false);

            var message = isNewUser ? $"Added {ViewModel.UserDetails.UserName}" : $"Updated {ViewModel.UserDetails.UserName}";

            PopupNotificationService.SendPopupNotification("User Update Completed", message);

            _suspendUpdates = false;

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;
        }

        private void OnError(Exception ex)
        {
            _log.Error("User update failed : " + ex.Message);

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;

            var messageArgs = new ErrorMessageDialogArgs("User Update Error",
                                                         ["Failed to Update User"],
                                                         true);

            MessageDialogService.ShowDialog(messageArgs);
        }

        #endregion

        #region Dispose

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                ChangeSubscription.Dispose();
            }

            _disposed = true;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        #endregion
    }
}
