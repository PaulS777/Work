﻿using Dsp.Gui.Dashboard.Common.Services.DataSource;
using Dsp.DataContracts;
using Prism.Mvvm;

namespace Dsp.Gui.Admin.UserMaintenance.ViewModels
{
    public sealed class FxCurveItem : BindableBase, IDataSourceItem
    {
        private string _name;
        private bool _canRead;
        private bool _canUpdate;

        public FxCurveItem(string name, int id)
        {
            Name = name;
            Id = id;
        }

        public AuthorisationFxCurve AuthorisationFxCurve { get; set; }

        public int Id { get; set; }

        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                RaisePropertyChanged();
            }
        }

        public bool CanRead
        {
            get => _canRead;
            set
            {
                _canRead = value;
                RaisePropertyChanged();
            }
        }

        public bool CanUpdate
        {
            get => _canUpdate;
            set
            {
                _canUpdate = value;
                RaisePropertyChanged();
            }
        }

        public void Dispose()
        {
            // do nothing
        }
    }
}
