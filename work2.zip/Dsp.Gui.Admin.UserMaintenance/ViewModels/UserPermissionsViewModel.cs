﻿using Prism.Mvvm;

namespace Dsp.Gui.Admin.UserMaintenance.ViewModels
{
    public class UserPermissionsViewModel : BindableBase
    {
        private bool _isEnabled;
		private bool _isUserAdmin;
        private bool _isCurveAdmin;
        private bool _isCurveAdminApprover;
        private int _warnAfterInactivityMinutes;
        private int _errorAfterInactivityMinutes;
        private bool _isBetaUser;
        private bool _isEomRoll;

        public bool IsEnabled
        {
            get => _isEnabled;
            set
            {
                _isEnabled = value;
                RaisePropertyChanged();
            }
        }

		public bool IsUserAdmin
        {
            get => _isUserAdmin;
            set
            {
                _isUserAdmin = value;
                RaisePropertyChanged();
            }
        }

        public bool IsCurveAdmin
        {
            get => _isCurveAdmin;
            set
            {
                _isCurveAdmin = value;
                RaisePropertyChanged();
            }
        }

        public bool IsCurveAdminApprover
        {
            get => _isCurveAdminApprover;
            set
            {
                _isCurveAdminApprover = value;
                RaisePropertyChanged();
            }
        }

        public bool IsBetaUser
        {
            get => _isBetaUser;
            set
            {
                _isBetaUser = value;
                RaisePropertyChanged();
            }
        }

        public bool IsEomRoll
        {
            get => _isEomRoll;
            set
            {
                _isEomRoll = value;
                RaisePropertyChanged();
            }
        }

        public int WarnAfterInactivityMinutes
        {
            get => _warnAfterInactivityMinutes;
            set
            {
                _warnAfterInactivityMinutes = value;
                RaisePropertyChanged();
            }
        }

        public int ErrorAfterInactivityMinutes
        {
            get => _errorAfterInactivityMinutes;
            set
            {
                _errorAfterInactivityMinutes = value;
                RaisePropertyChanged();
            }
        }
    }
}
