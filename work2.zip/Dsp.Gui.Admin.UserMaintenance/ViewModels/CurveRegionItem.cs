﻿using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Common.Services.DataSource;
using Prism.Mvvm;

namespace Dsp.Gui.Admin.UserMaintenance.ViewModels
{
    public class CurveRegionItem : BindableBase, IDataSourceItem
    {
        private CurveRegion _curveRegion;
        private bool _canRead;
        private bool _canUpdate;

        public CurveRegionItem(CurveRegion curveRegion)
        {
            CurveRegion = curveRegion;
        }

        public AuthorisationCurveRegion AuthorisationCurveRegion { get; set; }

        public CurveRegion CurveRegion
        {
            get => _curveRegion;
            set
            {
                _curveRegion = value;
                RaisePropertyChanged();
            }
        }

        public bool CanRead
        {
            get => _canRead;
            set
            {
                _canRead = value;
                RaisePropertyChanged();
            }
        }

        public bool CanUpdate
        {
            get => _canUpdate;
            set
            {
                _canUpdate = value;
                RaisePropertyChanged();
            }
        }

        public void Dispose()
        {
            // do nothing
        }
    }
}
