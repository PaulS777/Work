﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Dsp.Gui.Admin.UserMaintenance.Services;
using Prism.Commands;
using Prism.Mvvm;

namespace Dsp.Gui.Admin.UserMaintenance.ViewModels
{
    public class UserAdminViewModel : BindableBase
    {
        private bool _isBusy;
        private string _busyText;
        private IList<User> _users;
        private User _selectedUser;
        private bool _isAddNewUser;
        private bool _addUserNameRequired;
        private bool _addDisplayNameRequired;
        private bool _canEditUserDetailsAndItems;
        private bool _hasChanged;
        private bool _isUserNameValid;
        private string _userNameError;
        private bool _isDisplayNameValid;
        private string _displayNameError;
        private ReadOnlyObservableCollection<CurveGroupItem> _curveGroupItems;
        private ReadOnlyObservableCollection<CurveRegionItem> _curveRegionItems;
        private ReadOnlyObservableCollection<FxCurveItem> _fxCurveItems;

        public DelegateCommand InitializeCommand { get; set; }
        public UserDetailsViewModel UserDetails { get; } = new();
        public UserPermissionsViewModel UserPermissions { get; } = new();

        public IList<User> Users
        {
            get => _users;
            set
            {
                _users = value;
                RaisePropertyChanged();
            }
        }

        public bool IsAddNewUser
        {
            get => _isAddNewUser;
            set
            {
                if (_isAddNewUser == value)
                {
                    return;
                }

                _isAddNewUser = value;
                RaisePropertyChanged();
            }
        }

        public bool CanEditUserDetailsAndItems
        {
            get => _canEditUserDetailsAndItems;
            set
            {
                _canEditUserDetailsAndItems = value;
                RaisePropertyChanged();
            }
        }

        public bool AddUserNameRequired
        {
            get => _addUserNameRequired;
            set
            {
                _addUserNameRequired = value;
                RaisePropertyChanged();
            }
        }

        public bool AddDisplayNameRequired
        {
            get => _addDisplayNameRequired;
            set
            {
                _addDisplayNameRequired = value;
                RaisePropertyChanged();
            }
        }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        public User SelectedUser
        {
            get => _selectedUser;
            set
            {
                _selectedUser = value;
                RaisePropertyChanged();
            }
        }

        public ReadOnlyObservableCollection<CurveGroupItem> CurveGroupItems
        {
            get => _curveGroupItems;
            set
            {
                _curveGroupItems = value;
                RaisePropertyChanged();
            }
        }

        public ReadOnlyObservableCollection<CurveRegionItem> CurveRegionItems
        {
            get => _curveRegionItems;
            set
            {
                _curveRegionItems = value;
                RaisePropertyChanged();
            }
        }

        public bool HasChanged
        {
            get => _hasChanged;
            set
            {
                _hasChanged = value;
                RaisePropertyChanged();
            }
        }

        public bool IsUserNameValid
        {
            get => _isUserNameValid;
            set
            {
                _isUserNameValid = value;
                RaisePropertyChanged();
            }
        }

        public string UserNameError
        {
            get => _userNameError;
            set
            {
                _userNameError = value;
                RaisePropertyChanged();
            }
        }

        public bool IsDisplayNameValid
        {
            get => _isDisplayNameValid;
            set
            {
                _isDisplayNameValid = value;
                RaisePropertyChanged();
            }
        }

        public string DisplayNameError
        {
            get => _displayNameError;
            set
            {
                _displayNameError = value;
                RaisePropertyChanged();
            }
        }

        public ReadOnlyObservableCollection<FxCurveItem> FxCurveItems
        {
            get => _fxCurveItems;
            set
            {
                _fxCurveItems = value;
                RaisePropertyChanged();
            }
        }

        public string BusyText
        {
            get => _busyText;
            set
            {
                _busyText = value;
                RaisePropertyChanged();
            }
        }
    }
}
