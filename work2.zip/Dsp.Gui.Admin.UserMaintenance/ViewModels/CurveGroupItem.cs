﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Dashboard.Common.Services.DataSource;
using Prism.Mvvm;

namespace Dsp.Gui.Admin.UserMaintenance.ViewModels
{
    /// <summary>
    /// Maps to AuthorisationCurveGroup
    /// </summary>
    public sealed class CurveGroupItem : BindableBase, IDataSourceItem
    {
        private CurveGroup _curveGroup;
        private bool _canRead;
        private bool _canUpdate;

        public CurveGroupItem(CurveGroup curveGroup)
        {
            ArgumentNullException.ThrowIfNull(curveGroup);

            CurveGroup = curveGroup;
        }

        public CurveGroup CurveGroup
        {
            get => _curveGroup;
            set
            {
                _curveGroup = value;
                RaisePropertyChanged();
            }
        }

        public string Name => CurveGroup.Name;

        public bool CanRead
        {
            get => _canRead;
            set
            {
                _canRead = value;
                RaisePropertyChanged();
            }
        }

        public bool CanUpdate
        {
            get => _canUpdate;
            set
            {
                _canUpdate = value;
                RaisePropertyChanged();
            }
        }

        public AuthorisationCurveGroup AuthorisationCurveGroup { get; set; }

        public void Dispose()
        {
            // do nothing
        }
    }
}
