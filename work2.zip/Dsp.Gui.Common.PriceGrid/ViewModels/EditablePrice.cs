﻿using Prism.Mvvm;

namespace Dsp.Gui.Common.PriceGrid.ViewModels
{
    public class EditablePrice : BindableBase
    {
        private bool _isEditable;
        private decimal? _serverValue;
        private decimal? _editValue;
        private decimal? _value;
        private bool _hasError;
        private string _error;

        public decimal? ServerValue
        {
            get => _serverValue;
            set
            {
                _serverValue = value;
                RaisePropertyChanged();
            }
        }

        public decimal? EditValue
        {
            get => _editValue;
            set
            {
                _editValue = value;
                RaisePropertyChanged();
            }
        }

        public decimal? Value
        {
            get => _value;
            set
            {
                _value = value;
                RaisePropertyChanged();
            }
        }

        public string Error
        {
            get => _error;
            set
            {
                _error = value;
                RaisePropertyChanged();
            }
        }

        public bool IsEditable
        {
            get => _isEditable;
            set
            {
                _isEditable = value;
                RaisePropertyChanged();
            }
        }

        public bool HasError
        {
            get => _hasError;
            set
            {
                _hasError = value;
                RaisePropertyChanged();
            }
        }
    }
}
