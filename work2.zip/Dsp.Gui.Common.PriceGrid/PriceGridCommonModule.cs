﻿// ***********************************************************************************************************************
// PriceGridCommonModule.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.PriceGrid.Services.Bands;
using Dsp.Gui.Common.PriceGrid.Services.Grid;
using Dsp.Gui.Common.PriceGrid.Services.Premiums;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream;
using Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice;
using Microsoft.Extensions.DependencyInjection;
using ServiceCollection.Extensions.Modules;

namespace Dsp.Gui.Common.PriceGrid
{
    [ExcludeFromCodeCoverage]
    public class PriceGridCommonModule : Module
    {
        protected override void Load(IServiceCollection services)
        {
            base.Load(services);

            services.AddSingleton<ITenorPremiumCellGroupingService, TenorPremiumCellGroupingService>();
            services.AddSingleton<ITenorPremiumViewModelUpdater, TenorPremiumViewModelUpdater>();
            services.AddSingleton<ITenorTreeNodeExpansionService, TenorTreeNodeExpansionService>();
            services.AddTransient<IMarginValueChangedService, MarginValueChangedService>();
            services.AddTransient<ITenorMarginsValidationService, TenorMarginsValidationService>();
            services.AddTransient<ITenorPremiumChangedService, TenorPremiumChangedService>();
            services.AddTransient<ITenorPremiumPresentationService, TenorPremiumPresentationService>();
            services.AddSingleton<IPriceStreamsLoadedStatusTaskRunner, PriceStreamsLoadedStatusTaskRunner>();
            services.AddTransient<ILivePriceStreamReadyService, LivePriceStreamReadyService>();
            services.AddTransient<ILivePriceStreamService, LivePriceStreamService>();
            services.AddTransient<ILivePriceStreamSubscriptionService, LivePriceStreamSubscriptionService>();
            services.AddTransient<IToggleIsTradeableService, ToggleIsTradeableService>();
            services.AddTransient<ICurveEditRegistrationService, CurveEditRegistrationService>();
			services.AddSingleton<IPriceCurveSettingObserver, PriceCurveSettingObserver>();
            services.AddSingleton<ICurrentUserIsPublisherObserver, CurrentUserIsPublisherObserver>();
			
			services.AddFactory<ILivePriceStreamService, LivePriceStreamService>();

            services.AddPropertyInjectedServices();
        }
    }
}
