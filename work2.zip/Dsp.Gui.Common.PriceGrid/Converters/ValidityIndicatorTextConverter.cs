﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows.Data;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Common.PriceGrid.Converters
{
    [ExcludeFromCodeCoverage]
    public class ValidityIndicatorTextConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return value is not ValidityIndicator indicator ? 
                       Binding.DoNothing 
                       : indicator.ToEnumDescription();
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
