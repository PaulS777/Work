﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using Dsp.DataContracts.Curve;


namespace Dsp.Gui.Common.PriceGrid.Converters
{
    [ExcludeFromCodeCoverage]
    public class ValidityIndicatorBrushConverter : IValueConverter
    {
        public SolidColorBrush InvalidBrush { get; set; }
        public SolidColorBrush WarningBrush { get; set; }
        public SolidColorBrush ValidBrush { get; set; }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is not ValidityIndicator status)
            {
                return Binding.DoNothing;
            }

            switch (status)
            {
                case ValidityIndicator.Invalid:
                    return InvalidBrush;
                case ValidityIndicator.Warning:
                    return WarningBrush;
                default:
                    return ValidBrush;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Binding.DoNothing;
        }
    }
}
