﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common.PriceGrid.Converters
{
    [ExcludeFromCodeCoverage]
    public class CurveGroupBackgroundConverter : IValueConverter
    {
        private static readonly SolidColorBrush DefaultBrush = new(Colors.Transparent);
        public SolidColorBrush MoGasBrush { get; set; }
        public SolidColorBrush FreightBrush { get; set; }
        public SolidColorBrush CrudeBrush { get; set; }
        public SolidColorBrush FuelOilBrush { get; set; }
        public SolidColorBrush MiddleDistillatesBrush { get; set; }
        public SolidColorBrush JetAndSingaporeDistillatesBrush { get; set; }
        public SolidColorBrush NaphthaAndLpgBrush { get; set; }
        public SolidColorBrush BioBrush { get; set; }
        public SolidColorBrush RefineryMarginsBrush { get; set; }
        public SolidColorBrush PowerBrush { get; set; }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is not CurveGroup curveGroup)
            {
                return Binding.DoNothing;
            }

            return curveGroup.Name switch
            {
				CurveGroupNames.MOGAS => MoGasBrush,
				CurveGroupNames.Freight => FreightBrush,
                CurveGroupNames.Crude => CrudeBrush,
				CurveGroupNames.FuelOil => FuelOilBrush,
				CurveGroupNames.MiddleDistillates => MiddleDistillatesBrush,
				CurveGroupNames.JetAndSingaporeDistillates => JetAndSingaporeDistillatesBrush,
				CurveGroupNames.NaphthaAndLpg => NaphthaAndLpgBrush,
				CurveGroupNames.Bio => BioBrush,
				CurveGroupNames.RefineryMargins => RefineryMarginsBrush,
				CurveGroupNames.Power => PowerBrush,
                _ => DefaultBrush
            };
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
