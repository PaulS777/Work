﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Dsp.Gui.Common.PriceGrid.Converters
{
    [ExcludeFromCodeCoverage]
    public class GroupedCellBorderBrushConverter : IMultiValueConverter
    {
        public SolidColorBrush DefaultBrush { get; set; }
        public SolidColorBrush SelectedBrush { get; set; }
        public SolidColorBrush ParentBrush { get; set; }
        public SolidColorBrush ChildBrush { get; set; }

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values == null)
            {
                return DefaultBrush;
            }

            if (values.Length != 2)
            {
                return DefaultBrush;
            }

            if (values[0] is not bool || values[1] is not GroupedCellBorderType)
            {
                return DefaultBrush;
            }

            var borderType = (GroupedCellBorderType)values[1];

            if (borderType == GroupedCellBorderType.Parent)
            {
                return ParentBrush;
            }

            if (borderType == GroupedCellBorderType.Child)
            {
                return ChildBrush;
            }

            if ((bool)values[0])
            {
                return SelectedBrush;
            }

            return DefaultBrush;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            return Array.Empty<object>();
        }
    }
}
