﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Dsp.Gui.Common.PriceGrid.Converters
{
    [ExcludeFromCodeCoverage]
    public class MarginCellBackgroundConverter : IMultiValueConverter
    {
        public SolidColorBrush DefaultBrush { get; set; }
        public SolidColorBrush EditorBrush { get; set; }
        public SolidColorBrush SelectedBrush { get; set; }

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values.Length != 2)
            {
                return DefaultBrush;
            }

            if (values[0] is not bool || values[1] is not bool)
            {
                return DefaultBrush;
            }

            var isEditorTextSelected = (bool)values[1];

            if (isEditorTextSelected)
            {
                return EditorBrush;
            }

            var isSelected = (bool)values[0];

            return isSelected ? SelectedBrush : DefaultBrush;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            return Array.Empty<object>();
        }
    }
}
