﻿// ***********************************************************************************************************************
// TenorPremiumPresentationService.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:

// Synchronizes TenorPremiumViewModel with child Margin cell changes :
//  MarginChanged
//  IsMarginValid
//  Margin - CellBorderType
//  Margin - IsEditable
// ************************************************************************************************************************

using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public sealed class TenorPremiumPresentationService : ITenorPremiumPresentationService
    {
        private readonly CompositeDisposable _disposables = new();
        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~TenorPremiumPresentationService()
        {
            Dispose(false);
        }

        public void Attach(TenorPremiumViewModel tenorPremium)
        {
            tenorPremium.ObservePropertyChanged(vm => vm.IsChild)
                        .Subscribe(OnIsMarginChildChanged)
                        .AddTo(_disposables);

            tenorPremium.ObservePropertyChanged(vm => vm.CellBorderType)
                        .Subscribe(UpdateCellBorderTypes)
                        .AddTo(_disposables);
        }

        private static void UpdateCellBorderTypes(TenorPremiumViewModel tenorPremium)
        {
            tenorPremium.BidMargin.CellBorderType = tenorPremium.CellBorderType;
            tenorPremium.AskMargin.CellBorderType = tenorPremium.CellBorderType;
        }

        private static void OnIsMarginChildChanged(TenorPremiumViewModel tenorPremium)
        {
            var isEditable = tenorPremium.IsCurrentUserPublisher
                             && !tenorPremium.IsChild;

            tenorPremium.BidMargin.IsMarginChild = tenorPremium.IsChild;
            tenorPremium.AskMargin.IsMarginChild = tenorPremium.IsChild;

            tenorPremium.BidMargin.Margin.IsEditable = isEditable;
            tenorPremium.AskMargin.Margin.IsEditable = isEditable;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
