﻿// ***********************************************************************************************************************
// ITenorPremiumChangedService.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------

using Dsp.Gui.Common.PriceGrid.ViewModels;
using System;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public interface ITenorPremiumChangedService : IDisposable
    {
        void Attach(TenorPremiumViewModel tenorPremium);
    }
}
