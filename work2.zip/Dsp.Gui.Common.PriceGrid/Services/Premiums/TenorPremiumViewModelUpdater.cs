﻿using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public class TenorPremiumViewModelUpdater : ITenorPremiumViewModelUpdater
    {
        public void UpdateTenorPremium(TenorPremiumViewModel tenorPremium, 
                                       decimal? bidMargin, 
                                       decimal? askMargin, 
                                       bool isPublisher)
        {
            tenorPremium.IsCurrentUserPublisher = isPublisher;

            tenorPremium.BidMargin.Margin.ServerValue = bidMargin;
            tenorPremium.AskMargin.Margin.ServerValue = askMargin;

            if (!isPublisher)
            {
                tenorPremium.BidMargin.IsMarginParent = false;
                tenorPremium.BidMargin.IsMarginChild = false;
                tenorPremium.AskMargin.IsMarginParent = false;
                tenorPremium.AskMargin.IsMarginChild = false;
            }

            tenorPremium.BidMargin.Margin.IsEditable = isPublisher && !tenorPremium.BidMargin.IsMarginChild;
            tenorPremium.AskMargin.Margin.IsEditable = isPublisher && !tenorPremium.AskMargin.IsMarginChild;
        }
    }
}
