﻿// ***********************************************************************************************************************
// TenorMarginsValidationService.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
// Validates margins on user changes and at startup.
// Sets HasError on margin cells.
// Validation errors are cleared when user is not publisher.
//
// Usage:
// One instance per price tenor premium
// Margin.HasError used as binding source to display error icons
// IsMarginsValid monitored to determine overall curve status to display band header
// ************************************************************************************************************************
using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    /// <summary>
    /// Sets Error on Margins when Editable by comparing Bid And Ask values
    /// </summary>
    public sealed class TenorMarginsValidationService : ITenorMarginsValidationService
    {
        private const string MarginErrorText = "Invalid Margin";
        private readonly CompositeDisposable _disposables = new();
        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~TenorMarginsValidationService()
        {
            Dispose(false);
        }

        public void AttachPremium(TenorPremiumViewModel tenorPremium)
        {
            var isCurrentUserPublisher = tenorPremium.ObservePropertyChanged(vm => vm.IsCurrentUserPublisher)
                                                     .Select(vm => vm.IsCurrentUserPublisher)
                                                     .StartWith(tenorPremium.IsCurrentUserPublisher);

            var bidMargin = tenorPremium.BidMargin.Margin;
            var askMargin = tenorPremium.AskMargin.Margin;

            var bidMarginValue = bidMargin.ObservePropertyChanged(vm => vm.Value)
                                          .StartWith(bidMargin);

            var askMarginValue = askMargin.ObservePropertyChanged(vm => vm.Value)
                                          .StartWith(askMargin);

            isCurrentUserPublisher.CombineLatest(bidMarginValue,
                                                 askMarginValue,
                                                 (pub, bid, ask) => new
                                                 {
                                                     IsCurrentUserPublisher = pub,
                                                     Bid = bid,
                                                     Ask = ask
                                                 })
                                  .Subscribe(o =>
                                      {
                                          ValidateMargins(o.Bid,
                                                          o.Ask,
                                                          tenorPremium,
                                                          o.IsCurrentUserPublisher);
                                      }).AddTo(_disposables);
        }

        private static void ValidateMargins(EditablePrice bidMargin,
                                            EditablePrice askMargin,
                                            TenorPremiumViewModel tenorPremium,
                                            bool isPublisher)
        {
            if (!isPublisher || bidMargin.Value == null || askMargin.Value == null)
            {
                ClearErrors(bidMargin, 
                            askMargin,
                            tenorPremium);

                return;
            }

            var bidValue = Convert.ToDecimal(bidMargin.Value, CultureInfo.InvariantCulture);
            var askValue = Convert.ToDecimal(askMargin.Value, CultureInfo.InvariantCulture);

            if (bidValue == askValue)
            {
                SetErrors(bidMargin,
                          askMargin,
                          tenorPremium,
                          MarginErrorText);
                return;
            }

            if (bidValue > askValue)
            {
                SetErrors(bidMargin, 
                          askMargin, 
                          tenorPremium,
                          MarginErrorText);
                return;
            }

            ClearErrors(bidMargin, 
                        askMargin,
                        tenorPremium);
        }

        private static void ClearErrors(EditablePrice bidMargin, 
                                        EditablePrice askMargin,
                                        TenorPremiumViewModel tenorPremium)
        {
            bidMargin.HasError = false;
            askMargin.HasError = false;
            bidMargin.Error = null;
            askMargin.Error = null;

            tenorPremium.HasMarginErrors = false;
        }

        private static void SetErrors(EditablePrice bidMargin, 
                                      EditablePrice askMargin,
                                      TenorPremiumViewModel tenorPremium,
                                      string error)
        {
            bidMargin.HasError = true;
            askMargin.HasError = true;
            bidMargin.Error = error;
            askMargin.Error = error;

            tenorPremium.HasMarginErrors = true;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
