﻿using System;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public interface IMarginValueChangedService : IDisposable
    {
        void AttachMargin(TenorMargin tenorMargin,
                          IObserver<decimal?> textValueChanged,
                          IObserver<decimal?> spinValueChanged);
    }
}
