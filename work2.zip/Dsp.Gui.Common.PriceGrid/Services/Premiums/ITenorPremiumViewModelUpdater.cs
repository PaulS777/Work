﻿using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public interface ITenorPremiumViewModelUpdater
    {
        void UpdateTenorPremium(TenorPremiumViewModel tenorPremium,
                                decimal? bidMargin,
                                decimal? askMargin,
                                bool isPublisher);
    }
}
