﻿using System;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public interface ITenorMarginsValidationService : IDisposable
    {
        void AttachPremium(TenorPremiumViewModel tenorPremium);
    }
}
