﻿// ***********************************************************************************************************************
// TenorPremiumChangedService.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
// Initializes the Bid/Ask margin change monitors
// Observes margin changes (set by the monitors) to update the 
// premium HasChanged value
// ************************************************************************************************************************

using Dsp.Gui.Common.PriceGrid.ViewModels;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public sealed class TenorPremiumChangedService : ITenorPremiumChangedService
    {
        private readonly IMarginValueChangedService _bidMarginValueChangedService;
        private readonly IMarginValueChangedService _askMarginValueChangedService;
        private readonly CompositeDisposable _disposables = new();

        private bool _disposed;

        public TenorPremiumChangedService(IMarginValueChangedService bidMarginValueChangedService,
                                          IMarginValueChangedService askMarginValueChangedService)
        {
            _bidMarginValueChangedService = bidMarginValueChangedService;
            _askMarginValueChangedService = askMarginValueChangedService;
        }

        [ExcludeFromCodeCoverage]
        ~TenorPremiumChangedService()
        {
            Dispose(false);
        }

        public void Attach(TenorPremiumViewModel tenorPremium)
        {
            _bidMarginValueChangedService.AttachMargin(tenorPremium.BidMargin,
                                                       tenorPremium.Model().BidMarginTextUpdate,
                                                       tenorPremium.Model().MarginSpinUpdate);

            _askMarginValueChangedService.AttachMargin(tenorPremium.AskMargin,
                                                       tenorPremium.Model().AskMarginTextUpdate,
                                                       tenorPremium.Model().MarginSpinUpdate);

            tenorPremium.BidMargin
                        .ObservePropertyChanged(vm => vm.HasChanged)
                        .Subscribe(_ => CalculateMarginChanged(tenorPremium))
                        .AddTo(_disposables);

            tenorPremium.AskMargin
                        .ObservePropertyChanged(vm => vm.HasChanged)
                        .Subscribe(_ => CalculateMarginChanged(tenorPremium))
                        .AddTo(_disposables);
        }

        private static void CalculateMarginChanged(TenorPremiumViewModel tenorPremium)
        {
            tenorPremium.MarginChanged = tenorPremium.BidMargin.HasChanged
                                         || tenorPremium.AskMargin.HasChanged;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _bidMarginValueChangedService.Dispose();
                _askMarginValueChangedService.Dispose();

                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
