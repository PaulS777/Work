﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Common.PriceGrid.Services.Commands;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    [ExcludeFromCodeCoverage]
    public class TenorPremiumCellGroupingService : CellGroupingService<TenorPremiumViewModel>, ITenorPremiumCellGroupingService
    {
    }
}
