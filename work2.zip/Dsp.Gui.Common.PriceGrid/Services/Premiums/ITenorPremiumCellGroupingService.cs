﻿using Dsp.Gui.Common.PriceGrid.Services.Commands;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public interface ITenorPremiumCellGroupingService : ICellGroupingService<TenorPremiumViewModel>
    {
    }
}
