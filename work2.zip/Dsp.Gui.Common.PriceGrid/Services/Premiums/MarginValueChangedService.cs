﻿// ***********************************************************************************************************************
// MarginValueChangedService.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
// Responsible for managing changes to Bid and Ask Margin cells 
// Connects Margin text updates/spin button updates to the Model 
// Synchronizes TenorPremiumViewModel with child Margin cell changes :
//  MarginChanged
//  IsMarginValid
//  Margin - CellBorderType
//  Margin - IsEditable
// ************************************************************************************************************************
using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Prism.Commands;

namespace Dsp.Gui.Common.PriceGrid.Services.Premiums
{
    public sealed class MarginValueChangedService : IMarginValueChangedService
    {
        private readonly CompositeDisposable _disposables = new();
        private TenorMargin _viewModel;
        private decimal _previousSpinValue;
        private bool _isSpinUpdate;
        private bool _disposed;

        private const decimal MinimumIncrement = 0.01m;

        [ExcludeFromCodeCoverage]
        ~MarginValueChangedService()
        {
            Dispose(false);
        }

        public void AttachMargin(TenorMargin tenorMargin,
                                 IObserver<decimal?> textValueChanged,
                                 IObserver<decimal?> spinValueChanged)
        {
            _viewModel = tenorMargin;

            _viewModel.Margin
                      .ObservePropertyChanged(vm => vm.ServerValue)
                      .StartWith(_viewModel.Margin)
                      .Subscribe(vm =>
                      {
                          vm.EditValue = vm.Value = vm.ServerValue;
                          _previousSpinValue = Convert.ToDecimal(vm.ServerValue, CultureInfo.InvariantCulture);
                      })
                      .AddTo(_disposables);

            _viewModel.Margin
                      .ObservePropertyChanged(vm => vm.Value)
                      .StartWith(_viewModel.Margin)
                      .Subscribe(_ => OnMarginValueChanged(textValueChanged, spinValueChanged))
                      .AddTo(_disposables);

            _viewModel.SpinCommand = new DelegateCommand(() => _isSpinUpdate = true);
        }

        private void OnMarginValueChanged(IObserver<decimal?> textValueChanged,
                                          IObserver<decimal?> spinValueChanged)
        {
            var server = Convert.ToDecimal(_viewModel.Margin.ServerValue, CultureInfo.InvariantCulture);
            var editValue = Convert.ToDecimal(_viewModel.Margin.Value, CultureInfo.InvariantCulture);

            var hasChanged = editValue != server;

            _viewModel.HasChanged = hasChanged;

            if (_isSpinUpdate)
            {
                var valueChanged = Math.Abs(editValue - _previousSpinValue);

                if (valueChanged == MinimumIncrement)
                {
                    spinValueChanged.OnNext(_viewModel.Margin.Value);
                    _previousSpinValue = editValue;
                }
                else
                {
                    textValueChanged.OnNext(_viewModel.Margin.Value);
                }

                _isSpinUpdate = false;
            }
            else
            {
                textValueChanged.OnNext(_viewModel.Margin.Value);
            }
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
