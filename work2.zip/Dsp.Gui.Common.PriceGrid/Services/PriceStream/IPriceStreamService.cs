﻿using Dsp.Gui.Common.PriceGrid.Model;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream
{
    public interface IPriceStreamService
    {
        void SetDetails(PriceCurveDetails details);
        PriceCurveDetails GetDetails();
    }
}
