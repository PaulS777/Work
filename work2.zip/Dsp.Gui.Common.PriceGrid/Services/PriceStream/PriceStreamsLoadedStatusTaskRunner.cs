﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Linq;
using System.Reactive.Threading.Tasks;
using System.Threading.Tasks;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream
{
    [ExcludeFromCodeCoverage]
    public class PriceStreamsLoadedStatusTaskRunner : IPriceStreamsLoadedStatusTaskRunner
    {
        public Task<PriceCurve[]> RunPriceCurveObservables(IList<IObservable<PriceCurve>> priceCurves)
        {
            var tasks = priceCurves.Select(stream => stream.RunAsync(System.Threading.CancellationToken.None).ToTask())
                                   .ToList();

            return Task.WhenAll(tasks);
        }
    }
}
