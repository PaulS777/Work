﻿using System;
using System.Collections.Generic;
using System.Reactive;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice
{
    public interface ILivePriceStreamReadyService
    {
        IObservable<Unit> LivePriceStreamsReady(IList<ILivePriceStreamService> livePriceStreams);
    }
}
