﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice
{
    public sealed class LivePriceStreamService : ILivePriceStreamService
    {
        private readonly BehaviorSubject<PriceCurve> _priceCurve = new(null);
        private readonly ISchedulerProvider _schedulerProvider;

        private PriceCurveDetails _details;
        private IDisposable _disposable;
        private bool _disposed;

        public LivePriceStreamService(ISchedulerProvider schedulerProvider)
        {
            _schedulerProvider = schedulerProvider;
        }

        [ExcludeFromCodeCoverage]
        ~LivePriceStreamService()
        {
            Dispose(false);
        }

        public IObservable<PriceCurve> PriceCurve => _priceCurve.AsObservable();

        public PriceCurve PriceCurveSnapshot { get; set; }

        public void SetDetails(PriceCurveDetails details)
        {
            _details = details;
        }

        public PriceCurveDetails GetDetails() => _details;

        public int Id => _details != null ? _details.LinkedCurve.Id : 0;

        public void Initialize(IObservable<PriceCurve> priceCurve)
        {
            if (_details == null)
            {
                throw new InvalidOperationException("PriceStreamDetails not set");
            }

            var snapShot = priceCurve.Where(pc => pc != null)
                                     .Take(1);

            var updates = priceCurve.Where(pc => pc != null)
                                    .Skip(1)
                                    .Sample(TimeSpan.FromSeconds(1), _schedulerProvider.TaskPool);

            _disposable = snapShot.Concat(updates)
                                  .Subscribe(pc =>
                                             {
                                                 PriceCurveSnapshot = pc;
                                                 _priceCurve.OnNext(pc);
                                             },
                                             _priceCurve.OnError,
                                             _priceCurve.OnCompleted);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposable?.Dispose();
            }

            _disposed = true;
        }
    }
}
