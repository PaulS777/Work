﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.Common.Services;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice
{
    /// <summary>
    /// Publishes a single flag to indicate that all PriceStreams contain a PriceCurve
    /// </summary>
    public class LivePriceStreamReadyService : ILivePriceStreamReadyService
    {
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly ILogger _log;

        public LivePriceStreamReadyService(ISchedulerProvider schedulerProvider,
                                           ILoggerFactory loggerFactory)
        {
            _schedulerProvider = schedulerProvider;
            _log = loggerFactory.Create(GetType().Name);
        }

        public IObservable<Unit> LivePriceStreamsReady(IList<ILivePriceStreamService> livePriceStreams)
        {
            ArgumentNullException.ThrowIfNull(livePriceStreams);

            if (livePriceStreams.Count == 0)
            {
                        return Observable.Create<Unit>(obs =>
                                                {
                                                    obs.OnNext(Unit.Default);
                                                    obs.OnCompleted();

                                                    return Disposable.Empty;
                                                });
            }

            return Observable.Create<Unit>(obs =>
                                           {
                                               var disposable = CombinePriceCurves(livePriceStreams, 
                                                                                   obs);

                                               return () => disposable.Dispose();
                                           });
        }

        private IDisposable CombinePriceCurves(IEnumerable<ILivePriceStreamService> livePriceStreams,
                                               IObserver<Unit> observer)
        {
            var priceCurves = livePriceStreams.Select(p => p.PriceCurve.Where(pc => pc != null).Take(1))
                                              .ToArray();

            return Observable.CombineLatest(priceCurves)
                             .Timeout(TimeSpan.FromSeconds(5), _schedulerProvider.TaskPool)
                             .Subscribe(curves => 
                                        {
                                            _log.Info($"All new Live Price Streams available [{curves.Count}]");

                                            observer.OnNext(Unit.Default);
                                            observer.OnCompleted();
                                        },
                                        ex =>
                                        {
                                            if (ex is TimeoutException)
                                            {
                                                _log.Info("Timeout loading curves");
                                                observer.OnNext(Unit.Default);
                                                observer.OnCompleted();
                                            }
                                            else
                                            {
                                                _log.Info($"Error loading curves : {ex.Message}");
                                                observer.OnError(ex);
                                            }
                                        });
        }
    }
}
