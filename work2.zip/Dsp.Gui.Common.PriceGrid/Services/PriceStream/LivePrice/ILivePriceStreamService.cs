﻿using System;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice
{
    public interface ILivePriceStreamService : IPriceStreamService, IDisposable
    {
        void Initialize(IObservable<PriceCurve> priceCurve);
        IObservable<PriceCurve> PriceCurve { get; }
        PriceCurve PriceCurveSnapshot { get; set; }
        
    }
}
