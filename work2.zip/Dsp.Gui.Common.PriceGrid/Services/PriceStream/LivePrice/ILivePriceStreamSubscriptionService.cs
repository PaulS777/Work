﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Common.PriceGrid.Model;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice
{
    public interface ILivePriceStreamSubscriptionService : IDisposable
    {
        IObservable<List<ILivePriceStreamService>> RefreshPriceStreams(IList<PriceCurveDetails> priceCurves, 
                                                                       bool refreshAllPrices);
    }
}
