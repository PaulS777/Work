﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Linq;
using Dsp.Gui.Common.PriceGrid.Model;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream.LivePrice
{
    public sealed class LivePriceStreamSubscriptionService : ILivePriceStreamSubscriptionService
    {
        private readonly IPriceCurveService _priceCurveService;
        private readonly ILivePriceStreamReadyService _livePriceStreamReadyService;
        private readonly IPriceCurveSubscriptionManager _priceCurveSubscriptionManager;
        private readonly List<ILivePriceStreamService> _priceStreams = new();

        private bool _disposed;

        public LivePriceStreamSubscriptionService(IPriceCurveService priceCurveService,
                                                  ILivePriceStreamReadyService livePriceStreamReadyService,
                                                  IPriceCurveSubscriptionManager priceCurveSubscriptionManager)
        {
            _priceCurveService = priceCurveService;
            _livePriceStreamReadyService = livePriceStreamReadyService;
            _priceCurveSubscriptionManager = priceCurveSubscriptionManager;
        }

        [ExcludeFromCodeCoverage]
        ~LivePriceStreamSubscriptionService()
        {
            Dispose(false);
        }

        [Inject]
        public IServiceFactory<ILivePriceStreamService> ServiceFactory { get; set; }

        public IObservable<List<ILivePriceStreamService>> RefreshPriceStreams(IList<PriceCurveDetails> priceCurves,
                                                                              bool refreshAllPrices)
        {
            return refreshAllPrices ? ResetPriceStreams(priceCurves) : UpdatePriceStreams(priceCurves);
        }

        private IObservable<List<ILivePriceStreamService>> ResetPriceStreams(IList<PriceCurveDetails> priceCurves)
        {
            RemoveAllPriceStreams();

            var newProviders = GetPriceStreamProviders(priceCurves);

            var subscribeIds = priceCurves.Select(f => f.LinkedCurve.Id).ToArray();

            // builds cache of price curve subjects
            if (subscribeIds.Length != 0)
            {
                _priceCurveService.SubscribeToPriceCurves(subscribeIds);
            }

            return InitializeStreams(newProviders);
        }

        private IObservable<List<ILivePriceStreamService>> UpdatePriceStreams(IList<PriceCurveDetails> priceCurves)
        {
            RemoveFilteredPriceStreams(priceCurves);

            var newPriceStreams = GetPriceStreamProviders(priceCurves);

            if (newPriceStreams.Count == 0)
            {
                return InitializeStreams(newPriceStreams);
            }

            var subscribeIds = newPriceStreams.Select(p => p.GetDetails().LinkedCurve.Id).ToArray();

            // builds cache of price curve subjects
            _priceCurveService.SubscribeToPriceCurves(subscribeIds);

            return InitializeStreams(newPriceStreams);
        }

        private void RemoveAllPriceStreams()
        {
            if (_priceStreams.Count == 0)
            {
                return;
            }

            var unsubscribeIds = _priceStreams.Select(p => p.GetDetails().LinkedCurve.Id).ToList();

            _priceCurveService.UnsubscribeFromPriceCurves(unsubscribeIds);

            _priceStreams.ForEach(s => s.Dispose());

            _priceStreams.Clear();
        }

        private void RemoveFilteredPriceStreams(IEnumerable<PriceCurveDetails> priceCurves)
        {
            if (_priceStreams.Count == 0)
            {
                return;
            }

            // streams removed from filter or failed to load
            var removePriceStreams = _priceStreams.Where(p => p.PriceCurveSnapshot == null
                                                           || priceCurves.All(c => c.LinkedCurve != p.GetDetails().LinkedCurve))
                                                  .ToList();

            if (removePriceStreams.Count == 0)
            {
                return;
            }

            foreach (var priceStream in removePriceStreams)
            {
                priceStream.Dispose();

                _priceStreams.Remove(priceStream);
            }

            var unsubscribeIds = removePriceStreams.Select(p => p.GetDetails().LinkedCurve.Id).ToList();

            _priceCurveService.UnsubscribeFromPriceCurves(unsubscribeIds);
        }

        private List<ILivePriceStreamService> GetPriceStreamProviders(IEnumerable<PriceCurveDetails> priceCurves)
        {
            var newPriceCurves = priceCurves.Where(c => _priceStreams.TrueForAll(p => p.GetDetails().LinkedCurve != c.LinkedCurve))
                                            .ToArray();

            return newPriceCurves.Length != 0 ? newPriceCurves.Select(GetPriceStreamService).ToList() : [];
        }

        private IObservable<List<ILivePriceStreamService>> InitializeStreams(List<ILivePriceStreamService> newPriceStreams)
        {
            newPriceStreams.ForEach(InitializePriceStream);

            _priceStreams.AddRange(newPriceStreams);

            return _livePriceStreamReadyService.LivePriceStreamsReady(_priceStreams)
                                               .Select(_ => _priceStreams);
        }

        private void InitializePriceStream(ILivePriceStreamService priceStream)
        {
            var priceCurve = _priceCurveSubscriptionManager.GetPriceCurve(priceStream.GetDetails().LinkedCurve.Id);

            priceStream.Initialize(priceCurve);
        }

        private ILivePriceStreamService GetPriceStreamService(PriceCurveDetails curveDetails)
        {
            var priceStream = ServiceFactory.Create();

            priceStream.SetDetails(curveDetails);

            return priceStream;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                RemoveAllPriceStreams();
            }

            _disposed = true;
        }
    }
}
