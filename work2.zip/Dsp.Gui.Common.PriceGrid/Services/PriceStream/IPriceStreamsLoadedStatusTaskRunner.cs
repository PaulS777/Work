﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common.PriceGrid.Services.PriceStream
{
    public interface IPriceStreamsLoadedStatusTaskRunner
    {
        Task<PriceCurve[]> RunPriceCurveObservables(IList<IObservable<PriceCurve>> priceCurves);
    }
}
