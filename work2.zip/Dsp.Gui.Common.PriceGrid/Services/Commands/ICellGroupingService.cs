﻿using Dsp.Gui.Common.PriceGrid.ViewModels;
using System.Collections.Generic;

namespace Dsp.Gui.Common.PriceGrid.Services.Commands
{
    public interface ICellGroupingService<T>
    where T : IGroupedCell
    {
        void UpdateParent(IList<T> cells);
        List<T> UpdateChildren(IList<T> cells);
        List<T> UpdateChildrenBelowParent(List<T> cells);
        List<T> UpdateChildrenBelowParent(T parent, List<T> cells);
        void ClearDependencies(IList<T> cells);
    }
}
