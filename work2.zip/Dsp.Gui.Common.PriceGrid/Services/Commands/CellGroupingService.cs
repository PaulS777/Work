﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Commands
{
    public class CellGroupingService<T> : ICellGroupingService<T>
        where T : class, IGroupedCell
    {
        public void UpdateParent(IList<T> cells)
        {
            if (cells.All(cell => !cell.IsSelected))
            {
                return;
            }

            var parents = cells.Where(cell => cell.IsParent).ToList();

            if (parents.Any())
            {
                parents.ForEach(cell => SetParentChild(cell, false, false));
            }

            var selected = cells.Where(cell => cell.IsSelected)
                                .ToList();

            if (selected.Count != 1)
            {
                return;
            }

            var parent = selected[0];

            SetParentChild(parent, true, false);
        }

        public List<T> UpdateChildren(IList<T> cells)
        {
            if (cells.All(cell => !cell.IsSelected))
            {
                return [];
            }

            ClearExistingChildren(cells);

            var children = cells.Where(cell => cell.IsSelected).ToList();

            children.ForEach(cell =>
            {
                SetParentChild(cell, false, true);
            });

            return children;
        }

        public List<T> UpdateChildrenBelowParent(List<T> cells)
        {
            ArgumentNullException.ThrowIfNull(cells);

            var parent = cells.Find(cell => cell.IsParent);

            return parent == null ? [] : UpdateChildrenBelowParent(parent, cells);
        }

        public List<T> UpdateChildrenBelowParent(T parent, List<T> cells)
        {
            ClearExistingChildren(cells);

            var index = cells.IndexOf(parent) + 1;

            if (index == cells.Count)
            {
                return [];
            }

            var children = cells.GetRange(index, cells.Count - index);

            children.ForEach(cell => SetParentChild(cell, false, true));

            return children;
        }

        public void ClearDependencies(IList<T> cells)
        {
            var dependencies = cells.Where(cell => cell.IsParent || cell.IsChild).ToList();

            dependencies.ForEach(cell => SetParentChild(cell, false, false));
        }

        private static void SetParentChild(T cell,
                                           bool isParent,
                                           bool isChild)
        {
            cell.IsParent = isParent;
            cell.IsChild = isChild;
            
            SetBorderType(cell);
        }

        private static void ClearExistingChildren(IEnumerable<T> cells)
        {
            var children = cells.Where(tp => tp.IsChild).ToList();

            if (children.Count != 0)
            {
                children.ForEach(tp => SetParentChild(tp, false, false));
            }
        }

        private static void SetBorderType(T cell)
        {
            if (cell.IsParent)
            {
                cell.CellBorderType = GroupedCellBorderType.Parent;
            }
            else if (cell.IsChild)
            {
                cell.CellBorderType = GroupedCellBorderType.Child;
            }
            else
            {
                cell.CellBorderType = GroupedCellBorderType.None;
            }
        }
    }
}
