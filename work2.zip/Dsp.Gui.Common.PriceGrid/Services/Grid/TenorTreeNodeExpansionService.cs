﻿using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Grid
{
    public class TenorTreeNodeExpansionService : ITenorTreeNodeExpansionService
    {
        public List<string> GetTenorNodeExpansionKeys(IList<ITenorNode> tenorNodes, 
                                                       ITenorNode selectedNode)
        {
            var nodes = new List<string>();

            var parent = GetParentNode(tenorNodes, selectedNode);

            while (parent != null)
            {
                nodes.Add(parent.TenorIdentifier);

                parent = GetParentNode(tenorNodes, parent);
            }

            return nodes;
        }

        private static ITenorNode GetParentNode(IEnumerable<ITenorNode> tenorNodes,
                                                ITenorNode selectedNode)
        {
            return tenorNodes.FirstOrDefault(row => row.TenorIdentifier != null 
                                                    && row.TenorIdentifier == selectedNode.ParentTenorIdentifier);
        }
    }
}
