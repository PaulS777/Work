﻿using System.Collections.Generic;
using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Grid
{
    public interface ITenorTreeNodeExpansionService
    { 
        List<string> GetTenorNodeExpansionKeys(IList<ITenorNode> tenorNodes,
                                               ITenorNode selectedNode);
    }
}
