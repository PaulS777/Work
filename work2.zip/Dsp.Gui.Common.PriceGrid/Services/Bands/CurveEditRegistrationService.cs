﻿using System;
using System.Reactive.Linq;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.ManualCurve;

namespace Dsp.Gui.Common.PriceGrid.Services.Bands
{
    /// <summary>
    /// Instance per ManualPriceBand so has associated curve id and Change Observer
    /// </summary>
	public class CurveEditRegistrationService : ICurveEditRegistrationService
	{
        private readonly ICurveEditLookupMonitor _curvesEditLookupMonitor;
        private readonly ICurveEditSource _curveEditSource;

        public CurveEditRegistrationService(ICurveEditLookupMonitor curvesEditLookupMonitor,
                                            ICurveEditSource curveEditSource)
        {
            _curvesEditLookupMonitor = curvesEditLookupMonitor;
            _curveEditSource = curveEditSource;
        }

        public void RegisterCurve(ICanUndoChanges viewModel, int curveId)
        {
            ArgumentNullException.ThrowIfNull(viewModel);

            _curveEditSource.ManualCurveChanged = viewModel.ObservePropertyChanged(vm => vm.CanUndoChanges)
                                                           .StartWith(viewModel)
                                                           .Select(vm => vm.CanUndoChanges);

            _curvesEditLookupMonitor.RegisterCurveEditSource(curveId,
                                                             _curveEditSource);
        }

        public void UnRegisterCurve(int curveId)
        {
            _curvesEditLookupMonitor.UnRegisterCurveEditSource(curveId, _curveEditSource);

            _curveEditSource.ManualCurveChanged = Observable.Empty<bool>();
        }
	}
}
