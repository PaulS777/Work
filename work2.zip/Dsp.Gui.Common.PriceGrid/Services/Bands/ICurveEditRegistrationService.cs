﻿using Dsp.Gui.Common.PriceGrid.ViewModels;

namespace Dsp.Gui.Common.PriceGrid.Services.Bands
{
	public interface ICurveEditRegistrationService
	{
        void RegisterCurve(ICanUndoChanges viewModel, int curveId);
        void UnRegisterCurve(int curveId);
	}
}
