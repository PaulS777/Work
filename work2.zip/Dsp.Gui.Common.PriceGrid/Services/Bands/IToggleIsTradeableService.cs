﻿using Dsp.Gui.Common.PriceGrid.ViewModels;
using System;

namespace Dsp.Gui.Common.PriceGrid.Services.Bands
{
    public interface IToggleIsTradeableService : IDisposable
    {
        void Attach(IToggleIsTradeable toggleIsTradeable);
        void SubscribeUpdates();
        void UnsubscribeUpdates();
    }
}
