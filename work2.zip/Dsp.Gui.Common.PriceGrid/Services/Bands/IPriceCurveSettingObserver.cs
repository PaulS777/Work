﻿using Dsp.DataContracts.Curve;
using System;

namespace Dsp.Gui.Common.PriceGrid.Services.Bands
{
    public interface IPriceCurveSettingObserver
    {
        IObservable<PriceCurveSetting> Observe(int curveId);
    }
}
