﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts.AdminActions;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.PriceGrid.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.AdminActions;
using Dsp.ServiceContracts;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Common.PriceGrid.Services.Bands
{
    public sealed class ToggleIsTradeableService : IToggleIsTradeableService
    {
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly SerialDisposable _toggleIsTradeable = new();
        private readonly SerialDisposable _updateResponse = new();
        private readonly ILogger _log;

        private IToggleIsTradeable _livePriceCurve;
        private bool _disposed;

        public ToggleIsTradeableService(ISchedulerProvider schedulerProvider,
                                        ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _schedulerProvider = schedulerProvider;
        }

        [ExcludeFromCodeCoverage]
        ~ToggleIsTradeableService()
        {
            Dispose(false);
        }

        [Inject]
        public ISetCurvePublishingControlsActionService SetCurvePublishingControlsService { get; set; }

        [Inject]
        public IPopupNotificationService PopupNotificationService { get; set; }

        [Inject]
        public IErrorMessageDialogService ErrorMessageDialogService { get; set; }

        public void Attach(IToggleIsTradeable toggleIsTradeable)
        {
            _livePriceCurve = toggleIsTradeable;
        }

        public void SubscribeUpdates()
        {
            _toggleIsTradeable.Disposable =
                _livePriceCurve.ObservePropertyChanged(vm => vm.IsTradeable)
                               .Where(vm => vm.PriceCurveSetting() != null
                                            && vm.IsTradeable != vm.PriceCurveSetting().IsTradeable)
                               .Subscribe(_ => OnIsTradeableChangedByUser());
        }

        public void UnsubscribeUpdates()
        {
            _toggleIsTradeable.Disposable?.Dispose();
        }

        private void OnIsTradeableChangedByUser()
        {
            try
            {
                _livePriceCurve.CanEditIsTradeable = false;

                if (_livePriceCurve.LinkedCurveId == null)
                {
                    OnSetCurvePublishingError(new InvalidOperationException("Linked Curve Id not Set"));
                    return;
                }

                var setCurvePublishingControls = new SetCurvePublishingControls(ActionTargetType.PriceCurve, 
                                                                                _livePriceCurve.LinkedCurveId.Value,
                                                                                _livePriceCurve.PriceCurveSetting().IsPublishable,
                                                                                _livePriceCurve.IsTradeable,
                                                                                _livePriceCurve.PriceCurveSetting().IsExcelSourced);
           
                var update = SetCurvePublishingControlsService.Update([setCurvePublishingControls],
                                                                      _schedulerProvider.TaskPool);

                _updateResponse.Disposable = update.ObserveOn(_schedulerProvider.Dispatcher)
                                                   .Subscribe(OnSetCurvePublishingActionCompleted,
                                                              OnSetCurvePublishingError);
            }
            catch (Exception ex)
            {
                OnSetCurvePublishingError(ex);
            }
        }

        private void OnSetCurvePublishingActionCompleted(AdminApiActionCompleted actionCompleted)
        {
            if (!actionCompleted.CompletedWithWarnings)
            {
                var message = _livePriceCurve.IsTradeable
                                  ? "Price Curve set to TRADEABLE"
                                  : "Price Curve set to NON-TRADEABLE";

                PopupNotificationService.SendPopupNotification(message);
			}
            else
            {
                _livePriceCurve.IsTradeable = _livePriceCurve.PriceCurveSetting().IsTradeable;
                _livePriceCurve.CanEditIsTradeable = true;

                _log.Warn($"Curve Settings Updated with Warning : {actionCompleted.WarningMessage}");

                var args = new ErrorMessageDialogArgs("Curve Settings Updated with Warning(s)",
                                                      actionCompleted.WarningMessage,
                                                      true);

                ErrorMessageDialogService.ShowDialog(args);
			}
        }

        private void OnSetCurvePublishingError(Exception ex)
        {
            _livePriceCurve.IsTradeable = _livePriceCurve.PriceCurveSetting().IsTradeable;
            _livePriceCurve.CanEditIsTradeable = true;

            _log.Error($"Curve Settings Update Error : {ex.Message}");

            var args = new ErrorMessageDialogArgs("Curve Settings Update Error",
                                                  "Failed to Update Price Curve Settings",
                                                  true);

            ErrorMessageDialogService.ShowDialog(args);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _toggleIsTradeable.Dispose();
                _updateResponse.Dispose();
            }

            _disposed = true;
        }
    }
}
