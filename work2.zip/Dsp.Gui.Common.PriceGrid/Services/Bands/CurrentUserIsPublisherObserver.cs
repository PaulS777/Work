﻿using System;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.Common.PriceGrid.Services.Bands
{
    public class CurrentUserIsPublisherObserver : ICurrentUserIsPublisherObserver
    {
        private readonly ICurveControlService _curveControlService;
        private readonly IPriceCurveSettingObserver _priceCurveSettingObserver;

        public CurrentUserIsPublisherObserver(ICurveControlService curveControlService,
                                              IPriceCurveSettingObserver priceCurveSettingObserver)
        {
            _curveControlService = curveControlService;
            _priceCurveSettingObserver = priceCurveSettingObserver;
        }

        public IObservable<bool> Observe(int linkedCurveId)
        {
            var currentUser = _curveControlService.CurrentUser
                                                  .Where(user => user != null)
                                                  .Take(1);
            var priceCurveSetting
                = _priceCurveSettingObserver.Observe(linkedCurveId)
                                            .Where(setting => setting != null);

            return currentUser.CombineLatest(priceCurveSetting, GetIsCurrentUserPublisher);
        }

        private static bool GetIsCurrentUserPublisher(IIdentifiable user, PriceCurveSetting setting)
        {
            return user.Id == setting.PublisherId;
        }
    }
}
