﻿using System;

namespace Dsp.Gui.Common.PriceGrid.Services.Bands
{
    public interface ICurrentUserIsPublisherObserver
    {
        IObservable<bool> Observe(int linkedCurveId);
    }
}
