﻿using System;
using System.Reactive.Linq;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.Common.PriceGrid.Services.Bands
{
    public class PriceCurveSettingObserver : IPriceCurveSettingObserver
    {
        private readonly IPriceCurveSettingsProvider _priceCurveSettingsProvider;

        public PriceCurveSettingObserver(IPriceCurveSettingsProvider priceCurveSettingsProvider)
        {
            _priceCurveSettingsProvider = priceCurveSettingsProvider;
        }

        public IObservable<PriceCurveSetting> Observe(int curveId)
        {
            return _priceCurveSettingsProvider.PriceCurveSettings
                                              .Where(settings => settings != null)
                                              .Select(settings => settings.TryGetValue(curveId, out var setting)
                                                                      ? setting : null);
        }
    }
}
