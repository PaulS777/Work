﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using DevExpress.Xpf.Grid;

namespace Dsp.Gui.Common.PriceGrid.Behaviors
{
    [ExcludeFromCodeCoverage]
    public static class ExtendTreeNodeBehavior
    {
        public static readonly DependencyProperty NodesProperty
            = DependencyProperty.RegisterAttached("Nodes",
                                                  typeof(IList<string>),
                                                  typeof(ExtendTreeNodeBehavior),
                                                  new UIPropertyMetadata(null, OnNodesChanged));

        public static IList<string> GetNodes(DependencyObject target)
        {
            return (IList<string>)target.GetValue(NodesProperty);
        }

        public static void SetNodes(DependencyObject target, IList<string> values)
        {
            target.SetValue(NodesProperty, values);
        }

        private static void OnNodesChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            if (obj is not TreeListView treeListView)
            {
                return;
            }

            if (args.NewValue is not IList<string> nodes)
            {
                return;
            }

            foreach (var nodeKey in nodes)
            {
                var node = treeListView.GetNodeByKeyValue(nodeKey);

                if (node == null)
                {
                    return;
                }

                node.IsExpanded = true;
            }

            treeListView.MoveLastRow();
        }
    }
}
