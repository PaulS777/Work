﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Data;
using DevExpress.Xpf.Grid;

namespace Dsp.Gui.Common.PriceGrid.Behaviors
{
    [ExcludeFromCodeCoverage]
    public static class ColumnBindingBehavior
    {
        public static readonly DependencyProperty BindingPathProperty
            = DependencyProperty.RegisterAttached("BindingPath",
                                                  typeof(string),
                                                  typeof(ColumnBindingBehavior),
                                                  new FrameworkPropertyMetadata(null, OnBindingPathChanged));

        public static string GetBindingPath(DependencyObject target)
        {
            return (string)target.GetValue(BindingPathProperty);
        }
        public static void SetBindingPath(DependencyObject target, string value)
        {
            target.SetValue(BindingPathProperty, value);
        }
        private static void OnBindingPathChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            OnBindingPathChanged(o, (string)e.NewValue);
        }

        private static void OnBindingPathChanged(DependencyObject o, string newValue)
        {
            if (o is not GridColumn column)
            {
                return;
            }

            column.Binding = new Binding(newValue) { Mode = BindingMode.OneWay };
        }
    }
}