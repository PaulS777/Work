﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using DevExpress.Xpf.Grid;

namespace Dsp.Gui.Common.PriceGrid.Behaviors
{
    [ExcludeFromCodeCoverage]
    public static class TreeListExpandAllNodesBehavior
    {
        public static readonly DependencyProperty ExpandNodesProperty
            = DependencyProperty.RegisterAttached("ExpandNodes",
                                                  typeof(bool),
                                                  typeof(TreeListExpandAllNodesBehavior),
                                                  new UIPropertyMetadata(false, OnExpandNodesChanged));

        public static bool GetExpandNodes(DependencyObject target)
        {
            return (bool)target.GetValue(ExpandNodesProperty);
        }

        public static void SetExpandNodes(DependencyObject target, bool value)
        {
            target.SetValue(ExpandNodesProperty, value);
        }

        private static void OnExpandNodesChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            if (obj is not TreeListView treeListView)
            {
                return;
            }

            if (args.NewValue is not bool expandNodes)
            {
                return;
            }

            if (!expandNodes)
            {
                return;
            }

            treeListView.ExpandAllNodes();
        }
    }
}
