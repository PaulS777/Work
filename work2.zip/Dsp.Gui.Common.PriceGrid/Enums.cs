﻿namespace Dsp.Gui.Common.PriceGrid
{
    public enum RowTenorType
    {
        None,
        Daily,
        Weekly,
        Monthly,
        Quarterly,
        Yearly
    }

    public enum GroupedCellBorderType
    {
        None,
        Parent,
        Child
    }

    public enum TenorMarginSide
    {
        Bid,
        Ask
    }
}
