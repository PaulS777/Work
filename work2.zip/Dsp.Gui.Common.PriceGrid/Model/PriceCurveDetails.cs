﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.Gui.Common.PriceGrid.Model
{
    public enum PriceCurveType
    {
        Live,
        Manual
    }

    public sealed class PriceCurveDetails : IEquatable<PriceCurveDetails>
    {
        public PriceCurveDetails(PriceCurveType priceCurveType,
                                 LinkedCurve linkedCurve,
                                 int precision)
        {
            PriceCurveType = priceCurveType;
            LinkedCurve = linkedCurve;
            Precision = precision;
        }

        public string Name { get; set; }
        public CurveGroup CurveGroup { get; set; }
        public PriceCurveType PriceCurveType { get; }
        public LinkedCurve LinkedCurve { get; }
        public int Precision { get; }
        public TenorType TenorType { get; set; }

        public bool Equals(PriceCurveDetails other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }

            if (ReferenceEquals(this, other))
            {
                return true;
            }

            return Name == other.Name 
                   && CurveGroup == other.CurveGroup
                   && PriceCurveType == other.PriceCurveType 
                   && LinkedCurve.Equals(other.LinkedCurve) 
                   && Precision == other.Precision;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }

            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (obj.GetType() != GetType())
            {
                return false;
            }

            return Equals((PriceCurveDetails)obj);
        }

        public override int GetHashCode()
        {
            return LinkedCurve.GetHashCode();
        }

        public override string ToString()
        {
            return $"PriceCurveDetails : CurveGroup [{CurveGroup}] {Name} {PriceCurveType} {LinkedCurve}  {Precision}";
        }
    }
}
