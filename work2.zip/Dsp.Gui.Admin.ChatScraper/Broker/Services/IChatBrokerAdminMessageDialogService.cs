﻿using Dsp.Gui.Dashboard.Common.Services;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    public interface IChatBrokerAdminMessageDialogService : IErrorMessageDialogService
    {
    }
}
