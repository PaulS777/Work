﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Controllers;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    internal class ChatUserItemViewModelBuilder : IChatUserItemViewModelBuilder
    {
        [Inject]
        public IServiceFactory<IChatUserItemViewModelController> Factory { get; set; }

        public ChatUserItemViewModel CreateNewItem()
        {
            var controller = Factory.Create();

            var viewModel = controller.ViewModel;

            viewModel.SetChatUser(new ChatUser(0, EntityStatus.Active, string.Empty, new List<ChatUserMarket>(), new List<ChatUserReference>()));

            viewModel.NewRecord = true;
            viewModel.IsDirty = true;

            return viewModel;
        }

        public ChatUserItemViewModel CreateItemFromChatUser(ChatUser chatUser, 
                                                            IList<MarketItemViewModel> marketItems)
        {
            var controller = Factory.Create();

            var viewModel = controller.ViewModel;

            viewModel.Id = chatUser.Id;

            UpdateItemFromChatUser(viewModel, chatUser, marketItems);

            return viewModel;
        }

        public void UpdateItemFromChatUser(ChatUserItemViewModel viewModel, 
                                           ChatUser chatUser, 
                                           IList<MarketItemViewModel> marketItems)
        {
            viewModel.SetChatUser(chatUser);

            if (viewModel.NewRecord)
            {
                viewModel.Id = chatUser.Id;
                viewModel.NewRecord = false;
            }

            viewModel.Name = chatUser.Name;
            
            ApplyMarkets(viewModel, chatUser, marketItems);
            ApplyReferences(viewModel, chatUser.ChatUserReferences);

            viewModel.IsDirty = false;
        }


        public void UpdateUserMarkets(ChatUserItemViewModel chatUserViewModel,
                                      IEnumerable<MarketItemViewModel> marketItems)
        {
            if (chatUserViewModel.Markets == null)
            {
                return;
            }

            var marketIds = chatUserViewModel.Markets
                                             .Cast<MarketItemViewModel>()
                                             .Select(m => m.MarketId)
                                             .ToList();

            chatUserViewModel.Markets = marketItems.Where(item => marketIds.Contains(item.MarketId))
                                                   .Cast<object>()
                                                   .ToList();
        }

        private static void ApplyMarkets(ChatUserItemViewModel chatUserViewModel, 
                                         ChatUser chatUser, 
                                         IEnumerable<MarketItemViewModel> marketItems)
        {
            var marketIds = chatUser.ChatUserMarkets
                                    .Select(m => m.ChatMarketId)
                                    .ToList();

            chatUserViewModel.Markets = marketItems.Where(item => marketIds.Contains(item.MarketId))
                                                   .Cast<object>()
                                                   .ToList();
        }

        private static void ApplyReferences(ChatUserItemViewModel chatUserViewModel,
                                            IEnumerable<ChatUserReference> chatUserReferences)
        {
            chatUserViewModel.References = chatUserReferences.Select(r => r.ExternalRef)
                                                             .Cast<object>()
                                                             .ToList();
        }
    }
}
