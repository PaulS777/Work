﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    internal class ChatUserBuilder : IChatUserBuilder
    {
        public ChatUser GetNewChatUser(ChatUserItemViewModel viewModel, IList<ChatMarket> chatMarkets)
        {
            var chatUserMarkets = GetSelectedChatUserMarkets(viewModel, chatMarkets);

            var chatUserReferences = GetChatUserReferences(viewModel);

            var chatUser = new ChatUser(0, EntityStatus.Active, viewModel.Name, chatUserMarkets, chatUserReferences);

            return chatUser;
        }

        public ChatUser GetUpdatedChatUser(ChatUserItemViewModel viewModel, IList<ChatMarket> chatMarkets)
        {
            var chatUserMarkets = GetSelectedChatUserMarkets(viewModel, chatMarkets);

            var chatUserReferences = GetChatUserReferences(viewModel);

            var chatUser = new ChatUser(viewModel.GetChatUser().Id, EntityStatus.Active, viewModel.Name, chatUserMarkets, chatUserReferences);

            return chatUser;
        }

        public ChatUser GetDeletedChatUser(ChatUserItemViewModel viewModel, IList<ChatMarket> chatMarkets)
        {
            var chatUserMarkets = GetSelectedChatUserMarkets(viewModel, chatMarkets);

            var chatUserReferences = GetChatUserReferences(viewModel);

            var chatUser = new ChatUser(viewModel.GetChatUser().Id, EntityStatus.Deleted, viewModel.Name, chatUserMarkets, chatUserReferences);

            return chatUser;
        }

        private static List<ChatUserMarket> GetSelectedChatUserMarkets(ChatUserItemViewModel viewModel,
                                                                       IEnumerable<ChatMarket> chatMarkets)
        {
            if (viewModel.Markets == null)
            {
                return new List<ChatUserMarket>();
            }

            var marketIds = viewModel.Markets
                                     .Cast<MarketItemViewModel>()
                                     .Select(m => m.MarketId)
                                     .ToList();

            var chatUserMarkets = marketIds.Select(id => chatMarkets.Where(cm => cm.Id == id)
                                                                    .Select(_ => new ChatUserMarket(0, viewModel.GetChatUser().Id, id)))
                                           .SelectMany(cm => cm)
                                           .ToList();
            return chatUserMarkets;
        }

        private static List<ChatUserReference> GetChatUserReferences(ChatUserItemViewModel viewModel)
        {
            if (viewModel.References == null)
            {
                return new List<ChatUserReference>();
            }
          
            var chatUserReferences =
                viewModel.References.Select(r => new ChatUserReference(0, viewModel.GetChatUser().Id, r.ToString()))
                         .ToList();

            return chatUserReferences;
        }
    }
}
