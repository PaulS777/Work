﻿using System.Collections.Generic;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    public interface IChatUserItemViewModelBuilder
    {
        ChatUserItemViewModel CreateNewItem();
        ChatUserItemViewModel CreateItemFromChatUser(ChatUser chatUser,
                                                     IList<MarketItemViewModel> marketItems);
        void UpdateItemFromChatUser(ChatUserItemViewModel viewModel, 
                                    ChatUser chatUser,
                                    IList<MarketItemViewModel> marketItems);

        void UpdateUserMarkets(ChatUserItemViewModel chatUserViewModel,
                               IEnumerable<MarketItemViewModel> marketItems);
    }
}
