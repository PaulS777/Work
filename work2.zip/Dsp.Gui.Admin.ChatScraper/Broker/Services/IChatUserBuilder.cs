﻿using System.Collections.Generic;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    public interface IChatUserBuilder
    {
        ChatUser GetNewChatUser(ChatUserItemViewModel viewModel, IList<ChatMarket> chatMarkets);
        ChatUser GetUpdatedChatUser(ChatUserItemViewModel viewModel, IList<ChatMarket> chatMarkets);
        ChatUser GetDeletedChatUser(ChatUserItemViewModel viewModel, IList<ChatMarket> chatMarkets);
    }
}
