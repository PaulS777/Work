﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    [ExcludeFromCodeCoverage]
    internal class ChatUserItemCollectionService : EditableItemCollectionService<ChatUserItemViewModel>, IChatUserItemCollectionService
    {
        public ChatUserItemCollectionService(IChatUserDuplicateItemsService chatUserDuplicateItemsService)
        : base(chatUserDuplicateItemsService)
        {
        }

        ~ChatUserItemCollectionService()
        {
            Dispose(false);
        }
    }
}
