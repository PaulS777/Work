﻿using Dsp.Gui.Dashboard.Common.Services;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    internal class ChatBrokerAdminMessageDialogService : ErrorMessageDialogService, IChatBrokerAdminMessageDialogService
    {
    }
}
