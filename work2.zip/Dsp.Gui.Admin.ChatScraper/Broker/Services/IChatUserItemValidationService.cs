﻿using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    public interface IChatUserItemValidationService : IEditableItemValidationService<ChatUserItemViewModel>
    {
    }
}
