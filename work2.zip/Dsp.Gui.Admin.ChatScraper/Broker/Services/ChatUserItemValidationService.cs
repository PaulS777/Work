﻿using Dsp.Gui.Admin.ChatScraper.Broker.Rules;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Services
{
    internal class ChatUserItemValidationService : EditableItemValidationService<ChatUserItemViewModel>
                                                   ,IChatUserItemValidationService
    {
        public ChatUserItemValidationService(IChatUserNameRule nameRule)
        :base(nameRule)
        {
        }

        public override string IsDuplicateText() => "Duplicate Name";
    }
}
