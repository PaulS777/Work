﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Broker.ViewModels
{
    public sealed class ChatUserItemViewModel : EditableItem
    {
        private ChatUser _chatUser;
        private string _name;
        private IList<object> _markets;
        private IList<object> _references;
        private bool _disposed;

        private readonly IDisposable _controller;

        public ChatUserItemViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        [ExcludeFromCodeCoverage]
        ~ChatUserItemViewModel()
        {
            Dispose(false);
        }

        public void SetChatUser(ChatUser value) => _chatUser = value;
        public ChatUser GetChatUser() => _chatUser;
        public DelegateCommand DeleteCommand { get; set; }
        public DelegateCommand UndoDeleteCommand { get; set; }

        public string Name
        {
            get => _name;
            set
            {
                var parsed = value?.Trim();

                if (_name == parsed)
                {
                    return;
                }

                _name = parsed;
                RaisePropertyChanged();
            }
        }

        public IList<object> Markets
        {
            get => _markets;
            set
            {
                _markets = value;
                RaisePropertyChanged();
            }
        }

        public IList<object> References
        {
            get => _references;
            set
            {
                _references = value;
                RaisePropertyChanged();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller?.Dispose();
            }

            _disposed = true;
        }
    }
}
