﻿using Prism.Mvvm;

namespace Dsp.Gui.Admin.ChatScraper.Broker.ViewModels
{
    public class MarketItemViewModel : BindableBase
    {
        private int _marketId;
        private string _marketName;


        public int MarketId
        {
            get => _marketId;
            set
            {
                _marketId = value;
                RaisePropertyChanged();
            }
        }

        public string MarketName
        {
            get => _marketName;
            set
            {
                _marketName = value;
                RaisePropertyChanged();
            }
        }
    }
}
