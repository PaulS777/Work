﻿using System.Collections.ObjectModel;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Broker.ViewModels
{
    public class ChatBrokerUsersAdminViewModel : BindableBase, IEditableItemCollectionDialog
    {
        private ObservableCollection<ChatUserItemViewModel> _chatUserItems;
        private ObservableCollection<MarketItemViewModel> _marketItems;
        private IEditableItem _selectedItem;
        private bool _isBusy;
        private string _busyText;

        public ObservableCollection<ChatUserItemViewModel> ChatUserItems
        {
            get => _chatUserItems;
            set
            {
                _chatUserItems = value;
                RaisePropertyChanged();
            }
        }

        public IEditableItem SelectedItem
        {
            get => _selectedItem;
            set
            {
                _selectedItem = value;
                RaisePropertyChanged();
            }
        }

        public DelegateCommand AddChatUserCommand { get; set; }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        public string BusyText
        {
            get => _busyText;
            set
            {
                _busyText = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<MarketItemViewModel> MarketItems
        {
            get => _marketItems;
            set
            {
                _marketItems = value;
                RaisePropertyChanged();
            }
        }
    }
}
