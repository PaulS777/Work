﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Broker.Controllers;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Views
{
    [ExcludeFromCodeCoverage]
    public partial class ChatScraperBrokerAdminView 
    {
        public ChatScraperBrokerAdminView(IChatBrokerUsersAdminViewModelController controller)
        {
            DataContext = controller.ViewModel;
            InitializeComponent();
        }
    }
}
