﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Views
{
    /// <summary>
    /// Interaction logic for ChatBrokerUsersAdminControl.xaml
    /// </summary>
    [ExcludeFromCodeCoverage]
    public partial class ChatBrokerUsersAdminControl
    {
        public ChatBrokerUsersAdminControl()
        {
            InitializeComponent();
        }
    }
}
