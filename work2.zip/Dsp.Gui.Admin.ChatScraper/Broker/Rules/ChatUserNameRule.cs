﻿using System;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Rules
{
    internal class ChatUserNameRule : IChatUserNameRule
    {
        public IObservable<ChatUserItemViewModel> ObservePropertyChanged(ChatUserItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => vm.Name);
        }

        public string Validate(ChatUserItemViewModel viewModel)
        {
            return string.IsNullOrEmpty(viewModel.Name) ? "Missing Name" : string.Empty;
        }
    }
}
