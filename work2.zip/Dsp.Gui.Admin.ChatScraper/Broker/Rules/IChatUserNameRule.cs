﻿using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Rules
{
    public interface IChatUserNameRule : IValidationRule<ChatUserItemViewModel>
    {
    }
}
