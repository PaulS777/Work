﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Common.Extensions;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Controllers
{
    internal sealed class ChatUserItemViewModelController : IChatUserItemViewModelController
    {
        private readonly IChatUserItemValidationService _validationService;
        private readonly CompositeDisposable _disposables = new();
        private bool _disposed;

        public ChatUserItemViewModelController(IChatUserItemValidationService validationService)
        {
            _validationService = validationService;

            ViewModel = new ChatUserItemViewModel(this);

            ViewModel.DeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = true);
            ViewModel.UndoDeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = false);

            _validationService.Attach(ViewModel);

            ViewModel.ObservePropertyChanged(vm => vm.Name)
                     .Where(vm => !vm.NewRecord
                                  && vm.GetChatUser() != null)
                     .Subscribe(_ => CalculateIsDirty())
                     .AddTo(_disposables);

            ViewModel.ObservePropertiesChanged(vm => vm.Markets,
                                               vm => vm.References)
                     .Where(vm => !vm.NewRecord
                                  && vm.GetChatUser() != null)
                     .Subscribe(_ => CalculateIsDirty())
                     .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatUserItemViewModelController()
        {
            Dispose(false);
        }

        public ChatUserItemViewModel ViewModel { get; }

        private void CalculateIsDirty()
        {
            if (ViewModel.Name != ViewModel.GetChatUser().Name)
            {
                ViewModel.IsDirty = true;
                return;
            }

            if (!CompareMarkets(ViewModel.Markets, ViewModel.GetChatUser().ChatUserMarkets))
            {
                ViewModel.IsDirty = true;
                return;
            }

            if (!CompareReferences(ViewModel.References, ViewModel.GetChatUser().ChatUserReferences))
            {
                ViewModel.IsDirty = true;
                return;
            }

            ViewModel.IsDirty = false;
        }

        private static bool CompareMarkets(IEnumerable marketItems, 
                                           IEnumerable<ChatUserMarket> chatUserMarkets)
        {
            var newIds = marketItems != null
                ? marketItems.Cast<MarketItemViewModel>()
                             .Select(m => m.MarketId)
                             .OrderBy(m => m)
                             .ToList()
                : new List<int>();

            var originalIds = chatUserMarkets.Select(m => m.ChatMarketId)
                                             .OrderBy(m => m)
                                             .ToList();

            return !newIds.Except(originalIds).Any() 
                   && !originalIds.Except(newIds).Any();
        }

        private static bool CompareReferences(IEnumerable references,
                                              IEnumerable<ChatUserReference> chatUserReferences)
        {
            var newReferences = references != null
                ? references.Cast<string>()
                            .OrderBy(r => r)
                            .ToList()
                : new List<string>();

            var oldReferences = chatUserReferences.Select(r => r.ExternalRef)
                                                  .OrderBy(r => r)
                                                  .ToList();

            return !newReferences.Except(oldReferences).Any() 
                   && !oldReferences.Except(newReferences).Any();
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _validationService.Dispose();
            }

            _disposed = true;
        }
    }
}
