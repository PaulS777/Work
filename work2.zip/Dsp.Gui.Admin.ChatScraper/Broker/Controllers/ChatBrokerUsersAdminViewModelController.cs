﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.ServiceContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Microsoft.Extensions.DependencyInjection;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Controllers
{
    internal sealed class ChatBrokerUsersAdminViewModelController : IChatBrokerUsersAdminViewModelController
    {
        private readonly ICurveControlService _curveControlService;
        private readonly CompositeDisposable _disposables = new();
        private readonly IChatUserItemCollectionProvider _itemCollectionProvider;
        private readonly IChatUserItemViewModelBuilder _itemViewModelBuilder;
        private readonly IChatUserItemCollectionService _itemCollectionService;
        private readonly IChatScraperBrokerAdminToolBarService _toolBarService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly ILogger _log;

        private bool _disposed;

        public ChatBrokerUsersAdminViewModelController(ICurveControlService curveControlService,
                                                       IChatUserItemViewModelBuilder itemViewModelBuilder,
                                                       IChatUserItemCollectionProvider itemCollectionProvider,
                                                       IChatUserItemCollectionService itemCollectionService,
                                                       IChatScraperBrokerAdminToolBarService toolBarService,
                                                       ISchedulerProvider schedulerProvider,
                                                       ILoggerFactory loggerFactory)
        {
            _curveControlService = curveControlService;
            _itemCollectionProvider = itemCollectionProvider;
            _itemViewModelBuilder = itemViewModelBuilder;
            _itemCollectionService = itemCollectionService;
            _toolBarService = toolBarService;
            _schedulerProvider = schedulerProvider;
            _log = loggerFactory.Create(GetType().Name);

            ViewModel.AddChatUserCommand = new DelegateCommand(OnAddChatUserCommand);

            _toolBarService.Update
                           .Subscribe(_ => OnUpdateCommand())
                           .AddTo(_disposables);

            _toolBarService.Undo
                           .Subscribe(_ => OnUndoChatUserCommand())
                           .AddTo(_disposables);

            ViewModel.ChatUserItems = new ObservableCollection<ChatUserItemViewModel>();

            _itemCollectionService.CanExecuteUpdateCommand
                                  .Subscribe(OnCanExecuteUpdateCommand)
                                  .AddTo(_disposables);

            _itemCollectionService.CanExecuteUndoCommand
                                  .Subscribe(OnCanExecuteUndoCommand)
                                  .AddTo(_disposables);

            _itemCollectionService.ValidationErrors
                                  .Subscribe(OnValidationErrors)
                                  .AddTo(_disposables);

            var chatUsers = curveControlService.ChatUsers
                                               .Where(users => users != null);

            var chatMarkets = curveControlService.ChatMarkets
                                                 .Where(m => m != null);

            chatUsers.CombineLatest(chatMarkets.Take(1), (u, _) => u)
                     .ObserveOn(_schedulerProvider.Dispatcher)
                     .Subscribe(OnChatUsers)
                     .AddTo(_disposables);

            chatMarkets.Skip(1)
                       .ObserveOn(_schedulerProvider.Dispatcher)
                       .Subscribe(_ => OnChatMarkets())
                       .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatBrokerUsersAdminViewModelController()
        {
            Dispose(false);
        }

        public ChatBrokerUsersAdminViewModel ViewModel { get; } = new();

        [Inject]
        public IPopupNotificationService PopupNotificationService { get; set; }

        [Inject]
        public IErrorMessageDialogService ErrorMessageDialogService { get; set; }

        [Inject]
        public IChatUserItemsConflictService ChatUserConflictService { get; set; }

        [Inject]
        public IChatUserBuilder ChatUserBuilder { get; set; }

        [Inject]
        public IChatUserAdminUpdateService ChatUserAdminUpdateService { get; set; }

        private void OnCanExecuteUpdateCommand(bool value)
        {
            _toolBarService.SetCanUpdate(value);
        }

        private void OnCanExecuteUndoCommand(bool value)
        {
            _toolBarService.SetCanUndo(value);
        }

        private void OnAddChatUserCommand()
        {
            var viewModel = _itemViewModelBuilder.CreateNewItem();

            _itemCollectionService.AddNewItem(viewModel, ViewModel.ChatUserItems, ViewModel);
        }

        private void OnUndoChatUserCommand()
        {
            var chatUsers = _curveControlService.GetChatUsersSnapshot().ToList();

            RefreshRowItems(chatUsers);
        }

        private void OnChatUsers(IList<ChatUser> chatUsers)
        {
            var chatMarkets = _curveControlService.GetChatMarketSnapshot().ToList();

            UpdateRowItems(chatUsers, chatMarkets);
        }

        private void OnChatMarkets()
        {
            var chatMarkets = _curveControlService.GetChatMarketSnapshot();

            ViewModel.MarketItems = GetMarketItems(chatMarkets);

            foreach (var chatUserRowViewModel in ViewModel.ChatUserItems)
            {
                _itemViewModelBuilder.UpdateUserMarkets(chatUserRowViewModel, ViewModel.MarketItems);
            }
        }

        private void UpdateRowItems(IList<ChatUser> chatUsers,
                                    IEnumerable<ChatMarket> chatMarkets)
        {
            ViewModel.MarketItems ??= GetMarketItems(chatMarkets);
            
            var conflicts = ChatUserConflictService.GetConflicts(ViewModel.ChatUserItems, chatUsers);

            var rowItems =
                _itemCollectionProvider.GetCollection(ViewModel.ChatUserItems,
                                                      chatUsers,
                                                      (item, user) => item.Name == user.Name,
                                                      (item, user) => _itemViewModelBuilder.UpdateItemFromChatUser(item, user, ViewModel.MarketItems),
                                                      user => _itemViewModelBuilder.CreateItemFromChatUser(user, ViewModel.MarketItems));

            ViewModel.ChatUserItems = new ObservableCollection<ChatUserItemViewModel>(rowItems.OrderBy(i => i.Name));

            _itemCollectionService.RefreshItems(ViewModel.ChatUserItems);

            if (!conflicts.Any())
            {
                return;
            }

            var conflictNames = conflicts.Select(c => c.Name);

            ChatUserConflictService.ShowConflictsDialog(conflictNames);
        }

        private void RefreshRowItems(IList<ChatUser> chatUsers)
        {
            var items = _itemCollectionProvider.GetCollectionReset(chatUsers, 
                                                                   user => _itemViewModelBuilder.CreateItemFromChatUser(user, ViewModel.MarketItems));

            ViewModel.ChatUserItems = new ObservableCollection<ChatUserItemViewModel>(items);

            _itemCollectionService.RefreshItems(ViewModel.ChatUserItems);
        }

        private static ObservableCollection<MarketItemViewModel> GetMarketItems(IEnumerable<ChatMarket> chatMarkets)
        {
            var markets = chatMarkets.Where(cm => cm.Status == EntityStatus.Active)
                                     .Select(cm => new MarketItemViewModel
                                      {
                                          MarketId = cm.Id,
                                          MarketName = cm.Market

                                      }).ToList();

            return new ObservableCollection<MarketItemViewModel>(markets);
        }

        private void OnUpdateCommand()
        {
            ViewModel.IsBusy = true;
            ViewModel.BusyText = "Updating Chat Users";

            var chatMarkets = _curveControlService.GetChatMarketSnapshot()
                                                  .ToList();
            var response = 
                ChatUserAdminUpdateService.Update(ViewModel.ChatUserItems,
                                                  _schedulerProvider.Dispatcher,
                                                  item => ChatUserBuilder.GetNewChatUser(item, chatMarkets),
                                                  item => ChatUserBuilder.GetUpdatedChatUser(item, chatMarkets),
                                                  item => ChatUserBuilder.GetDeletedChatUser(item, chatMarkets));

            response.ObserveOn(_schedulerProvider.Dispatcher)
                    .Subscribe(_ => OnUpdateComplete(),
                               OnError)
                    .AddTo(_disposables);
        }

        private void OnUpdateComplete()
        {
            _log.Info("User update completed !");

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;

            OnCanExecuteUndoCommand(false);
            OnCanExecuteUpdateCommand(false);

            PopupNotificationService.SendPopupNotification("Chat Scraper Brokers Updated");
        }

        private void OnValidationErrors(IList<string> validationErrors)
        {
            if (validationErrors.Count == 0)
            {
                _toolBarService.ClearValidation();
            }
            else
            {
                _toolBarService.SetValidationErrors(validationErrors);
            }
        }

        private void OnError(Exception ex)
        {
            ViewModel.IsBusy = false;
            ViewModel.BusyText = "";

            var messageArgs = new ErrorMessageDialogArgs("Broker Update Failed", ex.Message, true);
            
            ErrorMessageDialogService.ShowDialog(messageArgs);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
