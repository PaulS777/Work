﻿using System;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Controllers
{
    public interface IChatBrokerUsersAdminViewModelController : IDisposable
    {
        ChatBrokerUsersAdminViewModel ViewModel { get; }
    }
}
