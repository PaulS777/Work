﻿using System;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Broker.Controllers
{
    public interface IChatUserItemViewModelController : IDisposable
    {
        ChatUserItemViewModel ViewModel { get; }
    }
}
