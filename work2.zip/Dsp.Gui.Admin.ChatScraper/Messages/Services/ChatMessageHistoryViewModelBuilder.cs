﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Messages.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Messages.Services
{
    internal class ChatMessageHistoryViewModelBuilder : IChatMessageHistoryViewModelBuilder
    {
        public ChatMessageHistoryViewModel CreateChatMessageHistoryViewModel(ChatMessageHistory chatMessageHistory, 
                                                                             IList<ChatIceMap> chatIceMaps, 
                                                                             IList<ChatMarket> chatMarkets)
        {
            var newMessage = new ChatMessageHistoryViewModel
                             {
                                 Id = chatMessageHistory.Id,
                                 TimeStamp = chatMessageHistory.TimeStamp,
                                 SenderExternalRef = chatMessageHistory.SenderExternalRef,
                                 ReceiverExternalRef = chatMessageHistory.ReceiverExternalRef,
                                 PriceCurveName = chatMessageHistory.PriceCurveName,
                                 TenorString = chatMessageHistory.TenorString,
                                 TenorClassified = chatMessageHistory.TenorClassified,
                                 IsDirty = false
                             };
            
            if (chatMessageHistory.TenorStart != null)
            {
                newMessage.TenorStart = chatMessageHistory.TenorStart.ToString();
            }

            if (newMessage.TenorEnd != null)
            {
                newMessage.TenorEnd = chatMessageHistory.TenorEnd.ToString();
            }
            newMessage.PriceString = chatMessageHistory.PriceString;

            if (chatMessageHistory.Bid != null)
            {
                newMessage.Bid = (double) chatMessageHistory.Bid;
            }

            if (chatMessageHistory.Offer != null)
            {
                newMessage.Offer = (double) chatMessageHistory.Offer;
            }

            if (chatMessageHistory.TradedPrice != null)
            {
                newMessage.TradedPrice = (double) chatMessageHistory.TradedPrice;
            }

            newMessage.TradedVolume = chatMessageHistory.TradedVolume;
            newMessage.IsManuallyCorrected = chatMessageHistory.IsManuallyCorrected;
            newMessage.IsCommodityEstimated = chatMessageHistory.IsCommodityEstimated;
            newMessage.IsUnknownUser = chatMessageHistory.IsUnknownUser;

            var iceMap = chatIceMaps.FirstOrDefault(ice => ice.PriceCurveName == chatMessageHistory.PriceCurveName);

            if (iceMap != null)
            {
                newMessage.Commodity = iceMap.PriceCurveName;
                newMessage.Market = chatMarkets.FirstOrDefault(x => x.Id == iceMap.ChatMarketId)?.Market;
            }

            return newMessage;
        }
    }
}
