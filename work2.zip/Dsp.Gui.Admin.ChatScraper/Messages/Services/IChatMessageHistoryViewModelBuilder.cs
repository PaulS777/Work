﻿using System.Collections.Generic;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Messages.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Messages.Services
{
    public interface IChatMessageHistoryViewModelBuilder
    {
        ChatMessageHistoryViewModel CreateChatMessageHistoryViewModel(ChatMessageHistory chatMessageHistory,
                                                                      IList<ChatIceMap> chatIceMaps,
                                                                      IList<ChatMarket> chatMarkets);

    }
}
