﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Messages.Views
{
    /// <summary>
    /// Interaction logic for UserAdminControl.xaml
    /// </summary>
    [ExcludeFromCodeCoverage]
    public partial class ChatMessagesAdminControl
    {
        public ChatMessagesAdminControl()
        {
            InitializeComponent();
        }
    }
}
