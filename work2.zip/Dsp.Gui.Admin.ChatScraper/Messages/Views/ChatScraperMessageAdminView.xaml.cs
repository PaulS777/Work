﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Messages.Controllers;

namespace Dsp.Gui.Admin.ChatScraper.Messages.Views
{
    /// <summary>
    /// Interaction logic for ChatScraperMessageAdminView.xaml
    /// </summary>
    [ExcludeFromCodeCoverage]
    public partial class ChatScraperMessageAdminView
    {
        public ChatScraperMessageAdminView(IChatMessageAdminViewModelController controller)
        {
            DataContext = controller.ViewModel;
            InitializeComponent();
        }
    }
}
