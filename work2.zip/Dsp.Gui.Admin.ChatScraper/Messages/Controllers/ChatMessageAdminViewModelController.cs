﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.ServiceContracts;
using Prism.Commands;
using DevExpress.Data.Extensions;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Messages.Services;
using Dsp.Gui.Admin.ChatScraper.Messages.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Messages.Controllers
{
    internal sealed class ChatMessageAdminViewModelController : IChatMessageAdminViewModelController
    {
        private readonly ICurveControlService _curveControlService;
        private readonly CompositeDisposable _disposables = new();
        private readonly IChatMessageHistoryViewModelBuilder _chatMessageHistoryViewModelBuilder;
        private readonly ILogger _log;

        private bool _disposed;

        public ChatMessagesAdminViewModel ViewModel { get; set; } = new();

        public ChatMessageAdminViewModelController(ICurveControlService curveControlService,
                                                   IChatMessageHistoryViewModelBuilder chatMessageHistoryViewModelBuilder,
                                                   ISchedulerProvider schedulerProvider,
                                                   ILoggerFactory loggerFactory)
        {
            _curveControlService = curveControlService;
            _chatMessageHistoryViewModelBuilder = chatMessageHistoryViewModelBuilder;
            _log = loggerFactory.Create(GetType().Name);
            
            ViewModel.MessageDialog.DialogOkCommand = new DelegateCommand(() => ViewModel.ShowDialog = false);
            ViewModel.MessageDialog.CompletedDialogOkCommand = new DelegateCommand(() => ViewModel.ShowCompletedDialog = false);

            _curveControlService.ChatMessages?.Where(d => d != null)
                                .ObserveOn(schedulerProvider.Dispatcher)
                                .Subscribe(_ => OnChatMessagesLoaded())
                                .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatMessageAdminViewModelController()
        {
            Dispose(false);
        }

        private void OnChatMessagesLoaded()
        {
            try
            {
                var  messages = ViewModel.ChatMessages.Count == 0 ? 
                                    _curveControlService.GetChatMessagesSnapshot()
                                                        .OrderBy(m => m.Id)
                                                        .ToList() 
                                    : _curveControlService.ChatMessagesOnUpdate
                                                          .OrderBy(m => m.Id)
                                                          .ToList();

                var iceCodes = _curveControlService.GetChatIceMapSnapshot().ToList();
                var chatMarkets = _curveControlService.GetChatMarketSnapshot().ToList();

                foreach (var message in messages)
                {
                    ProcessMessage(message, iceCodes, chatMarkets);
                }
            }
            catch (Exception e)
            {
                _log.Error("Exception OnChatMessagesLoaded :" + e.Message);
                OnError(e);
            }
        }

        private void ProcessMessage(ChatMessageHistory message, IList<ChatIceMap> iceCodes, IList<ChatMarket> chatMarkets)
        {
            var chatMessageHistory = ViewModel.ChatMessages.FirstOrDefault(m => m.Id == message.Id);

            if (message.Status == EntityStatus.Active)
            {
                if (chatMessageHistory != null)
                {
                    ViewModel.ChatMessages.RemoveAt(ViewModel.ChatMessages.FindIndex(m => m.Id == chatMessageHistory.Id));
                }

                var chatMessageHistoryViewModel =
                    _chatMessageHistoryViewModelBuilder.CreateChatMessageHistoryViewModel(message, iceCodes, chatMarkets);

                ViewModel.ChatMessages.Add(chatMessageHistoryViewModel);

            }
            else if (message.Status == EntityStatus.Deleted && chatMessageHistory != null)
            {
                ViewModel.ChatMessages.RemoveAt(ViewModel.ChatMessages.FindIndex(m => m.Id == message.Id));
            }
        }

        private void OnError(Exception ex)
        {
            _log.Error("Update failed !" + ex.Message);
            ViewModel.IsBusy = false;
            ViewModel.BusyText = "";
            ViewModel.ShowCompletedDialog = true;
            ViewModel.MessageDialog.DialogMessages = new[] { ex.Message };
            ViewModel.UserInputErrorMessage = "";
            ViewModel.IsUserInputError = false;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
