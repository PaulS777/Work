﻿using System;
using Dsp.Gui.Admin.ChatScraper.Messages.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Messages.Controllers
{
    public interface IChatMessageAdminViewModelController : IDisposable
    {
        ChatMessagesAdminViewModel ViewModel { get; }
    }
}