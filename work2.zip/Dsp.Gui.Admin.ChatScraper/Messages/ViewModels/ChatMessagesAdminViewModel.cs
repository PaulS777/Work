﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.Gui.Admin.ChatScraper.ViewModels;
using Prism.Mvvm;

namespace Dsp.Gui.Admin.ChatScraper.Messages.ViewModels
{
    public class ChatMessagesAdminViewModel : BindableBase
    {
        private ObservableCollection<ChatMessageHistoryViewModel> _chatMessages = new();
        private List<string> _priceCurveNames = new();

        private bool _isBusy;
        private string _busyText;
        private bool _showDialog;
        private bool _showCompletedDialog;
        private string _userInputMessage;
        private string _userInputErrorMessage;
        private bool _isUserInputError;
        
        public MessageDialogViewModel MessageDialog { get; set; } = new();

        public ObservableCollection<ChatMessageHistoryViewModel> ChatMessages
        {
            get => _chatMessages;
            set
            {
                _chatMessages = value;
                RaisePropertyChanged();
            }
        }

        public List<string> PriceCurveNames
        {
            get => _priceCurveNames;
            set
            {
                _priceCurveNames = value;
                RaisePropertyChanged();
            }
        }
        
        public string UserInputMessage
        {
            get => _userInputMessage;
            set
            {
                _userInputMessage = value;
                RaisePropertyChanged();
            }
        }

        public string UserInputErrorMessage
        {
            get => _userInputErrorMessage;
            set
            {
                _userInputErrorMessage = value;
                RaisePropertyChanged();
            }
        }

        public bool IsUserInputError
        {
            get => _isUserInputError;
            set
            {
                _isUserInputError = value;
                RaisePropertyChanged();
            }
        }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        public string BusyText
        {
            get => _busyText;
            set
            {
                _busyText = value;
                RaisePropertyChanged();
            }
        }
        public bool ShowDialog
        {
            get => _showDialog;
            set
            {
                _showDialog = value;
                RaisePropertyChanged();
            }
        }

        public bool ShowCompletedDialog
        {
            get => _showCompletedDialog;
            set
            {
                _showCompletedDialog = value;
                RaisePropertyChanged();
            }
        }
    }
}
