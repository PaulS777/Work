﻿using System;
using Prism.Mvvm;

namespace Dsp.Gui.Admin.ChatScraper.Messages.ViewModels
{
    public class ChatMessageHistoryViewModel : BindableBase
    {
        private int _id;
        private DateTime _timeStamp;
        private string _senderExtRef;
        private string _receiverExtRef;
        private string _priceCurveName;
        private string _tenorString;
        private string _tenorClassified;
        private string _tenorStart;
        private string _tenorEnd;
        private string _priceString;
        private double _bid;
        private double _offer;
        private double _tradedPrice;
        private string _tradedVolume;
        private int _isManuallyCorrected;
        private int _isCommodityEst;
        private int _isUnknownUser;
        private string _commodity;
        private string _iceTraded;
        private string _market;
        private bool _isDirty;

        public int Id
        {
            get => _id;
            set
            {
                _id = value;
                RaisePropertyChanged();
            }
        }

        public DateTime TimeStamp
        {
            get => _timeStamp;
            set
            {
                _timeStamp = value;
                RaisePropertyChanged();
            }
        }

        public string SenderExternalRef
        {
            get => _senderExtRef;
            set
            {
                _senderExtRef = value;
                RaisePropertyChanged();
            }
        }

        public string ReceiverExternalRef
        {
            get => _receiverExtRef;
            set
            {
                _receiverExtRef = value;
                RaisePropertyChanged();
            }
        }

        public string PriceCurveName
        {
            get => _priceCurveName;
            set
            {
                _priceCurveName = value;
                RaisePropertyChanged();
            }
        }

        public string TenorString
        {
            get => _tenorString;
            set
            {
                _tenorString = value;
                RaisePropertyChanged();
            }
        }

        public string TenorClassified
        {
            get => _tenorClassified;
            set
            {
                _tenorClassified = value;
                RaisePropertyChanged();
            }
        }

        public string TenorStart
        {
            get => _tenorStart;
            set
            {
                _tenorStart = value;
                RaisePropertyChanged();
            }
        }

        public string TenorEnd
        {
            get => _tenorEnd;
            set
            {
                _tenorEnd = value;
                RaisePropertyChanged();
            }
        }

        public string PriceString
        {
            get => _priceString;
            set
            {
                _priceString = value;
                RaisePropertyChanged();
            }
        }

        public double Bid
        {
            get => _bid;
            set
            {
                _bid = value;
                RaisePropertyChanged();
            }
        }

        public double Offer
        {
            get => _offer;
            set
            {
                _offer = value;
                RaisePropertyChanged();
            }
        }

        public double TradedPrice
        {
            get => _tradedPrice;
            set
            {
                _tradedPrice = value;
                RaisePropertyChanged();
            }
        }

        public string TradedVolume
        {
            get => _tradedVolume;
            set
            {
                _tradedVolume = value;
                RaisePropertyChanged();
            }
        }

        public int IsManuallyCorrected
        {
            get => _isManuallyCorrected;
            set
            {
                _isManuallyCorrected = value;
                RaisePropertyChanged();
            }
        }

        public int IsCommodityEstimated
        {
            get => _isCommodityEst;
            set
            {
                _isCommodityEst = value;
                RaisePropertyChanged();
            }
        }

        public int IsUnknownUser
        {
            get => _isUnknownUser;
            set
            {
                _isUnknownUser = value;
                RaisePropertyChanged();
            }
        }

        public string Commodity
        {
            get => _commodity;
            set
            {
                _commodity = value;
                RaisePropertyChanged();
            }
        }

        public string IceTraded
        {
            get => _iceTraded;
            set
            {
                _iceTraded = value;
                RaisePropertyChanged();
            }
        }

        public string Market
        {
            get => _market;
            set
            {
                _market = value;
                RaisePropertyChanged();
            }
        }

        public bool IsDirty
        {
            get => _isDirty;
            set
            {
                _isDirty = value;
                RaisePropertyChanged();
            }
        }
    }
}
