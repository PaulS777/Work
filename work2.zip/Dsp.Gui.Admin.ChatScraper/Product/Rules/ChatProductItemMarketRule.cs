﻿using System;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Product.Rules
{
    internal class ChatProductItemMarketRule : IChatProductItemMarketRule
    {
        public IObservable<ChatProductItemViewModel> ObservePropertyChanged(ChatProductItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => vm.ChatMarket);
        }

        public string Validate(ChatProductItemViewModel viewModel)
        {
            return viewModel.ChatMarket == null ? "Missing Market" : string.Empty;
        }
    }
}
