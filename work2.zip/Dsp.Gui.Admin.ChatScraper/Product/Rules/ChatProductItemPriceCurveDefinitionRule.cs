﻿using System;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Product.Rules
{
    internal class ChatProductItemPriceCurveDefinitionRule : IChatProductItemPriceCurveDefinitionRule
    {
        public IObservable<ChatProductItemViewModel> ObservePropertyChanged(ChatProductItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => vm.PriceCurveDefinition);
        }

        public string Validate(ChatProductItemViewModel viewModel)
        {
            return viewModel.PriceCurveDefinition == null ? "Missing Price Curve" : string.Empty;
        }
    }
}
