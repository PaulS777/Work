﻿using System;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Product.Rules
{
    internal class ChatProductItemShortcutRule : IChatProductItemShortcutRule
    {
        public IObservable<ChatProductItemViewModel> ObservePropertyChanged(ChatProductItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => vm.IsDuplicateShortcut);
        }

        public string Validate(ChatProductItemViewModel viewModel)
        {
            return viewModel.IsDuplicateShortcut ? "Duplicate Shortcut" : string.Empty;
        }
    }
}
