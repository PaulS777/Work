﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.ViewModels;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Product.ViewModels
{
    public sealed class ChatProductItemViewModel : EditableItem, IEditableItemWithShortcuts
    {
        private ChatIceMap _chatIceMap;
        private string _priceCurveName;
        private string _priceCurveDescription;
        private PriceCurveDefinitionItem _priceCurveDefinition;
        private ChatMarketItem _chatMarket;
        private IList<object> _shortcuts;
        private bool _isDuplicateShortcut;
        private bool _isDeletedWithExistingMapping;
        private bool _disposed;

        private readonly IDisposable _controller;

        public ChatProductItemViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        [ExcludeFromCodeCoverage]
        ~ChatProductItemViewModel()
        {
            Dispose(false);
        }

        public void SetChatIceMap(ChatIceMap value) => _chatIceMap = value;
        public ChatIceMap ChatIceMap() => _chatIceMap;

        public DelegateCommand DeleteCommand { get; set; }
        public DelegateCommand UndoDeleteCommand { get; set; }

        public string PriceCurveName
        {
            get => _priceCurveName;
            set
            {
                _priceCurveName = value;
                RaisePropertyChanged();
            }
        }

        public string PriceCurveDescription
        {
            get => _priceCurveDescription;
            set
            {
                _priceCurveDescription = value;
                RaisePropertyChanged();
            }
        }

        public PriceCurveDefinitionItem PriceCurveDefinition
        {
            get => _priceCurveDefinition;
            set
            {
                _priceCurveDefinition = value;
                RaisePropertyChanged();
            }
        }

        public ChatMarketItem ChatMarket
        {
            get => _chatMarket;
            set
            {
                _chatMarket = value;
                RaisePropertyChanged();
            }
        }

        public IList<object> Shortcuts
        {
            get => _shortcuts;
            set
            {
                if (_shortcuts != null && _shortcuts.SequenceEqual(value))
                {
                    return;
                }

                _shortcuts = value;
                RaisePropertyChanged();
            }
        }

        public bool IsDuplicateShortcut
        {
            get => _isDuplicateShortcut;
            set
            {
                _isDuplicateShortcut = value;
                RaisePropertyChanged();
            }
        }

        public bool IsDeletedWithExistingMapping
        {
            get => _isDeletedWithExistingMapping;
            set
            {
                _isDeletedWithExistingMapping = value;
                RaisePropertyChanged();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller?.Dispose();
            }

            _disposed = true;
        }
    }
}
