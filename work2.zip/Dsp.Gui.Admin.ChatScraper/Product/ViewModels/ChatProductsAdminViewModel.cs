﻿
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Product.ViewModels
{
    public class ChatProductsAdminViewModel : BindableBase, IEditableItemCollectionDialog
    {
        private ObservableCollection<ChatProductItemViewModel> _chatProductItems;
        private IEditableItem _selectedItem;
        private List<PriceCurveDefinitionItem> _priceCurveDefinitionItems;
        private IList<ChatMarketItem> _chatMarketItems;
        private bool _canFilterRows;
        private string _searchText;
        private bool _isBusy;
        private string _busyText;

        public DelegateCommand AddProductItemCommand { get; set; }

        public ObservableCollection<ChatProductItemViewModel> ChatProductItems
        {
            get => _chatProductItems;
            set
            {
                _chatProductItems = value;
                RaisePropertyChanged();
            }
        }

        public IEditableItem SelectedItem
        {
            get => _selectedItem;
            set
            {
                _selectedItem = value;
                RaisePropertyChanged();
            }
        }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        public string BusyText
        {
            get => _busyText;
            set
            {
                _busyText = value;
                RaisePropertyChanged();
            }
        }

        public List<PriceCurveDefinitionItem> PriceCurveDefinitionItems
        {
            get => _priceCurveDefinitionItems;
            set
            {
                _priceCurveDefinitionItems = value;
                RaisePropertyChanged();
            }
        }

        public IList<ChatMarketItem> ChatMarketItems
        {
            get => _chatMarketItems;
            set
            {
                _chatMarketItems = value;
                RaisePropertyChanged();
            }
        }

        public bool CanFilterRows
        {
            get => _canFilterRows;
            set
            {
                _canFilterRows = value;
                RaisePropertyChanged();
            }
        }

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                RaisePropertyChanged();
            }
        }
    }
}
