﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Product.Controllers;

namespace Dsp.Gui.Admin.ChatScraper.Product.Views
{
    /// <summary>
    /// Interaction logic for ChatScraperProductAdminView.xaml
    /// </summary>
    [ExcludeFromCodeCoverage]
    public partial class ChatScraperProductAdminView
    {
        public ChatScraperProductAdminView(IChatProductsAdminViewModelController controller)
        {
            DataContext = controller.ViewModel;
            InitializeComponent();
        }
    }
}
