﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Product.Views
{
    /// <summary>
    /// Interaction logic for ChatScraperProductAdminControl.xaml
    /// </summary>
    [ExcludeFromCodeCoverage]
    public partial class ChatScraperProductAdminControl
    {
        public ChatScraperProductAdminControl()
        {
            InitializeComponent();
        }
    }
}
