﻿using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    public interface IChatProductDuplicateItemsService : IDuplicateItemsService<ChatProductItemViewModel>
    {
    }
}
