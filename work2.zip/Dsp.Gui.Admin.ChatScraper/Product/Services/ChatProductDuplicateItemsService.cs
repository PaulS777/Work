﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    internal sealed class ChatProductDuplicateItemsService : DuplicateItemsService<ChatProductItemViewModel, PriceCurveDefinitionItem>, 
                                                             IChatProductDuplicateItemsService
    {
        public ChatProductDuplicateItemsService()
            : base(item => item.PriceCurveDefinition,
                   item => item.PriceCurveDefinition,
                   item => item.PriceCurveDefinition != null)
        {
        }

        [ExcludeFromCodeCoverage]
        ~ChatProductDuplicateItemsService()
        {
            Dispose(false);
        }
    }
}
