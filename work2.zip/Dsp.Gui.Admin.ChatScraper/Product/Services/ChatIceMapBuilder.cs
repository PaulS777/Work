﻿using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    internal class ChatIceMapBuilder : IChatIceMapBuilder
    {
        public ChatIceMap GetNewChatIceMap(ChatProductItemViewModel item)
        {
            return GetChatIceMap(item, 0);
        }

        public ChatIceMap GetUpdatedChatIceMap(ChatProductItemViewModel item)
        {
            return GetChatIceMap(item, item.Id);
        }

        public ChatIceMap GetDeletedChatIceMap(ChatProductItemViewModel item)
        {
            var iceChatMap = new ChatIceMap(item.Id,
                                            EntityStatus.Deleted,
                                            item.ChatIceMap().PriceCurveName,
                                            item.ChatIceMap().ChatMarketId,
                                            item.ChatIceMap().PriceCurveDefinitionId,
                                            item.ChatIceMap().Shortcuts);
            return iceChatMap;
        }

        private static ChatIceMap GetChatIceMap(ChatProductItemViewModel viewModel,
                                                int id)
        {
            var shortcuts = viewModel.Shortcuts != null ? string.Join(";", viewModel.Shortcuts.ToArray()) : null;

            var iceChatMap = new ChatIceMap(id,
                                            EntityStatus.Active,
                                            viewModel.PriceCurveDefinition.Name,
                                            viewModel.ChatMarket.Model().Id,
                                            viewModel.PriceCurveDefinition.Id,
                                            shortcuts);
            return iceChatMap;
        }
    }
}
