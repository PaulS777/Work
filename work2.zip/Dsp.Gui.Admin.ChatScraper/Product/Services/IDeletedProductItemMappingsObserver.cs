﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    public interface IDeletedProductItemMappingsObserver : IDisposable
    {
        IObservable<bool> HasDeletedWithExistingMappings { get; }
        void RefreshItems(IEnumerable<ChatProductItemViewModel> items);
        void AddItem(ChatProductItemViewModel item);
    }
}
