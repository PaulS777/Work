﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.Controllers;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    internal class ChatProductItemViewModelBuilder : IChatProductItemViewModelBuilder
    {
        [Inject]
        public IServiceFactory<IChatProductItemViewModelController> Factory { get; set; }

        public ChatProductItemViewModel CreateNewItem()
        {
            var controller = Factory.Create();

            var viewModel = controller.ViewModel;

            viewModel.NewRecord = true;

            return viewModel;
        }

        public ChatProductItemViewModel CreateItemFromChatIceMap(ChatIceMap chatIceMap, 
                                                                 IList<PriceCurveDefinitionItem> priceCurveDefinitions, 
                                                                 IList<ChatMarketItem> chatMarkets)
        {
            var controller = Factory.Create();

            var viewModel = controller.ViewModel;

            UpdateRowFromChatIceMapImpl(viewModel,
                                        chatIceMap,
                                        priceCurveDefinitions,
                                        chatMarkets);

            return viewModel;
        }

        public void UpdateItemFromChatIceMap(ChatProductItemViewModel viewModel, 
                                             ChatIceMap chatIceMap, 
                                             IList<PriceCurveDefinitionItem> priceCurveDefinitions,
                                             IList<ChatMarketItem> chatMarkets)
        {
            using (new UpdateGuardSection(value => viewModel.SubscribeUpdates = value, true))
            {
                UpdateRowFromChatIceMapImpl(viewModel, 
                                            chatIceMap, 
                                            priceCurveDefinitions, 
                                            chatMarkets);
            }
        }

        private static void UpdateRowFromChatIceMapImpl(ChatProductItemViewModel viewModel, 
                                                        ChatIceMap chatIceMap, 
                                                        IEnumerable<PriceCurveDefinitionItem> priceCurveDefinitions, 
                                                        IEnumerable<ChatMarketItem> chatMarkets)
        {
            viewModel.SetChatIceMap(chatIceMap);

            viewModel.Id = chatIceMap.Id;
            viewModel.NewRecord = false;

            if (chatIceMap.PriceCurveDefinitionId != null && chatIceMap.PriceCurveDefinitionId != 0)
            {
                viewModel.PriceCurveDefinition = priceCurveDefinitions.FirstOrDefault(p => p.Id == chatIceMap.PriceCurveDefinitionId);
            }

            if (chatIceMap.ChatMarketId != 0)
            {
                viewModel.ChatMarket = chatMarkets.FirstOrDefault(m => m.Id == chatIceMap.ChatMarketId);
            }

            if (chatIceMap.Shortcuts != null)
            {
                viewModel.Shortcuts = !string.IsNullOrEmpty(chatIceMap.Shortcuts)
                    ? chatIceMap.Shortcuts.Split(';').Cast<object>().ToList()
                    : new List<object>();
            }
        }
    }
}
