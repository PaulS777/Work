﻿using System.Collections.Generic;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    public interface IChatProductItemFilterService
    {
        IEnumerable<ChatProductItemViewModel> RefreshItems(IList<ChatProductItemViewModel> items,
                                                           string searchText);

        IEnumerable<ChatProductItemViewModel> FilterItems(string searchText);
    }
}
