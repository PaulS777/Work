﻿using System.Collections.Generic;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    public interface IChatProductItemViewModelBuilder
    {
        ChatProductItemViewModel CreateNewItem();

        ChatProductItemViewModel CreateItemFromChatIceMap(ChatIceMap chatIceMap, 
                                                          IList<PriceCurveDefinitionItem> priceCurveDefinitions, 
                                                          IList<ChatMarketItem> chatMarkets);

        void UpdateItemFromChatIceMap(ChatProductItemViewModel viewModel, 
                                      ChatIceMap chatIceMap,
                                      IList<PriceCurveDefinitionItem> priceCurveDefinitions,
                                      IList<ChatMarketItem> chatMarkets);
    }
}
