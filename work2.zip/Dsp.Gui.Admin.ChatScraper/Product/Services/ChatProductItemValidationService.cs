﻿using Dsp.Gui.Admin.ChatScraper.Product.Rules;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    internal class ChatProductItemValidationService : EditableItemValidationService<ChatProductItemViewModel>
                                                      ,IChatProductItemValidationService
    {
        public ChatProductItemValidationService(IChatProductItemPriceCurveDefinitionRule priceCurveDefinitionRule,
                                                IChatProductItemMarketRule marketRule,
                                                IChatProductItemShortcutRule shortcutRule)
        :base(priceCurveDefinitionRule,
              marketRule,
              shortcutRule)
        {
            
        }

        public override string IsDuplicateText() => "Duplicate Price Curve Mapping";
    }
}
