﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    internal class ChatProductItemFilterService : IChatProductItemFilterService
    {
        private IEnumerable<ChatProductItemViewModel> _unfilteredItems;

        public IEnumerable<ChatProductItemViewModel> RefreshItems(IList<ChatProductItemViewModel> items,
                                                                  string searchText)
        {
            if (items != null)
            {
                _unfilteredItems = items.OrderBy(i => i.PriceCurveName).ToList();
            }

            return FilterItems(searchText);
        }

        public IEnumerable<ChatProductItemViewModel> FilterItems(string searchText)
        {
            if (_unfilteredItems == null)
            {
                return new List<ChatProductItemViewModel>();
            }

            var filterItems = _unfilteredItems;

            if (string.IsNullOrEmpty(searchText))
            {
                return filterItems;
            }

            var searchTextRows = filterItems.Where(r => r.PriceCurveName != null
                                                        && r.PriceCurveName.Contains(searchText, StringComparison.CurrentCultureIgnoreCase)
                                                        || (r.PriceCurveDescription !=null 
                                                            && r.PriceCurveDescription.Contains(searchText, StringComparison.CurrentCultureIgnoreCase)));

            return searchTextRows;
        }
    }
}
