﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    public interface IChatIceMapBuilder
    {
        ChatIceMap GetNewChatIceMap(ChatProductItemViewModel item);
        ChatIceMap GetUpdatedChatIceMap(ChatProductItemViewModel item);
        ChatIceMap GetDeletedChatIceMap(ChatProductItemViewModel item);
    }
}
