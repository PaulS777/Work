﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    internal sealed class DeletedProductItemMappingsObserver : IDeletedProductItemMappingsObserver
    {
        private readonly BehaviorSubject<bool> _hasDeletedWithExistingMappings = new(false);
        private CompositeDisposable _disposables;
        private IList<ChatProductItemViewModel> _items;
        private bool _disposed;

        public IObservable<bool> HasDeletedWithExistingMappings => _hasDeletedWithExistingMappings.AsObservable();

        [ExcludeFromCodeCoverage]
        ~DeletedProductItemMappingsObserver()
        {
            Dispose(false);
        }

        public void RefreshItems(IEnumerable<ChatProductItemViewModel> items)
        {
            _disposables?.Dispose();
            _disposables = new CompositeDisposable();

            _items = items.ToList();

            foreach (var item in _items)
            {
                item.ObservePropertiesChanged(vm => vm.IsDeletedWithExistingMapping)
                    .Subscribe(_ => CalculateHasDeletedWithExistingMappings())
                    .AddTo(_disposables);
            }
        }

        public void AddItem(ChatProductItemViewModel item)
        {
            _items.Add(item);

            item.ObservePropertiesChanged(vm => vm.IsDeletedWithExistingMapping)
                .Subscribe(_ => CalculateHasDeletedWithExistingMappings())
                .AddTo(_disposables);
        }

        private void CalculateHasDeletedWithExistingMappings()
        {
            var value = _items.Any(r => r.IsDeletedWithExistingMapping);

            _hasDeletedWithExistingMappings.OnNext(value);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables?.Dispose();
            }

            _disposed = true;
        }
    }
}
