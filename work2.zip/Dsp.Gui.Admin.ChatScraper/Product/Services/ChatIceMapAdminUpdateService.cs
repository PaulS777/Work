﻿using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Services;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    [ExcludeFromCodeCoverage]
    internal class ChatIceMapAdminUpdateService : BrokerAdminUpdateService<ChatProductItemViewModel, ChatIceMap>,
                                                  IChatIceMapAdminUpdateService
    {
        public ChatIceMapAdminUpdateService(IChatScraperAdminUpdateService chatScraperAdminUpdateService) 
            : base(chatScraperAdminUpdateService)
        {
        }
    }
}
