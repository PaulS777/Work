﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Services;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    public interface IChatIceMapAdminUpdateService : IBrokerAdminUpdateService<ChatProductItemViewModel, ChatIceMap>
    {
    }
}
