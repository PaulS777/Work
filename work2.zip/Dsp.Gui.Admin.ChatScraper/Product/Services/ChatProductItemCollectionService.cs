﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Product.Services
{
    [ExcludeFromCodeCoverage]
    internal sealed class ChatProductItemCollectionService : EditableItemCollectionService<ChatProductItemViewModel>, 
                                                             IChatProductItemCollectionService
    {
        public ChatProductItemCollectionService(IChatProductDuplicateItemsService duplicateItemsService) 
        : base(duplicateItemsService)
        {
        }

        ~ChatProductItemCollectionService()
        {
            Dispose(false);
        }
    }
}
