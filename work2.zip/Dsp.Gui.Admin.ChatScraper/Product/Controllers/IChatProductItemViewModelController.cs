﻿using System;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Product.Controllers
{
    public interface IChatProductItemViewModelController : IDisposable
    {
        ChatProductItemViewModel ViewModel { get; }
    }
}
