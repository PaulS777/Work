﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Product.Controllers
{
    internal sealed class ChatProductItemViewModelController : IChatProductItemViewModelController
    {
        private readonly ICurveControlService _curveControlService;
        private readonly IChatProductItemValidationService _validationService;
        private readonly CompositeDisposable _disposables = new();
        private CompositeDisposable _onSubscribedDisposable;
        private bool _canDelete;
        private bool _disposed;

        public ChatProductItemViewModelController(ICurveControlService curveControlService,
                                                  IChatProductItemValidationService validationService)
        {
            _curveControlService = curveControlService;
            _validationService = validationService;

            ViewModel = new ChatProductItemViewModel(this);

            ViewModel.DeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = true, () => _canDelete);
            ViewModel.UndoDeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = false);

            ViewModel.ObservePropertyChanged(vm => vm.SubscribeUpdates)
                     .Where(vm => vm.SubscribeUpdates)
                     .Subscribe(_ => SubscribeUpdates())
                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.SubscribeUpdates)
                     .Where(vm => !vm.SubscribeUpdates)
                     .Subscribe(_ => UnSubscribeUpdates())
                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.PriceCurveDefinition)
                     .Subscribe(_ => UpdatePriceCurveDetails())
                     .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatProductItemViewModelController()
        {
            Dispose(false);
        }

        public ChatProductItemViewModel ViewModel { get; }

        private void SubscribeUpdates()
        {
            _onSubscribedDisposable = new CompositeDisposable();

            _validationService.Attach(ViewModel);

            ViewModel.ObservePropertyChanged(vm => vm.PriceCurveDefinition)
                     .Where(vm => !vm.NewRecord && vm.ChatIceMap() != null)
                     .Subscribe(_ => CalculateIsDirty())
                     .AddTo(_onSubscribedDisposable);

            ViewModel.ObservePropertyChanged(vm => vm.ChatMarket)
                     .Where(vm => !vm.NewRecord && vm.ChatIceMap() != null)
                     .Subscribe(_ => CalculateIsDirty())
                     .AddTo(_onSubscribedDisposable);

            ViewModel.ObservePropertyChanged(vm => vm.Shortcuts)
                     .Where(vm => !vm.NewRecord && vm.ChatIceMap() != null)
                     .Subscribe(_ => CalculateIsDirty())
                     .AddTo(_onSubscribedDisposable);

            ViewModel.ObservePropertyChanged(vm => vm.IsDeleted)
                     .Where(_ => !ViewModel.IsDeleted && ViewModel.IsDeletedWithExistingMapping)
                     .Subscribe(_ => ViewModel.IsDeletedWithExistingMapping = false)
                     .AddTo(_onSubscribedDisposable);

            if (!ViewModel.NewRecord)
            {
                _curveControlService.ChatVariableShortcuts
                                    .Where(cs => cs != null)
                                    .Subscribe(CalculateCanDelete)
                                    .AddTo(_onSubscribedDisposable);
            }

            CalculateIsDirty();
        }

        private void CalculateCanDelete(IEnumerable<ChatVariableShortcut> shortcuts)
        {
            _canDelete = !CheckExistingPriceCurveMappings(shortcuts);

            ViewModel.DeleteCommand.RaiseCanExecuteChanged();
        }

        private bool CheckExistingPriceCurveMappings(IEnumerable<ChatVariableShortcut> shortcuts)
        {
            return shortcuts.Any(s => s.Status == EntityStatus.Active 
                                      && s.ChatVariableShortcutVariations.Exists(v => v.PriceCurveName == ViewModel.PriceCurveName));
        }

        private void UnSubscribeUpdates()
        {
            _onSubscribedDisposable?.Dispose();
        }

        private void UpdatePriceCurveDetails()
        {
            ViewModel.PriceCurveName = ViewModel.PriceCurveDefinition?.Name;
            ViewModel.PriceCurveDescription = ViewModel.PriceCurveDefinition?.Model().Description;
        }

        private void CalculateIsDirty()
        {
            if (ViewModel.NewRecord || ViewModel.ChatIceMap() == null)
            {
                ViewModel.IsDirty = true;
                return;
            }

            if (!ComparePriceCurves(ViewModel.PriceCurveDefinition, ViewModel.ChatIceMap().PriceCurveDefinitionId))
            {
                ViewModel.IsDirty = true;
                return;
            }

            if (!CompareChatMarkets(ViewModel.ChatMarket, ViewModel.ChatIceMap().ChatMarketId))
            {
                ViewModel.IsDirty = true;
                return;
            }

            ViewModel.IsDirty = !CompareShortcuts(ViewModel.Shortcuts,
                                                  ViewModel.ChatIceMap()?.Shortcuts);
        }

        private static bool ComparePriceCurves(PriceCurveDefinitionItem item, int? curveId)
        {
            var iceMapCurveIdValue = curveId ?? 0;

            return item switch
                   {
                       null when iceMapCurveIdValue == 0 => true,
                       null => false,
                       _ => item.Id == iceMapCurveIdValue
                   };
        }

        private static bool CompareChatMarkets(ChatMarketItem item, int chatMarketId)
        {
            if (item == null && chatMarketId == 0)
            {
                return true;
            }

            if (item == null || chatMarketId == 0)
            {
                return false;
            }

            return item.Id == chatMarketId;
        }

        private static bool CompareShortcuts(IEnumerable items,
                                             string shortcuts)
        {
            var itemTags = items != null
                ? items.Cast<string>()
                       .ToList()
                : new List<string>();

            var shortcutsArray = !string.IsNullOrEmpty(shortcuts) ? shortcuts.Split(';').ToList() : new List<string>();

            var diffs = itemTags.Except(shortcutsArray).Any() || shortcutsArray.Except(itemTags).Any();

            return !diffs;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _onSubscribedDisposable?.Dispose();
                _validationService.Dispose();
            }

            _disposed = true;
        }
    }
}
