﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.ServiceContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.Gui.Dashboard.Common.ViewModels.EntityItems;
using Microsoft.Extensions.DependencyInjection;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Product.Controllers
{
    internal sealed class ChatProductsAdminViewModelController : IChatProductsAdminViewModelController
    {
        private readonly ICurveControlService _curveControlService;
        private readonly CompositeDisposable _disposables = new();
        private readonly IChatProductItemCollectionService _itemCollectionService;
        private readonly IChatProductItemViewModelBuilder _iceProductMappingRowViewModelBuilder;
        private readonly IChatProductItemCollectionProvider _itemCollectionProvider;
        private readonly IChatProductItemFilterService _filterService;
        private readonly IChatVariableShortcutDuplicateShortcutsService _duplicateShortcutsService;
        private readonly IDeletedProductItemMappingsObserver _deletedProductItemMappingsObserver;
        private readonly IChatScraperProductAdminToolBarService _toolBarService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly ILogger _log;
        private readonly BehaviorSubject<bool> _priceCurvesAndMarketsLoaded = new(false);

        private CompositeDisposable _rowFilterDisposables;
        private bool _disposed;

        public ChatProductsAdminViewModelController(ICurveControlService curveControlService,
                                                    IChatProductItemViewModelBuilder iceProductMappingRowViewModelBuilder, 
                                                    IChatProductItemCollectionProvider itemCollectionProvider,
                                                    IChatProductItemCollectionService itemCollectionService,
                                                    IChatProductItemFilterService filterService,
                                                    IChatVariableShortcutDuplicateShortcutsService duplicateShortcutsService,
                                                    IDeletedProductItemMappingsObserver deletedProductItemMappingsObserver,
                                                    IChatScraperProductAdminToolBarService toolBarService,
                                                    ISchedulerProvider schedulerProvider,
                                                    ILoggerFactory loggerFactory)
        {
            _curveControlService = curveControlService;
            _itemCollectionService = itemCollectionService;
            _iceProductMappingRowViewModelBuilder = iceProductMappingRowViewModelBuilder;
            _itemCollectionProvider = itemCollectionProvider;
            _filterService = filterService;
            _duplicateShortcutsService = duplicateShortcutsService;
            _deletedProductItemMappingsObserver = deletedProductItemMappingsObserver;
            _toolBarService = toolBarService;
            _schedulerProvider = schedulerProvider;

            _log = loggerFactory.Create(GetType().Name);

            ViewModel.AddProductItemCommand = new DelegateCommand(OnAddProductItemCommand);

            _toolBarService.Update
                           .Subscribe(_ => OnUpdateChatProductCommand())
                           .AddTo(_disposables);

            _toolBarService.Undo
                           .Subscribe(_ => OnUndoChatProductCommand())
                           .AddTo(_disposables);

            ViewModel.CanFilterRows = true;

            ViewModel.ObservePropertyChanged(vm => vm.SearchText)
                     .Subscribe(_ => FilterRows())
                     .AddTo(_disposables);

            ViewModel.ChatProductItems = new ObservableCollection<ChatProductItemViewModel>();

            _itemCollectionService.CanExecuteUpdateCommand
                                  .CombineLatest(_deletedProductItemMappingsObserver.HasDeletedWithExistingMappings, (r,d) => r && !d)
                                  .Subscribe(OnCanExecuteUpdateCommand)
                                  .AddTo(_disposables);

            _itemCollectionService.CanExecuteUndoCommand
                                  .Subscribe(OnCanExecuteUndoCommand)
                                  .AddTo(_disposables);

            _itemCollectionService.ValidationErrors
                                  .Subscribe(OnValidationErrors)
                                  .AddTo(_disposables);

            var iceMaps = _curveControlService.ChatIceMaps
                                              .Where(d => d != null);

            var priceCurveDefinitions = _curveControlService.PriceCurveDefinitions
                                                            .Where(d => d != null)
                                                            .Take(1);

            var chatMarketsLoaded = _curveControlService.ChatMarkets
                                                        .Where(m => m != null)
                                                        .Take(1);

            priceCurveDefinitions.CombineLatest(chatMarketsLoaded, 
                                                (pc, cm) => new
                                                {
                                                    PriceCurves = pc, ChatMarkets = cm
                                                })
                                 .ObserveOn(_schedulerProvider.Dispatcher)
                                 .Subscribe(d => OnPriceCurvesAndChatMarketsLoaded(d.PriceCurves, d.ChatMarkets))
                                 .AddTo(_disposables);

            var priceCurvesAndMarketsLoaded = _priceCurvesAndMarketsLoaded.Where(r => r)
                                                                          .Take(1);

            iceMaps.CombineLatest(priceCurvesAndMarketsLoaded, (im, _) => im)
                   .ObserveOn(_schedulerProvider.Dispatcher)
                   .Subscribe(UpdateRowItems)
                   .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatProductsAdminViewModelController()
        {
            Dispose(false);
        }

        public ChatProductsAdminViewModel ViewModel { get; set; } = new();

        [Inject]
        public IErrorMessageDialogService ErrorMessageDialogService { get; set; }

        [Inject]
        public IPopupNotificationService PopupNotificationService { get; set; }

        [Inject]
        public IChatIceMapBuilder ChatIceMapBuilder { get; set; }

        [Inject]
        public IChatIceMapAdminUpdateService ChatIceMapAdminUpdateService { get; set; }

        private void OnPriceCurvesAndChatMarketsLoaded(IEnumerable<PriceCurveDefinition> priceCurveDefinitions, 
                                                       IEnumerable<ChatMarket> chatMarkets)
        {
            if (ViewModel.PriceCurveDefinitionItems == null)
            {
                ViewModel.PriceCurveDefinitionItems = priceCurveDefinitions.OrderBy(d => d.Name)
                                                                           .Select(d => new PriceCurveDefinitionItem(d))
                                                                           .ToList();
            }

            ViewModel.ChatMarketItems = chatMarkets.OrderBy(m => m.Market)
                                                   .Select(m => new ChatMarketItem(m))
                                                   .ToList();

            _priceCurvesAndMarketsLoaded.OnNext(true);
        }

        private void OnCanExecuteUpdateCommand(bool value)
        {
            _toolBarService.SetCanUpdate(value);
        }

        private void OnCanExecuteUndoCommand(bool value)
        {
            _toolBarService.SetCanUndo(value);
        }

        private void OnValidationErrors(IList<string> validationErrors)
        {
            if (validationErrors.Count == 0)
            {
                _toolBarService.ClearValidation();
            }
            else
            {
                _toolBarService.SetValidationErrors(validationErrors);
            }
        }

        private void OnAddProductItemCommand()
        {
            var iceMapRow = _iceProductMappingRowViewModelBuilder.CreateNewItem();

            _itemCollectionService.AddNewItem(iceMapRow, ViewModel.ChatProductItems, ViewModel);
            _duplicateShortcutsService.AddItem(iceMapRow);
            _deletedProductItemMappingsObserver.AddItem(iceMapRow);

            iceMapRow.SubscribeUpdates = true;
        }

        private void UpdateRowItems(IList<ChatIceMap> chatIceMaps)
        {
            _log.Info("Chat Ice Maps Loaded.");

            var conflicts = GetConflicts(ViewModel.ChatProductItems,
                                         chatIceMaps);

            RefreshItems(chatIceMaps);

            if (!conflicts.Any())
            {
                return;
            }

            ShowConflicts(conflicts);
        }

        private void RefreshItems(IList<ChatIceMap> chatIceMaps)
        {
            var items
                = _itemCollectionProvider.GetCollection(ViewModel.ChatProductItems, 
                                                        chatIceMaps, 
                                                        (item, ice) => item.PriceCurveDefinition?.Id == ice.PriceCurveDefinitionId, 
                                                        UpdateItemFromChatIceMap, 
                                                        CreateItemFromChatIceMap);

            SubscribeUpdates(items);
            RefreshFilterItems(items);

            _itemCollectionService.RefreshItems(items);
            _duplicateShortcutsService.RefreshItems(items);
            _deletedProductItemMappingsObserver.RefreshItems(items);

            RegisterCanFilterItems(items);
        }

        private void UpdateItemFromChatIceMap(ChatProductItemViewModel item, ChatIceMap chatIceMap)
        {
            _iceProductMappingRowViewModelBuilder.UpdateItemFromChatIceMap(item,
                                                                           chatIceMap,
                                                                           ViewModel.PriceCurveDefinitionItems,
                                                                           ViewModel.ChatMarketItems);
        }

        private ChatProductItemViewModel CreateItemFromChatIceMap(ChatIceMap chatIceMap)
        {
            return _iceProductMappingRowViewModelBuilder.CreateItemFromChatIceMap(chatIceMap,
                                                                                  ViewModel.PriceCurveDefinitionItems,
                                                                                  ViewModel.ChatMarketItems);
        }

        private void OnUndoChatProductCommand()
        {
            var chatIceMaps = _curveControlService.GetChatIceMapSnapshot()
                                                  .ToList();

            var items = _itemCollectionProvider.GetCollectionReset(chatIceMaps, 
                                                                   CreateItemFromChatIceMap);

            SubscribeUpdates(items);
            RefreshFilterItems(items);

            _itemCollectionService.RefreshItems(items);
            _duplicateShortcutsService.RefreshItems(items);
            _deletedProductItemMappingsObserver.RefreshItems(items);

            RegisterCanFilterItems(items);
        }

        private static IList<ChatProductItemViewModel> GetConflicts(IEnumerable<ChatProductItemViewModel> items, 
                                                                    IEnumerable<ChatIceMap> models)
        {
            var userIds = models.Select(u => u.Id).ToList();

            var conflicts = items.Where(r => r.IsInEdit && userIds.Contains(r.Id))
                                 .ToList();
            return conflicts;
        }

        private void ShowConflicts(IEnumerable<ChatProductItemViewModel> items)
        {
            var conflicts = items.Select(c => c.PriceCurveDefinition?.Name);

            var messages = new List<string> { "The following updates have overwritten your changes due to conflicts :", "" };
            messages.AddRange(conflicts);

            var args = new ErrorMessageDialogArgs("Update Conflict", messages, false);

            ErrorMessageDialogService.ShowDialog(args);
        }

        private void FilterRows()
        {
            var filterItems = _filterService.FilterItems(ViewModel.SearchText);

            ViewModel.ChatProductItems = new ObservableCollection<ChatProductItemViewModel>(filterItems);
        }

        private static void SubscribeUpdates(IEnumerable<ChatProductItemViewModel> items)
        {
            foreach (var item in items)
            {
                item.SubscribeUpdates = true;
            }
        }

        private void RefreshFilterItems(IList<ChatProductItemViewModel> items)
        {
            var filterItems = _filterService.RefreshItems(items, ViewModel.SearchText);

            ViewModel.ChatProductItems = new ObservableCollection<ChatProductItemViewModel>(filterItems);
        }

        private void RegisterCanFilterItems(IList<ChatProductItemViewModel> items)
        {
            _rowFilterDisposables?.Dispose();

            _rowFilterDisposables = new CompositeDisposable();

            foreach (var item in items)
            {
                item.ObservePropertyChanged(vm => vm.IsDirty)
                    .Select(_ => items.Any(vm => vm.IsDirty))
                    .DistinctUntilChanged()
                    .Subscribe(hasChanges => ViewModel.CanFilterRows = !hasChanges)
                    .AddTo(_rowFilterDisposables);
            }
        }

        private void OnUpdateChatProductCommand()
        {
            ViewModel.IsBusy = true;
            ViewModel.BusyText = "Updating ICE Chat Products";

            if (!CheckDeletedRowsWithMappedProducts())
            {
                var args = new ErrorMessageDialogArgs("Chat Product Validation Failed",
                                                      new[] 
                                                      { 
                                                          "Some Product Shortcut Mappings have been","added outside this session.", 
                                                          "",
                                                          "Please undo deleted mappings."
                                                      }, 
                                                      false);

                ViewModel.IsBusy = false;
                ViewModel.BusyText = null;

                ErrorMessageDialogService.ShowDialog(args);

                return;
            }

            var response = 
                ChatIceMapAdminUpdateService.Update(ViewModel.ChatProductItems, 
                                                    _schedulerProvider.Dispatcher, 
                                                    ChatIceMapBuilder.GetNewChatIceMap, 
                                                    ChatIceMapBuilder.GetUpdatedChatIceMap, 
                                                    ChatIceMapBuilder.GetDeletedChatIceMap);

            response.ObserveOn(_schedulerProvider.Dispatcher)
                    .Subscribe(_ => OnUpdateComplete(), 
                               OnError)
                    .AddTo(_disposables);
        }

        private bool CheckDeletedRowsWithMappedProducts()
        {
            var deletedItems = ViewModel.ChatProductItems.Where(r => r.IsDeleted).ToList();

            if (deletedItems.Count == 0)
            {
                return true;
            }

            var shortcuts = _curveControlService.GetChatVariableShortcutSnapshot().ToList();

            deletedItems.ForEach(item =>
            {
                if (shortcuts.Exists(s => s.ChatVariableShortcutVariations.Exists(v => v.PriceCurveName == item.PriceCurveName)))
                {
                    item.IsDeletedWithExistingMapping = true;
                }
            });

            return deletedItems.TrueForAll(r => !r.IsDeletedWithExistingMapping);
        }

        private void OnUpdateComplete()
        {
            _log.Info("ChatIceMap Update completed !");

            PopupNotificationService.SendPopupNotification("ICE Chat Mappings Updated");

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;
        }

        private void OnError(Exception ex)
        {
            _log.Error("Update failed !" + ex.Message);

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;

            var args = new ErrorMessageDialogArgs("Chat Product Mapping Update Failed", ex.Message, true);

            ErrorMessageDialogService.ShowDialog(args);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _itemCollectionService.Dispose();
                _duplicateShortcutsService.Dispose();
                _deletedProductItemMappingsObserver.Dispose();
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
