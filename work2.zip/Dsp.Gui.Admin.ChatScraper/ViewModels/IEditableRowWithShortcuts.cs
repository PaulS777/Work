﻿using System.Collections.Generic;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.ViewModels
{
    public interface IEditableItemWithShortcuts : IEditableItem
    {
        IList<object> Shortcuts { get; set; }
        bool IsDuplicateShortcut { get; set; }
    }
}
