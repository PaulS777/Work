﻿using System.Collections.Generic;
using Prism.Mvvm;
using Prism.Commands;
namespace Dsp.Gui.Admin.ChatScraper.ViewModels
{
    public class MessageDialogViewModel : BindableBase
    {
        private string _headerText;
        private IList<string> _dialogMessages;
        private string _dialogMessage;
        private bool _showDialog;

        public DelegateCommand DialogOkCommand { get; set; }

        public DelegateCommand CompletedDialogOkCommand { get; set; }

        public string HeaderText
        {
            get => _headerText;
            set
            {
                _headerText = value;
                RaisePropertyChanged();
            }
        }

        public IList<string> DialogMessages
        {
            get => _dialogMessages;
            set
            {
                _dialogMessages = value;
                RaisePropertyChanged();
            }
        }

        public string DialogMessage
        {
            get => _dialogMessage;
            set
            {
                _dialogMessage = value;
                RaisePropertyChanged();
            }
        }

        public bool ShowDialog
        {
            get => _showDialog;
            set
            {
                _showDialog = value;
                RaisePropertyChanged();
            }
        }
    }
}
