﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Views
{
    /// <summary>
    /// Interaction logic for UserAdminCompletedDialog.xaml
    /// </summary>
    ///
    [ExcludeFromCodeCoverage]
    public partial class UserAdminCompletedDialog
    {
        public UserAdminCompletedDialog()
        {
            InitializeComponent();
        }
    }
}
