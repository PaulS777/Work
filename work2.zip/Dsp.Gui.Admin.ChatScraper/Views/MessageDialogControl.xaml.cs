﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Views
{
    /// <summary>
    /// Interaction logic for MessageDialogControl.xaml
    /// </summary>
    [ExcludeFromCodeCoverage]
    public partial class MessageDialogControl
    {
        public MessageDialogControl()
        {
            InitializeComponent();
        }
    }
}
