﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Market.Controllers;

namespace Dsp.Gui.Admin.ChatScraper.Market.Views
{
    [ExcludeFromCodeCoverage]
    public partial class ChatBrokerMarketsAdminView 
    {
        public ChatBrokerMarketsAdminView(IChatBrokerMarketsAdminViewModelController controller)
        {
            DataContext = controller.ViewModel;
            InitializeComponent();
        }
    }
}
