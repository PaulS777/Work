﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Market.Views
{
    [ExcludeFromCodeCoverage]
    public partial class ChatBrokerMarketsAdminControl
    {
        public ChatBrokerMarketsAdminControl()
        {
            InitializeComponent();
        }
    }
}
