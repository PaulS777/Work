﻿using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Market.Rules
{
    public interface IChatMarketNameRule : IValidationRule<ChatMarketItemViewModel>
    {
    }
}
