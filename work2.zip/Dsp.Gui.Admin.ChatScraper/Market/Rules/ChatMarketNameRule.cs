﻿using System;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Market.Rules
{
    internal class ChatMarketNameRule : IChatMarketNameRule
    {
        public IObservable<ChatMarketItemViewModel> ObservePropertyChanged(ChatMarketItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => vm.Name);
        }

        public string Validate(ChatMarketItemViewModel viewModel)
        {
            return string.IsNullOrEmpty(viewModel.Name) ? "Missing Market" : string.Empty;
        }
    }
}
