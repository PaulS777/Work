﻿using System;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Market.Controllers
{
    public interface IChatBrokerMarketsAdminViewModelController : IDisposable
    {
        ChatBrokerMarketsAdminViewModel ViewModel { get; }
    }
}
