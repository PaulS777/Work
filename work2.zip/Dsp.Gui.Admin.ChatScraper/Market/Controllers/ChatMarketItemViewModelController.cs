﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Common.Extensions;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Market.Controllers
{
    internal sealed class ChatMarketItemViewModelController : IChatMarketItemViewModelController
    {
        private readonly IChatMarketItemValidationService _validationService;
        private readonly CompositeDisposable _disposables = new();

        private bool _canDelete;
        private bool _disposed;

        public ChatMarketItemViewModelController(IChatMarketDependencyService chatMarketDependencyService,
                                                 IChatMarketItemValidationService validationService)
        {
            _validationService = validationService;

            ViewModel = new ChatMarketItemViewModel(this);

            ViewModel.DeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = true, () => _canDelete);
            ViewModel.UndoDeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = false);

            _validationService.Attach(ViewModel);

            ViewModel.ObservePropertyChanged(vm => vm.Id)
                     .Select(vm => chatMarketDependencyService.HasDependents(vm.Id))
                     .Switch()
                     .Subscribe(value => UpdateCanDelete(!value))
                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.Name)
                     .Where(vm => !vm.NewRecord
                                  && vm.GetChatMarket() != null)
                     .Subscribe(vm => CalculateIsDirty())
                     .AddTo(_disposables);

            UpdateCanDelete(true);
        }

        [ExcludeFromCodeCoverage]
        ~ChatMarketItemViewModelController()
        {
            Dispose(false);
        }

        public ChatMarketItemViewModel ViewModel { get; }

        private void UpdateCanDelete(bool value)
        {
            _canDelete = value;
            ViewModel.DeleteCommand.RaiseCanExecuteChanged();
        }

        private void CalculateIsDirty()
        {
            ViewModel.IsDirty = ViewModel.Name != ViewModel.GetChatMarket().Market;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _validationService.Dispose();
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
