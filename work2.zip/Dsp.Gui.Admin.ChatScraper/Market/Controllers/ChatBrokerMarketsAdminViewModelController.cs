﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.ServiceContracts;
using Microsoft.Extensions.DependencyInjection;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Market.Controllers
{
    internal sealed class ChatBrokerMarketsAdminViewModelController : IChatBrokerMarketsAdminViewModelController
    {
        private readonly ICurveControlService _curveControlService;
        private readonly CompositeDisposable _disposables = new();
        private readonly IChatMarketItemCollectionProvider _itemCollectionProvider;
        private readonly IChatMarketItemViewModelBuilder _chatMarketItemViewModelBuilder;
        private readonly IChatMarketItemCollectionService _chatMarketItemCollectionService;
        private readonly IChatScraperMarketAdminToolBarService _toolBarService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly ILogger _log;

        private bool _disposed;

        public ChatBrokerMarketsAdminViewModelController(ICurveControlService curveControlService,
                                                         IChatMarketItemViewModelBuilder chatMarketItemViewModelBuilder,
                                                         IChatMarketItemCollectionProvider itemCollectionProvider,
                                                         IChatMarketItemCollectionService chatMarketItemCollectionService,
                                                         IChatScraperMarketAdminToolBarService toolBarService,
                                                         ISchedulerProvider schedulerProvider,
                                                         ILoggerFactory loggerFactory)
        {
            _curveControlService = curveControlService;
            _chatMarketItemViewModelBuilder = chatMarketItemViewModelBuilder;
            _itemCollectionProvider = itemCollectionProvider;
            _chatMarketItemCollectionService = chatMarketItemCollectionService;
            _toolBarService = toolBarService;
            _schedulerProvider = schedulerProvider;
            _log = loggerFactory.Create(GetType().Name);
             
            ViewModel.AddChatMarketCommand = new DelegateCommand(OnAddChatMarketCommand);

            _toolBarService.Update
                           .Subscribe(_ => OnUpdateCommand())
                           .AddTo(_disposables);

            _toolBarService.Undo
                           .Subscribe(_ => OnUndoCommand())
                           .AddTo(_disposables);

            _chatMarketItemCollectionService.CanExecuteUpdateCommand
                                            .Subscribe(OnCanExecuteUpdateCommand)
                                            .AddTo(_disposables);

            _chatMarketItemCollectionService.CanExecuteUndoCommand
                                            .Subscribe(OnCanExecuteUndoCommand)
                                            .AddTo(_disposables);

            _chatMarketItemCollectionService.ValidationErrors
                                            .Subscribe(OnValidationErrors)
                                            .AddTo(_disposables);

            _curveControlService.ChatMarkets?
                                .Where(d => d != null)
                                .ObserveOn(schedulerProvider.Dispatcher)
                                .Subscribe(UpdateRowItems)
                                .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatBrokerMarketsAdminViewModelController()
        {
            Dispose(false);
        }

        public ChatBrokerMarketsAdminViewModel ViewModel { get; } = new();

        [Inject]
        public IErrorMessageDialogService ErrorMessageDialogService { get; set; }

        [Inject]
        public IPopupNotificationService PopupNotificationService { get; set; }

        [Inject]
        public IChatMarketItemsConflictService ChatMarketConflictService { get; set; }

        [Inject]
        public IChatMarketAdminUpdateService ChatMarketAdminUpdateService { get; set; }

        private void OnCanExecuteUpdateCommand(bool value)
        {
            _toolBarService.SetCanUpdate(value);
        }

        private void OnCanExecuteUndoCommand(bool value)
        {
            _toolBarService.SetCanUndo(value);
        }

        private void OnUndoCommand()
        {
            var chatMarkets = _curveControlService.GetChatMarketSnapshot()
                                                  .ToList();

            RefreshRowItems(chatMarkets);
        }

        private void OnAddChatMarketCommand()
        {
            var viewModel = _chatMarketItemViewModelBuilder.CreateNewItem();

            _chatMarketItemCollectionService.AddNewItem(viewModel, 
                                                        ViewModel.ChatMarketItems, 
                                                        ViewModel);
        }

        private void UpdateRowItems(IList<ChatMarket> chatMarkets)
        {
            var conflicts = ChatMarketConflictService.GetConflicts(ViewModel.ChatMarketItems, chatMarkets);

            var rowItems = 
                 _itemCollectionProvider.GetCollection(ViewModel.ChatMarketItems,
                                                       chatMarkets,
                                                       (item, market) => item.Name == market.Market,
                                                       (item, market) => _chatMarketItemViewModelBuilder.UpdateItemFromChatMarket(item, market),
                                                       market => _chatMarketItemViewModelBuilder.CreateItemFromChatMarket(market));

            ViewModel.ChatMarketItems = new ObservableCollection<ChatMarketItemViewModel>(rowItems.OrderBy(i => i.Name));

            _chatMarketItemCollectionService.RefreshItems(ViewModel.ChatMarketItems);

            if (!conflicts.Any())
            {
                return;
            }

            var conflictNames = conflicts.Select(c => c.Name);

            ChatMarketConflictService.ShowConflictsDialog(conflictNames);
        }

        private void RefreshRowItems(IList<ChatMarket> chatMarkets)
        {
            var items = _itemCollectionProvider.GetCollectionReset(chatMarkets, 
                                                                   market => _chatMarketItemViewModelBuilder.CreateItemFromChatMarket(market));

            ViewModel.ChatMarketItems = new ObservableCollection<ChatMarketItemViewModel>(items);

            _chatMarketItemCollectionService.RefreshItems(ViewModel.ChatMarketItems);
        }

        private void OnUpdateCommand()
        {
            ViewModel.IsBusy = true;
            ViewModel.BusyText = "Updating Chat Markets";

            var response =
                ChatMarketAdminUpdateService.Update(ViewModel.ChatMarketItems,
                                                    _schedulerProvider.Dispatcher,
                                                    item => new ChatMarket(0, EntityStatus.Active, item.Name),
                                                    item => new ChatMarket(item.GetChatMarket().Id, EntityStatus.Active, item.Name),
                                                    item => new ChatMarket(item.GetChatMarket().Id, EntityStatus.Deleted, item.GetChatMarket().Market));

            response.ObserveOn(_schedulerProvider.Dispatcher)
                    .Subscribe(_ => OnUpdateComplete(),
                               OnError)
                    .AddTo(_disposables);
        }

        private void OnUpdateComplete()
        {
            _log.Info("Chat Markets Update Complete");

            PopupNotificationService.SendPopupNotification("Chat Scraper Markets Updated");

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;
        }

        private void OnError(Exception ex)
        {
            _log.Error($"Failed to Update Chat Markets : {ex.Message}");
            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;

            var messageArgs = new ErrorMessageDialogArgs("Markets Update Failed", ex.Message, true);

            ErrorMessageDialogService.ShowDialog(messageArgs);
        }

        private void OnValidationErrors(IList<string> validationErrors)
        {
            if (validationErrors.Count == 0)
            {
                _toolBarService.ClearValidation();
            }
            else
            {
                _toolBarService.SetValidationErrors(validationErrors);
            }
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
