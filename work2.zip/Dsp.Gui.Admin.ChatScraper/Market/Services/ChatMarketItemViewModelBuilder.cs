﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Market.Controllers;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Admin.ChatScraper.Market.Services
{
    internal class ChatMarketItemViewModelBuilder : IChatMarketItemViewModelBuilder
    {
        [Inject]
        public IServiceFactory<IChatMarketItemViewModelController> Factory { get; set; }

        public ChatMarketItemViewModel CreateNewItem()
        {
            var controller = Factory.Create();

            var viewModel = controller.ViewModel;

            viewModel.NewRecord = true;
            
            return viewModel;
        }

        public ChatMarketItemViewModel CreateItemFromChatMarket(ChatMarket chatMarket)
        {
            var controller = Factory.Create();

            var viewModel = controller.ViewModel;

            viewModel.SetChatMarket(chatMarket);

            viewModel.Id = chatMarket.Id;
            viewModel.Name = chatMarket.Market;
            viewModel.IsDirty = false;

            return viewModel;
        }

        public void UpdateItemFromChatMarket(ChatMarketItemViewModel viewModel, ChatMarket chatMarket)
        {
            viewModel.SetChatMarket(chatMarket);

            if (viewModel.NewRecord)
            {
                viewModel.Id = chatMarket.Id;
                viewModel.NewRecord = false;
            }

            viewModel.Name = chatMarket.Market;
            viewModel.IsDirty = false;
        }
    }
}
