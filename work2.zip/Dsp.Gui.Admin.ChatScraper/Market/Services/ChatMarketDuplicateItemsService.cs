﻿using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Market.Services
{
    internal sealed class ChatMarketDuplicateItemsService : DuplicateItemsService<ChatMarketItemViewModel, string>, 
                                                            IChatMarketDuplicateItemsService
    {
        public ChatMarketDuplicateItemsService()
        : base(item => item.Name,
               item => item.Name.ToUpper(CultureInfo.InvariantCulture),
               item => !string.IsNullOrEmpty(item.Name))
        {
        }

        [ExcludeFromCodeCoverage]
        ~ChatMarketDuplicateItemsService()
        {
            Dispose(false);
        }
    }
}
