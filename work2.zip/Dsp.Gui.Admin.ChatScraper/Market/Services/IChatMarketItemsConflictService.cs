﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Market.Services
{
    public interface IChatMarketItemsConflictService : IEditableItemsConflictService<ChatMarketItemViewModel, ChatMarket>
    {
    }
}
