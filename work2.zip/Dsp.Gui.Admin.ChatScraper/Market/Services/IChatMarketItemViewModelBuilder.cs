﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Market.Services
{
    public interface IChatMarketItemViewModelBuilder
    {
        ChatMarketItemViewModel CreateNewItem();
        ChatMarketItemViewModel CreateItemFromChatMarket(ChatMarket chatMarket);
        void UpdateItemFromChatMarket(ChatMarketItemViewModel viewModel, ChatMarket chatMarket);
    }
}
