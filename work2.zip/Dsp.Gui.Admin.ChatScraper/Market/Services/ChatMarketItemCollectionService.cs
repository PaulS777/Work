﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Market.Services
{
    [ExcludeFromCodeCoverage]
    internal class ChatMarketItemCollectionService : EditableItemCollectionService<ChatMarketItemViewModel>, IChatMarketItemCollectionService
    {
        public ChatMarketItemCollectionService(IChatMarketDuplicateItemsService chatMarketDuplicateItemsDuplicateService)
        : base(chatMarketDuplicateItemsDuplicateService)
        {
        }

        ~ChatMarketItemCollectionService()
        {
            Dispose(false);
        }
    }
}
