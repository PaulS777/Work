﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Market.Services
{
    internal class ChatMarketItemsConflictService : EditableItemsConflictService<ChatMarketItemViewModel, ChatMarket>,
                                                    IChatMarketItemsConflictService
    {
        public ChatMarketItemsConflictService(IChatBrokerAdminMessageDialogService messageDialogService)
        : base(messageDialogService)
        {
        }
    }

}
