﻿using System;
using System.Linq;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.Admin.ChatScraper.Market.Services
{
    internal class ChatMarketDependencyService : IChatMarketDependencyService
    {
        private readonly ICurveControlService _curveControlService;

        public ChatMarketDependencyService(ICurveControlService curveControlService)
        {
            _curveControlService = curveControlService;
        }
        public IObservable<bool> HasDependents(int id)
        {
            var chatUsers = _curveControlService.ChatUsers
                                                .Where(users => users != null)
                                                .Select(users => users.Where(u => u.Status == EntityStatus.Active)
                                                                      .Any(u => u.ChatUserMarkets.Exists(m => m.ChatMarketId == id)));

            var chatShortcuts = _curveControlService.ChatVariableShortcuts
                                                    .Where(shortcuts => shortcuts != null)
                                                    .Select(shortcuts => shortcuts.Where(s => s.Status == EntityStatus.Active)
                                                                                  .Any(shortcut => HasShortcutDependency(shortcut, id)));

            var chatIceMaps = _curveControlService.ChatIceMaps
                                                  .Where(map => map != null)
                                                  .Select(maps => maps.Where(m => m.Status == EntityStatus.Active)
                                                                      .Any(map => map.ChatMarketId == id));

            return chatUsers.CombineLatest(chatShortcuts, chatIceMaps, (u, s, m) => u || s || m);
        }

        private static bool HasShortcutDependency(ChatVariableShortcut shortcut, int id)
        {
            var item = shortcut.ChatVariableShortcutVariations is { Count: > 0 }
                ? shortcut.ChatVariableShortcutVariations[0]
                : null;

            if (item == null)
            {
                return false;
            }

            return item.ChatMarketId == id;
        }
    }
}
