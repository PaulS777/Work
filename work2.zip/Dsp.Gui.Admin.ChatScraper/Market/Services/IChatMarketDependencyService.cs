﻿using System;

namespace Dsp.Gui.Admin.ChatScraper.Market.Services
{
    public interface IChatMarketDependencyService
    {
        IObservable<bool> HasDependents(int id);
    }
}
