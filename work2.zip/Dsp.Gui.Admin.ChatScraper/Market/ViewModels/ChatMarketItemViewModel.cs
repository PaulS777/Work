﻿using System;
using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Market.ViewModels
{
    public sealed class ChatMarketItemViewModel : EditableItem
    {
        private readonly IDisposable _controller;

        private ChatMarket _chatMarket;
        private string _name;
        private bool _disposed;

        public ChatMarketItemViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        [ExcludeFromCodeCoverage]
        ~ChatMarketItemViewModel()
        {
            Dispose(false);
        }

        public void SetChatMarket(ChatMarket value) => _chatMarket = value;
        public ChatMarket GetChatMarket() => _chatMarket;

        public DelegateCommand DeleteCommand { get; set; }
        public DelegateCommand UndoDeleteCommand { get; set; }

        public string Name
        {
            get => _name;
            set
            {
                var parsed = value?.Trim();

                if (_name == parsed)
                {
                    return;
                }

                _name = parsed;
                RaisePropertyChanged();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller?.Dispose();
            }

            _disposed = true;
        }
    }
}
