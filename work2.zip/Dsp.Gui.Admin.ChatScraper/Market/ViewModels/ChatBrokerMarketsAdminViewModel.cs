﻿using System.Collections.ObjectModel;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Market.ViewModels
{
    public class ChatBrokerMarketsAdminViewModel : BindableBase, IEditableItemCollectionDialog
    {
        private bool _isBusy;
        private string _busyText;
        private ObservableCollection<ChatMarketItemViewModel> _chatMarketItems = new();
        private IEditableItem _selectedItem;
        public DelegateCommand AddChatMarketCommand { get; set; }

        public ObservableCollection<ChatMarketItemViewModel> ChatMarketItems
        {
            get => _chatMarketItems;
            set
            {
                _chatMarketItems = value;
                RaisePropertyChanged();
            }
        }

        public IEditableItem SelectedItem
        {
            get => _selectedItem;
            set
            {
                _selectedItem = value;
                RaisePropertyChanged();
            }
        }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        public string BusyText
        {
            get => _busyText;
            set
            {
                _busyText = value;
                RaisePropertyChanged();
            }
        }
    }
}
