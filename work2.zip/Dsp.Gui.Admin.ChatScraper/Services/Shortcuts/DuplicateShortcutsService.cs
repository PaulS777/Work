﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using Dsp.Gui.Admin.ChatScraper.ViewModels;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    internal class DuplicateShortcutsService : IDuplicateShortcutsService
    {
        private readonly IShortcutsSnapshotProvider _shortcutsSnapshotProvider;
        private CompositeDisposable _disposables;
        private IList<IEditableItemWithShortcuts> _items;
        private bool _disposed;

        public DuplicateShortcutsService(IShortcutsSnapshotProvider shortcutsSnapshotProvider)
        {
            _shortcutsSnapshotProvider = shortcutsSnapshotProvider;
        }

        [ExcludeFromCodeCoverage]
        ~DuplicateShortcutsService()
        {
            Dispose(false);
        }

        public void RefreshItems(IEnumerable<IEditableItemWithShortcuts> items)
        {
            _disposables?.Dispose();
            _disposables = new CompositeDisposable();

            _items = items.ToList();

            foreach (var item in _items)
            {
                item.ObservePropertyChanged(vm => vm.Shortcuts)
                    .Subscribe(CheckDuplicates)
                    .AddTo(_disposables);

                item.ObservePropertyChanged(vm => vm.IsDeleted)
                    .Subscribe(CheckDuplicates)
                    .AddTo(_disposables);
            }
        }

        public void AddItem(IEditableItemWithShortcuts item)
        {
            item.ObservePropertyChanged(vm => vm.Shortcuts)
                .Subscribe(CheckDuplicates)
                .AddTo(_disposables);

            _items.Add(item);
        }

        private void CheckDuplicates(IEditableItemWithShortcuts item)
        {
            if (item.IsDuplicateShortcut)
            {
                // In case a duplicate token has been removed/changed in the items,
                // recalculate the other duplicate items
                RecalculateOtherDuplicates(item);
            }

            if (item.Shortcuts == null || item.Shortcuts.Count == 0 || item.IsDeleted)
            {
                item.IsDuplicateShortcut = false;
                return;
            }

            // In case a token has been added, search for any duplicates in all other items
            var duplicates = _items.Where(i => i.Id != item.Id
                                               && !i.IsDeleted
                                               && CheckDuplicates(i, item))
                                  .ToList();

            if (duplicates.Any())
            {
                item.IsDuplicateShortcut = true;

                duplicates.ForEach(d => d.IsDuplicateShortcut = true);

                return;
            }

            // now check against server
            var snapshot = _shortcutsSnapshotProvider.GetSnapshot()
                                                     .ToList();

            var itemShortcuts = item.Shortcuts.Select(s => s.ToString());

            item.IsDuplicateShortcut = itemShortcuts.Intersect(snapshot, 
                                                               StringComparer.InvariantCultureIgnoreCase)
                                                    .Any();
        }

        // Check rows in current collection for duplication with current row
        private void RecalculateOtherDuplicates(IEditableEntity item)
        {
            var allDuplicates = _items.Where(r => !r.IsDeleted
                                                  && r.IsDuplicateShortcut)
                                     .ToList();

            var otherDuplicates = allDuplicates.Where(d => d.Id != item.Id)
                                               .ToList();

            // iterate through each duplicate row, checking if duplicates still exist with other rows
            foreach (var otherDuplicate in otherDuplicates)
            {
                otherDuplicate.IsDuplicateShortcut = allDuplicates.Exists(d => d.Id != otherDuplicate.Id 
                                                                            && CheckDuplicates(d, otherDuplicate));
            }
        }

        private static bool CheckDuplicates(IEditableItemWithShortcuts item1, IEditableItemWithShortcuts item2)
        {
            if (item1.Shortcuts == null || item2.Shortcuts == null)
            {
                return false;
            }

            var item1Shortcuts = item1.Shortcuts.Select(s => s.ToString());
            var item2Shortcuts = item2.Shortcuts.Select(s => s.ToString());

            return item1Shortcuts.Intersect(item2Shortcuts, 
                                            StringComparer.InvariantCultureIgnoreCase)
                                 .Any();
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables?.Dispose();
            }

            _disposed = true;
        }
    }
}
