﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    [ExcludeFromCodeCoverage]
    internal class ChatVariableShortcutDuplicateShortcutsService : DuplicateShortcutsService,
                                                                   IChatVariableShortcutDuplicateShortcutsService
    {
        public ChatVariableShortcutDuplicateShortcutsService(IChatVariableShortcutShortcutsProvider provider)
            :base(provider)
        {
        }
    }
}
