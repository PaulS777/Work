﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    internal class ChatVariableShortcutShortcutsProvider : IChatVariableShortcutShortcutsProvider
    {
        private readonly ICurveControlService _curveControlService;

        public ChatVariableShortcutShortcutsProvider(ICurveControlService curveControlService)
        {
            _curveControlService = curveControlService;
        }

        public IEnumerable<string> GetSnapshot()
        {
            var shortcuts = _curveControlService.GetChatVariableShortcutSnapshot();

            return shortcuts.Where(vs => vs.Status == EntityStatus.Active)
                            .Select(vs => vs.Shortcuts)
                            .Where(s => !string.IsNullOrEmpty(s))
                            .SelectMany(s => s.Split(';'));
        }
    }
}
