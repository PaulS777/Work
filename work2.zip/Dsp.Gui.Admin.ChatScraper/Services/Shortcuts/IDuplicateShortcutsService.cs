﻿using System;
using System.Collections.Generic;
using Dsp.Gui.Admin.ChatScraper.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    public interface IDuplicateShortcutsService : IDisposable
    {
        void RefreshItems(IEnumerable<IEditableItemWithShortcuts> items);
        void AddItem(IEditableItemWithShortcuts item);
    }
}
