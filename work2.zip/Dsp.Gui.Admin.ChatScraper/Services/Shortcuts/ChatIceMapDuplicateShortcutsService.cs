﻿
using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    [ExcludeFromCodeCoverage]
    internal sealed class ChatIceMapDuplicateShortcutsService : DuplicateShortcutsService, 
                                                                IChatIceMapDuplicateShortcutsService
    {
        public ChatIceMapDuplicateShortcutsService(IChatIceMapShortcutsProvider provider)
            :base(provider)
        {
        }
    }
}
