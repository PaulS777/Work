﻿using System.Collections.Generic;
using System.Linq;

namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    internal class ChatShortcutsComparer : IChatShortcutsComparer
    {
        public bool CompareShortcuts(IEnumerable<object> items, string shortcuts)
        {
            var itemTags = items != null
                ? items.Cast<string>()
                       .ToList()
                : new List<string>();

            var shortcutsArray = !string.IsNullOrEmpty(shortcuts) ? shortcuts.Split(';').ToList() : new List<string>();

            var diffs = itemTags.Except(shortcutsArray).Any() || shortcutsArray.Except(itemTags).Any();

            return !diffs;
        }
    }
}
