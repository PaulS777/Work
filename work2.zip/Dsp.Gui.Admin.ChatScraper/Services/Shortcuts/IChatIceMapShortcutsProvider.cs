﻿namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    public interface IChatIceMapShortcutsProvider : IShortcutsSnapshotProvider
    {
    }
}
