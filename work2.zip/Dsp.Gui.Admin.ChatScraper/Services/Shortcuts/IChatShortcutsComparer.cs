﻿using System.Collections.Generic;

namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    public interface IChatShortcutsComparer
    {
        bool CompareShortcuts(IEnumerable<object> items, string shortcuts);
    }
}
