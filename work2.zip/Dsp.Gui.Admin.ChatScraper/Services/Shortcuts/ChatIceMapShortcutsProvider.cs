﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.Admin.ChatScraper.Services.Shortcuts
{
    internal class ChatIceMapShortcutsProvider : IChatIceMapShortcutsProvider
    {
        private readonly ICurveControlService _curveControlService;

        public ChatIceMapShortcutsProvider(ICurveControlService curveControlService)
        {
            _curveControlService = curveControlService;
        }

        public IEnumerable<string> GetSnapshot()
        {
            var iceMaps = _curveControlService.GetChatIceMapSnapshot();

            return iceMaps.Where(im => im.Status == EntityStatus.Active)
                          .Select(im => im.Shortcuts)
                          .Where(s => !string.IsNullOrEmpty(s))
                          .SelectMany(s => s.Split(';'));
        }
    }
}
