﻿using System;
using System.Reactive;
using System.Reactive.Concurrency;

namespace Dsp.Gui.Admin.ChatScraper.Services
{
    public interface IChatScraperAdminUpdateService
    {
        IObservable<Unit> UpdateChatScraperProfile<T>(IScheduler scheduler, T model, bool add);
    }
}
