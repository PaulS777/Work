﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Services
{
    public interface IChatVariableShortcutAdminUpdateService : IBrokerAdminUpdateService<ChatShortcutsItemViewModel, ChatVariableShortcut> 
    {
    }
}
