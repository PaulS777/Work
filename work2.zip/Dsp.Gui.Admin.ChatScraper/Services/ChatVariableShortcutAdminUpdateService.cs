﻿using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Services
{
    [ExcludeFromCodeCoverage]
    internal class ChatVariableShortcutAdminUpdateService : BrokerAdminUpdateService<ChatShortcutsItemViewModel, ChatVariableShortcut>,
                                                            IChatVariableShortcutAdminUpdateService
    {
        public ChatVariableShortcutAdminUpdateService(IChatScraperAdminUpdateService chatScraperAdminUpdateService)
        :base(chatScraperAdminUpdateService)
        {
        }
    }
}
