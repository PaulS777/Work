﻿using System.Collections.Generic;

namespace Dsp.Gui.Admin.ChatScraper.Services
{
    public interface IShortcutsSnapshotProvider
    {
        IEnumerable<string> GetSnapshot();
    }
}
