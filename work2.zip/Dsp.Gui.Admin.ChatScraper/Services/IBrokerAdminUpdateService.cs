﻿using System;
using System.Collections.Generic;
using System.Reactive;
using System.Reactive.Concurrency;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Services
{
    public interface IChatUserAdminUpdateService : IBrokerAdminUpdateService<ChatUserItemViewModel, ChatUser> { }
    public interface IChatMarketAdminUpdateService : IBrokerAdminUpdateService<ChatMarketItemViewModel, ChatMarket> { }

    public interface IBrokerAdminUpdateService <TRow, in TModel>
    where TRow : class, IEditableItem
    where TModel : class
    {
        IObservable<Unit> Update(IList<TRow> rows,
                                 IScheduler scheduler,
                                 Func<TRow, TModel> buildNew,
                                 Func<TRow, TModel> buildChanged,
                                 Func<TRow, TModel> buildDeleted);
    }
}
