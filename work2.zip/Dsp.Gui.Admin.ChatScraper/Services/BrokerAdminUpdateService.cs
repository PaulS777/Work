﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Broker.ViewModels;
using Dsp.Gui.Admin.ChatScraper.Market.ViewModels;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Services
{
    [ExcludeFromCodeCoverage]
    internal class ChatUserAdminUpdateService : BrokerAdminUpdateService<ChatUserItemViewModel, ChatUser>,
                                                IChatUserAdminUpdateService
    {
        public ChatUserAdminUpdateService(IChatScraperAdminUpdateService chatScraperAdminUpdateService)
        :base(chatScraperAdminUpdateService)
        {}
    }

    [ExcludeFromCodeCoverage]
    internal class ChatMarketAdminUpdateService : BrokerAdminUpdateService<ChatMarketItemViewModel, ChatMarket>,
                                                  IChatMarketAdminUpdateService
    {
        public ChatMarketAdminUpdateService(IChatScraperAdminUpdateService chatScraperAdminUpdateService)
        : base(chatScraperAdminUpdateService)
        { }
    }

    internal class BrokerAdminUpdateService<TRow, TModel> : IBrokerAdminUpdateService<TRow, TModel>
        where TRow : class, IEditableItem
        where TModel : class
    {
        private readonly IChatScraperAdminUpdateService _chatScraperAdminUpdateService;

        public BrokerAdminUpdateService(IChatScraperAdminUpdateService chatScraperAdminUpdateService)
        {
            _chatScraperAdminUpdateService = chatScraperAdminUpdateService;
        }

        public IObservable<Unit> Update(IList<TRow> rows, 
                                        IScheduler scheduler,
                                        Func<TRow, TModel> buildNew, 
                                        Func<TRow, TModel> buildChanged, 
                                        Func<TRow, TModel> buildDeleted)
        {
            var changes = rows.Where(r => r.IsInEdit)
                              .ToList();

            changes.ForEach(r => r.IsInEdit = false);

            var newRows = rows.Where(r => r.NewRecord && r.IsValid)
                              .ToList();

            var changedRows = rows.Where(r => !r.NewRecord && !r.IsDeleted
                                              && r.IsDirty && r.IsValid);

            var deletedRows = rows.Where(r => !r.NewRecord
                                              && r.IsDeleted);

            var newObjects = newRows.Select(buildNew).ToList();

            var deletedObjects = deletedRows.Select(buildDeleted).ToList();
            var changedObjects = changedRows.Select(buildChanged).ToList();

            changedObjects.AddRange(deletedObjects);

            var newChatUsersUpdateResponse = newObjects.Any()
                ? _chatScraperAdminUpdateService.UpdateChatScraperProfile(scheduler, newObjects, true)
                : Observable.Return(Unit.Default);

            var changedChatUsersUpdateResponse = changedObjects.Any()
                ? _chatScraperAdminUpdateService.UpdateChatScraperProfile(scheduler, changedObjects, false)
                : Observable.Return(Unit.Default);

            return newChatUsersUpdateResponse.CombineLatest(changedChatUsersUpdateResponse, (n, c) => Unit.Default);
        }
    }
}
