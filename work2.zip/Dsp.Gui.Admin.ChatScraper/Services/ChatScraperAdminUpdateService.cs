﻿using System;
using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Services;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Admin.ChatScraper.Services
{
    internal class ChatScraperAdminUpdateService : IChatScraperAdminUpdateService
    {
        private readonly IAdminApiServiceClient _adminApiServiceClient;
        private readonly ILogger _log;

        public ChatScraperAdminUpdateService(IAdminApiServiceClient adminApiServiceClient, 
                                             ILoggerFactory loggerFactory)
        {
            _adminApiServiceClient = adminApiServiceClient;
            _log = loggerFactory.Create(GetType().Name);
        }

        public IObservable<Unit> UpdateChatScraperProfile<T>(IScheduler scheduler, T model, bool add)
        {
            return Observable.Create<Unit>(obs =>
            {
                return scheduler.ScheduleAsync(async (_, _) =>
                {
                    try
                    {
                        AdminApiServiceResponse response;

                        _log.Info("Updating Chat Scraper Admin");

                        if (add)
                        {
                            response = await _adminApiServiceClient.Add(model);
                        }
                        else
                        {
                            response = await _adminApiServiceClient.Update(model);
                        }

                        if (!response.IsSuccess)
                        {
                            obs.OnError( new Exception(response.ReasonText));
                            _log.Error("Request failed.");

                            return;
                        }

                        obs.OnNext(Unit.Default);
                        obs.OnCompleted();
                        _log.Info("Request completed");
                    
                    }
                    catch (Exception ex)
                    {
                        obs.OnError(ex);
                        _log.Error(ex.Message);
                    }
                });
            });
        }
    }
}
