﻿// ***********************************************************************************************************************
// ChatScraperAdminModule.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Broker.Controllers;
using Dsp.Gui.Admin.ChatScraper.Broker.Rules;
using Dsp.Gui.Admin.ChatScraper.Broker.Services;
using Dsp.Gui.Admin.ChatScraper.Broker.Views;
using Dsp.Gui.Admin.ChatScraper.Market.Controllers;
using Dsp.Gui.Admin.ChatScraper.Market.Rules;
using Dsp.Gui.Admin.ChatScraper.Market.Services;
using Dsp.Gui.Admin.ChatScraper.Market.Views;
using Dsp.Gui.Admin.ChatScraper.Messages.Controllers;
using Dsp.Gui.Admin.ChatScraper.Messages.Services;
using Dsp.Gui.Admin.ChatScraper.Messages.Views;
using Dsp.Gui.Admin.ChatScraper.Product.Controllers;
using Dsp.Gui.Admin.ChatScraper.Product.Rules;
using Dsp.Gui.Admin.ChatScraper.Product.Services;
using Dsp.Gui.Admin.ChatScraper.Product.Views;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Views;
using Dsp.Gui.Common.Extensions;
using Microsoft.Extensions.DependencyInjection;
using ServiceCollection.Extensions.Modules;

namespace Dsp.Gui.Admin.ChatScraper
{
    [ExcludeFromCodeCoverage]
    public class ChatScraperAdminModule : Module
    {
        protected override void Load(IServiceCollection services)
        {
            base.Load(services);

            services.AddSingleton<ChatScraperBrokerAdminView>();
            services.AddSingleton<ChatBrokerMarketsAdminView>();
            services.AddSingleton<ChatScraperProductAdminView>();
            services.AddSingleton<ChatScraperShortcutsAdminView>();
            services.AddSingleton<ChatScraperMessageAdminView>();

            services.AddSingleton<IChatShortcutsComparer, ChatShortcutsComparer>();
            services.AddSingleton<IChatIceMapShortcutsProvider, ChatIceMapShortcutsProvider>();
            services.AddSingleton<IChatVariableShortcutShortcutsProvider, ChatVariableShortcutShortcutsProvider>();
            services.AddTransient<IChatIceMapDuplicateShortcutsService, ChatIceMapDuplicateShortcutsService>();
            services.AddTransient<IChatVariableShortcutDuplicateShortcutsService, ChatVariableShortcutDuplicateShortcutsService>();
            services.AddSingleton<IChatBrokerUsersAdminViewModelController, ChatBrokerUsersAdminViewModelController>();
            services.AddSingleton<IChatBrokerMarketsAdminViewModelController, ChatBrokerMarketsAdminViewModelController>();
            services.AddSingleton<IChatMessageAdminViewModelController, ChatMessageAdminViewModelController>();
            services.AddSingleton<IChatProductsAdminViewModelController, ChatProductsAdminViewModelController>();
            services.AddSingleton<IChatShortcutsAdminViewModelController, ChatShortcutsAdminViewModelController>();
            services.AddSingleton<IChatScraperAdminUpdateService, ChatScraperAdminUpdateService>();
            services.AddSingleton<IChatUserItemViewModelBuilder, ChatUserItemViewModelBuilder>();
            services.AddSingleton<IChatUserBuilder, ChatUserBuilder>();
            services.AddSingleton<IChatMessageHistoryViewModelBuilder, ChatMessageHistoryViewModelBuilder>();
            services.AddSingleton<IChatIceMapBuilder, ChatIceMapBuilder>();
            services.AddSingleton<IChatUserItemCollectionProvider, ChatUserItemCollectionProvider>();
            services.AddSingleton<IChatUserItemsConflictService, ChatUserItemsConflictService>();
            services.AddSingleton<IChatMarketItemsConflictService, ChatMarketItemsConflictService>();
            services.AddSingleton<IChatBrokerAdminMessageDialogService, ChatBrokerAdminMessageDialogService>();
            services.AddSingleton<IChatMarketItemViewModelBuilder, ChatMarketItemViewModelBuilder>();
            services.AddSingleton<IChatMarketDependencyService, ChatMarketDependencyService>();
            services.AddTransient<IChatMarketNameRule, ChatMarketNameRule>();
            services.AddTransient<IChatMarketItemValidationService, ChatMarketItemValidationService>();
            services.AddTransient<IChatMarketDuplicateItemsService, ChatMarketDuplicateItemsService>();
            services.AddSingleton<IChatMarketItemCollectionProvider, ChatMarketItemCollectionProvider>();
            services.AddTransient<IChatUserNameRule, ChatUserNameRule>();
            services.AddTransient<IChatUserItemValidationService, ChatUserItemValidationService>();
            services.AddTransient<IChatUserDuplicateItemsService, ChatUserDuplicateItemsService>();
            services.AddTransient<IChatUserItemCollectionService, ChatUserItemCollectionService>();
            services.AddTransient<IChatMarketItemCollectionService, ChatMarketItemCollectionService>();
            services.AddTransient<IChatUserAdminUpdateService, ChatUserAdminUpdateService>();
            services.AddTransient<IChatMarketAdminUpdateService, ChatMarketAdminUpdateService>();
            services.AddTransient<IChatUserItemViewModelController, ChatUserItemViewModelController>();
            services.AddTransient<IChatMarketItemViewModelController, ChatMarketItemViewModelController>();
            services.AddSingleton<IChatProductItemViewModelBuilder, ChatProductItemViewModelBuilder>();
            services.AddSingleton<IChatProductItemCollectionProvider, ChatProductItemCollectionProvider>();
            services.AddTransient<IChatProductItemPriceCurveDefinitionRule, ChatProductItemPriceCurveDefinitionRule>();
            services.AddTransient<IChatProductItemMarketRule, ChatProductItemMarketRule>();
            services.AddTransient<IChatProductItemShortcutRule, ChatProductItemShortcutRule>();
            services.AddTransient<IChatProductItemValidationService, ChatProductItemValidationService>();
            services.AddTransient<IDeletedProductItemMappingsObserver, DeletedProductItemMappingsObserver>();
            services.AddTransient<IChatProductDuplicateItemsService, ChatProductDuplicateItemsService>();
            services.AddTransient<IChatProductItemCollectionService, ChatProductItemCollectionService>();
            services.AddTransient<IChatProductItemFilterService, ChatProductItemFilterService>();
            services.AddTransient<IChatIceMapAdminUpdateService, ChatIceMapAdminUpdateService>();
            services.AddTransient<IChatProductItemViewModelController, ChatProductItemViewModelController>();
            services.AddSingleton<IChatShortcutsItemCollectionProvider, ChatShortcutsItemCollectionProvider>();
            services.AddSingleton<IChatShortcutsItemViewModelBuilder, ChatShortcutsItemViewModelBuilder>();
            services.AddTransient<IChatShortcutsNameRule, ChatShortcutsNameRule>();
            services.AddTransient<IChatShortcutsShortcutsRule, ChatShortcutsShortcutsRule>();
            services.AddTransient<IChatShortcutsMappingsValidRule, ChatShortcutsMappingsValidRule>();
            services.AddTransient<IChatShortcutsDuplicateItemsService, ChatShortcutsDuplicateItemsService>();
            services.AddTransient<IChatShortcutsItemValidationService, ChatShortcutsItemValidationService>();
            services.AddTransient<IChatShortcutsItemCollectionService, ChatShortcutsItemCollectionService>();
            services.AddTransient<IChatShortcutsItemChangedObserver, ChatShortcutsItemChangedObserver>();
            services.AddTransient<IChatShortcutsSubscribeUpdatesService, ChatShortcutsSubscribeUpdatesService>();
            services.AddTransient<IChatShortcutsMappingMarketRule, ChatShortcutsMappingMarketRule>();
            services.AddTransient<IChatShortcutsMappingIceMapRule, ChatShortcutsMappingIceMapRule>();
            services.AddTransient<IChatShortcutsMappingDuplicateItemsService, ChatShortcutsMappingDuplicateItemsService>();
            services.AddTransient<IChatShortcutsMappingItemValidationService, ChatShortcutsMappingItemValidationService>();
            services.AddTransient<IChatShortcutsMappingItemCollectionService, ChatShortcutsMappingItemCollectionService>();
            services.AddTransient<IChatShortcutsMappingItemChangedObserver, ChatShortcutsMappingItemChangedObserver>();
            services.AddTransient<IChatShortcutsMappingItemSubscribeUpdatesService, ChatShortcutsMappingItemSubscribeUpdatesService>();
            services.AddSingleton<IChatVariableShortcutBuilder, ChatVariableShortcutBuilder>();
            services.AddTransient<IChatVariableShortcutAdminUpdateService, ChatVariableShortcutAdminUpdateService>();
            services.AddTransient<IChatShortcutsAdminViewModelController, ChatShortcutsAdminViewModelController>();
            services.AddTransient<IChatShortcutsItemViewModelController, ChatShortcutsItemViewModelController>();
            services.AddTransient<IChatShortcutsMappingItemViewModelController, ChatShortcutsMappingItemViewModelController>();

            services.AddFactory<IChatUserItemViewModelController, ChatUserItemViewModelController>();
            services.AddFactory<IChatMarketItemViewModelController, ChatMarketItemViewModelController>();
            services.AddFactory<IChatProductItemViewModelController, ChatProductItemViewModelController>();
            services.AddFactory<IChatShortcutsItemViewModelController, ChatShortcutsItemViewModelController>();
            services.AddFactory<IChatShortcutsMappingItemViewModelController, ChatShortcutsMappingItemViewModelController>();

            services.AddPropertyInjectedServices();
        }
    }
}
