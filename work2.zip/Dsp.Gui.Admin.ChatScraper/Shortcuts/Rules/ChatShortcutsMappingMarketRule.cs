﻿using System;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules
{
    internal class ChatShortcutsMappingMarketRule : IChatShortcutsMappingMarketRule
    {
        public IObservable<ChatShortcutsMappingItemViewModel> ObservePropertyChanged(ChatShortcutsMappingItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => viewModel.Market);
        }

        public string Validate(ChatShortcutsMappingItemViewModel viewModel)
        {
            return viewModel.Market == null ? "Missing Market" : string.Empty;
        }
    }
}
