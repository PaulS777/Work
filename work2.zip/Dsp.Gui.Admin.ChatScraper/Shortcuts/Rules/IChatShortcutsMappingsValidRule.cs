﻿using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules
{
    public interface IChatShortcutsMappingsValidRule : IValidationRule<ChatShortcutsItemViewModel>
    {
    }
}
