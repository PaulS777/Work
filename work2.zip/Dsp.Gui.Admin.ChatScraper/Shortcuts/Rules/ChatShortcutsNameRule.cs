﻿using System;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules
{
    internal class ChatShortcutsNameRule : IChatShortcutsNameRule
    {
        public IObservable<ChatShortcutsItemViewModel> ObservePropertyChanged(ChatShortcutsItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => viewModel.NameIsValid);
        }

        public string Validate(ChatShortcutsItemViewModel viewModel)
        {
            return viewModel.NameIsValid ? string.Empty :  "Missing Name";
        }
    }
}
