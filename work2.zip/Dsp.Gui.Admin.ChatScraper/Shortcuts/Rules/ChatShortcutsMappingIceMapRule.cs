﻿using System;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules
{
    internal class ChatShortcutsMappingIceMapRule : IChatShortcutsMappingIceMapRule
    {
        public IObservable<ChatShortcutsMappingItemViewModel> ObservePropertyChanged(ChatShortcutsMappingItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => viewModel.IceMap);
        }

        public string Validate(ChatShortcutsMappingItemViewModel viewModel)
        {
            return viewModel.IceMap == null ? "Missing Price Curve" : string.Empty;
        }
    }
}
