﻿using System;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules
{
    internal class ChatShortcutsMappingsValidRule : IChatShortcutsMappingsValidRule
    {
        public IObservable<ChatShortcutsItemViewModel> ObservePropertyChanged(ChatShortcutsItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => viewModel.ChatShortcutsMappingsValid);
        }

        public string Validate(ChatShortcutsItemViewModel viewModel)
        {
            return viewModel.ChatShortcutsMappingsValid ? string.Empty : "Invalid Variations";
        }
    }
}
