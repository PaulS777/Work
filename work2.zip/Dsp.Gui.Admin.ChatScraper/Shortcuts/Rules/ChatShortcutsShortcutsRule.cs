﻿using System;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules
{
    internal class ChatShortcutsShortcutsRule : IChatShortcutsShortcutsRule
    {
        public IObservable<ChatShortcutsItemViewModel> ObservePropertyChanged(ChatShortcutsItemViewModel viewModel)
        {
            return viewModel.ObservePropertyChanged(vm => viewModel.ShortcutsValid);
        }

        public string Validate(ChatShortcutsItemViewModel viewModel)
        {
            return viewModel.ShortcutsValid ? string.Empty : "Missing Shortcuts";
        }
    }
}
