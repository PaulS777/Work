﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Views
{
    [ExcludeFromCodeCoverage]
    public partial class ChatScraperShortcutsAdminControl
    {
        public ChatScraperShortcutsAdminControl()
        {
            InitializeComponent();
        }
    }
}
