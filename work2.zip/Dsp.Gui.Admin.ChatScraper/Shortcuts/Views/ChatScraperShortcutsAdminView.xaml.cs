﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Views
{
    [ExcludeFromCodeCoverage]
    public partial class ChatScraperShortcutsAdminView
    {
        public ChatScraperShortcutsAdminView(IChatShortcutsAdminViewModelController controller)
        {
            DataContext = controller.ViewModel;
            InitializeComponent();
        }
    }
}
