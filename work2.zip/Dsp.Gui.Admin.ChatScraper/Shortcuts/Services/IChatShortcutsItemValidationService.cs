﻿using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    public interface IChatShortcutsItemValidationService : IEditableItemValidationService<ChatShortcutsItemViewModel>
    {
    }
}
