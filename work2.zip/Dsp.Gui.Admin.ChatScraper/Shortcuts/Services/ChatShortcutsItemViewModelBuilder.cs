﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    internal class ChatShortcutsItemViewModelBuilder : IChatShortcutsItemViewModelBuilder
    {
        [Inject]
        public IServiceFactory<IChatShortcutsItemViewModelController> ItemFactory { get; set; }

        [Inject]
        public IServiceFactory<IChatShortcutsMappingItemViewModelController> MappingItemFactory { get; set; }

        public ChatShortcutsItemViewModel CreateItemFromChatVariableShortcut(ChatVariableShortcut chatVariableShortcut, 
                                                                             ObservableCollection<ChatIceMap> chatIceMaps, 
                                                                             ObservableCollection<ChatMarket> chatMarkets)
        {
            var controller = ItemFactory.Create();

            var viewModel = controller.ViewModel;

            viewModel.Id = chatVariableShortcut.Id;

            viewModel.SetChatIceMaps(chatIceMaps);
            viewModel.SetChatMarkets(chatMarkets);

            UpdateViewModelFromChatVariableShortcut(viewModel, chatVariableShortcut);

            viewModel.SubscribeUpdates = true;

            return controller.ViewModel;
        }

        public void UpdateItemFromChatVariableShortcut(ChatShortcutsItemViewModel viewModel, 
                                                       ChatVariableShortcut chatVariableShortcut)
        {
            viewModel.SubscribeUpdates = false;

            UpdateViewModelFromChatVariableShortcut(viewModel, chatVariableShortcut);

            viewModel.SubscribeUpdates = true;
        }

        /// <summary>
        /// Creates new ChatShortcuts with NewRecord
        /// </summary>
        /// <param name="chatIceMaps"></param>
        /// <param name="chatMarkets"></param>
        /// <returns></returns>
        public ChatShortcutsItemViewModel CreateNewItem(ObservableCollection<ChatIceMap> chatIceMaps,
                                                        ObservableCollection<ChatMarket> chatMarkets)
        {
            var controller = ItemFactory.Create();

            controller.ViewModel.NewRecord = true;

            controller.ViewModel.SetChatIceMaps(chatIceMaps);
            controller.ViewModel.SetChatMarkets(chatMarkets);

            controller.ViewModel.ChatShortcutsMappings = new ObservableCollection<ChatShortcutsMappingItemViewModel>();

            controller.ViewModel.SubscribeUpdates = true;

            return controller.ViewModel;
        }

        /// <summary>
        /// Creates new ChatShortcutsRow with NewRecord
        /// </summary>
        /// <param name="chatIceMaps"></param>
        /// <param name="chatMarkets"></param>
        /// <returns></returns>
        public ChatShortcutsMappingItemViewModel CreateNewMappingItem(ObservableCollection<ChatIceMap> chatIceMaps,
                                                                      ObservableCollection<ChatMarket> chatMarkets)
        {
            var controller = MappingItemFactory.Create();

            controller.ViewModel.NewRecord = true;

            controller.ViewModel.ChatIceMaps = chatIceMaps;
            controller.ViewModel.ChatMarkets = chatMarkets;

            controller.ViewModel.SubscribeUpdates = true;

            return controller.ViewModel;
        }

        /// <summary>
        /// ViewModel has previously been initialized with Id, Markets and IceMaps
        /// </summary>
        /// <param name="viewModel"></param>
        /// <param name="chatVariableShortcut"></param>
        private void UpdateViewModelFromChatVariableShortcut(ChatShortcutsItemViewModel viewModel,
                                                             ChatVariableShortcut chatVariableShortcut)
        {
            viewModel.Name = chatVariableShortcut.Name;

            if (chatVariableShortcut.Shortcuts != null)
            {
                viewModel.Shortcuts = !string.IsNullOrEmpty(chatVariableShortcut.Shortcuts)
                    ? chatVariableShortcut.Shortcuts.Split(';').Cast<object>().ToList()
                    : new List<object>();
            }

            viewModel.SetChatVariableShortcut(chatVariableShortcut);

            var chatShortcutRows = chatVariableShortcut.ChatVariableShortcutVariations
                                                       .Select(variation => GetMappingItem(variation,
                                                                                           viewModel.ChatIceMaps(),
                                                                                           viewModel.ChatMarkets()));

            viewModel.ChatShortcutsMappings = new ObservableCollection<ChatShortcutsMappingItemViewModel>(chatShortcutRows);
        }

        private ChatShortcutsMappingItemViewModel GetMappingItem(ChatVariableShortcutVariation variation, 
                                                                 ObservableCollection<ChatIceMap> chatIceMaps,
                                                                 ObservableCollection<ChatMarket> chatMarkets)
        {
            var controller = MappingItemFactory.Create();
            
            controller.ViewModel.SetVariation(variation);

            controller.ViewModel.ChatIceMaps = chatIceMaps;
            controller.ViewModel.ChatMarkets = chatMarkets;

            controller.ViewModel.IceMap = chatIceMaps.FirstOrDefault(d => d.PriceCurveName == variation.PriceCurveName);
            controller.ViewModel.Market = chatMarkets.FirstOrDefault(m => m.Id == variation.ChatMarketId);

            controller.ViewModel.SubscribeUpdates = true;

            return controller.ViewModel;
        }
    }
}
