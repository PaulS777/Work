﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    [ExcludeFromCodeCoverage]
    internal class ChatShortcutsSubscribeUpdatesService : EditableItemSubscribeUpdatesService<ChatShortcutsItemViewModel>,
                                                          IChatShortcutsSubscribeUpdatesService

    {
        public ChatShortcutsSubscribeUpdatesService(IChatShortcutsItemChangedObserver changedObserver,
                                                    IChatShortcutsItemValidationService validationService)
        :base(changedObserver, validationService)
        {
        }
    }
}
