﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings
{
    internal sealed class ChatShortcutsMappingItemChangedObserver : IChatShortcutsMappingItemChangedObserver
    {
        private CompositeDisposable _disposables;
        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~ChatShortcutsMappingItemChangedObserver()
        {
            Dispose(false);
        }

        public void SubscribeUpdates(ChatShortcutsMappingItemViewModel item)
        {
            _disposables = new CompositeDisposable();

            item.ObservePropertyChanged(vm => vm.IceMap)
                .Where(vm => vm.IceMap != null)
                .Subscribe(SetDefaultMarket)
                .AddTo(_disposables);

            item.ObservePropertyChanged(vm => vm.Market)
                .Where(vm => !vm.NewRecord && vm.Variation() != null)
                .Subscribe(CalculateIsDirty)
                .AddTo(_disposables);

            item.ObservePropertyChanged(vm => vm.IceMap)
                .Where(vm => !vm.NewRecord && vm.Variation() != null)
                .Subscribe(CalculateIsDirty)
                .AddTo(_disposables);
        }

        public void UnSubscribe()
        {
            _disposables?.Dispose();
        }

        private static void SetDefaultMarket(ChatShortcutsMappingItemViewModel item)
        {
            item.Market = item.ChatMarkets.FirstOrDefault(m => m.Id == item.IceMap.ChatMarketId);
        }

        private static void CalculateIsDirty(ChatShortcutsMappingItemViewModel item)
        {
            if (item.Market?.Id != item.Variation().ChatMarketId)
            {
                item.IsDirty = true;
                return;
            }

            if (item.IceMap?.PriceCurveName != item.Variation().PriceCurveName)
            {
                item.IsDirty = true;
                return;
            }

            item.IsDirty = false;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                UnSubscribe();
            }

            _disposed = true;
        }
    }
}
