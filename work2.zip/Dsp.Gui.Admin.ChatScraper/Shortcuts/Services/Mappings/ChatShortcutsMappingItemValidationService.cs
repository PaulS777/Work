﻿using Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings
{
    internal class ChatShortcutsMappingItemValidationService : EditableItemValidationService<ChatShortcutsMappingItemViewModel>,
                                                               IChatShortcutsMappingItemValidationService
    {
        public ChatShortcutsMappingItemValidationService(IChatShortcutsMappingMarketRule marketRule,
                                                         IChatShortcutsMappingIceMapRule iceMapRule)
        :base(marketRule,
              iceMapRule)
        {
        }

        public override string IsDuplicateText() => "Duplicate Market";
    }
}
