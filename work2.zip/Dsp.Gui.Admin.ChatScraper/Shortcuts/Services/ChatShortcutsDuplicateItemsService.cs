﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    internal class ChatShortcutsDuplicateItemsService : DuplicateItemsService<ChatShortcutsItemViewModel, string>,
                                                        IChatShortcutsDuplicateItemsService
    {
        public ChatShortcutsDuplicateItemsService()
            : base(shortcuts => shortcuts.Name,
                   shortcuts => shortcuts.Name,
                   shortcuts => shortcuts.Name != null)
        {
        }

        [ExcludeFromCodeCoverage]
        ~ChatShortcutsDuplicateItemsService()
        {
            Dispose(false);
        }
    }
}
