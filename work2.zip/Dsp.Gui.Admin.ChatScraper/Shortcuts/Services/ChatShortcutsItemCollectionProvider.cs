﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    internal class ChatShortcutsItemCollectionProvider : EditableEntityCollectionProvider<ChatShortcutsItemViewModel, ChatVariableShortcut>,
                                                         IChatShortcutsItemCollectionProvider
    {
    }
}
