﻿using System.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    internal class ChatVariableShortcutBuilder : IChatVariableShortcutBuilder
    {
        public ChatVariableShortcut GetNewChatVariableShortcut(ChatShortcutsItemViewModel viewModel)
        {
            return GetChatVariableShortcut(viewModel, 0);
        }

        public ChatVariableShortcut GetUpdatedChatVariableShortcut(ChatShortcutsItemViewModel viewModel)
        {
            return GetChatVariableShortcut(viewModel, viewModel.Id);
        }

        public ChatVariableShortcut GetDeletedChatVariableShortcut(ChatShortcutsItemViewModel viewModel)
        {
            return new ChatVariableShortcut(viewModel.Id,
                                            EntityStatus.Deleted,
                                            viewModel.ChatVariableShortcut().Name,
                                            viewModel.ChatVariableShortcut().Shortcuts,
                                            viewModel.ChatVariableShortcut().ChatVariableShortcutVariations);
        }

        private static ChatVariableShortcut GetChatVariableShortcut(ChatShortcutsItemViewModel viewModel, int id)
        {
            var shortcuts = viewModel.Shortcuts != null ? string.Join(";", viewModel.Shortcuts.ToArray()) : null;

            var variations = viewModel.ChatShortcutsMappings
                                      .Where(row => !row.IsDeleted)
                                      .Select(row => new ChatVariableShortcutVariation(0, id, row.Market.Id, row.IceMap.PriceCurveName))
                                      .ToList();

            var chatVariableShortcut = new ChatVariableShortcut(id,
                                                                EntityStatus.Active,
                                                                viewModel.Name,
                                                                shortcuts, 
                                                                variations);

            return chatVariableShortcut;
        }
    }
}
