﻿using System.Collections.ObjectModel;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    public interface IChatShortcutsItemViewModelBuilder

    {
        ChatShortcutsItemViewModel CreateItemFromChatVariableShortcut(ChatVariableShortcut chatVariableShortcut, 
                                                                      ObservableCollection<ChatIceMap> chatIceMaps, 
                                                                      ObservableCollection<ChatMarket> chatMarkets);

        void UpdateItemFromChatVariableShortcut(ChatShortcutsItemViewModel viewModel,
                                                ChatVariableShortcut chatVariableShortcut);

        ChatShortcutsItemViewModel CreateNewItem(ObservableCollection<ChatIceMap> chatIceMaps,
                                                 ObservableCollection<ChatMarket> chatMarkets);

        ChatShortcutsMappingItemViewModel CreateNewMappingItem(ObservableCollection<ChatIceMap> chatIceMaps,
                                                               ObservableCollection<ChatMarket> chatMarkets);
    }
}
