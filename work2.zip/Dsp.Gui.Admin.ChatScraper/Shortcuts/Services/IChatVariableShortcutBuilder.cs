﻿using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    public interface IChatVariableShortcutBuilder
    {
        ChatVariableShortcut GetNewChatVariableShortcut(ChatShortcutsItemViewModel viewModel);
        ChatVariableShortcut GetUpdatedChatVariableShortcut(ChatShortcutsItemViewModel viewModel);
        ChatVariableShortcut GetDeletedChatVariableShortcut(ChatShortcutsItemViewModel viewModel);
    }
}
