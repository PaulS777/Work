﻿using Dsp.Gui.Admin.ChatScraper.Shortcuts.Rules;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Dashboard.Common.Services.DialogEditor;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    internal class ChatShortcutsItemValidationService : EditableItemValidationService<ChatShortcutsItemViewModel>,
                                                        IChatShortcutsItemValidationService
    {
        public ChatShortcutsItemValidationService(IChatShortcutsNameRule nameRule,
                                                  IChatShortcutsShortcutsRule shortcutsRule,
                                                  IChatShortcutsMappingsValidRule mappingsValidRule)
        :base(nameRule, shortcutsRule, mappingsValidRule)
        {
        }

        public override string IsDuplicateText() => "Duplicate Chat Shortcuts Name";
    }
}
