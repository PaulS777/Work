﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Services
{
    internal sealed class ChatShortcutsItemChangedObserver : IChatShortcutsItemChangedObserver
    {
        private readonly IChatShortcutsComparer _shortcutsComparer;
        private CompositeDisposable _disposables;
        private bool _disposed;

        public ChatShortcutsItemChangedObserver(IChatShortcutsComparer shortcutsComparer)
        {
            _shortcutsComparer = shortcutsComparer;
        }

        [ExcludeFromCodeCoverage]
        ~ChatShortcutsItemChangedObserver()
        {
            Dispose(false);
        }

        public void SubscribeUpdates(ChatShortcutsItemViewModel item)
        {
            _disposables?.Dispose();
            _disposables = new CompositeDisposable();

            item.ObservePropertyChanged(vm => vm.Name)
                .StartWith(item)
                .Subscribe(ValidateName)
                .AddTo(_disposables);

            item.ObservePropertyChanged(vm => vm.Shortcuts)
                .StartWith(item)
                .Subscribe(ValidateShortcuts)
                .AddTo(_disposables);

            item.ObservePropertyChanged(vm => vm.IsDuplicateShortcut)
                .StartWith(item)
                .Subscribe(ValidateShortcuts)
                .AddTo(_disposables);

            item.ObservePropertyChanged(vm => vm.Name)
                .Where(vm => !vm.NewRecord && vm.ChatVariableShortcut() != null)
                .Subscribe(CalculateIsDirty)
                .AddTo(_disposables);
            
            item.ObservePropertyChanged(vm => vm.Shortcuts)
                .Where(vm => !vm.NewRecord && vm.ChatVariableShortcut() != null)
                .Subscribe(CalculateIsDirty)
                .AddTo(_disposables);

            item.ObservePropertyChanged(vm => vm.ChatShortcutsMappingsChanged)
                .Where(vm => !vm.NewRecord)
                .Subscribe(CalculateIsDirty)
                .AddTo(_disposables);

            item.ObservePropertiesChanged(vm => vm.NameIsValid, vm => vm.IsDuplicate)
                .StartWith(item)
                .Subscribe(UpdateNameIsValidAndNotDuplicate)
                .AddTo(_disposables);
        }

        public void UnSubscribe()
        {
            _disposables?.Dispose();
        }

        private static void ValidateName(ChatShortcutsItemViewModel item)
        {
            item.NameIsValid = item.Name != null
                                && item.Name.Trim() != string.Empty;
        }

        private static void ValidateShortcuts(ChatShortcutsItemViewModel item)
        {
            if (item.Shortcuts == null || item.Shortcuts.Count == 0)
            {
                item.ShortcutsValid = false;
                item.ShortcutsValidText = "Missing Shortcuts";
            }
            else if (item.IsDuplicateShortcut)
            {
                item.ShortcutsValid = false;
                item.ShortcutsValidText = "Duplicate Shortcut";
            }
            else
            {
                item.ShortcutsValid = true;
                item.ShortcutsValidText = null;
            }
        }

        private static void UpdateNameIsValidAndNotDuplicate(ChatShortcutsItemViewModel item)
        {
            item.NameIsValidAndNotDuplicate = item.NameIsValid && !item.IsDuplicate;

            if (!item.NameIsValid)
            {
                item.NameValidationText = "Missing Name";
            }
            else if (item.IsDuplicate)
            {
                item.NameValidationText = "Duplicate Name";
            }
            else
            {
                item.NameValidationText = null;
            }
        }

        private void CalculateIsDirty(ChatShortcutsItemViewModel item)
        {
            item.NameChanged = item.Name != item.ChatVariableShortcut().Name;

            item.ShortcutsChanged = !_shortcutsComparer.CompareShortcuts(item.Shortcuts,
                                                                         item.ChatVariableShortcut()?.Shortcuts);

            item.IsDirty = item.NameChanged
                           || item.ShortcutsChanged
                           || item.ChatShortcutsMappingsChanged;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                UnSubscribe();
            }

            _disposed = true;
        }
    }
}
