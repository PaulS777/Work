﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.Services;
using Dsp.Gui.Admin.ChatScraper.Services.Shortcuts;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Dsp.ServiceContracts;
using Microsoft.Extensions.DependencyInjection;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers
{
    internal sealed class ChatShortcutsAdminViewModelController : IChatShortcutsAdminViewModelController
    {
        private readonly ICurveControlService _curveControlService;
        private readonly IChatScraperShortcutsAdminToolBarService _toolBarService;
        private readonly IChatShortcutsItemCollectionProvider _itemCollectionProvider;
        private readonly IChatShortcutsItemCollectionService _itemCollectionService;
        private readonly IChatIceMapDuplicateShortcutsService _duplicateShortcutsService;
        private readonly IChatVariableShortcutAdminUpdateService _chatVariableShortcutAdminUpdateService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly CompositeDisposable _disposables = new();
        private readonly ILogger _log;

        private bool _disposed;

        public ChatShortcutsAdminViewModelController(ICurveControlService curveControlService,
                                                     IChatScraperShortcutsAdminToolBarService toolBarService,
                                                     IChatShortcutsItemCollectionProvider itemCollectionProvider,
                                                     IChatShortcutsItemCollectionService itemCollectionService,
                                                     IChatIceMapDuplicateShortcutsService duplicateShortcutsService,
                                                     IChatVariableShortcutAdminUpdateService chatVariableShortcutAdminUpdateService, 
                                                     ISchedulerProvider schedulerProvider,
                                                     ILoggerFactory loggerFactory)
        {
            _curveControlService = curveControlService;
            _toolBarService = toolBarService;
            _itemCollectionProvider = itemCollectionProvider;
            _itemCollectionService = itemCollectionService;
            _duplicateShortcutsService = duplicateShortcutsService;
            _chatVariableShortcutAdminUpdateService = chatVariableShortcutAdminUpdateService;
            _schedulerProvider = schedulerProvider;
            _log = loggerFactory.Create(GetType().Name);

            ViewModel.ChatIceMaps = new ObservableCollection<ChatIceMap>();
            ViewModel.ChatMarkets = new ObservableCollection<ChatMarket>();

            ViewModel.AddShortcutsCommand = new DelegateCommand(OnAddChatShortcutsCommand);

            _toolBarService.Update
                           .Subscribe(_ => OnUpdateChatShortcutsCommand())
                           .AddTo(_disposables);

            _toolBarService.Undo
                           .Subscribe(_ => OnUndoChatShortcutsCommand())
                           .AddTo(_disposables);

            _itemCollectionService.CanExecuteUpdateCommand
                                  .Subscribe(OnCanExecuteUpdateCommand)
                                  .AddTo(_disposables);

            _itemCollectionService.CanExecuteUndoCommand
                                  .Subscribe(OnCanExecuteUndoCommand)
                                  .AddTo(_disposables);

            _itemCollectionService.ValidationErrors
                                  .Subscribe(OnValidationErrors)
                                  .AddTo(_disposables);

            var chatIceMapsAndMarkets = ChatIceMapsAndMarkets(_curveControlService.ChatIceMaps,
                                                              _curveControlService.ChatMarkets).Where(value => value)
                                                                                               .DistinctUntilChanged();
            
            var chatShortcuts = _curveControlService.ChatVariableShortcuts.Where(s => s != null);

            chatShortcuts.CombineLatest(chatIceMapsAndMarkets, (shortcuts, _) => shortcuts)
                         .ObserveOn(_schedulerProvider.Dispatcher)
                         .Subscribe(OnChatVariableShortcuts)
                         .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatShortcutsAdminViewModelController()
        {
            Dispose(false);
        }

        [Inject]
        public IChatShortcutsItemViewModelBuilder ChatShortcutsItemViewModelBuilder { get; set; }

        [Inject]
        public IChatVariableShortcutBuilder ChatVariableShortcutBuilder { get; set; }

        [Inject]
        public IErrorMessageDialogService ErrorMessageDialogService { get; set; }

        [Inject]
        public IPopupNotificationService PopupNotificationService { get; set; }

        public ChatShortcutsAdminViewModel ViewModel { get; } = new();

        private IObservable<bool> ChatIceMapsAndMarkets(IObservable<List<ChatIceMap>> chatIceMaps,
                                                        IObservable<List<ChatMarket>> chatMarkets)
        {
            return Observable.Create<bool>(obs =>
            {
                var disposable
                    = chatIceMaps.Where(iceMaps => iceMaps != null)
                                 .CombineLatest(chatMarkets.Where(markets => markets != null), 
                                                (i, m) => new {IceMaps = i, Markets = m })
                                 .ObserveOn(_schedulerProvider.Dispatcher)
                                 .Subscribe(value =>
                                 {
                                     ViewModel.ChatIceMaps.Clear();
                                     ViewModel.ChatIceMaps.AddRange(value.IceMaps);

                                     ViewModel.ChatMarkets.Clear();
                                     ViewModel.ChatMarkets.AddRange(value.Markets);

                                     obs.OnNext(true);
                                 });

                return () => disposable.Dispose();
            });
        }

        private void OnChatVariableShortcuts(IList<ChatVariableShortcut> shortcuts)
        {
            var viewModels 
                = _itemCollectionProvider.GetCollection(
                    ViewModel.ChatShortcuts,
                    shortcuts,
                    (vm, shortcut) => vm.Id == shortcut.Id,
                    (vm, shortcut) => ChatShortcutsItemViewModelBuilder.UpdateItemFromChatVariableShortcut(vm, shortcut),
                    shortcut => ChatShortcutsItemViewModelBuilder.CreateItemFromChatVariableShortcut(shortcut, 
                                                                                                     ViewModel.ChatIceMaps, 
                                                                                                     ViewModel.ChatMarkets));

            UpdateChatVariableShortcuts(viewModels);
        }

        private void UpdateChatVariableShortcuts(IList<ChatShortcutsItemViewModel> viewModels)
        {
            ViewModel.ChatShortcuts = new ObservableCollection<ChatShortcutsItemViewModel>(viewModels);

            foreach (var chatShortcuts in ViewModel.ChatShortcuts)
            {
                chatShortcuts.RefreshItemsCommand?.Execute();
            }

            _itemCollectionService.RefreshItems(viewModels);
            _duplicateShortcutsService.RefreshItems(viewModels);
        }

        private void OnAddChatShortcutsCommand()
        {
            var chatShortcuts = ChatShortcutsItemViewModelBuilder.CreateNewItem(ViewModel.ChatIceMaps, 
                                                                                ViewModel.ChatMarkets);

            _itemCollectionService.AddNewItem(chatShortcuts, 
                                              ViewModel.ChatShortcuts, 
                                              ViewModel);

            _duplicateShortcutsService.AddItem(chatShortcuts);

            chatShortcuts.RefreshItemsCommand?.Execute();
        }

        private void OnCanExecuteUpdateCommand(bool value)
        {
            _toolBarService.SetCanUpdate(value);
        }

        private void OnCanExecuteUndoCommand(bool value)
        {
            _toolBarService.SetCanUndo(value);
        }

        private void OnValidationErrors(IList<string> validationErrors)
        {
            if (validationErrors.Count == 0)
            {
                _toolBarService.ClearValidation();
            }
            else
            {
                _toolBarService.SetValidationErrors(validationErrors);
            }
        }

        private void OnUndoChatShortcutsCommand()
        {
            var chatVariableShortcuts = _curveControlService.GetChatVariableShortcutSnapshot().ToList();

            var viewModels =
                _itemCollectionProvider.GetCollectionReset(
                    chatVariableShortcuts,
                    shortcut => ChatShortcutsItemViewModelBuilder.CreateItemFromChatVariableShortcut(shortcut, 
                                                                                                     ViewModel.ChatIceMaps, 
                                                                                                     ViewModel.ChatMarkets));

            UpdateChatVariableShortcuts(viewModels);
        }

        private void OnUpdateChatShortcutsCommand()
        {
            ViewModel.IsBusy = true;
            ViewModel.BusyText = "Updating ICE Chat Shortcuts";

            var response
                = _chatVariableShortcutAdminUpdateService.Update(ViewModel.ChatShortcuts,
                                                                 _schedulerProvider.Dispatcher,
                                                                 ChatVariableShortcutBuilder.GetNewChatVariableShortcut,
                                                                 ChatVariableShortcutBuilder.GetUpdatedChatVariableShortcut,
                                                                 ChatVariableShortcutBuilder.GetDeletedChatVariableShortcut);

            response.ObserveOn(_schedulerProvider.Dispatcher)
                    .Subscribe(_ => OnUpdateComplete(),
                               OnError)
                    .AddTo(_disposables);
        }

        private void OnUpdateComplete()
        {
            _log.Info("Chat Shortcuts Update completed !");

            PopupNotificationService.SendPopupNotification("ICE Chat Shortcuts Updated");

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;
        }

        private void OnError(Exception ex)
        {
            _log.Error("Update failed !" + ex.Message);

            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;

            var args = new ErrorMessageDialogArgs("Chat Shortcuts Update Failed", ex.Message, true);

            ErrorMessageDialogService.ShowDialog(args);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _itemCollectionService.Dispose();
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
