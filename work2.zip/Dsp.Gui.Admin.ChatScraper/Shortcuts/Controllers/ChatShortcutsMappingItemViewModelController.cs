﻿using System;
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers
{
    internal sealed class ChatShortcutsMappingItemViewModelController : IChatShortcutsMappingItemViewModelController
    {
        private readonly IChatShortcutsMappingItemSubscribeUpdatesService _subscribeUpdatesService;

        private bool _disposed;

        public ChatShortcutsMappingItemViewModelController(IChatShortcutsMappingItemSubscribeUpdatesService subscribeUpdatesService)
        {
            ViewModel = new ChatShortcutsMappingItemViewModel(this);

            _subscribeUpdatesService = subscribeUpdatesService;

            ViewModel.DeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = true);
            ViewModel.UndoDeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = false);

            _subscribeUpdatesService.Attach(ViewModel);
        }

        [ExcludeFromCodeCoverage]
        ~ChatShortcutsMappingItemViewModelController()
        {
            Dispose(false);
        }

        public ChatShortcutsMappingItemViewModel ViewModel { get; }
        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _subscribeUpdatesService.Dispose();
            }

            _disposed = true;
        }
    }
}
