﻿using System;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers
{
    public interface IChatShortcutsMappingItemViewModelController : IDisposable
    {
        ChatShortcutsMappingItemViewModel ViewModel { get; }
    }
}
