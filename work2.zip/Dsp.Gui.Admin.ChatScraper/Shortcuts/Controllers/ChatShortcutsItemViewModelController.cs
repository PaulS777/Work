﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.Services.Mappings;
using Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels;
using Dsp.Gui.Common.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.Controllers
{
    internal sealed class ChatShortcutsItemViewModelController : IChatShortcutsItemViewModelController
    {
        private readonly IChatShortcutsSubscribeUpdatesService _subscribeUpdatesService;
        private readonly IChatShortcutsMappingItemCollectionService _itemCollectionService;
        private readonly CompositeDisposable _disposables = new();

        private bool _disposed;

        public ChatShortcutsItemViewModelController(IChatShortcutsSubscribeUpdatesService subscribeUpdatesService, 
                                                    IChatShortcutsMappingItemCollectionService itemCollectionService)
        {
            ViewModel = new ChatShortcutsItemViewModel(this);

            _subscribeUpdatesService = subscribeUpdatesService;
            _itemCollectionService = itemCollectionService;

            ViewModel.DeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = true);
            ViewModel.UndoDeleteCommand = new DelegateCommand(() => ViewModel.IsDeleted = false);

            ViewModel.RefreshItemsCommand = new DelegateCommand(OnRefreshItemsCommand);
            ViewModel.AddItemCommand = new DelegateCommand(OnAddItemCommand);

            _subscribeUpdatesService.Attach(ViewModel);

            _itemCollectionService.ValidationErrors
                                  .Subscribe(errors => ViewModel.ChatShortcutsMappingsValid = !errors.Any())
                                  .AddTo(_disposables);

            _itemCollectionService.CanExecuteUndoCommand
                                  .Subscribe(value => ViewModel.ChatShortcutsMappingsChanged = value)
                                  .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatShortcutsItemViewModelController()
        {
            Dispose(false);
        }

        [Inject]
        public IChatShortcutsItemViewModelBuilder ChatShortcutsItemViewModelBuilder { get; set; }

        public ChatShortcutsItemViewModel ViewModel { get; }

        private void OnRefreshItemsCommand()
        {
            _itemCollectionService.RefreshItems(ViewModel.ChatShortcutsMappings);
        }

        private void OnAddItemCommand()
        {
            var mapping = ChatShortcutsItemViewModelBuilder.CreateNewMappingItem(ViewModel.ChatIceMaps(), 
                                                                                 ViewModel.ChatMarkets());

            _itemCollectionService.AddNewItem(mapping, ViewModel.ChatShortcutsMappings);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _subscribeUpdatesService.Dispose();
                _itemCollectionService.Dispose();

                if (ViewModel.ChatShortcutsMappings != null)
                {
                    foreach (var chatShortcutRow in ViewModel.ChatShortcutsMappings)
                    {
                        chatShortcutRow.Dispose();
                    }
                }
            }

            _disposed = true;
        }
    }
}
