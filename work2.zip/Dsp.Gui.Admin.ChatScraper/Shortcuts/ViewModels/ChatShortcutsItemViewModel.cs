﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Admin.ChatScraper.ViewModels;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels
{
    public sealed class ChatShortcutsItemViewModel : EditableItem, IEditableItemWithShortcuts
    {
        private readonly IDisposable _controller;
        private string _name;
        private IList<object> _shortcuts;
        private ObservableCollection<ChatShortcutsMappingItemViewModel> _chatShortcutsMappings;

        private bool _nameChanged;
        private bool _shortcutsChanged;
        private bool _chatShortcutsMappingsChanged;

        private bool _nameIsValid;
        private bool _nameIsValidAndNotDuplicate;
        private bool _shortcutsValid;
        private bool _isDuplicateShortcut;
        private bool _chatShortcutsMappingsValid;
        private string _shortcutsValidText;
        private string _nameValidationText;

        private ChatVariableShortcut _chatVariableShortcut;
        private ObservableCollection<ChatIceMap> _chatIceMaps;
        private ObservableCollection<ChatMarket> _chatMarkets;

        private bool _disposed;

        public ChatShortcutsItemViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        [ExcludeFromCodeCoverage]
        ~ChatShortcutsItemViewModel()
        {
            Dispose(false);
        }

        public void SetChatVariableShortcut(ChatVariableShortcut value) => _chatVariableShortcut = value;
        public ChatVariableShortcut ChatVariableShortcut() => _chatVariableShortcut;

        public void SetChatIceMaps(ObservableCollection<ChatIceMap> values) => _chatIceMaps = values;
        public ObservableCollection<ChatIceMap> ChatIceMaps() => _chatIceMaps;

        public void SetChatMarkets(ObservableCollection<ChatMarket> values) => _chatMarkets = values;
        public ObservableCollection<ChatMarket> ChatMarkets() => _chatMarkets;

        public DelegateCommand DeleteCommand { get; set; }
        public DelegateCommand UndoDeleteCommand { get; set; }
        public DelegateCommand RefreshItemsCommand { get; set; }
        public DelegateCommand AddItemCommand { get; set; }

        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                RaisePropertyChanged();
            }
        }

        public IList<object> Shortcuts
        {
            get => _shortcuts;
            set
            {
                if (_shortcuts != null && _shortcuts.SequenceEqual(value))
                {
                    return;
                }
                
                _shortcuts = value;
                RaisePropertyChanged();
            }
        }

        public bool IsDuplicateShortcut
        {
            get => _isDuplicateShortcut;
            set
            {
                _isDuplicateShortcut = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<ChatShortcutsMappingItemViewModel> ChatShortcutsMappings
        {
            get => _chatShortcutsMappings;
            set
            {
                _chatShortcutsMappings = value;
                RaisePropertyChanged();
            }
        }

        public bool NameChanged
        {
            get => _nameChanged;
            set
            {
                _nameChanged = value;
                RaisePropertyChanged();
            }
        }

        public bool ShortcutsChanged
        {
            get => _shortcutsChanged;
            set
            {
                _shortcutsChanged = value;
                RaisePropertyChanged();
            }
        }

        public bool ChatShortcutsMappingsChanged
        {
            get => _chatShortcutsMappingsChanged;
            set
            {
                _chatShortcutsMappingsChanged = value;
                RaisePropertyChanged();
            }
        }

        public bool NameIsValid
        {
            get => _nameIsValid;
            set
            {
                _nameIsValid = value;
                RaisePropertyChanged();
            }
        }

        public bool NameIsValidAndNotDuplicate
        {
            get => _nameIsValidAndNotDuplicate;
            set
            {
                _nameIsValidAndNotDuplicate = value;
                RaisePropertyChanged();
            }
        }

        public bool ShortcutsValid
        {
            get => _shortcutsValid;
            set
            {
                _shortcutsValid = value;
                RaisePropertyChanged();
            }
        }

        public bool ChatShortcutsMappingsValid
        {
            get => _chatShortcutsMappingsValid;
            set
            {
                _chatShortcutsMappingsValid = value;
                RaisePropertyChanged();
            }
        }

        public string ShortcutsValidText
        {
            get => _shortcutsValidText;
            set
            {
                _shortcutsValidText = value;
                RaisePropertyChanged();
            }
        }

        public string NameValidationText
        {
            get => _nameValidationText;
            set
            {
                _nameValidationText = value;
                RaisePropertyChanged();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller?.Dispose();
            }

            _disposed = true;
        }
    }
}
