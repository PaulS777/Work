﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels
{
    /// <summary>
    /// Similar to CalendarRowViewModel
    /// </summary>
    public sealed class ChatShortcutsMappingItemViewModel : EditableItem
    {
        private readonly IDisposable _controller;

        private ChatVariableShortcutVariation _variation;
        private ChatIceMap _iceMap; 
        private ChatMarket _market;
        private ObservableCollection<ChatIceMap> _chatIceMaps;
        private ObservableCollection<ChatMarket> _chatMarkets;

        private bool _disposed;

        public ChatShortcutsMappingItemViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        [ExcludeFromCodeCoverage]
        ~ChatShortcutsMappingItemViewModel()
        {
            Dispose(false);
        }

        public void SetVariation(ChatVariableShortcutVariation value) => _variation = value;
        public ChatVariableShortcutVariation Variation() => _variation;

        public DelegateCommand DeleteCommand { get; set; }
        public DelegateCommand UndoDeleteCommand { get; set; }

        public ChatIceMap IceMap
        {
            get => _iceMap;
            set
            {
                if (_iceMap == value)
                {
                    return;
                }

                _iceMap = value;
                RaisePropertyChanged();
            }
        }

        public ChatMarket Market
        {
            get => _market;
            set
            {
                if (_market == value)
                {
                    return;
                }
                
                _market = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<ChatIceMap> ChatIceMaps
        {
            get => _chatIceMaps;
            set
            {
                _chatIceMaps = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<ChatMarket> ChatMarkets
        {
            get => _chatMarkets;
            set
            {
                _chatMarkets = value;
                RaisePropertyChanged();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller?.Dispose();
            }

            _disposed = true;
        }
    }
}
