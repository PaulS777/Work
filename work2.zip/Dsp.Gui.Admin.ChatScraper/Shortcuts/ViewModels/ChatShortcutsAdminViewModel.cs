﻿using System.Collections.ObjectModel;
using Dsp.DataContracts.ChatScraper;
using Dsp.Gui.Dashboard.Common.ViewModels.DialogEditor;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.Admin.ChatScraper.Shortcuts.ViewModels
{
    public class ChatShortcutsAdminViewModel : BindableBase, IEditableItemCollectionDialog
    {
        private ObservableCollection<ChatShortcutsItemViewModel> _chatShortcuts;
        private ObservableCollection<ChatIceMap> _chatIceMaps;
        private ObservableCollection<ChatMarket> _chatMarkets;
        private IEditableItem _selectedItem;
        private bool _canFilterRows;
        private string _searchText;
        private bool _isBusy;
        private string _busyText;
        
        public DelegateCommand AddShortcutsCommand { get; set; }

        public ObservableCollection<ChatShortcutsItemViewModel> ChatShortcuts
        {
            get => _chatShortcuts;
            set
            {
                _chatShortcuts = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<ChatIceMap> ChatIceMaps
        {
            get => _chatIceMaps;
            set
            {
                _chatIceMaps = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<ChatMarket> ChatMarkets
        {
            get => _chatMarkets;
            set
            {
                _chatMarkets = value;
                RaisePropertyChanged();
            }
        }

        public IEditableItem SelectedItem
        {
            get => _selectedItem;
            set
            {
                _selectedItem = value;
                RaisePropertyChanged();
            }
        }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        public string BusyText
        {
            get => _busyText;
            set
            {
                _busyText = value;
                RaisePropertyChanged();
            }
        }

        public bool CanFilterRows
        {
            get => _canFilterRows;
            set
            {
                _canFilterRows = value;
                RaisePropertyChanged();
            }
        }

        public string SearchText
        {
            get => _searchText;
            set
            {
                _searchText = value;
                RaisePropertyChanged();
            }
        }
    }
}
