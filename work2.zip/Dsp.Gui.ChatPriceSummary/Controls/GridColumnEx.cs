﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using DevExpress.Xpf.Grid;

namespace Dsp.Gui.ChatPriceSummary.Controls
{
    [ExcludeFromCodeCoverage]
    public class GridColumnEx : GridColumn
    {
        public static readonly DependencyProperty AdjustedWidthProperty =
            DependencyProperty.Register(
                "AdjustedWidth",
                typeof(double),
                typeof(GridColumnEx),
                new PropertyMetadata(0d, null));

        public double AdjustedWidth
        {
            get => (double)GetValue(AdjustedWidthProperty);
            set => SetValue(AdjustedWidthProperty, value);
        }
    }
}
