﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DevExpress.Xpf.Editors;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.Controls
{
    [ExcludeFromCodeCoverage]
    public class MarketsHeaderControl : Control
    {
        static MarketsHeaderControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(MarketsHeaderControl), new FrameworkPropertyMetadata(typeof(MarketsHeaderControl)));
        }

        public static readonly DependencyProperty HeaderTextProperty =
            DependencyProperty.Register(
                nameof(HeaderText),
                typeof(string),
                typeof(MarketsHeaderControl),
                new PropertyMetadata(null));

        public string HeaderText
        {
            get => (string)GetValue(HeaderTextProperty);
            set => SetValue(HeaderTextProperty, value);
        }

        public static readonly DependencyProperty SetSelectedCommandProperty =
            DependencyProperty.Register(
                nameof(SetSelectedCommand),
                typeof(DelegateCommand),
                typeof(MarketsHeaderControl),
                new PropertyMetadata(null));

        public DelegateCommand SetSelectedCommand
        {
            get => (DelegateCommand) GetValue(SetSelectedCommandProperty);
            set => SetValue(SetSelectedCommandProperty, value);
        }

        public static readonly DependencyProperty RemoveMarketsCommandProperty =
            DependencyProperty.Register(
                nameof(RemoveMarketsCommand),
                typeof(DelegateCommand),
                typeof(MarketsHeaderControl),
                new PropertyMetadata(null));

        public DelegateCommand RemoveMarketsCommand
        {
            get => (DelegateCommand)GetValue(RemoveMarketsCommandProperty);
            set => SetValue(RemoveMarketsCommandProperty, value);
        }

        public static readonly DependencyProperty RemoveMarketsVisibilityProperty =
            DependencyProperty.Register(
                nameof(RemoveMarketsVisibility),
                typeof(Visibility),
                typeof(MarketsHeaderControl),
                new PropertyMetadata(Visibility.Visible));

        public Visibility RemoveMarketsVisibility
        {
            get => (Visibility)GetValue(RemoveMarketsVisibilityProperty);
            set => SetValue(RemoveMarketsVisibilityProperty, value);
        }

        public static readonly DependencyProperty NameEditorCommandProperty =
            DependencyProperty.Register(
                nameof(NameEditorCommand),
                typeof(DelegateCommand),
                typeof(MarketsHeaderControl),
                new PropertyMetadata(null));

        public DelegateCommand NameEditorCommand
        {
            get => (DelegateCommand)GetValue(NameEditorCommandProperty);
            set => SetValue(NameEditorCommandProperty, value);
        }

        public override void OnApplyTemplate()
        {
            if (Template.FindName("PART_TextEdit", this) is TextEdit textEdit
                && Template.FindName("PART_EditButton", this) is Button editButton)
            {
                textEdit.PreviewKeyDown += TextEditOnPreviewKeyDown;
                editButton.Click += EditButtonOnClick;
            }

            base.OnApplyTemplate();
        }

        private void EditButtonOnClick(object sender, RoutedEventArgs e)
        {
            var textEdit = (TextEdit)Template.FindName("PART_TextEdit", this);
            var selectButton = (Button)Template.FindName("PART_SelectButton", this);

            selectButton.Visibility = Visibility.Hidden;
            textEdit.Visibility = Visibility.Visible;
 
            textEdit.Focus();
        }

        private void TextEditOnPreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter && e.Key != Key.Tab)
            {
                return;
            }

            var textEdit = (TextEdit)Template.FindName("PART_TextEdit", this);
            var button = (Button)Template.FindName("PART_SelectButton", this);

            textEdit.Visibility = Visibility.Hidden;
            button.Visibility = Visibility.Visible;
        }
    }
}
