﻿using System;
using Dsp.DataContracts;

namespace Dsp.Gui.ChatPriceSummary.Common
{
    public class ChatPrice
    {
        public ChatPrice(int id, ITenor tenor)
        {
            Id = id;
            Tenor = tenor;
        }

        public int Id { get; }
        public ITenor Tenor { get; }
        public DateTime? BidTime { get; set; }
        public DateTime? AskTime { get; set; }
    }
}
