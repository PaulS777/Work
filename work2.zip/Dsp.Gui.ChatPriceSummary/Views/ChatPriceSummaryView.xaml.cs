﻿using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.ChatPriceSummary.Controllers;

namespace Dsp.Gui.ChatPriceSummary.Views
{
    [ExcludeFromCodeCoverage]
    public partial class ChatPriceSummaryView
    {
        public ChatPriceSummaryView(IChatPriceSummaryViewModelController controller)
        {
            DataContext = controller.ViewModel;
            InitializeComponent();
        }
    }
}
