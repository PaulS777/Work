﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.ChatPriceSummary.Views
{
    [ExcludeFromCodeCoverage]
    public partial class ChatPriceMarketsControl 
    {
        public ChatPriceMarketsControl()
        {
            InitializeComponent();
        }
    }
}
