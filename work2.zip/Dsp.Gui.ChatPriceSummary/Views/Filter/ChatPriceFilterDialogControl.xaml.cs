﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.ChatPriceSummary.Views.Filter
{
    [ExcludeFromCodeCoverage]
    public partial class ChatPriceFilterDialogControl 
    {
        public ChatPriceFilterDialogControl()
        {
            InitializeComponent();
        }
    }
}
