﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.TemplateSelectors
{
    [ExcludeFromCodeCoverage]
    public class PriceColumnTemplateSelector : DataTemplateSelector
    {
        public DataTemplate BidBrokerColumnTemplate { get; set; }
        public DataTemplate BidTimeColumnTemplate { get; set; }
        public DataTemplate BidPriceColumnTemplate { get; set; }
        public DataTemplate AskBrokerColumnTemplate { get; set; }
        public DataTemplate AskTimeColumnTemplate { get; set; }
        public DataTemplate AskPriceColumnTemplate { get; set; }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var columnInfo = (ColumnInfo)item;

            if (columnInfo == null)
            {
                return null;
            }

            switch (columnInfo.ColumnType)
            {
                case ColumnType.BidBroker:
                    return BidBrokerColumnTemplate;
                case ColumnType.BidTime:
                    return BidTimeColumnTemplate;
                case ColumnType.BidPrice:
                    return BidPriceColumnTemplate;
                case ColumnType.AskBroker:
                    return AskBrokerColumnTemplate;
                case ColumnType.AskTime:
                    return AskTimeColumnTemplate;
                case ColumnType.AskPrice:
                    return AskPriceColumnTemplate;
                default:
                    return null;
            }
        }
    }
}
