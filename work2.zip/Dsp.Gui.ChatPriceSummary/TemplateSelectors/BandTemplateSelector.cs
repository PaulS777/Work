﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.TemplateSelectors
{
    [ExcludeFromCodeCoverage]
    public class BandTemplateSelector : DataTemplateSelector
    {
        public DataTemplate TenorBandTemplate { get; set; }
        public DataTemplate PriceBandTemplate { get; set; }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var bandInfo = (BandInfo)item;

            if (bandInfo == null)
            {
                return null;
            }

            switch (bandInfo.BandType)
            {
                case BandType.Tenor:
                    return TenorBandTemplate;
                case BandType.Price:
                    return PriceBandTemplate;
                default:
                    return null;
            }
        }
    }
}
