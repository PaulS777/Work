﻿// ***********************************************************************************************************************
// ChatPriceSummaryModule.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.ChatPriceSummary.Controllers;
using Dsp.Gui.ChatPriceSummary.Controllers.Filter;
using Dsp.Gui.ChatPriceSummary.Services.Filter;
using Dsp.Gui.ChatPriceSummary.Services.GridBuilder;
using Dsp.Gui.ChatPriceSummary.Services.GridUpdate;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.Views;
using Dsp.Gui.Common.Extensions;
using Microsoft.Extensions.DependencyInjection;
using ServiceCollection.Extensions.Modules;

namespace Dsp.Gui.ChatPriceSummary
{
    public class ChatPriceSummaryModule : Module
    {
        [ExcludeFromCodeCoverage]
        protected override void Load(IServiceCollection services)
        {
            base.Load(services);

            services.AddSingleton<ChatPriceSummaryView>();

            services.AddSingleton<IChatPriceSummarySettingsFileProvider, ChatPriceSummarySettingsFileProvider>();
            services.AddSingleton<IChatPriceSummarySettingsBuilder, ChatPriceSummarySettingsBuilder>();
            services.AddSingleton<IChatPriceSummarySettingsService, ChatPriceSummarySettingsService>();
            services.AddSingleton<IBandInfoProvider, BandInfoProvider>();
            services.AddSingleton<IChatTenorTreeGenerator, ChatTenorTreeGenerator>();
            services.AddSingleton<IChatPriceGridBuilder, ChatPriceGridBuilder>();
            services.AddSingleton<IChatPriceDictionaryService, ChatPriceDictionaryService>();
            services.AddSingleton<IChatPriceSummaryViewModelController, ChatPriceSummaryViewModelController>();
            services.AddSingleton<IChatPriceCurveFilterItemsProvider, ChatPriceCurveFilterItemsProvider>();
            services.AddSingleton<IChatPriceMarketsBuilder, ChatPriceMarketsBuilder>();
            services.AddSingleton<IChatPriceCurveFilterCurveGroupBuilder, ChatPriceCurveFilterCurveGroupBuilder>();
            services.AddSingleton<IChatPriceGridRemovalServiceCache, ChatPriceGridRemovalServiceCache>();
            services.AddSingleton<IChatPriceMarketsRemovalService, ChatPriceMarketsRemovalService>();

            services.AddTransient<IChatPriceFilterDialogViewModelController, ChatPriceFilterDialogViewModelController>();
            services.AddTransient<IChatPriceGridRemovalService, ChatPriceGridRemovalService>();
            services.AddTransient<IChatPriceColumnWidthService, ChatPriceColumnWidthService>();
            services.AddTransient<IChatPriceMarketsViewModelController, ChatPriceMarketsViewModelController>();
            services.AddTransient<IColumnFilterLoadedService, ColumnFilterLoadedService>();
            services.AddTransient<IColumnFilterDialogService, ColumnFilterDialogService>();
            services.AddTransient<ICurveFilterLoadedService, CurveFilterLoadedService>();
            services.AddTransient<ICurveFilterDialogService, CurveFilterDialogService>();

            services.AddTransient<IChatPriceSummaryStreamProvider, ChatPriceSummaryStreamProvider>();
            services.AddTransient<IChatPriceUpdateService, ChatPriceUpdateService>();
            services.AddTransient<IChatPriceGridRefreshService, ChatPriceGridRefreshService>();
            services.AddTransient<IChatPriceGridViewModelController, ChatPriceGridViewModelController>();
            services.AddTransient<IChatPriceSummaryMonitor, ChatPriceSummaryMonitor>();
            services.AddTransient<IChatPriceCurveFilterRegionController, ChatPriceCurveFilterRegionController>();

            services.AddFactory<IChatPriceSummaryMonitor, ChatPriceSummaryMonitor>();
            services.AddFactory<IChatPriceCurveFilterRegionController, ChatPriceCurveFilterRegionController>();
            services.AddFactory<IChatPriceGridRemovalService, ChatPriceGridRemovalService>();
            services.AddFactory<IChatPriceMarketsViewModelController, ChatPriceMarketsViewModelController>();
            services.AddFactory<IChatPriceGridViewModelController, ChatPriceGridViewModelController>();

            services.AddPropertyInjectedServices();
        }
    }
}
