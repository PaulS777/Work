﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using DevExpress.Mvvm.UI.Interactivity;
using System.Windows.Data;
using Dsp.Gui.ChatPriceSummary.Controls;

namespace Dsp.Gui.ChatPriceSummary.Behaviors
{
    [ExcludeFromCodeCoverage]
    public class ColumnAdjustedWidthBehavior : Behavior<GridColumnEx>
    {
        protected static readonly DependencyProperty ColumnActualWidthProperty = 
            DependencyProperty.Register("ColumnActualWidth",
                                        typeof(double),
                                        typeof(ColumnAdjustedWidthBehavior),
                                        new PropertyMetadata(0d, OnActualWidthChanged));

        protected double ColumnActualWidth
        {
            get => (double)GetValue(ColumnActualWidthProperty);
            set => SetValue(ColumnActualWidthProperty, value);
        }

        private static void OnActualWidthChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var helper = (ColumnAdjustedWidthBehavior)obj;

            helper.AssociatedObject.SetValue(GridColumnEx.AdjustedWidthProperty, (double)args.NewValue);
        }

        protected override void OnAttached()
        {
            base.OnAttached();

            BindingOperations.SetBinding(this,
                                         ColumnActualWidthProperty,
                                         new Binding("ActualWidth")
                                         {
                                             Source = AssociatedObject
                                         });
        }

        protected override void OnDetaching()
        {
            ClearValue(ColumnActualWidthProperty);
            base.OnDetaching();
        }
    }
}
