﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public interface IChatPriceCurveFilterItemsProvider
    {
        IObservable<IList<ChatPriceCurveFilterItem>> ChatPriceFilterItems();
    }
}
