﻿using System;
using System.Collections.Generic;
using System.Reactive;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public interface IFilterDialogService<T> : IDisposable
    where T : class, ISelectableFilterItem
    {
        IObservable<Unit> ApplyFilterChangesCommand { get; }
        void AttachFilterDialog(IDialogFilter<T> dialogFilter);
        void RefreshFilterItems(IList<T> filterItems);
    }
}
