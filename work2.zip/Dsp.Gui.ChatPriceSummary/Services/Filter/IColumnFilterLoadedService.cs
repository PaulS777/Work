﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public interface IColumnFilterLoadedService : IDisposable
    {
        void Initialize();
        void Initialize(ChatPriceGridSettings settings);
        IObservable<List<ChatPriceColumnFilterItem>> ColumnFilter { get; }
    }
}
