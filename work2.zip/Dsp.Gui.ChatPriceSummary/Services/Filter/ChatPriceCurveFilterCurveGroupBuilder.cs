﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.Controllers.Filter;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public class ChatPriceCurveFilterCurveGroupBuilder : IChatPriceCurveFilterCurveGroupBuilder
    {
        [Inject]
        public IServiceFactory<IChatPriceCurveFilterRegionController> CurveFilterRegionFactory { get; set; }

        public List<ChatPriceCurveFilterGroup> GetCurveFilterGroups(IList<ChatPriceCurveFilterItem> curveFilterItems)
        {
            return curveFilterItems.OrderBy(i => i.PriceCurveName)
                                   .GroupBy(i => i.CurveGroup)
                                   .Select(GetChatPriceCurveFilterGroup)
                                   .ToList();
        }

        private ChatPriceCurveFilterGroup GetChatPriceCurveFilterGroup(IGrouping<CurveGroup, ChatPriceCurveFilterItem> grouping)
        {
            var curveFilterGroup = new ChatPriceCurveFilterGroup(grouping.Key);

            var regions = grouping.GroupBy(g => g.CurveRegion)
                                  .Select(GetChatPriceCurveFilterRegion)
                                  .ToList();

            curveFilterGroup.CurveFilterRegions = regions;
            
            return curveFilterGroup;
        }

        private ChatPriceCurveFilterRegion GetChatPriceCurveFilterRegion(IGrouping<CurveRegion, ChatPriceCurveFilterItem> grouping)
        {
            var controller = CurveFilterRegionFactory.Create();

            controller.ViewModel.RegionHeader = new CurveRegionFilterHeader(grouping.Key);
            controller.ViewModel.Items = grouping.ToList();

            return controller.ViewModel;
        }
    }
}
