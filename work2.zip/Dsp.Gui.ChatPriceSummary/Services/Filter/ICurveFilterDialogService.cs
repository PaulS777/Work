﻿using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public interface ICurveFilterDialogService : IFilterDialogService<ChatPriceCurveFilterItem>
    {
    }
}
