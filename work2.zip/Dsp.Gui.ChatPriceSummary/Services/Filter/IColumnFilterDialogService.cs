﻿using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public interface IColumnFilterDialogService : IFilterDialogService<ChatPriceColumnFilterItem>
    {
    }
}
