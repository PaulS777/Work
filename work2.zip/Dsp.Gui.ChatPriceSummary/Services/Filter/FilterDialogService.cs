﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Extensions;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public class FilterDialogService<T> : IFilterDialogService<T>
        where T : class, ISelectableFilterItem
    {
        private readonly CompositeDisposable _disposables = new();
        private readonly Subject<Unit> _applyFilterCommand = new();
        private IDialogFilter<T> _dialogFilter;
        private CompositeDisposable _filterItemsDisposables = new();
        private bool _disposed;

        public void AttachFilterDialog(IDialogFilter<T> dialogFilter)
        {
            _dialogFilter = dialogFilter;

            _dialogFilter.ApplyFilterChangesCommand = new DelegateCommand(OnApplyFilterChangesCommand, 
                                                                          () => _dialogFilter.CanApplyFilterChanges);

            _dialogFilter.CancelFilterChangesCommand = new DelegateCommand(OnCancelFilterChangesCommand, 
                                                                           () => _dialogFilter.CanCancelFilterChanges);

            _dialogFilter.ObservePropertyChanged(d => d.CanRemoveFilter)
                         .Subscribe(_ => OnCanRemoveFilter())
                         .AddTo(_disposables);

            _dialogFilter.ObservePropertyChanged(d => d.ShowFilter)
                         .Where(d => !d.ShowFilter)
                         .Subscribe(_ => ResetFilterWithOriginalIsSelected())
                         .AddTo(_disposables);
        }

        public IObservable<Unit> ApplyFilterChangesCommand => _applyFilterCommand.AsObservable();

        public void RefreshFilterItems(IList<T> filterItems)
        {
            _filterItemsDisposables?.Dispose();
            _filterItemsDisposables = new CompositeDisposable();

            if (_dialogFilter.FilterItems is { Count: > 0 })
            {
                foreach (var item in filterItems)
                {
                    var existing = _dialogFilter.FilterItems.FirstOrDefault(i => i.CompareTo(item) == 0);

                    if (existing == null)
                    {
                        continue;
                    }

                    item.IsSelected = existing.IsSelected;
                    item.OriginalIsSelected = existing.OriginalIsSelected;
                }
            }

            foreach (var item in filterItems)
            {
                item.ObservePropertyChanged(vm => vm.IsSelected)
                    .Subscribe(_ => RecalculateCanExecuteCommands(filterItems))
                    .AddTo(_filterItemsDisposables);
            }

            RecalculateCanExecuteCommands(filterItems);
        }

        private void OnApplyFilterChangesCommand()
        {
            foreach (var item in _dialogFilter.FilterItems)
            {
                item.OriginalIsSelected = item.IsSelected;
            }

            RecalculateCanExecuteCommands(_dialogFilter.FilterItems);

            _applyFilterCommand.OnNext(Unit.Default);
        }

        private void OnCancelFilterChangesCommand() => _dialogFilter.ShowFilter = false;

        private void ResetFilterWithOriginalIsSelected()
        {
            foreach (var item in _dialogFilter.FilterItems)
            {
                item.IsSelected = item.OriginalIsSelected;
            }

            RecalculateCanExecuteCommands(_dialogFilter.FilterItems);
        }

        private void OnCanRemoveFilter()
        {
            RecalculateCanExecuteCommands(_dialogFilter.FilterItems);
        }

        private void RecalculateCanExecuteCommands(IList<T> filterItems)
        {
            _dialogFilter.CanCancelFilterChanges = _dialogFilter.CanRemoveFilter 
                                                   || filterItems.Any(i => i.OriginalIsSelected);

            _dialogFilter.CanApplyFilterChanges = filterItems.Any(i => i.IsSelected) 
                                                  && filterItems.Any(i => i.IsSelected != i.OriginalIsSelected);

            _dialogFilter.CancelFilterChangesCommand.RaiseCanExecuteChanged();
            _dialogFilter.ApplyFilterChangesCommand.RaiseCanExecuteChanged();
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _filterItemsDisposables.Dispose();
            }

            _disposed = true;
        }
    }
}
