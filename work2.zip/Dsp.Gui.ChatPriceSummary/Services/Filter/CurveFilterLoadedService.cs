﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public sealed class CurveFilterLoadedService : ICurveFilterLoadedService
    {
        private readonly IChatPriceCurveFilterItemsProvider _filterItemsProvider;
        private readonly BehaviorSubject<List<ChatPriceCurveFilterItem>> _curveFilter = new(null);
        private CompositeDisposable _disposables = new();

        private bool _disposed;

        public CurveFilterLoadedService(IChatPriceCurveFilterItemsProvider filterItemsProvider)
        {
            _filterItemsProvider = filterItemsProvider;
        }

        [ExcludeFromCodeCoverage]
        ~CurveFilterLoadedService()
        {
            Dispose(false);
        }

        public IObservable<List<ChatPriceCurveFilterItem>> CurveFilter => _curveFilter.AsObservable();

        public void Initialize()
        {
            _disposables?.Dispose();
            _disposables = new CompositeDisposable();

            _filterItemsProvider.ChatPriceFilterItems()
                                .Where(i => i != null)
                                .Select(CloneChatPriceFilterItems)
                                .Subscribe(_curveFilter.OnNext)
                                .AddTo(_disposables);
        }

        public void Initialize(ChatPriceGridSettings settings)
        {
            _disposables?.Dispose();
            _disposables = new CompositeDisposable();

            _filterItemsProvider.ChatPriceFilterItems()
                                .Where(i => i != null)
                                .Select(CloneChatPriceFilterItems)
                                .Subscribe(items => ApplyFilterSettings(items, settings))
                                .AddTo(_disposables);
        }

        private static List<ChatPriceCurveFilterItem> CloneChatPriceFilterItems(IEnumerable filterItems)
        {
            var items = filterItems.Cast<ICloneable>()
                                   .Select(i => i.Clone())
                                   .Cast<ChatPriceCurveFilterItem>()
                                   .ToList();
            return items;
        }

        // Apply settings to items on initial load and publish
        private void ApplyFilterSettings(List<ChatPriceCurveFilterItem> filterItems,
                                         ChatPriceGridSettings settings)
        {
            if (settings != null)
            {
                foreach (var item in filterItems)
                {
                    item.OriginalIsSelected =  Array.Exists(settings.MarketBands, m => m.ChatPriceSummaryId == item.Id);

                    item.IsSelected = item.OriginalIsSelected;
                }
            }

            _curveFilter.OnNext(filterItems);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables?.Dispose();
            }

            _disposed = true;
        }
    }
}
