﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Curve;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public class ChatPriceCurveFilterItemsProvider : IChatPriceCurveFilterItemsProvider
    {
        private readonly ICurveControlService _curveControlService;

        public ChatPriceCurveFilterItemsProvider(ICurveControlService curveControlService)
        {
            _curveControlService = curveControlService;
        }

        public IObservable<IList<ChatPriceCurveFilterItem>> ChatPriceFilterItems()
        {
            return Observable.Create<IList<ChatPriceCurveFilterItem>>(obs =>
            {
                var disposables = new CompositeDisposable();

                var snapshot = _curveControlService.ChatPriceSummarySnapshot
                                                   .Where(cp => cp != null)
                                                   .Take(1);

                var mappings = _curveControlService.ChatIceMaps
                                                   .Where(maps => maps != null);

                var priceCurveDefinitions = _curveControlService.PriceCurveDefinitions
                                                                .Where(definitions => definitions != null)
                                                                .Select(definitions =>
                                                                            definitions.Where(item => item.ProductDefinition.PricingTenorGroup == PricingTenorGroupType.Monthly)
                                                                                       .ToList())
                                                                .Take(1);

                snapshot.CombineLatest(mappings, priceCurveDefinitions, GetItems)
                        .Subscribe(obs.OnNext);

                return () => disposables.Dispose();
            });
        }

        private static IList<ChatPriceCurveFilterItem> GetItems(IEnumerable<DataContracts.ChatScraper.ChatPriceSummary> chatPrices, 
                                                                IEnumerable<ChatIceMap> chatIceMaps,
                                                                IEnumerable<PriceCurveDefinition> priceCurveDefinitions)
        {
            var mappings = chatIceMaps.Where(m => m.PriceCurveDefinitionId != null && m.PriceCurveDefinitionId != 0)
                                      .ToList();

            var mappedCurves = chatPrices.Join(mappings,
                                               chatPrice => chatPrice.PriceCurveName,
                                               mapping => mapping.PriceCurveName,
                                               (chatPrice, mapping) => new
                                               {
                                                   ChatPriceSummary = chatPrice,
                                                   mapping.PriceCurveDefinitionId
                                               });

            var filterItems = mappedCurves.Join(priceCurveDefinitions,
                                                chatPrice => chatPrice.PriceCurveDefinitionId,
                                                def => def.Id,
                                                (chatPrice, def) => new ChatPriceCurveFilterItem(chatPrice.ChatPriceSummary.Id,
                                                                                                 chatPrice.ChatPriceSummary.PriceCurveName,
                                                                                                 chatPrice.ChatPriceSummary.Name,
                                                                                                 def.ProductDefinition.CurveGroup, 
                                                                                                 def.CurveRegion))
                                          .OrderBy(item => item.PriceCurveName)
                                          .ToList();

            return filterItems;
        }
    }
}
