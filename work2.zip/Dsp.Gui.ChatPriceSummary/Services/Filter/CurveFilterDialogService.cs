﻿using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public class CurveFilterDialogService : FilterDialogService<ChatPriceCurveFilterItem>, 
                                            ICurveFilterDialogService
    {
    }
}
