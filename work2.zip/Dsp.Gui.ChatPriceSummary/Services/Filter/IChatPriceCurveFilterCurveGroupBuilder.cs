﻿using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public interface IChatPriceCurveFilterCurveGroupBuilder
    {
        List<ChatPriceCurveFilterGroup> GetCurveFilterGroups(IList<ChatPriceCurveFilterItem> curveFilterItems);
    }
}
