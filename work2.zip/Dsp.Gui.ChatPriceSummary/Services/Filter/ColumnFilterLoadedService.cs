﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public sealed class ColumnFilterLoadedService : IColumnFilterLoadedService
    {
        private BehaviorSubject<List<ChatPriceColumnFilterItem>> _columnFilter = new(null);
        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~ColumnFilterLoadedService()
        {
            Dispose(false);
        }

        public void Initialize()
        {
            var filterItems = CreateColumnFilterItems();

            _columnFilter?.OnNext(filterItems);
        }

        public void Initialize(ChatPriceGridSettings settings)
        {
            var filterItems = CreateColumnFilterItems();

            foreach (var item in filterItems)
            {
                item.OriginalIsSelected = settings.VisibleColumns.Contains(item.ColumnType);
                item.IsSelected = item.OriginalIsSelected;
            }
            
            _columnFilter?.OnNext(filterItems);
        }

        public IObservable<List<ChatPriceColumnFilterItem>> ColumnFilter => _columnFilter.AsObservable();

        private static List<ChatPriceColumnFilterItem> CreateColumnFilterItems()
        {
            return new List<ChatPriceColumnFilterItem>
            {
                new(ColumnType.BidBroker, "Bid Broker", true),
                new(ColumnType.BidTime, "Bid Time", true),
                new(ColumnType.BidPrice, "Bid Price", true),
                new(ColumnType.AskPrice, "Ask Price", true),
                new(ColumnType.AskTime, "Ask Time", true),
                new(ColumnType.AskBroker, "Ask Broker", true)
            };
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _columnFilter?.Dispose();
                _columnFilter = null;
            }

            _disposed = true;
        }
    }
}
