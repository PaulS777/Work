﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.Filter
{
    public interface ICurveFilterLoadedService : IDisposable
    {
        IObservable<List<ChatPriceCurveFilterItem>> CurveFilter { get; }
        void Initialize();
        void Initialize(ChatPriceGridSettings settings);
    }
}
