﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.Gui.ChatPriceSummary.Common;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.GridBuilder
{
    public class ChatPriceGridBuilder : IChatPriceGridBuilder
    {
        private readonly IChatTenorTreeGenerator _tenorTreeGenerator;

        public ChatPriceGridBuilder(IChatTenorTreeGenerator tenorTreeGenerator)
        {
            _tenorTreeGenerator = tenorTreeGenerator;
        }

        public List<ChatPriceRowViewModel> GetChatPriceRows(IList<DataContracts.ChatScraper.ChatPriceSummary> chatPriceSummaries)
        {
            var chatPriceRows = new List<ChatPriceRowViewModel>();

            var tenorSequence = _tenorTreeGenerator.GetTenorSequence(chatPriceSummaries);

            ITenor annualParent = null;
            ITenor quarterlyParent = null;

            tenorSequence.ForEach(tenor =>
            {
                var chatPriceRow = GetTenorRow(tenor, annualParent, quarterlyParent);

                var alternateBand = false;

                foreach (var chatPriceSummary in chatPriceSummaries)
                {
                    var chatPrice = new ChatPrice(chatPriceSummary.Id, tenor);
  
                    var cell = new ChatPriceCellViewModel(tenor.TenorType(), chatPrice, alternateBand);

                    chatPriceRow.PriceCells.Add(cell);

                    alternateBand = !alternateBand;
                }

                if (tenor.TenorType() == TenorType.Year)
                {
                    annualParent = tenor;
                }
                else if (tenor.TenorType() == TenorType.Quarter)
                {
                    quarterlyParent = tenor;
                }

                chatPriceRows.Add(chatPriceRow);
            });

            return chatPriceRows;
        }

        private static ChatPriceRowViewModel GetTenorRow(ITenor tenor,
                                                         ITenor yearTenor,
                                                         ITenor quarterTenor)
        {
            var tenorType = tenor.TenorType();

            return tenorType switch
                   {
                       TenorType.Month => new ChatPriceRowViewModel(tenor, quarterTenor),
                       TenorType.Quarter => yearTenor != null ? new ChatPriceRowViewModel(tenor, yearTenor) 
                                                : new ChatPriceRowViewModel(tenor),
                       _ => new ChatPriceRowViewModel(tenor)
                   };
        }
    }
}
