﻿using System.Collections.Generic;
using Dsp.DataContracts;

namespace Dsp.Gui.ChatPriceSummary.Services.GridBuilder
{
    public interface IChatTenorTreeGenerator
    {
        List<ITenor> GetTenorSequence(IList<DataContracts.ChatScraper.ChatPriceSummary> chatPriceSummaries);
    }
}
