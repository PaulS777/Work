﻿using System.Collections.Generic;
using System.Globalization;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.GridBuilder
{
    public class BandInfoProvider : IBandInfoProvider
    {
        public IList<BandInfo> GetBandInfos(IList<ChatPriceCurveFilterItem> items)
        {
            var bands = new List<BandInfo> {new(BandType.Tenor)};

            var index = 0;

            var alternateBand = false;

            foreach (var item in items)
            {
                var columnInfos = GetColumnInfos(item.Id, index, alternateBand);

                bands.Add(new BandInfo(BandType.Price, item.Id, item.PriceCurveName, item.Name, alternateBand, columnInfos));

                alternateBand = !alternateBand;
                index++;
            }

            return bands;
        }

        private static IList<ColumnInfo> GetColumnInfos(int bandId, int index, bool alternateBand)
        {
            var cellBinding = string.Format($"{nameof(ChatPriceRowViewModel.PriceCells)}[{index}]", CultureInfo.InvariantCulture);

            var columnInfos = new[]
            {
                new ColumnInfo(ColumnType.BidBroker, bandId, "Broker", cellBinding, alternateBand, 100),
                new ColumnInfo(ColumnType.BidTime, bandId, "Time", cellBinding, alternateBand, 80),
                new ColumnInfo(ColumnType.BidPrice, bandId, "Bid", cellBinding, alternateBand, 60),
                new ColumnInfo(ColumnType.AskPrice, bandId,"Offer", cellBinding, alternateBand, 60),
                new ColumnInfo(ColumnType.AskTime, bandId, "Time", cellBinding, alternateBand, 80),
                new ColumnInfo(ColumnType.AskBroker, bandId, "Broker", cellBinding, alternateBand, 100)
            };

            return columnInfos;
        }
    }
}
