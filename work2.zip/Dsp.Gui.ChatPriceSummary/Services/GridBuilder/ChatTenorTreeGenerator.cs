﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using System.Linq;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.ChatPriceSummary.Services.GridBuilder
{
    public class ChatTenorTreeGenerator : IChatTenorTreeGenerator
    {
        private const int AnnualTenorMultiplier = 10000;
        private const int MonthQuarter1 = 1;
        private const int MonthQuarter2 = 4;
        private const int MonthQuarter3 = 7;
        private const int MonthQuarter4 = 10;

        public List<ITenor> GetTenorSequence(IList<DataContracts.ChatScraper.ChatPriceSummary> chatPriceSummaries)
        {

            var annualTenors = chatPriceSummaries.SelectMany(cps => cps.AnnualTenors)
                                                 .Select(cps => TenorConverter.CreateFromKey(cps.TenorKey))
                                                 .Where(t => t is AnnualTenor)
                                                 .Cast<AnnualTenor>()
                                                 .OrderBy(t => t.GetTenorValue())
                                                 .ToList();

            var quarterlyTenors = chatPriceSummaries.SelectMany(cps => cps.QuarterlyTenors)
                                                    .Select(cps => TenorConverter.CreateFromKey(cps.TenorKey))
                                                    .Where(t => t is QuarterlyTenor)
                                                    .Cast<QuarterlyTenor>()
                                                    .OrderBy(t => t.GetTenorValue())
                                                    .ToList();

            var monthlyTenors = chatPriceSummaries.SelectMany(cps => cps.MonthlyTenors)
                                                  .Select(cps => TenorConverter.CreateFromKey(cps.TenorKey))
                                                  .Where(t => t is MonthlyTenor)
                                                  .Cast<MonthlyTenor>()
                                                  .OrderBy(t => t.GetTenorValue())
                                                  .ToList();

            var firstYear = annualTenors.FirstOrDefault();
            var firstQuarter = quarterlyTenors.FirstOrDefault();
            var firstMonth = monthlyTenors.FirstOrDefault();

            var tenors = GetStartTenorSequence(firstYear, firstQuarter, firstMonth);

            var monthStart = (MonthlyTenor)tenors.Last(t => t.TenorType() == TenorType.Month);
            
            var lastTenor = GetLastTenor(annualTenors, quarterlyTenors, monthlyTenors);

            ApplyTenorSequence(tenors, monthStart, lastTenor);

            return tenors;
        }

        private static List<ITenor> GetStartTenorSequence(AnnualTenor firstYear, 
                                                          QuarterlyTenor firstQuarter, 
                                                          MonthlyTenor firstMonth)
        {
            var tenors = new List<ITenor>();

            var annualStart = GetFirstAnnualTenor(firstYear, firstQuarter, firstMonth);
            tenors.Add(annualStart);

            var quarterStart = GetFirstQuarterlyTenor(annualStart, firstQuarter, firstMonth);
            tenors.Add(quarterStart);

            var monthStart = GetFirstMonthlyTenor(quarterStart, firstMonth);
            tenors.Add(monthStart);

            return tenors;
        }

        private static AnnualTenor GetFirstAnnualTenor(AnnualTenor startYear, 
                                                       QuarterlyTenor startQuarter, 
                                                       MonthlyTenor startMonth)
        {
            if (startYear.Year <= startQuarter.Year
                && startYear.Year <= startMonth.Year)
            {
                return startYear;
            }

            var yearMin = Math.Min(startQuarter.Year, startMonth.Year);

            return new AnnualTenor(yearMin * AnnualTenorMultiplier);
        }

        private static QuarterlyTenor GetFirstQuarterlyTenor(AnnualTenor startYear, 
                                                             QuarterlyTenor startQuarter,
                                                             MonthlyTenor startMonth)
        {
            var lastQuarter = new QuarterlyTenor((short)startYear.Year, 4);

            if (startQuarter.GetTenorValue() < startMonth.GetTenorValue())
            {
                return startQuarter.GetTenorValue() <= lastQuarter.GetTenorValue() ? startQuarter : lastQuarter;
            }

            var startMonthQuarter = new QuarterlyTenor((short)startMonth.Year, (short)startMonth.GetQuarter());

            return startMonthQuarter.GetTenorValue() <= lastQuarter.GetTenorValue() ? startMonthQuarter : lastQuarter;
        }

        private static MonthlyTenor GetFirstMonthlyTenor(QuarterlyTenor startQuarter,
                                                         MonthlyTenor startMonth)
        {
            if (startMonth.Year == startQuarter.Year
                && startMonth.GetQuarter() == startQuarter.Quarter)
            {
                return startMonth;
            }

            var month = (startQuarter.Quarter * 3) - 2;

            return new MonthlyTenor(startQuarter.Year, month);
        }

        private static ITenor GetLastTenor(IEnumerable<AnnualTenor> years,
                                           IEnumerable<QuarterlyTenor> quarters,
                                           IEnumerable<MonthlyTenor> months)
        {
            var lastYear = years.LastOrDefault();
            var lastQuarter = quarters.LastOrDefault();
            var lastMonth = months.LastOrDefault();

            if (lastYear.Year > lastQuarter.Year
                && lastYear.Year > lastMonth.Year)
            {
                return lastYear;
            }

            return lastMonth.GetTenorValue() > lastQuarter.GetTenorValue() ? lastMonth : lastQuarter;
        }

        private static void ApplyTenorSequence(ICollection<ITenor> tenors,
                                               MonthlyTenor startMonth, 
                                               ITenor endTenor)
        {
            var endDate = endTenor.StartDate();

            var endMonth = new MonthlyTenor(endDate.Year, endDate.Month);

            var date = new DateTime(startMonth.Year, startMonth.Month, 1, 0, 0, 0, kind: DateTimeKind.Utc).AddMonths(1);

            var currentMonth = new MonthlyTenor(date);

            while (currentMonth <= endMonth)
            {
                if (currentMonth.Month == 1)
                {
                    var annualTenor = new AnnualTenor(currentMonth.Year * 10000);
                    tenors.Add(annualTenor);
                }
                if (IsFirstMonthInQuarter(currentMonth, out var quarter))
                {
                    var quarterTenor = new QuarterlyTenor((short)currentMonth.Year, quarter);
                    tenors.Add(quarterTenor);
                }

                tenors.Add(currentMonth);

                date = new DateTime(currentMonth.Year, currentMonth.Month, 1, 0, 0, 0, kind: DateTimeKind.Utc).AddMonths(1);

                currentMonth = new MonthlyTenor(date);
            }
        }

        private static bool IsFirstMonthInQuarter(MonthlyTenor tenor, out short quarter)
        {
            switch (tenor.Month)
            {
                case MonthQuarter1:
                    quarter = 1;
                    return true;
                case MonthQuarter2:
                    quarter = 2;
                    return true;
                case MonthQuarter3:
                    quarter = 3;
                    return true;
                case MonthQuarter4:
                    quarter = 4;
                    return true;
                default:
                    quarter = 0;
                    return false;
            }
        }
    }
}
