﻿using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.GridBuilder
{
    public interface IChatPriceGridBuilder
    {
        List<ChatPriceRowViewModel> GetChatPriceRows(IList<DataContracts.ChatScraper.ChatPriceSummary> chatPriceSummaries);
    }
}
