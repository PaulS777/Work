﻿using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Services.GridBuilder
{
    public interface IBandInfoProvider
    {
        IList<BandInfo> GetBandInfos(IList<ChatPriceCurveFilterItem> items);
    }
}
