﻿using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.Markets
{
    public interface IChatPriceMarketsRemovalService
    {
        void RegisterSummary(ChatPriceSummaryViewModel chatPriceSummary);
        void RemoveMarkets(ChatPriceMarketsViewModel chatPriceMarkets);
        void UnRegisterSummary(ChatPriceSummaryViewModel chatPriceSummary);
    }
}
