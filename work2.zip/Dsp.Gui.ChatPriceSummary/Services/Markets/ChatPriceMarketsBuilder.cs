﻿using System.Linq;
using Dsp.Gui.ChatPriceSummary.Controllers;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.ChatPriceSummary.Services.Markets
{
    /// <summary>
    /// Instance generated per markets due to shared IChatPriceGridRemovalService between markets instance and price grids
    /// </summary>
    public class ChatPriceMarketsBuilder : IChatPriceMarketsBuilder
    {
        private readonly IChatPriceGridRemovalServiceCache _gridRemovalServiceCache;

        public ChatPriceMarketsBuilder(IChatPriceGridRemovalServiceCache gridRemovalServiceCache)
        {
            _gridRemovalServiceCache = gridRemovalServiceCache;
        }

        [Inject]
        public IServiceFactory<IChatPriceMarketsViewModelController> MarketsFactory { get; set; }

        [Inject]
        public IServiceFactory<IChatPriceGridViewModelController> GridFactory { get; set; }

        public ChatPriceMarketsViewModel GetMarketsFromSettings(ChatPriceMarketsSettings settings)
        {
            var chatPriceMarkets = MarketsFactory.Create();

            var gridRemovalService = _gridRemovalServiceCache.GetChatPriceGridRemovalService(settings.MarketsId);

            chatPriceMarkets.Initialize(settings.MarketsId, 
                                        settings.MarketsName, 
                                        gridRemovalService);

            foreach (var chatPriceGridSettings in settings.ChatPriceGrids)
            {
                AddChatPriceGridWithFilterSettings(chatPriceMarkets.ViewModel,
                                                   chatPriceGridSettings, 
                                                   gridRemovalService);
            }

            return chatPriceMarkets.ViewModel;
        }
        public void AddChatPriceGridToMarkets(int priceGridId,
                                              ChatPriceMarketsViewModel chatPriceMarkets)
        {
            var gridRemovalService = _gridRemovalServiceCache.GetChatPriceGridRemovalService(chatPriceMarkets.MarketsId);

            AddChatPriceGridWithFilter(chatPriceMarkets,
                                       chatPriceMarkets.ChatPriceFilterDialog,
                                       priceGridId, 
                                       gridRemovalService);
        }

        private void AddChatPriceGridWithFilterSettings(ChatPriceMarketsViewModel chatPriceMarkets,
                                                        ChatPriceGridSettings settings,
                                                        IChatPriceGridRemovalService gridRemovalService)
        {
            var priceGridController = GridFactory.Create();

            priceGridController.Initialize(chatPriceMarkets.MarketsId, 
                                           settings, 
                                           gridRemovalService);

            chatPriceMarkets.ChatPriceGrids.Add(priceGridController.ViewModel);

            chatPriceMarkets.ChatPriceFilterDialog.ChatPriceFilters.Add(priceGridController.ViewModel.ChatPriceGridFilters);

            chatPriceMarkets.ChatPriceFilterDialog.SelectedChatPriceFilterViewModel 
                = chatPriceMarkets.ChatPriceFilterDialog.ChatPriceFilters[0];
        }

        private void AddChatPriceGridWithFilter(ChatPriceMarketsViewModel chatPriceMarkets,
                                                ChatPriceFilterDialogViewModel chatPriceFilterDialog,
                                                int priceGridId,
                                                IChatPriceGridRemovalService gridRemovalService)
        {
            var priceGridController = GridFactory.Create();

            priceGridController.Initialize(chatPriceMarkets.MarketsId, 
                                           priceGridId, 
                                           gridRemovalService);

            chatPriceMarkets.ChatPriceGrids.Add(priceGridController.ViewModel);
            chatPriceFilterDialog.ChatPriceFilters.Add(priceGridController.ViewModel.ChatPriceGridFilters);

            chatPriceFilterDialog.SelectedChatPriceFilterViewModel = chatPriceFilterDialog.ChatPriceFilters[^1];
        }
    }
}
