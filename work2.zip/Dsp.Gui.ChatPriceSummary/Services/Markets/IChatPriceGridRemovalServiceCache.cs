﻿namespace Dsp.Gui.ChatPriceSummary.Services.Markets
{
    public interface IChatPriceGridRemovalServiceCache
    {
        IChatPriceGridRemovalService GetChatPriceGridRemovalService(int marketsId);
    }
}
