﻿using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.Markets
{
    public interface IChatPriceGridRemovalService
    {
        void RegisterMarkets(ChatPriceMarketsViewModel chatPriceMarkets);

        void UnRegisterMarkets(ChatPriceMarketsViewModel chatPriceMarkets);

        void RemoveGrid(ChatPriceGridViewModel chatPriceGrid);
    }
}
