﻿using System.Collections.Specialized;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.Services.Markets
{
    /// <summary>
    /// Responsible for removal and disposal of Price Grids from the Markets Tab
    /// One instance created per ChatPriceMarketsViewModel
    /// Calculates the enabled status of the grid's Remove Command by observing the grid collection count (must be > 1)
    /// </summary>
    public class ChatPriceGridRemovalService : IChatPriceGridRemovalService
    {
        private readonly IChatPriceSummarySettingsService _settingsService;
        private ChatPriceMarketsViewModel _chatPriceMarkets;

        public ChatPriceGridRemovalService(IChatPriceSummarySettingsService settingsService)
        {
            _settingsService = settingsService;
        }

        public void RegisterMarkets(ChatPriceMarketsViewModel chatPriceMarkets)
        {
            _chatPriceMarkets = chatPriceMarkets;

            chatPriceMarkets.MessageDialogPrompt.Header = "Remove Price Grid";
            chatPriceMarkets.MessageDialogPrompt.DialogNoCommand = new DelegateCommand(() => chatPriceMarkets.MessageDialogPrompt.ShowDialog = false);

            chatPriceMarkets.ChatPriceGrids.CollectionChanged += ChatPriceGridsOnCollectionChanged; 

            CalculateCanRemoveGrids();
        }

        public void UnRegisterMarkets(ChatPriceMarketsViewModel chatPriceMarkets)
        {
            chatPriceMarkets.ChatPriceGrids.CollectionChanged -= ChatPriceGridsOnCollectionChanged;

            _chatPriceMarkets = null;
        }

        public void RemoveGrid(ChatPriceGridViewModel chatPriceGrid)
        {
            if (!chatPriceGrid.PriceGridLoaded)
            {
                RemoveGridFromMarkets(chatPriceGrid);
                return;
            }

            _chatPriceMarkets.MessageDialogPrompt.DialogMessages = new[] { "Are you sure you wish to remove the Price Grid :", chatPriceGrid.PriceGridName };
            _chatPriceMarkets.MessageDialogPrompt.DialogYesCommand = new DelegateCommand(() => OnDialogRemoveGrid(chatPriceGrid));

            _chatPriceMarkets.MessageDialogPrompt.ShowDialog = true;
        }

        private void OnDialogRemoveGrid(ChatPriceGridViewModel chatPriceGrid)
        {
            _chatPriceMarkets.MessageDialogPrompt.ShowDialog = false;
            RemoveGridFromMarkets(chatPriceGrid);
        }

        private void RemoveGridFromMarkets(ChatPriceGridViewModel chatPriceGrid)
        {
            _chatPriceMarkets.ChatPriceGrids?.Remove(chatPriceGrid);

            _chatPriceMarkets.ChatPriceFilterDialog.ChatPriceFilters?.Remove(chatPriceGrid.ChatPriceGridFilters);

            _settingsService.RemovePriceGrid(_chatPriceMarkets.MarketsId, chatPriceGrid.PriceGridId);

            chatPriceGrid.Dispose();
        }

        private void ChatPriceGridsOnCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            CalculateCanRemoveGrids();
        }

        private void CalculateCanRemoveGrids()
        {
            var canRemove = _chatPriceMarkets.ChatPriceGrids.Count > 1;

            foreach (var chatPriceGrid in _chatPriceMarkets.ChatPriceGrids)
            {
                chatPriceGrid.CanRemoveGrid = canRemove;
            }
        }
    }
}
