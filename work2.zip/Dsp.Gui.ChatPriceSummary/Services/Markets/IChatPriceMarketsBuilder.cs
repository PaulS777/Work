﻿using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.Markets
{
    public interface IChatPriceMarketsBuilder
    {
        ChatPriceMarketsViewModel GetMarketsFromSettings(ChatPriceMarketsSettings settings);

        void AddChatPriceGridToMarkets(int priceGridId,
                                       ChatPriceMarketsViewModel chatPriceMarkets);
    }
}
