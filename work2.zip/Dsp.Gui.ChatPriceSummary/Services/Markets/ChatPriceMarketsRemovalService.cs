﻿using System.Collections.Specialized;
using System.Linq;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.Services.Markets
{
    /// <summary>
    /// Responsible for removal and disposal of Markets from the Summary Markets Tab
    /// Calculates the enabled status of the market's Remove Command by observing the markets collection count (must be > 1)
    /// </summary>
    public class ChatPriceMarketsRemovalService : IChatPriceMarketsRemovalService
    {
        private readonly IChatPriceSummarySettingsService _settingsService;
        private ChatPriceSummaryViewModel _chatPriceSummary;

        public ChatPriceMarketsRemovalService(IChatPriceSummarySettingsService settingsService)
        {
            _settingsService = settingsService;
        }

        public void RegisterSummary(ChatPriceSummaryViewModel chatPriceSummary)
        {
            _chatPriceSummary = chatPriceSummary;

            _chatPriceSummary.RemoveMarketsDialogPrompt.Header = "Remove Markets";
            _chatPriceSummary.RemoveMarketsDialogPrompt.DialogNoCommand = new DelegateCommand(() => _chatPriceSummary.RemoveMarketsDialogPrompt.ShowDialog = false);

            _chatPriceSummary.ChatPriceMarkets.CollectionChanged += ChatPriceMarketsOnCollectionChanged;
            
            CalculateCanRemoveMarkets();
        }

        public void UnRegisterSummary(ChatPriceSummaryViewModel chatPriceSummary)
        {
            chatPriceSummary.ChatPriceMarkets.CollectionChanged -= ChatPriceMarketsOnCollectionChanged;

            _chatPriceSummary = null;
        }

        public void RemoveMarkets(ChatPriceMarketsViewModel chatPriceMarkets)
        {
            if (chatPriceMarkets.ChatPriceGrids.Any(g => g.PriceGridLoaded))
            {
                _chatPriceSummary.RemoveMarketsDialogPrompt.DialogMessages = new[]{ "Are you sure you wish to remove the Markets Tab : ", chatPriceMarkets.Name};
                _chatPriceSummary.RemoveMarketsDialogPrompt.DialogYesCommand = new DelegateCommand(() => OnDialogRemoveMarkets(chatPriceMarkets));

                _chatPriceSummary.RemoveMarketsDialogPrompt.ShowDialog = true;

                return;
            }
            
            RemoveMarketsFromSummary(chatPriceMarkets);
        }

        private void OnDialogRemoveMarkets(ChatPriceMarketsViewModel chatPriceMarkets)
        {
            _chatPriceSummary.RemoveMarketsDialogPrompt.ShowDialog = false;
            RemoveMarketsFromSummary(chatPriceMarkets);
        }

        private void RemoveMarketsFromSummary(ChatPriceMarketsViewModel chatPriceMarkets)
        {
            var isSelected = chatPriceMarkets.IsSelected;

            _chatPriceSummary.ChatPriceMarkets?.Remove(chatPriceMarkets);

            _settingsService.RemoveMarkets(chatPriceMarkets.MarketsId);

            chatPriceMarkets.Dispose();

            if (isSelected && _chatPriceSummary.ChatPriceMarkets?.Count > 0)
            {
                _chatPriceSummary.ChatPriceMarkets[0].IsSelected = true;
            }
        }

        private void ChatPriceMarketsOnCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            
            CalculateCanRemoveMarkets();
        }

        private void CalculateCanRemoveMarkets()
        {
            var canRemove = _chatPriceSummary.ChatPriceMarkets.Count > 1;

            foreach (var chatPriceMarket in _chatPriceSummary.ChatPriceMarkets)
            {
                chatPriceMarket.CanRemoveMarkets = canRemove;
            }
        }
    }
}
