﻿using System.Collections.Generic;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.ChatPriceSummary.Services.Markets
{
    public class ChatPriceGridRemovalServiceCache : IChatPriceGridRemovalServiceCache
    {
        private readonly Dictionary<int, IChatPriceGridRemovalService> _serviceLookup = new();

        [Inject]
        public IServiceFactory<IChatPriceGridRemovalService> ServiceFactory { get; set; }

        public IChatPriceGridRemovalService GetChatPriceGridRemovalService(int marketsId)
        {
            if (_serviceLookup.TryGetValue(marketsId, out var service))
            {
                return service;
            }

            var newService = ServiceFactory.Create();

            _serviceLookup.Add(marketsId, newService);

            return newService;
        }
    }
}
