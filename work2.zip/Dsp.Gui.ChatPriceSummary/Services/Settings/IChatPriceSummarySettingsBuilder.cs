﻿using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.Settings
{
    public interface IChatPriceSummarySettingsBuilder
    {
        ChatPriceSummarySettings GetDefaultChatPriceSummarySettings(int marketsId, 
                                                                    int priceGridId);

        ChatPriceGridSettings CreateNewPriceGrid(int marketsId, 
                                                 ChatPriceSummarySettings settings);

        ChatPriceMarketsSettings CreateNewChatPriceMarkets(ChatPriceSummarySettings settings);

        void ApplyMarketsFilter(int marketsId,
                                int priceGridId,
                                IList<int> curveIds,
                                ChatPriceSummarySettings settings);

        void ApplyColumnsFilter(int marketsId, 
                                int priceGridId, 
                                IList<ColumnType> columns, 
                                ChatPriceSummarySettings settings);

        void ApplyColumnWidths(int marketsId, 
                               int priceGridId, 
                               IList<ColumnInfo> columnInfos, 
                               ChatPriceSummarySettings settings);

        void ApplyPriceGridName(int marketsId, 
                                int priceGridId,
                                string name,
                                ChatPriceSummarySettings settings);

        void ApplyMarketsName(int marketsId,
                              string name, 
                              ChatPriceSummarySettings settings);

        void RemovePriceGrid(int marketsId, 
                             int priceGridId,
                             ChatPriceSummarySettings settings);

        void RemoveMarkets(int marketsId,
                           ChatPriceSummarySettings settings);
    }
}
