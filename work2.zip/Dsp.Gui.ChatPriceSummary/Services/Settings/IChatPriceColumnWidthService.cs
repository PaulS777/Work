﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.Settings
{
    public interface IChatPriceColumnWidthService : IDisposable
    {
        void MonitorColumnWidthChanges(int marketsId,
                                       int priceGridId, 
                                       IList<BandInfo> bandInfos, 
                                       IScheduler scheduler);

        void ApplyColumnWidths(int marketsId, 
                               int priceGridId, 
                               IList<BandInfo> bandInfos);
    }
}
