﻿using System;
using System.Collections.Generic;
using System.Reactive.Concurrency;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Services;
using Dsp.ServiceContracts;

namespace Dsp.Gui.ChatPriceSummary.Services.Settings
{
    public class ChatPriceSummarySettingsService : IChatPriceSummarySettingsService
    {
        private readonly IChatPriceSummarySettingsFileProvider _fileProvider;
        private readonly IChatPriceSummarySettingsBuilder _builder;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly ILogger _log;
        private readonly object _synch = new();

        private readonly BehaviorSubject<ChatPriceSummarySettings> _chatPriceSummarySettingsSubject = new(null);

        private ChatPriceSummarySettings _chatPriceSummarySettings;

        public ChatPriceSummarySettingsService(IChatPriceSummarySettingsFileProvider fileProvider,
                                               IChatPriceSummarySettingsBuilder builder,
                                               ISchedulerProvider schedulerProvider,
                                               ILoggerFactory loggerFactory)
        {
            _fileProvider = fileProvider;
            _builder = builder;
            _schedulerProvider = schedulerProvider;

            _log = loggerFactory.Create(GetType().Name);

            LoadSettings();
        }

        public IObservable<ChatPriceSummarySettings> ChatPriceSummarySettings => _chatPriceSummarySettingsSubject.AsObservable();

        public void LoadSettings()
        {
            _schedulerProvider.TaskPool.Schedule(() =>
            {
                lock (_synch)
                {
                    var settings = _fileProvider.LoadChatPriceSummarySettings();

                    _chatPriceSummarySettings = settings.ChatPriceMarkets != null && settings.ChatPriceMarkets.Length != 0
                        ? settings
                        : _builder.GetDefaultChatPriceSummarySettings(1, 1);

                    _chatPriceSummarySettingsSubject.OnNext(_chatPriceSummarySettings);
                }
            });
        }

        public ChatPriceGridSettings CreateNewPriceGrid(int marketsId)
        {
            lock (_synch)
            {
                var settings = _builder.CreateNewPriceGrid(marketsId, 
                                                           _chatPriceSummarySettings);

                return settings;
            }
        }

        public ChatPriceMarketsSettings CreateNewChatPriceMarkets()
        {
            lock (_synch)
            {
                var settings = _builder.CreateNewChatPriceMarkets(_chatPriceSummarySettings);

                return settings;
            }
        }

        public void SaveMarketsFilter(int marketsId, int priceGridId, IList<int> curveIds)
        {
            _schedulerProvider.TaskPool.Schedule(() =>
            {
                try
                {
                    lock (_synch)
                    {
                        _builder.ApplyMarketsFilter(marketsId,
                                                    priceGridId, 
                                                    curveIds, 
                                                    _chatPriceSummarySettings);

                        _fileProvider.SaveChatPriceSummarySettings(_chatPriceSummarySettings);
                    }
                }
                catch (Exception ex)
                {
                    _log.Error($"Failed to Save Chat Price Summary Markets : {ex.Message}");
                }
            });
        }

        public void SaveColumnsFilter(int marketsId, int priceGridId, IList<ColumnType> columns)
        {
            _schedulerProvider.TaskPool.Schedule(() =>
            {
                try
                {
                    lock (_synch)
                    {
                        _builder.ApplyColumnsFilter(marketsId,
                                                    priceGridId,
                                                    columns,
                                                    _chatPriceSummarySettings);

                        _fileProvider.SaveChatPriceSummarySettings(_chatPriceSummarySettings);
                    }
                }
                catch (Exception ex)
                {
                    _log.Error($"Failed to Save Chat Price Summary Markets : {ex.Message}");
                }
            });
        }

        public void SaveColumnWidths(int marketsId, int priceGridId, IList<ColumnInfo> columnInfos)
        {
            _schedulerProvider.TaskPool.Schedule(() =>
            {
                try
                {
                    lock (_synch)
                    {
                        _builder.ApplyColumnWidths(marketsId,
                                                   priceGridId,
                                                   columnInfos,
                                                   _chatPriceSummarySettings);

                        _fileProvider.SaveChatPriceSummarySettings(_chatPriceSummarySettings);
                    }
                }
                catch (Exception ex)
                {
                    _log.Error($"Failed to Save Chat Price Summary Markets : {ex.Message}");
                }
            });
        }

        public void SavePriceGridName(int marketsId, int priceGridId, string name)
        {
            _schedulerProvider.TaskPool.Schedule(() =>
            {
                try
                {
                    lock (_synch)
                    {
                        _builder.ApplyPriceGridName(marketsId,
                                                    priceGridId, 
                                                    name,
                                                   _chatPriceSummarySettings);

                        _fileProvider.SaveChatPriceSummarySettings(_chatPriceSummarySettings);
                    }
                }
                catch (Exception ex)
                {
                    _log.Error($"Failed to Save Chat Price Summary Markets : {ex.Message}");
                }
            });
        }

        public void SaveMarketsName(int marketsId, string name)
        {
            _schedulerProvider.TaskPool.Schedule(() =>
            {
                try
                {
                    lock (_synch)
                    {
                        _builder.ApplyMarketsName(marketsId,
                                                  name,
                                                  _chatPriceSummarySettings);

                        _fileProvider.SaveChatPriceSummarySettings(_chatPriceSummarySettings);
                    }
                }
                catch (Exception ex)
                {
                    _log.Error($"Failed to Save Chat Price Summary Markets : {ex.Message}");
                }
            });
        }

        public void RemovePriceGrid(int marketsId, 
                                    int priceGridId)
        {
            _schedulerProvider.TaskPool.Schedule(() =>
            {
                try
                {
                    lock (_synch)
                    {
                        _builder.RemovePriceGrid(marketsId,
                                                 priceGridId, 
                                                 _chatPriceSummarySettings);

                        _fileProvider.SaveChatPriceSummarySettings(_chatPriceSummarySettings);
                    }
                }
                catch (Exception ex)
                {
                    _log.Error($"Failed to Save Chat Price Summary Markets : {ex.Message}");
                }
            });
        }

        public void RemoveMarkets(int marketsId)
        {
            _schedulerProvider.TaskPool.Schedule(() =>
            {
                try
                {
                    lock (_synch)
                    {
                        _builder.RemoveMarkets(marketsId,
                                               _chatPriceSummarySettings);

                        _fileProvider.SaveChatPriceSummarySettings(_chatPriceSummarySettings);
                    }
                }
                catch (Exception ex)
                {
                    _log.Error($"Failed to Save Chat Price Summary Markets : {ex.Message}");
                }
            });
        }

        public ChatPriceGridSettings GetChatPriceGridSettings(int marketsId, int priceGridId)
        {
            lock (_synch)
            {
                if (_chatPriceSummarySettings == null)
                {
                    return null;
                }

                var markets = Array.Find(_chatPriceSummarySettings.ChatPriceMarkets, m => m.MarketsId == marketsId);

                return markets == null ? null : Array.Find(markets.ChatPriceGrids, g => g.PriceGridId == priceGridId);
            }
        }
    }
}
