﻿using Dsp.Gui.ChatPriceSummary.Settings;

namespace Dsp.Gui.ChatPriceSummary.Services.Settings
{
    public interface IChatPriceSummarySettingsFileProvider
    {
        ChatPriceSummarySettings LoadChatPriceSummarySettings();
        void SaveChatPriceSummarySettings(ChatPriceSummarySettings filter);
    }
}
