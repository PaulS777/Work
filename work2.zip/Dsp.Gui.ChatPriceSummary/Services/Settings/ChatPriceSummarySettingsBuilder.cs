﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.Settings
{
    public class ChatPriceSummarySettingsBuilder : IChatPriceSummarySettingsBuilder
    {
        public ChatPriceSummarySettings GetDefaultChatPriceSummarySettings(int marketsId,
                                                                           int priceGridId)
        {
            var marketsName = GetMarketsName(marketsId);

            return new ChatPriceSummarySettings
            {
                ChatPriceMarkets =
                [
                    new ChatPriceMarketsSettings
                    {
                        MarketsId = marketsId,
                        MarketsName = marketsName,
                        ChatPriceGrids =
                        [
                            new ChatPriceGridSettings
                            {
                                Name = "ICE Chat Prices",
                                PriceGridId = priceGridId,
                                MarketBands = [],
                                VisibleColumns =
                                [
                                    ColumnType.BidBroker,
                                    ColumnType.BidPrice,
                                    ColumnType.BidTime,
                                    ColumnType.AskBroker,
                                    ColumnType.AskPrice,
                                    ColumnType.AskTime
                                ]
                            }
                        ]
                    }
                ]
            };
        }

        private static string GetMarketsName(int id) => $"Markets {id}";

        public ChatPriceMarketsSettings CreateNewChatPriceMarkets(ChatPriceSummarySettings settings)
        {
            var marketsId = settings.ChatPriceMarkets
                                    .Max(m => m.MarketsId) + 1;

            var marketsName = GetMarketsName(marketsId);

            var marketsSettings = new ChatPriceMarketsSettings
            {
                MarketsId = marketsId,
                MarketsName = marketsName,
                ChatPriceGrids =
                [
                    new ChatPriceGridSettings
                    {
                        Name = "ICE Chat Prices",
                        PriceGridId = 1,
                        MarketBands = [],
                        VisibleColumns =
                        [
                            ColumnType.BidBroker,
                            ColumnType.BidPrice,
                            ColumnType.BidTime,
                            ColumnType.AskBroker,
                            ColumnType.AskPrice,
                            ColumnType.AskTime
                        ]
                    }
                ]
            };

            var chatPriceMarkets = settings.ChatPriceMarkets.ToList();

            chatPriceMarkets.Add(marketsSettings);

            settings.ChatPriceMarkets = chatPriceMarkets.ToArray();

            return marketsSettings;
        }

        public ChatPriceGridSettings CreateNewPriceGrid(int marketsId,
                                                        ChatPriceSummarySettings settings)
        {
            var priceGridId = settings.ChatPriceMarkets
                                      .SelectMany(m => m.ChatPriceGrids)
                                      .Max(g => g.PriceGridId) +1;

            var gridSettings = new ChatPriceGridSettings
            {
                PriceGridId = priceGridId,
                MarketBands = [],
                VisibleColumns =
                [
                    ColumnType.BidBroker,
                    ColumnType.BidPrice,
                    ColumnType.BidTime,
                    ColumnType.AskBroker,
                    ColumnType.AskPrice,
                    ColumnType.AskTime
                ]
            };

            var markets = settings.ChatPriceMarkets
                                  .First(m => m.MarketsId == marketsId);

            var chatPriceGrids = markets.ChatPriceGrids.ToList();

            chatPriceGrids.Add(gridSettings);

            markets.ChatPriceGrids = chatPriceGrids.ToArray();

            return gridSettings;
        }

        public void ApplyMarketsFilter(int marketsId, 
                                       int priceGridId, 
                                       IList<int> curveIds, 
                                       ChatPriceSummarySettings settings)
        {
            var priceGridSettings = GetChatPriceGridSettings(marketsId, priceGridId, settings);

            if (priceGridSettings == null)
            {
                return;
            }
                                     
            priceGridSettings.MarketBands = curveIds.Select(id => GetMarketBand(id, priceGridSettings))
                                                    .ToArray();
        }

        public void ApplyColumnsFilter(int marketsId, 
                                       int priceGridId, 
                                       IList<ColumnType> columns, 
                                       ChatPriceSummarySettings settings)
        {
            var priceGridSettings = GetChatPriceGridSettings(marketsId, priceGridId, settings);

            if (priceGridSettings == null)
            {
                return;
            }

            priceGridSettings.VisibleColumns = columns.ToArray();
        }

        public void ApplyColumnWidths(int marketsId, 
                                      int priceGridId, 
                                      IList<ColumnInfo> columnInfos, 
                                      ChatPriceSummarySettings settings)
        {
            var priceGridSettings = GetChatPriceGridSettings(marketsId, priceGridId, settings);

            if (priceGridSettings == null)
            {
                return;
            }

            foreach (var marketBand in priceGridSettings.MarketBands)
            {
                var columnInfo = columnInfos.FirstOrDefault(ci => ci.BandId == marketBand.ChatPriceSummaryId);

                if (columnInfo == null)
                {
                    continue;
                }

                var column = Array.Find(marketBand.ColumnWidths, c => c.ColumnType == columnInfo.ColumnType);

                if (column != null)
                {
                    column.Width = columnInfo.AdjustedWidth;
                }
                else
                {
                    var newColumn = new ChatPriceGridSettings.ColumnWidth
                    {
                        ColumnType = columnInfo.ColumnType,
                        Width = columnInfo.AdjustedWidth
                    };

                    var columnWidths = new List<ChatPriceGridSettings.ColumnWidth>(marketBand.ColumnWidths) { newColumn };

                    marketBand.ColumnWidths = columnWidths.ToArray();
                }
            }
        }

        public void ApplyPriceGridName(int marketsId, 
                                       int priceGridId, 
                                       string name, 
                                       ChatPriceSummarySettings settings)
        {
            var priceGridSettings = GetChatPriceGridSettings(marketsId, priceGridId, settings);

            if (priceGridSettings == null)
            {
                return;
            }

            priceGridSettings.Name = name;
        }

        public void ApplyMarketsName(int marketsId, 
                                     string name, 
                                     ChatPriceSummarySettings settings)
        {
            var chatPriceMarkets = settings.ChatPriceMarkets.ToList();

            var markets = chatPriceMarkets.Find(m => m.MarketsId == marketsId);

            if (markets == null)
            {
                return;
            }

            markets.MarketsName = name;

            settings.ChatPriceMarkets = chatPriceMarkets.ToArray();
        }

        public void RemovePriceGrid(int marketsId, 
                                    int priceGridId, 
                                    ChatPriceSummarySettings settings)
        {
            ArgumentNullException.ThrowIfNull(settings);

            var market = Array.Find(settings.ChatPriceMarkets, 
                                    m => Array.Exists(m.ChatPriceGrids, grid => grid.PriceGridId == priceGridId));

            if (market == null)
            {
                return;
            }

            var chatPriceGrids = market.ChatPriceGrids.ToList();

            var index = chatPriceGrids.FindIndex(grid => grid.PriceGridId == priceGridId);

            chatPriceGrids.RemoveAt(index);

            market.ChatPriceGrids = chatPriceGrids.ToArray();
        }

        public void RemoveMarkets(int marketsId,
                                  ChatPriceSummarySettings settings)
        {
            var chatPriceMarkets = settings.ChatPriceMarkets.ToList();

            var markets = chatPriceMarkets.Find(m => m.MarketsId == marketsId);

            if (markets == null)
            {
                return;
            }

            chatPriceMarkets.Remove(markets);

            settings.ChatPriceMarkets = chatPriceMarkets.ToArray();
        }

        private static ChatPriceGridSettings GetChatPriceGridSettings(int marketsId, 
                                                                      int priceGridId,
                                                                      ChatPriceSummarySettings settings)
        {
            var markets = Array.Find(settings.ChatPriceMarkets, m => m.MarketsId == marketsId);

            return markets == null ? null : Array.Find(markets.ChatPriceGrids, p => p.PriceGridId == priceGridId);
        }

        private static ChatPriceGridSettings.MarketBand GetMarketBand(int id,
                                                                      ChatPriceGridSettings settings)
        {


            var band = Array.Find(settings.MarketBands, b => b.ChatPriceSummaryId == id);

            return band ?? new ChatPriceGridSettings.MarketBand
            {
                ChatPriceSummaryId = id,
                ColumnWidths = []
            };
        }
    }
}
