﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.Settings
{
    public interface IChatPriceSummarySettingsService
    {
        void LoadSettings();
        ChatPriceGridSettings CreateNewPriceGrid(int marketsId);
        ChatPriceMarketsSettings CreateNewChatPriceMarkets();
        void SaveMarketsFilter(int marketsId, int priceGridId, IList<int> curveIds);
        void SaveColumnsFilter(int marketsId, int priceGridId, IList<ColumnType> columns);
        void SaveColumnWidths(int marketsId, int priceGridId, IList<ColumnInfo> columnInfos);
        void SavePriceGridName(int marketsId, int priceGridId, string name);
        void SaveMarketsName(int marketsId, string name);
        void RemovePriceGrid(int marketsId, int priceGridId);
        void RemoveMarkets(int marketsId);
        IObservable<ChatPriceSummarySettings> ChatPriceSummarySettings { get; }
        ChatPriceGridSettings GetChatPriceGridSettings(int marketsId, int priceGridId);
    }
}
