﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.ChatPriceSummary.Services.Settings
{
    public sealed class ChatPriceColumnWidthService : IChatPriceColumnWidthService
    {
        private readonly IChatPriceSummarySettingsService _settingsService;
        private readonly SerialDisposable _disposable = new();

        private bool _disposed;

        public ChatPriceColumnWidthService(IChatPriceSummarySettingsService settingsService)
        {
            _settingsService = settingsService;
        }

        [ExcludeFromCodeCoverage]
        ~ChatPriceColumnWidthService()
        {
            Dispose(false);
        }

        public void MonitorColumnWidthChanges(int marketsId,
                                              int priceGridId, 
                                              IList<BandInfo> bandInfos, 
                                              IScheduler scheduler)
        {
            var columnInfos = bandInfos.SelectMany(band => band.ColumnInfos);

            var columnChanges = Merge(columnInfos);

            _disposable.Disposable 
                = columnChanges.Buffer(TimeSpan.FromSeconds(1), scheduler)
                               .Where(changes => changes.Count > 0)
                               .Subscribe(changes => _settingsService.SaveColumnWidths(marketsId, priceGridId, changes));
        }

        private static IObservable<ColumnInfo> Merge(IEnumerable<ColumnInfo> columnInfos)
        {
            return Observable.Create<ColumnInfo>(obs =>
            {
                var disposables = new CompositeDisposable();

                foreach (var columnInfo in columnInfos)
                {
                    columnInfo.ObservePropertyChanged(vm => vm.AdjustedWidth)
                              .Subscribe(obs.OnNext)
                              .AddTo(disposables);
                }

                return () => disposables.Dispose();
            });
        }

        public void ApplyColumnWidths(int marketsId, 
                                      int priceGridId, 
                                      IList<BandInfo> bandInfos)
        {
            var gridSettings = _settingsService.GetChatPriceGridSettings(marketsId, priceGridId);

            if (gridSettings == null)
            {
                return;
            }

            foreach (var bandInfo in bandInfos)
            {
                var bandSetting = Array.Find(gridSettings.MarketBands, band => band.ChatPriceSummaryId == bandInfo.Id);

                if (bandSetting == null)
                {
                    continue;
                }

                foreach (var columnInfo in bandInfo.ColumnInfos)
                {
                    var columnSettings = Array.Find(bandSetting.ColumnWidths, c => c.ColumnType == columnInfo.ColumnType);

                    if (columnSettings != null)
                    {
                        columnInfo.Width = columnSettings.Width;
                    }
                }
            }
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposable.Dispose();
            }

            _disposed = true;
        }
    }
}
