﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Xml.Serialization;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.Common;
using Dsp.ServiceContracts;

namespace Dsp.Gui.ChatPriceSummary.Services.Settings
{
    [ExcludeFromCodeCoverage]
    public class ChatPriceSummarySettingsFileProvider : IChatPriceSummarySettingsFileProvider
    {
        private readonly string _settingsPath;
        private readonly string _gridFilterFile;
        private readonly ILogger _log;

        public ChatPriceSummarySettingsFileProvider(IConfigProvider configProvider,
                                                    IDspApplicationRunService dspApplicationRunService,
                                                    ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _settingsPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                dspApplicationRunService.SettingsPath,
                configProvider.Configuration.EnvironmentName);

            _gridFilterFile = Path.Combine(_settingsPath, "ChatPriceSummarySettings.xml");
        }

        public ChatPriceSummarySettings LoadChatPriceSummarySettings()
        {
            try
            {
                var serializer = new XmlSerializer(typeof(ChatPriceSummarySettings));

                using (var file = new StreamReader(_gridFilterFile))
                {
                    var settings = (ChatPriceSummarySettings)serializer.Deserialize(file);

                    return settings.ChatPriceMarkets == null ? new ChatPriceSummarySettings() : settings;
                }
            }
            catch (Exception ex)
            {
                _log.Warn($"Failed to load Chat Price Summary settings :{ex.Message}");
                return new ChatPriceSummarySettings();
            }
        }

        public void SaveChatPriceSummarySettings(ChatPriceSummarySettings filter)
        {
            try
            {
                if (!Directory.Exists(_settingsPath))
                {
                    Directory.CreateDirectory(_settingsPath);
                }

                var serializer = new XmlSerializer(typeof(ChatPriceSummarySettings));

                using (var file = File.Create(_gridFilterFile))
                {
                    serializer.Serialize(file, filter);
                }
            }
            catch (Exception ex)
            {
                _log.Error($"Failed to save Chat Price Summary settings :{ex.Message}");
                throw;
            }
        }
    }
}
