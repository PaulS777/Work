﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public class ChatPriceGridRefreshArgs
    {
        public ChatPriceGridRefreshArgs(IList<BandInfo> bands, IList<ChatPriceRowViewModel> chatPriceRows)
        {
            Bands = bands;
            ChatPriceRows = chatPriceRows;
        }

        public IList<BandInfo> Bands { get; }
        public IList<ChatPriceRowViewModel> ChatPriceRows { get; }
    }

    public interface IChatPriceGridRefreshService : IDisposable
    {
        IObservable<ChatPriceGridRefreshArgs> GridRefresh { get; }

        void BuildGrid(IList<ChatPriceCurveFilterItem> filter, IDispatcherExecutionService dispatcherExecutionService);
    }
}
