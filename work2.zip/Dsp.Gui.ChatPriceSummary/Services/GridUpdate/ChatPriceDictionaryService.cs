﻿using System.Collections.Generic;
using System.Linq;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public class ChatPriceDictionaryService : IChatPriceDictionaryService
    {
        public Dictionary<int, List<ChatPriceCellViewModel>> CreateDictionary(IList<ChatPriceRowViewModel> chatPriceRows)
        {
            var dictionary = new Dictionary<int, List<ChatPriceCellViewModel>>();

            var priceCellRows = chatPriceRows.Select(r => r.PriceCells)
                                             .ToList();

            priceCellRows.ForEach(row =>
            {
                foreach (var priceCell in row)
                {
                    if (!dictionary.TryGetValue(priceCell.Model.Id, out var priceCells))
                    {
                        priceCells = new List<ChatPriceCellViewModel>();
                        dictionary.Add(priceCell.Model.Id, priceCells);
                    }

                    priceCells.Add(priceCell);
                }
            });

            return dictionary;
        }
    }
}
