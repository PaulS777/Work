﻿using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public interface IChatPriceUpdateService
    {
        void RefreshPriceMonitors(IList<int> filter, 
                                  Dictionary<int, List<ChatPriceCellViewModel>> chatPriceDictionary,
                                  IDispatcherExecutionService dispatcherExecutionService);
    }
}
