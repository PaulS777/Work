﻿using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public interface IChatPriceDictionaryService
    {
        Dictionary<int, List<ChatPriceCellViewModel>> CreateDictionary(IList<ChatPriceRowViewModel> chatPriceRows);
    }
}
