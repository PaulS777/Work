﻿using System;
using System.Linq;
using System.Reactive.Linq;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public class ChatPriceSummaryStreamProvider : IChatPriceSummaryStreamProvider
    {
        private readonly ICurveControlService _curveControlService;

        public ChatPriceSummaryStreamProvider(ICurveControlService curveControlService)
        {
            _curveControlService = curveControlService;
        }

        public IObservable<DataContracts.ChatScraper.ChatPriceSummary> GetPriceStream(int id)
        {
            var snapshot = _curveControlService.ChatPriceSummarySnapshot
                                               .Where(list => list != null)
                                               .Select(list => list.FirstOrDefault(cps => cps.Id == id))
                                               .Where(cps => cps != null)
                                               .Take(1);

            var notifications = _curveControlService.ChatPriceSummaryNotifications
                                                    .Where(list => list != null)
                                                    .Select(list => list.FirstOrDefault(cps => cps.Id == id))
                                                    .Where(cps => cps != null);

            var chatPrices = snapshot.Concat(notifications);

            return chatPrices;
        }
    }
}
