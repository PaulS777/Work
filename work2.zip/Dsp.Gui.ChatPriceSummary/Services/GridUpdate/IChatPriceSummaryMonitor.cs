﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public interface IChatPriceSummaryMonitor : IDisposable
    {
        void MonitorChatPrices(IObservable<DataContracts.ChatScraper.ChatPriceSummary> chatPriceSummary,
                               List<ChatPriceCellViewModel> priceCells,
                               IDispatcherExecutionService dispatcher);
    }
}
