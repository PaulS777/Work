﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using System.Threading;
using Dsp.Gui.ChatPriceSummary.Services.GridBuilder;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Services;
using Dsp.ServiceContracts;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public sealed class ChatPriceGridRefreshService : IChatPriceGridRefreshService
    {
        private readonly ICurveControlService _curveControlService;
        private readonly IBandInfoProvider _bandInfoProvider;
        private readonly IChatPriceGridBuilder _gridBuilder;
        private readonly IChatPriceDictionaryService _chatPriceDictionaryService;
        private readonly IChatPriceUpdateService _chatPriceUpdateService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly BehaviorSubject<ChatPriceGridRefreshArgs> _refreshArgs = new(null);

        private readonly SemaphoreSlim _semaphoreSlim = new(1);
        private readonly SerialDisposable _snapshotDisposable = new();
        private readonly ILogger _log;

        private bool _disposed;

        public ChatPriceGridRefreshService(ICurveControlService curveControlService,
                                           IBandInfoProvider bandInfoProvider,
                                           IChatPriceGridBuilder gridBuilder,
                                           IChatPriceDictionaryService chatPriceDictionaryService,
                                           IChatPriceUpdateService chatPriceUpdateService,
                                           ISchedulerProvider schedulerProvider,
                                           ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _curveControlService = curveControlService;
            _bandInfoProvider = bandInfoProvider;
            _gridBuilder = gridBuilder;
            _chatPriceDictionaryService = chatPriceDictionaryService;
            _chatPriceUpdateService = chatPriceUpdateService;
            _schedulerProvider = schedulerProvider;
        }

        [ExcludeFromCodeCoverage]
        ~ChatPriceGridRefreshService()
        {
            Dispose(false);
        }

        public IObservable<ChatPriceGridRefreshArgs> GridRefresh => _refreshArgs.AsObservable();

        public void BuildGrid(IList<ChatPriceCurveFilterItem> filter,
                              IDispatcherExecutionService dispatcherExecutionService)
        {
            _log.Info("Waiting for Semaphore.. ");
            _semaphoreSlim.Wait();
            _log.Info("Semaphore obtained");

            _snapshotDisposable.Disposable =
                _curveControlService.ChatPriceSummarySnapshot
                                    .Where(snapshot => snapshot != null)
                                    .Take(1)
                                    .ObserveOn(_schedulerProvider.TaskPool)
                                    .Subscribe(snapshot => OnChatPriceSummarySnapshot(snapshot,
                                                                                      filter,
                                                                                      dispatcherExecutionService));

        }

        private void OnChatPriceSummarySnapshot(IEnumerable<DataContracts.ChatScraper.ChatPriceSummary> chatPriceSummaries,
                                                IList<ChatPriceCurveFilterItem> filter,
                                                IDispatcherExecutionService dispatcherExecutionService)
        {
            var bands = _bandInfoProvider.GetBandInfos(filter);

            var filterIds = filter.Select(item => item.Id).ToList();

            var filterSummaries = new List<DataContracts.ChatScraper.ChatPriceSummary>();

            filterIds.ForEach(id =>
            {
                var summary = chatPriceSummaries.FirstOrDefault(cps => cps.Id == id);

                if (summary != null)
                {
                    filterSummaries.Add(summary);
                }
            });

            if (filterSummaries.Count > 0)
            {
                var rows = _gridBuilder.GetChatPriceRows(filterSummaries);

                var dictionary = _chatPriceDictionaryService.CreateDictionary(rows);

                _chatPriceUpdateService.RefreshPriceMonitors(filterIds, dictionary, dispatcherExecutionService);

                var refreshArgs = new ChatPriceGridRefreshArgs(bands, rows);

                _refreshArgs.OnNext(refreshArgs);
            }
            else
            {
                _refreshArgs.OnNext(new ChatPriceGridRefreshArgs(new List<BandInfo>(), new List<ChatPriceRowViewModel>()));
            }

            _semaphoreSlim.Release();
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _snapshotDisposable?.Dispose();
            }

            _disposed = true;
        }
    }
}
