﻿using System;
using System.Collections.Generic;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public class ChatPriceUpdateService : IChatPriceUpdateService
    {
        private readonly Dictionary<int, IChatPriceSummaryMonitor> _monitors = new();
        private readonly IChatPriceSummaryStreamProvider _chatPriceSummaryStreamProvider;

        public ChatPriceUpdateService(IChatPriceSummaryStreamProvider chatPriceSummaryStreamProvider)
        {
            _chatPriceSummaryStreamProvider = chatPriceSummaryStreamProvider;
        }

        [Inject]
        public IServiceFactory<IChatPriceSummaryMonitor> MonitorFactory { get; set; }

        public void RefreshPriceMonitors(IList<int> filter,
                                         Dictionary<int, List<ChatPriceCellViewModel>> chatPriceDictionary,
                                         IDispatcherExecutionService dispatcherExecutionService)
        {
            ArgumentNullException.ThrowIfNull(chatPriceDictionary);

            RemoveOldMonitors();

            foreach (var id in filter)
            {
                var monitor = MonitorFactory.Create();

                if (!chatPriceDictionary.TryGetValue(id, out var priceCells))
                {
                    continue;
                }

                var chatPrices = _chatPriceSummaryStreamProvider.GetPriceStream(id);

                monitor.MonitorChatPrices(chatPrices, priceCells, dispatcherExecutionService);

                _monitors.Add(id, monitor);
            }
        }

        private void RemoveOldMonitors()
        {
            if (_monitors.Count == 0)
            {
                return;
            }

            foreach (var monitor in _monitors)
            {
                monitor.Value.Dispose();
            }

            _monitors.Clear();
        }
    }
}
