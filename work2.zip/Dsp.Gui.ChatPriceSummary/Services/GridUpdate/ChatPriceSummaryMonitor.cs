﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using Dsp.DataContracts;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public sealed class ChatPriceSummaryMonitor : IChatPriceSummaryMonitor
    {
        private readonly SerialDisposable _disposable = new();

        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~ChatPriceSummaryMonitor()
        {
            Dispose(false);
        }

        public void MonitorChatPrices(IObservable<DataContracts.ChatScraper.ChatPriceSummary> chatPriceSummary, 
                                      List<ChatPriceCellViewModel> priceCells,
                                      IDispatcherExecutionService dispatcher)
        {
            _disposable.Disposable 
                = chatPriceSummary.Subscribe(cps => UpdateChatPrices(cps, 
                                                                     priceCells, 
                                                                     dispatcher));
        }

        private static void UpdateChatPrices(DataContracts.ChatScraper.ChatPriceSummary chatPriceSummary,
                                             IReadOnlyCollection<ChatPriceCellViewModel> priceCells,
                                             IDispatcherExecutionService dispatcher)
        {
            if (chatPriceSummary.AnnualTenors != null)
            {
                var annualCells = priceCells.Where(cell => cell.TenorType == TenorType.Year)
                                            .ToList();

                UpdatePriceCells(chatPriceSummary.AnnualTenors, annualCells, dispatcher);
            }

            if (chatPriceSummary.QuarterlyTenors != null)
            {
                var quarterlyCells = priceCells.Where(cell => cell.TenorType == TenorType.Quarter)
                                               .ToList();

                UpdatePriceCells(chatPriceSummary.QuarterlyTenors, quarterlyCells, dispatcher);
            }

            if (chatPriceSummary.MonthlyTenors != null)
            {
                var monthlyCells = priceCells.Where(cell => cell.TenorType == TenorType.Month)
                                             .ToList();

                UpdatePriceCells(chatPriceSummary.MonthlyTenors, monthlyCells, dispatcher);
            }
        }

        private static void UpdatePriceCells(List<DataContracts.ChatScraper.ChatPriceSummary.ChatPriceTenor> chatPriceTenors, 
                                             IEnumerable<ChatPriceCellViewModel> priceCells, 
                                             IDispatcherExecutionService dispatcher)
        {
            chatPriceTenors.ForEach(tenor =>
            {
                var priceCell = priceCells.FirstOrDefault(cell => cell.Model.Tenor.Key == tenor.TenorKey);

                if (priceCell == null)
                {
                    return;
                }

                if (priceCell.Model.BidTime == null || priceCell.Model.BidTime < tenor.BidTime)
                {
                    priceCell.Model.BidTime = tenor.BidTime;

                    dispatcher.Schedule(() =>
                    {
                        priceCell.BidBroker = tenor.BidBroker;
                        priceCell.BidPrice = tenor.BidPrice;
                        priceCell.BidTime = tenor.BidTime;
                    });
                }

                if (priceCell.Model.AskTime == null || priceCell.Model.AskTime < tenor.AskTime)
                {
                    priceCell.Model.AskTime = tenor.AskTime;

                    dispatcher.Schedule(() =>
                    {
                        priceCell.AskBroker = tenor.AskBroker;
                        priceCell.AskPrice = tenor.AskPrice;
                        priceCell.AskTime = tenor.AskTime;
                    });
                }
            });
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposable.Dispose();
            }

            _disposed = true;
        }
    }
}
