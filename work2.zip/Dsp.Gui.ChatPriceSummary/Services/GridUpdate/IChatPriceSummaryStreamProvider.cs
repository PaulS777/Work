﻿using System;

namespace Dsp.Gui.ChatPriceSummary.Services.GridUpdate
{
    public interface IChatPriceSummaryStreamProvider
    {
        IObservable<DataContracts.ChatScraper.ChatPriceSummary> GetPriceStream(int id);
    }
}
