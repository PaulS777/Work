﻿using System;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Settings
{
    [Serializable]
    public class ChatPriceGridSettings
    {
        public int PriceGridId { get; set; }
        public string Name { get; set; }

        public class ColumnWidth
        {
            public ColumnType ColumnType { get; set; }
            public double Width { get; set; }
        }

        public class MarketBand
        {
            public int ChatPriceSummaryId { get; set; }

            public ColumnWidth[] ColumnWidths { get; set; }
        }


        public MarketBand[] MarketBands { get; set; }

        public ColumnType[] VisibleColumns { get; set; }
    }
}
