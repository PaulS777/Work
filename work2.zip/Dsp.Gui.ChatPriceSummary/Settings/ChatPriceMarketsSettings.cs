﻿using System;

namespace Dsp.Gui.ChatPriceSummary.Settings
{
    [Serializable]
    public class ChatPriceMarketsSettings
    {
        public int MarketsId { get; set; }
        public string MarketsName { get; set; }
        public ChatPriceGridSettings[] ChatPriceGrids { get; set; }
    }
}
