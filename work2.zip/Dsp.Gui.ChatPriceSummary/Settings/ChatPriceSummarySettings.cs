﻿using System;

namespace Dsp.Gui.ChatPriceSummary.Settings
{
    [Serializable]
    public class ChatPriceSummarySettings
    {
        public ChatPriceMarketsSettings[] ChatPriceMarkets { get; set; }
    }
}
