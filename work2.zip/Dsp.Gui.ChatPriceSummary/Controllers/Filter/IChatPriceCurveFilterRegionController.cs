﻿using System;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;

namespace Dsp.Gui.ChatPriceSummary.Controllers.Filter
{
    public interface IChatPriceCurveFilterRegionController : IDisposable
    {
        ChatPriceCurveFilterRegion ViewModel { get; }
    }
}
