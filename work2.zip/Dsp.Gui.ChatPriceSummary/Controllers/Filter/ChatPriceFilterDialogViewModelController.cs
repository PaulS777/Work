﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.Controllers.Filter
{
    public sealed class ChatPriceFilterDialogViewModelController : IChatPriceFilterDialogViewModelController
    {
        private readonly CompositeDisposable _disposables = new();
        private readonly TransactionContextState _showColumnFilterState = new();
        private readonly TransactionContextState _showCurveFilterState = new();

        private CompositeDisposable _selectedFilterDisposable;
        private bool _canSelectNextFilter;
        private bool _canSelectPreviousFilter;
        private bool _canCloseDialog;
        private bool _disposed;

        public ChatPriceFilterDialogViewModelController(IChatPriceSummaryToolBarService toolBarService, 
                                                        ISchedulerProvider schedulerProvider)
        {
            ViewModel.ChatPriceFilters = new ObservableCollection<ChatPriceGridFiltersViewModel>();

            ViewModel.SelectNextFilterCommand = new DelegateCommand(OnSelectNextFilterCommand, () => _canSelectNextFilter);
            ViewModel.SelectPreviousFilterCommand = new DelegateCommand(OnSelectPreviousFilterCommand, () => _canSelectPreviousFilter);
            ViewModel.CloseDialogCommand = new DelegateCommand(OnCloseDialogCommand, () => _canCloseDialog);

            toolBarService.ShowMarketsFilter
                          .Where(_ => ViewModel.IsMarketsSelected)
                          .Subscribe(_ => OnToolBarShowMarketsFilter())
                          .AddTo(_disposables);

            toolBarService.ShowColumnSettings
                          .Where(_ => ViewModel.IsMarketsSelected)
                          .Subscribe(_ => OnToolBarShowColumnFilter())
                          .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.SelectedChatPriceFilterViewModel)
                     .Where(vm => vm.SelectedChatPriceFilterViewModel != null)
                     .Select(vm => vm.SelectedChatPriceFilterViewModel)
                     .ObserveOn(schedulerProvider.Dispatcher)
                     .Subscribe(SubscribeSelectedFilter)
                     .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatPriceFilterDialogViewModelController()
        {
            Dispose(false);
        }

        public ChatPriceFilterDialogViewModel ViewModel { get; } = new ();

        private void OnToolBarShowMarketsFilter()
        {
            using (new TransactionContextStateManager(_showCurveFilterState))
            {
                foreach (var chatPriceFilter in ViewModel.ChatPriceFilters)
                {
                    chatPriceFilter.CurveFilter.ShowFilter = true;
                }

                UpdateShowDialog();
            }
        }

        private void OnToolBarShowColumnFilter()
        {
            using (new TransactionContextStateManager(_showColumnFilterState))
            {
                foreach (var chatPriceFilter in ViewModel.ChatPriceFilters)
                {
                    chatPriceFilter.ColumnFilter.ShowFilter = true;
                }

                UpdateShowDialog();
            }
        }

        private void UpdateShowDialog()
        {
            ViewModel.ShowDialog =
                ViewModel.ChatPriceFilters.Any(f => f.CurveFilter.ShowFilter || f.ColumnFilter.ShowFilter);
        }

        private void SubscribeSelectedFilter(ChatPriceGridFiltersViewModel gridFilters)
        {
            _selectedFilterDisposable?.Dispose();
            _selectedFilterDisposable = new CompositeDisposable();

            gridFilters.ColumnFilter
                       .ObservePropertyChanged(vm => vm.ShowFilter)
                       .Where(vm => !vm.ShowFilter && !_showColumnFilterState.IsUpdating)
                       .Subscribe(OnCloseColumnFilter)
                       .AddTo(_selectedFilterDisposable);

            gridFilters.CurveFilter
                       .ObservePropertyChanged(vm => vm.ShowFilter)
                       .Where(vm => !vm.ShowFilter && !_showCurveFilterState.IsUpdating)
                       .Subscribe(OnCloseCurveFilter)
                       .AddTo(_selectedFilterDisposable);

            gridFilters.CurveFilter
                       .ObservePropertyChanged(vm => vm.ShowFilter)
                       .StartWith(gridFilters.CurveFilter)
                       .Where(vm => vm.ShowFilter && !_showCurveFilterState.IsUpdating)
                       .Subscribe(OnOpenCurveFilterFromFilterShowFilter)
                       .AddTo(_selectedFilterDisposable);

            gridFilters.CurveFilter
                       .ObservePropertyChanged(vm => vm.CanCancelFilterChanges)
                       .StartWith(gridFilters.CurveFilter)
                       .Subscribe(UpdateCanCloseDialogCommand)
                       .AddTo(_selectedFilterDisposable);

            UpdateFilterNavigationCommands(gridFilters);
        }


        private void OnCloseCurveFilter(ChatPriceCurveFilterViewModel curveFilter)
        {
            using (new TransactionContextStateManager(_showCurveFilterState))
            {
                var nonMatching = ViewModel.ChatPriceFilters
                                           .Select(f => f.CurveFilter)
                                           .Where(cf => cf != null
                                                        && !ReferenceEquals(cf, curveFilter))
                                           .ToList();

                nonMatching.ForEach(f => f.ShowFilter = false);

                UpdateShowDialog();
            }
        }

        private void OnCloseColumnFilter(ChatPriceColumnFilterViewModel columnFilter)
        {
            using (new TransactionContextStateManager(_showCurveFilterState))
            {
                var nonMatching = ViewModel.ChatPriceFilters
                                           .Select(f => f.ColumnFilter)
                                           .Where(cf => cf != null
                                                        && !ReferenceEquals(cf, columnFilter))
                                           .ToList();

                nonMatching.ForEach(f => f.ShowFilter = false);

                UpdateShowDialog();
            }
        }

        private void OnOpenCurveFilterFromFilterShowFilter(ChatPriceCurveFilterViewModel curveFilter)
        {
            using (new TransactionContextStateManager(_showCurveFilterState))
            {
                foreach (var filter in ViewModel.ChatPriceFilters.Select(cpf => cpf.CurveFilter))
                {
                    if (filter != null && !ReferenceEquals(curveFilter, filter))
                    {
                        filter.ShowFilter = true;
                    }
                }

                UpdateShowDialog();
            }
        }

        private void OnSelectNextFilterCommand()
        {
            var index = ViewModel.ChatPriceFilters.IndexOf(ViewModel.SelectedChatPriceFilterViewModel);

            if (index == ViewModel.ChatPriceFilters.Count - 1)
            {
                return;
            }

            ViewModel.SelectedChatPriceFilterViewModel = ViewModel.ChatPriceFilters[index + 1];
        }

        private void OnSelectPreviousFilterCommand()
        {
            var index = ViewModel.ChatPriceFilters.IndexOf(ViewModel.SelectedChatPriceFilterViewModel);

            if (index == 0)
            {
                return;
            }

            ViewModel.SelectedChatPriceFilterViewModel = ViewModel.ChatPriceFilters[index - 1];
        }

        private void OnCloseDialogCommand()
        {
            var filters = ViewModel.ChatPriceFilters.ToList();

            using (new TransactionContextStateManager(_showCurveFilterState))
            {
                using (new TransactionContextStateManager(_showColumnFilterState))
                {
                    filters.ForEach(filter =>
                    {
                        filter.ColumnFilter.ShowFilter = false;
                        filter.CurveFilter.ShowFilter = false; 
                    });

                    UpdateShowDialog();
                }
            }
        }

        private void UpdateFilterNavigationCommands(ChatPriceGridFiltersViewModel gridFilters)
        {
            var index = ViewModel.ChatPriceFilters.IndexOf(gridFilters);

            _canSelectNextFilter = index < ViewModel.ChatPriceFilters.Count - 1;
            _canSelectPreviousFilter = index > 0;

            ViewModel.SelectNextFilterCommand.RaiseCanExecuteChanged();
            ViewModel.SelectPreviousFilterCommand.RaiseCanExecuteChanged();
        }

        private void UpdateCanCloseDialogCommand(ChatPriceCurveFilterViewModel curveFilter)
        {
            _canCloseDialog = curveFilter.CanCancelFilterChanges;
            ViewModel.CloseDialogCommand.RaiseCanExecuteChanged();
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _selectedFilterDisposable?.Dispose();
            }

            _disposed = true;
        }
    }
}
