﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;

namespace Dsp.Gui.ChatPriceSummary.Controllers.Filter
{
    public sealed class ChatPriceCurveFilterRegionController : IChatPriceCurveFilterRegionController
    {
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly CompositeDisposable _disposables = new();
        private readonly SerialDisposable _curveGroupHeaderDisposable = new();

        private CompositeDisposable _curveItemDisposables;
        private bool _isHeaderUpdate;
        private bool _inItemUpdate;
        private bool _disposed;

        public ChatPriceCurveFilterRegionController(ISchedulerProvider schedulerProvider)
        {
            _schedulerProvider = schedulerProvider;

            ViewModel.ObservePropertyChanged(vm => vm.RegionHeader)
                     .Take(1)
                     .ObserveOn(_schedulerProvider.Dispatcher)
                     .Subscribe(OnRegionHeaderChanged)
                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.Items)
                     .ObserveOn(_schedulerProvider.Dispatcher)
                     .Subscribe(OnCurveItemsChanged)
                     .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatPriceCurveFilterRegionController()
        {
            Dispose(false);
        }

        public ChatPriceCurveFilterRegion ViewModel { get; } = new();

        private void OnRegionHeaderChanged(ChatPriceCurveFilterRegion viewModel)
        {
            viewModel.RegionHeader
                     .ObservePropertyChanged(vm => vm.IsSelected)
                     .Where(vm => vm.IsSelected.HasValue && !_inItemUpdate)
                      // ReSharper disable once PossibleInvalidOperationException
                     .Select(vm => vm.IsSelected.Value)
                     .Subscribe(OnCurveGroupHeaderSelectionChanged)
                     .AddTo(_disposables);
        }

        private void OnCurveGroupHeaderSelectionChanged(bool isSelected)
        {
            _isHeaderUpdate = true;

            foreach (var item in ViewModel.Items)
            {
                item.IsSelected = isSelected;
            }

            _isHeaderUpdate = false;
        }

        private void OnCurveItemsChanged(ChatPriceCurveFilterRegion viewModel)
        {
            _curveItemDisposables?.Dispose();
            _curveItemDisposables = new CompositeDisposable();

            viewModel.Items.ForEach(item =>
            {
                item.ObservePropertyChanged(i => i.IsSelected)
                    .Where(_ => !_isHeaderUpdate)
                    .ObserveOn(_schedulerProvider.Dispatcher)
                    .Subscribe(_ => OnCurveItemSelectionChanged())
                    .AddTo(_curveItemDisposables);
            });

            OnCurveItemSelectionChanged();
        }

        private void OnCurveItemSelectionChanged()
        {
            _inItemUpdate = true;

            if (ViewModel.Items.TrueForAll(c => c.IsSelected))
            {
                ViewModel.RegionHeader.IsSelected = true;
            }
            else if (ViewModel.Items.TrueForAll(c => !c.IsSelected))
            {
                ViewModel.RegionHeader.IsSelected = false;
            }
            else
            {
                ViewModel.RegionHeader.IsSelected = null;
            }

            _inItemUpdate = false;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _curveItemDisposables?.Dispose();
                _curveGroupHeaderDisposable.Disposable?.Dispose();
            }

            _disposed = true;
        }
    }
}
