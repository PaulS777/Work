﻿using System;
using System.Collections.ObjectModel;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Dsp.Gui.Dashboard.Common.Services.Connection;
using Dsp.Gui.Dashboard.Common.Services.ToolBar;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.Controllers
{
    public sealed class ChatPriceSummaryViewModelController : IChatPriceSummaryViewModelController
    {
        private readonly IChatPriceSummaryToolBarService _toolBarService;
        private readonly IChatPriceSummarySettingsService _settingsService;
        private readonly IChatPriceMarketsBuilder _chatPriceMarketsBuilder;
        private readonly IChatPriceMarketsRemovalService _marketsRemovalService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly CompositeDisposable _disposables = new();
        private readonly SerialDisposable _settingsDisposable = new();

        private CompositeDisposable _selectedMarketsDisposable;
        private bool _disposed;

        public ChatPriceSummaryViewModelController(IChatPriceSummaryToolBarService toolBarService,
                                                   IChatPriceSummarySettingsService settingsService,
                                                   IConnectionRunStateMonitor connectionRunStateMonitor,
                                                   IChatPriceMarketsBuilder chatPriceMarketsBuilder,
                                                   IChatPriceMarketsRemovalService marketsRemovalService,
                                                   ISchedulerProvider schedulerProvider)
        {
            _toolBarService = toolBarService;
            _settingsService = settingsService;
            _chatPriceMarketsBuilder = chatPriceMarketsBuilder;
            _marketsRemovalService = marketsRemovalService;
            _schedulerProvider = schedulerProvider;

            ViewModel = new ChatPriceSummaryViewModel
            {
                ChatPriceMarkets = new ObservableCollection<ChatPriceMarketsViewModel>(),
                AddChatPriceMarketsCommand = new DelegateCommand(OnAddNewChatPriceGridMarkets),
                RemoveMarketsDialogPrompt = new MessageDialogPromptViewModel()
            };

            _settingsService.LoadSettings();

            connectionRunStateMonitor.RunState
                                     .Where(state => state.In(SystemRunConnectState.Connected, 
                                                              SystemRunConnectState.Reconnected))
                                     .ObserveOn(_schedulerProvider.Dispatcher)
                                     .Subscribe(_ => SubscribeChatPriceSummarySettings())
                                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.SelectedChatPriceMarkets)
                     .StartWith(ViewModel)
                     .Subscribe(_ => CalculateCanAddNewChatPriceGridCommand())
                     .AddTo(_disposables);

            _toolBarService.AddPriceGrid
                           .Subscribe(_ => OnAddNewChatPriceGrid())
                           .AddTo(_disposables);

            _marketsRemovalService.RegisterSummary(ViewModel);
        }

        ~ChatPriceSummaryViewModelController()
        {
            Dispose(false);
        }

        public ChatPriceSummaryViewModel ViewModel { get; }

        private void SubscribeChatPriceSummarySettings()
        {
            _settingsDisposable.Disposable
                = _settingsService.ChatPriceSummarySettings
                                  .Where(settings => settings != null)
                                  .ObserveOn(_schedulerProvider.Dispatcher)
                                  .Subscribe(OnChatPriceSummarySettings);
        }

        private void OnChatPriceSummarySettings(ChatPriceSummarySettings settings)
        {
            foreach (var chatPriceMarketsSettings in settings.ChatPriceMarkets)
            {
                var chatPriceMarket = _chatPriceMarketsBuilder.GetMarketsFromSettings(chatPriceMarketsSettings);

                ViewModel.ChatPriceMarkets.Add(chatPriceMarket);
            }

            RefreshMonitorSelectedMarkets();

            ViewModel.ChatPriceMarkets[0].IsSelected = true;
        }

        private void RefreshMonitorSelectedMarkets()
        {
            _selectedMarketsDisposable?.Dispose();
            _selectedMarketsDisposable = new CompositeDisposable();

            foreach (var market in ViewModel.ChatPriceMarkets)
            {
                market.ObservePropertyChanged(vm => vm.IsSelected)
                      .Where(vm => vm.IsSelected)
                      .Subscribe(OnSelectedMarketsChanged)
                      .AddTo(_selectedMarketsDisposable);
            }
        }

        private void OnSelectedMarketsChanged(ChatPriceMarketsViewModel selectedMarkets)
        {
            ViewModel.SelectedChatPriceMarkets = selectedMarkets;

            foreach (var market in ViewModel.ChatPriceMarkets)
            {
                if (!ReferenceEquals(market, selectedMarkets))
                {
                    market.IsSelected = false;
                }
            }
        }

        private void OnAddNewChatPriceGridMarkets()
        {
            var settings = _settingsService.CreateNewChatPriceMarkets();

            var chatPriceMarket = _chatPriceMarketsBuilder.GetMarketsFromSettings(settings);

            chatPriceMarket.MarketsId = settings.MarketsId;
            chatPriceMarket.Name = settings.MarketsName;

            ViewModel.ChatPriceMarkets.Add(chatPriceMarket);

            RefreshMonitorSelectedMarkets();

            chatPriceMarket.IsSelected = true;
        }

        private void OnAddNewChatPriceGrid()
        {
            var settings = _settingsService.CreateNewPriceGrid(ViewModel.SelectedChatPriceMarkets.MarketsId);

            _chatPriceMarketsBuilder.AddChatPriceGridToMarkets(settings.PriceGridId, 
                                                               ViewModel.SelectedChatPriceMarkets);
        }

        private void ClearChatPriceMarkets()
        {
            foreach (var chatPriceMarkets in ViewModel.ChatPriceMarkets)
            {
                chatPriceMarkets.Dispose();
            }

            ViewModel.ChatPriceMarkets.Clear();
        }

        private void CalculateCanAddNewChatPriceGridCommand()
        {
            var canAddPriceGrid = ViewModel.SelectedChatPriceMarkets != null;
            _toolBarService.SetCanAddPriceGrid(canAddPriceGrid);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _settingsDisposable?.Dispose();

                _marketsRemovalService.UnRegisterSummary(ViewModel);

                ClearChatPriceMarkets();
            }

            _disposed = true;
        }
    }
}
