﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.Gui.ChatPriceSummary.Services.Filter;
using Dsp.Gui.ChatPriceSummary.Services.GridUpdate;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Dsp.Gui.Common.Extensions;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.Controllers
{
    public sealed class ChatPriceGridViewModelController : IChatPriceGridViewModelController
    {
        private readonly IChatPriceSummarySettingsService _settingsService;
        private readonly ICurveFilterDialogService _curveFilterDialogService;
        private readonly IColumnFilterDialogService _columnFilterDialogService;
        private readonly IChatPriceColumnWidthService _columnWidthService;
        private readonly IChatPriceGridRefreshService _chatPriceGridRefreshService;
        private readonly IDispatcherExecutionService _dispatcherExecutionService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly CompositeDisposable _disposables = new();
        private readonly ICurveFilterLoadedService _curveFilterLoadedService;
        private readonly IColumnFilterLoadedService _columnFilterLoadedService;
        private IChatPriceGridRemovalService _gridRemovalService;   
        private bool _disposed;

        public ChatPriceGridViewModelController(IChatPriceSummarySettingsService settingsService,
                                                ICurveFilterLoadedService curveFilterLoadedService, 
                                                IColumnFilterLoadedService columnFilterLoadedService,
                                                ICurveFilterDialogService curveFilterDialogService,
                                                IColumnFilterDialogService columnFilterDialogService,
                                                IChatPriceGridRefreshService chatPriceGridRefreshService,
                                                IChatPriceColumnWidthService columnWidthService,
                                                IDispatcherExecutionService dispatcherExecutionService,
                                                ISchedulerProvider schedulerProvider)
        {
            _settingsService = settingsService;
            _curveFilterLoadedService = curveFilterLoadedService;
            _columnFilterLoadedService = columnFilterLoadedService;
            _curveFilterDialogService = curveFilterDialogService;
            _columnFilterDialogService = columnFilterDialogService;
            _chatPriceGridRefreshService = chatPriceGridRefreshService;
            _columnWidthService = columnWidthService;
            _dispatcherExecutionService = dispatcherExecutionService;
            _schedulerProvider = schedulerProvider;

            ViewModel = new ChatPriceGridViewModel(this)
            {
                ChatPriceGridFilters = new ChatPriceGridFiltersViewModel
                {
                    CurveFilter = new ChatPriceCurveFilterViewModel
                    {
                        FilterGroups = new List<ChatPriceCurveFilterGroup>(),
                        FilterItems = new List<ChatPriceCurveFilterItem>()
                    },
                    ColumnFilter = new ChatPriceColumnFilterViewModel
                    {
                        FilterItems = new List<ChatPriceColumnFilterItem>()
                    }
                },
                IsBusy = true,
                BusyText = "Loading Chat Price Curve Filter..."
            };

            ViewModel.ChatPriceCurveFilter
                     .ObservePropertyChanged(f => f.ShowFilter)
                     .Where(f => f.CanRemoveFilter && !f.ShowFilter)
                     .Subscribe(OnCurveFilterClosed)
                     .AddTo(_disposables);

            _curveFilterDialogService.AttachFilterDialog(ViewModel.ChatPriceCurveFilter);
            _columnFilterDialogService.AttachFilterDialog(ViewModel.ChatPriceColumnFilter);

            _curveFilterDialogService.ApplyFilterChangesCommand
                                     .Subscribe(_ => OnApplyCurveFilterChangesCommand())
                                     .AddTo(_disposables);

            _columnFilterDialogService.ApplyFilterChangesCommand
                                      .Subscribe(_ => OnApplyColumnFilterChangesCommand())
                                      .AddTo(_disposables);

            ViewModel.RemoveChatPriceGridCommand = new DelegateCommand(RemoveGrid, () => ViewModel.CanRemoveGrid);

            ViewModel.ObservePropertyChanged(vm => vm.CanRemoveGrid)
                     .ObserveOn(_schedulerProvider.Dispatcher)
                     .Subscribe(_ => OnCanRemoveGrid())
                     .AddTo(_disposables);

            _chatPriceGridRefreshService.GridRefresh
                                        .Where(r => r != null)
                                        .ObserveOn(schedulerProvider.Dispatcher)
                                        .Subscribe(OnGridRefreshed)
                                        .AddTo(_disposables);

            var columnsLoaded = _columnFilterLoadedService.ColumnFilter
                                                          .Where(filter => filter != null)
                                                          .Take(1);

            var curvesLoaded = _curveFilterLoadedService.CurveFilter
                                                        .Where(filter => filter != null);

            var curvesAndColumns = curvesLoaded.CombineLatest(columnsLoaded, 
                                                              (curves, columns) => new {Curves = curves, Columns = columns});

            curvesAndColumns.Take(1)
                            .ObserveOn(_schedulerProvider.Dispatcher)
                            .Subscribe(o => OnCurvesAndColumnsLoaded(o.Curves, o.Columns))
                            .AddTo(_disposables);

            curvesAndColumns.Skip(1)
                            .Select(o => o.Curves)
                            .ObserveOn(_schedulerProvider.Dispatcher)
                            .Subscribe(OnCurveFilterLoaded)
                            .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~ChatPriceGridViewModelController()
        {
            Dispose(false);
        }

        [Inject]
        public IChatPriceCurveFilterCurveGroupBuilder ChatPriceCurveFilterCurveGroupBuilder { get; set; }

        public ChatPriceGridViewModel ViewModel { get; }

        public void Initialize(int marketsId, 
                               int priceGridId, 
                               IChatPriceGridRemovalService gridRemovalService)
        {
            _gridRemovalService = gridRemovalService;

            var priceGridName = $"ICE Chat Prices - {priceGridId}";

            InitializeViewModel(marketsId, 
                                priceGridId, 
                                priceGridName);

            _curveFilterLoadedService.Initialize();
            _columnFilterLoadedService.Initialize();
        }

        public void Initialize(int marketsId, 
                               ChatPriceGridSettings settings, 
                               IChatPriceGridRemovalService gridRemovalService)
        {
            _gridRemovalService = gridRemovalService;

            InitializeViewModel(marketsId, 
                                settings.PriceGridId, 
                                settings.Name);

            _curveFilterLoadedService.Initialize(settings);
            _columnFilterLoadedService.Initialize(settings);
        }

        private void InitializeViewModel(int marketsId, 
                                         int priceGridId,
                                         string priceGridName)
        {
            ViewModel.MarketsId = marketsId;
            ViewModel.PriceGridId = priceGridId;
            ViewModel.PriceGridName = priceGridName;
            ViewModel.ChatPriceGridFilters.Name = ViewModel.PriceGridName;

            ViewModel.ObservePropertyChanged(vm => vm.PriceGridName)
                     .Subscribe(_ => OnPriceGridNameChanged())
                     .AddTo(_disposables);
        }

        private void OnCurvesAndColumnsLoaded(List<ChatPriceCurveFilterItem> curveFilterItems,
                                              List<ChatPriceColumnFilterItem> columnFilterItems)
        {
            OnColumnFilterLoaded(columnFilterItems);
            OnCurveFilterLoaded(curveFilterItems);
        }

        private void OnCurveFilterLoaded(List<ChatPriceCurveFilterItem> filterItems)
        {
            _curveFilterDialogService.RefreshFilterItems(filterItems);

            ViewModel.ChatPriceCurveFilter.FilterItems = filterItems;

            ViewModel.ChatPriceCurveFilter.FilterGroups = ChatPriceCurveFilterCurveGroupBuilder.GetCurveFilterGroups(filterItems);

            var selectedCurveFilterItems = filterItems.FindAll(i => i.IsSelected);

            if (selectedCurveFilterItems.Any())
            {
                LoadGridFromCurveFilter(selectedCurveFilterItems);
            }
            else
            {
                ViewModel.IsBusy = false;
                ViewModel.BusyText = null;
                ViewModel.ChatPriceCurveFilter.ShowFilter = true;
            }
        }

        private void OnColumnFilterLoaded(List<ChatPriceColumnFilterItem> columnFilterItems)
        {
            _columnFilterDialogService.RefreshFilterItems(columnFilterItems);

            ViewModel.ChatPriceColumnFilter.FilterItems = columnFilterItems;
        }

        private void OnApplyCurveFilterChangesCommand()
        {
            var selectedCurveFilterItems = ViewModel.ChatPriceCurveFilter
                                                    .FilterItems
                                                    .Where(item => item.IsSelected)
                                                    .ToList();

            var ids = selectedCurveFilterItems.Select(item => item.Id)
                                              .ToList();

            _settingsService.SaveMarketsFilter(ViewModel.MarketsId, ViewModel.PriceGridId, ids);

            LoadGridFromCurveFilter(selectedCurveFilterItems);
        }

        private void OnApplyColumnFilterChangesCommand()
        {
            var columns = GetSelectedColumns();

            _settingsService.SaveColumnsFilter(ViewModel.MarketsId, ViewModel.PriceGridId, columns);

            ApplyColumnFilter(columns);
        }

        private void OnCanRemoveGrid()
        {
            ViewModel.ChatPriceCurveFilter.CanRemoveFilter = ViewModel.CanRemoveGrid;
            ViewModel.ChatPriceColumnFilter.CanRemoveFilter = ViewModel.CanRemoveGrid;

            ViewModel.RemoveChatPriceGridCommand.RaiseCanExecuteChanged();
        }

        private List<ColumnType> GetSelectedColumns()
        {
            return ViewModel.ChatPriceColumnFilter
                            .FilterItems
                            .Where(item => item.IsSelected)
                            .Select(item => item.ColumnType)
                            .ToList();
        }

        private void LoadGridFromCurveFilter(IList<ChatPriceCurveFilterItem> curves)
        {
            ViewModel.IsBusy = true;
            ViewModel.BusyText = "Loading Chat Prices...";
            ViewModel.ChatPriceSummaryReady = false;

            ViewModel.BandInfos = null;
            ViewModel.ChatPriceRows = null;

            _dispatcherExecutionService.Stop();

            _chatPriceGridRefreshService.BuildGrid(curves, _dispatcherExecutionService);
        }

        private void OnGridRefreshed(ChatPriceGridRefreshArgs args)
        {
            ViewModel.PriceGridLoaded = true;
            ViewModel.BandInfos = args.Bands;

            var columns = GetSelectedColumns();

            ApplyColumnFilter(columns);

            var priceBands = ViewModel.BandInfos
                                      .Where(band => band.BandType == BandType.Price)
                                      .ToList();

            _columnWidthService.ApplyColumnWidths(ViewModel.MarketsId, ViewModel.PriceGridId, priceBands);

            ViewModel.ChatPriceRows = new ObservableCollection<ChatPriceRowViewModel>(args.ChatPriceRows);
            
            _columnWidthService.MonitorColumnWidthChanges(ViewModel.MarketsId, 
                                                          ViewModel.PriceGridId, 
                                                          priceBands, 
                                                          _schedulerProvider.TaskPool);

            _dispatcherExecutionService.Start();

            ViewModel.ChatPriceSummaryReady = true;
            ViewModel.IsBusy = false;
            ViewModel.BusyText = null;
        }

        private void ApplyColumnFilter(IReadOnlyCollection<ColumnType> columns)
        {
            if (ViewModel.BandInfos == null)
            {
                return;
            }

            foreach (var bandInfo in ViewModel.BandInfos.Where(band => band.BandType == BandType.Price))
            {
                foreach (var columnInfo in bandInfo.ColumnInfos)
                {
                    columnInfo.IsVisible = columns.Any(column => column == columnInfo.ColumnType);
                }
            }
        }

        private void OnPriceGridNameChanged()
        {
            ViewModel.ChatPriceGridFilters.Name = ViewModel.PriceGridName;

            _settingsService.SavePriceGridName(ViewModel.MarketsId, ViewModel.PriceGridId, ViewModel.PriceGridName);
        }

        private void OnCurveFilterClosed(ChatPriceCurveFilterViewModel curveFilter)
        {
            if (curveFilter.FilterItems.Any(i => i.OriginalIsSelected))
            {
                return;
            }

            RemoveGrid();
        }

        private void RemoveGrid()
        {
            _gridRemovalService.RemoveGrid(ViewModel);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _curveFilterLoadedService.Dispose();
                _curveFilterDialogService.Dispose();
                _columnFilterDialogService.Dispose();
                _columnWidthService.Dispose();
                _chatPriceGridRefreshService.Dispose();
                _columnFilterLoadedService.Dispose();

                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
