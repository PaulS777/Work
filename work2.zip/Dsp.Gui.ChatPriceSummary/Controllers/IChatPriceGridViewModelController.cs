﻿using System;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Controllers
{
    public interface IChatPriceGridViewModelController : IDisposable
    {
        ChatPriceGridViewModel ViewModel { get; }

        void Initialize(int marketsId,
                        int priceGridId, 
                        IChatPriceGridRemovalService gridRemovalService);

        void Initialize(int marketsId,
                        ChatPriceGridSettings settings, 
                        IChatPriceGridRemovalService gridRemovalService);
    }
}
