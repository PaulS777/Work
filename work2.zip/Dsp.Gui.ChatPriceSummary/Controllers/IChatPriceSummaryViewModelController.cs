﻿using System;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Controllers
{
    public interface IChatPriceSummaryViewModelController : IDisposable
    {
        ChatPriceSummaryViewModel ViewModel { get; }
    }
}
