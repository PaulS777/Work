﻿using System;
using System.Collections.ObjectModel;
using System.Reactive.Disposables;
using Dsp.Gui.ChatPriceSummary.Controllers.Filter;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.Services.Settings;
using Dsp.Gui.ChatPriceSummary.ViewModels;
using Dsp.Gui.Common.Extensions;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.Controllers
{
    public sealed class ChatPriceMarketsViewModelController : IChatPriceMarketsViewModelController
    {
        private readonly IChatPriceFilterDialogViewModelController _chatPriceFilterDialogViewModelController;
        private readonly IChatPriceMarketsRemovalService _marketsRemovalService;
        private readonly CompositeDisposable _disposables = new();

        private IChatPriceGridRemovalService _chatPriceGridRemovalService;
        private bool _disposed;

        public ChatPriceMarketsViewModelController(IChatPriceFilterDialogViewModelController chatPriceFilterDialogViewModelController,
                                                   IChatPriceSummarySettingsService settingsService,
                                                   IChatPriceMarketsRemovalService marketsRemovalService)
        {
            _chatPriceFilterDialogViewModelController = chatPriceFilterDialogViewModelController;
            _marketsRemovalService = marketsRemovalService;

            ViewModel = new ChatPriceMarketsViewModel(this)
            {
                ChatPriceGrids = new ObservableCollection<ChatPriceGridViewModel>(),
                ChatPriceFilterDialog = chatPriceFilterDialogViewModelController.ViewModel,
                MessageDialogPrompt = new MessageDialogPromptViewModel(),
                RemoveMarketsCommand = new DelegateCommand(OnRemoveMarketsCommand, () => ViewModel.CanRemoveMarkets)
            };

            ViewModel.SetSelectedCommand = new DelegateCommand(() => ViewModel.IsSelected = true);

            ViewModel.ObservePropertyChanged(vm => vm.Name)
                     .Subscribe(_ => settingsService.SaveMarketsName(ViewModel.MarketsId, ViewModel.Name))
                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.IsSelected)
                     .Subscribe(_ => ViewModel.ChatPriceFilterDialog.IsMarketsSelected = ViewModel.IsSelected)
                     .AddTo(_disposables);

            ViewModel.ObservePropertyChanged(vm => vm.CanRemoveMarkets)
                     .Subscribe(_ => ViewModel.RemoveMarketsCommand.RaiseCanExecuteChanged())
                     .AddTo(_disposables);
        }

        ~ChatPriceMarketsViewModelController()
        {
            Dispose(false);
        }

        public ChatPriceMarketsViewModel ViewModel { get; }

        public void Initialize(int marketsId, 
                               string marketsName,
                               IChatPriceGridRemovalService chatPriceGridRemovalService)
        {
            ViewModel.MarketsId = marketsId;
            ViewModel.Name = marketsName;

            _chatPriceGridRemovalService = chatPriceGridRemovalService;

            _chatPriceGridRemovalService.RegisterMarkets(ViewModel);
        }

        private void OnRemoveMarketsCommand()
        {
            _marketsRemovalService.RemoveMarkets(ViewModel);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _chatPriceFilterDialogViewModelController.Dispose();

                _chatPriceGridRemovalService?.UnRegisterMarkets(ViewModel);

                foreach (var chatPriceGrid in ViewModel.ChatPriceGrids)
                {
                    chatPriceGrid.Dispose();
                }

                ViewModel.ChatPriceGrids.Clear();
            }

            _disposed = true;
        }
    }
}
