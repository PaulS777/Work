﻿using System;
using Dsp.Gui.ChatPriceSummary.Services.Markets;
using Dsp.Gui.ChatPriceSummary.ViewModels;

namespace Dsp.Gui.ChatPriceSummary.Controllers
{
    public interface IChatPriceMarketsViewModelController : IDisposable
    {
        ChatPriceMarketsViewModel ViewModel { get; }

        void Initialize(int marketsId,
                        string marketsName,
                        IChatPriceGridRemovalService chatPriceGridRemovalService);
    }
}
