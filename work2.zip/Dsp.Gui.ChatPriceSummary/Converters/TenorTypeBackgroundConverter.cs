﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using Dsp.DataContracts;

namespace Dsp.Gui.ChatPriceSummary.Converters
{
    [ExcludeFromCodeCoverage]
    public class TenorTypeBackgroundConverter : IValueConverter
    {
        public SolidColorBrush YearlyBrush { get; set; }
        public SolidColorBrush QuarterlyBrush { get; set; }
        public SolidColorBrush MonthlyBrush { get; set; }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is not TenorType rowTenorType)
            {
                return null;
            }

            return rowTenorType switch
                   {
                       TenorType.Year => YearlyBrush,
                       TenorType.Quarter => QuarterlyBrush,
                       _ => MonthlyBrush
                   };
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
