﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows.Data;

namespace Dsp.Gui.ChatPriceSummary.Converters
{
    [ExcludeFromCodeCoverage]
    public class GridControlWidthConverter : IValueConverter
    {
        private const int WidthAdjustment = 20;

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var width = value as double?;

            return width - WidthAdjustment;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
