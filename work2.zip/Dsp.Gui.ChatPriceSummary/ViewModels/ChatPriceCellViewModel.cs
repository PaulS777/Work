﻿using System;
using Dsp.DataContracts;
using Dsp.Gui.ChatPriceSummary.Common;
using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels
{
    public class ChatPriceCellViewModel : BindableBase
    {
        private double? _bidPrice;
        private DateTime? _bidTime;
        private string _bidBroker;
        private double? _askPrice;
        private DateTime? _askTime;
        private string _askBroker;

        public ChatPriceCellViewModel(TenorType tenorType,
                                      ChatPrice chatPrice,
                                      bool alternateBand = false)
        {
            Model = chatPrice;
            TenorType = tenorType;
            AlternateBand = alternateBand;
        }

        public TenorType TenorType { get; }
        public bool AlternateBand { get; }
        public ChatPrice Model { get; }

        public double? BidPrice
        {
            get => _bidPrice;
            set
            {
                _bidPrice = value;
                RaisePropertyChanged();
            }
        }

        public DateTime? BidTime
        {
            get => _bidTime;
            set
            {
                _bidTime = value;
                RaisePropertyChanged();
            }
        }

        public string BidBroker
        {
            get => _bidBroker;
            set
            {
                _bidBroker = value;
                RaisePropertyChanged();
            }
        }

        public double? AskPrice
        {
            get => _askPrice;
            set
            {
                _askPrice = value;
                RaisePropertyChanged();
            }
        }

        public DateTime? AskTime
        {
            get => _askTime;
            set
            {
                _askTime = value;
                RaisePropertyChanged();
            }
        }

        public string AskBroker
        {
            get => _askBroker;
            set
            {
                _askBroker = value;
                RaisePropertyChanged();
            }
        }
    }
}
