﻿using System;
using System.Collections.ObjectModel;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.ViewModels
{
    public sealed class ChatPriceMarketsViewModel : BindableBase, IDisposable
    {
        private readonly IDisposable _controller;
        private ObservableCollection<ChatPriceGridViewModel> _chatPriceGrids;
        private ChatPriceGridViewModel _selectedChatPriceGrid;
        private bool _canRemoveMarkets;
        private string _name;
        private bool _isSelected;
        private bool _disposed;

        public ChatPriceMarketsViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        ~ChatPriceMarketsViewModel()
        {
            Dispose(false);
        }

        public DelegateCommand SetSelectedCommand { get; set; }
        public DelegateCommand RemoveMarketsCommand { get; set; }
        public int MarketsId { get; set; }
        public ChatPriceFilterDialogViewModel ChatPriceFilterDialog { get; set; }
        public MessageDialogPromptViewModel MessageDialogPrompt { get; set; }

        public ObservableCollection<ChatPriceGridViewModel> ChatPriceGrids
        {
            get => _chatPriceGrids;
            set
            {
                _chatPriceGrids = value;
                RaisePropertyChanged();
            }
        }

        // used for filter
        public ChatPriceGridViewModel SelectedChatPriceGrid
        {
            get => _selectedChatPriceGrid;
            set
            {
                _selectedChatPriceGrid = value;
                RaisePropertyChanged();
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                RaisePropertyChanged();
            }
        }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                RaisePropertyChanged();
            }
        }

        public bool CanRemoveMarkets
        {
            get => _canRemoveMarkets;
            set
            {
                _canRemoveMarkets = value;
                RaisePropertyChanged();
            }
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller.Dispose();
            }

            _disposed = true;
        }
    }
}
