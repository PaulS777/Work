﻿using System.Collections.ObjectModel;
using Dsp.DataContracts;
using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels
{
    public class ChatPriceRowViewModel : BindableBase
    {
        private ObservableCollection<ChatPriceCellViewModel> _priceCells;

        public ChatPriceRowViewModel(ITenor tenor, ITenor parentTenor)
            : this(tenor)
        {
            ParentTenorDisplay = parentTenor?.ToString();
        }

        public ChatPriceRowViewModel(ITenor tenor)
        {
            Tenor = tenor;
            TenorDisplay = tenor.ToString();
            TenorType = tenor.TenorType();

            PriceCells = new ObservableCollection<ChatPriceCellViewModel>();
        }

        public TenorType TenorType { get; }
        public ITenor Tenor { get; }
        public string TenorDisplay { get; }
        public string ParentTenorDisplay { get; }

        public ObservableCollection<ChatPriceCellViewModel> PriceCells
        {
            get => _priceCells;
            set
            {
                _priceCells = value;
                RaisePropertyChanged();
            }
        }
    }
}
