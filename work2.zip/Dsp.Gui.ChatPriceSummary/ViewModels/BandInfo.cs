﻿using System.Collections.Generic;

namespace Dsp.Gui.ChatPriceSummary.ViewModels
{
    public enum BandType
    {
        Tenor,
        Price
    }

    public class BandInfo
    {
        public BandInfo(BandType bandType)
        {
            BandType = bandType;
        }

        public BandInfo(BandType bandType,
                        int id,
                        string header,
                        string toolTip,
                        bool isAlternateBand,
                        IList<ColumnInfo> columnInfos)
        {
            BandType = bandType;
            Id = id;
            Header = header;
            ToolTip = toolTip;
            IsAlternateBand = isAlternateBand;
            ColumnInfos = columnInfos;
        }

        public BandType BandType { get; }
        public int Id { get; }
        public string Header { get; }
        public string ToolTip { get; }
        public bool IsAlternateBand { get; }
        public IList<ColumnInfo> ColumnInfos { get; set; }
    }
}
