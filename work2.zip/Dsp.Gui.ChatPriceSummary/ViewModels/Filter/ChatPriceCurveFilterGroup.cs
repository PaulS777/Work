﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public class ChatPriceCurveFilterGroup : BindableBase
    {
        private CurveGroup _curveGroup;
        private string _groupHeader;
        private List<ChatPriceCurveFilterRegion> _curveFilterRegions;

        public ChatPriceCurveFilterGroup(CurveGroup curveGroup)
        {
            ArgumentNullException.ThrowIfNull(curveGroup);

            CurveGroup = curveGroup;
            GroupHeader = curveGroup.Name;
        }

        public CurveGroup CurveGroup
        {
            get => _curveGroup;
            set
            {
                _curveGroup = value;
                RaisePropertyChanged();
            }
        }

        public string GroupHeader
        {
            get => _groupHeader;
            set
            {
                _groupHeader = value;
                RaisePropertyChanged();
            }
        }

        public List<ChatPriceCurveFilterRegion> CurveFilterRegions
        {
            get => _curveFilterRegions;
            set
            {
                _curveFilterRegions = value;
                RaisePropertyChanged();
            }
        }
    }
}
