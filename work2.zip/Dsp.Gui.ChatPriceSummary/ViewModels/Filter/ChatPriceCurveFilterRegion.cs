﻿using System.Collections.Generic;
using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public class ChatPriceCurveFilterRegion : BindableBase
    {
        private CurveRegionFilterHeader _regionHeader;
        private List<ChatPriceCurveFilterItem> _items;

        public CurveRegionFilterHeader RegionHeader
        {
            get => _regionHeader;
            set
            {
                _regionHeader = value;
                RaisePropertyChanged();
            }
        }

        public List<ChatPriceCurveFilterItem> Items
        {
            get => _items;
            set
            {
                _items = value;
                RaisePropertyChanged();
            }
        }
    }
}
