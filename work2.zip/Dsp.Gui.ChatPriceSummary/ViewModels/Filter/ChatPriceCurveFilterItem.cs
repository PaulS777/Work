﻿using System;
using Dsp.DataContracts.Curve;
using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public class ChatPriceCurveFilterItem : BindableBase, ISelectableFilterItem, ICloneable
    {
        private string _priceCurveName;
        private string _name;
        private bool _isSelected;

        public ChatPriceCurveFilterItem(int id, 
                                        string priceCurveName, 
                                        string name,
                                        CurveGroup curveGroup,
                                        CurveRegion curveRegion)
        {
            Id = id;
            PriceCurveName = priceCurveName;
            Name = name;
            CurveGroup = curveGroup;
            CurveRegion = curveRegion;
        }

        public int Id { get; }

        public CurveRegion CurveRegion { get; set; }
        public CurveGroup CurveGroup { get; set; }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                RaisePropertyChanged();
            }
        }
        public string PriceCurveName
        {
            get => _priceCurveName;
            set
            {
                _priceCurveName = value;
                RaisePropertyChanged();
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                RaisePropertyChanged();
            }
        }

        public bool OriginalIsSelected { get; set; }

        public int CompareTo(object obj)
        {
            return obj is not ChatPriceCurveFilterItem item ? 1 : Id.CompareTo(item.Id);
        }

        public object Clone()
        {
            return new ChatPriceCurveFilterItem(Id, PriceCurveName, Name, CurveGroup, CurveRegion);
        }
    }
}
