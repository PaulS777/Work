﻿using System.Collections.Generic;
using System.ComponentModel;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public interface IDialogFilter<T> : INotifyPropertyChanged
        where T : class, ISelectableFilterItem
    {
        DelegateCommand ApplyFilterChangesCommand { get; set; }
        DelegateCommand CancelFilterChangesCommand { get; set; }
        bool CanApplyFilterChanges { get; set; }
        bool CanCancelFilterChanges { get; set; }
        bool ShowFilter { get; set; }
        bool CanRemoveFilter { get; set; }
        IList<T> FilterItems { get; }
    }
}
