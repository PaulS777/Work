﻿using System;
using System.ComponentModel;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public interface ISelectableFilterItem : INotifyPropertyChanged, IComparable
    {
        bool IsSelected { get; set; }
        bool OriginalIsSelected { get; set; }
    }
}
