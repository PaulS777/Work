﻿using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    /// <summary>
    /// Encapsulates Curve and Columns filters.
    /// </summary>
    public sealed class ChatPriceGridFiltersViewModel : BindableBase
    {
        private string _name;

        public ChatPriceCurveFilterViewModel CurveFilter { get; set; }
        public ChatPriceColumnFilterViewModel ColumnFilter { get; set; }

        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                RaisePropertyChanged();
            }
        }
    }
}
