﻿using System.Collections.Generic;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public class ChatPriceCurveFilterViewModel : BindableBase, IDialogFilter<ChatPriceCurveFilterItem>
    {
        private IList<ChatPriceCurveFilterGroup> _filterGroups;
        private IList<ChatPriceCurveFilterItem> _filterItems;
        private bool _showFilter;
        private bool _canApplyFilter;
        private bool _canCancelFilter;
        private bool _canRemoveFilter;

        public DelegateCommand ApplyFilterChangesCommand { get; set; }
        public DelegateCommand CancelFilterChangesCommand { get; set; }

        public IList<ChatPriceCurveFilterGroup> FilterGroups
        {
            get => _filterGroups;
            set
            {
                _filterGroups = value;
                RaisePropertyChanged();
            }
        }

        public IList<ChatPriceCurveFilterItem> FilterItems
        {
            get => _filterItems;
            set
            {
                _filterItems = value;
                RaisePropertyChanged();
            }
        }

        public bool ShowFilter
        {
            get => _showFilter;
            set
            {
                if (_showFilter == value)
                {
                    return;
                }

                _showFilter = value;
                RaisePropertyChanged();
            }
        }

        public bool CanApplyFilterChanges
        {
            get => _canApplyFilter;
            set
            {
                _canApplyFilter = value;
                RaisePropertyChanged();
            }
        }

        public bool CanCancelFilterChanges
        {
            get => _canCancelFilter;
            set
            {
                _canCancelFilter = value;
                RaisePropertyChanged();
            }
        }

        public bool CanRemoveFilter
        {
            get => _canRemoveFilter;
            set
            {
                _canRemoveFilter = value;
                RaisePropertyChanged();
            }
        }
    }
}
