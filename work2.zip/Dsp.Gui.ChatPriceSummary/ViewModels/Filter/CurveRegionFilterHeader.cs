﻿using Dsp.DataContracts.Curve;
using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public class CurveRegionFilterHeader : BindableBase
    {
        private CurveRegion _region;
        private bool? _isSelected;
        private bool? _originalIsSelected;
        private string _regionName;

        public CurveRegionFilterHeader(CurveRegion curveRegion)
        {
            Region = curveRegion;
            RegionName = curveRegion.ToString();
        }

        public bool? IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected == value)
                {
                    return;
                }

                _isSelected = value;
                RaisePropertyChanged();
            }
        }

        public bool? OriginalIsSelected
        {
            get => _originalIsSelected;
            set
            {
                _originalIsSelected = value;
                RaisePropertyChanged();
            }
        }

        public CurveRegion Region
        {
            get => _region;
            set
            {
                _region = value;
                RaisePropertyChanged();
            }
        }

        public string RegionName
        {
            get => _regionName;
            set
            {
                _regionName = value;
                RaisePropertyChanged();
            }
        }
    }
}
