﻿using System.Collections.Generic;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public class ChatPriceColumnFilterViewModel : BindableBase, IDialogFilter<ChatPriceColumnFilterItem>
    {
        private IList<ChatPriceColumnFilterItem> _filterItems;
        private bool _showFilter;
        private bool _canApplyFilterChanges;
        private bool _canCancelFilterChanges;
        private bool _canRemoveFilter;

        public DelegateCommand ApplyFilterChangesCommand { get; set; }
        public DelegateCommand CancelFilterChangesCommand { get; set; }

        public IList<ChatPriceColumnFilterItem> FilterItems
        {
            get => _filterItems;
            set
            {
                _filterItems = value;
                RaisePropertyChanged();
            }
        }

        public bool ShowFilter
        {
            get => _showFilter;
            set
            {
                if (value == _showFilter)
                {
                    return;
                }

                _showFilter = value;
                RaisePropertyChanged();
            }
        }

        public bool CanApplyFilterChanges
        {
            get => _canApplyFilterChanges;
            set
            {
                _canApplyFilterChanges = value;
                RaisePropertyChanged();
            }
        }

        public bool CanCancelFilterChanges
        {
            get => _canCancelFilterChanges;
            set
            {
                _canCancelFilterChanges = value;
                RaisePropertyChanged();
            }
        }

        public bool CanRemoveFilter
        {
            get => _canRemoveFilter;
            set
            {
                _canRemoveFilter = value;
                RaisePropertyChanged();
            }
        }
    }
}
