﻿using System.Collections.ObjectModel;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public class ChatPriceFilterDialogViewModel : BindableBase
    {
        private bool _showDialog;
        private bool _isMarketsSelected;
        private ObservableCollection<ChatPriceGridFiltersViewModel> _chatPriceFilters;
        private ChatPriceGridFiltersViewModel _selectedChatPriceFilterViewModel;

        public DelegateCommand SelectNextFilterCommand { get; set; }
        public DelegateCommand SelectPreviousFilterCommand { get; set; }
        public DelegateCommand CloseDialogCommand { get; set; }

        public bool ShowDialog
        {
            get => _showDialog;
            set
            {
                _showDialog = value;
                RaisePropertyChanged();
            }
        }

        public bool IsMarketsSelected
        {
            get => _isMarketsSelected;
            set
            {
                _isMarketsSelected = value;
                RaisePropertyChanged();
            }
        }


        public ObservableCollection<ChatPriceGridFiltersViewModel> ChatPriceFilters
        {
            get => _chatPriceFilters;
            set
            {
                _chatPriceFilters = value;
                RaisePropertyChanged();
            }
        }

        public ChatPriceGridFiltersViewModel SelectedChatPriceFilterViewModel
        {
            get => _selectedChatPriceFilterViewModel;
            set
            {
                _selectedChatPriceFilterViewModel = value;
                RaisePropertyChanged();
            }
        }
    }
}
