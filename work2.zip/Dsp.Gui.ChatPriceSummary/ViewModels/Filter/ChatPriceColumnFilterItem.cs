﻿using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels.Filter
{
    public class ChatPriceColumnFilterItem : BindableBase, ISelectableFilterItem
    {
        private bool _isSelected;

        public ChatPriceColumnFilterItem(ColumnType columnType, string columnName, bool isSelected)
        {
            ColumnType = columnType;
            ColumnName = columnName;
            IsSelected = isSelected;
            OriginalIsSelected = isSelected;
        }

        public ColumnType ColumnType { get; }
        public string ColumnName { get; }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                RaisePropertyChanged();
            }
        }

        public bool OriginalIsSelected { get; set; }

        public int CompareTo(object obj)
        {
            if (obj is not ChatPriceColumnFilterItem item)
            {
                return 1;
            }

            return ColumnType.CompareTo(item.ColumnType);
        }
    }
}
