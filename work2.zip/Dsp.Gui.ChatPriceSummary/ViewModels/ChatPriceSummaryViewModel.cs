﻿using System.Collections.ObjectModel;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.ViewModels
{
    public class ChatPriceSummaryViewModel : BindableBase
    {
        private ObservableCollection<ChatPriceMarketsViewModel> _chatPriceMarkets;
        private ChatPriceMarketsViewModel _selectedChatPriceMarkets;

        public DelegateCommand AddChatPriceMarketsCommand { get; set; }
        public MessageDialogPromptViewModel RemoveMarketsDialogPrompt { get; set; }

        public ObservableCollection<ChatPriceMarketsViewModel> ChatPriceMarkets
        {
            get => _chatPriceMarkets;
            set
            {
                _chatPriceMarkets = value;
                RaisePropertyChanged();
            }
        }

        public ChatPriceMarketsViewModel SelectedChatPriceMarkets
        {
            get => _selectedChatPriceMarkets;
            set
            {
                _selectedChatPriceMarkets = value;
                RaisePropertyChanged();
            }
        }
    }
}
