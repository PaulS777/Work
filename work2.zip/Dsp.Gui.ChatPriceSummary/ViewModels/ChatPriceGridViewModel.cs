﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.ChatPriceSummary.ViewModels.Filter;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.ViewModels
{
    public sealed class ChatPriceGridViewModel : BindableBase, IDisposable
    {
        private readonly IDisposable _controller;
        private IList<BandInfo> _bandInfos;
        private string _priceGridName;
        private ObservableCollection<ChatPriceRowViewModel> _chatPriceRows;
        private bool _isBusy;
        private string _busyText;
        private bool _chatPriceSummaryReady;
        private bool _canRemoveGrid;
        private bool _disposed;

        public ChatPriceGridViewModel(IDisposable controller)
        {
            _controller = controller;
        }

        [ExcludeFromCodeCoverage]
        ~ChatPriceGridViewModel()
        {
            Dispose(false);
        }

        public DelegateCommand RemoveChatPriceGridCommand { get; set; }
        public int MarketsId { get; set; }
        public int PriceGridId { get; set; }
        public ChatPriceGridFiltersViewModel ChatPriceGridFilters { get; set; }
        public ChatPriceCurveFilterViewModel ChatPriceCurveFilter => ChatPriceGridFilters?.CurveFilter;
        public ChatPriceColumnFilterViewModel ChatPriceColumnFilter => ChatPriceGridFilters?.ColumnFilter;

        public string PriceGridName
        {
            get => _priceGridName;
            set
            {
                _priceGridName = value;
                RaisePropertyChanged();
            }
        }

        public bool PriceGridLoaded { get; set; }

        public IList<BandInfo> BandInfos
        {
            get => _bandInfos;
            set
            {
                _bandInfos = value;
                RaisePropertyChanged();
            }
        }

        public ObservableCollection<ChatPriceRowViewModel> ChatPriceRows
        {
            get => _chatPriceRows;
            set
            {
                _chatPriceRows = value;
                RaisePropertyChanged();
            }
        }

        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                _isBusy = value;
                RaisePropertyChanged();
            }
        }

        public string BusyText
        {
            get => _busyText;
            set
            {
                _busyText = value;
                RaisePropertyChanged();
            }
        }

        public bool ChatPriceSummaryReady
        {
            get => _chatPriceSummaryReady;
            set
            {
                _chatPriceSummaryReady = value;
                RaisePropertyChanged();
            }
        }

        public bool CanRemoveGrid
        {
            get => _canRemoveGrid;
            set
            {
                if (_canRemoveGrid == value)
                {
                    return;
                }

                _canRemoveGrid = value;
                RaisePropertyChanged();
            }
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _controller.Dispose();
            }

            _disposed = true;
        }
    }
}
