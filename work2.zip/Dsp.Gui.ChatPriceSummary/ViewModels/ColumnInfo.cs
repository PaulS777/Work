﻿using Prism.Mvvm;

namespace Dsp.Gui.ChatPriceSummary.ViewModels
{
    public enum ColumnType
    {
        BidBroker,
        BidTime,
        BidPrice,
        AskPrice,
        AskTime,
        AskBroker
    }

    public class ColumnInfo : BindableBase
    {
        private bool _isVisible;
        private double _width;
        private double _adjustedWidth;

        public ColumnInfo(ColumnType columnType,
                          int bandId,
                          string header,
                          string bindingPath,
                          bool alternateBand,
                          double width = 0)
        {
            ColumnType = columnType;
            BandId = bandId;
            Header = header;
            BindingPath = bindingPath;
            IsAlternateBand = alternateBand;
            Width = width;
        }

        public ColumnType ColumnType { get; set; }
        public int BandId { get; }
        public string Header { get; set; }
        public string BindingPath { get; set; }
        public bool IsAlternateBand { get; set; }

        public bool IsVisible
        {
            get => _isVisible;
            set
            {
                _isVisible = value;
                RaisePropertyChanged();
            }
        }

        public double Width
        {
            get => _width;
            set
            {
                _width = value;
                RaisePropertyChanged();
            }
        }

        public double AdjustedWidth
        {
            get => _adjustedWidth;
            set
            {
                _adjustedWidth = value;
                RaisePropertyChanged();
            }
        }
    }
}
