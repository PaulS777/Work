﻿using System.Collections.Generic;
using Prism.Mvvm;
using Prism.Commands;

namespace Dsp.Gui.ChatPriceSummary.ViewModels
{
    public class MessageDialogPromptViewModel : BindableBase
    {
        private bool _showDialog;
        private string _header;
        private IList<string> _dialogMessages;

        private DelegateCommand _dialogYesCommand;

        public DelegateCommand DialogYesCommand
        {
            get => _dialogYesCommand;
            set
            {
                _dialogYesCommand = value;
                RaisePropertyChanged();
            }
        }

        public DelegateCommand DialogNoCommand { get; set; }

        public IList<string> DialogMessages
        {
            get => _dialogMessages;
            set
            {
                _dialogMessages = value;
                RaisePropertyChanged();
            }
        }

        public bool ShowDialog
        {
            get => _showDialog;
            set
            {
                _showDialog = value;
                RaisePropertyChanged();
            }
        }

        public string Header
        {
            get => _header;
            set
            {
                _header = value;
                RaisePropertyChanged();
            }
        }
    }
}
