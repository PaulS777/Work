﻿
namespace Dsp.Gui.Common
{
    public interface IGroupingItem
    {
        bool IsGroupingItem { get; }
    }
}
