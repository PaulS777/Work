﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Dsp.Gui.Common
{
    public class DictionaryEqualityComparer<TKey, TValue> : IEqualityComparer<IDictionary<TKey, TValue>>
    {
        private readonly IEqualityComparer<TKey> _keyComparer;
        private readonly IEqualityComparer<TValue> _valueComparer;

        public DictionaryEqualityComparer() : this(null, null)
        {
        }

        public DictionaryEqualityComparer(IEqualityComparer<TKey> keyComparer, IEqualityComparer<TValue> valueComparer)
        {
            _keyComparer = keyComparer ?? EqualityComparer<TKey>.Default;
            _valueComparer = valueComparer ?? EqualityComparer<TValue>.Default;
        }

        public bool Equals(IDictionary<TKey, TValue> x, IDictionary<TKey, TValue> y)
        {
            if (x == null || y == null)
            {
                return false;
            }

            if (x.Count != y.Count)
            {
                return false;
            }

            return x.Keys.Intersect(y.Keys, _keyComparer).Count() == x.Count 
                && x.Keys.All(key => ValueEquals(x[key], y[key]));
        }

        public int GetHashCode(IDictionary<TKey, TValue> obj)
        {
             ArgumentNullException.ThrowIfNull(obj);

            long hashCode = obj.Count;

            foreach (var key in obj.Keys)
            {
                if (Equals(key, default(TKey)))
                {
                    continue;
                }

                hashCode += key.GetHashCode() + (obj[key]?.GetHashCode() ?? 0);
                hashCode %= int.MaxValue; //ensure we don't go outside the bounds of MinValue-MaxValue
            }
            return (int)hashCode; //safe conversion thanks to the above %
        }

        private bool ValueEquals(TValue x, TValue y)
        {
            return _valueComparer.Equals(x, y);
        }
    }
}
