﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Dsp.Gui.Common
{
    public class CollectionEqualityComparer<T> : IEqualityComparer<IEnumerable<T>>
    {
        public bool Equals(IEnumerable<T> x, IEnumerable<T> y)
        {
            if (ReferenceEquals(x, y))
            {
                return true;
            }

            if (x is null)
            {
                return false;
            }

            if (y is null)
            {
                return false;
            }

			return x.SequenceEqual(y);
        }

        public int GetHashCode(IEnumerable<T> list)
        {
            ArgumentNullException.ThrowIfNull(list);

            unchecked
            {
                var hash = 19;

                foreach (var item in list)
                {
                    hash = hash * 31 + item.GetHashCode();
                }
                return hash;
            }
        }
    }
}
