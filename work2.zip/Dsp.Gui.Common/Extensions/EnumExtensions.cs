﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ComponentModel;

namespace Dsp.Gui.Common.Extensions
{
    public static class EnumExtensions
    {
        public static bool In(this Enum value, params Enum[] list)
        {
            return Array.Exists(list ,i => i.Equals(value));
        }

        public static string ToEnumString<T>(this T instance)
        where T : struct
        {
            var enumString = instance.ToString();

            var field = typeof(T).GetField(enumString);

            if (field != null) // instance can be a number that was cast to T, instead of a named value, or could be a combination of flags instead of a single value
            {
                var attr = (EnumMemberAttribute)field.GetCustomAttributes(typeof(EnumMemberAttribute), false).SingleOrDefault();

                if (attr != null) // if there's no EnumMember attr, use the default value
                {
                    enumString = attr.Value;
                }
            }

            return enumString;
        }

        public static string ToEnumDescription<T>(this T instance)
            where T : struct
        {
            var enumString = instance.ToString();

            var field = typeof(T).GetField(enumString);

            if (field != null) 
            {
                var attr = (DescriptionAttribute)field.GetCustomAttributes(typeof(DescriptionAttribute), false).SingleOrDefault();

                if (attr != null)
                {
                    enumString = attr.Description;
                }
            }

            return enumString;
        }
    }
}
