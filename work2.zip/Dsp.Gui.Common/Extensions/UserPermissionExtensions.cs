﻿using System.Diagnostics;
using System.Linq;
using Dsp.DataContracts;

namespace Dsp.Gui.Common.Extensions
{
	public static class UserPermissionExtensions
	{
		public static bool HasPermission(this User user, PermissionCategory permissionCategory)
		{
			Debug.Assert(user != null, nameof(user) + " != null");

			return user.AuthorisationUserPermissions.Any(a => a.CategoryName == permissionCategory.ToString() && a.Value);
		}
	}
}
