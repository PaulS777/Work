﻿using System;
using System.Reactive.Disposables;

namespace Dsp.Gui.Common.Extensions
{
    public static class CompositeDisposableExtensions
    {
        public static T AddTo<T>(this T disposable, CompositeDisposable compositeDisposable)
            where T : IDisposable
        {
            compositeDisposable.Add(disposable);
            return disposable;
        }
    }
}
