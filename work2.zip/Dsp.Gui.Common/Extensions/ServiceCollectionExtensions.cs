﻿// ***********************************************************************************************************************
// ServiceCollectionExtensions.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------

using System;
using System.Diagnostics.CodeAnalysis;
using Dsp.Gui.Common.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Common.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class ServiceCollectionExtensions
    {
        public static void AddFactory<TService, TImpl>(this IServiceCollection services)
            where TService : class
            where TImpl : class, TService
        {
            services.AddTransient<TService, TImpl>();
            services.AddSingleton<Func<TService>>(x => () => x.GetService<TService>()!);
            services.AddSingleton<IServiceFactory<TService>, ServiceFactory<TService>>();
        }
    }
}
