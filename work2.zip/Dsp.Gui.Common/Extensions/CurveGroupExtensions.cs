﻿using System;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common.Extensions
{
	public static class CurveGroupExtensions
    {
        public static bool IsCrude(this CurveGroup curveGroup)
        {
            return string.Equals(curveGroup.Name, CurveGroupNames.Crude, StringComparison.InvariantCulture);
        }

        public static bool IsFx(this CurveGroup curveGroup)
        {
            return string.Equals(curveGroup.Name, CurveGroupNames.Fx, StringComparison.InvariantCulture);
        }
	}
}
