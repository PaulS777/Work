﻿using System;
using Dsp.DataContracts;

namespace Dsp.Gui.Common.Extensions
{
    public static class TenorExtensions
    {
        private const int YearMultiplier = 10000;
        private const int QuarterMultiplier = 100;

        public static int GetTenorValue(this ITenor tenor)
        {
            switch (tenor.TenorType())
            {
                case TenorType.Month:
                    return ((MonthlyTenor)tenor).GetTenorValue();
                case TenorType.Quarter:
                    return ((QuarterlyTenor)tenor).GetTenorValue();
                case TenorType.Year:
                    return ((AnnualTenor)tenor).GetTenorValue();
                default:
                    throw new ArgumentOutOfRangeException(nameof(tenor));
            }
        }
        public static int GetTenorValue(this AnnualTenor tenor) => tenor.Year * YearMultiplier;
        public static int GetTenorValue(this QuarterlyTenor tenor) => (tenor.Year * YearMultiplier) + (tenor.Quarter * QuarterMultiplier);
        public static int GetTenorValue(this MonthlyTenor tenor) => (tenor.Year * YearMultiplier) + (tenor.GetQuarter() * QuarterMultiplier) + tenor.Month;
        public static int GetQuarter(this MonthlyTenor tenor) => ((tenor.Month - 1) / 3) + 1;
    }
}
