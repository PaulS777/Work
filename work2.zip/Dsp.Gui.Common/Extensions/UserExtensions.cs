﻿using Dsp.DataContracts;
using System.Linq;

namespace Dsp.Gui.Common.Extensions
{
	public static class UserExtensions
    {
        public static bool IsEomRoll(this User user) => user.HasPrivilege(PermissionCategory.EomRoll);
        public static bool IsBetaUser(this User user) => user.HasPrivilege(PermissionCategory.BetaUser);
        public static bool IsCurveAdmin(this User user) => user.HasPrivilege(PermissionCategory.CurveAdmin);
		public static bool IsCurveAdminApprover(this User user) => user.HasPrivilege(PermissionCategory.CurveAdminApprover);
        public static bool IsFxPublisher(this User user) => user.FxCurvePermissions.Any(p => p.CanUpdate);
        public static bool IsCrudeReader(this User user) => user.CurveGroupPermissions.Any(p => p.CurveGroup.IsCrude() && p.CanRead);
	}
}
