﻿using System;
using System.Diagnostics.CodeAnalysis;
using Exception = System.Exception;

namespace Dsp.Gui.Common.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class RxSynchExtensions
    {
        public static IDisposable SubscribeSynch<T>(this IObservable<T> source,
                                                    object synch,
                                                    Action<T> onNext)
        {
            return source.Subscribe(r =>
            {
                lock (synch)
                {
                    onNext(r);
                }
            });
        }

        public static IDisposable SubscribeSynch<T>(this IObservable<T> source,
                                                    object synch,
                                                    Action<T> onNext,
                                                    Action<Exception> onError)
        {
            return source.Subscribe(r =>
            {
                lock (synch)
                {
                    onNext(r);
                }
            },
            onError);
        }

        public static IDisposable SubscribeWithEx<T>(this IObservable<T> source,
                                                     Action<T> onNext,
                                                     Action<Exception> onError)
        {
            return source.Subscribe(r =>
                                    {
                                        try
                                        {
                                            onNext(r);
                                        }
                                        catch (Exception ex)
                                        {
                                            onError(ex);
                                        }
                                    },
                                    onError);
        }

        public static IDisposable SubscribeWithEx<T>(this IObservable<T> source,
                                                     Action<T> onNext,
                                                     Action<Exception> onError,
                                                     Action onCompleted)
        {
            return source.Subscribe(r =>
            {
                try
                {
                    onNext(r);
                }
                catch (Exception ex)
                {
                    onError(ex);
                }
            }, onError, onCompleted);
        }
    }
}
