﻿using System;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Linq.Expressions;
using System.Reactive.Linq;
using System.Reflection;

namespace Dsp.Gui.Common.Extensions
{
    [ExcludeFromCodeCoverage]
    public static class NotifyPropertyChangesExtensions
    {
        private const string CannotBeNull = "Cannot be null";
        private const string MustBeMemberExpression = "Must be MemberExpression";

        public static IObservable<TSource> ObservePropertyChanged<TSource>(this TSource source,
                                                                           string propertyName)
            where TSource : class, INotifyPropertyChanged
        {
            return Observable.FromEventPattern<PropertyChangedEventHandler, PropertyChangedEventArgs>
                              (h => source.PropertyChanged += h, h => source.PropertyChanged -= h)
                             .Where(e => string.Equals(e.EventArgs.PropertyName, propertyName, StringComparison.InvariantCulture))
                             .Select(e => (TSource)e.Sender);
        }

		public static IObservable<TSource> ObservePropertyChanged<TSource, TProp>(this TSource source,
																				  string propertyName)
			where TSource : class, INotifyPropertyChanged
		{
			if (source == null)
			{
				throw new ArgumentException(CannotBeNull, nameof(source));
			}

			return Observable.FromEventPattern<PropertyChangedEventHandler, PropertyChangedEventArgs>
							  (h => source.PropertyChanged += h, h => source.PropertyChanged -= h)
							 .Where(e => string.Equals(e.EventArgs.PropertyName, propertyName, StringComparison.InvariantCulture))
							 .Select(e => (TSource)e.Sender);
		}

		public static IObservable<TSource> ObservePropertyChanged<TSource, TProp>(this TSource source,
                                                                                  Expression<Func<TSource, TProp>> propertySelector)
            where TSource : class, INotifyPropertyChanged
        {
            if (source == null)
            {
                throw new ArgumentException(CannotBeNull, nameof(source));
            }

            if (propertySelector == null)
            {
                throw new ArgumentException(CannotBeNull, nameof(propertySelector));
            }

            var propertyName = GetPropertyName(propertySelector);

            return Observable.FromEventPattern<PropertyChangedEventHandler, PropertyChangedEventArgs>
                (h => source.PropertyChanged += h,h => source.PropertyChanged -= h)
                .Where(e => string.Equals(e.EventArgs.PropertyName, propertyName, StringComparison.InvariantCulture))
                .Select(e => (TSource) e.Sender);
        }

        public static IObservable<TSource> ObservePropertiesChanged<TSource, TProp>(this TSource source, 
            params Expression<Func<TSource, TProp>>[] propertySelectors)
            where TSource :class, INotifyPropertyChanged
        {
            if (source == null)
            {
                throw new ArgumentException(CannotBeNull, nameof(source));
            }

            if (propertySelectors == null)
            {
                throw new ArgumentException(CannotBeNull, nameof(propertySelectors));
            }

            return propertySelectors.Select(source.ObservePropertyChanged).Merge();
        }

        private static string GetPropertyName(LambdaExpression propertySelector)
        {
            if (propertySelector.Body is not MemberExpression body)
            {
                throw new ArgumentException(MustBeMemberExpression, nameof(propertySelector));
            }

            var member = body.Member as PropertyInfo;

            return member == null ? throw new ArgumentException(CannotBeNull, nameof(propertySelector)) : member.Name;
        }
    }
}
