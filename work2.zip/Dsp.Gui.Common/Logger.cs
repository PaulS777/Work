﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using Dsp.ServiceContracts;
using log4net;

namespace Dsp.Gui.Common
{
    [ExcludeFromCodeCoverage]
    public class Logger : ILogger
    {
        private const string CorrelationIdContext = "correlation_id";
        private readonly ILog _logger;

        public Logger(ILog logger)
        {
            _logger = logger;
            IsDebugEnabled = logger.IsDebugEnabled;
        }

        public bool IsDebugEnabled { get; }

        public void Debug(string message)
        {
            if (!IsDebugEnabled)
            {
                return;
            }
            _logger.Debug(message);
        }

        public void Debug(string format, params object[] args)
        {
            if (!IsDebugEnabled)
            {
                return;
            }
            _logger.DebugFormat(format, args, CultureInfo.InvariantCulture);
        }

        public void Info(string message)
        {
            _logger.Info(message);
        }

        public void Info(string format, params object[] args)
        {
            _logger.InfoFormat(format, args, CultureInfo.InvariantCulture);
        }

        public void Warn(string message)
        {
            _logger.Warn(message);
        }

        public void Warn(string format, params object[] args)
        {
            _logger.WarnFormat(format, args, CultureInfo.InvariantCulture);
        }

        public void Error(string message)
        {
            _logger.Error(message);
        }

        public void Error(string message, Exception exception)
        {
            _logger.Error(message, exception);
        }

        public void Error(string format, params object[] args)
        {
            _logger.ErrorFormat(format, args, CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Sets the correlation id to be passed around to other services and applications, or creates a new one.
        /// </summary>
        /// <param name="correlationId">The id to be used.  Method call will generate a new one if omitted or null.</param>
        public string SetCorrelationId(string correlationId = null)
        {
            return SetCorrelationIdS(correlationId);
        }

        public static string SetCorrelationIdS(string correlationId = null)
        {
            if (string.IsNullOrWhiteSpace(correlationId))
            {
                correlationId = Guid.NewGuid().ToString("N");
            }
            LogicalThreadContext.Properties[CorrelationIdContext] = correlationId;
            return correlationId;
        }

        /// <summary>
        /// Retrieves any correlation id to be used in messaging/logging
        /// </summary>
        /// <returns></returns>
        public string GetCorrelationId()
        {
            var id = LogicalThreadContext.Properties[CorrelationIdContext] ?? string.Empty;
            return id.ToString();
        }

        public void ErrorFormat(Exception exception, string format, params object[] args)
        {
            _logger.ErrorFormat(string.Format(format, args), exception, CultureInfo.InvariantCulture);
        }
    }
}
