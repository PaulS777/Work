﻿using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts;
using Prism.Mvvm;

namespace Dsp.Gui.Common
{
    [ExcludeFromCodeCoverage]
    public abstract class EntityItem<T> : BindableBase
        where T : IIdentifiable
    {
        protected readonly T _model;

        protected EntityItem(T model)
        {
            _model = model;
        }

        public int Id => _model.Id;

        public abstract string Name { get; }

        public T Model() => _model;

    }
}
