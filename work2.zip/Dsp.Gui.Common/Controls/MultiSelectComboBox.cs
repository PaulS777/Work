﻿using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace Dsp.Gui.Common.Controls
{
    [ExcludeFromCodeCoverage]
    public class MultiSelectComboBox : Control
    {
        static MultiSelectComboBox()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(MultiSelectComboBox), new FrameworkPropertyMetadata(typeof(MultiSelectComboBox)));
        }

        public static readonly DependencyProperty TextProperty = DependencyProperty.Register(
            nameof(Text),
            typeof(string),
            typeof(MultiSelectComboBox),
            new UIPropertyMetadata(null));

        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        public static readonly DependencyProperty AllItemsSelectedProperty = DependencyProperty.Register(
            nameof(AllItemsSelected),
            typeof(bool?),
            typeof(MultiSelectComboBox),
            new UIPropertyMetadata(false));


        public bool? AllItemsSelected
        {
            get => (bool?)GetValue(AllItemsSelectedProperty);
            set => SetValue(AllItemsSelectedProperty, value);
        }

        public static readonly DependencyProperty ItemTemplateProperty = DependencyProperty.Register(
            nameof(ItemTemplate),
            typeof(DataTemplate),
            typeof(MultiSelectComboBox),
            new UIPropertyMetadata(null));

        public DataTemplate ItemTemplate
        {
            get => (DataTemplate)GetValue(ItemTemplateProperty);
            set => SetValue(ItemTemplateProperty, value);
        }

        public static readonly DependencyProperty ItemsSourceProperty = DependencyProperty.Register(
            nameof(ItemsSource),
            typeof(IEnumerable),
            typeof(MultiSelectComboBox),
            new UIPropertyMetadata(null));

        public IEnumerable ItemsSource
        {
            get => (IEnumerable)GetValue(ItemsSourceProperty);
            set => SetValue(ItemsSourceProperty, value);
        }

        public static readonly DependencyProperty ItemTemplateSelectorProperty = DependencyProperty.Register(
            nameof(ItemTemplateSelector),
            typeof(DataTemplateSelector),
            typeof(MultiSelectComboBox),
            new UIPropertyMetadata(null));

        public DataTemplateSelector ItemTemplateSelector
        {
            get => (DataTemplateSelector)GetValue(ItemTemplateSelectorProperty);
            set => SetValue(ItemTemplateSelectorProperty, value);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            var button = (Button)GetTemplateChild("PART_Button");
            var popup = (Popup)GetTemplateChild("PART_Popup");

            if (button == null || popup == null)
            {
                return;
            }

            button.Click += (_, _) => popup.IsOpen = true;
        }

    }
}
