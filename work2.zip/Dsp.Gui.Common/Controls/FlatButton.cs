﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Dsp.Gui.Common.Controls
{
    [ExcludeFromCodeCoverage]
    public class FlatButton : Button
    {
        static FlatButton()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(FlatButton), new FrameworkPropertyMetadata(typeof(FlatButton)));
        }

        public static readonly DependencyProperty PressedBackgroundProperty = DependencyProperty.Register(
            "PressedBackground",
            typeof(SolidColorBrush),
            typeof(FlatButton),
            new UIPropertyMetadata(null));

        public SolidColorBrush PressedBackground
        {
            get => (SolidColorBrush)GetValue(PressedBackgroundProperty);
            set => SetValue(PressedBackgroundProperty, value);
        }

        public static readonly DependencyProperty MouseOverBorderThicknessProperty = DependencyProperty.Register("MouseOverBorderThickness",
            typeof(Thickness),
            typeof(FlatButton),
            new UIPropertyMetadata(new Thickness()));

        public Thickness MouseOverBorderThickness
        {
            get => (Thickness)GetValue(MouseOverBorderThicknessProperty);
            set => SetValue(MouseOverBorderThicknessProperty, value);
        }
    }
}
