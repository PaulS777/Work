﻿using System.Diagnostics.CodeAnalysis;
using System.Windows.Input;
using DevExpress.Xpf.Editors;

namespace Dsp.Gui.Common.Controls
{
    [ExcludeFromCodeCoverage]
    public class ComboBoxEditEx : ComboBoxEdit
    {
        bool _lockOpening;

        public ComboBoxEditEx()
        {
            PopupOpening += ComboBoxEditEx_PopupOpening;
        }

        private void ComboBoxEditEx_PopupOpening(object sender, OpenPopupEventArgs e)
        {
            e.Cancel = _lockOpening;
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            _lockOpening = true;
            base.OnMouseDown(e);
            _lockOpening = false;
        }
    }
}
