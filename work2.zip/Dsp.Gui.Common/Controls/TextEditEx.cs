﻿using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Windows;
using DevExpress.Xpf.Editors;

namespace Dsp.Gui.Common.Controls
{
    [ExcludeFromCodeCoverage]
    public class TextEditEx : TextEdit
    {
        public static readonly DependencyProperty SelectAllOnEditorActivatedProperty =
            DependencyProperty.Register(
                                        nameof(SelectAllOnEditorActivated),
                                        typeof(bool),
                                        typeof(TextEditEx),
                                        new UIPropertyMetadata(false, OnSelectAllOnEditorActivatedChanged));

        public bool SelectAllOnEditorActivated
        {
            get => (bool)GetValue(SelectAllOnEditorActivatedProperty);
            set => SetValue(SelectAllOnEditorActivatedProperty, value);
        }

        private static void OnSelectAllOnEditorActivatedChanged(DependencyObject dependencyObject,
                                                                DependencyPropertyChangedEventArgs args)
        {
            if (dependencyObject is not TextEditEx textEdit)
            {
                return;
            }

            if (args.NewValue is not bool selectAllOnEditorActivated)
            {
                return;
            }

            if (selectAllOnEditorActivated)
            { 
                textEdit.EditorActivated += TextEditOnEditorActivated;
            }
            else
            {
                textEdit.EditorActivated -= TextEditOnEditorActivated;
            }
        }

        private static void TextEditOnEditorActivated(object sender, RoutedEventArgs e)
        {
            ((TextEditEx)sender).SelectAll();
        }

        public static readonly DependencyProperty PrecisionDplsProperty =
            DependencyProperty.Register(
                nameof(PrecisionDpls),
                typeof(int),
                typeof(TextEditEx),
                new UIPropertyMetadata(0, OnPrecisionDplsChanged));

        public int PrecisionDpls
        {
            get => (int)GetValue(PrecisionDplsProperty);
            set => SetValue(PrecisionDplsProperty, value);
        }

        private static void OnPrecisionDplsChanged(DependencyObject dependencyObject,
                                                   DependencyPropertyChangedEventArgs args)
        {
            if (dependencyObject is not TextEditEx textEdit)
            {
                return;
            }

            if (args.NewValue is not int precision)
            {
                return;
            }

            textEdit.Mask = string.Format($"n{precision}", CultureInfo.InvariantCulture);
        }

        public static readonly DependencyProperty SpinEnabledProperty =
            DependencyProperty.Register(
                nameof(SpinEnabled),
                typeof(bool),
                typeof(TextEditEx),
                new FrameworkPropertyMetadata(true, OnSpinEnabledChanged));

        public bool SpinEnabled
        {
            get => (bool)GetValue(SpinEnabledProperty);
            set => SetValue(SpinEnabledProperty, value);
        }

        private static void OnSpinEnabledChanged(DependencyObject dependencyObject,
                                                 DependencyPropertyChangedEventArgs args)
        {
            if (dependencyObject is not TextEditEx textEdit)
            {
                return;
            }

            if (!(args.NewValue is bool enabled))
            {
                return;
            }

            textEdit.Spin += (_, e) => { e.Handled = !enabled; };
        }
    }
}
