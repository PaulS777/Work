﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls.Primitives;

namespace Dsp.Gui.Common.Controls
{
    [ExcludeFromCodeCoverage]
    public class ExpanderButton : ToggleButton
    {
        static ExpanderButton()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ExpanderButton), new FrameworkPropertyMetadata(typeof(ExpanderButton)));
        }

        public static readonly DependencyProperty IsHighlightedProperty = DependencyProperty.Register(
            "IsHighlighted",
            typeof(bool),
            typeof(ExpanderButton),
            new UIPropertyMetadata(false));

        public bool IsHighlighted
        {
            get => (bool)GetValue(IsHighlightedProperty);
            set => SetValue(IsHighlightedProperty, value);
        }
    }
}
