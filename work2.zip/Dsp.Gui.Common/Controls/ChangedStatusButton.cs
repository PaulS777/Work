﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;

namespace Dsp.Gui.Common.Controls
{
    [ExcludeFromCodeCoverage]
    public class ChangedStatusButton  :  Button
    {
        public static readonly DependencyProperty IsValidProperty = DependencyProperty.Register("IsValid",
            typeof(bool),
            typeof(ChangedStatusButton),
            new UIPropertyMetadata(true));

        public bool IsValid
        {
            get => (bool)GetValue(IsValidProperty);
            set => SetValue(IsValidProperty, value);
        }
    }
}
