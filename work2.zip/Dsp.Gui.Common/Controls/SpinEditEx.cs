﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using DevExpress.Xpf.Editors;
using Prism.Commands;

namespace Dsp.Gui.Common.Controls
{
    [ExcludeFromCodeCoverage]
    public class SpinEditEx : SpinEdit
    {
        public SpinEditEx()
        {
            MouseDoubleClick += (_, _) => IsEditTextSelected = true;
            LostFocus += (_, _) => IsEditTextSelected = false;
            GotKeyboardFocus += (_, _) => SelectedSpinEditEx = this;
            LostKeyboardFocus += (_, _) => SelectedSpinEditEx = null;
            
            SetEditable(false);
        }

        public static readonly DependencyProperty SelectedSpinEditExProperty = DependencyProperty.Register(nameof(SelectedSpinEditEx),
                                                                                                           typeof(SpinEditEx),
                                                                                                           typeof(SpinEditEx),
                                                                                                           null);
        public SpinEditEx SelectedSpinEditEx
        {
            get => (SpinEditEx)GetValue(SelectedSpinEditExProperty);
            set => SetValue(SelectedSpinEditExProperty, value);
        }

        public static readonly DependencyProperty SpinCommandProperty = DependencyProperty.Register(nameof(SpinCommand),
                                                                                                    typeof(DelegateCommand),
                                                                                                    typeof(SpinEditEx),
                                                                                                    new UIPropertyMetadata(null, OnSpinCommandChanged));

        public DelegateCommand SpinCommand
        {
            get => (DelegateCommand)GetValue(SpinCommandProperty);
            set => SetValue(SpinCommandProperty, value);
        }

        private static void OnSpinCommandChanged(DependencyObject dependencyObject,
                                                 DependencyPropertyChangedEventArgs args)
        {
            if (dependencyObject is not SpinEditEx spinEditEx)
            {
                return;
            }

            var command = spinEditEx.SpinCommand;

            if (command == null)
            {
                return;
            }

            spinEditEx.Spin += (_, _) => command.Execute();
        }

        public static readonly DependencyProperty IsEditTextSelectedProperty = DependencyProperty.Register(nameof(IsEditTextSelected),
                                                                                                           typeof(bool),
                                                                                                           typeof(SpinEditEx),
                                                                                                           new UIPropertyMetadata(false));

        public bool IsEditTextSelected
        {
            get => (bool)GetValue(IsEditTextSelectedProperty);
            set => SetValue(IsEditTextSelectedProperty, value);
        }

        public static readonly DependencyProperty IsEditableProperty = DependencyProperty.Register(nameof(IsEditable),
                                                                                                   typeof(bool),
                                                                                                   typeof(SpinEditEx),
                                                                                                   new UIPropertyMetadata(false, OnIsEditableChanged));

        public bool IsEditable
        {
            get => (bool)GetValue(IsEditableProperty);
            set => SetValue(IsEditableProperty, value);
        }

        private static void OnIsEditableChanged(DependencyObject dependencyObject,
                                                DependencyPropertyChangedEventArgs args)
        {
            if (dependencyObject is not SpinEditEx spinEditEx)
            {
                return;
            }

            if (args.NewValue is not bool value)
            {
                return;
            }

            spinEditEx.SetEditable(value);
        }

        public void SetEditable(bool isEditable)
        {
            ShowEditorButtons = isEditable;
            IsTextEditable = isEditable;
        }

        public static readonly DependencyProperty PrecisionDplsProperty = DependencyProperty.Register(nameof(PrecisionDpls),
                                                                                                      typeof(int?),
                                                                                                      typeof(SpinEditEx),
                                                                                                      new UIPropertyMetadata(0, OnPrecisionDplsChanged));

        public int PrecisionDpls
        {
            get => (int)GetValue(PrecisionDplsProperty);
            set => SetValue(PrecisionDplsProperty, value);
        }

        private static void OnPrecisionDplsChanged(DependencyObject dependencyObject,
                                                   DependencyPropertyChangedEventArgs args)
        {
            if (dependencyObject is not SpinEditEx spinEditEx)
            {
                return;
            }

            if (args.NewValue is not int precision)
            {
                return;
            }

            spinEditEx.Increment = Convert.ToDecimal(Math.Pow(10, precision * -1));
            spinEditEx.Mask = "#0.".PadRight(precision + 3, '0');
        }

        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if (!IsEditable)
            {
                if (e.Key == Key.Up)
                {
                    e.Handled = true;
                }
                else if (e.Key == Key.Down)
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (e.Key == Key.Left)
                {
                    Dispatcher?.BeginInvoke(SelectAll, DispatcherPriority.Background);
                }
                else if (e.Key == Key.Right)
                {
                    Dispatcher?.BeginInvoke(() => { SelectionLength = PrecisionDpls; }, DispatcherPriority.Background);
                }
            }

            base.OnPreviewKeyDown(e);
        }
    }
}
