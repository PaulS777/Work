﻿using Dsp.DataContracts;

namespace Dsp.Gui.Common
{
    public interface IDspApplicationRunService
    {
        WebSocketClientType WebSocketClientType { get; }
        string MutexInstanceName { get; }
        string SettingsPath { get; }
    }
}
