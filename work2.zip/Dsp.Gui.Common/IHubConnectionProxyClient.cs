﻿using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Configuration;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.Gui.Common
{
    public interface IHubConnectionProxyClient
    {
        void OnPriceCurveSnapshotNotification(IList<PriceCurveSetting> priceCurveSettings, 
                                              IList<PriceCurvePremium> priceCurvePremiums, 
                                              IList<PublisherTenorPremium> publisherTenorPremiums);
        void OnPriceCurveSettingNotification(PriceCurveSetting priceCurveSetting);
        void OnPublisherTenorPremiumsSnapshot(IList<PublisherTenorPremium> publisherTenorPremiums);
        void OnPublisherTenorPremiumNotification(PublisherTenorPremium publisherTenorPremium);
        void OnUsersSnapshot(IList<User> users);
        void OnUsersNotification(IList<User> users);
        void OnPriceCurveSettingsUpdates(IList<PriceCurveSetting> priceCurveSettings);
        void OnPriceCurvePremiumsUpdates(IList<PriceCurvePremium> priceCurvePremiums);
        void OnPublisherTenorPremiumUpdates(IList<PublisherTenorPremium> publisherTenorPremiums);
        void OnPriceCurvePremiumNotification(PriceCurvePremium priceCurvePremium);
        void OnPriceCurveDefinitionsSnapshot(IList<PriceCurveDefinition> priceCurveDefinitions);
        void OnPriceCurveDefinitionsNotification(IList<PriceCurveDefinition> priceCurveDefinitions);
        void OnDerivedCurveDefinitionsSnapshot(IList<DerivedCurveDefinition> derivedCurveDefinitions);
        void OnDerivedCurveDefinitionsNotification(IList<DerivedCurveDefinition> derivedCurveDefinitions);
        void OnFxCurveDefinitionSnapshot(IList<FxCurveDefinition> fxCurveDefinitions);
        void OnFxCurveDefinitionNotification(IList<FxCurveDefinition> fxCurveDefinitions);
		void OnFxCurveSettingsSnapshot(FxCurveSetting fxCurveSetting);
        void OnFxCurveSettingsSnapshot(IList<FxCurveSetting> fxCurveSettings);
        void OnFxCurvePipsBufferSnapshot(IList<FxCurvePipsBuffer> fxCurvePipsBuffers);
        void OnFxCurvePipsBufferSnapshot(FxCurvePipsBuffer fxCurvePipsBuffer);
        void OnChatUsersSnapshot(IList<ChatUser> chatUsers);
        void OnChatUsersNotification(IList<ChatUser> chatUsers);
        void OnChatUsersNotification(ChatUser chatUser);
        void OnChatMarketsSnapshot(IList<ChatMarket> chatMarkets);
        void OnChatMarketsNotification(IList<ChatMarket> chatMarkets);
        void OnChatMarketsNotification(ChatMarket chatMarket);
        void OnChatMessagesSnapshot(IList<ChatMessageHistory> chatMessages);
        void OnChatMessagesNotification(IList<ChatMessageHistory> chatMessages);
        void OnChatIceMapSnapshot(IList<ChatIceMap> chatIceMaps);
        void OnChatIceMapNotification(IList<ChatIceMap> chatIceMaps);
        void OnChatVariableShortcutSnapshot(IList<ChatVariableShortcut> chatVariableShortcuts);
        void OnChatVariableShortcutNotification(IList<ChatVariableShortcut> chatVariableShortcuts);
        void OnChatPriceSummarySnapshot(IList<ChatPriceSummary> chatPriceSummaries);
        void OnChatPriceSummaryNotification(IList<ChatPriceSummary> chatPriceSummaries);
        void OnServiceStatusNotificationSnapshot(IList<ServiceStatusNotification> serviceStatusNotifications);
        void OnServiceStatusNotificationNotification(IList<ServiceStatusNotification> serviceStatusNotifications);
        void OnCalendarSnapshot(IList<Calendar> calendars);
        void OnCalendarNotification(IList<Calendar> calendars);
        void OnMonthEndRollStatusSnapshot(IList<MonthEndRollStatus> monthEndRollStatus);
        void OnMonthEndRollStatusNotification(IList<MonthEndRollStatus> monthEndRollStatus);
        void OnConfigurationSnapshot(IList<DynamicConfiguration> configurations);
        void OnConfigurationNotification(IList<DynamicConfiguration> configurations);
        void OnSystemDateSnapshot(SystemDate systemDate);
        void OnSystemDateNotification(SystemDate systemDate);
        void OnProductDefinitionsSnapshot(IList<ProductDefinition> productDefinitions);
        void OnProductDefinitionsNotifications(IList<ProductDefinition> productDefinitions);
        void OnCurrencyCodesSnapshot(IList<CurrencyCode> currencyCodes);
        void OnCurrencyCodesNotifications(IList<CurrencyCode> currencyCodes);
        void OnCurveGroupsSnapshot(IList<CurveGroup> curveGroups);
        void OnCurveGroupsNotifications(IList<CurveGroup> curveGroups);
    }
}
