﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Extensions;

namespace Dsp.Gui.Common
{
    public enum AdminApiServiceResponseReason
    {
        [Description("User is Not Authorized")]
        UserNotAuthorized,
        [Description("Dsp Failed to Process the Request")]
        DspServerError,
        [Description("User does not have Permissions to Perform Action")]
        UserPermissions,
        [Description("The Action has Timed out")]
        Timeout,
        [Description("Pricing Failures")]
        PricingFailures,
        [Description("System Error")]
        UnspecifiedError
    }

    [ExcludeFromCodeCoverage]
    public class AdminApiServiceResponse
    {
        public AdminApiServiceResponse(bool isSuccess)
        {
            IsSuccess = isSuccess;
        }

        public AdminApiServiceResponse(List<PricingFailure> pricingFailures)
        {
            PricingFailures = pricingFailures;
            IsSuccess = false;
        }

        public AdminApiServiceResponse(AdminApiServiceResponseReason reason, 
                                       List<PricingFailure> pricingFailures = null)
        {
            Response = reason;
            ReasonText = reason.ToEnumDescription();
            PricingFailures = pricingFailures;
        }

        public bool IsSuccess { get; }
        public List<PricingFailure> PricingFailures { get; }
        public string ReasonText { get; }
        public AdminApiServiceResponseReason Response { get; }
    }
}
