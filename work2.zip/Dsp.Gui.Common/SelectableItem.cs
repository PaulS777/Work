﻿
using System.Diagnostics.CodeAnalysis;
using Prism.Mvvm;

namespace Dsp.Gui.Common
{
    [ExcludeFromCodeCoverage]
    public class SelectableItem<T> : BindableBase, ISelectableItem<T>
    {
        private bool _isSelected;

        public SelectableItem(string displayText, bool isGroupingItem, T id)
        {
            DisplayText = displayText;
            IsGroupingItem = isGroupingItem;
            Id = id;
        }

        public bool IsGroupingItem { get; set; }

        public string DisplayText { get;  set; }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                RaisePropertyChanged(nameof(IsSelected));

            }
        }

        public T Id { get; set; }
    }
}
