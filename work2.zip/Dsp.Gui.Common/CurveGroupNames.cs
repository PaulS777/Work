﻿using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Common
{
    [ExcludeFromCodeCoverage]
	public static class CurveGroupNames
    {
        public const string MOGAS = "MOGAS";
        public const string Freight = "Freight";
		public const string Crude = "Crude";
        public const string FuelOil = "Fuel Oil";
        public const string MiddleDistillates = "Middle Distillates";
        public const string JetAndSingaporeDistillates = "Jet & Singapore Distillates";
        public const string NaphthaAndLpg = "Naphtha & LPG";
        public const string Bio = "Bio";
        public const string RefineryMargins = "Refinery Margins";
        public const string Power = "Power";
        public const string Fx = "Fx";
        public const string TestCurves = "Test Curves";
    }
}
