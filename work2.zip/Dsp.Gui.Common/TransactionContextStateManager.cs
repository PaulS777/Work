﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Common
{
    public sealed class TransactionContextStateManager : IDisposable
    {
        private bool _disposed;
        private readonly TransactionContextState _updateContextState;

        public TransactionContextStateManager(TransactionContextState state)
        {
            if (state.HasOwner)
            {
                throw new InvalidOperationException("Transaction Context State already has owner");
            }

            _updateContextState = state;
            _updateContextState.IsUpdating = true;
            _updateContextState.HasOwner = true;
        }

        [ExcludeFromCodeCoverage]
        ~TransactionContextStateManager()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _updateContextState.IsUpdating = false;
                _updateContextState.HasOwner = false;
            }

            _disposed = true;
        }
    }
}
