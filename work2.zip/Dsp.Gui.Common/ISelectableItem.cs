﻿
using System.ComponentModel;

namespace Dsp.Gui.Common
{
    public interface ISelectableItem<T> : IGroupingItem, INotifyPropertyChanged 
    {
        string DisplayText { get; }
        bool IsSelected { get; set; }
        T Id { get; set; }
    }
}
