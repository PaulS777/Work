﻿using System.Diagnostics.CodeAnalysis;
using System.Windows;
using System.Windows.Controls;
using DevExpress.Mvvm.UI.Interactivity;

namespace Dsp.Gui.Common.Behaviors
{
    [ExcludeFromCodeCoverage]
    public class CheckBoxThreeStateBehavior : Behavior<CheckBox>
    {
        protected override void OnAttached()
        {
            base.OnAttached();
            AssociatedObject.Click += OnClick;
        }

        private static void OnClick(object sender, RoutedEventArgs e)
        {
            if (e.Source is not CheckBox cb)
            {
                return;
            }

            cb.IsChecked ??= false;
        }
    }
}
