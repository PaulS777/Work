﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.Gui.Common.Exceptions
{
    [Serializable]
    public sealed class PricingFailuresException : Exception
    {
        private PricingFailuresException(SerializationInfo info, StreamingContext context)
        {
            PricingFailures =
                (List<PricingFailure>) info.GetValue(nameof(PricingFailures), typeof(List<PricingFailure>));
        }

        public PricingFailuresException(List<PricingFailure> pricingFailures, string message=null, Exception inner = null)
        :base(message, inner)
        {
            PricingFailures = pricingFailures;
        }

        public List<PricingFailure> PricingFailures { get; }
    }
}
