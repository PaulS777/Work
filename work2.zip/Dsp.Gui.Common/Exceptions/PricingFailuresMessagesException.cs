﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Dsp.Gui.Common.Exceptions
{
    [Serializable]
    public class PricingFailuresMessagesException : Exception
    {
        private PricingFailuresMessagesException(SerializationInfo info, StreamingContext context)
        {
            PricingFailures =
                (IList<string>)info.GetValue(nameof(PricingFailures), typeof(IList<string>));
        }

        public PricingFailuresMessagesException(IList<string> pricingFailures, string message = null, Exception inner = null)
            : base(message, inner)
        {
            PricingFailures = pricingFailures;
        }

        public IList<string> PricingFailures { get; }
    }
}
