﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;
using Dsp.ServiceContracts;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Common.Services
{
    public sealed class DispatcherExecutionService : IDispatcherExecutionService
    {
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly List<Action> _repeatActions = new();
        private readonly ILogger _log;
        private readonly ConcurrentQueue<Action> _actions = new();

        private bool _dispatcherStarted;

        private IDisposable _disposable;
        private bool _disposed;

        private bool _firstActionScheduled;
        private bool _firstActionsInvoked;

        public DispatcherExecutionService(ISchedulerProvider schedulerProvider,
                                          ILoggerFactory loggerFactory)
        {
            _schedulerProvider = schedulerProvider;

            _log = loggerFactory.Create(GetType().Name); 
        }

        [ExcludeFromCodeCoverage]
        ~DispatcherExecutionService()
        {
            Dispose(false);
        }

        [Inject]
        public IPerformanceLogger PerformanceLogger { get; set; }

        public void Start()
        {
            _disposable = Observable.Interval(TimeSpan.FromSeconds(1), _schedulerProvider.TaskPool)
                                    .ObserveOn(_schedulerProvider.Dispatcher)
                                    .Subscribe(_ => ProcessUpdates());
        }

        public void Stop()
        {
            _disposable?.Dispose();
            _actions.Clear();

            _firstActionScheduled = false;
            _firstActionsInvoked = false;
            _dispatcherStarted = false;
        }

        public void Schedule(Action action)
        {
            if (!_firstActionScheduled)
            {
                PerformanceLogger.Log(_log, GetType().Name, "First Item Scheduled");
                _firstActionScheduled = true;
            }

            _actions.Enqueue(action);
        }

        public void ScheduleRepeat(Action action)
        {
            _repeatActions.Add(action);
        }

        private void ProcessUpdates()
        {
            try
            {
                if (!_dispatcherStarted)
                {
                    PerformanceLogger.DispatcherStarted();
                    _dispatcherStarted = true;
                }

                InvokeActionsFromQueue();

                _repeatActions.ForEach(action => action());

            }
            catch (Exception ex)
            {
                _log.Error($"Error processing Dispatcher Update - {ex.Message}");
            }
        }

        private void InvokeActionsFromQueue()
        {
            var count = _actions.Count;

            if (count <= 0)
            {
                return;
            }

            if (!_firstActionsInvoked)
            {
                PerformanceLogger.Log(_log, GetType().Name, $"Processing First Batch of Actions : [{count}]");
                _firstActionsInvoked = true;
            }

            while (!_actions.IsEmpty)
            {
                if (_actions.TryDequeue(out var action))
                {
                    action();
                }
            }
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposable?.Dispose();
            }

            _disposed = true;
        }
    }
}
