﻿using System;
using System.Windows.Threading;

namespace Dsp.Gui.Common.Services
{
    public interface IDispatcherService
    {
        void BeginInvoke(Dispatcher dispatcher, Action action, DispatcherPriority priority);
    }
}
