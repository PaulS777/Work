﻿// ***********************************************************************************************************************
// ServiceFactory.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------

using System;
using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Common.Services
{
    [ExcludeFromCodeCoverage]
    public class ServiceFactory<TService> : IServiceFactory<TService>
    {
        private readonly Func<TService> _factory;

        public ServiceFactory(Func<TService> factory)
        {
            _factory = factory;
        }

        public TService Create()
        {
            return _factory();
        }
    }
}
