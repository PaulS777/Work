﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common.Services
{
    public interface IPriceCurveSettingsProvider : IDisposable
    {
        IObservable<Dictionary<int, PriceCurveSetting>> PriceCurveSettings { get; }
    }
}
