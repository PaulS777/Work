﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    /// <summary>
    /// Shared across all worksheets
    /// </summary>
    public class PriceCurveSubscriptionManager : IPriceCurveSubscriptionManager
    {
        private sealed class RefCountedCurve : IDisposable
        {
            private int _count;
            private bool _disposed;

            public RefCountedCurve()
            {
                _count = 1;

                PriceCurve = new BehaviorSubject<PriceCurve>(null);
                FxCurve = new BehaviorSubject<FxPriceCurve>(null);
            }

            [ExcludeFromCodeCoverage]
            ~RefCountedCurve()
            {
                Dispose(false);
            }
            public BehaviorSubject<PriceCurve> PriceCurve { get; }
            public BehaviorSubject<FxPriceCurve> FxCurve { get; }

            public void Add() => _count++;

            public int Remove()
            {
                _count--;
                return _count;
            }

            public void Dispose()
            {
                GC.SuppressFinalize(this);
                Dispose(true);
            }

            private void Dispose(bool disposing)
            {
                if (_disposed)
                {
                    return;
                }

                if (disposing)
                {
                    PriceCurve.Dispose();
                }

                _disposed = true;
            }
        }

        private readonly Dictionary<int, RefCountedCurve> _priceCurveRefLookup = new();
        private readonly object _synch = new();
        private readonly ILogger _log;

        public PriceCurveSubscriptionManager(ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);
        }

        public List<int> AddPriceCurves(IList<int> curveIds)
        {
            lock (_synch)
            {
                _log.Info($"AddPriceCurves : {string.Join(",", curveIds)}");

                var subscriptions = new List<int>();

                foreach (var curveId in curveIds)
                {
                    if (_priceCurveRefLookup.TryGetValue(curveId, out var curve))
                    {
                        curve.Add();
                    }
                    else
                    {
                        var refCountedCurve = new RefCountedCurve();

                        _priceCurveRefLookup.Add(curveId, refCountedCurve); 
                        
                        subscriptions.Add(curveId);
                    }
                }

                return subscriptions;
            }
        }

        public List<int> RemovePriceCurves(IList<int> curveIds)
        {
            lock (_synch)
            {
                _log.Info($"RemovePriceCurves : {string.Join(",", curveIds)}");

                var subscriptions = new List<int>();

                foreach (var curveId in curveIds)
                {
                    if (!_priceCurveRefLookup.TryGetValue(curveId, out var refCountedCurve))
                    {
                        continue;
                    }

                    if (refCountedCurve.Remove() >= 1)
                    {
                        continue;
                    }

                    refCountedCurve.Dispose();

                    _priceCurveRefLookup.Remove(curveId);

                    subscriptions.Add(curveId);
                }

                return subscriptions;
            }
        }


        public void UpdatePriceCurves(IEnumerable<PriceCurve> priceCurves)
        {
            lock (_synch)
            {
                foreach (var priceCurve in priceCurves)
                {
                    if (!_priceCurveRefLookup.TryGetValue(priceCurve.Id, out var refCountedCurve))
                    {
                        continue;
                    }

                    refCountedCurve.PriceCurve.OnNext(priceCurve);
                }
            }
        }

        // After initial batch, this will fire one by one
        // may contain successive updates for same curve
        // can that be sampled ?
        public void UpdateFxCurves(IEnumerable<FxPriceCurve> fxCurves)
        {
            lock (_synch)
            {
                foreach (var fxCurve in fxCurves)
                {
                    if (_priceCurveRefLookup.TryGetValue(fxCurve.Id, out var refCountedCurve))
                    {
                        refCountedCurve.FxCurve.OnNext(fxCurve);
                    }
                }
            }
        }
        public IObservable<PriceCurve> GetPriceCurve(int curveId)
        {
            lock (_synch)
            {
                return _priceCurveRefLookup.TryGetValue(curveId, out var refCountedCurve) ? 
                           refCountedCurve.PriceCurve 
                           : Observable.Empty<PriceCurve>();
            }
        }

        public IObservable<FxPriceCurve> GetFxCurve(int curveId)
        {
            lock (_synch)
            {
                return _priceCurveRefLookup.TryGetValue(curveId, out var refCountedCurve)
                ? refCountedCurve.FxCurve
                : Observable.Empty<FxPriceCurve>();
            }
        }
    }
}
