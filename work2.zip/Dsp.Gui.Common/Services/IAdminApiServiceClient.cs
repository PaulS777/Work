﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services.Connection;

namespace Dsp.Gui.Common.Services
{
    public interface IAdminApiServiceClient
    {
        void Initialize(IHttpClientProxy httpClient);
        Task <AdminApiServiceResponse> Update<T>(int id, T value);
        Task<AdminApiServiceResponse> Update<T>(T value);
        Task<AdminApiServiceResponse> UpdateChatTenorSelection(User value);
        Task<AdminApiServiceResponse> UpdateMonthEndRoll<T>(T value);
        Task<AdminApiServiceResponse> Add<T>(T value);
        Task<AdminApiServiceResponse> Add<T>(IList<T> values);
        Task<AdminApiActionResponse> UpdateAction<T>(IList<T> actions);
    }
}
