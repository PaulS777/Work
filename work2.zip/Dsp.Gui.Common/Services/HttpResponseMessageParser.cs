﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using Dsp.DataContracts.DerivedCurves;
using Newtonsoft.Json;

namespace Dsp.Gui.Common.Services
{
    public class HttpResponseMessageParser : IHttpResponseMessageParser
    {
        public async Task<List<PricingFailure>> ParsePricingFailures(HttpResponseMessage response)
        {
            var error = await response.Content.ReadAsAsync<HttpError>();

            if (error == null)
            {
                return null;
            }

            if (!error.TryGetValue("message", out var value))
            {
                return null;
            }

            if (value is not string message)
            {
                return null;
            }

            if (string.IsNullOrEmpty(message))
            {
                return null;
            }

            var pricingFailures =
                (List<PricingFailure>)JsonConvert.DeserializeObject(message,
                    typeof(List<PricingFailure>));

            return pricingFailures;
        }
    }
}
