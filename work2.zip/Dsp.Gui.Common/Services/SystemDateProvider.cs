﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;

namespace Dsp.Gui.Common.Services
{
    public sealed class SystemDateProvider : ISystemDateProvider
    {
        private const string UkCalendarCode = "UKB";
        private readonly BehaviorSubject<DateTime?> _systemDate = new(null);
        private readonly IDisposable _disposable;
        private bool _disposed;

        public SystemDateProvider(ICurveControlService controlService)
        {
            var calendarId = controlService.Calendars
                                           .Where(c => c != null)
                                           .Select(c => c.FirstOrDefault(cal =>  cal.Status == EntityStatus.Active 
                                                                                 && cal.Code == UkCalendarCode))
                                           .Where(cal => cal != null)
                                           .Select(cal => cal.Id)
                                           .Take(1);

            _disposable = calendarId.Select(id => controlService.SystemDate
                                                                .Where(sd => sd != null)
                                                                .Select(sd => sd.BusinessDays.Find(bd => bd.CalendarId == id)))
                                    .Switch()
                                    .Where(bd => bd != null)
                                    .Select(bd => bd.CurrentBusinessDay)
                                    .DistinctUntilChanged()
                                    .Subscribe(date => _systemDate.OnNext(date));
        }

        [ExcludeFromCodeCoverage]
        ~SystemDateProvider()
        {
            Dispose(false);
        }

        public IObservable<DateTime?> SystemDate => _systemDate.AsObservable();

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposable.Dispose();
            }

            _disposed = true;
        }
    }
}
