﻿// ***********************************************************************************************************************
// IPackageInfoProvider.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
using Windows.ApplicationModel;

namespace Dsp.Gui.Common.Services
{
    public interface IPackageInfoProvider
    {
        bool IsNetworkDeployment { get; }
        PackageVersion PackageVersion { get; }
    }
}
