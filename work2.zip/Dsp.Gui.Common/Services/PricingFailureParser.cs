﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.Gui.Common.Services
{
    public class PricingFailureParser : IPricingFailureParser
    {
        public bool TryParsePricingFailures(Dictionary<LinkedCurve, string> curveLookup,
                                            List<PricingFailure> pricingFailures,
                                            out string[] messages)
        {
            var list = new List<string>();

            pricingFailures?.ForEach(pf =>
            {
                if (pf.Reason == PricingFailureReason.DependencyFailure)
                {
                    return;
                }

                if (ParseFailure(curveLookup, pf, out var message))
                {
                    list.Add(message);
                }
            });

            if (list.Count == 0)
            {
                messages = Array.Empty<string>();
                return false;
            }

            messages = list.ToArray();

            return true;
        }

        private static bool ParseFailure(IReadOnlyDictionary<LinkedCurve, string> curveLookup,
                                         PricingFailure pricingFailure,
                                         out string message)
        {
            if ( pricingFailure?.LinkedCurve == null)
            {
                message = null;
                return false;
            }

            var priceCurveId = new LinkedCurve(pricingFailure.PriceCurveId, PriceCurveDefinitionType.PriceCurve);

            var priceCurveName = curveLookup.TryGetValue(priceCurveId, out var priceCurve)
                                    ? priceCurve
                                    : pricingFailure.PriceCurveId.ToString();

            var derivedCurveId = new LinkedCurve(pricingFailure.DerivedCurveId, PriceCurveDefinitionType.DerivedCurve);

            var derivedCurveName = curveLookup.TryGetValue(derivedCurveId, out var derivedCurve)
                                        ? derivedCurve
                                        : pricingFailure.DerivedCurveId.ToString();

            string relatedCurveName = null;

            if (pricingFailure.LinkedCurve != null)
            {
                relatedCurveName = curveLookup.TryGetValue(pricingFailure.LinkedCurve.Value, out var relatedCurve)
                                       ? relatedCurve
                                       : pricingFailure.LinkedCurve.Value.Id.ToString(CultureInfo.InvariantCulture);
            }

            var reasonText = GetReasonText(pricingFailure.Reason);

            var sb = new StringBuilder($"{derivedCurveName} ({priceCurveName}) - {reasonText}");

            if (!string.IsNullOrEmpty(relatedCurveName))
            {
                sb.AppendLine($": referenced curve {relatedCurveName}.");
            }

            if (!string.IsNullOrEmpty(pricingFailure.Details))
            {
                sb.AppendLine(pricingFailure.Details);
            }

            message = sb.ToString();   

            return true;
        }

        private static string GetReasonText(PricingFailureReason reason)
        {
            switch (reason)
            {
                case PricingFailureReason.AnchorPointTenorReferenceNotFound:
                    return "Anchor Point Tenor Reference Not Found";
                default:
                    return reason.ToString();
            }
        }
    }
}
