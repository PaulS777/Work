﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Threading;

namespace Dsp.Gui.Common.Services
{
    [ExcludeFromCodeCoverage]
    public class DispatcherService : IDispatcherService
    {
        public void BeginInvoke(Dispatcher dispatcher, Action action, DispatcherPriority priority) => dispatcher.BeginInvoke(action, priority);
    }
}
