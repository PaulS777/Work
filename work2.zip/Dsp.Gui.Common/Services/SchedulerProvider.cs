﻿using System.Diagnostics.CodeAnalysis;
using System.Reactive.Concurrency;

namespace Dsp.Gui.Common.Services
{
    [ExcludeFromCodeCoverage]
    public class SchedulerProvider : ISchedulerProvider
    {
        public IScheduler Dispatcher => DispatcherScheduler.Current;

        public IScheduler TaskPool => Scheduler.Default;

        public IScheduler Immediate => Scheduler.Immediate;
    }
}
