﻿using System.Reactive.Concurrency;

namespace Dsp.Gui.Common.Services
{
    public interface ISchedulerProvider
    {
        IScheduler Dispatcher { get; }

        IScheduler TaskPool { get; }

        IScheduler Immediate { get; }
    }
}
