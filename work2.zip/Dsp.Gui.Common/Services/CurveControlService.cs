﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Configuration;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Extensions;
using Dsp.ServiceContracts;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Calendar = Dsp.DataContracts.Calendar;

namespace Dsp.Gui.Common.Services
{
    public sealed class CurveControlService : ICurveControlService, IDisposable
    {
        private readonly IAdminApiConnectionService _adminApiConnectionService;
        private readonly IAdminApiHubConnection _hubConnection;

        private readonly Cache<PriceCurveDefinition> _priceCurveDefinitionCache;
        private readonly Cache<ManualCurveDefinition<MonthlyTenor>> _manualCurveDefinitionCache;
        private readonly Cache<ManualCurveDefinition<DailyTenor>> _dailyCurveDefinitionCache;
        private readonly Cache<FlatPriceCurveDefinition<MonthlyTenor>> _flatPriceCurveDefinitionCache;
        private readonly Cache<DerivedCurveDefinition> _derivedCurveDefinitionCache;
        private readonly Cache<User> _userCache;
        private readonly Cache<PublisherTenorPremium> _publisherTenorPremiumCache;
        private readonly Cache<FxCurveDefinition> _fxCurveDefinitionCache;
        private readonly Cache<FxCurvePipsBuffer> _fxCurvePipsBufferCache;
        private readonly Cache<FxCurveSetting> _fxCurveSettingCache;
        private readonly Cache<PriceCurveSetting> _priceCurveSettingCache;
        private readonly Cache<PriceCurvePremium> _priceCurvePremiumCache;
        private readonly Cache<ChatUser> _chatUserCache;
        private readonly Cache<ChatMarket> _chatMarketCache;
        private readonly Cache<ChatMessageHistory> _chatMessageCache;
        private readonly Cache<ChatIceMap> _chatIceMapCache;
        private readonly Cache<ChatVariableShortcut> _chatVariableShortcutCache;
        private readonly Cache<ChatPriceSummary> _chatPriceSummaryCache;
        private readonly Cache<ServiceStatusNotification> _serviceStatusNotificationCache;
        private readonly Cache<Calendar> _calendarCache;
        private readonly Cache<MonthEndRollStatus> _monthEndRollStatusCache;
        private readonly Cache<DynamicConfiguration> _dynamicConfigurationCache;
        private readonly Cache<ProductDefinition> _productDefinitionsCache;
        private readonly Cache<CurrencyCode> _currencyCodesCache;
        private readonly Cache<CurveGroup> _curveGroupCache;

        private readonly BehaviorSubject<IList<PriceCurveDefinition>> _priceCurveDefinitionsSubject = new(null);
        private readonly BehaviorSubject<IList<ManualCurveDefinition<MonthlyTenor>>> _manualCurveDefinitionsSubject = new(null);
        private readonly BehaviorSubject<List<ManualCurveDefinition<MonthlyTenor>>> _manualOverridesSubject = new(null);
        private readonly BehaviorSubject<List<ManualCurveDefinition<DailyTenor>>> _dailyOverridesSubject = new(null);
        private readonly BehaviorSubject<List<PriceCurveSetting>> _priceCurveSettingSubject = new(null);
        private readonly BehaviorSubject<List<PriceCurvePremium>> _priceCurvePremiumSubject = new(null);
        private readonly BehaviorSubject<List<PublisherTenorPremium>> _publisherTenorPremiumsSubject = new(null);
        private readonly BehaviorSubject<List<FlatPriceCurveDefinition<MonthlyTenor>>> _flatPriceCurveDefinitionSubject = new(null);
        private readonly BehaviorSubject<List<DerivedCurveDefinition>> _derivedCurvesSubject = new(null);
        private readonly BehaviorSubject<List<User>> _users = new(null);
        private readonly BehaviorSubject<User> _currentUser = new(null);
        private readonly BehaviorSubject<IList<FxCurveDefinition>> _fxCurveDefinitions = new(null);
        private readonly BehaviorSubject<IList<FxCurvePipsBuffer>> _fxCurvePipsBuffers = new(null);
        private readonly BehaviorSubject<IList<FxCurveSetting>> _fxCurveSettings = new(null);
        private readonly BehaviorSubject<IList<ChatUser>> _chatUsersSubject = new(null);
        private readonly BehaviorSubject<List<ChatMarket>> _chatMarketSubject = new(null);
        private readonly BehaviorSubject<List<ChatMessageHistory>> _chatMessageSubject = new(null);
        private readonly BehaviorSubject<List<ChatIceMap>> _chatIceMapSubject = new(null);
        private readonly BehaviorSubject<List<ChatVariableShortcut>> _chatVariableShortcutSubject = new(null);
        private readonly BehaviorSubject<IList<ChatPriceSummary>> _chatPriceSummarySnapshotSubject = new(null);
        private readonly ReplaySubject<IList<ChatPriceSummary>> _chatPriceSummaryNotificationSubject = new();
        private readonly BehaviorSubject<List<ServiceStatusNotification>> _serviceStatusNotificationSubject = new(null);
        private readonly BehaviorSubject<IList<Calendar>> _calendarSubject = new(null);
        private readonly BehaviorSubject<List<MonthEndRollStatus>> _monthEndRollStatusSubject = new(null);
        private readonly Subject<IList<MonthEndRollStatus>> _monthEndRollStatusNotifications = new();
        private readonly BehaviorSubject<List<DynamicConfiguration>> _configurationSubject = new(null);
        private readonly BehaviorSubject<SystemDate> _systemDate = new(null);
        private readonly BehaviorSubject<List<ProductDefinition>> _productDefinitions = new(null);
        private readonly BehaviorSubject<List<CurrencyCode>> _currencyCodes = new(null);
        private readonly BehaviorSubject<List<CurveGroup>> _curveGroups = new(null);

		private bool _subscribedCurrencyCodes;
		private bool _subscribedProductDefinitions;
        private bool _subscribedCurveGroups;

		private readonly CompositeDisposable _disposables = new();
        private readonly object _synch = new();
        private readonly ILogger _log;

        private bool _disposed;
        
        public CurveControlService(ILoggerFactory loggerFactory,
                                   IAdminApiConnectionService adminApiConnectionService,
                                   IAdminApiHubConnection hubConnection)
        {
            _log = loggerFactory.Create(GetType().Name);

            _adminApiConnectionService = adminApiConnectionService;
            _hubConnection = hubConnection;

            _priceCurveDefinitionCache = new Cache<PriceCurveDefinition>();
            _userCache = new Cache<User>();
            _publisherTenorPremiumCache = new Cache<PublisherTenorPremium>();
            _manualCurveDefinitionCache = new Cache<ManualCurveDefinition<MonthlyTenor>>();
            _dailyCurveDefinitionCache = new Cache<ManualCurveDefinition<DailyTenor>>();
            _flatPriceCurveDefinitionCache = new Cache<FlatPriceCurveDefinition<MonthlyTenor>>();
            _derivedCurveDefinitionCache = new Cache<DerivedCurveDefinition>();
            _fxCurveDefinitionCache = new Cache<FxCurveDefinition>();
            _fxCurvePipsBufferCache = new Cache<FxCurvePipsBuffer>();
            _fxCurveSettingCache = new Cache<FxCurveSetting>();
            _priceCurveSettingCache = new Cache<PriceCurveSetting>();
            _chatUserCache = new Cache<ChatUser>();
            _chatMarketCache = new Cache<ChatMarket>();
            _chatMessageCache = new Cache<ChatMessageHistory>();
            _chatIceMapCache = new Cache<ChatIceMap>();
            _chatVariableShortcutCache = new Cache<ChatVariableShortcut>();
            _chatPriceSummaryCache = new Cache<ChatPriceSummary>();
            _serviceStatusNotificationCache = new Cache<ServiceStatusNotification>();
            _calendarCache = new Cache<Calendar>();
            _priceCurvePremiumCache = new Cache<PriceCurvePremium>();
            _monthEndRollStatusCache = new Cache<MonthEndRollStatus>();
            _dynamicConfigurationCache = new Cache<DynamicConfiguration>();
            _productDefinitionsCache = new Cache<ProductDefinition>();
            _currencyCodesCache = new Cache<CurrencyCode>();
            _curveGroupCache = new Cache<CurveGroup>();

            _log.Info("Waiting for connection to CurvePublisher SignalR Hub...");

            var connected = _adminApiConnectionService.RunState
                                                      .Where(state => state == HubConnectionRunState.Connected);

            var reconnected = _adminApiConnectionService.RunState
                                                        .Where(state => state == HubConnectionRunState.Reconnected);

            connected.Take(1)
                     .Subscribe(_ => OnConnected())
                     .AddTo(_disposables);

            reconnected.Subscribe(_ => SubscribeAll())
                       .AddTo(_disposables);

            _adminApiConnectionService.CurrentUser
                                      .Where(user => user != null)
                                      .Subscribe(OnCurrentUser)
                                      .AddTo(_disposables);
        }

        [ExcludeFromCodeCoverage]
        ~CurveControlService()
        {
            Dispose(false);
        }

        private void OnConnected()
        {
            _hubConnection.AttachHubEvents(this,
                                           _adminApiConnectionService.HubConnectionProxy);

            SubscribeAll();

            _log.Info("Connected to CurvePublisher SignalR Hub");
        }

        public User CurrentUserSnapshot { get; private set; }

        // todo : TASK-2729441  Refactor
        public IObservable<User> CurrentUser => _currentUser.AsObservable();
        public IEnumerable<User> GetUsersSnapshot() => _userCache.GetSnapshot();
        public IEnumerable<Calendar> GetCalendarsSnapshot() => _calendarCache.GetSnapshot();
        public IEnumerable<PriceCurveDefinition> GetPriceCurveDefinitionsSnapshot() => _priceCurveDefinitionCache.GetSnapshot();
        public IEnumerable<FxCurveDefinition> GetFxCurveDefinitionsSnapshot() => _fxCurveDefinitionCache.GetSnapshot();
        public IEnumerable<FxCurvePipsBuffer> GetFxCurvePipsBufferSnapshot() => _fxCurvePipsBufferCache.GetSnapshot();
        public IEnumerable<FxCurveSetting> GetFxCurveSettingsSnapshot() => _fxCurveSettingCache.GetSnapshot();
        public IEnumerable<PriceCurveSetting> GetPriceCurveSettingsSnapshot() => _priceCurveSettingCache.GetSnapshot();
        public IEnumerable<ChatUser> GetChatUsersSnapshot() => _chatUserCache.GetSnapshot();
        public IEnumerable<ChatMarket> GetChatMarketSnapshot() => _chatMarketCache.GetSnapshot();
        public IEnumerable<ChatMessageHistory> GetChatMessagesSnapshot() => _chatMessageCache.GetSnapshot();
        public IEnumerable<ChatIceMap> GetChatIceMapSnapshot() => _chatIceMapCache.GetSnapshot();
        public IEnumerable<ChatVariableShortcut> GetChatVariableShortcutSnapshot() => _chatVariableShortcutCache.GetSnapshot();
        public IEnumerable<ChatPriceSummary> GetChatPriceSummarySnapshot() => _chatPriceSummaryCache.GetSnapshot();
        public IEnumerable<ServiceStatusNotification> GetServiceStatusNotificationSnapshot() => _serviceStatusNotificationCache.GetSnapshot();
        public IEnumerable<Calendar> GetCalendarSnapshot() => _calendarCache.GetSnapshot();
        public IEnumerable<PriceCurvePremium> GetPriceCurvePremiumsSnapshot() => _priceCurvePremiumCache.GetSnapshot();
        public IEnumerable<MonthEndRollStatus> GetMonthEndRollStatusSnapshot() => _monthEndRollStatusCache.GetSnapshot();
        public IEnumerable<ManualCurveDefinition<MonthlyTenor>> GetManualCurveDefinitionsSnapshot() => _manualCurveDefinitionCache.GetSnapshot();
        public IEnumerable<ProductDefinition> GetProductDefinitionsSnapshot() => _productDefinitionsCache.GetSnapshot();
        public IEnumerable<CurrencyCode> GetCurrencyCodesSnapshot() => _currencyCodesCache.GetSnapshot();
        public IEnumerable<CurveGroup> GetCurveGroupsSnapshot() => _curveGroupCache.GetSnapshot();
        public IEnumerable<DynamicConfiguration> GetConfigurationSnapshot() => _dynamicConfigurationCache.GetSnapshot();
        public IObservable<List<User>> Users => _users.AsObservable();
        public IObservable<IList<PriceCurveDefinition>> PriceCurveDefinitions => _priceCurveDefinitionsSubject.AsObservable();
        public IObservable<IList<ManualCurveDefinition<MonthlyTenor>>> ManualCurveDefinitions => _manualCurveDefinitionsSubject.AsObservable();
        public IObservable<List<ManualCurveDefinition<MonthlyTenor>>> ManualOverrides => _manualOverridesSubject.AsObservable();
        public IObservable<List<ManualCurveDefinition<DailyTenor>>> DailyOverrides => _dailyOverridesSubject.AsObservable();
        public IObservable<List<PriceCurveSetting>> PriceCurveSettings => _priceCurveSettingSubject.AsObservable();
        public IObservable<List<FlatPriceCurveDefinition<MonthlyTenor>>> FlatPriceCurveDefinitions => _flatPriceCurveDefinitionSubject.AsObservable();
        public IObservable<List<DerivedCurveDefinition>> DerivedCurveDefinitions => _derivedCurvesSubject.AsObservable();
        public IObservable<List<PublisherTenorPremium>> PublisherTenorPremiums => _publisherTenorPremiumsSubject.AsObservable();
        public IObservable<IList<FxCurveDefinition>> FxCurveDefinitions => _fxCurveDefinitions.AsObservable();
        public IObservable<IList<FxCurvePipsBuffer>> FxCurvePipsBuffers => _fxCurvePipsBuffers.AsObservable();
        public IObservable<IList<FxCurveSetting>> FxCurveSettings => _fxCurveSettings.AsObservable();
        public IObservable<IList<ChatUser>> ChatUsers => _chatUsersSubject.AsObservable();
        public IObservable<List<ChatMarket>> ChatMarkets => _chatMarketSubject.AsObservable();
        public IObservable<List<ChatMessageHistory>> ChatMessages => _chatMessageSubject.AsObservable();
        public IObservable<List<ChatIceMap>> ChatIceMaps => _chatIceMapSubject.AsObservable();
        public IObservable<List<ChatVariableShortcut>> ChatVariableShortcuts => _chatVariableShortcutSubject.AsObservable();
        public IObservable<IList<ChatPriceSummary>> ChatPriceSummarySnapshot  => _chatPriceSummarySnapshotSubject.AsObservable();
        public IObservable<IList<ChatPriceSummary>> ChatPriceSummaryNotifications => _chatPriceSummaryNotificationSubject.AsObservable();
        public IObservable<List<ServiceStatusNotification>> ServiceStatusNotifications => _serviceStatusNotificationSubject.AsObservable();
        public IObservable<List<ProductDefinition>> ProductDefinitions => _productDefinitions.AsObservable();
        public IObservable<List<CurrencyCode>> CurrencyCodes => _currencyCodes.AsObservable();
        public IObservable<SystemDate> SystemDate => _systemDate.AsObservable();
        public IObservable<List<CurveGroup>> CurveGroups => _curveGroups.AsObservable();
        public IObservable<IList<Calendar>> Calendars => _calendarSubject.AsObservable();
        public IObservable<List<PriceCurvePremium>> PriceCurvePremiums => _priceCurvePremiumSubject.AsObservable();
        public IObservable<List<MonthEndRollStatus>> MonthEndRollStatusOnUpdate => _monthEndRollStatusSubject.AsObservable();
        public IObservable<IList<MonthEndRollStatus>> MonthEndRollStatusNotifications => _monthEndRollStatusNotifications.AsObservable();
        public IObservable<List<DynamicConfiguration>> ConfigurationOnUpdate => _configurationSubject.AsObservable();
        public List<ChatMessageHistory> ChatMessagesOnUpdate { get; set; }

        public void SubscribeUsers()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }
                
            _hubConnection.SubscribeUsers();
        }

        public void UnsubscribeUsers()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeUsers();
        }

        public void SubscribePriceCurveDefinitions()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribePriceCurveDefinitions();
        }

        public void UnsubscribePriceCurveDefinitions()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }
            
            _hubConnection.UnsubscribePriceCurveDefinitions();
        }

        public void SubscribeDerivedCurveDefinitions()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeDerivedCurveDefinitions();
        }

        public void UnsubscribeDerivedCurveDefinitions()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeDerivedCurveDefinitions();
        }

        public void SubscribeCurvePublishers()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeCurvePublishers();
        }

        public void UnsubscribeCurvePublishers()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeCurvePublishers();
        }

        public void SubscribePriceCurves(IEnumerable<int> curveIds)
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribePriceCurves(curveIds);
        }

        public void UnsubscribePriceCurves(IEnumerable<int> curveIds)
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribePriceCurves(curveIds);
        }

        public void SubscribeFxCurveDefinitions()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeFxCurveDefinitions();
        }

        public void UnsubscribeFxCurveDefinitions()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeFxCurveDefinitions();
        }

        public void SubscribeFxCurves(IEnumerable<int> curveIds)
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeFxCurves(curveIds);
        }

        public void UnsubscribeFxCurves(IEnumerable<int> curveIds)
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }
            
            _hubConnection.UnsubscribeFxCurves(curveIds);
        }

        public void SubscribeChatUsers()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeChatUsers();
        }
        public void UnsubscribeChatUsers()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeChatUsers();
        }

        public void SubscribeChatMarkets()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeChatMarkets();
        }

        public void UnsubscribeChatMarkets()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }
            
            _hubConnection.UnsubscribeChatMarkets();
        }

        public void SubscribeChatMessageHistory()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeChatMessageHistory();
        }

        public void UnsubscribeChatMessageHistory()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeChatMessageHistory();
        }

        public void SubscribeChatIceMap()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeChatIceMap();
        }

        public void UnsubscribeChatIceMap()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeChatIceMap();
        }

        public void SubscribeChatVariableShortcut()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeChatVariableShortcut();
        }

        public void UnsubscribeChatVariableShortcut()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeChatVariableShortcut();
        }

        public void SubscribeCalendars()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeCalendars();
        }

        public void UnsubscribeCalendars()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeCalendars();
        }

        public void SubscribeSystemDate()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeSystemDate();
        }

        public void UnsubscribeSystemDate()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeSystemDate();
        }

        public void SubscribeProductDefinitions()
        {
            if (!_adminApiConnectionService.IsConnected || _subscribedProductDefinitions)
            {
                return;
            }

            _hubConnection.SubscribeProductDefinitions();

			_subscribedProductDefinitions = true;

		}

        public void UnsubscribeProductDefinitions()
        {
            if (!_adminApiConnectionService.IsConnected )
            {
                return;
            }

            _hubConnection.UnsubscribeProductDefinitions();

			_subscribedProductDefinitions = false;
		}

		public void SubscribeCurrencyCodes()
        {
            if (!_adminApiConnectionService.IsConnected || _subscribedCurrencyCodes)
            {
                return;
            }

            _hubConnection.SubscribeCurrencyCodes();

			_subscribedCurrencyCodes = true;
		}

        public void UnsubscribeCurrencyCodes()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeCurrencyCodes();

			_subscribedCurrencyCodes = false;
		}

        public void SubscribeCurveGroups()
        {
			if (!_adminApiConnectionService.IsConnected || _subscribedCurveGroups)
            {
                return;
            }

            _hubConnection.SubscribeCurveGroups();

            _subscribedCurveGroups = true;
        }

        public void UnsubscribeCurveGroups()
        {
			if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeCurveGroups();
            _subscribedCurveGroups = false;
        }

        public void SubscribeMonthEndRollStatus()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeMonthEndRollStatus();
        }

        public void UnsubscribeMonthEndRollStatus()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeMonthEndRollStatus();
        }

        public void SubscribeConfiguration()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.SubscribeConfiguration();
        }

        public void UnsubscribeConfiguration()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                return;
            }

            _hubConnection.UnsubscribeConfiguration();
        }

        public void OnPriceCurveSnapshotNotification(IList<PriceCurveSetting> priceCurveSettings, 
                                                     IList<PriceCurvePremium> priceCurvePremiums, 
                                                     IList<PublisherTenorPremium> publisherTenorPremiums)
        {
            OnPriceCurveSettingsUpdates(priceCurveSettings);
            OnPriceCurvePremiumsUpdates(priceCurvePremiums);
            OnPublisherTenorPremiumUpdates(publisherTenorPremiums);
        }

        public void OnPriceCurveSettingNotification(PriceCurveSetting priceCurveSetting) => OnPriceCurveSettingsUpdates(new List<PriceCurveSetting> { priceCurveSetting });
        public void OnPublisherTenorPremiumsSnapshot(IList<PublisherTenorPremium> publisherTenorPremiums) => OnPublisherTenorPremiumUpdates(publisherTenorPremiums);
        public void OnPublisherTenorPremiumNotification(PublisherTenorPremium publisherTenorPremium) => OnPublisherTenorPremiumUpdates(new List<PublisherTenorPremium>{publisherTenorPremium});
		public void OnPriceCurveDefinitionsSnapshot(IList<PriceCurveDefinition> priceCurveDefinitions) => UpdatePriceCurveDefinitionsSnapshot(priceCurveDefinitions);
        public void OnPriceCurveDefinitionsNotification(IList<PriceCurveDefinition> priceCurveDefinitions) => UpdatePriceCurveDefinitions(priceCurveDefinitions);

        public void OnUsersSnapshot(IList<User> users)
        {
            lock (_synch)
            {
                _log.Info($"OnUsersSnapshot: {users.Count} Users");

                var allUsers = _userCache.StoreLatest(users);

                _users.OnNext(allUsers);
            }
        }

        public void OnUsersNotification(IList<User> users)
        {
            lock (_synch)
            {
                if (users == null)
                {
                    return;
                }

                _log.Info($"OnUsersNotification: {users.Count} Users");
                 
                var allUsers = _userCache.StoreLatest(users);

                if (CurrentUserSnapshot != null && users.Any(u => CurrentUserSnapshot.Id == u.Id))
                {
                    CurrentUserSnapshot = users.First(u => CurrentUserSnapshot.Id == u.Id);

                    _priceCurveDefinitionCache.Clear();
                    _manualCurveDefinitionCache.Clear();

                    _priceCurveDefinitionsSubject.OnNext(null);
					_manualCurveDefinitionsSubject.OnNext(null);

                    _hubConnection.SubscribePriceCurveDefinitions();
                    _hubConnection.SubscribeDerivedCurveDefinitions();

                    _currentUser.OnNext(CurrentUserSnapshot);
                }
                _users.OnNext(allUsers);
            }
        }

        public void OnDerivedCurveDefinitionsSnapshot(IList<DerivedCurveDefinition> derivedCurveDefinitions)
        {
            _log.Info($"OnDerivedCurveDefinitionsSnapshot: {derivedCurveDefinitions?.Count} DerivedCurveDefinitions");

            var derivedCurves = _derivedCurveDefinitionCache.StoreLatest(derivedCurveDefinitions);

            _derivedCurvesSubject.OnNext(derivedCurves);

            var manualCurves = GetManualCurveDefinitions(derivedCurveDefinitions);

            _manualCurveDefinitionsSubject.OnNext(manualCurves);
            _manualOverridesSubject.OnNext(manualCurves);

            var dailyCurveDefinitions = GetDailyCurveDefinitions(derivedCurveDefinitions);

            _dailyOverridesSubject.OnNext(dailyCurveDefinitions);

            var flatPriceCurves = GetFlatPriceCurveDefinitions(derivedCurveDefinitions);

            _flatPriceCurveDefinitionSubject.OnNext(flatPriceCurves);
        }

        public void OnDerivedCurveDefinitionsNotification(IList<DerivedCurveDefinition> derivedCurveDefinitions)
        {
            _log.Info($"OnDerivedCurveDefinitionsNotification: {derivedCurveDefinitions?.Count} DerivedCurveDefinitions");

            var derivedCurves = _derivedCurveDefinitionCache.StoreLatest(derivedCurveDefinitions);

            _derivedCurvesSubject.OnNext(derivedCurves);

            var manualCurveDefinitions = GetManualCurveDefinitions(derivedCurveDefinitions);

            _manualCurveDefinitionsSubject.OnNext(manualCurveDefinitions);
            _manualOverridesSubject.OnNext(manualCurveDefinitions);

            var dailyCurveDefinitions = GetDailyCurveDefinitions(derivedCurveDefinitions);

            _dailyOverridesSubject.OnNext(dailyCurveDefinitions);


            var flatPriceCurves = GetFlatPriceCurveDefinitions(derivedCurveDefinitions);

            _flatPriceCurveDefinitionSubject.OnNext(flatPriceCurves);
        }

        private List<ManualCurveDefinition<MonthlyTenor>> GetManualCurveDefinitions(IEnumerable<DerivedCurveDefinition> derivedCurveDefinitions)
        {
            lock (_synch)
            {
                var manualCurves = derivedCurveDefinitions.Where(curve => curve.MonthlyDefinition?.ManualCurveDefinition != null)
                                                          .Select(curve => curve.MonthlyDefinition.ManualCurveDefinition)
                                                          .ToList();

                _manualCurveDefinitionCache.StoreLatest(manualCurves);

                return _manualCurveDefinitionCache.GetSnapshot();
            }
        }

        private List<ManualCurveDefinition<DailyTenor>> GetDailyCurveDefinitions(IEnumerable<DerivedCurveDefinition> derivedCurveDefinitions)
        {
            lock (_synch)
            {
                var dailyCurves = derivedCurveDefinitions.Where(curve => curve.DailyDefinition?.ManualCurveDefinition != null)
                                                         .Select(curve => curve.DailyDefinition.ManualCurveDefinition)
                                                         .ToList();

                _dailyCurveDefinitionCache.StoreLatest(dailyCurves);

                return _dailyCurveDefinitionCache.GetSnapshot();
            }
        }

        private List<FlatPriceCurveDefinition<MonthlyTenor>> GetFlatPriceCurveDefinitions(IEnumerable<DerivedCurveDefinition> derivedCurveDefinitions)
        {
            var flatPriceCurves = derivedCurveDefinitions.Where(curve => curve.MonthlyDefinition?.FlatPriceCurveDefinition != null)
                                                         .Select(curve => curve.MonthlyDefinition.FlatPriceCurveDefinition)
                                                         .ToList();

            _flatPriceCurveDefinitionCache.StoreLatest(flatPriceCurves);

            return _flatPriceCurveDefinitionCache.GetSnapshot();
        }

        public void OnFxCurveSettingsSnapshot(IList<FxCurveSetting> fxCurveSettings)
        {
            lock (_synch)
            {
                _log.Info($"OnFxCurveSettingsNotification: {fxCurveSettings.Count} FxCurveSetting");
                _fxCurveSettingCache.StoreLatest(fxCurveSettings);
                _fxCurveSettings.OnNext(fxCurveSettings.ToList());
            }
        }

        public void OnFxCurveSettingsSnapshot(FxCurveSetting fxCurveSetting) => OnFxCurveSettingsSnapshot(new List<FxCurveSetting> { fxCurveSetting });

        public void OnFxCurvePipsBufferSnapshot(FxCurvePipsBuffer fxCurvePipsBuffer) => OnFxCurvePipsBufferSnapshot(new List<FxCurvePipsBuffer> { fxCurvePipsBuffer });

        public void OnFxCurvePipsBufferSnapshot(IList<FxCurvePipsBuffer> fxCurvePipsBuffers)
        {
            lock (_synch)
            {
                _log.Info($"OnFxCurvePipsBufferNotification: {fxCurvePipsBuffers.Count} FxCurvePipsBuffer");

                var cache = _fxCurvePipsBufferCache.StoreLatest(fxCurvePipsBuffers);

                _fxCurvePipsBuffers.OnNext(cache);
            }
        }

        public void OnChatUsersSnapshot(IList<ChatUser> chatUsers)
        {
            lock (_synch)
            {
                _log.Info($"OnChatUsersSnapshot: {chatUsers.Count} ChatUser");

                var cache = _chatUserCache.StoreLatest(chatUsers);

                _chatUsersSubject.OnNext(cache);
            }
        }

        public void OnChatUsersNotification(IList<ChatUser> chatUsers)
        {
            lock (_synch)
            {
                _log.Info($"OnChatUsersNotification: {chatUsers.Count} ChatUser");

                var cache = _chatUserCache.StoreLatest(chatUsers);

                _chatUsersSubject.OnNext(cache);
            }
        }

        public void OnChatUsersNotification(ChatUser chatUser)
        {
            lock (_synch)
            {
                _log.Info($"OnChatUsersNotification: {chatUser.Name} ChatUser");

                var cache = _chatUserCache.StoreLatest(new List<ChatUser>{chatUser});

                _chatUsersSubject.OnNext(cache);
            }
        }

        public void OnChatMarketsSnapshot(IList<ChatMarket> chatMarkets)
        {
            lock (_synch)
            {
                _log.Info($"OnChatMarketsSnapshot: {chatMarkets.Count} ChatMarket");

                var cache = _chatMarketCache.StoreLatest(chatMarkets);

                _chatMarketSubject.OnNext(cache);
            }
        }

        public void OnChatMarketsNotification(IList<ChatMarket> chatMarkets)
        {
            lock (_synch)
            {
                _log.Info($"OnChatMarketsNotification: {chatMarkets.Count} ChatMarket");

                var cache = _chatMarketCache.StoreLatest(chatMarkets);

                _chatMarketSubject.OnNext(cache);
            }
        }

        public void OnChatMarketsNotification(ChatMarket chatMarket)
        {
            lock (_synch)
            {
                _log.Info($"OnChatMarketsNotification: {chatMarket.Market} ChatMarket");

                var cache = _chatMarketCache.StoreLatest(new List<ChatMarket> { chatMarket });

                _chatMarketSubject.OnNext(cache);
            }
        }

        public void OnChatMessagesSnapshot(IList<ChatMessageHistory> chatMessages)
        {
            lock (_synch)
            {
                _log.Info($"OnChatMessagesSnapshot: {chatMessages.Count} ChatMessageHistory");

                var cache = _chatMessageCache.StoreLatest(chatMessages);

                _chatMessageSubject.OnNext(cache);

                ChatMessagesOnUpdate = chatMessages?.ToList();
            }
        }

        public void OnChatMessagesNotification(IList<ChatMessageHistory> chatMessages)
        {
            lock (_synch)
            {
                var cache = _chatMessageCache.StoreLatest(chatMessages);

                _chatMessageSubject.OnNext(cache);

                ChatMessagesOnUpdate = chatMessages?.ToList();
            }
        }

        public void OnChatIceMapSnapshot(IList<ChatIceMap> chatIceMaps)
        {
            lock (_synch)
            {
                _log.Info($"OnChatIceMapsSnapshot: {chatIceMaps.Count} ChatIceMap");

                var cache = _chatIceMapCache.StoreLatest(chatIceMaps);

                _chatIceMapSubject.OnNext(cache);
            }
        }

        public void OnChatIceMapNotification(IList<ChatIceMap> chatIceMaps)
        {
            lock (_synch)
            {
                _log.Info($"OnChatIceMapNotification: {chatIceMaps.Count} ChatIceMap");

                var cache = _chatIceMapCache.StoreLatest(chatIceMaps);

                _chatIceMapSubject.OnNext(cache);
            }
        }

        public void OnChatVariableShortcutSnapshot(IList<ChatVariableShortcut> chatVariableShortcuts)
        {
            lock (_synch)
            {
                _log.Info($"OnChatVariableShortcutsSnapshot: {chatVariableShortcuts.Count} ChatVariableShortcut");

                var cache = _chatVariableShortcutCache.StoreLatest(chatVariableShortcuts);

                _chatVariableShortcutSubject.OnNext(cache);
            }
        }

        public void OnChatVariableShortcutNotification(IList<ChatVariableShortcut> chatVariableShortcuts)
        {
            lock (_synch)
            {
                _log.Info($"OnChatVariableShortcutNotification: {chatVariableShortcuts.Count} ChatVariableShortcut");

                var cache = _chatVariableShortcutCache.StoreLatest(chatVariableShortcuts);

                _chatVariableShortcutSubject.OnNext(cache);
            }
        }

        public void OnChatPriceSummarySnapshot(IList<ChatPriceSummary> chatPriceSummaries)
        {
            lock (_synch)
            {
                _log.Info($"OnChatPriceSummarySnapshot: {chatPriceSummaries.Count} ChatPriceSummary");

                _chatPriceSummarySnapshotSubject.OnNext(chatPriceSummaries);
            }
        }

        public void OnChatPriceSummaryNotification(IList<ChatPriceSummary> chatPriceSummaries)
        {
            lock (_synch)
            {
                _log.Info($"OnChatPriceSummaryNotification: {chatPriceSummaries.Count} ChatPriceSummary");

                _chatPriceSummaryNotificationSubject.OnNext(chatPriceSummaries);
            }
        }

        public void OnServiceStatusNotificationSnapshot(IList<ServiceStatusNotification> serviceStatusNotifications)
        {
            lock (_synch)
            {
                var cache = _serviceStatusNotificationCache.StoreLatest(serviceStatusNotifications);

                _serviceStatusNotificationSubject.OnNext(cache);
            }
        }

        public void OnServiceStatusNotificationNotification(IList<ServiceStatusNotification> serviceStatusNotifications)
        {
            lock (_synch)
            {
                var cache = _serviceStatusNotificationCache.StoreLatest(serviceStatusNotifications);

                _serviceStatusNotificationSubject.OnNext(cache);
            }
        }

        public void OnCalendarSnapshot(IList<Calendar> calendars)
        {
            lock (_synch)
            {
                _log.Info($"OnCalendarSnapshot: {calendars.Count} Calendar");

                var cache = _calendarCache.StoreLatest(calendars);

                _calendarSubject.OnNext(cache);
            }
        }
        public void OnCalendarNotification(IList<Calendar> calendars)
        {
            lock (_synch)
            {
                _log.Info($"OnCalendarNotification: {calendars.Count} Calendars");

                var cache = _calendarCache.StoreLatest(calendars);

                _calendarSubject.OnNext(cache);
            }
        }

        /// <summary>
        /// Returns all months
        /// </summary>
        /// <param name="monthEndRollStatus"></param>
        public void OnMonthEndRollStatusSnapshot(IList<MonthEndRollStatus> monthEndRollStatus)
        {
            lock (_synch)
            {
                _log.Info($"OnMonthEndRollStatusSnapshot: {monthEndRollStatus.Count} monthEndRollStatus");
                var latest = _monthEndRollStatusCache.StoreLatest(monthEndRollStatus);
                _monthEndRollStatusSubject.OnNext(latest);
            }
        }

        /// <summary>
        /// Returns single record for current month only
        /// </summary>
        /// <param name="monthEndRollStatus"></param>
        public void OnMonthEndRollStatusNotification(IList<MonthEndRollStatus> monthEndRollStatus)
        {
            lock (_synch)
            {
                _log.Info($"OnMonthEndRollStatusNotification: {monthEndRollStatus.Count} MonthEndRollStatus");
                var latest = _monthEndRollStatusCache.StoreLatest(monthEndRollStatus);
                _monthEndRollStatusSubject.OnNext(latest);

                _monthEndRollStatusNotifications.OnNext(monthEndRollStatus);
            }
        }

        public void OnConfigurationSnapshot(IList<DynamicConfiguration> configurations)
        {
            lock (_synch)
            {
                _log.Info($"OnConfigurationSnapshot: {configurations.Count} Configuration");
                var latest = _dynamicConfigurationCache.StoreLatest(configurations);
                _configurationSubject.OnNext(latest);
            }
        }

        public void OnConfigurationNotification(IList<DynamicConfiguration> configurations)
        {
            lock (_synch)
            {
                _log.Info($"OnConfigurationNotification: {configurations.Count} Configuration");
                var latest = _dynamicConfigurationCache.StoreLatest(configurations);
                _configurationSubject.OnNext(latest);
            }
        }

        public void OnSystemDateSnapshot(SystemDate systemDate)
        {
            lock (_synch)
            {
                _log.Info($"OnSystemDateSnapshot: {systemDate}");
                _systemDate.OnNext(systemDate);
            }
        }

        public void OnSystemDateNotification(SystemDate systemDate)
        {
            lock (_synch)
            {
                _log.Info($"OnSystemDateNotification: {systemDate}");
                _systemDate.OnNext(systemDate);
            }
        }

        public void OnProductDefinitionsSnapshot(IList<ProductDefinition> productDefinitions)
        {
            lock (_synch)
            {
                _log.Info($"OnProductDefinitionsSnapshot: {productDefinitions?.Count} ProductDefinitions");

                var cache = _productDefinitionsCache.StoreLatest(productDefinitions);
                _productDefinitions.OnNext(cache);
            }
        }

        public void OnProductDefinitionsNotifications(IList<ProductDefinition> productDefinitions)
        {
            lock (_synch)
            {
                _log.Info($"OnProductDefinitionsNotifications {productDefinitions?.Count} ProductDefinitions");

                var cache = _productDefinitionsCache.StoreLatest(productDefinitions);
                _productDefinitions.OnNext(cache);
            }
        }

        public void OnCurrencyCodesSnapshot(IList<CurrencyCode> currencyCodes)
        {
            lock (_synch)
            {
                _log.Info($"OnCurrencyCodesSnapshot {currencyCodes?.Count} CurrencyCodes");

                var cache = _currencyCodesCache.StoreLatest(currencyCodes);
                _currencyCodes.OnNext(cache);
            }
        }

        public void OnCurrencyCodesNotifications(IList<CurrencyCode> currencyCodes)
        {
            lock (_synch)
            {
                _log.Info($"OnCurrencyCodesNotifications {currencyCodes?.Count} CurrencyCodes");

                var cache = _currencyCodesCache.StoreLatest(currencyCodes);
                _currencyCodes.OnNext(cache);
            }
        }

        public void OnCurveGroupsSnapshot(IList<CurveGroup> curveGroups)
        {
			lock (_synch)
            {
                _log.Info($"OnCurveGroupsSnapshot {curveGroups?.Count} CurveGroups");

                var cache = _curveGroupCache.StoreLatest(curveGroups);
                _curveGroups.OnNext(cache);
            }
		}

        public void OnCurveGroupsNotifications(IList<CurveGroup> curveGroups)
        {
			lock (_synch)
            {
                _log.Info($"OnCurveGroupsNotifications {curveGroups?.Count} CurveGroups");

                var cache = _curveGroupCache.StoreLatest(curveGroups);
                _curveGroups.OnNext(cache);
            }
		}

        public void OnPriceCurvePremiumNotification(PriceCurvePremium priceCurvePremium) => OnPriceCurvePremiumsUpdates(new List<PriceCurvePremium> { priceCurvePremium });

        public void OnPriceCurveSettingsUpdates(IList<PriceCurveSetting> priceCurveSettings)
        {
            _log.Info($"OnPriceCurveSettingsUpdates: {priceCurveSettings?.Count} PriceCurveSettings");
            _priceCurveSettingCache.StoreLatest(priceCurveSettings);

            _priceCurveSettingSubject.OnNext(priceCurveSettings?.ToList());
        }

        public void OnPriceCurvePremiumsUpdates(IList<PriceCurvePremium> priceCurvePremiums)
        {
            _log.Info($"OnPriceCurvePremiumUpdates: {priceCurvePremiums?.Count} PriceCurvePremiums");
            var cache = _priceCurvePremiumCache.StoreLatest(priceCurvePremiums);
            _priceCurvePremiumSubject.OnNext(cache);
        }

        public void OnPublisherTenorPremiumUpdates(IList<PublisherTenorPremium> publisherTenorPremiums)
        {
            _log.Info($"OnPublisherTenorPremiumUpdates: {publisherTenorPremiums?.Count} PublisherTenorPremiums");

            _publisherTenorPremiumCache.StoreLatest(publisherTenorPremiums);
            var latest = _publisherTenorPremiumCache.GetSnapshot();

            _publisherTenorPremiumsSubject.OnNext(latest);
        }

        public void OnFxCurveDefinitionSnapshot(IList<FxCurveDefinition> fxCurveDefinitions)
        {
            lock (_synch)
            {
                _log.Info($"OnFxCurveDefinitionSnapshot: {fxCurveDefinitions.Count} FxCurveDefinition");
                _fxCurveDefinitionCache.StoreLatest(fxCurveDefinitions);

                var latest = _fxCurveDefinitionCache.GetSnapshot();

                _fxCurveDefinitions.OnNext(latest);
            }
        }


        public void OnFxCurveDefinitionNotification(IList<FxCurveDefinition> fxCurveDefinitions)
        {
			lock (_synch)
            {
                _log.Info($"OnFxCurveDefinitionNotification: {fxCurveDefinitions.Count} FxCurveDefinition");
                _fxCurveDefinitionCache.StoreLatest(fxCurveDefinitions);

                var latest = _fxCurveDefinitionCache.GetSnapshot();

                _fxCurveDefinitions.OnNext(latest);
            }
		}

		private void OnCurrentUser(User user)
        {
            CurrentUserSnapshot = user;
            _currentUser.OnNext(user);
        }

        private void SubscribeAll()
        {
            _hubConnection.SubscribePriceCurveDefinitions();
            _hubConnection.SubscribeDerivedCurveDefinitions();
            _hubConnection.SubscribeCurvePublishers();
            _hubConnection.SubscribeUsers();
            _hubConnection.SubscribeFxCurveDefinitions();
            _hubConnection.SubscribeChatUsers();
            _hubConnection.SubscribeChatMarkets();
            _hubConnection.SubscribeChatMessageHistory();
            _hubConnection.SubscribeChatIceMap();
            _hubConnection.SubscribeChatVariableShortcut();
            _hubConnection.SubscribeChatPriceSummary();
            _hubConnection.SubscribeServiceStatusNotification();
            _hubConnection.SubscribeCalendars();
            _hubConnection.SubscribeMonthEndRollStatus();
            _hubConnection.SubscribeConfiguration();
            _hubConnection.SubscribeSystemDate();
            _hubConnection.SubscribeCurveGroups();
        }

		private void UpdatePriceCurveDefinitionsSnapshot(IEnumerable<PriceCurveDefinition> cd)
		{
			var priceCurveDefinitions = cd.Where(def => def.Status != EntityStatus.Deleted);

			UpdatePriceCurveDefinitions(priceCurveDefinitions);
		}

        private void UpdatePriceCurveDefinitions(IEnumerable<PriceCurveDefinition> cd)
        {
            var priceCurveDefinitions = cd as PriceCurveDefinition[] ?? cd.ToArray();

            _log.Info($"UpdatePriceCurveDefinitions: {priceCurveDefinitions.Length} PriceCurveDefinitions");
            _priceCurveDefinitionCache.StoreLatest(priceCurveDefinitions);

            var latest = _priceCurveDefinitionCache.GetSnapshot();

			_priceCurveDefinitionsSubject.OnNext(latest);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
