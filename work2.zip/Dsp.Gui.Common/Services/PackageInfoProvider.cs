﻿// ***********************************************************************************************************************
// PackageInfoProvider.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
// Provides Package Info
// ************************************************************************************************************************

using System.Diagnostics.CodeAnalysis;
using Windows.ApplicationModel;

namespace Dsp.Gui.Common.Services
{
    [ExcludeFromCodeCoverage]
    public class PackageInfoProvider : IPackageInfoProvider
    {
        public PackageInfoProvider()
        {
            var helpers = new DesktopBridge.Helpers();

            IsNetworkDeployment = helpers.IsRunningAsUwp();
        }

        public bool IsNetworkDeployment { get; }

        public PackageVersion PackageVersion => IsNetworkDeployment ? Package.Current.Id.Version : new PackageVersion();
    }
}
