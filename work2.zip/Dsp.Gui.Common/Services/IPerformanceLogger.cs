﻿using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    public interface IPerformanceLogger
    {
        void StartLog();
        void Log(ILogger logger, string source, string message);
        void Checkpoint();
        void DispatcherStarted();
    }
}
