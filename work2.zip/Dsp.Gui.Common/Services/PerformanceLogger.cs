﻿using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    [ExcludeFromCodeCoverage]
    public class PerformanceLogger : IPerformanceLogger
    {
        private readonly ILogger _log;
        private DateTime _startTime;
        private DateTime _checkpointTime;

        public PerformanceLogger(ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);
        }

        public void StartLog()
        {
            _startTime = DateTime.Now;

            var message = $"[{_startTime:HH:mm:ss.fff}] PERFORMANCE LOGGING [START]";

            Debug.WriteLine(message);
            _log.Info(message);
        }

        public void Checkpoint()
        {
            _checkpointTime = DateTime.Now;

            var timeSpan = _checkpointTime - _startTime;

            var message = $"[{_checkpointTime:HH:mm:ss.fff}] PERFORMANCE LOGGING [CHECKPOINT] - ELAPSED [{timeSpan.Seconds}:{timeSpan.Milliseconds:000}]";

            Debug.WriteLine(message);
            _log.Info(message);
        }

        public void DispatcherStarted()
        {
            var renderTime = DateTime.Now;

            var timeSpan = renderTime - _checkpointTime;

            var message1 = $"[{_checkpointTime:HH:mm:ss.fff}] PERFORMANCE LOGGING [DISPATCHER STARTED] - ELAPSED [{timeSpan.Seconds}:{timeSpan.Milliseconds:000}]";

            Debug.WriteLine(message1);
            _log.Info(message1);

            var totalTime = renderTime - _startTime;

            var message2 = $"[{_checkpointTime:HH:mm:ss.fff}] PERFORMANCE LOGGING [END] - TOTAL ELAPSED [{totalTime.Seconds}:{totalTime.Milliseconds:000}]";

            Debug.WriteLine(message2);
            _log.Info(message2);
        }

        public void Log(ILogger logger, string source, string message)
        {
            var threadName = Thread.CurrentThread.IsBackground || Thread.CurrentThread.IsThreadPoolThread
                ? "THREAD POOL"
                : "MAIN";

            Debug.WriteLine($"[{threadName}] {source} [{DateTime.Now:HH:mm:ss.fff}] {message}");

            logger.Info($"{source} {message}");
        }
    }
}
