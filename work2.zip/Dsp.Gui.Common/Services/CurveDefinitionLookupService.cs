﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Extensions;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    public sealed class CurveDefinitionLookupService : ICurveDefinitionLookupService
    {
        private readonly ILogger _log;
        private readonly CompositeDisposable _disposables = new();
        private readonly BehaviorSubject<bool> _curvesLoaded = new(false);
        private bool _disposed;

        public CurveDefinitionLookupService(ICurveControlService curveControlService,
                                            ISchedulerProvider schedulerProvider,
                                            ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            var derivedCurves = curveControlService.DerivedCurveDefinitions
                                                   .Where(d => d != null);

            var priceCurves = curveControlService.PriceCurveDefinitions
                                                 .Where(p => p != null);

            derivedCurves.CombineLatest(priceCurves, (d, p) => new { Derived = d, Prices = p })
                         .ObserveOn(schedulerProvider.TaskPool)
                         .Subscribe(curves => OnCurvesLoaded(curves.Derived, curves.Prices))
                         .AddTo(_disposables);
        }

        public IObservable<bool> CurvesLoaded => _curvesLoaded;
        public List<FlatPriceCurveDefinition<MonthlyTenor>> FlatPriceCurveDefinitions { get; private set; }
        public List<PartitionedCurveDefinition<MonthlyTenor>> PartitionedCurveDefinitions { get; private set; }
        public Dictionary<LinkedCurve, string> CurveNameLookup { get; private set; }

        private void OnCurvesLoaded(IReadOnlyCollection<DerivedCurveDefinition> derivedCurves,
                                    IEnumerable<PriceCurveDefinition> priceCurves)
        {
            FlatPriceCurveDefinitions = derivedCurves.Where(d => d.MonthlyDefinition?.FlatPriceCurveDefinition != null)
                                                     .Select(d => d.MonthlyDefinition.FlatPriceCurveDefinition).ToList();

            PartitionedCurveDefinitions = derivedCurves.Where(d => d.MonthlyDefinition?.PartitionedCurveDefinition != null)
                                                       .Select(d => d.MonthlyDefinition.PartitionedCurveDefinition).ToList();

            CurveNameLookup = priceCurves.ToDictionary(c => new LinkedCurve(c.Id, PriceCurveDefinitionType.PriceCurve), c => c.Name);

            _log.Info("Curves Loaded");

            _curvesLoaded.OnNext(true);
        }

        [ExcludeFromCodeCoverage]
        ~CurveDefinitionLookupService()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
