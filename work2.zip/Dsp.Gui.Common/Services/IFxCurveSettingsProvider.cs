﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common.Services
{
    public interface IFxCurveSettingsProvider : IDisposable
    {
        IObservable<IList<FxCurveSetting>> FxCurveSettings { get; }
    }
}
