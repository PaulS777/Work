﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.Gui.Common.Services
{
    public interface IHttpResponseMessageParser
    {
        Task<List<PricingFailure>> ParsePricingFailures(HttpResponseMessage response);
    }
}
