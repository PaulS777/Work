﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using System.Threading;
using Dsp.DataContracts.Configuration;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    public sealed class MutexInstance : IMutexInstance
    {
        private readonly BehaviorSubject<bool?> _status = new(false);
        private readonly Mutex _mutex;
        private bool _disposed;

        public MutexInstance(IConfigProvider configProvider,
                             IDspApplicationRunService dspApplicationRunService,
                             ILoggerFactory loggerFactory)
        {
            var log = loggerFactory.Create(GetType().Name);

            log.Info("Initializing DSP : ...");

            var name = string.Format(
                $"{dspApplicationRunService.MutexInstanceName}_{configProvider.Configuration.EnvironmentName}", CultureInfo.InvariantCulture);

            _status.OnNext(true);

            log.Info($"Obtaining Mutex [{name}]");
            _mutex = new Mutex(true, name, out var created);

            if (created)
            {
                log.Warn($"Obtained Mutex [{name}]");
                _status.OnNext(true);
            }
            else
            {
                log.Warn($"Failed to Obtain Mutex [{name}]");
                _status.OnNext(false);
            }
        }

        [ExcludeFromCodeCoverage]
        ~MutexInstance()
        {
            Dispose(false);
        }

        public IObservable<bool?> Status => _status.AsObservable();

        public void Dispose()
        {
           GC.SuppressFinalize(this);
           Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _mutex?.Dispose();
            }

            _disposed = true;
        }
    }
}
