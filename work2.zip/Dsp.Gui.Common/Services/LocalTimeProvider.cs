﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Dsp.Gui.Common.Services
{
    [ExcludeFromCodeCoverage]
    public class LocalTimeProvider : ILocalTimeProvider
    {
        public TimeOnly LocalTime => TimeOnly.FromDateTime(DateTime.Now);
    }
}
