﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common.Services
{
    public interface IPriceCurveSubscriptionManager
    {
        List<int> AddPriceCurves(IList<int> curveIds);
        List<int> RemovePriceCurves(IList<int> curveIds);
        void UpdatePriceCurves(IEnumerable<PriceCurve> priceCurves);
        void UpdateFxCurves(IEnumerable<FxPriceCurve> fxCurves);
        IObservable<PriceCurve> GetPriceCurve(int curveId);
        IObservable<FxPriceCurve> GetFxCurve(int curveId);
    }
}
