﻿using Dsp.DataContracts.Curve;
using System.Collections.Generic;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface ICurvePublisherHubConnectionClient
    {
        void OnPriceCurvesSnapshot(IEnumerable<PriceCurve> priceCurves);
        void OnPriceCurveNotification(PriceCurve priceCurve);
        void OnFxCurvesSnapshot(IEnumerable<FxPriceCurve> fxPriceCurves);
        void OnFxCurveNotification(FxPriceCurve fxPriceCurve);
    }
}
