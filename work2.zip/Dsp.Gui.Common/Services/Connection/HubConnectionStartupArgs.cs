﻿namespace Dsp.Gui.Common.Services.Connection
{
    public enum FatalHubConnectionError
    {
        NotSet,
        ApiAuthenticationFailed,
        SsoAuthenticationFailed,
        AuthorizationFailed,
        HubInitializeFailed,
        ObsoleteClient,
        ConnectionsExceeded,
        UnexpectedError
    }

    public enum HubConnectingState
    {
        NotSet,
        Connecting,
        Connected,
        HttpFailed
    }

    public class HubConnectionStartupArgs
    {
        public HubConnectionStartupArgs(HubConnectingState state)
        {
            ConnectingState = state;
        }

        public HubConnectionStartupArgs(FatalHubConnectionError error, string message)
        {
            FatalError = error;
            IsFatalError = true;
            ErrorMessage = message;
        }

        public HubConnectingState ConnectingState { get; }
        public bool IsFatalError { get; }
        public FatalHubConnectionError FatalError { get; }
        public string ErrorMessage { get; }
    }
}
