﻿using System.Net.Http;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IHttpClientProxy
    {
        HttpClient HttpClient { get; }
    }
}
