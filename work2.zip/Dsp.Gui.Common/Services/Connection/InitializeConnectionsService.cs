﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Reactive.Threading.Tasks;
using System.Threading.Tasks;
using Dsp.Gui.Common.Extensions;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services.Connection
{
    /// <summary>
    /// Performs initialization of connections 
    /// </summary>
    public sealed class InitializeConnectionsService : IInitializeConnectionsService
    {
        private readonly IMutexInstance _mutexInstance;
        private readonly IAdminApiConnectionService _adminApiConnectionService;
        private readonly ICurvePublisherConnectionService _curvePublisherConnectionService;
        private readonly IAdminApiServiceClient _adminApiService;
        private readonly CompositeDisposable _disposables = new();
        private readonly ILogger _log;

        private bool _disposed;

        public InitializeConnectionsService(IMutexInstance mutexInstance,
                                            IAdminApiConnectionService adminApiConnectionService,
                                            ICurvePublisherConnectionService curvePublisherConnectionService,
                                            IAdminApiServiceClient adminApiService,
                                            ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _mutexInstance = mutexInstance;
            _adminApiConnectionService = adminApiConnectionService;
            _curvePublisherConnectionService = curvePublisherConnectionService;
            _adminApiService = adminApiService;
        }

        [ExcludeFromCodeCoverage]
        ~InitializeConnectionsService()
        {
            Dispose(false);
        }

        public void InitializeConnections()
        {
            _log.Info("Waiting for Mutex ...");

            _mutexInstance.Status
                          .Where(s => s is true)
                          .Take(1)
                          .Subscribe(_ => Connect().ToObservable())
                          .AddTo(_disposables);
        }

        private async Task Connect()
        {
            await _adminApiConnectionService.Connect();

            if (_adminApiConnectionService.IsConnected)
            {
                _adminApiService.Initialize(_adminApiConnectionService.HttpClientProxy);
            }

            await _curvePublisherConnectionService.Connect();
        }

        public async Task RetryConnect()
        {
            if (!_adminApiConnectionService.IsConnected)
            {
                await _adminApiConnectionService.RetryConnect();

                if (_adminApiConnectionService.IsConnected)
                {
                    _adminApiService.Initialize(_adminApiConnectionService.HttpClientProxy);
                }
            }

            if (!_curvePublisherConnectionService.IsConnected)
            {
                await _curvePublisherConnectionService.RetryConnect();
            }
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
