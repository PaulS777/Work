﻿using System;
using System.Threading.Tasks;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Common.Services.Connection.Publication;

namespace Dsp.Gui.Common.Services.Connection
{
    public class CurvePublisherConnectionService : ICurvePublisherConnectionService
    {
        private readonly IAuthenticatedHubConnectionService _authenticatedHubConnectionService;
        private readonly IConfigProvider _configProvider;
        private const string ServiceName = "Curve Publisher";

        public CurvePublisherConnectionService(IAuthenticatedHubConnectionService authenticatedHubConnectionService,
                                               IConfigProvider configProvider)
        {
            _authenticatedHubConnectionService = authenticatedHubConnectionService;
            _configProvider = configProvider;
        }

        public async Task Connect()
        {
            var authenticationUrl = _configProvider.GetApiUrl(DataContracts.Configuration.Services.AdminWebApi);
            var hubUrl = _configProvider.GetSignalRUrl(DataContracts.Configuration.Services.CurvePublisherService);

            // Authentication must be done on the same host as the hub - this check ensures the code works on both VMs and K8S
            if (authenticationUrl.Host != hubUrl.Host)
            {
                authenticationUrl = _configProvider.GetApiUrl(DataContracts.Configuration.Services.CurvePublisherService);
            }

            await _authenticatedHubConnectionService.Connect(ServiceName, authenticationUrl, hubUrl);
        }

        public async Task RetryConnect()
        {
            await _authenticatedHubConnectionService.RetryConnect();
        }

        public async Task RestartConnect()
        {
            await _authenticatedHubConnectionService.RestartConnect();
        }

        public IHubConnectionProxy HubConnectionProxy => _authenticatedHubConnectionService.HubConnectionProxy;
        public IObservable<HubConnectionStartupArgs> StartupState => _authenticatedHubConnectionService.StartupStatePublisher.StartupState;
        public IObservable<HubConnectionRunState> RunState => _authenticatedHubConnectionService.RunStatePublisher.RunState;
        public bool IsConnected => _authenticatedHubConnectionService.IsConnected;

        public async ValueTask DisposeAsync()
        {
            await _authenticatedHubConnectionService.DisposeAsync().ConfigureAwait(false);

            GC.SuppressFinalize(this);
        }
    }
}
