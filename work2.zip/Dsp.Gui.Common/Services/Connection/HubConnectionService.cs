﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Threading.Tasks;
using Windows.ApplicationModel;
using Dsp.DataContracts;
using Dsp.DataContracts.WebApi;
using Dsp.Serialization;
using Dsp.ServiceContracts;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.DependencyInjection;

namespace Dsp.Gui.Common.Services.Connection
{
    [ExcludeFromCodeCoverage]
    public sealed class HubConnectionService : IHubConnectionService
    {
        private readonly IDspApplicationRunService _dspApplicationRunService;
        private readonly IPackageInfoProvider _packageInfoProvider;
        private readonly ILogger _log;

        private IHubConnectionClient _hubConnectionClient;
        private HubConnection _hubConnection;
        private bool _disconnecting;
        private bool _disposed;

        public HubConnectionService(IDspApplicationRunService dspApplicationRunService,
                                    IPackageInfoProvider packageInfoProvider,
                                    ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _dspApplicationRunService = dspApplicationRunService;
            _packageInfoProvider = packageInfoProvider;
        }

        public IHubConnectionProxy Initialize(IAuthenticatedServiceClient authorisedServiceClient,
                                              IHubConnectionClient hubConnectionClient,
                                              Uri hubUri)
        {
            _hubConnectionClient = hubConnectionClient;
        
            _hubConnection = 
                new HubConnectionBuilder().WithAutomaticReconnect(hubConnectionClient.RetryPolicy)
                                          .AddNewtonsoftJsonProtocol(j =>
                                                                     { 
                                                                         j.PayloadSerializerSettings.ContractResolver = new CustomContractResolver();
                                                                     })
                                          .WithUrl(hubUri, options => 
                                                           {
                                                               options.Credentials = CredentialCache.DefaultNetworkCredentials;
                                                               options.Cookies.Add(authorisedServiceClient.Cookies);
                                                               options.ClientCertificates?.AddRange(authorisedServiceClient.Certificates);
                                                               options.Headers.Add(WebSocketHeaderType.Api, _dspApplicationRunService.WebSocketClientType.ToString());
                                                               options.Headers.Add(WebSocketHeaderType.Version, VersionInfo());
                                                               options.Headers.Add("Origin", Environment.MachineName);
                                                           })
                                          .Build();

            _hubConnection.On<ApiConnectionStatus, User>("HandleConnectionStatus", OnHandleConnectionStatus);
            _hubConnection.On("DisconnectClient", async () => await OnDisconnectClient().ConfigureAwait(false));

            _hubConnection.Reconnecting += HubConnectionOnReconnecting;
            _hubConnection.Closed += HubConnectionOnClosed;

            return new HubConnectionProxy(_hubConnection);
        }

        private Task HubConnectionOnClosed(Exception exception)
        {
            _log.Info($"[{_hubConnectionClient.Service}] HubConnection Closed [{exception?.Message}]");

            if (!_disconnecting)
            {
                _hubConnectionClient.OnClosed(exception);
            }
            
            return Task.CompletedTask;
        }

        public async Task Connect()
        {
            await _hubConnection.StartAsync();
        }

        private Task HubConnectionOnReconnecting(Exception ex)
        {
            _hubConnectionClient.OnReconnecting(ex);

            return Task.CompletedTask;
        }

        private void OnHandleConnectionStatus(ApiConnectionStatus status, User user)
        {
            _hubConnectionClient.OnApiConnectionStatus(status);
            _hubConnectionClient.OnUser(user);
        }

        private  string VersionInfo()
        {
            return _packageInfoProvider.IsNetworkDeployment
                                    ? GetPackageVersionString(_packageInfoProvider.PackageVersion)
                                    : "Development Build";
        }

        private static string GetPackageVersionString(PackageVersion packageVersion)
        {
            return $"{packageVersion.Major}.{packageVersion.Minor}.{packageVersion.Build}.{packageVersion.Revision}";
        }

        public async ValueTask DisposeAsync()
        {
            if (_disposed)
            {
                return;
            }

            await Disconnect();

            _disposed = true;
        }

        private async Task OnDisconnectClient()
        {
            _log.Info($"[{_hubConnectionClient.Service}] Disconnecting...");

            await Disconnect().ConfigureAwait(false);
        }

        private async Task Disconnect()
        {
            if (_hubConnection == null)
            {
                return;
            }

            _disconnecting = true;

            _log.Info($"[{_hubConnectionClient.Service}] Stopping HubConnection...");

            await _hubConnection.StopAsync().WaitAsync(TimeSpan.FromSeconds(5)).ConfigureAwait(false);

            _log.Info($"[{_hubConnectionClient.Service}] Disposing HubConnection...");

            await _hubConnection.DisposeAsync().ConfigureAwait(false);

            _hubConnection = null;
        }
    }
}
