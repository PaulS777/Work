﻿using System;
using System.Threading.Tasks;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IAuthenticatedHubConnectionService : IAuthenticatedHubConnection,  
                                                          IAsyncDisposable, 
                                                          IDisposable
    {
        Task Connect(string service, 
                     Uri authenticationUri, 
                     Uri hubUri);

        Task RetryConnect();

        Task RestartConnect();

        bool IsConnected { get; }
    }
}
