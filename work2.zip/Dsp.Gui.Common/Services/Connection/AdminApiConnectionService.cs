﻿using System;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.DataContracts.Configuration;
using Dsp.Gui.Common.Services.Connection.Publication;

namespace Dsp.Gui.Common.Services.Connection
{
    public class AdminApiConnectionService : IAdminApiConnectionService
    {
        private readonly IAuthenticatedHubConnectionService _authenticatedHubConnectionService;
        private readonly IConfigProvider _configProvider;
        private const string ServiceName = "AdminWebApi";

        public AdminApiConnectionService(IAuthenticatedHubConnectionService authenticatedHubConnectionService,
                                         IConfigProvider configProvider)
        {
            _authenticatedHubConnectionService = authenticatedHubConnectionService;
            _configProvider = configProvider;
        }

        public async Task Connect()
        {
            var apiUrl = _configProvider.GetApiUrl(DataContracts.Configuration.Services.AdminWebApi);
            var hubUrl = _configProvider.GetSignalRUrl(DataContracts.Configuration.Services.AdminWebApi);

            await _authenticatedHubConnectionService.Connect(ServiceName,
                                                             apiUrl, 
                                                             hubUrl);
        }

        public async Task RetryConnect()
        {
            await _authenticatedHubConnectionService.RetryConnect();
        }

        public async Task RestartConnect()
        {
            await _authenticatedHubConnectionService.RestartConnect();
        }

        public IHttpClientProxy HttpClientProxy => _authenticatedHubConnectionService.HttpClientProxy;

        public IHubConnectionProxy HubConnectionProxy => _authenticatedHubConnectionService.HubConnectionProxy;

        public IObservable<HubConnectionStartupArgs> StartupState => _authenticatedHubConnectionService.StartupStatePublisher.StartupState;

        public IObservable<HubConnectionRunState> RunState => _authenticatedHubConnectionService.RunStatePublisher.RunState;

        public IObservable<User> CurrentUser => _authenticatedHubConnectionService.UserPublisher.CurrentUser;

        public bool IsConnected => _authenticatedHubConnectionService.IsConnected;

        public async ValueTask DisposeAsync()
        {
            await _authenticatedHubConnectionService.DisposeAsync().ConfigureAwait(false);

            GC.SuppressFinalize(this);
        }
    }
}
