﻿using System;
using System.Threading.Tasks;
using Dsp.Gui.Common.Services.Connection.Publication;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface ICurvePublisherConnectionService : IAsyncDisposable
    {
        Task Connect();
        Task RetryConnect();
        Task RestartConnect();
        IHubConnectionProxy HubConnectionProxy { get; }
        IObservable<HubConnectionStartupArgs> StartupState { get; }
        IObservable<HubConnectionRunState> RunState { get; }
        bool IsConnected { get; }
    }
}
