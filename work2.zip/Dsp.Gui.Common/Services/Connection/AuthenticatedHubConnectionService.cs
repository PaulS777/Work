﻿using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using System.Reactive.Disposables;
using System.Security.Authentication;
using System.Threading.Tasks;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services.Connection
{
    /// <summary>
    /// Provides Connection and Authentication with Retry if first connect attempt fails
    /// </summary>
    public sealed class AuthenticatedHubConnectionService : IAuthenticatedHubConnectionService
    {
        private readonly IAuthenticatedServiceClient _authenticatedServiceClient;
        private readonly IHubConnectionService _hubConnectionService;
        private readonly IHubConnectionStartupStateService _startupStateService;
        private readonly IHubConnectionRunStateService _runStateService;
        private readonly IHubConnectionUserService _userService;
        private readonly IHubConnectionClient _hubConnectionClient;
        private readonly CompositeDisposable _disposables = new();
        private readonly ILogger _log;

        private string _service;
        private Uri _authenticationUri;
        private Uri _hubUri;
        private bool _hasFatalError;
        private bool _isAuthenticated;
        private bool _disposed;

        public AuthenticatedHubConnectionService(IAuthenticatedServiceClient authenticatedServiceClient,
                                                 IHubConnectionService hubConnectionService,
                                                 IHubConnectionStartupStateService startupStateService,
                                                 IHubConnectionRunStateService runStateService,
                                                 IHubConnectionUserService userService,
                                                 IHubConnectionClient hubConnectionClient,
                                                 ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _authenticatedServiceClient = authenticatedServiceClient;
            _hubConnectionService = hubConnectionService;
            _startupStateService = startupStateService;
            _runStateService = runStateService;
            _userService = userService;
            _hubConnectionClient = hubConnectionClient;
        }

        [ExcludeFromCodeCoverage]
        ~AuthenticatedHubConnectionService()
        {
            Dispose(false);
        }

        public IHttpClientProxy HttpClientProxy { get; private set; }
        public IHubConnectionProxy HubConnectionProxy { get; private set; }
        public IHubConnectionStartupStatePublisher StartupStatePublisher => _startupStateService;
        public IHubConnectionRunStatePublisher RunStatePublisher => _runStateService;
        public IHubConnectionUserPublisher UserPublisher => _userService;
        public bool IsConnected => HubConnectionProxy is { IsConnected: true };
   
        public async Task Connect(string service,
                                  Uri authenticationUri,
                                  Uri hubUri)
        {
            _service = service;
            _authenticationUri = authenticationUri;
            _hubUri = hubUri;

            LogInfo($"Connect : Initialize HubConnectionClient [{_hubUri.AbsoluteUri}]");

            _hubConnectionClient.Initialize(_service, 
                                            _startupStateService, 
                                            _runStateService,
                                            _userService);

             await CheckAuthenticationAndConnectHub();
        }

        public async Task RetryConnect()
        {
            if (_hasFatalError)
            {
                throw new InvalidOperationException("Cannot RetryConnection due to previous fatal error");
            }

            await CheckAuthenticationAndConnectHub();
        }

        public async Task RestartConnect()
        {
            _hubConnectionClient.OnRestart();

            await ConnectHub();
        }

        private async Task CheckAuthenticationAndConnectHub()
        {
            try
            {
                _hubConnectionClient.OnConnecting();

                LogError($"CheckAuthenticationAndConnectHub : IsAuthenticated [{_isAuthenticated}]");

                if (!_isAuthenticated)
                {
                    _isAuthenticated = await Authenticate(_authenticationUri);

                    if (!_isAuthenticated)
                    {
                        LogError("CheckAuthenticationAndConnectHub : Failed to Authenticate");

                        return;
                    }

                    HttpClientProxy = _authenticatedServiceClient.HttpClient;
                }

                if (!InitializeHub(_hubUri))
                {
                    LogError("CheckAuthenticationAndConnectHub : Failed to Initialize Hub Connection");

                    _hasFatalError = true;

                    return;
                }

                await ConnectHub();
            }
            catch (Exception ex)
            {
                _log.Error($"Unexpected error : {_service} : {ex.Message}");

                _hubConnectionClient.OnHttpUnexpectedError(ex.Message);

                _hasFatalError = true;
            }
        }

        private async Task<bool> Authenticate(Uri authenticationUri)
        {
            try
            {
                LogInfo("Authenticate : Connecting to Authenticated Service Client..");

                await _authenticatedServiceClient.Connect(authenticationUri);
            }
            catch (HttpRequestException ex)
            {
                OnHttpRequestException(ex);

                return false;
            }
            catch (AuthenticationException ex)
            {
                LogError($"Authenticate : AuthenticationException - {ex.Message}");

                _hubConnectionClient.OnSsoAuthenticationError();

                _hasFatalError = true;

                return false;
            }

            return true;
        }

        private bool InitializeHub(Uri hubUri)
        {
            try
            {
                LogInfo($"InitializeHub : {hubUri}");

                // hub connection client just acts as an event handler, routes events to startup or run state
                HubConnectionProxy = _hubConnectionService.Initialize(_authenticatedServiceClient,
                                                                      _hubConnectionClient,
                                                                      hubUri);
            }
            catch (InvalidOperationException ex)
            {
                LogError($"InitializeHub : InvalidOperationException - {ex.Message}");

                _hubConnectionClient.OnHubInitializeFailed();

                return false;
            }

            return true;
        }

        private async Task ConnectHub()
        {
            try
            {
                LogInfo("ConnectHub : Connecting...");

                await _hubConnectionService.Connect();
            }
            catch (HttpRequestException ex)
            {
                LogError($"ConnectHub : HttpRequestException - {ex.StatusCode} - {ex.Message}");

                OnHttpRequestException(ex);
            }
            catch (Exception ex)
            {
                _log.Error($"Unexpected error : {_service} : {ex.Message}");

                _hubConnectionClient.OnHttpUnexpectedError(ex.Message);

                _hasFatalError = true;
            }
        }

        private void OnHttpRequestException(HttpRequestException ex)
        {
            switch (ex.StatusCode)
            {
                case HttpStatusCode.ServiceUnavailable:
                    _hubConnectionClient.OnHttpServiceUnavailable();
                    break;
                case HttpStatusCode.Unauthorized:
                    _hubConnectionClient.OnHttpUnauthorized();
                    _hasFatalError = true;
                    break;
                default:
                    _hubConnectionClient.OnHttpUnexpectedError(ex.Message);
                    _hasFatalError = true;
                    break;
            }
        }

        #region Log

        private void LogInfo(string message)
        {
            Debug.WriteLine($"AuthenticatedHubConnectionService [{_service}]  {message}");
            _log.Info($"[{_service}] {message}");
        }

        private void LogError(string message)
        {
            Debug.WriteLine($"AuthenticatedHubConnectionService [{_service}]  {message}");
            _log.Error($"[{_service}] {message}");
        }

        #endregion

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public async ValueTask DisposeAsync()
        {
            if (_disposed)
            {
                return;
            }

            if (_hubConnectionService != null)
            {
                await _hubConnectionService.DisposeAsync().ConfigureAwait(false);
            }

            _disposables.Dispose();
            _authenticatedServiceClient.Dispose();

            Dispose(false);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
                _authenticatedServiceClient.Dispose();
            }

            _disposed = true;
        }
    }
}
