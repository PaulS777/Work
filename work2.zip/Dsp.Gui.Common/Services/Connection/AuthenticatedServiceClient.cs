﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services.Connection
{
    [ExcludeFromCodeCoverage]
    public sealed class AuthenticatedServiceClient : IAuthenticatedServiceClient
    {
        private readonly ILogger _log;
        private HttpClientHandler _clientHandler;
        private bool _disposed;

        public AuthenticatedServiceClient(ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);
        }

        [ExcludeFromCodeCoverage]
        ~AuthenticatedServiceClient()
        {
            Dispose(false);
        }

        public IHttpClientProxy HttpClient { get; private set; }
        public X509CertificateCollection Certificates => _clientHandler?.ClientCertificates;
        public CookieCollection Cookies => _clientHandler.CookieContainer.GetAllCookies();

        public async Task Connect(Uri baseAddress)
        {
            _clientHandler = new HttpClientHandler
                             {
                                 UseDefaultCredentials = true,
                                 AllowAutoRedirect = true
                             };

            var cert = GetUserCertificateForAuth();

            if (cert != null)
            {
                _clientHandler.ClientCertificates.Add(cert);
            }

            var httpClient = new HttpClient(_clientHandler, false);

            httpClient.BaseAddress = baseAddress;

            var httpResponseMessage = await httpClient.GetAsync("Login");

            if (!httpResponseMessage.IsSuccessStatusCode)
            {
                throw new HttpRequestException(httpResponseMessage.ReasonPhrase, null, httpResponseMessage.StatusCode);
            }

            HttpClient = new HttpClientProxy(httpClient);
        }

        private X509Certificate GetUserCertificateForAuth()
        {
            X509Store store = null;

            try
            {
                store = new X509Store(StoreName.My, StoreLocation.CurrentUser);

                store.Open(OpenFlags.OpenExistingOnly | OpenFlags.ReadOnly);

                _log.Info($"Finding Store Certificate for {Environment.UserName}");

                var cert = store.Certificates
                                .Find(X509FindType.FindBySubjectName, Environment.UserName, true)
                                .Find(X509FindType.FindByIssuerName, "Shell Information Technology International", true);

                if (cert.Count > 0)
                {
                    return cert[0];
                }

                _log.Info("User Certificate not found");

                foreach (var storeCertificate in store.Certificates)
                {
                    _log.Info($"Certificate : Subject [{storeCertificate.Subject}], Issuer [{storeCertificate.Issuer}]");
                }

                return null;
            }
            finally
            {
                store?.Close();
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                HttpClient?.HttpClient.Dispose();
                _clientHandler?.Dispose();
            }

            _disposed = true;
        }
    }
}