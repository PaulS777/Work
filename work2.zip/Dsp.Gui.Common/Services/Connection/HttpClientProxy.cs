﻿using System.Diagnostics.CodeAnalysis;
using System.Net.Http;

namespace Dsp.Gui.Common.Services.Connection
{
    [ExcludeFromCodeCoverage]
    public class HttpClientProxy : IHttpClientProxy
    {
        public HttpClientProxy(HttpClient httpClient)
        {
            HttpClient = httpClient;
        }

        public HttpClient HttpClient { get; }
    }
}
