﻿using System;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IAuthenticatedServiceClient : IDisposable
    {
        IHttpClientProxy HttpClient { get; }
        X509CertificateCollection Certificates { get; }
        CookieCollection Cookies { get; }
        Task Connect(Uri baseAddress);
    }
}
