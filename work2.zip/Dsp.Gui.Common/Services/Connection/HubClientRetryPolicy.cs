﻿using Microsoft.AspNetCore.SignalR.Client;
using System;
using System.Diagnostics;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services.Connection
{
    public sealed class HubClientRetryPolicy : IHubClientRetryPolicy
    {
        private readonly ILogger _log;
        private IHubConnectionClient _hubConnectionClient;
        private string _service;

        public HubClientRetryPolicy(ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);
        }

        public static int ShortIntervalRetryTimeSpanSeconds => 3;
        public static int LongIntervalRetryTimeSpanSeconds => 60;
        public static int ShortIntervalRetryCount => 20;
        public static int LongIntervalRetryCount => 30;

        public void Initialize(IHubConnectionClient client,
                               string service)
        {
            _hubConnectionClient = client;
            _service = service;
        }

        public TimeSpan? NextRetryDelay(RetryContext retryContext)
        {
            LogInfo($"NextRetryDelay : PreviousRetryCount = {retryContext.PreviousRetryCount}, " +
                    $"ElapsedTime = {retryContext.ElapsedTime}, " +
                    $"RetryReason = {retryContext.RetryReason?.Message}");

            if (retryContext.PreviousRetryCount <= ShortIntervalRetryCount)
            {
                if (retryContext.PreviousRetryCount == 0)
                {
                    _hubConnectionClient.OnRetryConnection();
                }

                return TimeSpan.FromSeconds(ShortIntervalRetryTimeSpanSeconds);
            }
            if (retryContext.PreviousRetryCount <= LongIntervalRetryCount)
            {
                return TimeSpan.FromSeconds(LongIntervalRetryTimeSpanSeconds);
            }

            LogInfo("NextRetryDelay : Terminating AutoReconnect...");

            return null;
        }

        private void LogInfo(string message)
        {
            Debug.WriteLine($"HubConnectionService :[{_service}] {message}");
            _log.Info($"[{_service}] {message}");
        }
    }
}
