﻿using System.Collections.Generic;

namespace Dsp.Gui.Common.Services.Connection
{
  
    public interface ICurvePublisherHubSubscriber
    {
        void AttachHubEvents(ICurvePublisherHubConnectionClient hubConnectionClient,
                             IHubConnectionProxy hubConnection);

        void SubscribePriceCurves(IList<int> curveIds);
        void UnsubscribePriceCurves(IList<int> curveIds);
        void SubscribeFxCurves(IList<int> curveIds);
        void UnsubscribeFxCurves(IList<int> curveIds);
    }
}
