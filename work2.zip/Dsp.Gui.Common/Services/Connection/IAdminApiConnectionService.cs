﻿using System;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.Gui.Common.Services.Connection.Publication;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IAdminApiConnectionService : IAsyncDisposable
    {
        Task Connect();
        Task RetryConnect();
        Task RestartConnect();
        IHttpClientProxy HttpClientProxy { get; }
        IHubConnectionProxy HubConnectionProxy { get; }
        IObservable<HubConnectionStartupArgs> StartupState { get; }
        IObservable<HubConnectionRunState> RunState { get; }
        IObservable<User> CurrentUser { get; }
        bool IsConnected { get; }
    }
}
