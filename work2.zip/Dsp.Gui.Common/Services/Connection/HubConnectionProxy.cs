﻿using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.SignalR.Client;

namespace Dsp.Gui.Common.Services.Connection
{
    [ExcludeFromCodeCoverage]
    public class HubConnectionProxy : IHubConnectionProxy
    {
        public HubConnectionProxy(HubConnection value)
        {
            Value = value;
        }

        public HubConnection Value { get; }

        public bool IsConnected => Value?.State == HubConnectionState.Connected;
    }
}
