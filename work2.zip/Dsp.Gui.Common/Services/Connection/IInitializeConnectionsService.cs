﻿
using System;
using System.Threading.Tasks;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IInitializeConnectionsService : IDisposable
    {
        void InitializeConnections();
        Task RetryConnect();
    }
}
