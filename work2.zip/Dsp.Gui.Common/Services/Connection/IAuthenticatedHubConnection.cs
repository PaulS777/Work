﻿using Dsp.Gui.Common.Services.Connection.Publication;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IAuthenticatedHubConnection
    {
        IHttpClientProxy HttpClientProxy { get; }
        IHubConnectionProxy HubConnectionProxy { get; }
        IHubConnectionStartupStatePublisher StartupStatePublisher { get; }
        IHubConnectionRunStatePublisher RunStatePublisher { get; }
        IHubConnectionUserPublisher UserPublisher { get; }
    }
}
