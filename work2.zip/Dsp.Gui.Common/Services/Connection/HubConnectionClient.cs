﻿using Dsp.DataContracts.WebApi;
using System;
using System.Diagnostics;
using Dsp.DataContracts;
using Dsp.ServiceContracts;
using Dsp.Gui.Common.Services.Connection.Publication;

namespace Dsp.Gui.Common.Services.Connection
{
    /// <summary>
    /// Provides a wrapper to the HubConnectionService (not testable due to HttpClient instance)
    /// Handles callbacks during Start and Run Phases
    /// Determines Connection State based upon Phase
    /// </summary>
    public sealed class HubConnectionClient : IHubConnectionClient
    {
        private readonly ILogger _log;

        private IHubConnectionStartupStateHandler _startupStateHandler;
        private IHubConnectionRunStateHandler _runStateHandler;
        private IHubConnectionUserHandler _userHandler;
        private bool _startupConnected;

        public HubConnectionClient(IHubClientRetryPolicy retryPolicy, 
                                   ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            RetryPolicy = retryPolicy;
        }

        public IHubClientRetryPolicy RetryPolicy { get; }

        public string Service { get; private set; }

        public void Initialize(string service,
                               IHubConnectionStartupStateHandler startupStateHandler, 
                               IHubConnectionRunStateHandler runStateHandler,
                               IHubConnectionUserHandler userHandler)
        {
            Service = service;
            _startupStateHandler = startupStateHandler;
            _runStateHandler = runStateHandler;
            _userHandler = userHandler;

            RetryPolicy.Initialize(this, Service);
        }

        public void OnApiConnectionStatus(ApiConnectionStatus status)
        {
            if (status == ApiConnectionStatus.Success)
            {
                LogInfo($"OnApiConnectionStatus : [{status}]");

                OnConnected();
            }
            else
            {
                var fatalError = GetFatalHubConnectionErrorFromApi(status);

                LogError($"OnApiConnectionStatus : [{status}] => Fatal Error [{fatalError}]");

                OnFatalError(fatalError);
            }
        }

        private void OnConnected()
        {
            LogInfo($"OnConnected : Previously Connected = {_startupConnected}");

            if (!_startupConnected)
            {
                _startupStateHandler.OnConnected();
                _runStateHandler.OnConnected();

                _startupConnected = true;
            }
            else
            {
                _runStateHandler.OnReconnected();
            }
        }

        private static FatalHubConnectionError GetFatalHubConnectionErrorFromApi(ApiConnectionStatus apiConnectionStatus)
        {
            switch (apiConnectionStatus)
            {
                case ApiConnectionStatus.AuthenticationFailure:
                    return FatalHubConnectionError.ApiAuthenticationFailed;
                case ApiConnectionStatus.ObsoleteClientFailure:
                    return FatalHubConnectionError.ObsoleteClient;
                case ApiConnectionStatus.ConnectionsExceededFailure:
                default:
                    return FatalHubConnectionError.ConnectionsExceeded;
            }
        }

        public void OnUser(User user)
        {
            LogInfo($"OnUser : {user?.UserName}");

            _userHandler.OnCurrentUser(user);
        }

        public void OnConnecting()
        {
            LogInfo("OnConnecting");

            _startupStateHandler.OnConnecting();
        }

        public void OnRetryConnection()
        {
            LogInfo("OnRetryConnection");

            _runStateHandler.OnReconnecting();
        }

        public void OnSsoAuthenticationError()
        {
            LogError("OnSsoAuthenticationError");

            OnFatalError(FatalHubConnectionError.SsoAuthenticationFailed);
        }

        public void OnHubInitializeFailed()
        {
            LogError("OnHubInitializeFailed");

            OnFatalError(FatalHubConnectionError.HubInitializeFailed);
        }

        public void OnReconnecting(Exception ex)
        {
            LogInfo($"OnReconnecting : {ex?.Message}");

            _runStateHandler.OnReconnecting();
        }

        public void OnHttpServiceUnavailable()
        {
            LogError("OnHttpServiceUnavailable");

            _startupStateHandler.OnHttpFailed();
            _runStateHandler.OnHttpFailed();
        }

        public void OnHttpUnauthorized()
        {
            LogError("OnHttpUnauthorized");

            OnFatalError(FatalHubConnectionError.AuthorizationFailed);
        }

        public void OnHttpUnexpectedError(string error)
        {
            LogError($"OnHttpUnexpectedError : {error}");

            OnFatalError(FatalHubConnectionError.UnexpectedError, error);
        }

        public void OnClosed(Exception exception)
        {
            LogInfo("OnClosed");

            _runStateHandler.OnClosed();
        }

        public void OnRestart()
        {
            LogInfo("OnRestart");

            _runStateHandler.OnReconnecting();
        }

        private void OnFatalError(FatalHubConnectionError error, string message=null)
        {
            if (error == FatalHubConnectionError.ConnectionsExceeded)
            {
                _runStateHandler.OnConnectionsExceeded();
            }
            else
            {
                _startupStateHandler.OnFatalError(error, message);
                _runStateHandler.OnStartupFailed();
            }
        }

        #region Log

        private void LogInfo(string message)
        {
            Debug.WriteLine($"HubConnectionClient [{Service}]  {message}");
            _log.Info($"[{Service}] {message}");
        }

        private void LogError(string message)
        {
            Debug.WriteLine($"HubConnectionClient [{Service}]  {message}");
            _log.Error($"[{Service}] {message}");
        }

        #endregion
    }
}
