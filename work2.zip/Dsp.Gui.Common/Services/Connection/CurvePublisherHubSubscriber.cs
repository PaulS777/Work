﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Dsp.DataContracts.Curve;
using Microsoft.AspNetCore.SignalR.Client;

namespace Dsp.Gui.Common.Services.Connection
{
    [ExcludeFromCodeCoverage]
    public class CurvePublisherHubSubscriber : ICurvePublisherHubSubscriber
    {
        private HubConnection _hubConnection;

        public void AttachHubEvents(ICurvePublisherHubConnectionClient hubConnectionClient,
                                    IHubConnectionProxy hubConnection)
        {
            ArgumentNullException.ThrowIfNull(hubConnectionClient);
            ArgumentNullException.ThrowIfNull(hubConnection);

            _hubConnection = hubConnection.Value;

            _hubConnection.On<IList<PriceCurve>>("HandlePriceCurvesSnapshot", hubConnectionClient.OnPriceCurvesSnapshot);
            _hubConnection.On<PriceCurve>("HandlePriceCurveNotification", hubConnectionClient.OnPriceCurveNotification);
            _hubConnection.On<IList<FxPriceCurve>>("HandleFxCurvesSnapshot", hubConnectionClient.OnFxCurvesSnapshot);
            _hubConnection.On<FxPriceCurve>("HandleFxCurveNotification", hubConnectionClient.OnFxCurveNotification);
        }

        public async void SubscribePriceCurves(IList<int> curveIds)
        {
            await _hubConnection.SendAsync("SubscribeToPriceCurves", curveIds).ConfigureAwait(false);
        }

        public async void UnsubscribePriceCurves(IList<int> curveIds)
        {
            await _hubConnection.SendAsync("UnsubscribeFromPriceCurves", curveIds).ConfigureAwait(false);
        }

        public async void SubscribeFxCurves(IList<int> curveIds)
        {
            await _hubConnection.SendAsync("SubscribeToFxCurves", curveIds).ConfigureAwait(false);
        }

        public async void UnsubscribeFxCurves(IList<int> curveIds)
        {
            await _hubConnection.SendAsync("UnsubscribeFromFxCurves", curveIds).ConfigureAwait(false);
        }
    }
}
