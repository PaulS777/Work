﻿using Microsoft.AspNetCore.SignalR.Client;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IHubConnectionProxy
    {
        HubConnection Value { get; }
        bool IsConnected { get; }
    }
}
