﻿using System;
using Dsp.DataContracts;
using Dsp.DataContracts.WebApi;
using Dsp.Gui.Common.Services.Connection.Publication;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IHubConnectionClient
    {
        IHubClientRetryPolicy RetryPolicy { get; }
        string Service { get; }

        void Initialize(string service,
                        IHubConnectionStartupStateHandler startupStateHandler,
                        IHubConnectionRunStateHandler runStateHandler,
                        IHubConnectionUserHandler userHandler);

        void OnApiConnectionStatus(ApiConnectionStatus status);
        void OnUser(User user);
        void OnConnecting();
        void OnReconnecting(Exception ex);
        void OnRetryConnection();
        void OnSsoAuthenticationError();
        void OnHubInitializeFailed();
        void OnHttpServiceUnavailable();
        void OnHttpUnauthorized();
        void OnHttpUnexpectedError(string error);
        void OnClosed(Exception exception);
        void OnRestart();
    }
}
