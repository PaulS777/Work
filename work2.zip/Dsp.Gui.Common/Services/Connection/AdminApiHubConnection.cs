﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Configuration;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;
using Microsoft.AspNetCore.SignalR.Client;

namespace Dsp.Gui.Common.Services.Connection
{
    [ExcludeFromCodeCoverage]
    public class AdminApiHubConnection : IAdminApiHubConnection
    {
        private IHubConnectionProxyClient _hubConnectionProxyClient;
        private HubConnection _hubConnection;

        public void AttachHubEvents(IHubConnectionProxyClient hubConnectionProxyClient,
                                    IHubConnectionProxy hubConnection)
        {
            ArgumentNullException.ThrowIfNull(hubConnection);

            _hubConnectionProxyClient = hubConnectionProxyClient;
            _hubConnection = hubConnection.Value;

            _hubConnection.On<IEnumerable<PriceCurveSetting>, IEnumerable<PriceCurvePremium>, IEnumerable<PublisherTenorPremium>, string>
                ("HandlePriceCurveSnapshotNotification", HandlePriceCurveSnapshotNotification);
            _hubConnection.On<PriceCurveSetting, string>("HandlePriceCurveSettingNotification", HandlePriceCurveSettingNotification);
            _hubConnection.On<PriceCurvePremium, string>("HandlePriceCurvePremiumNotification", HandlePriceCurvePremiumNotification);
            _hubConnection.On<IEnumerable<PublisherTenorPremium>, string>("HandlePublisherTenorPremiumsSnapshot", HandlePublisherTenorPremiumsSnapshot);
            _hubConnection.On<PublisherTenorPremium, string>("HandlePublisherTenorPremiumNotification", HandlePublisherTenorPremiumNotification);
            _hubConnection.On<IEnumerable<PriceCurveDefinition>, string>("HandlePriceCurveDefinitionsSnapshot", HandlePriceCurveDefinitionsSnapshot);
            _hubConnection.On<IEnumerable<PriceCurveDefinition>, string>("HandlePriceCurveDefinitionsNotification", HandlePriceCurveDefinitionsNotification);
            _hubConnection.On<IEnumerable<DerivedCurveDefinition>, string>("HandleDerivedCurveDefinitionsSnapshot", HandleDerivedCurveDefinitionsSnapshot);
            _hubConnection.On<IEnumerable<DerivedCurveDefinition>, string>("HandleDerivedCurveDefinitionsNotification", HandleDerivedCurveDefinitionsNotification);
            _hubConnection.On<IEnumerable<User>, string>("HandleUsersSnapshot", HandleUsersSnapshot);
            _hubConnection.On<IEnumerable<User>, string>("HandleUsersNotification", HandleUsersNotification);
            _hubConnection.On<IEnumerable<FxCurveDefinition>, string>("HandleFxCurveDefinitionsSnapshot", HandleFxCurveDefinitionsSnapshot);
            _hubConnection.On<IEnumerable<FxCurveDefinition>, string>("HandleFxCurveDefinitionsNotification", HandleFxCurveDefinitionsNotification);
            _hubConnection.On<FxCurveSetting, string>("HandleFxCurveSettingNotification", HandleFxCurveSettingNotification);
            _hubConnection.On<FxCurvePipsBuffer, string>("HandleFxCurvePipsBufferNotification", HandleFxCurvePipsBufferNotification);
            _hubConnection.On<IEnumerable<FxCurveSetting>, IEnumerable<FxCurvePipsBuffer>, string>("HandleFxCurveSnapshotNotification", HandleFxCurveSnapshotNotification);
            _hubConnection.On<IEnumerable<ChatUser>, string>("HandleChatUsersSnapshot", HandleChatUsersSnapshot);
            _hubConnection.On<IEnumerable<ChatUser>, string>("HandleChatUsersNotification", HandleChatUsersNotification);
            _hubConnection.On<IEnumerable<ChatMarket>, string>("HandleChatMarketsSnapshot", HandleChatMarketsSnapshot);
            _hubConnection.On<IEnumerable<ChatMarket>, string>("HandleChatMarketsNotification", HandleChatMarketsNotification);
            _hubConnection.On<IEnumerable<ChatMessageHistory>, string>("HandleChatMessageHistorySnapshot", HandleChatMessageHistorySnapshot);
            _hubConnection.On<IEnumerable<ChatMessageHistory>, string>("HandleChatMessageHistoryNotification", HandleChatMessageHistoryNotification);
            _hubConnection.On<IEnumerable<ChatIceMap>, string>("HandleChatIceMapSnapshot", HandleChatIceMapSnapshot);
            _hubConnection.On<IEnumerable<ChatIceMap>, string>("HandleChatIceMapNotification", HandleChatIceMapNotification);
            _hubConnection.On<IEnumerable<ChatVariableShortcut>, string>("HandleChatVariableShortcutSnapshot", HandleChatVariableShortcutSnapshot);
            _hubConnection.On<IEnumerable<ChatVariableShortcut>, string>("HandleChatVariableShortcutNotification", HandleChatVariableShortcutNotification);
            _hubConnection.On<IEnumerable<ChatPriceSummary>, string>("HandleChatPriceSummarySnapshot", HandleChatPriceSummarySnapshot);
            _hubConnection.On<IEnumerable<ChatPriceSummary>, string>("HandleChatPriceSummaryNotification", HandleChatPriceSummaryNotification);
            _hubConnection.On<IEnumerable<Calendar>, string>("HandleCalendarSnapshot", HandleCalendarSnapshot);
            _hubConnection.On<IEnumerable<Calendar>, string>("HandleCalendarNotification", HandleCalendarNotification);
            _hubConnection.On<IEnumerable<MonthEndRollStatus>, string>("HandleMonthEndRollStatusSnapshot", HandleMonthEndRollStatusSnapshot);
            _hubConnection.On<IEnumerable<MonthEndRollStatus>, string>("HandleMonthEndRollStatusNotification", HandleMonthEndRollStatusNotification);
            _hubConnection.On<IEnumerable<DynamicConfiguration>, string>("HandleConfigurationSnapshot", HandleConfigurationSnapshot);
            _hubConnection.On<IEnumerable<DynamicConfiguration>, string>("HandleConfigurationNotification", HandleConfigurationNotification);
            _hubConnection.On<IEnumerable<ServiceStatusNotification>, string>("HandleServiceStatusNotificationSnapshot", HandleServiceStatusNotificationSnapshot);
            _hubConnection.On<IEnumerable<ServiceStatusNotification>, string>("HandleServiceStatusNotification", HandleServiceStatusNotification);
            _hubConnection.On<SystemDate, string>("HandleSystemDateSnapshot", HandleSystemDateSnapshot);
            _hubConnection.On<SystemDate, string>("HandleSystemDateNotification", HandleSystemDateNotification);
            _hubConnection.On<IEnumerable<ProductDefinition>, string>("HandleProductDefinitionSnapshot", HandleProductDefinitionsSnapshot);
            _hubConnection.On<IEnumerable<ProductDefinition>, string>("HandleProductDefinitionNotifications", HandleProductDefinitionsNotifications);
            _hubConnection.On<IEnumerable<CurrencyCode>, string>("HandleCurrencyCodeSnapshot", HandleCurrencyCodeSnapshot);
            _hubConnection.On<IEnumerable<CurrencyCode>, string>("HandleCurrencyCodeNotification", HandleCurrencyCodeNotification);
            _hubConnection.On<IEnumerable<CurveGroup>, string>("HandleCurveGroupSnapshot", HandleCurveGroupSnapshot);
            _hubConnection.On<IEnumerable<CurveGroup>, string>("HandleCurveGroupNotification", HandleCurveGroupNotification);
		}

        public Task SubscribeUsers() => _hubConnection?.SendAsync("SubscribeUsers");
        public Task UnsubscribeUsers() => _hubConnection?.SendAsync("UnsubscribeUsers");
        public Task SubscribePriceCurveDefinitions() => _hubConnection?.SendAsync("SubscribePriceCurveDefinitions");
        public Task UnsubscribePriceCurveDefinitions() => _hubConnection?.SendAsync("UnsubscribePriceCurveDefinitions");
        public Task SubscribeDerivedCurveDefinitions() => _hubConnection?.SendAsync("SubscribeDerivedCurveDefinitions");
        public Task UnsubscribeDerivedCurveDefinitions() => _hubConnection?.SendAsync("UnsubscribeDerivedCurveDefinitions");
        public Task SubscribeCurvePublishers() => _hubConnection?.SendAsync("SubscribeCurvePublishers");
        public Task UnsubscribeCurvePublishers() => _hubConnection?.SendAsync("UnsubscribeCurvePublishers");
        public Task SubscribePriceCurves(IEnumerable<int> curveIds) => _hubConnection?.SendAsync("SubscribePriceCurves", curveIds);
        public Task UnsubscribePriceCurves(IEnumerable<int> curveIds) => _hubConnection?.SendAsync("UnsubscribePriceCurves", curveIds);
        public Task SubscribeFxCurveDefinitions() => _hubConnection?.SendAsync("SubscribeFxCurveDefinitions");
        public Task UnsubscribeFxCurveDefinitions() => _hubConnection?.SendAsync("UnsubscribeFxCurveDefinitions");
        public Task SubscribeFxCurves(IEnumerable<int> curveIds) => _hubConnection?.SendAsync("SubscribeFxCurves", curveIds);
        public Task UnsubscribeFxCurves(IEnumerable<int> curveIds) => _hubConnection?.SendAsync("UnsubscribeFxCurves", curveIds);
        public Task SubscribeChatUsers() => _hubConnection?.SendAsync("SubscribeChatUsers");
        public Task UnsubscribeChatUsers() => _hubConnection?.SendAsync("UnsubscribeChatUsers");
        public Task SubscribeChatMarkets() => _hubConnection?.SendAsync("SubscribeChatMarkets");
        public Task UnsubscribeChatMarkets() => _hubConnection?.SendAsync("UnsubscribeChatMarkets");
        public Task SubscribeChatMessageHistory() => _hubConnection?.SendAsync("SubscribeChatMessageHistory");
        public Task UnsubscribeChatMessageHistory() => _hubConnection?.SendAsync("UnsubscribeChatMessageHistory");
        public Task SubscribeChatIceMap() => _hubConnection?.SendAsync("SubscribeChatIceMap");
        public Task UnsubscribeChatIceMap() => _hubConnection?.SendAsync("UnsubscribeChatIceMap");
        public Task SubscribeChatPriceSummary() => _hubConnection?.SendAsync("SubscribeChatPriceSummary");
        public Task UnsubscribeChatPriceSummary() => _hubConnection?.SendAsync("UnsubscribeChatPriceSummary");
        public Task SubscribeServiceStatusNotification() => _hubConnection?.SendAsync("SubscribeServiceStatusNotification");
        public Task UnsubscribeServiceStatusNotification() => _hubConnection?.SendAsync("UnsubscribeServiceStatusNotification");
        public Task SubscribeChatVariableShortcut() => _hubConnection?.SendAsync("SubscribeChatVariableShortcut");
        public Task UnsubscribeChatVariableShortcut() => _hubConnection?.SendAsync("UnsubscribeChatVariableShortcut");
        public Task SubscribeCalendars() => _hubConnection?.SendAsync("SubscribeCalendars");
        public Task UnsubscribeCalendars() => _hubConnection?.SendAsync("UnsubscribeCalendars");
        public Task SubscribeMonthEndRollStatus() => _hubConnection?.SendAsync("SubscribeMonthEndRollStatus");
        public Task UnsubscribeMonthEndRollStatus() => _hubConnection?.SendAsync("UnsubscribeMonthEndRollStatus");
        public Task SubscribeSystemDate() => _hubConnection?.SendAsync("SubscribeSystemDate");
        public Task UnsubscribeSystemDate() => _hubConnection?.SendAsync("UnsubscribeSystemDate");
        public Task SubscribeProductDefinitions() => _hubConnection?.SendAsync("SubscribeProductDefinitions");
        public Task UnsubscribeProductDefinitions() => _hubConnection?.SendAsync("UnsubscribeProductDefinitions");
        public Task SubscribeCurrencyCodes() => _hubConnection?.SendAsync("SubscribeCurrencyCodes");
        public Task UnsubscribeCurrencyCodes() => _hubConnection?.SendAsync("UnsubscribeCurrencyCodes");
        public Task SubscribeCurveGroups() => _hubConnection?.SendAsync("SubscribeCurveGroups");
        public Task UnsubscribeCurveGroups() => _hubConnection?.SendAsync("UnsubscribeCurveGroups");
		public Task SubscribeConfiguration() => _hubConnection?.SendAsync("SubscribeConfiguration");
        public Task UnsubscribeConfiguration() => _hubConnection?.SendAsync("UnsubscribeConfiguration");

        public void HandlePriceCurveSnapshotNotification(IEnumerable<PriceCurveSetting> curveSettings,
                                                         IEnumerable<PriceCurvePremium> priceCurvePremiums,
                                                         IEnumerable<PublisherTenorPremium> publisherTenorPremiums, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnPriceCurveSnapshotNotification(curveSettings?.ToList(),
                                                                       priceCurvePremiums?.ToList(),
                                                                       publisherTenorPremiums.ToList());
        }

        public void HandlePriceCurveSettingNotification(PriceCurveSetting model, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnPriceCurveSettingNotification(model);
        }

        public void HandlePublisherTenorPremiumNotification(PublisherTenorPremium model, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnPublisherTenorPremiumNotification(model);
        }

        public void HandlePublisherTenorPremiumsSnapshot(IEnumerable<PublisherTenorPremium> premiums, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnPublisherTenorPremiumsSnapshot(premiums?.ToList());
        }

        public void HandleUsersSnapshot(IEnumerable<User> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnUsersSnapshot(models?.ToList());
        }

        public void HandleUsersNotification(IEnumerable<User> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnUsersNotification(models?.ToList());
        }

        public void HandleSystemDateSnapshot(SystemDate systemDate, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnSystemDateSnapshot(systemDate);
        }

        public void HandleSystemDateNotification(SystemDate systemDate, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnSystemDateNotification(systemDate);
        }

        public void HandlePriceCurveDefinitionsSnapshot(IEnumerable<PriceCurveDefinition> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnPriceCurveDefinitionsSnapshot(models?.ToList());
        }

        public void HandlePriceCurveDefinitionsNotification(IEnumerable<PriceCurveDefinition> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnPriceCurveDefinitionsNotification(models?.ToList());
        }

        public void HandlePriceCurvePremiumNotification(PriceCurvePremium model, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnPriceCurvePremiumNotification(model);
        }

        public void HandleDerivedCurveDefinitionsSnapshot(IEnumerable<DerivedCurveDefinition> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnDerivedCurveDefinitionsSnapshot(models?.ToList());
        }

        public void HandleDerivedCurveDefinitionsNotification(IEnumerable<DerivedCurveDefinition> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnDerivedCurveDefinitionsNotification(models?.ToList());
        }

        public void HandleFxCurveDefinitionsSnapshot(IEnumerable<FxCurveDefinition> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnFxCurveDefinitionSnapshot(models?.ToList());
        }

        public void HandleFxCurveDefinitionsNotification(IEnumerable<FxCurveDefinition> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnFxCurveDefinitionNotification(models?.ToList());
        }

		public void HandleFxCurveSettingNotification(FxCurveSetting model, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnFxCurveSettingsSnapshot(model);
        }

        public void HandleFxCurvePipsBufferNotification(FxCurvePipsBuffer model, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnFxCurvePipsBufferSnapshot(model);
        }

        public void HandleFxCurveSnapshotNotification(IEnumerable<FxCurveSetting> curveSettings, IEnumerable<FxCurvePipsBuffer> curvePips, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnFxCurvePipsBufferSnapshot(curvePips?.ToList());
            _hubConnectionProxyClient.OnFxCurveSettingsSnapshot(curveSettings?.ToList());
        }

        public void HandleChatUsersSnapshot(IEnumerable<ChatUser> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatUsersSnapshot(models.ToList());
        }

        public void HandleChatUsersNotification(IEnumerable<ChatUser> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatUsersNotification(models.ToList());
        }

        public void HandleChatMarketsSnapshot(IEnumerable<ChatMarket> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatMarketsNotification(models.ToList());
        }

        public void HandleChatMarketsNotification(IEnumerable<ChatMarket> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            HandleChatMarketsSnapshot(models, correlationId);
        }

        public void HandleChatMessageHistorySnapshot(IEnumerable<ChatMessageHistory> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatMessagesSnapshot(models.ToList());
        }

        public void HandleChatMessageHistoryNotification(IEnumerable<ChatMessageHistory> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatMessagesNotification(models.ToList());
        }

        public void HandleChatIceMapSnapshot(IEnumerable<ChatIceMap> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatIceMapSnapshot(models.ToList());
        }

        public void HandleChatIceMapNotification(IEnumerable<ChatIceMap> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatIceMapNotification(models.ToList());
        }

        public void HandleChatPriceSummarySnapshot(IEnumerable<ChatPriceSummary> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatPriceSummarySnapshot(models.ToList());
        }

        public void HandleChatPriceSummaryNotification(IEnumerable<ChatPriceSummary> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatPriceSummaryNotification(models.ToList());
        }

        public void HandleServiceStatusNotificationSnapshot(IEnumerable<ServiceStatusNotification> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnServiceStatusNotificationSnapshot(models.ToList());
        }

        public void HandleServiceStatusNotification(IEnumerable<ServiceStatusNotification> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnServiceStatusNotificationNotification(models.ToList());
        }

        public void HandleCalendarSnapshot(IEnumerable<Calendar> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnCalendarSnapshot(models.ToList());
        }

        public void HandleCalendarNotification(IEnumerable<Calendar> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnCalendarNotification(models.ToList());
        }

        public void HandleChatVariableShortcutSnapshot(IEnumerable<ChatVariableShortcut> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatVariableShortcutSnapshot(models.ToList());
        }

        public void HandleChatVariableShortcutNotification(IEnumerable<ChatVariableShortcut> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnChatVariableShortcutNotification(models.ToList());
        }

        public void HandleMonthEndRollStatusSnapshot(IEnumerable<MonthEndRollStatus> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnMonthEndRollStatusSnapshot(models.ToList());
        }

        public void HandleMonthEndRollStatusNotification(IEnumerable<MonthEndRollStatus> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnMonthEndRollStatusNotification(models.ToList());
        }

        public void HandleConfigurationSnapshot(IEnumerable<DynamicConfiguration> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnConfigurationSnapshot(models.ToList());
        }

        public void HandleConfigurationNotification(IEnumerable<DynamicConfiguration> models, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnConfigurationNotification(models.ToList());
        }

        public void HandleProductDefinitionsSnapshot(IEnumerable<ProductDefinition> productDefinitions, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnProductDefinitionsSnapshot(productDefinitions.ToList());
        }

        public void HandleProductDefinitionsNotifications(IEnumerable<ProductDefinition> productDefinitions, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnProductDefinitionsNotifications(productDefinitions.ToList());
        }

        public void HandleCurrencyCodeSnapshot(IEnumerable<CurrencyCode> currencyCodes, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnCurrencyCodesSnapshot(currencyCodes.ToList());
        }

        public void HandleCurrencyCodeNotification(IEnumerable<CurrencyCode> currencyCodes, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnCurrencyCodesNotifications(currencyCodes.ToList());
        }

        public void HandleCurveGroupSnapshot(IEnumerable<CurveGroup> curveGroups, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnCurveGroupsSnapshot(curveGroups.ToList());
        }

        public void HandleCurveGroupNotification(IEnumerable<CurveGroup> curveGroups, string correlationId)
        {
            Logger.SetCorrelationIdS(correlationId);
            _hubConnectionProxyClient.OnCurveGroupsNotifications(curveGroups.ToList());
        }
	}
}
