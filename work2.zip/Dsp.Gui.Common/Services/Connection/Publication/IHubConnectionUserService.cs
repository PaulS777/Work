﻿namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public interface IHubConnectionUserService : IHubConnectionUserHandler,
                                                 IHubConnectionUserPublisher
    {
    }
}
