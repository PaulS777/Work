﻿using System;

namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public enum HubConnectionRunState
    {
        NotSet,
        FailedStartup,
        HttpFailed,
        Connected,
        Reconnecting,
        Reconnected,
        Closed,
        ConnectionsExceeded
    }

    public interface IHubConnectionRunStatePublisher : IDisposable
    {
        IObservable<HubConnectionRunState> RunState { get; }
    }
}
