﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts;

namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public sealed class HubConnectionUserService : IHubConnectionUserService
    {
        private readonly BehaviorSubject<User> _currentUser = new(null);
        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~HubConnectionUserService()
        {
            Dispose(false);
        }

        public IObservable<User> CurrentUser => _currentUser.AsObservable();

        public void OnCurrentUser(User user)
        {
            _currentUser.OnNext(user);
        }

        public void Dispose()
        {
            Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _currentUser.Dispose();
            }

            _disposed = true;
        }
    }
}
