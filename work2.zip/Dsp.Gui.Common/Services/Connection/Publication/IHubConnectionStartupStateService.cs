﻿namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public interface IHubConnectionStartupStateService : IHubConnectionStartupStateHandler,
                                                         IHubConnectionStartupStatePublisher
    {
    }
}
