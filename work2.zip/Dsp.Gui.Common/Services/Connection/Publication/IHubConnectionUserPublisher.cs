﻿using System;
using Dsp.DataContracts;

namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public interface IHubConnectionUserPublisher : IDisposable
    {
        IObservable<User> CurrentUser { get; }
    }
}
