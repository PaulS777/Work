﻿namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public interface IHubConnectionRunStateHandler
    {
        void OnStartupFailed();
        void OnConnected();
        void OnReconnected();
        void OnReconnecting();
        void OnHttpFailed();
        void OnConnectionsExceeded();
        void OnClosed();
    }
}
