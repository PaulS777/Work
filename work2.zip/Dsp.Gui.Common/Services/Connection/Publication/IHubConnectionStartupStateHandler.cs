﻿namespace Dsp.Gui.Common.Services.Connection.Publication
{

    public interface IHubConnectionStartupStateHandler
    {
        void OnConnecting();
        void OnConnected();
        void OnFatalError(FatalHubConnectionError error, string message);
        void OnHttpFailed();
    }
}
