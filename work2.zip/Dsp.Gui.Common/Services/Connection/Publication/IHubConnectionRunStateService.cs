﻿namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public interface IHubConnectionRunStateService : IHubConnectionRunStateHandler,
                                                     IHubConnectionRunStatePublisher
    {
    }
}
