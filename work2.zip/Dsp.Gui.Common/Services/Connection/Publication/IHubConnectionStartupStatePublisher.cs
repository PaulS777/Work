﻿using System;

namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public interface IHubConnectionStartupStatePublisher : IDisposable
    {
        IObservable<HubConnectionStartupArgs> StartupState { get; }
    }
}
