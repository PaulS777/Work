﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;
using System.Reactive.Subjects;

namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public sealed class HubConnectionStartupStateService : IHubConnectionStartupStateService
    {
        private readonly BehaviorSubject<HubConnectionStartupArgs> _startupState = new(null);

        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~HubConnectionStartupStateService()
        {
            Dispose(false);
        }

        public IObservable<HubConnectionStartupArgs> StartupState => _startupState.AsObservable();

        public void OnHttpFailed()
        {
            _startupState.OnNext(new HubConnectionStartupArgs(HubConnectingState.HttpFailed));
        }

        public void OnFatalError(FatalHubConnectionError error, string message)
        {
            _startupState.OnNext(new HubConnectionStartupArgs(error, message));
        }

        public void OnConnecting()
        {
            _startupState.OnNext(new HubConnectionStartupArgs(HubConnectingState.Connecting));
        }

        public void OnConnected()
        {
            _startupState.OnNext(new HubConnectionStartupArgs(HubConnectingState.Connected));
        }

        public void Dispose()
        {
            Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _startupState.Dispose();
            }

            _disposed = true;
        }
    }
}
