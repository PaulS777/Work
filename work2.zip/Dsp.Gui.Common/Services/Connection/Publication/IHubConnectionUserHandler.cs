﻿using Dsp.DataContracts;

namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public interface IHubConnectionUserHandler
    {
        void OnCurrentUser(User user);
    }
}
