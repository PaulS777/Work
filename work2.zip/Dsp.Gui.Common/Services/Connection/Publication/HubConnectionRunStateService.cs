﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;
using System.Reactive.Subjects;

namespace Dsp.Gui.Common.Services.Connection.Publication
{
    public sealed class HubConnectionRunStateService : IHubConnectionRunStateService
    {
        private readonly BehaviorSubject<HubConnectionRunState> _runState = new(HubConnectionRunState.NotSet);

        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~HubConnectionRunStateService()
        {
            Dispose(false);
        }

        public IObservable<HubConnectionRunState> RunState => _runState.AsObservable();

        public void OnStartupFailed()
        {
            _runState.OnNext(HubConnectionRunState.FailedStartup);
        }

        public void OnConnected()
        {
            _runState.OnNext(HubConnectionRunState.Connected);
        }

        public void OnReconnecting()
        {
            _runState.OnNext(HubConnectionRunState.Reconnecting);
        }

        public void OnHttpFailed()
        {
            _runState.OnNext(HubConnectionRunState.HttpFailed);
        }

        public void OnConnectionsExceeded()
        {
            _runState.OnNext(HubConnectionRunState.ConnectionsExceeded);
        }

        public void OnClosed()
        {
            _runState.OnNext(HubConnectionRunState.Closed);
        }

        public void OnReconnected()
        {
            _runState.OnNext(HubConnectionRunState.Reconnected);
        }

        public void Dispose()
        {
            Dispose(true);

            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _runState.Dispose();
            }

            _disposed = true;
        }
    }
}
