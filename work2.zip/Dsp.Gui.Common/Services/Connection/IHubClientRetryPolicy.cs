﻿using Microsoft.AspNetCore.SignalR.Client;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IHubClientRetryPolicy : IRetryPolicy
    {
        void Initialize(IHubConnectionClient client, string service);
    }
}
