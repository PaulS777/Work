﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IAdminApiHubConnection
    {
        void AttachHubEvents(IHubConnectionProxyClient hubConnectionProxyClient,
                             IHubConnectionProxy hubConnection);

        Task SubscribePriceCurveDefinitions();
        Task UnsubscribePriceCurveDefinitions();
        Task SubscribeFxCurveDefinitions();
        Task UnsubscribeFxCurveDefinitions();
        Task SubscribeDerivedCurveDefinitions();
        Task UnsubscribeDerivedCurveDefinitions();
        Task SubscribeUsers();
        Task UnsubscribeUsers();
        Task SubscribeCurvePublishers();
        Task UnsubscribeCurvePublishers();
        Task SubscribePriceCurves(IEnumerable<int> curveIds);
        Task UnsubscribePriceCurves(IEnumerable<int> curveIds);
        Task SubscribeFxCurves(IEnumerable<int> curveIds);
        Task UnsubscribeFxCurves(IEnumerable<int> curveIds);
        Task SubscribeChatUsers();
        Task UnsubscribeChatUsers();
        Task SubscribeChatMarkets();
        Task UnsubscribeChatMarkets();
        Task SubscribeChatMessageHistory();
        Task UnsubscribeChatMessageHistory();
        Task SubscribeChatVariableShortcut();
        Task UnsubscribeChatVariableShortcut();
        Task SubscribeChatIceMap();
        Task UnsubscribeChatIceMap();
        Task SubscribeChatPriceSummary();
        Task UnsubscribeChatPriceSummary();
        Task SubscribeServiceStatusNotification();
        Task UnsubscribeServiceStatusNotification();
        Task SubscribeCalendars();
        Task UnsubscribeCalendars();
        Task SubscribeMonthEndRollStatus();
        Task UnsubscribeMonthEndRollStatus();
        Task SubscribeConfiguration();
        Task UnsubscribeConfiguration();
        Task SubscribeSystemDate();
        Task UnsubscribeSystemDate();
        Task SubscribeProductDefinitions();
        Task UnsubscribeProductDefinitions();
        Task SubscribeCurrencyCodes();
        Task UnsubscribeCurrencyCodes();
        Task SubscribeCurveGroups();
        Task UnsubscribeCurveGroups();
    }
}
