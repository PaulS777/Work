﻿using System;
using System.Threading.Tasks;

namespace Dsp.Gui.Common.Services.Connection
{
    public interface IHubConnectionService : IAsyncDisposable
    {
        IHubConnectionProxy Initialize(IAuthenticatedServiceClient authorisedServiceClient,
                                       IHubConnectionClient hubConnectionClient,
                                       Uri hubUri);

        Task Connect();
    }
}
