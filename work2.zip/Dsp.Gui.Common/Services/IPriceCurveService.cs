﻿using System.Collections.Generic;
using Dsp.Gui.Common.Services.Connection;

namespace Dsp.Gui.Common.Services
{
    public interface IPriceCurveService : ICurvePublisherHubConnectionClient
    {
        void SubscribeToPriceCurves(IList<int> curveIds);
        void UnsubscribeFromPriceCurves(IList<int> curveIds);
        void SubscribeToFxCurves(IList<int> curveIds);
        void UnsubscribeFromFxCurves(IList<int> curveIds);
    }
}
