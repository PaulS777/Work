﻿using System;

namespace Dsp.Gui.Common.Services
{
    public interface ISystemDateProvider : IDisposable
    {
        IObservable<DateTime?> SystemDate { get; }
    }
}
