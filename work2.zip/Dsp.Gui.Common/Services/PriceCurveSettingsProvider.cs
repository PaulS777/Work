﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    public sealed class PriceCurveSettingsProvider : IPriceCurveSettingsProvider
    {
        private readonly Dictionary<int, PriceCurveSetting> _priceCurveSettings = new();
        private readonly BehaviorSubject<Dictionary<int, PriceCurveSetting>> _priceCurveSettingsSubject = new(null);
        private readonly ILogger _log;
        private readonly IDisposable _disposable;
        private readonly object _synch = new();
        private bool _disposed;

        public PriceCurveSettingsProvider(ICurveControlService curveControlService,
                                          ISchedulerProvider schedulerProvider,
                                          ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _disposable = curveControlService.PriceCurveSettings
                                             .Buffer(TimeSpan.FromMilliseconds(1000), schedulerProvider.TaskPool)
                                             .Where(items => items != null)
                                             .Select(items => items.Where(i => i != null)
                                                                   .SelectMany(i => i))
                                             .Where(settings => settings.Any())
                                             .Subscribe(OnPriceCurveSettings);
        }

        [ExcludeFromCodeCoverage]
        ~PriceCurveSettingsProvider()
        {
            Dispose(false);
        }

        public IObservable<Dictionary<int, PriceCurveSetting>> PriceCurveSettings => _priceCurveSettingsSubject.AsObservable();

        private void OnPriceCurveSettings(IEnumerable<PriceCurveSetting> priceCurveSettings)
        {
            lock (_synch)
            {
                foreach (var priceCurveSetting in priceCurveSettings)
                {
                    _priceCurveSettings[priceCurveSetting.PriceCurveDefinitionId] = priceCurveSetting;
                }

                _log.Info($"Price Curve Settings Updated : {_priceCurveSettings.Count}");
                _priceCurveSettingsSubject.OnNext(_priceCurveSettings);
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposable.Dispose();
            }

            _disposed = true;
        }
    }
}
