﻿using System;

namespace Dsp.Gui.Common.Services
{
    public interface ICurveSettingsService : IDisposable
    {
        void Initialize();
    }
}
