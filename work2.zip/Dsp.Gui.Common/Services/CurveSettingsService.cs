﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Extensions;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    /// <summary>
    /// Responsible for loading Price Curve Settings
    /// </summary>                                                  
    public sealed class CurveSettingsService : ICurveSettingsService
    {
        private readonly ICurveControlService _curveControlService;
        private readonly ISchedulerProvider _schedulerProvider;
        private readonly CompositeDisposable _disposables = new();
        private readonly ILogger _log;
        private bool _disposed;

        public CurveSettingsService(ICurveControlService curveControlService,
                                    ISchedulerProvider schedulerProvider,
                                    ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);
            _curveControlService = curveControlService;
            _schedulerProvider = schedulerProvider; 
        }

        [ExcludeFromCodeCoverage]
        ~CurveSettingsService()
        {
            Dispose(false);
        }

        public void Initialize()
        {
            _curveControlService.PriceCurveDefinitions
                                .Where(c => c != null && c.Any())
                                .ObserveOn(_schedulerProvider.TaskPool)
                                .Subscribe(OnPriceCurveDefinitionsLoaded)
                                .AddTo(_disposables);

            _curveControlService.FxCurveDefinitions
                                .Where(c => c != null && c.Any())
                                .ObserveOn(_schedulerProvider.TaskPool)
                                .Subscribe(OnFxCurveDefinitionsLoaded)
                                .AddTo(_disposables);
        }

        private void OnPriceCurveDefinitionsLoaded(IEnumerable<PriceCurveDefinition> priceCurveDefinitions)
        {
            var curveIds = priceCurveDefinitions.Where(p => p.CurveType != CurveType.Fx)
                                                .Select(p => p.Id).ToList();

            _log.Info("Price Curve Definitions Loaded . Subscribing to Price Curve Settings...");
            _curveControlService.SubscribePriceCurves(curveIds);
        }

        private void OnFxCurveDefinitionsLoaded(IEnumerable<FxCurveDefinition> fxCurveDefinitions)
        {
            var curveIds = fxCurveDefinitions.Select(p => p.Id).ToList();

            _log.Info("Fx Curve Definitions Loaded . Subscribing to Fx Curve Settings...");
            _curveControlService.SubscribeFxCurves(curveIds);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables.Dispose();
            }

            _disposed = true;
        }
    }
}
