﻿using Dsp.DataContracts;
using Dsp.DataContracts.Configuration;
using Dsp.DataContracts.DerivedCurves;
using Dsp.Gui.Common.Services.Connection;
using Dsp.ServiceContracts;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Threading.Tasks;

namespace Dsp.Gui.Common.Services
{
    [ExcludeFromCodeCoverage]
    public class AdminApiServiceClient : IAdminApiServiceClient
    {
        private readonly ILogger _logger;
        private readonly Uri _adminApi;
        private readonly JsonMediaTypeFormatter _formatter;

        private HttpClient _httpClient;
        private readonly object _guard = new();

        public AdminApiServiceClient(IConfigProvider configProvider,
                                     IContractResolver contractResolver,
                                     ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.Create(GetType().Name);
            _adminApi = configProvider.GetApiUrl(DataContracts.Configuration.Services.AdminWebApi);

            _formatter = new JsonMediaTypeFormatter
                         {
                             SerializerSettings = { ContractResolver = contractResolver }
                         };
        }

        public void Initialize(IHttpClientProxy httpClient)
        {
            _httpClient = httpClient.HttpClient;
        }

        public async Task<AdminApiServiceResponse> Update<T>(int id, T value)
        {
            SetCorrelationId();
            
            var httpRoute = GetControllerRoute<T>(id);

            _logger.Info($"Put:({httpRoute})({value})");

            var httpResponseMessage = await _httpClient.PutAsync(httpRoute, value, _formatter);

            return await GetResponse(httpResponseMessage);
        }

        public async Task<AdminApiServiceResponse> Update<T>(T value)
        {
            SetCorrelationId();

            var httpRoute = GetControllerRoute<T>();

            _logger.Info($"Put({httpRoute})({value})");

            var httpResponseMessage = await _httpClient.PutAsync(httpRoute, value, _formatter);

            return await GetResponse(httpResponseMessage);
        }

        public async Task<AdminApiServiceResponse> Add<T>(T value)
        {
            SetCorrelationId();

            var httpRoute = GetControllerRoute<T>();

            _logger.Info($"Post({httpRoute})({value})");

            var httpResponseMessage = await _httpClient.PostAsync(httpRoute, value, _formatter);

            return await GetResponse(httpResponseMessage);
        }

        public async Task<AdminApiServiceResponse> Add<T>(IList<T> values)
        {
            SetCorrelationId();

            var httpRoute = GetControllerRoute<IList<T>>();

            _logger.Info($"Post({httpRoute})({values})");

            var httpResponseMessage = await _httpClient.PostAsync(httpRoute, values, _formatter);

            return await GetResponse(httpResponseMessage);
        }

        public async Task<AdminApiActionResponse> UpdateAction<T>(IList<T> actions)
        {
            SetCorrelationId();

            var httpRoute = GetActionControllerRoute<T>();

            _logger.Info($"Post({httpRoute})");

            var httpResponseMessage = await _httpClient.PostAsync(httpRoute, actions, _formatter);

            var response = await GetActionResponse(httpResponseMessage);

            return response;
        }

        public async Task<AdminApiServiceResponse> UpdateChatTenorSelection(User value)
        {
            SetCorrelationId();

            //hardcoded as we are passing a User object to url UserChatTenorSelectionUpdate
            var httpRoute = GetControllerRoute("UserChatTenorSelectionUpdate");

            _logger.Info($"Put({httpRoute})({value})");

            var users = new[] { value };

            var httpResponseMessage = await _httpClient.PutAsync(httpRoute, users, _formatter);

            return await GetResponse(httpResponseMessage);
        }

        public async Task<AdminApiServiceResponse> UpdateMonthEndRoll<T>(T value)
        {
            SetCorrelationId();

            var monthEndRoll = (MonthEndRoll) (object) value;

            var httpRoute = monthEndRoll.IsReset ? GetControllerRoute("actions/MonthEndRoll/Reset") : GetControllerRoute("actions/MonthEndRoll/1/false");

            _logger.Info($"Put({httpRoute})({value})");

            var httpResponseMessage = await _httpClient.PutAsync(httpRoute, value, _formatter);

            return await GetResponse(httpResponseMessage);
        }

        
        private async Task<AdminApiActionResponse> GetActionResponse(HttpResponseMessage httpResponseMessage)
        {
            switch (httpResponseMessage.StatusCode)
            {
                case HttpStatusCode.NoContent:
                    return AdminApiActionResponse.Success();
                case HttpStatusCode.OK:
                    {
                        var warning = await httpResponseMessage.Content.ReadAsStringAsync();

                        return AdminApiActionResponse.CompletedWithWarnings(warning);
                    }
                default:
                    var error = await httpResponseMessage.Content.ReadAsStringAsync();

                    if (string.IsNullOrWhiteSpace(error))
                    {
                        error = $"A system error occurred calling service: {(int)httpResponseMessage.StatusCode} {httpResponseMessage.ReasonPhrase}";
                    }

                    _logger.Error($"ActionResponse Error : {error}");

                    return AdminApiActionResponse.Failed(error);
            }
        }

        private async Task<AdminApiServiceResponse> GetResponse(HttpResponseMessage httpResponseMessage)
        {
            if (httpResponseMessage.IsSuccessStatusCode)
            {
                return new AdminApiServiceResponse(true);
            }

            var errors = await httpResponseMessage.Content.ReadAsStringAsync();

            var reason = GetResponseReason(httpResponseMessage);

            if (!string.IsNullOrEmpty(errors)
                && httpResponseMessage.StatusCode == HttpStatusCode.BadRequest)
            {
                try
                {
                    var pricingFailures = JsonConvert.DeserializeObject<List<PricingFailure>>(errors);

                    _logger.Error("AdminService Update failed : Pricing Failures");

                    return new AdminApiServiceResponse(AdminApiServiceResponseReason.PricingFailures, 
                                                       pricingFailures);
                }
                catch (Exception)
                {
                    _logger.Error($"AdminService Update failed : {errors}");

                    return new AdminApiServiceResponse(reason);
                }
            }
            _logger.Error($"AdminService Update failed : {errors}");

            return new AdminApiServiceResponse(reason);
        }

        private static AdminApiServiceResponseReason GetResponseReason(HttpResponseMessage httpResponseMessage)
        {
            switch (httpResponseMessage.StatusCode)
            {
                case HttpStatusCode.Forbidden:
                    return AdminApiServiceResponseReason.UserPermissions;
                case HttpStatusCode.Unauthorized:
                    return AdminApiServiceResponseReason.UserNotAuthorized;
                case HttpStatusCode.InternalServerError:
                case HttpStatusCode.BadRequest:
                    return AdminApiServiceResponseReason.DspServerError;
                case HttpStatusCode.GatewayTimeout:
                    return AdminApiServiceResponseReason.Timeout;
                default:
                    return AdminApiServiceResponseReason.UnspecifiedError;
            }
        }

        private Uri GetControllerRoute<T>(int? id = null)
        {
            var type = typeof(T);

            if (type == typeof(MonthEndRoll))
            {
                return new Uri(_adminApi, "actions/MonthEndRoll/1/false"); // Legacy - not used?
            }

            if (type == typeof(PartitionShiftRequest))
            {
                return new Uri(_adminApi, "actions/PartitionShiftRequest");  // Legacy - not used
            }

            if (type.IsGenericType && (type.GetGenericTypeDefinition() == typeof(IList<>) || type.GetGenericTypeDefinition() == typeof(List<>)))
            {
                type = type.GetGenericArguments()[0];
            }

            return id == null ? new Uri(_adminApi, type.Name) : new Uri(_adminApi, $"{type.Name}/{id}");
        }
        private Uri GetControllerRoute(string relativePath)
        {
            return new Uri(_adminApi, relativePath);
        }
        private Uri GetActionControllerRoute<T>()
        {
            var type = typeof(T);
            return new Uri(_adminApi, $"action/{type.Name}");
        }

        private void SetCorrelationId()
        {
            lock (_guard) // HttpClient header manipulation is not thread safe
            {
                _httpClient.DefaultRequestHeaders.Remove("X-Correlation-ID");
                _httpClient.DefaultRequestHeaders.Add("X-Correlation-ID", _logger.SetCorrelationId());
            }
        }
    }
}
