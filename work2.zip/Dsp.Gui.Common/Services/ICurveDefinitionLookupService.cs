﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.Gui.Common.Services
{
    public interface ICurveDefinitionLookupService : IDisposable
    {
        IObservable<bool> CurvesLoaded { get; }
        List<FlatPriceCurveDefinition<MonthlyTenor>> FlatPriceCurveDefinitions { get; }
        List<PartitionedCurveDefinition<MonthlyTenor>> PartitionedCurveDefinitions { get; }
        Dictionary<LinkedCurve, string> CurveNameLookup { get; }
    }
}