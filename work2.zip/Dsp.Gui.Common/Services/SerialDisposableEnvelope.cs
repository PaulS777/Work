﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;

namespace Dsp.Gui.Common.Services
{
    public sealed class SerialDisposableEnvelope : ISerialDisposableEnvelope
    {
        private readonly SerialDisposable _serialDisposable = new();
        private bool _disposed;

        [ExcludeFromCodeCoverage]
        ~SerialDisposableEnvelope()
        {
            Dispose(false);
        }

        public void ApplySubscription(IDisposable disposable)
        {
            _serialDisposable.Disposable = disposable;
        }

        public void DisposeSubscription()
        {
            _serialDisposable.Disposable?.Dispose();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _serialDisposable.Dispose();
            }

            _disposed = true;
        }
    }
}
