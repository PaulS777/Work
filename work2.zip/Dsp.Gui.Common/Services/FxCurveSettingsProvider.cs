﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using Dsp.DataContracts.Curve;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    public sealed class FxCurveSettingsProvider : IFxCurveSettingsProvider
    {
        private readonly Dictionary<int, FxCurveSetting> _fxCurveSettingsLookup = new();
        private readonly BehaviorSubject<List<FxCurveSetting>> _fxCurveSettings = new(null);
        private readonly ILogger _log;
        private readonly IDisposable _disposable;
        private readonly object _synch = new();
        private bool _disposed;

        public FxCurveSettingsProvider(ICurveControlService curveControlService,
                                       ISchedulerProvider schedulerProvider,
                                       ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _disposable = curveControlService.FxCurveSettings
                                             .Buffer(TimeSpan.FromMilliseconds(1000), schedulerProvider.TaskPool)
                                             .Where(items => items != null)
                                             .Select(items => items.Where(i => i != null)
                                                                   .SelectMany(i => i))
                                             .Where(settings => settings.Any())
                                             .Subscribe(OnFxCurveSettings);
        }

        [ExcludeFromCodeCoverage]
        ~FxCurveSettingsProvider()
        {
            Dispose(false);
        }

        public IObservable<IList<FxCurveSetting>> FxCurveSettings => _fxCurveSettings.AsObservable();

        private void OnFxCurveSettings(IEnumerable<FxCurveSetting> fxCurveSettings)
        {
            lock (_synch)
            {
                foreach (var fxCurveSetting in fxCurveSettings)
                {
                    _fxCurveSettingsLookup[fxCurveSetting.FxCurveDefinitionId] = fxCurveSetting;
                }

                var settings = _fxCurveSettingsLookup.Values.ToList();

                _log.Info($"Fx Curve Settings Updated : {settings.Count}");
                _fxCurveSettings.OnNext(settings);
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposable.Dispose();
            }

            _disposed = true;
        }
    }
}
