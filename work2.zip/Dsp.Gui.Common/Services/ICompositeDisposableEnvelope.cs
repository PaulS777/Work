﻿using System;

namespace Dsp.Gui.Common.Services
{
	public interface ICompositeDisposableEnvelope : IDisposable
    {
        void AddSubscription(IDisposable disposable);
        void ResetSubscriptions();
    }
}
