﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts;
using Dsp.DataContracts.ChatScraper;
using Dsp.DataContracts.Configuration;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.Gui.Common.Services
{
    public interface ICurveControlService : IHubConnectionProxyClient
    {
        User CurrentUserSnapshot { get; }
        IObservable<User> CurrentUser { get; }
        IEnumerable<User> GetUsersSnapshot();
        IEnumerable<Calendar> GetCalendarsSnapshot();
        IEnumerable<PriceCurveDefinition> GetPriceCurveDefinitionsSnapshot();
        IEnumerable<FxCurveDefinition> GetFxCurveDefinitionsSnapshot();
        IEnumerable<FxCurveSetting> GetFxCurveSettingsSnapshot();
        IEnumerable<FxCurvePipsBuffer> GetFxCurvePipsBufferSnapshot();
        IEnumerable<PriceCurveSetting> GetPriceCurveSettingsSnapshot();
        IEnumerable<ChatUser> GetChatUsersSnapshot();
        IEnumerable<ChatMarket> GetChatMarketSnapshot();
        IEnumerable<ChatMessageHistory> GetChatMessagesSnapshot();
        IEnumerable<ChatIceMap> GetChatIceMapSnapshot();
        IEnumerable<ChatVariableShortcut> GetChatVariableShortcutSnapshot();
        IEnumerable<PriceCurvePremium> GetPriceCurvePremiumsSnapshot();
        IEnumerable<MonthEndRollStatus> GetMonthEndRollStatusSnapshot();
        IEnumerable<DynamicConfiguration> GetConfigurationSnapshot();
        IEnumerable<ManualCurveDefinition<MonthlyTenor>> GetManualCurveDefinitionsSnapshot();
        IEnumerable<ProductDefinition> GetProductDefinitionsSnapshot();
        IEnumerable<CurrencyCode> GetCurrencyCodesSnapshot();
        IEnumerable<CurveGroup> GetCurveGroupsSnapshot();
        IObservable<List<User>> Users { get; }
        IObservable<IList<PriceCurveDefinition>> PriceCurveDefinitions { get; }
        IObservable<IList<ManualCurveDefinition<MonthlyTenor>>> ManualCurveDefinitions { get; }
        IObservable<List<ManualCurveDefinition<MonthlyTenor>>> ManualOverrides { get; }
        IObservable<List<ManualCurveDefinition<DailyTenor>>> DailyOverrides { get; }
        IObservable<List<PriceCurveSetting>> PriceCurveSettings { get; }
        IObservable<List<FlatPriceCurveDefinition<MonthlyTenor>>> FlatPriceCurveDefinitions { get; }
        IObservable<List<DerivedCurveDefinition>> DerivedCurveDefinitions { get; }
        IObservable<List<PublisherTenorPremium>> PublisherTenorPremiums { get; }
        IObservable<IList<FxCurveDefinition>> FxCurveDefinitions { get; }
        IObservable<IList<FxCurveSetting>> FxCurveSettings { get; }
        IObservable<IList<FxCurvePipsBuffer>> FxCurvePipsBuffers { get; }
        IObservable<IList<ChatUser>> ChatUsers { get; }
        IObservable<List<ChatMarket>> ChatMarkets { get; }
        IObservable<List<ChatMessageHistory>> ChatMessages { get; }
        IObservable<List<ChatIceMap>> ChatIceMaps{ get; }
        IObservable<List<ChatVariableShortcut>> ChatVariableShortcuts { get; }
        IObservable<IList<ChatPriceSummary>> ChatPriceSummarySnapshot { get; }
        IObservable<IList<ChatPriceSummary>> ChatPriceSummaryNotifications { get; }
        IObservable<IList<Calendar>> Calendars { get; }
        IObservable<List<PriceCurvePremium>> PriceCurvePremiums { get; }
        List<ChatMessageHistory> ChatMessagesOnUpdate { get; set; }
        IObservable<List<MonthEndRollStatus>> MonthEndRollStatusOnUpdate { get; }
        IObservable<IList<MonthEndRollStatus>> MonthEndRollStatusNotifications { get; }
        IObservable<List<DynamicConfiguration>> ConfigurationOnUpdate { get; }
        IObservable<List<ServiceStatusNotification>> ServiceStatusNotifications { get; }
        IObservable<List<ProductDefinition>> ProductDefinitions { get; }
        IObservable<List<CurrencyCode>> CurrencyCodes { get; }
        IObservable<SystemDate> SystemDate { get; }
        IObservable<List<CurveGroup>> CurveGroups { get; }
        void SubscribeUsers();
        void UnsubscribeUsers();
        void SubscribePriceCurveDefinitions();
        void UnsubscribePriceCurveDefinitions();
        void SubscribeDerivedCurveDefinitions();
        void UnsubscribeDerivedCurveDefinitions();
        void SubscribeCurvePublishers();
        void UnsubscribeCurvePublishers();
        void SubscribePriceCurves(IEnumerable<int> curveIds);
        void UnsubscribePriceCurves(IEnumerable<int> curveIds);
        void SubscribeFxCurveDefinitions();
        void UnsubscribeFxCurveDefinitions();
        void SubscribeFxCurves(IEnumerable<int> curveIds);
        void UnsubscribeFxCurves(IEnumerable<int> curveIds);

        void SubscribeChatUsers();
        void UnsubscribeChatUsers();
        void SubscribeChatMarkets();
        void UnsubscribeChatMarkets();
        void SubscribeChatMessageHistory();
        void UnsubscribeChatMessageHistory();
        void SubscribeChatIceMap();
        void UnsubscribeChatIceMap();
        void SubscribeChatVariableShortcut();
        void UnsubscribeChatVariableShortcut();
        void SubscribeMonthEndRollStatus();
        void UnsubscribeMonthEndRollStatus();
        void SubscribeConfiguration();
        void UnsubscribeConfiguration();
        void SubscribeCalendars();
        void UnsubscribeCalendars();
        void SubscribeSystemDate();
        void UnsubscribeSystemDate();
        void SubscribeProductDefinitions();
        void UnsubscribeProductDefinitions();
        void SubscribeCurrencyCodes();
        void UnsubscribeCurrencyCodes();
        void SubscribeCurveGroups();
        void UnsubscribeCurveGroups();
    }
}
