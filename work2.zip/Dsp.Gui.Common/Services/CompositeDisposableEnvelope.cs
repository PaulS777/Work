﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Disposables;

namespace Dsp.Gui.Common.Services
{
	public sealed class CompositeDisposableEnvelope : ICompositeDisposableEnvelope
    {
        private CompositeDisposable _disposables = new();
        private bool _disposed;

        [ExcludeFromCodeCoverage]
		~CompositeDisposableEnvelope()
        {
            Dispose(false);
        }

        public void AddSubscription(IDisposable disposable)
        {
            _disposables.Add(disposable);
        }

        public void ResetSubscriptions()
        {
            _disposables?.Dispose();
            _disposables = new CompositeDisposable();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposables?.Dispose();
            }

            _disposed = true;
        }
	}
}
