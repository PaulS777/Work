﻿using System;

namespace Dsp.Gui.Common.Services
{
    public interface ISerialDisposableEnvelope : IDisposable
    {
        void ApplySubscription(IDisposable disposable);
        void DisposeSubscription();
    }
}
