﻿using System;

namespace Dsp.Gui.Common.Services
{
    public interface ILocalTimeProvider
    {
        TimeOnly LocalTime { get; }
    }
}
