﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;
using Dsp.DataContracts.Curve;
using Dsp.Gui.Common.Services.Connection;
using Dsp.Gui.Common.Services.Connection.Publication;
using Dsp.ServiceContracts;

namespace Dsp.Gui.Common.Services
{
    public sealed class PriceCurveService : IPriceCurveService, IDisposable
    {
        private readonly IPriceCurveSubscriptionManager _priceCurveSubscriptionManager;
        private readonly ICurvePublisherConnectionService _curvePublisherConnectionService;
        private readonly ICurvePublisherHubSubscriber _hubSubscriber;
        private readonly ILogger _log;

        private readonly IDisposable _connectDisposable;
        private bool _disposed;

        public PriceCurveService(IPriceCurveSubscriptionManager priceCurveSubscriptionManager,
                                 ICurvePublisherConnectionService curvePublisherConnectionService,
                                 ICurvePublisherHubSubscriber hubSubscriber,
                                 ILoggerFactory loggerFactory)
        {
            _log = loggerFactory.Create(GetType().Name);

            _priceCurveSubscriptionManager = priceCurveSubscriptionManager;
            _curvePublisherConnectionService = curvePublisherConnectionService;
            _hubSubscriber = hubSubscriber;

            _log.Info("Waiting for connection to CurvePublisher SignalR Hub...");

            _connectDisposable = _curvePublisherConnectionService.RunState
                                                                 .Where(state => state == HubConnectionRunState.Connected)
                                                                 .Subscribe(_ => OnConnected());
        }

        [ExcludeFromCodeCoverage]
        ~PriceCurveService()
        {
            Dispose(false);
        }

        public void SubscribeToPriceCurves(IList<int> curveIds)
        {
            var subscriptions = _priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            if (subscriptions.Count <= 0 || !_curvePublisherConnectionService.IsConnected)
            {
                return;
            }

            _log.Info($"Subscribing to PriceCurves : {string.Join(",", subscriptions)}");

            _hubSubscriber.SubscribePriceCurves(subscriptions);
        }

        public void UnsubscribeFromPriceCurves(IList<int> curveIds)
        {
            var subscriptions = _priceCurveSubscriptionManager.RemovePriceCurves(curveIds);

            if (subscriptions.Count <= 0 || !_curvePublisherConnectionService.IsConnected)
            {
                return;
            }

            _log.Info($"Unsubscribing from PriceCurves : {string.Join(",", subscriptions)}");

           _hubSubscriber.UnsubscribePriceCurves(subscriptions);
        }

        public void SubscribeToFxCurves(IList<int> curveIds)
        {
            var subscriptions = _priceCurveSubscriptionManager.AddPriceCurves(curveIds);

            if (subscriptions.Count <= 0 || !_curvePublisherConnectionService.IsConnected)
            {
                return;
            }

            _log.Info($"Subscribing to FxCurves : {string.Join(",", subscriptions)}");

            _hubSubscriber.SubscribeFxCurves(subscriptions);
        }

        public void UnsubscribeFromFxCurves(IList<int> curveIds)
        {
            var subscriptions = _priceCurveSubscriptionManager.RemovePriceCurves(curveIds);

            if (subscriptions.Count <= 0 || !_curvePublisherConnectionService.IsConnected)
            {
                return;
            }

            _log.Info($"Unsubscribing from FxCurves : {string.Join(",", subscriptions)}");

            _hubSubscriber.UnsubscribeFxCurves(subscriptions);
        }

        public void OnPriceCurvesSnapshot(IEnumerable<PriceCurve> priceCurves)
        {
            _priceCurveSubscriptionManager.UpdatePriceCurves(priceCurves);
        }

        public void OnPriceCurveNotification(PriceCurve priceCurve)
        {
            _priceCurveSubscriptionManager.UpdatePriceCurves(new[] { priceCurve });
        }

        public void OnFxCurvesSnapshot(IEnumerable<FxPriceCurve> fxPriceCurves)
        {
            _priceCurveSubscriptionManager.UpdateFxCurves(fxPriceCurves);
        }

        public void OnFxCurveNotification(FxPriceCurve fxPriceCurve)
        {
            _priceCurveSubscriptionManager.UpdateFxCurves(new[] { fxPriceCurve });
        }

        private void OnConnected()
        {
            _log.Info("Connected to CurvePublisher SignalR Hub");

            _hubSubscriber.AttachHubEvents(this, _curvePublisherConnectionService.HubConnectionProxy);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _connectDisposable.Dispose();
            }

            _disposed = true;
        }
    }
}
