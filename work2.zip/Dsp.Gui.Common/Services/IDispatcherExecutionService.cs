﻿using System;

namespace Dsp.Gui.Common.Services
{
    public interface IDispatcherExecutionService : IDisposable
    {
        void Start();
        void Stop();
        void Schedule(Action action);
        void ScheduleRepeat(Action action);
    }
}
