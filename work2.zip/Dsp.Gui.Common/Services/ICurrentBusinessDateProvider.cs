﻿using System;

namespace Dsp.Gui.Common.Services
{
    public interface ICurrentBusinessDateProvider : IDisposable
    {
        public DateTime CurrentDate { get; }
    }
}
