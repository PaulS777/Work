﻿using System.Collections.Generic;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.Gui.Common.Services
{
    public interface IPricingFailureParser
    {
        bool TryParsePricingFailures(Dictionary<LinkedCurve, string> curveLookup,
                                     List<PricingFailure> pricingFailures,
                                     out string[] messages);
    }
}
