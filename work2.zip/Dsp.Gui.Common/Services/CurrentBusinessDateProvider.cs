﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reactive.Linq;

namespace Dsp.Gui.Common.Services
{
    public sealed class CurrentBusinessDateProvider : ICurrentBusinessDateProvider
    {
        private readonly IDisposable _disposable;
        private bool _disposed;

        public CurrentBusinessDateProvider(ISystemDateProvider systemDateProvider)
        {
            _disposable = systemDateProvider.SystemDate
                                            .Where(date => date != null)
                                            .Subscribe(date => CurrentDate = date!.Value);
        }

        [ExcludeFromCodeCoverage]
        ~CurrentBusinessDateProvider()
        {
            Dispose(false);
        }

        public DateTime CurrentDate { get; private set; }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                _disposable?.Dispose();
            }

            _disposed = true;
        }
    }
}
