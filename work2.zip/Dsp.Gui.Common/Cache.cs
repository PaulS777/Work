﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts;

namespace Dsp.Gui.Common
{
    public class Cache<T> where T: IIdentifiable
    {
        private readonly Dictionary<int, T> _snapshot;
        private readonly object _synch = new();

        public Cache()
        {
            _snapshot = new Dictionary<int, T>();
        }

        public void Clear()
        {
            lock (_synch)
            {
                _snapshot.Clear();
            }
        }
        public List<T> StoreLatest(IEnumerable<T> items)
        {
            lock (_synch)
            {
                foreach (var item in items)
                {
                    _snapshot[item.Id] = item;
                }

                return _snapshot.Values.ToList();
            }
        }

        public List<T> GetSnapshot()
        {
            lock (_synch)
            {
                return _snapshot.Values.ToList();
            }
        }

        public bool TryGetValue(int key, out T value)
        {
            lock (_synch)
            {
                value = default(T);
                return _snapshot.TryGetValue(key, out value);
            }
        }
    }
}
