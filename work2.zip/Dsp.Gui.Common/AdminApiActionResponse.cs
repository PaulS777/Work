﻿namespace Dsp.Gui.Common
{
    public enum ActionResponse
    {
        Success,
        CompletedWithWarnings,
        Failed
    }

    public class AdminApiActionResponse
    {
        private AdminApiActionResponse(ActionResponse actionResponse)
        {
            ActionResponse = actionResponse;
        }

        private AdminApiActionResponse(ActionResponse actionResponse, string message)
        {
            ActionResponse = actionResponse;
            Message = message;
        }

        public ActionResponse ActionResponse { get; }
        public string Message { get; }
        public static AdminApiActionResponse Success() => new(ActionResponse.Success);
        public static AdminApiActionResponse CompletedWithWarnings(string warning) => new(ActionResponse.CompletedWithWarnings, warning);
        public static AdminApiActionResponse Failed(string error) => new(ActionResponse.Failed, error);
    }
}
