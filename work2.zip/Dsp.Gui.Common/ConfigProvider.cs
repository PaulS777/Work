﻿using System;
using System.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using Dsp.DataContracts;
using Dsp.DataContracts.Configuration;
using Dsp.ServiceContracts;
using Nerdle.AutoConfig;

namespace Dsp.Gui.Common
{
    [ExcludeFromCodeCoverage]
    public class ConfigProvider : IConfigProvider
    {
        public ICommonConfiguration Configuration { get; }

        public ConfigProvider(ILoggerFactory loggerFactory)
        {
            var logger = loggerFactory.Create(GetType());

            var directoryName = Path.GetDirectoryName(new Uri(typeof(ConfigProvider).Assembly.Location).LocalPath) ?? throw new InvalidOperationException("Invalid Path");

            try
            {
                var configFile = Path.Combine(directoryName, "common.config");

                Configuration = AutoConfig.Map<ICommonConfiguration>(configFilePath: configFile);
            }
            catch (Exception ex)
            {
                logger.Error("Configuration Initialisation failed", ex);
                throw;
            }
        }

        public ZmqPortConfiguration GetZmqConfig<T>() where T : IIdentifiable
        {
            throw new NotSupportedException();
        }

        public bool GetOption(string optionName)
        {
            throw new NotSupportedException();
        }

        public Uri GetApiUrl(DataContracts.Configuration.Services service)
        {
            // NB trailing '/' is required, otherwise using this for HttpClient.BaseAddress does not work
            // Due to some obscure ruling in RFC3986 from 2005.
            return new Uri(GetBaseUrl(service), "api/");  
        }

        public Uri GetSignalRUrl(DataContracts.Configuration.Services service)
        {
            return new Uri(GetBaseUrl(service), "signalr");
        }

        private Uri GetBaseUrl(DataContracts.Configuration.Services service)
        {
            var config = GetServiceConfiguration(service);

            if (!Uri.IsWellFormedUriString(config.Uri.OriginalString, UriKind.Absolute))
            {
                throw new ConfigurationErrorsException($"Bad URL found in config section for {service}: '{config.Uri.OriginalString}'.  It must be a valid absolute URL including protocol.");
            }

            return config.Uri;
        }

        private IServiceConfiguration GetServiceConfiguration(DataContracts.Configuration.Services serviceApi)
        {
            var service = serviceApi switch
                          {
                              DataContracts.Configuration.Services.AdminWebApi => Configuration.AdminWebApi,
                              DataContracts.Configuration.Services.CurvePublisherService => Configuration.CurvePublisherService,
                              _ => throw new ArgumentOutOfRangeException(nameof(serviceApi), serviceApi, null)
                          };

            return service;
        }
    }
}
