﻿namespace Dsp.Gui.Common
{
    public class TransactionContextState
    {
        public bool IsUpdating { get; set; }
        public bool HasOwner { get; set; }
    }
}
