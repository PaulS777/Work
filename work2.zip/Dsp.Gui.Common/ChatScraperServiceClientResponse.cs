﻿namespace Dsp.Gui.Common
{
    public class ChatScraperServiceClientResponse
    {
        public ChatScraperServiceClientResponse(bool isSuccess)
        {
            IsSuccess = isSuccess;
        }

        public ChatScraperServiceClientResponse(string reason)
        {
            Reason = reason;
        }

        public bool IsSuccess { get; }
        public string Reason { get; }
 
    }
}
