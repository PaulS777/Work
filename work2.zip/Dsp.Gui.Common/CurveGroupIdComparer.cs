﻿using System.Collections.Generic;
using Dsp.DataContracts.Curve;

namespace Dsp.Gui.Common
{
    public class CurveGroupIdComparer : IEqualityComparer<CurveGroup>
    {
        public bool Equals(CurveGroup x, CurveGroup y)
        {
            if (ReferenceEquals(x, y))
            {
                return true;
            }

            if (x is null)
            {
                return false;
            }

            if (y is null)
            {
                return false;
            }

            return x.Id == y.Id;
        }

        public int GetHashCode(CurveGroup obj)
        {
            return obj.Id;
        }
    }
}
