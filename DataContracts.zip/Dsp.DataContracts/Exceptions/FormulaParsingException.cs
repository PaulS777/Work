﻿using System;

namespace Dsp.DataContracts.Exceptions;

/// <summary>
/// A price formula has failed to parse
/// </summary>
public class FormulaParsingException : Exception
{
    public FormulaParsingException()
    {

    }
    public FormulaParsingException(string message, Exception ex) : base(message, ex)
    {
    }

    public FormulaParsingException(string message) : base(message)
    {
    }

}