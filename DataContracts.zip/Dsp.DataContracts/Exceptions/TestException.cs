﻿using System;

namespace Dsp.DataContracts.Exceptions
{
    /// <summary>
    /// An error has occurred in test code
    /// </summary>
    public class TestException : Exception
    {
        public TestException()
        { }

        public TestException(string message) : base(message)
        { }

        public TestException(string message, Exception innerException) : base(message, innerException)
        { }
    }
}