﻿// /***********************************************************************************************************************
// DspWebApiException.cs
// 
// (c) 2022 - Shell.  Created by Hughes, Tim DW SITI-PTIY/BBJ, 2022/03/30.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System;

namespace Dsp.DataContracts.Exceptions;

    /// <summary>
    /// Indicates an exception occurred while during inter-process communication
    /// </summary>
public class MessagingException : Exception
{
    public MessagingException()
    { }

    public MessagingException(string message) : base(message)
    { }

    public MessagingException(string message, Exception innerException) : base(message, innerException)
    { }
}
