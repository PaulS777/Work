﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record MonthEndRollStatus : DeletableEntity
    {
        [JsonProperty]
        public DateOnly RollMonth { get; init; }

        [Required]
        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        public RollStatus RollStatus { get; init; }

        [JsonProperty]
        public DateTime LastUpdated { get; init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public MonthEndRollStatus() : base(int.MinValue, EntityStatus.Active)
        { }

        private MonthEndRollStatus(int id, DateOnly rollMonth, RollStatus rollStatus, DateTime lastUpdated, EntityStatus status = EntityStatus.Active) : base(id, status)
        {
            RollStatus = rollStatus;
            RollMonth = rollMonth;
            LastUpdated = lastUpdated;

            if (id != rollMonth.Year * 100 + rollMonth.Month)
            {
                throw new ArgumentException($"Id {id} is inconsistent with RollMonth {RollMonth}", nameof(id));
            }
        }

        public MonthEndRollStatus(DateOnly rollMonth,  RollStatus rollStatus, DateTime lastUpdated)
        : this(rollMonth.Year * 100 + rollMonth.Month, rollMonth, rollStatus, lastUpdated)
        {}

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(RollMonth)}: {RollMonth}, {nameof(RollStatus)}: {RollStatus}, {nameof(LastUpdated)}: {LastUpdated}";
        }
    }
}
