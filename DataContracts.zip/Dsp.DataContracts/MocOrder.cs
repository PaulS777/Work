﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.Curve;
using Dsp.DataContracts.JsonConverters;
using Dsp.DataContracts.WebApi;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts
{
    [JsonObject]
    public class MocOrder : IWebApiMessage
    {
        [JsonProperty("msg_type")]
        public string MsgType => "moc_order";

        [JsonProperty("timestamp"), JsonConverter(typeof(DateTimeJsonConverter))]
        public DateTime Timestamp { get; init; }

        [JsonProperty("order_id")]
        public long OrderId { get; init; }

        [JsonProperty("close_date"), JsonConverter(typeof(DateJsonConverter))]
        public DateTime CloseDate { get; init; }

        [JsonProperty("region"), JsonConverter(typeof(StringEnumConverter))]
        public CurveRegion Region { get; init; }

        [JsonProperty("curve_id")]
        public string CurveId { get; init; }

        [JsonProperty("periods", ItemConverterType = typeof(MonthlyTenorJsonConverter))]
        public IList<MonthlyTenor> Periods { get; init; }

        [JsonProperty("sides", ItemConverterType = typeof(StringEnumConverter))]
        public IList<BuySell> Sides { get; init; }

        [JsonProperty("volumes")]
        public IList<int> Volumes { get; init; }

        [JsonProperty("user_id")]
        public string UserId { get; init; }

        public MocOrder()
        {            
        }

        public MocOrder(DateTime timestamp, long orderId, DateTime closeDate, CurveRegion region, string curveId, 
            IList<MonthlyTenor> periods, IList<BuySell> sides, IList<int> volumes, string userId)
        {
            Timestamp = timestamp;
            OrderId = orderId;
            CloseDate = closeDate;
            Region = region;
            CurveId = curveId;
            Periods = periods;
            Sides = sides;
            Volumes = volumes;
            UserId = userId;
        }
    }
}
