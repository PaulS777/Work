﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.AdminActions
{
    /// <summary>
    /// An Administrative Action - generally a user initiated request to perform some specific action not covered by the standard CRUD operations supported by the AdminWebApi<br/>
    /// This avoids putting too much domain logic in the GUI and allows multi-step DB operations to be covered in a single transaction within the DataManagementService
    /// </summary>
    [JsonObject]
    public abstract class AdminAction
    {
        [JsonProperty]
        [Required]
        public virtual string ActionName { get; init; }

        /// <summary>
        /// Id of the target of this operation, e.g. which data entity is the primary subject, such as curve or user.  Override to return the relevant id.
        /// </summary>
        public abstract int Target { get; }

        /// <summary>
        /// Implement this in the inheriting class so that it shows up correctly in the audit trail
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"ERROR: ToString() must be implemented in the {ActionName} child class to include all properties.";
        }
    }
}
