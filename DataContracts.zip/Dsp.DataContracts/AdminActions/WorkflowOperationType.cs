﻿namespace Dsp.DataContracts.AdminActions;

public enum WorkflowOperationType 
{
    Approve,
    Reject,
    Cancel,
    Delete

}