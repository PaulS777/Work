﻿// /***********************************************************************************************************************
// AssumeCurveOwnership.cs
// 
// (c) 2023 - Shell.  Created by Hughes, Tim DW SITILTD-PTIY/TCD, 2023/05/12.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.AdminActions;

[JsonObject]
public class SetSpreadMultiplier : AdminAction
{
    public override string ActionName => GetType().Name;
    public override int Target => UserId;

    [JsonProperty]
    [Required]
    public int UserId { get; init; }

    [JsonProperty]
    [Required]
    public double SpreadMultiplier { get; init; }

    /// <inheritdoc />
    public SetSpreadMultiplier(int userId, double spreadMultiplier)
    {
        UserId = userId;
        SpreadMultiplier = spreadMultiplier;
    }

    /// <inheritdoc />
    public override string ToString()
    {
        return $"{nameof(ActionName)}: {ActionName}, {nameof(UserId)}: {UserId}, {nameof(SpreadMultiplier)}: {SpreadMultiplier}";
    }
}