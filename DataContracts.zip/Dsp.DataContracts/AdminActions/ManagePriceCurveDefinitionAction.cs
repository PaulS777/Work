﻿using Dsp.DataContracts.Curve;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel.DataAnnotations;

namespace Dsp.DataContracts.AdminActions
{
    public class ManagePriceCurveDefinitionAction : AdminAction
    {
        [JsonProperty]
        [Required]
        public override string ActionName => GetType().Name;
        
        public override int Target => PriceCurveDefinitionId;
       
        [JsonProperty]
        [Required]
        public OperationType OperationType { get; init; }
        [JsonProperty]
        [Required]
        public AdminCurveType AdminCurveType { get; init; }
        public int PriceCurveDefinitionId { get; init; }

        [JsonProperty]
        [Required(AllowEmptyStrings = false),
        RegularExpression(@"^[a-zA-Z0-9_\-]*$",
        ErrorMessage ="Price Curve Name is required. Price Curve Name can only contain alphabets, numbers, - or _")]
        public string Name { get; init; }

        [JsonProperty]
        [Required(AllowEmptyStrings = false)]
        public string Description { get; init; }

        [JsonProperty]
        [Required]
        public int ProductDefinitionId { get; init; }

        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        [Required]
        public CurveRegion CurveRegion { get; init; }

        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        [Required]
        public CurveType CurveType { get; init; }

     
        [JsonProperty]
        [Required]
        public int DsxLotSize { get; init; }

        [JsonProperty]
        [Required]
        public UnitOfMeasure DsxUnitOfMeasureId { get; init; }

        [JsonProperty]
        public bool ExcludePremiums { get; init; }

        [JsonProperty]
        public string PriceFormula { get; init; }

        [JsonProperty]
        public int? MaxPeriodCount { get; init; }

        public PriceCurveDefinitionOverride Overrides { get; init; }

        public ManagePriceCurveDefinitionAction(
          OperationType operationType,
          AdminCurveType adminCurveType,
          int priceCurveDefinitionId,
          string name,
          string description,
          int productDefinitionId,
          CurveRegion curveRegion,
          CurveType curveType,
          UnitOfMeasure dsxUnitOfMeasure,
          int dsxLotSize,
          string priceFormula,
          bool excludePremiums,
          int? maxPeriodCount = null,
          PriceCurveDefinitionOverride definitionOverride = null)
        {
            OperationType = operationType;
            AdminCurveType = adminCurveType;
            PriceCurveDefinitionId = priceCurveDefinitionId;
            Name = name;
            Description = description;
            ProductDefinitionId = productDefinitionId;
            CurveRegion = curveRegion;
            CurveType = curveType;
            DsxUnitOfMeasureId = dsxUnitOfMeasure;
            DsxLotSize = dsxLotSize;
            PriceFormula = string.IsNullOrEmpty(priceFormula)? null : priceFormula;
            ExcludePremiums = excludePremiums;
            MaxPeriodCount = maxPeriodCount;
            Overrides = definitionOverride;

        }

        public override string ToString()
        {
            return
                $"{nameof(PriceCurveDefinitionId)}: {PriceCurveDefinitionId}, {nameof(Name)}: {Name}, {nameof(Description)}: {Description},  " +
                $"{nameof(CurveRegion)}: {CurveRegion}, {nameof(CurveType)}: {CurveType}, " +
                $"{nameof(DsxUnitOfMeasureId)}: {DsxUnitOfMeasureId}, {nameof(DsxLotSize)}: {DsxLotSize}, , {nameof(PriceFormula)}: {PriceFormula}, " +
                $"{nameof(MaxPeriodCount)}: {MaxPeriodCount}" +
                $"{nameof(Overrides.Currency)}: {Overrides?.Currency}" +
                $"{nameof(Overrides.LotSize)}: {Overrides?.LotSize}" +
                $"{nameof(Overrides.CurrencyDenominationFactor)}: {Overrides?.CurrencyDenominationFactor}" +
                $"{nameof(Overrides.UnitOfMeasure)}: {Overrides?.UnitOfMeasure?.ToString()}";
                
        }

    }

}
