﻿using Dsp.DataContracts.Curve;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.ComponentModel.DataAnnotations;

namespace Dsp.DataContracts.AdminActions
{
    public class ManageExternalPriceCurveDefinitionAction : ManagePriceCurveDefinitionAction
    {
        [JsonProperty]
        [Required]
        public override string ActionName => GetType().Name;
        public override int Target => PriceCurveDefinitionId;
        private const int MonthsInYear = 12;

        #region BaseCurve details

        [JsonProperty]
        [Required]
        [Range(1,10)]
        public int CurveLengthYears { get; init; }
     
        public int PeriodCountMonths => CurveLengthYears * MonthsInYear; 
                
        [JsonProperty]
        [Required]
        public int ExpirationDaysOffset { get; init; }
        [JsonProperty]
        [Required]
        public int CalendarId { get; init; }
        [JsonProperty]
        [Required]
        public int Precision { get; init; }
        // Determines if the Curve Builder Type is  FuturesSwapsAndSpreadBuilder or PassThroughBuilder
        public bool CreateFuturesSwapsAndSpreads { get; init; }
        [JsonProperty]
        [Required]
        public string FeedProductCode { get; init; }
        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        [Required]
        public FeedSource FeedSource { get; init; }
        #endregion

        [JsonProperty]
        [Required]
        public LiquidityThreshold LiquidityThreshold { get; init; }

        public ManageExternalPriceCurveDefinitionAction(
         OperationType operationType,
         AdminCurveType adminCurveType,
         int priceCurveDefinitionId,
         string name,
         string description,
         int productDefinitionId,
         CurveRegion curveRegion,
         CurveType curveType,
         UnitOfMeasure dsxUnitOfMeasure,
         int dsxLotSize,
         string priceFormula,
         bool excludePremiums,
         int curveLengthYears,
         int expirationDaysOffset,
         int calendarId,
         string feedProductCode,
         FeedSource feedSource,
         int? maxPeriodCount,
         int precision,
         bool createSwapsAndSpreads,
         PriceCurveDefinitionOverride definitionOverride = null,
         LiquidityThreshold liquidityThreshold = null) : base(
           operationType,
           adminCurveType,
           priceCurveDefinitionId,
           name,
           description,
           productDefinitionId,
           curveRegion,
           curveType,
           dsxUnitOfMeasure,
           dsxLotSize,
           priceFormula,
           excludePremiums,
           maxPeriodCount,
           definitionOverride)
        {

            CurveLengthYears = curveLengthYears;
            ExpirationDaysOffset = expirationDaysOffset;
            CalendarId = calendarId;
            FeedProductCode = feedProductCode;
            FeedSource = feedSource;
            ExpirationDaysOffset = expirationDaysOffset;
            CreateFuturesSwapsAndSpreads = createSwapsAndSpreads;
            LiquidityThreshold = liquidityThreshold;
            Precision = precision;
        }

        public override string ToString()
        {
            return
                $"{nameof(PriceCurveDefinitionId)}: {PriceCurveDefinitionId}, {nameof(Name)}: {Name}, {nameof(Description)}: {Description},  " +
                $"{nameof(CurveRegion)}: {CurveRegion}, " +
                $"{nameof(DsxUnitOfMeasureId)}: {DsxUnitOfMeasureId}, {nameof(DsxLotSize)}: {DsxLotSize}, " +
                $"{nameof(MaxPeriodCount)}: {MaxPeriodCount}, " +
                $"{nameof(Overrides.Currency)}: {Overrides?.Currency}, " +
                $"{nameof(Overrides.LotSize)}: {Overrides?.LotSize}, " +
                $"{nameof(Overrides.CurrencyDenominationFactor)}: {Overrides?.CurrencyDenominationFactor}, " +
                $"{nameof(Overrides.UnitOfMeasure)}: {Overrides?.UnitOfMeasure?.ToString()}, " +
                $"{nameof(FeedProductCode)}: {FeedProductCode}, " +
                $"{nameof(FeedSource)}: {FeedSource}, " +
                $"{nameof(ExpirationDaysOffset)}: {ExpirationDaysOffset}, " +
                $"{nameof(CalendarId)}: {CalendarId}, ";
        }

    }
}
