﻿// /***********************************************************************************************************************
// AssumeCurveOwnership.cs
// 
// (c) 2023 - Shell.  Created by Hughes, Tim DW SITILTD-PTIY/TCD, 2023/05/12.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.AdminActions;

/// <summary>
/// Take ownership of a curve
/// </summary>
[JsonObject]
public class AssumeCurveOwnership : AdminAction
{
    public override string ActionName => GetType().Name;
    public override int Target => PriceCurveId;

    [JsonProperty]
    [Required]
    public ActionTargetType ActionTargetType { get; init; }

    [JsonProperty]
    [Required]
    public int PriceCurveId { get; init; }

    [JsonProperty]
    [Required]
    public int NewUserId { get; init; }

    [JsonProperty]
    [Required]
    public bool InheritMargins { get; init; }

    [JsonProperty]
    [Required]
    public bool IsPublishable { get; init; }

    [JsonProperty]
    [Required]
    public bool IsTradeable { get; init; }

    [JsonProperty]
    [Required]
    public bool IsExcelSourced { get; init; }

    /// <inheritdoc />
    public AssumeCurveOwnership(ActionTargetType actionTargetType, int priceCurveId, int newUserId, bool inheritMargins, bool isPublishable, bool isTradeable, bool isExcelSourced)
    {
        ActionTargetType = actionTargetType;
        PriceCurveId = priceCurveId;
        NewUserId = newUserId;
        InheritMargins = inheritMargins;
        IsPublishable = isPublishable;
        IsTradeable = isTradeable;
        IsExcelSourced = isExcelSourced;
    }

    /// <inheritdoc />
    public override string ToString()
    {
        return
            $"{nameof(ActionName)}: {ActionName}, {ActionTargetType} " +
            $"{nameof(PriceCurveId)}: {PriceCurveId}, " +
            $"{nameof(NewUserId)}: {NewUserId}, " +
            $"{nameof(InheritMargins)}: {InheritMargins}, " +
            $"{nameof(IsPublishable)}: {IsPublishable}, " +
            $"{nameof(IsTradeable)}: {IsTradeable}" +
            $"{nameof(IsExcelSourced)}: {IsExcelSourced}";
    }
}