﻿namespace Dsp.DataContracts.AdminActions
{
    public class ManageCurveGroupAction : AdminAction
    {
        public override string ActionName => GetType().Name;
        public override int Target => CurveGroupId;
        public OperationType OperationType { get; init; }
        public int CurveGroupId { get; init; }
        public string CurveGroupName { get; init; }
        public string Description { get; init; }
        public string CurveGroupColour { get; init; }
        public bool IsPublishable { get; init; }

        public ManageCurveGroupAction(OperationType operationType, int curveGroupId, string name, string description, string color, bool isPublishable)
        {
            OperationType = operationType;
            CurveGroupId = curveGroupId;
            CurveGroupName = name;
            Description = description;
            CurveGroupColour = color;
            IsPublishable = isPublishable;
        }

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(ActionName)}: {ActionName}, {nameof(Target)}: {Target}, {nameof(OperationType)}: {OperationType}," +
                   $" {nameof(CurveGroupId)}: {CurveGroupId}, {nameof(CurveGroupName)}: {CurveGroupName}, {nameof(Description)}: {Description}, {nameof(CurveGroupColour)}: {CurveGroupColour}, " +
                   $"{nameof(IsPublishable)}: {IsPublishable}";
        }
    }
}
