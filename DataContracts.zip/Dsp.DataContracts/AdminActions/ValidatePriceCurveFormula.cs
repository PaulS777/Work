﻿// /***********************************************************************************************************************
// ValidatePriceCurveFormulaRequest.cs
// 
// (c) 2023 - Shell.  Created by Hughes, Tim DW SITILTD-PTIY/TCD, 2023/05/12.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.Curve;
using Newtonsoft.Json;

namespace Dsp.DataContracts.AdminActions;

/// <summary>
/// Validate a formula for correctness: syntax, references, etc.
/// </summary>
[JsonObject]
public class ValidatePriceCurveFormulaRequest(string requestId, string formula) : AdminAction, IIdentifiable
{
    public override string ActionName => GetType().Name;
    public override int Target => 0;
    public int Id => 0;

    [JsonProperty]
    [Required]
    public string RequestId { get; init; } = requestId;

    [JsonProperty]
    [Required]
    public string Formula { get; init; } = formula;

    /// <inheritdoc />
    public override string ToString()
    {
        return $"{nameof(ActionName)}: {ActionName}, {nameof(RequestId)}: {RequestId}, {nameof(Formula)}: {Formula}";
    }
}

/// <summary>
/// Response to a validation request containing either:
/// - a success result along with snapshot values of all the curves in the formula
/// - an error result containing error details and location to help highlight the problem
/// </summary>
/// <param name="requestId"></param>
/// <param name="formula"></param>
/// <param name="status"></param>
/// <param name="errorDetails"></param>
/// <param name="successDetails"></param>
[JsonObject]
public class ValidatePriceCurveFormulaResponse(
    string requestId,
    string formula,
    Status status,
    ValidatePriceCurveFormulaResponse.ParseErrorDetails errorDetails,
    ValidatePriceCurveFormulaResponse.ParseSuccessDetails successDetails) : IIdentifiable
{
    public int Id => 0;

    [JsonProperty]
    [Required]
    public string RequestId { get; init; } = requestId;

    [JsonProperty]
    [Required]
    public string Formula { get; init; } = formula;

    [JsonProperty]
    [Required]
    public Status Status { get; init; } = status;

    [JsonProperty]
    public ParseErrorDetails ErrorDetails { get; init; } = errorDetails;

    [JsonObject]
    public class ParseErrorDetails(List<string> logMessages, string offendingToken, string message, int lineNo, int charNo)
    {
        [JsonProperty]
        public List<string> LogMessages { get; init; } = logMessages;

        [JsonProperty]
        public string OffendingToken { get; init; } = offendingToken;

        [JsonProperty]
        public string Message { get; init; } = message;

        [JsonProperty]
        public int LineNo { get; init; } = lineNo;

        [JsonProperty]
        public int CharNo { get; init; } = charNo;
    }

    [JsonProperty]
    public ParseSuccessDetails SuccessDetails { get; init; } = successDetails;

    [JsonObject]
    public class ParseSuccessDetails(List<string> priceCurveNames, List<TenorPrices<MonthlyTenor>> priceCurves)
    {
        [JsonProperty]
        public List<string> PriceCurveNames { get; init; } = priceCurveNames;

        [JsonProperty]
        public List<TenorPrices<MonthlyTenor>> PriceCurves { get; init; } = priceCurves;
    }

    /// <inheritdoc />
    public override string ToString()
    {
        return $"{nameof(Id)}: {Id}, {nameof(RequestId)}: {RequestId}, {nameof(Formula)}: {Formula}, {nameof(Status)}: {Status}, {nameof(ErrorDetails)}: {ErrorDetails}, {nameof(SuccessDetails)}: {
            SuccessDetails}";
    }
}
