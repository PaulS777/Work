﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.AdminActions
{
    public class ManageFxCurveDefinitionAction: AdminAction
    {
        [JsonProperty]
        [Required]
        public override string ActionName => GetType().Name;
        /// <inheritdoc />
        [JsonProperty]
        [Required]
        public override int Target => FxCurveId;
        [JsonProperty]
        [Required]
        public OperationType OperationType { get; init; }
        [JsonProperty]
        [Required]
        public int  BaseCurrencyId { get; init; }
        [JsonProperty]
        [Required]
        public int QuoteCurrencyId { get; init; }
        [JsonProperty]
        [Required]
        [LessThan(11)]
        [GreaterThan(0)]
        public int NumberOfYears { get; init; }
        [JsonProperty]
        [Required]
        public int FxCurveId { get; init; }



        /// <inheritdoc />
        public ManageFxCurveDefinitionAction(OperationType operationType, int fxCurveId, int baseCurrencyId, int quoteCurrencyId, int numberOfYears)
        {
            OperationType = operationType;
            FxCurveId = fxCurveId;
            BaseCurrencyId = baseCurrencyId;
            QuoteCurrencyId = quoteCurrencyId;
            NumberOfYears = numberOfYears;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(ActionName)}: {ActionName}, {nameof(Target)}: {Target}, {nameof(OperationType)}: {OperationType}," +
                   $" {nameof(BaseCurrencyId)}: {BaseCurrencyId}, {nameof(QuoteCurrencyId)}: {QuoteCurrencyId}, {nameof(NumberOfYears)}: {NumberOfYears}, " +
                   $"{nameof(FxCurveId)}: {FxCurveId}";
        }
    }
}
