﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.JsonConverters;
using Dsp.DataContracts.WebApi;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts
{
    [JsonObject]
    public class Deal : IWebApiMessage
    {
        [JsonProperty("msg_type")]
        public string MsgType => "deal";

        [JsonProperty("deal_id")]
        public long DealId { get; init; }

        [JsonProperty("timestamp"), JsonConverter(typeof(DateTimeJsonConverter))]
        public DateTime Timestamp { get; init; }

        [JsonProperty("quote_id")]
        public long QuoteId { get; init; }

        [JsonProperty("curve_id")]
        public string CurveId { get; init; }

        [JsonProperty("periods", ItemConverterType = typeof(MonthlyTenorJsonConverter))]
        public IList<MonthlyTenor> Periods { get; init; }

        [JsonProperty("sides", ItemConverterType = typeof(StringEnumConverter))]
        public IList<BuySell> Sides { get; init; }

        [JsonProperty("volumes")]
        public IList<int> Volumes { get; init; }

        [JsonProperty("price")]
        public double Price { get; init; }

        [JsonProperty("currency")]
        public string Currency { get; init; }

        [JsonProperty("brokerage")]
        public double Brokerage { get; init; }

        [JsonProperty("service_fee")]
        public double ServiceFee { get; init; }

        [JsonProperty("user_id")]
        public string UserId { get; init; }

        [JsonProperty("user_timezone")]
        public string UserTimeZone { get; init; }

        [JsonProperty("cpty_user_id")]
        public string CptyUserId { get; init; }

        [JsonProperty("customer_id")]
        public string CustomerId { get; init; }

        [JsonProperty("internal_match")]
        public bool InternalMatch { get; init; }

        [JsonProperty("is_hedge")]
        public bool IsHedge { get; init; }

        [JsonProperty("memo")]
        public string Memo { get; init; }

        public Deal()
        {            
        }

        public Deal(long dealId, DateTime timestamp, long quoteId, string curveId, IList<MonthlyTenor> periods,
            IList<BuySell> sides, IList<int> volumes, double price, string currency, double brokerage,
            double serviceFee, string userId, string userTimeZone, string cptyUserId, string customerId,
            bool internalMatch, bool isHedge, string memo)
        {
            DealId = dealId;
            Timestamp = timestamp;
            QuoteId = quoteId;
            CurveId = curveId;
            Periods = periods;
            Sides = sides;
            Volumes = volumes;
            Price = price;
            Currency = currency;
            Brokerage = brokerage;
            ServiceFee = serviceFee;
            UserId = userId;
            CptyUserId = cptyUserId;
            CustomerId = customerId;
            InternalMatch = internalMatch;
            IsHedge = isHedge;
            Memo = memo;
            UserTimeZone = userTimeZone;
        }
    }
}