﻿namespace Dsp.DataContracts.Configuration
{
    public enum Services
    {
        AdminWebApi = 1,
        ChatScraper,
        ChatScraperParser,
        CurvePublisherService,
        FxService,
        DataManagementService,
        PriceFeed,
        PricingService,
        ShopfrontService,
        WebApi,
        ServiceBusApi,
        TestingOnly
    }
}