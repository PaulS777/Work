﻿using System;
using System.Diagnostics;

namespace Dsp.DataContracts.Configuration
{
    public static class LocalEnvironment
    {
        private static bool? _isRunningInVisualStudio;

        public static bool IsRunningInVisualStudio()
        {
            if (_isRunningInVisualStudio.HasValue)
            {
                return _isRunningInVisualStudio.Value;
            }

            _isRunningInVisualStudio = typeof(LocalEnvironment).Assembly.Location.Contains(@"C:\DEV\DSP", StringComparison.InvariantCultureIgnoreCase);
            _isRunningInVisualStudio |= !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("VisualStudioEdition"));
            _isRunningInVisualStudio |= Debugger.IsAttached;

            return _isRunningInVisualStudio.Value;
        }
    }
}
