﻿namespace Dsp.DataContracts.Configuration
{
    public enum ZmqPorts
    {
        // From Price Feed
        MarketData = 35501,
        FxData = 35505,
        // From Pricing Service
        PriceCurves = 35503,
        ValidatePriceCurveFormulaResponse = 35509,
        // From FX Service
        FxCurves = 35507,
        // From Data Management Service
        PriceCurveSettings = 35002,
        PriceCurvePremiums = 35016,
        PublisherTenorPremiums = 35018,
        PriceCurveDefinitions = 35006,
        Users = 35008,
        DerivedCurveDefinitions = 35010,
        FxCurveSettings = 35012,
        FxCurveDefinitions = 35014,
        FxCurvePipsBuffers = 35020,
        ChatUsers = 35022,
        ChatMarkets = 35024,
        ChatIceMaps = 35026,
        ChatMessageHistory = 35032,
        ChatVariableShortcuts = 35036,
        ChatPriceSummaries = 35038,
        ServiceStatusNotifications = 35040,
        Calendars = 35042,
        MonthEndRollStatus = 35046,
        DynamicConfiguration = 35048,
        BaseCurveLiquidityThreshold = 35050,
        BaseCurveDefinition = 35052,
        CurrencyCode = 35054,
        SystemDate = 35056,
        ProductDefinition = 35058,
        ClientApiKey = 35060,
        CurveGroup = 35062,
        ValidatePriceCurveFormulaRequest = 35064,

        // From Chat Scraper
        ChatIceRawTextMessages = 35524
    }
}