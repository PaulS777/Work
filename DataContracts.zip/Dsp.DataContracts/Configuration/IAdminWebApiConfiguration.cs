﻿using System;
using System.ComponentModel;

namespace Dsp.DataContracts.Configuration;

public interface IAdminWebApiConfiguration : IServiceConfiguration
{
    [DefaultValue(false)]
    bool EnableSso { get; set; }
    Uri SsoAuthority { get; }
    string SsoClientId { get; }
    string SsoClientSecret { get; }
}