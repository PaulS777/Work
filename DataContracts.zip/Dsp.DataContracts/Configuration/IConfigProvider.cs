﻿using System;

namespace Dsp.DataContracts.Configuration
{
    public interface IConfigProvider
    {
        ICommonConfiguration Configuration { get; }

        /// <summary>
        /// Returns the request API url for the given service
        /// </summary>
        /// <param name="service"></param>
        /// <returns>uri in the form "http://&lt;hostname&gt;:&lt;port&gt;/api"</returns>
        Uri GetApiUrl(Services service);

        /// <summary>
        /// Returns the request API url for the given service
        /// </summary>
        /// <param name="service"></param>
        /// <returns>uri in the form "http://&lt;hostname&gt;:&lt;port&gt;/signalr"</returns>
        Uri GetSignalRUrl(Services service);

        /// <summary>
        /// Get the ZeroMQ configuration for a given data type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns>port configuration, including host server and port numbers</returns>
        ZmqPortConfiguration GetZmqConfig<T>() where T : IIdentifiable;

        /// <summary>
        /// Returns the presence of a named option flag in the configuration
        /// </summary>
        /// <param name="optionName"></param>
        /// <returns>True if flag is present</returns>
        bool GetOption(string optionName);


    }
}