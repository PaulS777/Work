﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Configuration
{
    [JsonObject]
    public record DynamicConfiguration : DeletableEntity
    {
        public DynamicConfiguration(int id, string categoryName, string configName, string configValue) : base(id, EntityStatus.Active)
        {
            CategoryName = categoryName;
            ConfigName = configName;
            ConfigValue = configValue;
        }

        [JsonProperty]
        [Required]
        public string CategoryName { get; init; }

        [JsonProperty]
        [Required]
        public string ConfigName { get; init; }

        [JsonProperty]
        [Required]
        public string ConfigValue { get; init; }

        public override string ToString()
        {
            return $"{CategoryName}/{ConfigName}: {ConfigValue}";
        }
    }

    public static class ConfigurationHelper
    {
        public static string GetString(this Dictionary<int, DynamicConfiguration> configurationDict, string category, string name)
        {
            try
            {
                return configurationDict.Values.Single(x => x.CategoryName == category && x.ConfigName == name).ConfigValue;
            }
            catch (Exception)
            {
                throw new InvalidOperationException($"There is no configuration entry for {category}/{name}");
            }
        }

        private static readonly string[] BoolTrues = {"YES", "Y", "1", "-1"};
        public static bool GetBool(this Dictionary<int, DynamicConfiguration> configurationDict, string category, string name)
        {
            return BoolTrues.Contains(configurationDict.GetString(category, name).ToUpperInvariant());
        }

        public static int GetInt(this Dictionary<int, DynamicConfiguration> configurationDict, string category, string name)
        {
            return int.Parse(configurationDict.GetString(category, name).ToUpperInvariant());
        }

    }
}