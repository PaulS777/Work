﻿// /***********************************************************************************************************************
// IPriceFeedServiceConfiguration.cs
// 
// (c) 2022 - Shell.  Created by Hughes, Tim DW SITI-PTIY/BBJ, 2022/03/30.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System;
using System.ComponentModel;

namespace Dsp.DataContracts.Configuration
{
    public interface IPriceFeedServiceConfiguration : IServiceConfiguration
    {
        IElektronFeedConfiguration ElektronFeed { get; set; }
        IAesFeedConfiguration AesFeed { get; set; }
    }

    public interface IElektronFeedConfiguration
    {
        [DefaultValue(false)]
        bool UseRealTimeIdWatchList { get; set; }
        string FeedEndpoints { get; set; }
        string UserName { get; set; }
        string AppId { get; set; }
        Uri AuthenticationUrl { get; set; }
        Uri ServiceDiscoveryUrl { get; set; }
        string ClientId { get; set; }
        string Secret { get; set; }
        string Region { get; set; }
        string Scope { get; set; }
    }

    public interface IAesFeedConfiguration
    {
        string ConnectionString { get; set; }
        string ApiKey { get; set; }
        string WebsocketAddress { get; set; }
    }
}