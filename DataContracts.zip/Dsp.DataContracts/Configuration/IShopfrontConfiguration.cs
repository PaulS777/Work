﻿namespace Dsp.DataContracts.Configuration
{
    public interface IShopfrontConfiguration
    {
        int PublishFrequencySeconds { get; }
        int MaxPublishedMonths { get; }
        string ShopfrontDatabaseConnection { get; }
    }
}