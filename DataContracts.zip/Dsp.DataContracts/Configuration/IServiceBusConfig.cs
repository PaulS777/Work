﻿using System;

namespace Dsp.DataContracts.Configuration
{
    public interface IServiceBusConfig
    {
         string ConnectionString { get; set; }
         string TopicName { get; set; }
         int MaxPublishFrequencyMs { get; set; }
         Uri ProxyUrl { get; set; }
    }
}
