﻿// ***********************************************************************************************************************
// ServiceBusConfiguration.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class ServiceBusConfiguration : ConfigurationBase, IServiceBusConfig
    {
        public ServiceBusConfiguration(EnvironmentVariableTarget target) : base(target, "SERVICE_BUS_API")
        {
        }
        public string ConnectionString
        {
            get => GetEnvironmentVariable("CONNECTIONSTRING");
            set => throw new NotSupportedException();
        }

        public string TopicName
        {
            get => GetEnvironmentVariable("TOPICNAME");
            set => throw new NotSupportedException();
        }

        public int MaxPublishFrequencyMs
        {
            get => GetEnvironmentVariableAsInt("MAXPUBLISHFREQUENCYMS");
            set => throw new NotSupportedException();
        }

        public Uri ProxyUrl
        {
            get => GetEnvironmentVariableAsUri("PROXYURL");
            set => throw new NotSupportedException();
        }
    }
}
