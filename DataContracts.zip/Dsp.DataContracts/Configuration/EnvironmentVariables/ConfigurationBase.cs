﻿// /***********************************************************************************************************************
// ConfigurationBase.cs
// 
// (c) 2023 - Shell.  Created by Hughes, Tim DW SITILTD-PTIY/TCD, 2023/04/25.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using Dsp.DataContracts.Exceptions;
using System;
using System.Globalization;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class ConfigurationBase
    {
        private readonly EnvironmentVariableTarget _target;
        private readonly string _prefix;

        protected ConfigurationBase(EnvironmentVariableTarget target, string prefix)
        {
            _target = target;
            _prefix = prefix;
        }

        protected string GetEnvironmentVariable(string varName, bool throwIfMissing=true)
        {
            var envVariable = $"{_prefix}_{varName}";
            return Environment.GetEnvironmentVariable(envVariable, _target) ?? (throwIfMissing ? throw new ApplicationException($"Missing Environment Variable: {envVariable}") : string.Empty);
        }

        protected int GetEnvironmentVariableAsInt(string varName)
        {
            var val = GetEnvironmentVariable(varName);
            return Convert.ToInt32(val, CultureInfo.InvariantCulture);
        }

        protected int? GetEnvironmentVariableAsIntNullable(string varName)
        {
            var val = GetEnvironmentVariable(varName);
            return string.IsNullOrWhiteSpace(val) ? null : Convert.ToInt32(val, CultureInfo.InvariantCulture);
        }

        protected bool GetEnvironmentVariableAsBool(string varName, bool throwIfMissing=true)
        {
            return string.Equals(GetEnvironmentVariable(varName, throwIfMissing), "true", StringComparison.InvariantCultureIgnoreCase);
        }

        /// <summary>
        /// Create Uri from a config string containing a full uri
        /// </summary>
        /// <param name="varName"></param>
        /// <returns></returns>
        protected Uri GetEnvironmentVariableAsUri(string varName)
        {
            var val = GetEnvironmentVariable(varName);
            if (string.IsNullOrWhiteSpace(val))
            {
                return null;
            }

            if (!Uri.IsWellFormedUriString(val, UriKind.Absolute))
            {
                throw new InitializationException($"Bad URL found in env variable {varName}: '{val}'.  It must be a valid absolute URL including protocol.");
            }

            return new Uri(val);
        }
    }
}