﻿// ***********************************************************************************************************************
// ChatScraperConfiguration.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class ChatScraperConfiguration : ServiceConfiguration, IChatScraperConfiguration
    {
        public ChatScraperConfiguration(EnvironmentVariableTarget target) : base(target, "CHAT_SCRAPER")
        {
        }

        public Uri ChatServerUrl
        {
            get => GetEnvironmentVariableAsUri("CHATSERVER_URL");
            set => throw new NotSupportedException();
        }

        public string ChatServerUserName
        {
            get => GetEnvironmentVariable("CHATSERVER_USER_NAME");
            set => throw new NotSupportedException();
        }

        public string ChatServerPassword
        {
            get => GetEnvironmentVariable("CHATSERVER_PASSWORD");
            set => throw new NotSupportedException();
        }

        public string ChatServerProxy
        {
            get => GetEnvironmentVariable("CHATSERVER_PROXY");
            set => throw new NotSupportedException();
        }

        public string ChatTestMessageHook
        {
            get => GetEnvironmentVariable("CHAT_TEST_MESSAGE_HOOK");
            set => throw new NotSupportedException();
        }
    }
}
