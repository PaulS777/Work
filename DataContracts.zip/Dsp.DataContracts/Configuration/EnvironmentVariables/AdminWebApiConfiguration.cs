﻿using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables;

public class AdminWebApiConfiguration : ServiceConfiguration, IAdminWebApiConfiguration
{
    public AdminWebApiConfiguration(EnvironmentVariableTarget target) : base(target, "ADMIN_WEBAPI")
    { }

    public bool EnableSso
    {
        get => GetEnvironmentVariableAsBool("ENABLE_SSO");
        set => throw new NotSupportedException();
    }

    public Uri SsoAuthority
    {
        get => GetEnvironmentVariableAsUri("SSO_AUTHORITY");
        set => throw new NotSupportedException();
    }

    public string SsoClientId
    {
        get => GetEnvironmentVariable("SSO_CLIENT_ID");
        set => throw new NotSupportedException();
    }

    public string SsoClientSecret
    {
        get => GetEnvironmentVariable("SSO_CLIENT_SECRET");
        set => throw new NotSupportedException();
    }
}
