﻿// ***********************************************************************************************************************
// AdminWebApi.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class ServiceConfiguration : ConfigurationBase, IServiceConfiguration
    {
        public ServiceConfiguration(EnvironmentVariableTarget target, string prefix) : base(target, prefix)
        {
        }
        public bool RedirectedToAnotherEnvironment 
        {
            get => GetEnvironmentVariableAsBool("REDIRECTEDTOANOTHERENVIRONMENT", false);
            set => throw new NotSupportedException();
        }

        public Uri Uri
        {
            get => GetEnvironmentVariableAsUri("URI");
            set => throw new NotSupportedException();
        }
    }
}
