﻿// ***********************************************************************************************************************
// EnvironmentProvider.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class EnvironmentVariablesProvider : ICommonConfiguration
    {
        private readonly EnvironmentVariableTarget _target;
        public EnvironmentVariablesProvider(EnvironmentVariableTarget target)
        {
            _target = target;
        }
        public string EnvironmentName
        {
            get => Environment.GetEnvironmentVariable("ENVIRONMENT_NAME", _target);
            set => throw new NotSupportedException();
        }

        public string HelpDistribution { get; set; }

        public string HelpDistributionSlack { get; set; }

        public Uri DashboardInstallUrl { get; set; }

        public string DatabaseConnection
        {
            get => Environment.GetEnvironmentVariable("DATABASE_CONNECTION",_target);
            set => throw new NotSupportedException();
        }
        
        public IAdminWebApiConfiguration AdminWebApi
        {
            get => new AdminWebApiConfiguration(_target);
            set => throw new NotSupportedException();
        }
        
        public IServiceConfiguration DataManagementService
        {
            get => new ServiceConfiguration(_target, "DATA_MGMT_SERVICE");
            set => throw new NotSupportedException();
        }
        
        public IPriceFeedServiceConfiguration PriceFeed
        {
            get => new PriceFeedServiceConfiguration(_target);
            set => throw new NotSupportedException();
        }
        
        public IServiceConfiguration PricingService
        {
            get => new ServiceConfiguration(_target, "PRICING_SERVICE");
            set => throw new NotSupportedException();
        }
        
        public IServiceConfiguration FxService 
        { 
            get => new ServiceConfiguration(_target, "FX_SERVICE"); 
            set => throw new NotSupportedException();
        }
        
        public IServiceConfiguration CurvePublisherService
        {
            get => new ServiceConfiguration(_target, "CURVE_PUBLISHER_SERVICE");
            set => throw new NotSupportedException();
        }
        
        public IChatScraperConfiguration ChatScraper
        {
            get => new ChatScraperConfiguration(_target);
            set => throw new NotSupportedException();
        }
        
        public IChatScraperParserConfiguration ChatScraperParser
        {
            get => new ChatScraperParserConfiguration(_target);
            set => throw new NotSupportedException();
        }
        
        public IShopfrontConfiguration ShopfrontService
        {
            get => new ShopfrontConfiguration(_target);
            set => throw new NotSupportedException();
        }
        
        public IWebApiConfiguration WebApi
        {
            get => new WebApiConfiguration(_target);
            set => throw new NotSupportedException();
        }
        
        public IServiceBusConfig ServiceBusApi
        {
            get => new ServiceBusConfiguration(_target);
            set => throw new NotSupportedException();
        }

        public string Options { get; set; }

        public string LogLevel
        {
            get => Environment.GetEnvironmentVariable("LOG_LEVEL", _target);
            set => throw new NotSupportedException();
        }
    }
}
