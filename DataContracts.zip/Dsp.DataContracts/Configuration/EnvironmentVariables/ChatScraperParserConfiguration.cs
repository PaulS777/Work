﻿// ***********************************************************************************************************************
// ChatScraperParserConfiguration.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts.Configuration.EnvironmentVariables
{
    public class ChatScraperParserConfiguration : ServiceConfiguration, IChatScraperParserConfiguration
    {
        public ChatScraperParserConfiguration(EnvironmentVariableTarget target) : base(target, "CHAT_SCRAPER_PARSER")
        {
        }

        public string RootPath
        {
            get => GetEnvironmentVariable("ROOTPATH");
        }

        public string InterpreterPath
        {
            get => GetEnvironmentVariable("INTERPRETERPATH");
        }
    }
}