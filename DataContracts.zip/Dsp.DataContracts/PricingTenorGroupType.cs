﻿namespace Dsp.DataContracts
{
    public enum PricingTenorGroupType
    {
        Daily = 1,
        Monthly = 2
    }
}