﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record FxCurvePipsBuffer : DeletableEntity
    {
        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int FxCurveId { get; init; }

        [JsonProperty]
        [Required]
        [SortedListHasUniqueIds]
        public IList<PipsBufferPeriod> PipsBufferPeriods { get; init; }

        public FxCurvePipsBuffer(int fxCurveId, IEnumerable<PipsBufferPeriod> pipsBufferPeriods, EntityStatus status = EntityStatus.Active) : base(fxCurveId, status)
        {
            FxCurveId = fxCurveId;
            PipsBufferPeriods = pipsBufferPeriods.OrderBy(x => x.StartTime).ThenBy(x => x.IsBusinessDay).ToList();
        }

        public override string ToString()
        {
            return $"{nameof(FxCurveId)}: {FxCurveId}, {nameof(PipsBufferPeriods)}: [{string.Join(",", PipsBufferPeriods)}]";
        }
    }


    [JsonObject]
    public record PipsBufferPeriod
    {
        [JsonProperty]
        [Required]
        public bool IsBusinessDay { get; init; }

        [JsonProperty]
        [Required]
        [Range(typeof(TimeSpan), "00:00:00", "23:59:59")]
        public TimeSpan StartTime { get; init; }

        [JsonProperty]
        [Required]
        public int PipsBuffer { get; init; }

        public PipsBufferPeriod()
        {
        }

        public PipsBufferPeriod(bool isBusinessDay, TimeSpan startTime, int pipsBuffer)
        {
            IsBusinessDay = isBusinessDay;
            StartTime = startTime;
            PipsBuffer = pipsBuffer;
        }

        public override string ToString()
        {
            return $"{nameof(IsBusinessDay)}: {IsBusinessDay}, {nameof(StartTime)}: {StartTime}, {nameof(PipsBuffer)}: {PipsBuffer}";
        }
    }
}