﻿/*====================================================================================
 *
 * WARNING: THIS ENUM FORMS PART OF THE VERSIONED API WITH DSX.
 *
 * Changing it will require a new API version (and potentially filtering new values
 * out of any previous API version to avoid breaking DSX)
 *
 =====================================================================================
*/
using System.Runtime.Serialization;

namespace Dsp.DataContracts
{
    public enum UnitOfMeasure
    {
        None = 0,
        BBL = 1,
        MT = 2,
        GAL = 3,
        M3 = 4,
        [EnumMember(Value = "MWH")]
        MWh = 5
    }
}