﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public class CurveContributionDefinition
    {
        [JsonProperty]
        public LinkedCurve LinkedCurve { get; init; }

        [JsonProperty]
        public double Factor { get; init; }

        public CurveContributionDefinition(LinkedCurve linkedCurve, double factor = 1)
        {
            LinkedCurve = linkedCurve;
            Factor = factor;
        }

        public override string ToString()
        {
            return $"{{{LinkedCurve} Factor:{Factor}}}";
        }
    }
}