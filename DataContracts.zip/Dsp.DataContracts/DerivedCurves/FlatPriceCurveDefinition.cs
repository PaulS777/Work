﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public record FlatPriceCurveDefinition<T> : DerivedCurveDefinitionBase<T> where T : ITenor
    {
        [JsonProperty]
        public LinkedCurve SpreadLinkedCurve { get; init; }

        [JsonProperty]
        public AnchorPoint AnchorPoint { get; init; }

        public FlatPriceCurveDefinition(int id, string name, string description, int priceCurveDefinitionId, int publisherId, LinkedCurve spreadCurveDefinitionId,
            AnchorPoint anchorPoint)
            : base(id, name, description, priceCurveDefinitionId, publisherId)
        {
            SpreadLinkedCurve = spreadCurveDefinitionId;
            AnchorPoint = anchorPoint;
        }

        public override string ToString()
        {
            return $"{base.ToString()} [Flat Definition: Spread Definition: {SpreadLinkedCurve}, {AnchorPoint}]";
        }
    }
}