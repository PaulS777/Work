﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public class CurvePartition<T> where T : ITenor
    {
        [JsonProperty]
        public T Start { get; init; }

        [JsonProperty]
        public CurveContributionDefinition CurveContributionDefinition { get; init; }

        public CurvePartition(T start, CurveContributionDefinition contribution)
        {
            Start = start;
            CurveContributionDefinition = contribution;
        }

        public override string ToString()
        {
            return $"[{Start} {CurveContributionDefinition}]";
        }
    }
}