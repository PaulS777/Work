﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public record PartitionedCurveDefinition<T> : DerivedCurveDefinitionBase<T> where T : ITenor
    {
        [JsonProperty]
        public IReadOnlyList<CurvePartition<T>> Partitions { get; init; }

        public PartitionedCurveDefinition(PartitionedCurveDefinition<T> other, IEnumerable<CurvePartition<T>> partitions) 
            : this(other.Id, other.Name, other.Description, other.PriceCurveDefinitionId, other.PublisherId, partitions)
        {}

        [JsonConstructor]
        public PartitionedCurveDefinition(int id, string name, string description, int priceCurveDefinitionId, int publisherId, IEnumerable<CurvePartition<T>> partitions) 
            : base(id, name, description, priceCurveDefinitionId, publisherId)
        {
            var comparer = TenorComparer.GetInstance<T>();
            
            Partitions = partitions.Distinct().OrderBy(x => x.Start, comparer).ToList();

            var duplicates = string.Join(", ", Partitions.GroupBy(x => x.Start).Where(g => g.Count() > 1).Select(z => z.Key));

            if (!string.IsNullOrEmpty(duplicates))
            {
                throw new ArgumentException($"Partition start dates are not unique: {duplicates}.", nameof(partitions));
            }
        }

        public override string ToString()
        {
            return $"{base.ToString()} [Partition Definition: {string.Join(" ", Partitions.Select(x => x.ToString()))}]";
        }
    }
}