﻿using System.Collections.Generic;
using System.Linq;
using Dsp.DataContracts.Exceptions;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public record CompoundCurveDefinition<T> : DerivedCurveDefinitionBase<T> where T : ITenor
    {
        [JsonProperty]
        public IReadOnlyList<ProfiledCurveContributionDefinition> ContributionDefinitions { get; init; }

        public CompoundCurveDefinition(int id, string name, string description, int priceCurveDefinitionId, int publisherId, 
            IReadOnlyList<ProfiledCurveContributionDefinition> contributionDefinitions)
            : base(id, name, description, priceCurveDefinitionId, publisherId)
        {
            if (contributionDefinitions?.Any(x=>x?.LinkedCurve.Id == id) ?? false)
            {
                throw new InitializationException($"Invalid Compound Curve Definition - Curve {id} is self-referential");
            }
            ContributionDefinitions = contributionDefinitions;
        }

        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(ContributionDefinitions)}: {ContributionDefinitions.Count}";
        }
    }
}