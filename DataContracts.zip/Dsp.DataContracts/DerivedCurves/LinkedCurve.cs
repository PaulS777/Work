﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public struct LinkedCurve
    {
        [JsonProperty]
        public int Id { get; }

        [JsonProperty]
        public PriceCurveDefinitionType DefinitionType { get; }

        [JsonIgnore]
        public bool IsDerivedCurve => DefinitionType == PriceCurveDefinitionType.DerivedCurve;

        [JsonConstructor]
        public LinkedCurve(int id, PriceCurveDefinitionType definitionType)
        {
            Id = id;
            DefinitionType = definitionType;
        }

        public bool Equals(LinkedCurve other)
        {
            return Id == other.Id && DefinitionType == other.DefinitionType;
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            return obj is LinkedCurve id && Equals(id);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Id * 397) ^ (int) DefinitionType;
            }
        }

        public static bool operator ==(LinkedCurve left, LinkedCurve right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(LinkedCurve left, LinkedCurve right)
        {
            return !left.Equals(right);
        }

        public override string ToString()
        {
            return $"{DefinitionType} {nameof(Id)}: {Id}";
        }
    }
}