﻿namespace Dsp.DataContracts.DerivedCurves
{
    public enum CustomCompilerType
    {
        None,
        FrontlineBrent,
        BrentOutright
    }
}
