﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves;

public sealed class GenericCurvePoint
{
    [JsonProperty]
    [Required]
    public string TenorKey { get; }

    [JsonProperty]
    [Required]
    public double? Value { get; }

    public GenericCurvePoint(string tenorKey, double value)
    {
        TenorKey = tenorKey;
        Value = value;
    }

    [JsonConstructor]
    public GenericCurvePoint(string tenorKey, double? value)
    {
        TenorKey = tenorKey;
        Value = value;
    }

    public override string ToString()
    {
        return $"{TenorKey} {Value}";
    }
}