﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public class CurveContributionProfile
    {
        [JsonProperty]
        public int OneBasedIndex { get; init; }

        [JsonIgnore]
        public int Index => OneBasedIndex - 1;

        [JsonProperty]
        public TenorType DurationType { get; init; }

        public CurveContributionProfile(int oneBasedIndex, TenorType durationType)
        {
            OneBasedIndex = oneBasedIndex;
            DurationType = durationType;
        }
    }
}