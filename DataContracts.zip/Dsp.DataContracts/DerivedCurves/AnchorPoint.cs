﻿using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public class AnchorPoint
    {
        [JsonProperty]
        public int OneBasedIndex { get; init; }

        [JsonIgnore]
        public int Index => OneBasedIndex - 1;

        [JsonProperty]
        public IReadOnlyList<CurveContributionDefinition> CurveContributions { get; init; }

        public AnchorPoint(int oneBasedIndex, IReadOnlyList<CurveContributionDefinition> curveContributions = null)
        {
            OneBasedIndex = oneBasedIndex;
            CurveContributions = curveContributions;
        }

        public override string ToString()
        {
            return $"[Anchor Point: OneBasedIndex: {OneBasedIndex}, [Curve Contributions: {string.Join(",", CurveContributions.Select(x => x.ToString()))}]]";
        }
    }
}