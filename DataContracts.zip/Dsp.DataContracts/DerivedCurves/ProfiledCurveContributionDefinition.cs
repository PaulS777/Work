﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Dsp.DataContracts.DerivedCurves
{
    [JsonObject]
    public class ProfiledCurveContributionDefinition : CurveContributionDefinition
    {
        private static readonly IReadOnlyList<CurveContributionProfile> Default = new List<CurveContributionProfile>{new CurveContributionProfile(1, TenorType.Month)};

        [JsonProperty]
        public IReadOnlyList<CurveContributionProfile> Profile { get; init; }

        public ProfiledCurveContributionDefinition(LinkedCurve curveDefinitionId, double factor = 1, IReadOnlyList<CurveContributionProfile> profile = null) : base(curveDefinitionId, factor)
        {
            Profile = profile ?? Default;
        }
    }
}