﻿namespace Dsp.DataContracts.DerivedCurves
{
    public static class Utils
    {
        public static CurvePoint<TT> MakeCurvePoint<TT>(TT tenor, double value) where TT : ITenor
        {
            return new CurvePoint<TT>(tenor, value);
        }
        public static CurvePoint<TT> MakeCurvePoint<TT>(TT tenor, double? value) where TT : ITenor
        {
            return new CurvePoint<TT>(tenor, value);
        }
    }
}