﻿// /***********************************************************************************************************************
// BlockingConcurrentQueue.cs
// 
// (c) 2022 - Shell.  Created by Hughes, Tim DW SITI-PTIY/BBJ, 2022/05/18.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System.Collections.Concurrent;

namespace Dsp.DataContracts
{
    /// <summary>
    /// A thread safe queue that blocks on enqueue/dequeue operations.  This avoids the need for processing threads manually wait on idle.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class BlockingConcurrentQueue<T> : BlockingCollection<T>
    {
        /// <summary>
        /// Initializes a new instance of the ProducerConsumerQueue, Use Add and TryAdd for Enqueue and TryEnqueue and Take and TryTake for Dequeue and TryDequeue functionality
        /// </summary>
        public BlockingConcurrentQueue() : base(new ConcurrentQueue<T>())
        { }

        /// <summary>
        /// Initializes a new instance of the ProducerConsumerQueue, Use Add and TryAdd for Enqueue and TryEnqueue and Take and TryTake for Dequeue and TryDequeue functionality
        /// </summary>
        /// <param name="maxSize"></param>
        public BlockingConcurrentQueue(int maxSize) : base(new ConcurrentQueue<T>(), maxSize)
        { }

        public bool TryEnqueue(T item, int timeoutMSec = -1)
        {
            return TryAdd(item, timeoutMSec);
        }

        public bool TryDequeue(out T item, int timeoutMSec = -1)
        {
            return TryTake(out item, timeoutMSec);
        }
    }
}