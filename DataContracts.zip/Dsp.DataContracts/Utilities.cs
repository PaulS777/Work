﻿using System;
using System.Linq;

namespace Dsp.DataContracts;

public static class Utilities
{
    /// <summary>
    /// Sanitise string to prevent the possibility of malicious injection into logs
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    public static string Sanitise(this string message)
    {
        return SanitiseString(message);
    }

    /// <summary>
    /// Sanitise string to prevent the possibility of malicious injection into logs
    /// </summary>
    /// <param name="message"></param>
    /// <returns></returns>
    public static string SanitiseString(string message)
    {
        return message?.Replace('\n', '_').Replace('\r', '_');
    }

    /// <summary>
    /// returns null if whitespace or null
    /// </summary>
    /// <param name="s"></param>
    /// <returns></returns>
    public static string NullIfSpaces(this string s)
    {
        return string.IsNullOrWhiteSpace(s) ? null : s;
    }

    /// <summary>
    /// checks double is non-zero, avoiding exact comparison
    /// </summary>
    /// <param name="d"></param>
    /// <returns></returns>
    public static int DoubleToBit(this double d)
    {
        return Math.Abs(d) > double.Epsilon ? 1 : 0;
    }

    /// <summary>
    /// DateOnly to Utc DateTime
    /// </summary>
    /// <param name="d"></param>
    /// <returns></returns>
    public static DateTime ToUtcDateTime(this DateOnly d)
    {
        return d.ToDateTime(new TimeOnly(0, 0), DateTimeKind.Utc);
    }

    /// <summary>
    /// DateTime to DateOnly
    /// </summary>
    /// <param name="dt"></param>
    /// <returns></returns>
    public static DateOnly ToDateOnly(this DateTime dt)
    {
        return DateOnly.FromDateTime(dt);
    }

    /// <summary>
    /// Math.Max equivalent for DateTimes
    /// </summary>
    /// <param name="d1"></param>
    /// <param name="d2"></param>
    /// <returns></returns>
    public static DateTime Max(DateTime d1, DateTime d2)
    {
        return d1 > d2 ? d1 : d2;
    }

    /// <summary>
    /// Math.Max equivalent for nullable DateTimes
    /// </summary>
    /// <param name="d1"></param>
    /// <param name="d2"></param>
    /// <returns></returns>
    public static DateTime? Max(this DateTime? d1, DateTime? d2)
    {
        if (d1 == null && d2 != null)
        {
            return d2;
        }

        if (d2 == null && d1 != null)
        {
            return d1;
        }

        return d2 > d1 ? d2 : d1;
    }

    /// <summary>
    /// Math.Min equivalent for nullable DateTimes
    /// </summary>
    /// <param name="d1"></param>
    /// <param name="d2"></param>
    /// <returns></returns>
    public static DateTime? Min(this DateTime? d1, DateTime? d2)
    {
        if (d1 == null || d2 == null)
        {
            return null;
        }

        return d2 < d1 ? d2 : d1;
    }

    /// <summary>
    /// First calendar day of the passed month
    /// </summary>
    /// <param name="date"></param>
    /// <returns></returns>
    public static DateTime FirstDayOfMonth(this DateTime date)
    {
        return new DateTime(date.Year, date.Month, 1, 0, 0, 0, DateTimeKind.Utc);
    }

    /// <summary>
    /// Last calendar day of the passed month
    /// </summary>
    /// <param name="date"></param>
    /// <returns></returns>
    public static DateTime LastDayOfMonth(this DateTime date)
    {
        return date.FirstDayOfMonth().AddMonths(1).AddDays(-1);
    }

    /// <summary>
    /// Implements a standard IN function, i.e. allows tests like if( x.In(1, 2, 3) ) { ... }
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="value">value to test</param>
    /// <param name="choices">values to compare against</param>
    /// <returns>true if value is any one of the choices</returns>
    public static bool In<T>(this T value, params T[] choices)
    {
        return choices.Contains(value);
    }

    /// <summary>
    /// Implements the reverse of a standard IN function, i.e. allows tests like if( x.NotIn(1, 2, 3) ) { ... }
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="value">value to test</param>
    /// <param name="choices">values to compare against</param>
    /// <returns>true if value is not any of the choices</returns>
    public static bool NotIn<T>(this T value, params T[] choices)
    {
        return !choices.Contains(value);
    }

    private const double MinNonZero = 10 ^ -24;

    /// <summary>
    /// Considers a double value to be zero if its absolute value is smaller than 10^-24
    /// </summary>
    /// <param name="value"></param>
    /// <returns>true if "zero"</returns>
    public static bool IsZero(this double value)
    {
        return Math.Abs(value) < MinNonZero;
    }

    /// <summary>
    /// Considers a double value to be zero if its absolute value is smaller than 10^-24
    /// </summary>
    /// <param name="value"></param>
    /// <returns>true if not "zero"</returns>
    public static bool IsNotZero(this double value)
    {
        return Math.Abs(value) >= MinNonZero;
    }
}