﻿using System;
using System.Collections.Generic;
using TenorTypeEnum = Dsp.DataContracts.TenorType;

// ReSharper disable UnusedParameter.Local

namespace Dsp.DataContracts
{
    public struct HalfYearTenor: IComparable<HalfYearTenor>, ITenor
    {
        public static readonly IComparer<HalfYearTenor> ComparerInstance = new HalfYearTenorComparer();
        public static readonly ITenorConverter<HalfYearTenor> ConverterInstance = new HalfYearTenorConverter();

        public readonly short Year;
        public readonly short Semester;

        public HalfYearTenor(short year, short semester)
        {
            Year = year;
            Semester = semester;
            Validate();
        }

        public HalfYearTenor(int value)
        {
            //20190100
            Year = (short) (value / 10000 % 10000);
            Semester = (short) (value / 100 % 100);
            Validate();
        }

        public HalfYearTenor(string token)
        {
            var tenorStrings = token.Split('H');
            Year = Convert.ToInt16(tenorStrings[0]);
            Semester = Convert.ToInt16(tenorStrings[1]);
            Validate();
        }

        private void Validate()
        {
            if(Year < 2000 || Year > 3000)
            {
                throw new ArgumentException("Year must be between 2000 and 3000");
            }

            if (Semester < 1 || Semester > 2)
            {
                throw new ArgumentException("Semester must be 1 or 2");
            }
        }

        public bool Equals(HalfYearTenor other)
        {
            return Year == other.Year && Semester == other.Semester;
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            return obj is HalfYearTenor halfYearTenor && Equals(halfYearTenor);
        }

        public int CompareTo(ITenor other)
        {
            var typeComparison = TenorType().CompareTo(other.TenorType());
            return typeComparison != 0 ? typeComparison : CompareTo((HalfYearTenor)other);
        }

        public int CompareTo(HalfYearTenor other)
        {
            var yearComparison = Year.CompareTo(other.Year);
            return yearComparison != 0 ? yearComparison : Semester.CompareTo(other.Semester);
        }

        public static bool operator <(HalfYearTenor left, HalfYearTenor right)
        {
            return left.CompareTo(right) < 0;
        }

        public static bool operator >(HalfYearTenor left, HalfYearTenor right)
        {
            return left.CompareTo(right) > 0;
        }

        public static bool operator <=(HalfYearTenor left, HalfYearTenor right)
        {
            return left.CompareTo(right) <= 0;
        }

        public static bool operator >=(HalfYearTenor left, HalfYearTenor right)
        {
            return left.CompareTo(right) >= 0;
        }

        public static bool operator ==(HalfYearTenor left, HalfYearTenor right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(HalfYearTenor left, HalfYearTenor right)
        {
            return !left.Equals(right);
        }

        public string Key => $"{(int)TenorType()}{ConvertToInt()}";

        public int ConvertToInt()
        {
            return Year * 10000 + Semester * 100;
        }

        public TenorTypeEnum TenorType()
        {
            return TenorTypeEnum.HalfYear;
        }

        public DateTime StartDate()
        {
            return new DateTime(Year,Semester * 6 - 5,1);
        }

        public DateTime EndDate()
        {
            return StartDate().AddMonths(6).AddDays(-1);
        }

        public static HalfYearTenor ConvertFromInt(int value)
        {
            return new HalfYearTenor(value);
        }

        public override string ToString()
        {
            return $"{Year}H{Semester}";
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Year * 397) ^ Semester;
            }
        }

        private sealed class HalfYearTenorComparer : IComparer<HalfYearTenor>
        {
            public int Compare(HalfYearTenor x, HalfYearTenor y)
            {
                return x.CompareTo(y);
            }
        }

        private sealed class HalfYearTenorConverter: ITenorConverter<HalfYearTenor>
        {
            public HalfYearTenor FromInt(int token)
            {
                return new HalfYearTenor(token);
            }

            public int ToInt(HalfYearTenor tenor)
            {
                return tenor.ConvertToInt();
            }

            /// <inheritdoc />
            public HalfYearTenor FromDate(DateTime date)
            {
                return new HalfYearTenor((short)date.Year, (short)(date.Month <=6 ? 1 : 2));
            }

            /// <inheritdoc />
            public DateTime ToDate(HalfYearTenor tenor)
            {
                return tenor.StartDate();
            }
        }
    }
}