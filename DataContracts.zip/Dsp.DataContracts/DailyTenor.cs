﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json;
using TenorTypeEnum = Dsp.DataContracts.TenorType;

namespace Dsp.DataContracts
{
    [Serializable][JsonObject]
    public struct DailyTenor: IComparable<DailyTenor>, ITenor
    {
        public static readonly IComparer<DailyTenor> ComparerInstance = new DailyTenorComparer();
        public static readonly ITenorConverter<DailyTenor> ConverterInstance = new DailyTenorConverter();

        private const string Format = "yyyyMMdd";

        public DateTime Date  { get; }

        [JsonConstructor]
        public DailyTenor(DateTime date)
        {
            Date = date.Date;
        }

        public DailyTenor(int value):
            this(new DateTime(value / 10000 % 10000, value / 100 % 100, value % 100))
        {}

        public DailyTenor(string token): 
            this(DateTime.ParseExact(token, Format, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal).Date)
        {}

        public DailyTenor(int year, int month, int day):
            this(new DateTime(year, month, day, 0, 0, 0, DateTimeKind.Utc))
         {}

        public bool Equals(DailyTenor other)
        {
            return Date.Equals(other.Date);
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            return obj is DailyTenor other && Equals(other);
        }

        public int CompareTo(ITenor other)
        {
            var typeComparison = TenorType().CompareTo(other.TenorType());
            return typeComparison != 0 ? typeComparison : CompareTo((DailyTenor)other);
        }

        public int CompareTo(DailyTenor other)
        {
            return Date.CompareTo(other.Date);
        }

        public static bool operator <(DailyTenor left, DailyTenor right)
        {
            return left.CompareTo(right) < 0;
        }

        public static bool operator >(DailyTenor left, DailyTenor right)
        {
            return left.CompareTo(right) > 0;
        }

        public static bool operator <=(DailyTenor left, DailyTenor right)
        {
            return left.CompareTo(right) <= 0;
        }

        public static bool operator >=(DailyTenor left, DailyTenor right)
        {
            return left.CompareTo(right) >= 0;
        }

        public static bool operator ==(DailyTenor left, DailyTenor right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(DailyTenor left, DailyTenor right)
        {
            return !left.Equals(right);
        }

        public string Key => $"{(int)TenorType()}{ConvertToInt()}";

        public int ConvertToInt()
        {
            return Date.Year * 10000 + Date.Month*100 + Date.Day;
        }

        public TenorTypeEnum TenorType()
        {
            return TenorTypeEnum.Day;
        }

        public DateTime StartDate()
        {
            return Date;
        }

        public DateTime EndDate()
        {
            return Date;
        }
        
        public static DailyTenor ConvertFromInt(int value)
        {
            return new DailyTenor(value);
        }

        public override string ToString()
        {
            return Date.ToString(Format);
        }

        public override int GetHashCode()
        {
            return Date.GetHashCode();
        }

        private sealed class DailyTenorComparer : IComparer<DailyTenor>
        {
            public int Compare(DailyTenor x, DailyTenor y)
            {
                return x.CompareTo(y);
            }
        }

        private sealed class DailyTenorConverter: ITenorConverter<DailyTenor>
        {
            public DailyTenor FromInt(int token)
            {
                return new DailyTenor(token);
            }

            public int ToInt(DailyTenor tenor)
            {
                return tenor.ConvertToInt();
            }

            /// <inheritdoc />
            public DailyTenor FromDate(DateTime date)
            {
                return new DailyTenor(date);
            }

            /// <inheritdoc />
            public DateTime ToDate(DailyTenor tenor)
            {
                return tenor.StartDate();
            }
        }
    }
}