﻿namespace Dsp.DataContracts
{
    public class UserChatTenorSelection
    {
        public int UserId { get; set; }
        public int PriceCurveDefinitionId { get; set; }
        public string Tenor { get; set; }

        public UserChatTenorSelection()
        {}

        public UserChatTenorSelection(int userId, int priceCurveDefinitionId, ITenor tenor) : this(userId, priceCurveDefinitionId, tenor.Key)
        {}

        public UserChatTenorSelection(int userId, int priceCurveDefinitionId, string tenor)
        {
            UserId = userId;
            PriceCurveDefinitionId = priceCurveDefinitionId;
            Tenor = tenor;
        }

        public override string ToString()
        {
            return $"{nameof(UserId)}: {UserId}, {nameof(PriceCurveDefinitionId)}: {PriceCurveDefinitionId}, {nameof(Tenor)}: {Tenor}";
        }
    }
}