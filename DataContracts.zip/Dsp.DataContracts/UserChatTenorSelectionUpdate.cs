﻿namespace Dsp.DataContracts
{
    /// <summary>
    /// Wrapper around User to allow different authorisation for ChatTenorSelection updates
    /// </summary>
    public class UserChatTenorSelectionUpdate : IIdentifiable
    {
        public int Id => User.Id;
        public User User { get; init; }

        public UserChatTenorSelectionUpdate(User user)
        {
            User = user;
        }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(User)}: {User}";
        }
    }
}