﻿using System;
using System.Collections.Generic;
using TenorTypeEnum = Dsp.DataContracts.TenorType;

// ReSharper disable UnusedParameter.Local

namespace Dsp.DataContracts
{
    public struct QuarterlyTenor: IComparable<QuarterlyTenor>, ITenor
    {
        public static readonly IComparer<QuarterlyTenor> ComparerInstance = new QuarterlyTenorComparer();
        public static readonly ITenorConverter<QuarterlyTenor> ConverterInstance = new QuarterlyTenorConverter();

        public readonly short Year;
        public readonly short Quarter;

        public QuarterlyTenor(short year, short quarter)
        {
            Year = year;
            Quarter = quarter;
            Validate();
        }

        public QuarterlyTenor(int value)
        {
            //20190100
            Year = (short) (value / 10000 % 10000);
            Quarter = (short) (value / 100 % 100);
            Validate();
        }

        public QuarterlyTenor(string token)
        {
            var tenorStrings = token.Split('Q');
            Year = Convert.ToInt16(tenorStrings[0]);
            Quarter = Convert.ToInt16(tenorStrings[1]);
            Validate();
        }

        private void Validate()
        {
            if(Year < 2000 || Year > 3000)
            {
                throw new ArgumentException("Year must be between 2000 and 3000");
            }

            if (Quarter < 1 || Quarter > 4)
            {
                throw new ArgumentException("Quarter outside [1, 4] range");
            }
        }

        public bool Equals(QuarterlyTenor other)
        {
            return Year == other.Year && Quarter == other.Quarter;
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            return obj is QuarterlyTenor quarterTenor && Equals(quarterTenor);
        }

        public int CompareTo(ITenor other)
        {
            var typeComparison = TenorType().CompareTo(other.TenorType());
            return typeComparison != 0 ? typeComparison : CompareTo((QuarterlyTenor)other);
        }

        public int CompareTo(QuarterlyTenor other)
        {
            var yearComparison = Year.CompareTo(other.Year);
            return yearComparison != 0 ? yearComparison : Quarter.CompareTo(other.Quarter);
        }


        public static bool operator <(QuarterlyTenor left, QuarterlyTenor right)
        {
            return left.CompareTo(right) < 0;
        }

        public static bool operator >(QuarterlyTenor left, QuarterlyTenor right)
        {
            return left.CompareTo(right) > 0;
        }

        public static bool operator <=(QuarterlyTenor left, QuarterlyTenor right)
        {
            return left.CompareTo(right) <= 0;
        }

        public static bool operator >=(QuarterlyTenor left, QuarterlyTenor right)
        {
            return left.CompareTo(right) >= 0;
        }

        public static bool operator ==(QuarterlyTenor left, QuarterlyTenor right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(QuarterlyTenor left, QuarterlyTenor right)
        {
            return !left.Equals(right);
        }

        public string Key => $"{(int)TenorType()}{ConvertToInt()}";

        public int ConvertToInt()
        {
            return Year * 10000 + Quarter * 100;
        }

        public TenorTypeEnum TenorType()
        {
            return TenorTypeEnum.Quarter;
        }

        public DateTime StartDate()
        {
            return new DateTime(Year, Quarter * 3 - 2, 1);
        }

        public DateTime EndDate()
        {
            return StartDate().AddMonths(3).AddDays(-1);
        }

        public static QuarterlyTenor ConvertFromInt(int value)
        {
            return new QuarterlyTenor(value);
        }

        public override string ToString()
        {
            return $"{Year}Q{Quarter}";
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Year * 397) ^ Quarter;
            }
        }

        private sealed class QuarterlyTenorComparer : IComparer<QuarterlyTenor>
        {
            public int Compare(QuarterlyTenor x, QuarterlyTenor y)
            {
                return x.CompareTo(y);
            }
        }

        private sealed class QuarterlyTenorConverter: ITenorConverter<QuarterlyTenor>
        {
            public QuarterlyTenor FromInt(int token)
            {
                return new QuarterlyTenor(token);
            }

            public int ToInt(QuarterlyTenor tenor)
            {
                return tenor.ConvertToInt();
            }

            /// <inheritdoc />
            public QuarterlyTenor FromDate(DateTime date)
            {
                return new QuarterlyTenor((short)date.Year, (short)((date.Month / 3) + 1));
            }

            /// <inheritdoc />
            public DateTime ToDate(QuarterlyTenor tenor)
            {
                return tenor.StartDate();
            }
        }
    }
}