﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record Calendar : DeletableEntity
    {
        [JsonProperty] public string Code { get; init; }

        [JsonProperty] public string Description { get; init; }
        [JsonProperty] public string CountyCode { get; init; }
        [JsonProperty] public string CountryCode { get; init; }
        [JsonProperty] public string HolidaysToAdd { get; init; }
        [JsonProperty] public bool AutoPopulate { get; init; }

        public List<DateTime> Holidays { get; init; } = [];

        public Calendar() : base(-1, EntityStatus.Active)
        { }

        public Calendar(int id, string code, string description, string countyCode, string countryCode, string holidaysToAdd, bool autoPopulate, List<DateTime> holidays)
            : this(id, EntityStatus.Active, code, description, countyCode, countryCode, holidaysToAdd, autoPopulate, holidays)
        { }

        public Calendar(int id,
            EntityStatus status,
            string code,
            string description,
            string countyCode,
            string countryCode,
            string holidaysToAdd,
            bool autoPopulate,
            List<DateTime> holidays) : base(id,
            status)
        {
            Code = code;
            Description = description;
            CountyCode = countyCode;
            CountryCode = countryCode;
            HolidaysToAdd = holidaysToAdd;
            AutoPopulate = autoPopulate;
            Holidays = holidays;
        }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Code)}: {Code}, {nameof(Description)}: {Description}, Holidays: {Holidays.Count}, {nameof(CountryCode)}: {CountryCode}, {nameof(CountyCode)}: {
                CountyCode}";
        }
    }

    [JsonObject]
    public class CalendarHoliday : IIdentifiable
    {
        public int Id => CalendarId;

        [JsonProperty] public int CalendarId { get; init; }

        [JsonProperty] public DateTime Holiday { get; init; }

        public CalendarHoliday()
        {
        }

        public CalendarHoliday(int calendarId, DateTime holiday)
        {
            CalendarId = calendarId;
            Holiday = holiday;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(CalendarId)}: {CalendarId}, {nameof(Holiday)}: {Holiday}";
        }
    }
}