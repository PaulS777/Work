﻿using System;
using Newtonsoft.Json;

namespace Dsp.DataContracts.JsonConverters
{
    /// <summary>
    /// ITenor converter - NB This serializes/deserializes using the KEY field so it can differentiate between the TenorTypes - not the same as the individual tenor converters below.
    /// </summary>
    public class TenorJsonConverter : JsonConverter<ITenor>
    {
        public override void WriteJson(JsonWriter writer, ITenor value, JsonSerializer serializer)
        {
            writer.WriteValue(value.Key);
        }

        public override ITenor ReadJson(JsonReader reader, Type objectType, ITenor existingValue, bool hasExistingValue, JsonSerializer serializer)
        {
            return TenorConverter.CreateFromKey((string)reader.Value);
        }
    }

    /// <summary>
    /// Period-specific Tenor converter - NB This serializes/deserializes using the ToString() method so it CANNOT differentiate between different TenorTypes.
    /// These methods retained for legacy reasons, in order to preserve the date formatting passed out in the web API, e.g. "Oct19".
    /// </summary>
    public abstract class TenorJsonConverter<T> : JsonConverter<T> where T: ITenor
    {
        public override void WriteJson(JsonWriter writer, T value, JsonSerializer serializer)
        {
            writer.WriteValue(value.ToString());
        }
    }

    public class DailyTenorConverter : TenorJsonConverter<DailyTenor>
    {
        public override DailyTenor ReadJson(JsonReader reader, Type objectType, DailyTenor existingValue, bool hasExistingValue,
            JsonSerializer serializer)
        {
            return new DailyTenor((string)reader.Value);
        }
    }

    public class WeeklyTenorConverter : TenorJsonConverter<WeeklyTenor>
    {
        public override WeeklyTenor ReadJson(JsonReader reader, Type objectType, WeeklyTenor existingValue, bool hasExistingValue,
            JsonSerializer serializer)
        {
            return new WeeklyTenor((string)reader.Value);
        }
    }

    public class MonthlyTenorJsonConverter : TenorJsonConverter<MonthlyTenor>
    {
        public override MonthlyTenor ReadJson(JsonReader reader, Type objectType, MonthlyTenor existingValue, bool hasExistingValue, JsonSerializer serializer)
        {
            return new MonthlyTenor((string)reader.Value);
        }
    }

    public class QuarterlyTenorJsonConverter : TenorJsonConverter<QuarterlyTenor>
    {
        public override QuarterlyTenor ReadJson(JsonReader reader, Type objectType, QuarterlyTenor existingValue, bool hasExistingValue,
            JsonSerializer serializer)
        {
            return new QuarterlyTenor((string)reader.Value);
        }
    }

    public class HalfYearTenorJsonConverter : TenorJsonConverter<HalfYearTenor>
    {
        public override HalfYearTenor ReadJson(JsonReader reader, Type objectType, HalfYearTenor existingValue, bool hasExistingValue,
            JsonSerializer serializer)
        {
            return new HalfYearTenor((string)reader.Value);
        }
    }

    public class AnnualTenorJsonConverter : TenorJsonConverter<AnnualTenor>
    {
        public override AnnualTenor ReadJson(JsonReader reader, Type objectType, AnnualTenor existingValue, bool hasExistingValue,
            JsonSerializer serializer)
        {
            return new AnnualTenor((string)reader.Value);
        }
    }
}
