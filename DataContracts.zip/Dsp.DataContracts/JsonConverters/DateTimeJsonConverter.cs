﻿using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.JsonConverters
{
    public class DateTimeJsonConverter : IsoDateTimeConverter
    {
        public DateTimeJsonConverter()
        {
            DateTimeFormat = "yyyyMMdd'T'HH':'mm':'ss.FFFFFFFK";
        }
    }
}
