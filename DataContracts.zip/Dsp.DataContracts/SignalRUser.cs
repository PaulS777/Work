﻿namespace Dsp.DataContracts
{

    public class SignalRUser : IIdentifiable
    {
        public string ConnectionId { get; }

        public int Id { get; }

        public string UserName { get; }

        public WebSocketClientType ClientType { get; }

        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public string ClientVersion { get; }

        public SignalRUser(string connectionId, int id, string userName, WebSocketClientType clientType, string clientVersion)
        {
            ConnectionId = connectionId;
            Id = id;
            UserName = userName;
            ClientType = clientType;
            ClientVersion = clientVersion;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(ConnectionId)}: {ConnectionId}, {nameof(UserName)}: {UserName}, {nameof(ClientType)}: {ClientType}, {nameof(ClientVersion)}: {ClientVersion}";
        }
    }
}
