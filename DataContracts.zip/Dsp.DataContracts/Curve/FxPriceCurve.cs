﻿// /***********************************************************************************************************************
// FxPriceCurve.cs
// 
// (c) 2022 - Shell.  Created by Hughes, Tim DW SITI-PTIY/BBJ, 2022/07/19.
// ------------------------------------------------------------------------------------------------------------------------
// Purpose:
// 
// Usage Notes:
// 
// ***********************************************************************************************************************/

using System;
using Dsp.DataContracts.DerivedCurves;

namespace Dsp.DataContracts.Curve
{
    public class FxPriceCurve : PriceCurveBase
    {
        public FxPriceCurve(int id,
            string productName,
            int publisherId,
            string publisher,
            DateTime timestamp,
            bool tradeable,
            ValidityIndicator validity,
            TenorPrices<DailyTenor> dailyPrices,
            TenorPrices<WeeklyTenor> weeklyPrices,
            TenorPrices<MonthlyTenor> monthlyPrices,
            TenorPrices<QuarterlyTenor> quarterlyPrices,
            TenorPrices<HalfYearTenor> halfYearPrices,
            TenorPrices<AnnualTenor> annualPrices,
            PricingFailure pricingFailure = null) : 
            base(id,
            productName,
            publisherId,
            publisher,
            timestamp,
            tradeable,
            validity,
            dailyPrices, 
            weeklyPrices, 
            monthlyPrices, 
            quarterlyPrices, 
            halfYearPrices,
            annualPrices, 
            pricingFailure)
        {
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}";
        }
    }
}