﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.JsonConverters;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record TenorPremium
    {
        [JsonProperty, JsonConverter(typeof(TenorJsonConverter))]
        [Required]
        public ITenor Tenor { get; init; }

        [JsonProperty]
        [Required]
        public double BidMargin { get; init; }

        [JsonProperty]
        [Required]
        public double AskMargin { get; init; }

        public TenorPremium()
        {
        }

        public TenorPremium(ITenor tenor, double bidMargin, double askMargin)
        {
            Tenor = tenor;
            BidMargin = bidMargin;
            AskMargin = askMargin;
        }

        public override string ToString()
        {
            return $"{{{Tenor}: {BidMargin}/{AskMargin}}}";
        }

        public static int GetHashCode(TenorPremium obj)
        {
            unchecked
            {
                var hashCode = (obj.Tenor != null ? obj.Tenor.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ obj.BidMargin.GetHashCode();
                hashCode = (hashCode * 397) ^ obj.AskMargin.GetHashCode();
                return hashCode;
            }
        }
    }
}