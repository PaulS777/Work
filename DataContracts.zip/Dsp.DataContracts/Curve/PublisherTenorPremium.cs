﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record PublisherTenorPremium : DeletableEntity
    {
        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int PriceCurveId { get; init; }

        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int PublisherId { get; init; }

        [JsonProperty]
        [Required]
        [SortedListHasUniqueIds]
        public IList<TenorPremium> TenorPremiums { get; init; }

        // for testing/builders only
        public PublisherTenorPremium() : base(int.MinValue, EntityStatus.Active)
        { }

        public PublisherTenorPremium(int id, int priceCurveId, int publisherId, IEnumerable<TenorPremium> tenorPremiums, EntityStatus status = EntityStatus.Active) : base(id, status)
        {
            PriceCurveId = priceCurveId;
            PublisherId = publisherId;
            TenorPremiums = tenorPremiums.OrderBy(x => x.Tenor).ToList();
        }

        public PublisherTenorPremium(int priceCurveId, int publisherId) : this(priceCurveId * -10000 + publisherId, priceCurveId, publisherId, [])
        {}

        /// <inheritdoc />
        public virtual bool Equals(PublisherTenorPremium other)
        {
            if (other is null)
            {
                return false;
            }

            if (ReferenceEquals(this, other))
            {
                return true;
            }

            return Id == other.Id && PriceCurveId == other.PriceCurveId && PublisherId == other.PublisherId && TenorPremiums.Intersect(other.TenorPremiums).Count() == TenorPremiums.Count;
        }

        /// <inheritdoc />
        public override int GetHashCode()
        {
            return HashCode.Combine(Id, PriceCurveId, PublisherId, TenorPremiums);
        }

        /// <summary>
        /// Returns a unique, compound key for the publisher tenor premium representing price curve and user
        /// </summary>
        /// <returns></returns>
        public string CompoundKey()
        {
            return CompoundKey(PriceCurveId, PublisherId);
        }

        public static string CompoundKey(int priceCurveId, int publisherId)
        {
            return $"{priceCurveId}-{publisherId}";
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(PriceCurveId)}: {PriceCurveId}, {nameof(PublisherId)}: {PublisherId}, {nameof(TenorPremiums)}: {TenorPremiums}";
        }
    }
}