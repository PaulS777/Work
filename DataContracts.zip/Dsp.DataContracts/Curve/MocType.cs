﻿/*====================================================================================
 *
 * WARNING: THIS ENUM FORMS PART OF THE VERSIONED API WITH DSX.
 *
 * Changing it will require a new API version (and potentially filtering new values
 * out of any previous API version to avoid breaking DSX)
 *
 =====================================================================================
*/
// ReSharper disable InconsistentNaming
namespace Dsp.DataContracts.Curve
{
    public enum MocType
    {
        MM = 1,
        TAP = 2,
        TAS = 3
    }
}
