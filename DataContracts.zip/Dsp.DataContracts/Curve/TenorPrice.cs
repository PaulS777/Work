﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    public class TenorPrice<T> where T: ITenor
    {
        [JsonProperty]
        public T Tenor { get; init; }

        [JsonProperty]
        public double? BidPrice { get; init; }

        [JsonProperty]
        public double? MidPrice { get; init; }

        [JsonProperty]
        public double? AskPrice { get; init; }

        [JsonProperty]
        public double? PrevClosePrice { get; init; }

        [JsonProperty]
        public MonthlyTenor? EfpMonth { get; init; }

        [JsonProperty]
        public double? EfpValue { get; init; }

        public TenorPrice()
        {}

        public TenorPrice(T tenor, double? bidPrice, double? midPrice, double? askPrice, double? prevClosePrice, MonthlyTenor? efpMonth = null, double? efpValue=null)
        {
            Tenor = tenor;
            BidPrice = bidPrice;
            MidPrice = midPrice;
            AskPrice = askPrice;
            PrevClosePrice = prevClosePrice;
            EfpMonth = efpMonth;
            EfpValue = efpValue;
        }
        public TenorPrice(T tenor, double bidPrice, double midPrice, double askPrice, double? prevClosePrice, MonthlyTenor? efpMonth = null, double? efpValue=null)
        {
            Tenor = tenor;
            BidPrice = bidPrice;
            MidPrice = midPrice;
            AskPrice = askPrice;
            PrevClosePrice = prevClosePrice;
            EfpMonth = efpMonth;
            EfpValue = efpValue;
        }
    }
}