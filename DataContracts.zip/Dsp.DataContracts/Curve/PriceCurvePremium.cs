﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record PriceCurvePremium : DeletableEntity
    {
        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int PriceCurveId { get; init; }

        [JsonProperty]
        [Required]
        [SortedListHasUniqueIds]
        public IList<VolumePremium> Volume { get; init; }

        [JsonProperty]
        [Required]
        [SortedListHasUniqueIds]
        public IList<ValidityPremium> Validity { get; init; }

        [JsonProperty]
        [Required]
        public PriceCurveFees Fees { get; init; }

        public PriceCurvePremium(int priceCurveId, IEnumerable<VolumePremium> volume,
                                 IEnumerable<ValidityPremium> validity, PriceCurveFees fees,
                                 EntityStatus status = EntityStatus.Active) : base(priceCurveId,status)
        {
            PriceCurveId = priceCurveId;
            Volume = volume.OrderByDescending(x => x.ThresholdInUoM).ToList();
            Validity = validity.OrderByDescending(x => x.ThresholdInSeconds).ToList();
            Fees = fees;
        }

        public override string ToString()
        {
            return $"{nameof(PriceCurveId)}: {PriceCurveId}, {nameof(Volume)}: {Volume}, {nameof(Validity)}: {Validity}, {nameof(Fees)}: {Fees}";
        }
    }
}