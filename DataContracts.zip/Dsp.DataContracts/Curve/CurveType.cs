﻿/*====================================================================================
 *
 * WARNING: THIS ENUM FORMS PART OF THE VERSIONED API WITH DSX.
 *
 * Changing it will require a new API version (and potentially filtering new values
 * out of any previous API version to avoid breaking DSX)
 *
 =====================================================================================
*/
namespace Dsp.DataContracts.Curve
{
    public enum CurveType
    {
        Arb = 1,
        Crack = 2,
        Diff = 3,
        FlatPrice = 4,
        Futures = 5,
        Fx = 6,
        Spread = 7,
        Swap = 8
    }
}
