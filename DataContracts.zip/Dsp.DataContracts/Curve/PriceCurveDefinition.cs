﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record PriceCurveDefinition : DeletableEntity
    {
        private static readonly ImmutableList<TenorType> DailyTenors = [TenorType.Day, TenorType.Week];
        private static readonly ImmutableList<TenorType> MonthlyTenors = [TenorType.Month, TenorType.Quarter, TenorType.HalfYear, TenorType.Year];
        private readonly List<PriceCurveMoc> _mocs;
        private Density _density;
        private readonly ProductDefinition _productDefinition;
        private PriceCurveDefinitionOverride _overrides;
        private List<TenorType> _tenorTypes;

        [JsonProperty]
        public string Name { get; init; }

        [JsonProperty]
        public string Description { get; init; }

        [JsonProperty]
        public ProductDefinition ProductDefinition
        {
            get => _productDefinition;
            init
            {
                _density = null;
                _productDefinition = value;
            }
        }

        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        public CurveRegion CurveRegion { get; init; }

        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        public CurveType CurveType { get; init; }

        [JsonIgnore]
        public UnitOfMeasure UnitOfMeasure => Overrides?.UnitOfMeasure ?? ProductDefinition.UnitOfMeasure;

        [JsonIgnore]
        public int LotSize => Overrides?.LotSize ?? ProductDefinition.LotSize;

        [JsonIgnore]
        public int Currency => Overrides?.Currency ?? ProductDefinition.Currency;

        [JsonIgnore]
        public int CurrencyDenominationFactor => Overrides?.CurrencyDenominationFactor ?? ProductDefinition.CurrencyDenominationFactor;

        [JsonProperty]
        public Density Density
        {
            get
            {
                _density ??= Overrides?.Density ?? (ProductDefinition.Density is null ? null : ProductDefinition.Density with {});
                return _density;
            }
        }

        [JsonIgnore]
        public List<TenorType> TenorTypes {
            get
            {
                _tenorTypes ??= ProductDefinition?.PricingTenorGroup == PricingTenorGroupType.Daily ? DailyTenors.ToList() : MonthlyTenors.ToList();
                return _tenorTypes;
            }
        }

        [JsonIgnore]
        public TenorType PricingTenor => ProductDefinition?.PricingTenorGroup == PricingTenorGroupType.Daily ? TenorType.Day : TenorType.Month;

        [JsonProperty]
        public PriceCurveDefinitionOverride Overrides
        {
            get => _overrides;
            init
            {
                _density = null;
                _overrides = value;
            }
        }

        [JsonProperty]
        public int? RelatedFlatPriceCurveId { get; init; }

        [JsonProperty]
        public List<PriceCurveMoc> Mocs
        {
            get => _mocs;
            init => _mocs = value ?? [];
        }

        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        public UnitOfMeasure DsxUnitOfMeasure { get; init; }

        [JsonProperty]
        public int DsxLotSize { get; init; }

        /// <summary>
        /// Defines an optional parent curve - if set then margins are always inherited from the parent
        /// </summary>
        [JsonProperty]
        public int? MarginParentCurveId { get; init; }

        /// <summary>
        /// When set, premiums and margins are not/must not be set for this price curve
        /// </summary>
        [JsonProperty]
        public bool ExcludePremiums { get; init; }

        /// <summary>
        /// Formula to use to calculate this price curve
        /// </summary>
        [JsonProperty]
        public string PriceFormula { get; init; }

        /// <summary>
        /// Defines the max period count for price curve
        /// </summary>
        [JsonProperty]
        public int? MaxPeriodCount { get; init; }
        [JsonProperty]
        public int? PendingCurveId { get; init; }
        [JsonProperty]
        public int? ActionedByUserId { get; init; }

        public PriceCurveDefinition() : base(int.MinValue, EntityStatus.Active)
        {
            Mocs ??= [];
        }

        public PriceCurveDefinition(int id,
            string name,
            string description,
            ProductDefinition productDefinition,
            CurveRegion curveRegion,
            CurveType curveType,
            UnitOfMeasure dsxUnitOfMeasure,
            int dsxLotSize,
            int? marginParentCurveId,
            string priceFormula,
            bool excludePremiums,
            EntityStatus status = EntityStatus.Active,
            int? maxPeriodCount = null,
            IEnumerable<PriceCurveMoc> mocs = null,
            int? relatedFlatPriceCurveId = null,
            PriceCurveDefinitionOverride definitionOverride = null,
            int? pendingCurveId = null,
            int? actionedByUserId = null) : base(id, status)
        {
            Name = name;
            Description = description;
            ProductDefinition = productDefinition;
            CurveRegion = curveRegion;
            CurveType = curveType;
            RelatedFlatPriceCurveId = relatedFlatPriceCurveId;
            DsxUnitOfMeasure = dsxUnitOfMeasure;
            DsxLotSize = dsxLotSize;
            PriceFormula = priceFormula;
            ExcludePremiums = excludePremiums;
            MaxPeriodCount = maxPeriodCount;
            Overrides = definitionOverride;
            MarginParentCurveId = marginParentCurveId != id ? marginParentCurveId : throw new ArgumentException("Parent cannot be self", nameof(marginParentCurveId));
            PendingCurveId = pendingCurveId;
            ActionedByUserId = actionedByUserId;

            Mocs ??= [];
            Mocs.Clear();
            if (mocs != null)
            {
                foreach (var moc in mocs)
                {
                    Mocs.Add(moc);
                }
            }
        }

        public override string ToString()
        {
            return
                $"{nameof(Id)}: {Id}, {nameof(Name)}: {Name}, {nameof(Description)}: {Description}, {nameof(ProductDefinition)}: {ProductDefinition}, " +
                $"{nameof(CurveRegion)}: {CurveRegion}, {nameof(CurveType)}: {CurveType}, {nameof(UnitOfMeasure)}: {UnitOfMeasure}, {nameof(LotSize)}: {LotSize}, " +
                $"{nameof(Currency)}: {Currency}, {nameof(CurrencyDenominationFactor)}: {CurrencyDenominationFactor}, {nameof(Density)}: {Density}, " +
                $"{nameof(TenorTypes)}: {TenorTypes}, {nameof(PricingTenor)}: {PricingTenor}, {nameof(Overrides)}: {Overrides}, {nameof(RelatedFlatPriceCurveId)}: {RelatedFlatPriceCurveId}, " +
                $"{nameof(Mocs)}: {Mocs}, " +
                $"{nameof(DsxUnitOfMeasure)}: {DsxUnitOfMeasure}, {nameof(DsxLotSize)}: {DsxLotSize}, {nameof(MarginParentCurveId)}: {MarginParentCurveId}, {nameof(PriceFormula)}: {PriceFormula}, " +
                $"{nameof(MaxPeriodCount)}: {MaxPeriodCount}," +
                $"{nameof(PendingCurveId)}: {PendingCurveId}, {nameof(Status)}: {Status}, {nameof(ActionedByUserId)}: {ActionedByUserId}" ;
        }

    }

    public record PriceCurveDefinitionOverride
    {
        public int? Currency { get; }
        public UnitOfMeasure? UnitOfMeasure { get; }
        public Density Density { get; }
        public int? CurrencyDenominationFactor { get; }
        public int? LotSize { get; }

        public PriceCurveDefinitionOverride(
            UnitOfMeasure? unitOfMeasure = null, Density density = null,
            int? currencyDenominationFactor = null, int? lotSize = null, int? currency = null)
        {
            Currency = currency;
            UnitOfMeasure = unitOfMeasure;
            Density = density;
            CurrencyDenominationFactor = currencyDenominationFactor;
            LotSize = lotSize;
        }
    }
}