﻿using System.ComponentModel;

namespace Dsp.DataContracts.Curve
{
    /// <summary>
    /// Shows the validity of price curves.
    /// Replaces the old Stale flag (Nov2019), so ValidityIndicator.Invalid is equivalent to Stale=True.
    /// </summary>
    public enum ValidityIndicator
    {
        [Description("Prices are valid")]
        Valid = 1,
        [Description("Prices are suspicious as exceeded warning timeout threshold since last update")]
        Warning,
        [Description("Prices are invalid as exceeded timeout threshold since last update, and/or feed connection has been lost")]
        Invalid
    }
}