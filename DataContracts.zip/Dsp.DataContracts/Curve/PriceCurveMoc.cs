﻿using System;
using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record PriceCurveMoc : DeletableEntity
    {
        [JsonProperty] 
        public string Name { get; init; }

        [JsonProperty]
        [Required]
        [GreaterThan(0)]
        public int PriceCurveDefinitionId { get; init; }

        [Required]
        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        public MocType MocType { get; init; }

        [Required] 
        [JsonProperty] 
        public string Timezone { get; init; }

        [JsonProperty]
        [Required]
        [Range(typeof(TimeSpan), "00:00:00", "23:59:59")]
        public TimeSpan CutoffTime { get; init; }

        [JsonProperty] 
        public string PrmTradebook { get; init; }

        [JsonProperty] 
        public int? EnabledCalendarId { get; init; }
        [JsonProperty] 
        public PriceCurveMocCalendar EnabledCalendar { get; init; }
        [JsonProperty] 
        public int? DisabledCalendarId { get; init; }
        [JsonProperty] 
        public PriceCurveMocCalendar DisabledCalendar { get; init; }

        public PriceCurveMoc() : base(int.MinValue, EntityStatus.Active)
        { }

        public PriceCurveMoc(int id,
            string name,
            int priceCurveDefinitionId,
            MocType mocType,
            string timezone,
            TimeSpan cutoffTime,
            string prmTradebook,
            PriceCurveMocCalendar enabledCalendar,
            PriceCurveMocCalendar disabledCalendar, 
            EntityStatus status = EntityStatus.Active) : base(id, status)
        {
            Name = name;
            PriceCurveDefinitionId = priceCurveDefinitionId;
            MocType = mocType;
            Timezone = timezone;
            CutoffTime = cutoffTime;
            PrmTradebook = prmTradebook;
            EnabledCalendarId = enabledCalendar?.Id;
            EnabledCalendar = enabledCalendar;
            DisabledCalendarId = disabledCalendar?.Id;
            DisabledCalendar = disabledCalendar;
        }

        public PriceCurveMoc(PriceCurveMoc entity, PriceCurveMocCalendar enabledCalendar, PriceCurveMocCalendar disabledCalendar) :
            this(entity.Id, 
                entity.Name, 
                entity.PriceCurveDefinitionId, 
                entity.MocType, 
                entity.Timezone, 
                entity.CutoffTime, 
                entity.PrmTradebook, 
                enabledCalendar, 
                disabledCalendar)
        {}

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Name)}: {Name}, {nameof(PriceCurveDefinitionId)}: {PriceCurveDefinitionId}, {nameof(MocType)}: {MocType}, {nameof(Timezone)}: {Timezone}, {
                nameof(CutoffTime)
            }: {CutoffTime}, {nameof(PrmTradebook)}: {PrmTradebook}, {nameof(EnabledCalendarId)}: {EnabledCalendarId}, {nameof(EnabledCalendar)}: {EnabledCalendar}, {
                    nameof(DisabledCalendarId)
            }: {DisabledCalendarId}, {nameof(DisabledCalendar)}: {DisabledCalendar}";
        }
    }
}