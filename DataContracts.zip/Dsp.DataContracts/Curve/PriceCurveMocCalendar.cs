﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public class PriceCurveMocCalendar : IIdentifiable
    {
        [JsonProperty]
        public int Id { get; init; }

        [JsonProperty] 
        public string Description { get; init; }

        [Required] 
        [JsonProperty] 
        public List<DateTime> Holidays { get; init; }

        public PriceCurveMocCalendar()
        { }

        public PriceCurveMocCalendar(int id, string description, List<DateTime> holidays)
        {
            Id = id;
            Description = description;
            Holidays = holidays;
        }

        public PriceCurveMocCalendar(PriceCurveMocCalendar from, List<DateTime> holidays) :
            this(from.Id,
                from.Description,
                holidays)
        {
        }
        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Description)}: {Description}, {nameof(Holidays)}: {Holidays}";
        }

    }
}