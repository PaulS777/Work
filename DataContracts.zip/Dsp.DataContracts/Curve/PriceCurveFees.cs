﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record PriceCurveFees : DeletableEntity
    {
        private int _priceCurveDefinitionId;

        public int PriceCurveDefinitionId
        {
            get => _priceCurveDefinitionId;
            init => _priceCurveDefinitionId = Id = value;
        }

        public double InternalPlatformFee { get; init; }

        public double ExternalPlatformFee { get; init; }

        public double InternalServiceFee { get; init; }

        public double BrokerageFee { get; init; }

        public double ClearingFee { get; init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public PriceCurveFees() : base(int.MinValue, EntityStatus.Active)
        { }

        [JsonConstructor]
        public PriceCurveFees(int priceCurveDefinitionId,
            double internalPlatformFee,
            double externalPlatformFee,
            double internalServiceFee,
            double brokerageFee,
            double clearingFee,
            EntityStatus status = EntityStatus.Active) : base(priceCurveDefinitionId, status)
        {
            PriceCurveDefinitionId = priceCurveDefinitionId;
            InternalPlatformFee = internalPlatformFee;
            ExternalPlatformFee = externalPlatformFee;
            InternalServiceFee = internalServiceFee;
            BrokerageFee = brokerageFee;
            ClearingFee = clearingFee;
        }

        public override string ToString()
        {
            return $"{nameof(PriceCurveDefinitionId)}: {PriceCurveDefinitionId}, {nameof(InternalPlatformFee)}: {InternalPlatformFee}, {nameof(ExternalPlatformFee)}: {ExternalPlatformFee}, {
                nameof(InternalServiceFee)
            }: {InternalServiceFee}, {nameof(BrokerageFee)}: {BrokerageFee}, {nameof(ClearingFee)}: {ClearingFee}";
        }
    }
}
