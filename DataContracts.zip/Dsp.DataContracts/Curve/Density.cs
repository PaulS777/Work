﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts.Curve
{
    [JsonObject]
    public record Density
    {
        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        [Required]
        public UnitOfMeasure UnitOfVolume { get; init; }

        [JsonProperty]
        [Required]
        public double Factor { get; init; }

        public Density()
        {
        }

        public Density(UnitOfMeasure unitOfVolume, double? factor)
        {
            if (unitOfVolume.IsUnitOfWeight())
            {
                throw new ArgumentException("Unit of volume should be specified", nameof(unitOfVolume));
            }

            if (factor==null ||factor <= 0)
            {
                throw new ArgumentException("Conversion factor must be greater than 0", nameof(factor));
            }

            UnitOfVolume = unitOfVolume;
            Factor = (double)factor;
        }

        public override string ToString()
        {
            return $"{{{nameof(UnitOfMeasure)}:{UnitOfVolume}, {nameof(Factor)}:{Factor}}}";
        }
    }
}
