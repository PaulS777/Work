﻿using System.ComponentModel.DataAnnotations;

namespace Dsp.DataContracts
{
    public record ClientApiKey : DeletableEntity
    {
        [Required]
        public string ApiKeyHash { get; init; }
        public string Description { get; init; }
        public bool IsEnabled { get; init; }
        public string ContactEmail { get; init; } = string.Empty;

        public ClientApiKey(int id, string apiKeyHash, string description, bool isEnabled, string contactEmail) : base(id, EntityStatus.Active)
        {
            ApiKeyHash = apiKeyHash;
            Description = description;
            IsEnabled = isEnabled;
            ContactEmail = contactEmail;
        }
        public string GetCompoundKey()
        {
            return $"{Id}-{Description}{(IsEnabled ? "" : " (DISABLED)")}";
        }

        public override string ToString()
        {
            return $"{Id}-{Description}{(IsEnabled?"":" (DISABLED)")}";
        }

    }
}
