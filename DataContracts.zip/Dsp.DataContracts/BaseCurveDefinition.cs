﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record BaseCurveDefinition : DeletableEntity
    {
        public static readonly int MaxPeriodCount = 60;

        public int BaseCurveId => Id;

        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public string Name { get; init; }

        public int PeriodCount { get; init; }

        public int Precision { get; init; }

        public int ExpirationDaysOffset { get; init; }

        public int CalendarId { get; init; }

        public IList<FuturesExpiry> FuturesExpiries { get; init; }

        public int FuturesDefinitionId { get; init; }
        public int SwapDefinitionId { get; init; }
        public int FuturesSpreadDefinitionId { get; init; }
        public int SwapSpreadDefinitionId { get; init; }
        public CurveBuilderType CurveBuilderType { get; init; }
        public string FeedProductCode  { get; init; }
        public FeedSource FeedSource { get; init; }
        public int? PendingCurveId { get; init; }
        public int? ActionedByUserId { get; init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public BaseCurveDefinition() : base(int.MinValue, EntityStatus.Active)
        { }
        
        [JsonConstructor]
        public BaseCurveDefinition(int baseCurveId,
            string name,
            int periodCount,
            int precision,
            int expirationDaysOffset,
            int calendarId,
            IList<FuturesExpiry> futuresExpiries,
            int futuresDefinitionId,
            int swapDefinitionId,
            int futuresSpreadDefinitionId,
            int swapSpreadDefinitionId,
            CurveBuilderType curveBuilderType,
            string feedProductCode,
            FeedSource feedSource,
            EntityStatus status = EntityStatus.Active,
            int? pendingCurveId = null,
            int? actionedByUserId = null) : base(baseCurveId, status)
        {
            Name = name;
            PeriodCount = periodCount;
            Precision = precision;
            ExpirationDaysOffset = expirationDaysOffset;
            CalendarId = calendarId;
            FuturesExpiries = futuresExpiries;
            FuturesDefinitionId = futuresDefinitionId;
            SwapDefinitionId = swapDefinitionId;
            FuturesSpreadDefinitionId = futuresSpreadDefinitionId;
            SwapSpreadDefinitionId = swapSpreadDefinitionId;
            CurveBuilderType = curveBuilderType;
            FeedProductCode = feedProductCode;
            FeedSource = feedSource;
            PendingCurveId = pendingCurveId;
            ActionedByUserId = actionedByUserId;
           
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(BaseCurveId)}: {BaseCurveId}, {nameof(Id)}: {Id}, {nameof(Name)}: {Name}, {nameof(PeriodCount)}: {PeriodCount}, {nameof(Precision)}: {Precision}, " +
                   $"{nameof(ExpirationDaysOffset)}: {ExpirationDaysOffset}, {nameof(CalendarId)}: {CalendarId}, {nameof(FuturesExpiries)}: {FuturesExpiries}, {nameof(FuturesDefinitionId)}: " +
                   $"{FuturesDefinitionId}, {nameof(SwapDefinitionId)}: {SwapDefinitionId}, {nameof(FuturesSpreadDefinitionId)}: {FuturesSpreadDefinitionId}, {nameof(SwapSpreadDefinitionId)}: " +
                   $"{SwapSpreadDefinitionId}, {nameof(CurveBuilderType)}: {CurveBuilderType}, {nameof(FeedProductCode)}: {FeedProductCode}, {nameof(FeedSource)}: {FeedSource}," +
                   $"{nameof(PendingCurveId)}: {PendingCurveId},{nameof(ActionedByUserId)}: {ActionedByUserId} ";
        }
    }
}