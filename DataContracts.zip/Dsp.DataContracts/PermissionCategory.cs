﻿namespace Dsp.DataContracts
{
    public enum PermissionCategory
    {
        EomRoll = 1,
        BetaUser,
        CurveAdmin,
        CurveAdminApprover
}
}
