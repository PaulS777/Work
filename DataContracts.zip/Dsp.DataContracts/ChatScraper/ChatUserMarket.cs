﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public record ChatUserMarket : DeletableEntity
    {

        public ChatUserMarket(int id, int chatUserId, int chatMarketId) : base(id, EntityStatus.Active)
        {
            ChatUserId = chatUserId;
            ChatMarketId = chatMarketId;

        }

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int ChatUserId { get; }

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int ChatMarketId { get; }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(ChatUserId)}: {ChatUserId}, {nameof(ChatMarketId)}: {ChatMarketId}";
        }
    }
}
