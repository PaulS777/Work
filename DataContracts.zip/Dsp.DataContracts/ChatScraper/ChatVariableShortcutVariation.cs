﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public class ChatVariableShortcutVariation : IIdentifiable
    {

        public ChatVariableShortcutVariation(int id, int chatVariableShortcutId, int chatMarketId, string priceCurveName)
        {
            Id = id;
            ChatVariableShortcutId = chatVariableShortcutId;
            ChatMarketId = chatMarketId;
            PriceCurveName = priceCurveName;
        }

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int Id { get; init; }

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int ChatVariableShortcutId { get; init; }

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int ChatMarketId { get; init; }

        [JsonProperty]
        [Required]
        public string PriceCurveName { get; init; }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(ChatVariableShortcutId)}: {ChatVariableShortcutId}, {nameof(ChatMarketId)}: {ChatMarketId}, {nameof(PriceCurveName)}: {PriceCurveName}";
        }
    }
}