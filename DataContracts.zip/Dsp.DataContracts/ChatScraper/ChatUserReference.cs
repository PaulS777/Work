﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public record ChatUserReference : DeletableEntity
    {
        public ChatUserReference(int id, int chatUserId, string externalRef) : base(id, EntityStatus.Active)
        {
            ChatUserId = chatUserId;
            ExternalRef = externalRef;
        }

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int ChatUserId { get; }

        [JsonProperty]
        [Required]
        public string ExternalRef { get; }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(ChatUserId)}: {ChatUserId}, {nameof(ExternalRef)}: {ExternalRef}";
        }
    }
}
