﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Newtonsoft.Json;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public record ChatUser : DeletableEntity
    {
        public ChatUser() : base(int.MinValue, EntityStatus.Active)
        { }

        public ChatUser(int id, EntityStatus status, string name, List<ChatUserMarket> markets, List<ChatUserReference> references) : base(id, status)
        {
            Name = name;
            ChatUserMarkets = markets.ToList();
            ChatUserReferences = references.ToList();
        }

        public ChatUser(ChatUser from, List<ChatUserMarket> markets, List<ChatUserReference> references) :
            this(
                from.Id,
                from.Status,
                from.Name,
                markets,
                references)
        {
        }

        [JsonProperty]
        [Required]
        public string Name { get; init; }

        [JsonProperty]
        [Required]
        public List<ChatUserMarket> ChatUserMarkets { get; init; }

        [JsonProperty]
        [Required]
        public List<ChatUserReference> ChatUserReferences { get; init; }

        public override string ToString()
        {
            return $"{nameof(Id)}: {Id},  {nameof(Name)}: {Name}, {nameof(ChatUserMarkets)}: {ChatUserMarkets}, {nameof(ChatUserReferences)}: {ChatUserReferences}";
        }
    }
}
