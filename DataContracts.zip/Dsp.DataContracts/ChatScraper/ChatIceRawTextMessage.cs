﻿using System;
using System.Collections.Generic;

namespace Dsp.DataContracts.ChatScraper
{
    public class ChatIceRawTextMessage : IIdentifiable
    {
        public int Id { get; init; }
        public string UserHandle { get; init; }
        public string SenderHandle { get; set; }
        public List<string> Contact { get; init; }
        public  List<object> MarketInfo { get; init; }
        public string Text { get; init; }
        public bool Incoming { get; init; }
        public DateTime MessageTime { get; init; }

        public override string ToString()
        {
            return $"Sender: {SenderHandle}, {nameof(Incoming)}: {Incoming}, {nameof(MessageTime)}: {MessageTime}, {nameof(Text)}: {Text} ";
        }
    }
}