﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public record ChatVariableShortcut : DeletableEntity
    {
        /// <summary>
        /// Required for Dapper
        /// </summary>
        public ChatVariableShortcut() : base(int.MinValue, EntityStatus.Active)
        { }

        public ChatVariableShortcut(int id, EntityStatus status, string name, string shortCuts, List<ChatVariableShortcutVariation> chatVariableShortcutVariations) : base(id, status)
        {
            Name = name;
            Shortcuts = shortCuts;
            ChatVariableShortcutVariations = chatVariableShortcutVariations;
        }

        [JsonProperty]
        [Required]
        public string Name { get; init; }

        [JsonProperty]
        [Required]
        public string Shortcuts { get; init; }

        [JsonProperty]
        [Required]
        public List<ChatVariableShortcutVariation> ChatVariableShortcutVariations { get; init; }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(Name)}: {Name}, {nameof(Shortcuts)}: {Shortcuts}, {nameof(ChatVariableShortcutVariations)}: {ChatVariableShortcutVariations}";
        }
    }
}