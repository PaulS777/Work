﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace Dsp.DataContracts.ChatScraper
{
    [JsonObject]
    public record ChatMarket : DeletableEntity
    {

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public ChatMarket() : base(int.MinValue, EntityStatus.Active)
        { }

        public ChatMarket(int id, EntityStatus status, string market) : base(id, status)
        {
            Market = market;
        }

        [JsonProperty]
        [Required]
        public string Market { get; init; }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(Market)}: {Market}";
        }
    }
}
