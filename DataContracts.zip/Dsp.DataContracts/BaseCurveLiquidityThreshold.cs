﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record BaseCurveLiquidityThreshold : DeletableEntity
    {
        private int _baseCurveId;

        public int BaseCurveId
        {
            get => _baseCurveId;
            init => _baseCurveId = Id = value;
        }

        public List<LiquidityThreshold> LiquidityThresholds { get;init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public BaseCurveLiquidityThreshold() : base(-1, EntityStatus.Active)
        {
            LiquidityThresholds = new List<LiquidityThreshold>();
        }
        
        [JsonConstructor]
        public BaseCurveLiquidityThreshold(int baseCurveId, List<LiquidityThreshold> liquidityThresholds, EntityStatus status = EntityStatus.Active ) : base(baseCurveId, status)
        {
            BaseCurveId = baseCurveId;
            LiquidityThresholds = liquidityThresholds;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(BaseCurveId)}: {BaseCurveId}, {nameof(LiquidityThresholds)}: {LiquidityThresholds}";
        }
    }
}
