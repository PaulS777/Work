﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.Curve;

namespace Dsp.DataContracts.ValidationAttributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class SortedListHasUniqueIdsAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var valueType = value?.GetType();
            var errorMessage = $"The {validationContext.DisplayName} list has duplicate ids.";
          
            if (valueType == typeof(List<VolumePremium>))
            {
                if (VolumePremiumContainsDuplicateId((List<VolumePremium>)value))
                {
                    return new ValidationResult(errorMessage);
                }
            }
            else if (valueType == typeof(List<TenorPremium>))
            {
                if (TenorPremiumContainsDuplicateId((List<TenorPremium>)value))
                {
                    return new ValidationResult(errorMessage);
                }
            }
            else if (valueType == typeof(List<ValidityPremium>))
            {
                if (ValidityPremiumContainsDuplicateId((List<ValidityPremium>)value))
                {
                    return new ValidationResult(errorMessage);
                }
            }
            else if (valueType == typeof(List<PipsBufferPeriod>))
            {
                if (PipsBufferPeriodContainsDuplicateId((List<PipsBufferPeriod>)value))
                {
                    return new ValidationResult(errorMessage);
                }
            }
            else
            {
                throw new ArgumentException($"The {validationContext.DisplayName} is not supported by this validation attribute.");
            }

            return ValidationResult.Success;
        }

        private static bool VolumePremiumContainsDuplicateId(IReadOnlyList<VolumePremium> items)
        {
            for (var i = 1; i <= items.Count - 1; i++)
            {
                if (items[i].ThresholdInUoM == items[i - 1].ThresholdInUoM)
                {
                    return true;
                }
            }
            return false;
        }

        private static bool ValidityPremiumContainsDuplicateId(IReadOnlyList<ValidityPremium> items)
        {
            for (var i = 1; i <= items.Count - 1; i++)
            {
                if (items[i].ThresholdInSeconds == items[i - 1].ThresholdInSeconds)
                {
                    return true;
                }
            }
            return false;
        }
        private static bool TenorPremiumContainsDuplicateId(IReadOnlyList<TenorPremium> items)
        {
            for (var i = 1; i <= items.Count - 1; i++)
            {
                if (items[i].Tenor.Equals(items[i - 1].Tenor))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool PipsBufferPeriodContainsDuplicateId(IReadOnlyList<PipsBufferPeriod> items)
        {
            for (var i = 1; i <= items.Count - 1; i++)
            {
                if (items[i].StartTime == items[i - 1].StartTime &&
                    items[i].IsBusinessDay == items[i - 1].IsBusinessDay)
                {
                    return true;
                }
            }

            return false;
        }
    }
}