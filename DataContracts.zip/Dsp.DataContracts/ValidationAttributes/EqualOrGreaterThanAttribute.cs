﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Dsp.DataContracts.ValidationAttributes
{
    [AttributeUsage(AttributeTargets.Property)]
    public class EqualOrGreaterThanAttribute : ValidationAttribute
    {
        private readonly double _equalOrGreaterThan;

        public EqualOrGreaterThanAttribute(int equalOrGreaterThan)
        {
            _equalOrGreaterThan = equalOrGreaterThan;
        }

        public EqualOrGreaterThanAttribute(double equalOrGreaterThan)
        {
            _equalOrGreaterThan = equalOrGreaterThan;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            double number;
            try
            {
                number = Convert.ToDouble(value);
            }
            catch (InvalidCastException)
            {
                return new ValidationResult($"The {validationContext.DisplayName} field is invalid.");
            }

            return number >= _equalOrGreaterThan ?
                ValidationResult.Success :
                new ValidationResult($"The {validationContext.DisplayName} field should be equal or greater than {_equalOrGreaterThan}.");
        }
    }
}