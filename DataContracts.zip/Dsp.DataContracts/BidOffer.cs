﻿using System;

namespace Dsp.DataContracts
{
    public struct BidOffer : IEquatable<BidOffer>
    {
        public double Bid { get; }
        public double Offer { get; }

        public BidOffer(double bid, double ask)
        {
            Bid = bid;
            Offer = ask;
        }

        public override string ToString()
        {
            return $"{nameof(Bid)}: {Bid}, {nameof(Offer)}: {Offer}";
        }

        /// <inheritdoc />
        public bool Equals(BidOffer other)
        {
            return Bid.Equals(other.Bid) && Offer.Equals(other.Offer);
        }

        /// <inheritdoc />
        public override bool Equals(object obj)
        {
            return obj is BidOffer other && Equals(other);
        }

        /// <inheritdoc />
        public override int GetHashCode()
        {
            unchecked
            {
                return (Bid.GetHashCode() * 397) ^ Offer.GetHashCode();
            }
        }
    }
}
