﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    [JsonObject]
    public class AuthorisationUserPermission :  IIdentifiable
    {
        public AuthorisationUserPermission(int id, string categoryName, int userId, bool value)
        {
            Id = id;
            CategoryName = categoryName;
            UserId = userId;
            Value = value;
        }

        public AuthorisationUserPermission()
        {
        }

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int Id { get; init; }

        [JsonProperty]
        [Required]
        public string CategoryName { get; init; }

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int UserId { get; init; }
        
        [JsonProperty]
        [Required]
        public bool Value { get; init; }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(CategoryName)}: {CategoryName}, {nameof(UserId)}: {UserId}, {nameof(Value)}: {Value}";
        }
    }
}
