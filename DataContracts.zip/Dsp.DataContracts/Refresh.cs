﻿using System;

namespace Dsp.DataContracts
{
    public class Refresh
    {
        public Type Type { get; set; }
        public Refresh(Type type)
        {
            Type = type;
        }
    }
}
