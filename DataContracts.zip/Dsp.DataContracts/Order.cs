﻿using System;
using System.Collections.Generic;
using Dsp.DataContracts.JsonConverters;
using Dsp.DataContracts.WebApi;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts
{
    [JsonObject]
    public class Order : IWebApiMessage
    {
        [JsonProperty("msg_type")]
        public string MsgType => "order";

        [JsonProperty("timestamp"), JsonConverter(typeof(DateTimeJsonConverter))]
        public DateTime Timestamp { get; init; }

        [JsonProperty("order_id")]
        public long OrderId { get; init; }

        [JsonProperty("quote_id")]
        public long QuoteId { get; init; }

        [JsonProperty("curve_id")]
        public string CurveId { get; init; }

        [JsonProperty("periods", ItemConverterType = typeof(MonthlyTenorJsonConverter))]
        public IList<MonthlyTenor> Periods { get; init; }

        [JsonProperty("price")]
        public double Price { get; init; }

        [JsonProperty("sides", ItemConverterType = typeof(StringEnumConverter))]
        public IList<BuySell> Sides { get; init; }

        [JsonProperty("volumes")]
        public IList<int> Volumes { get; init; }

        [JsonProperty("user_id")]
        public string UserId { get; init; }

        public Order()
        {            
        }

        public Order(DateTime timestamp, long orderId, long quoteId, string curveId, IList<MonthlyTenor> periods,
            IList<BuySell> sides, IList<int> volumes, double price, string userId)
        {
            Timestamp = timestamp;
            OrderId = orderId;
            QuoteId = quoteId;
            CurveId = curveId;
            Periods = periods;
            Price = price;
            Sides = sides;
            Volumes = volumes;
            UserId = userId;
        }
    }
}
