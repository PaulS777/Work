﻿using Newtonsoft.Json;

namespace Dsp.DataContracts
{

    public enum KeyType
    {
        Quote = 1
    }

    [JsonObject]
    public record KeyAllocation : DeletableEntity
    {
        public int KeyId { get; init; }

        public string KeyName { get; init; }

        public int PreAllocation { get; init; }

        public long NextKey { get; init; }

        public KeyAllocation(int keyId, string keyName, int preAllocation, long nextKey) : base(keyId, EntityStatus.Active)
        {
            KeyId = keyId;
            KeyName = keyName;
            PreAllocation = preAllocation;
            NextKey = nextKey;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{base.ToString()}, {nameof(KeyId)}: {KeyId}, {nameof(KeyName)}: {KeyName}, {nameof(PreAllocation)}: {PreAllocation}, {nameof(NextKey)}: {NextKey}";
        }
    }
}
