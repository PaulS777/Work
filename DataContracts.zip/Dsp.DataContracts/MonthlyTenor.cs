﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using TenorTypeEnum = Dsp.DataContracts.TenorType;

namespace Dsp.DataContracts
{
    [Serializable][JsonObject]
    public struct MonthlyTenor: IComparable<MonthlyTenor>, ITenor
    {
        public static IComparer<MonthlyTenor> ComparerInstance { get; } = new YearMonthRelationalComparer();
        public static readonly ITenorConverter<MonthlyTenor> ConverterInstance = new MonthlyTenorConverter();

        private static readonly string[] MonthNames = {
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec"
        };

        public int Year { get; }

        public int Month { get; }

        public MonthlyTenor(DateTime date): this(date.Year, date.Month)
        {}

        public MonthlyTenor(int value): this(value / 10000 % 10000, value / 100 % 100)
        {}

        [JsonConstructor]
        public MonthlyTenor(int year, int month)
        {
            Year = year;
            Month = month;
            Validate();
        }

        public MonthlyTenor(string token)
        {
            if(token.Length != 5)
            {
                throw new FormatException("Expected tenor string of length 5");
            }

            var monthStr = token.Substring(0, 3);
            var yearStr = token.Substring(3, 2);
            Year = 2000 + Convert.ToInt32(yearStr);
            Month = 1 + Array.IndexOf(MonthNames, monthStr);
            Validate();
        }

        private void Validate()
        {
            if(Year < 2000 || Year > 3000)
            {
                throw new ArgumentException($"Year must be between 2000 and 3000. Actual: y={Year} m={Month}");
            }

            if(Month < 1 || Month > 12)
            {
                throw new ArgumentException("Month must be between 1 and 12.Actual: y={Year} m={Month}");
            }
        }

        public bool Equals(MonthlyTenor other)
        {
            return Year == other.Year && Month == other.Month;
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            return obj is MonthlyTenor yearMonth && Equals(yearMonth);
        }

        public int CompareTo(ITenor other)
        {
            var typeComparison = TenorType().CompareTo(other.TenorType());
            return typeComparison != 0 ? typeComparison : CompareTo((MonthlyTenor)other);
         }

        public int CompareTo(MonthlyTenor other)
        {
            var yearComparison = Year.CompareTo(other.Year);
            return yearComparison != 0 ? yearComparison : Month.CompareTo(other.Month);
        }

        public static bool operator <(MonthlyTenor left, MonthlyTenor right)
        {
            return left.CompareTo(right) < 0;
        }

        public static bool operator >(MonthlyTenor left, MonthlyTenor right)
        {
            return left.CompareTo(right) > 0;
        }

        public static bool operator <=(MonthlyTenor left, MonthlyTenor right)
        {
            return left.CompareTo(right) <= 0;
        }

        public static bool operator >=(MonthlyTenor left, MonthlyTenor right)
        {
            return left.CompareTo(right) >= 0;
        }

        public static bool operator ==(MonthlyTenor left, MonthlyTenor right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(MonthlyTenor left, MonthlyTenor right)
        {
            return !left.Equals(right);
        }

        public string Key => $"{(int)TenorType()}{ConvertToInt()}";

        public int ConvertToInt()
        {
            return Year * 10000 + Month * 100;
        }

        public TenorTypeEnum TenorType()
        {
            return TenorTypeEnum.Month;
        }

        public DateTime StartDate()
        {
            return new DateTime(Year, Month, 1);
        }

        public DateTime EndDate()
        {
            return StartDate().LastDayOfMonth();
        }

        public static MonthlyTenor ConvertFromInt(int value)
        {
            return new MonthlyTenor(value);
        }

        public override string ToString()
        {
            return $"{MonthNames[Month - 1]}{Year % 100}";
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (Year * 397) ^ Month;
            }
        }

        private sealed class YearMonthRelationalComparer : IComparer<MonthlyTenor>
        {
            public int Compare(MonthlyTenor x, MonthlyTenor y)
            {
                return x.CompareTo(y);
            }
        }

        private sealed class MonthlyTenorConverter: ITenorConverter<MonthlyTenor>
        {
            public MonthlyTenor FromInt(int token)
            {
                return ConvertFromInt(token);
            }

            public int ToInt(MonthlyTenor tenor)
            {
                return tenor.ConvertToInt();
            }

            /// <inheritdoc />
            public MonthlyTenor FromDate(DateTime date)
            {
                return new MonthlyTenor(date);
            }

            /// <inheritdoc />
            public DateTime ToDate(MonthlyTenor tenor)
            {
                return tenor.StartDate();
            }
        }
    }
}