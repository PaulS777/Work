﻿namespace Dsp.DataContracts
{
    public class MocRegion
    {
        public int ProductDefinitionId { get; init; } 
        public int CurveRegionId { get; init; }

        public MocRegion(int productDefinitionId, int curveRegionId)
        {
            ProductDefinitionId = productDefinitionId;
            CurveRegionId = curveRegionId;
        }     
    }
}
