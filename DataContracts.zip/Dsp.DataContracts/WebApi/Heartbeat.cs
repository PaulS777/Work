﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.WebApi
{
    [JsonObject]
    public class Heartbeat : IWebApiMessage
    {
        [JsonProperty("msg_type")]
        public string MsgType => "heartbeat";
    }
}
