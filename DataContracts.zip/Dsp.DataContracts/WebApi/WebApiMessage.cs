﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.WebApi
{
    [JsonObject]
    public class WebApiMessage : IWebApiMessage
    {
        [JsonProperty("msg_type")]
        public string MsgType { get; init; }
    }
}
