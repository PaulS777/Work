﻿using Newtonsoft.Json;

namespace Dsp.DataContracts.WebApi
{
    [JsonObject]
    public class DealSubscription : IWebApiMessage
    {
        [JsonProperty("msg_type")]
        public string MsgType => "deal_subscription";

        [JsonProperty("last_deal_id")]
        public long LastDealId { get; init; }

        public DealSubscription()
        {            
        }

        public DealSubscription(long lastDealId)
        {
            LastDealId = lastDealId;
        }
    }
}
