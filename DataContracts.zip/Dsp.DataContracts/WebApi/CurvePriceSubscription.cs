﻿using System.Collections.Generic;

namespace Dsp.DataContracts.WebApi
{
   public class CurvePriceSubscription
    {
        public IList<string> CurveIds { get; }

        public CurvePriceSubscription(IList<string> curveIds)
        {
            CurveIds = curveIds;
        }
    }
}
