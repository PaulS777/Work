﻿namespace Dsp.DataContracts.WebApi
{
    public enum ApiConnectionStatus
    {
        Success,
        AuthenticationFailure,
        ConnectionsExceededFailure,
        ObsoleteClientFailure
    }
}
