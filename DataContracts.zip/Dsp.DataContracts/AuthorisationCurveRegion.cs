﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.Curve;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace Dsp.DataContracts
{
    [JsonObject]
    public record AuthorisationCurveRegion
    {
        [Required]
        [JsonProperty, JsonConverter(typeof(StringEnumConverter))]
        public CurveRegion CurveRegion { get; init; }

        [JsonProperty]
        [Required]
        public bool CanRead { get; init; }

        [JsonProperty]
        [Required]
        public bool CanUpdate { get; init; }

        public AuthorisationCurveRegion()
        {
        }

        public AuthorisationCurveRegion(CurveRegion curveRegion, bool canRead, bool canUpdate)
        {
            CurveRegion = curveRegion;
            CanRead = canRead;
            CanUpdate = canUpdate;
        }

        public override string ToString()
        {
            return $"{{{nameof(CurveRegion)}:{CurveRegion}, {nameof(CanRead)}:{CanRead}, {nameof(CanUpdate)}:{CanUpdate}}}";
        }
    }
}