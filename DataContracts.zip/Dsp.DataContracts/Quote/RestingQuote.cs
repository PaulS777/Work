﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Dsp.DataContracts.Quote
{
    [JsonObject]
    public class RestingQuote : IIdentifiable
    {       
        [JsonProperty]    
        public int Id => (int)QuoteId;
        
        [JsonProperty]
        public long RequestId { get; init; }

        [JsonProperty]
        public long QuoteId { get; init; }

        [JsonProperty]
        public DateTime Timestamp { get; init; }

        [JsonProperty]
        public DateTime Expiry { get; init; }

        [JsonProperty]
        public List<RestingQuoteLeg> Legs { get; init; }

        public RestingQuote()
        {            
        }

        public RestingQuote(long requestId, long quoteId, DateTime timestamp, DateTime expiry, List<RestingQuoteLeg> legs)
        {
            RequestId = requestId;
            QuoteId = quoteId;
            Timestamp = timestamp;
            Expiry = expiry;
            Legs = legs;
        }

        public override string ToString()
        {
            return $"{nameof(RequestId)}: {RequestId}, {nameof(QuoteId)}: {QuoteId}, {nameof(Timestamp)}: {Timestamp}, {nameof(Expiry)}: {Expiry}, " +
                   $"{nameof(Legs)}: [{string.Join("; ", Legs.Select(x => x.ToString()))}]";
        }
    }

    [JsonObject]
    public class RestingQuoteLeg
    {       
        [JsonProperty]
        public string CurveId { get; init; }

        [JsonProperty]
        public int PublisherId { get; init;}
        
        [JsonProperty]
        public string Publisher { get; init; }

        [JsonProperty]
        public int PriceCurveDefinitionId { get; init; }
        
        [JsonProperty]
        public IList<DailyTenor> DailyPeriods { get; init; }
        [JsonProperty]
        public IList<WeeklyTenor> WeeklyPeriods { get; init; }
        [JsonProperty]
        public IList<MonthlyTenor> MonthlyPeriods { get; init; }
        [JsonProperty]
        public IList<QuarterlyTenor> QuarterlyPeriods { get; init; }
        [JsonProperty]
        public IList<HalfYearTenor> HalfYearlyPeriods { get; init; }
        [JsonProperty]
        public IList<AnnualTenor> YearlyPeriods { get; init; }

        [JsonProperty]
        public IList<BuySell> Sides { get; init; }
       
        [JsonProperty]
        public IList<double> Volumes { get; init; }

        [JsonProperty]
        public double SpecifiedPrice { get; init; }

        [JsonProperty]
        public double TriggerPrice { get; init; }

        [JsonProperty]
        public TriggerDirection TriggerWhen { get; init; }

        public RestingQuoteLeg()
        {            
        }

        public RestingQuoteLeg(string curveId,
            int publisherId,
            string publisher,
            int priceCurveDefinitionId,
            IList<DailyTenor> dailyPeriods,
            IList<WeeklyTenor> weeklyPeriods,
            IList<MonthlyTenor> monthlyPeriods,
            IList<QuarterlyTenor> quarterlyPeriods,
            IList<HalfYearTenor> halfYearlyPeriods,
            IList<AnnualTenor> yearlyPeriods,
            IList<BuySell> sides,
            IList<double> volumes,
            double specifiedPrice,
            double triggerPrice,
            TriggerDirection triggerWhen)
        {
            CurveId = curveId;
            PublisherId = publisherId;
            Publisher = publisher;
            PriceCurveDefinitionId = priceCurveDefinitionId;
            DailyPeriods = dailyPeriods;
            WeeklyPeriods = weeklyPeriods;
            MonthlyPeriods = monthlyPeriods;
            QuarterlyPeriods = quarterlyPeriods;
            HalfYearlyPeriods = halfYearlyPeriods;
            YearlyPeriods = yearlyPeriods;
            Sides = sides;
            Volumes = volumes;
            SpecifiedPrice = specifiedPrice;
            TriggerPrice = triggerPrice;
            TriggerWhen = triggerWhen;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(CurveId)}: {CurveId}, {nameof(PublisherId)}: {PublisherId}, {nameof(Publisher)}: {Publisher}, " +
                   $"{nameof(PriceCurveDefinitionId)}: {PriceCurveDefinitionId}, " +
                   $"{nameof(DailyPeriods)}: [{string.Join(", ", DailyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(WeeklyPeriods)}: [{string.Join(", ", WeeklyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(MonthlyPeriods)}: [{string.Join(", ", MonthlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(QuarterlyPeriods)}: [{string.Join(", ", QuarterlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(HalfYearlyPeriods)}: [{string.Join(", ", HalfYearlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(YearlyPeriods)}: [{string.Join(", ", YearlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(Sides)}: [{string.Join(", ", Sides.Select(x => x.ToString()))}], " +
                   $"{nameof(Volumes)}: [{string.Join(", ", Volumes.Select(x => x.ToString(CultureInfo.InvariantCulture)))}], " +
                   $"{nameof(SpecifiedPrice)}: {SpecifiedPrice}, {nameof(TriggerPrice)}: {TriggerPrice}, {nameof(TriggerWhen)}: {TriggerWhen}";
        }
    }
}