﻿using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Dsp.DataContracts.Quote
{
    public class RestingQuoteRequest
    {
        public long RequestId { get; init; }

        public string CustomerId { get; init; }

        public List<RestingQuoteRequestLeg> Legs { get; init; }

        public RestingQuoteRequest()
        { }

        public RestingQuoteRequest(long requestId, string customerId, List<RestingQuoteRequestLeg> legs)
        {
            RequestId = requestId;
            CustomerId = customerId;
            Legs = legs;
        }

        public override string ToString()
        {
            return $"{nameof(RequestId)}: {RequestId}, {nameof(CustomerId)}: {CustomerId}, " +
                   $"{nameof(Legs)}: [{string.Join("; ", Legs.Select(x => x.ToString()))}]";
        }
    }

    public class RestingQuoteRequestLeg
    {
        public string CurveId { get; init; }

        public IList<DailyTenor> DailyPeriods { get; init; }
        public IList<WeeklyTenor> WeeklyPeriods { get; init; }
        public IList<MonthlyTenor> MonthlyPeriods { get; init; }
        public IList<QuarterlyTenor> QuarterlyPeriods { get; init; }
        public IList<HalfYearTenor> HalfYearlyPeriods { get; init; }
        public IList<AnnualTenor> YearlyPeriods { get; init; }
        public IList<BuySell> Sides { get; init; }

        public IList<double> Volumes { get; init; }

        public double SpecifiedPrice { get; init; }

        public RestingQuoteRequestLeg()
        { }

        public RestingQuoteRequestLeg(string curveId,
            IList<DailyTenor> dailyPeriods,
            IList<WeeklyTenor> weeklyPeriods,
            IList<MonthlyTenor> monthlyPeriods,
            IList<QuarterlyTenor> quarterlyPeriods,
            IList<HalfYearTenor> halfYearlyPeriods,
            IList<AnnualTenor> yearlyPeriods,
            IList<BuySell> sides,
            IList<int> volumes,
            double specifiedPrice)
        {
            CurveId = curveId;
            DailyPeriods = dailyPeriods;
            WeeklyPeriods = weeklyPeriods;
            MonthlyPeriods = monthlyPeriods;
            QuarterlyPeriods = quarterlyPeriods;
            HalfYearlyPeriods = halfYearlyPeriods;
            YearlyPeriods = yearlyPeriods;
            Sides = sides;
            Volumes = volumes.Select(x => (double)x).ToList();
            SpecifiedPrice = specifiedPrice;
        }

        public RestingQuoteRequestLeg(string curveId,
            IList<DailyTenor> dailyPeriods,
            IList<WeeklyTenor> weeklyPeriods,
            IList<MonthlyTenor> monthlyPeriods,
            IList<QuarterlyTenor> quarterlyPeriods,
            IList<HalfYearTenor> halfYearlyPeriods,
            IList<AnnualTenor> yearlyPeriods,
            IList<BuySell> sides,
            IList<double> volumes,
            double specifiedPrice)
        {
            CurveId = curveId;
            DailyPeriods = dailyPeriods;
            WeeklyPeriods = weeklyPeriods;
            MonthlyPeriods = monthlyPeriods;
            QuarterlyPeriods = quarterlyPeriods;
            HalfYearlyPeriods = halfYearlyPeriods;
            YearlyPeriods = yearlyPeriods;
            Sides = sides;
            Volumes = volumes;
            SpecifiedPrice = specifiedPrice;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(CurveId)}: {CurveId}, " +
                   $"{nameof(DailyPeriods)}: [{string.Join(", ", DailyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(WeeklyPeriods)}: [{string.Join(", ", WeeklyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(MonthlyPeriods)}: [{string.Join(", ", MonthlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(QuarterlyPeriods)}: [{string.Join(", ", QuarterlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(HalfYearlyPeriods)}: [{string.Join(", ", HalfYearlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(YearlyPeriods)}: [{string.Join(", ", YearlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(Sides)}: [{string.Join(", ", Sides?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(Volumes)}: [{string.Join(", ", Volumes?.Select(x => x.ToString(CultureInfo.InvariantCulture)) ?? [])}], " +
                   $"{nameof(SpecifiedPrice)}: {SpecifiedPrice}";
        }
    }
}