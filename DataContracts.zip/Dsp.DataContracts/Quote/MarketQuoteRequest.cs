﻿using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Dsp.DataContracts.Quote
{
   public class MarketQuoteRequest
    {
        public long RequestId { get; init; }
        public string CustomerId { get; init; }
        public int ValidForMins { get; init; }
        public List<MarketQuoteRequestLeg> Legs { get; init; }

        public MarketQuoteRequest()
        {
        }

        public MarketQuoteRequest(long requestId, string customerId, int validForMins, List<MarketQuoteRequestLeg> legs)
        {
            RequestId = requestId;
            CustomerId = customerId;
            ValidForMins = validForMins;
            Legs = legs;
        }

        public override string ToString()
        {
            return $"{nameof(RequestId)}: {RequestId}, {nameof(CustomerId)}: {CustomerId}, {nameof(ValidForMins)}: {ValidForMins}, " +
                   $"{nameof(Legs)}: [{string.Join("; ", Legs.Select(x => x.ToString()))}]";
        }
    }

    public class MarketQuoteRequestLeg
    {
        public string CurveId { get; init; }
        public IList<DailyTenor> DailyPeriods { get; init; }
        public IList<WeeklyTenor> WeeklyPeriods { get; init; }
        public IList<MonthlyTenor> MonthlyPeriods { get; init; }
        public IList<QuarterlyTenor> QuarterlyPeriods { get; init; }
        public IList<HalfYearTenor> HalfYearlyPeriods { get; init; }
        public IList<AnnualTenor> YearlyPeriods { get; init; }
        public IList<BuySell> Sides { get; init; }
        public IList<double> Volumes { get; init; }

        public MarketQuoteRequestLeg()
        {
        }

        public MarketQuoteRequestLeg(string curveId,
            IList<DailyTenor> dailyPeriods,
            IList<WeeklyTenor> weeklyPeriods,
            IList<MonthlyTenor> monthlyPeriods,
            IList<QuarterlyTenor> quarterlyPeriods,
            IList<HalfYearTenor> halfYearlyPeriods,
            IList<AnnualTenor> yearlyPeriods,
            IList<BuySell> sides,
            IList<int> volumes)
        {
            CurveId = curveId;
            DailyPeriods = dailyPeriods;
            WeeklyPeriods = weeklyPeriods;
            MonthlyPeriods = monthlyPeriods;
            QuarterlyPeriods = quarterlyPeriods;
            HalfYearlyPeriods = halfYearlyPeriods;
            YearlyPeriods = yearlyPeriods;
            Sides = sides;
            Volumes = volumes.Select(x => (double)x).ToList();
        }

        public MarketQuoteRequestLeg(string curveId,
            IList<DailyTenor> dailyPeriods,
            IList<WeeklyTenor> weeklyPeriods,
            IList<MonthlyTenor> monthlyPeriods,
            IList<QuarterlyTenor> quarterlyPeriods,
            IList<HalfYearTenor> halfYearlyPeriods,
            IList<AnnualTenor> yearlyPeriods,
            IList<BuySell> sides,
            IList<double> volumes)
        {
            CurveId = curveId;
            DailyPeriods = dailyPeriods;
            WeeklyPeriods = weeklyPeriods;
            MonthlyPeriods = monthlyPeriods;
            QuarterlyPeriods = quarterlyPeriods;
            HalfYearlyPeriods = halfYearlyPeriods;
            YearlyPeriods = yearlyPeriods;
            Sides = sides;
            Volumes = volumes;
        }

        public override string ToString()
        {
            return $"{nameof(CurveId)}: {CurveId}, " +
                   $"{nameof(DailyPeriods)}: [{string.Join(", ", DailyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(WeeklyPeriods)}: [{string.Join(", ", WeeklyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(MonthlyPeriods)}: [{string.Join(", ", MonthlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(QuarterlyPeriods)}: [{string.Join(", ", QuarterlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(HalfYearlyPeriods)}: [{string.Join(", ", HalfYearlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(YearlyPeriods)}: [{string.Join(", ", YearlyPeriods?.Select(x => x.ToString()) ?? [])}], " +
                   $"{nameof(Sides)}: [{string.Join(", ", Sides.Select(x => x.ToString()))}], " +
                   $"{nameof(Volumes)}: [{string.Join(", ", Volumes.Select(x => x.ToString(CultureInfo.InvariantCulture)))}]";
        }
    }
}