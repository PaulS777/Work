﻿// ***********************************************************************************************************************
// AuditTrailRecord.cs
//
// (Copyright (c) 2023 Shell. All rights reserved.
//
// -----------------------------------------------------------------------------------------------------------------------
// Purpose:
//
// Usage Notes:
//
// ************************************************************************************************************************

using System;

namespace Dsp.DataContracts
{
    public class AuditTrailRecord : IIdentifiable
    {
        public int Id { get; set; }
        public DateTime TimeStamp { get; set; }
        public string UserName { get; set; }
        public string Action { get; set; }
        public string Subject { get; set; }
        public string KeyValue { get; set; }
        public string Details { get; set; }


        public AuditTrailRecord(DateTime timeStamp, string userName, string action, string subject, string keyValue, string details)
        {
            TimeStamp = timeStamp;
            UserName = userName;
            Action = action;
            Subject = subject;
            KeyValue = keyValue;
            Details = details;
        }

        public AuditTrailRecord() { }

        
    }
}
