﻿using System;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    public class FuturesExpiry
    {
        public int BaseCurveId { get; init; }
        public DateTime ContractMonth { get; init; }

        public DateTime Expiry { get; init; }

        /// <summary>
        /// Required for Dapper
        /// </summary>
        public FuturesExpiry()
        {
        }

        [JsonConstructor]
        public FuturesExpiry(int baseCurveId, DateTime contractMonth, DateTime expiry)
        {
            BaseCurveId = baseCurveId;
            ContractMonth = contractMonth;
            Expiry = expiry;
        }
    }
}