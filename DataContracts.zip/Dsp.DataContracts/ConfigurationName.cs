﻿namespace Dsp.DataContracts
{
    public enum ConfigurationName
    {
        AutoRollEnabled = 1,
        DayOffset,
        RollTime,
        SetCurvesUntradeable,
        EomRollWindow
    }
}