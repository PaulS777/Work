﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Dsp.DataContracts
{
    /// <summary>
    /// Dictionary Wrapper and Snapshot helper for IIdentifiable items.
    /// Automatically maps the 'Id' attribute to dictionary key.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class DictionaryWrapper<T> where T : IIdentifiable
    {
        public Dictionary<int, T> SnapshotDictionary { get; }
        public Func<T, bool> DefaultFilter { get; protected init; }

        public static DictionaryWrapper<T> GetInstance()
        {
            if (typeof(T).IsAssignableTo(typeof(DeletableEntity)))
            {
                return new DeletableDictionaryWrapper<T>();
            }

            return new DictionaryWrapper<T>();
        }

        protected DictionaryWrapper(IEnumerable<T> items = null)
        {
            SnapshotDictionary = items == null ? new Dictionary<int, T>() : items.ToDictionary(x => x.Id);
            DefaultFilter = SubscriptionFilters.All;
        }

        public virtual void StoreLatest(List<T> items, Func<T, bool> filter)
        {
            if (filter is null)
            {
                foreach (var item in items)
                {
                    SnapshotDictionary[item.Id] = item;
                }
            }
            else
            {
                foreach (var item in items)
                {
                    if (filter(item))
                    {
                        SnapshotDictionary[item.Id] = item;
                    }
                    else
                    {
                        SnapshotDictionary.Remove(item.Id);
                    }
                }
            }
        }

        public List<T> GetSnapshot()
        {
            return SnapshotDictionary.Values.ToList();
        }

        public List<T> GetSnapshot(IEnumerable<int> ids)
        {
            return ids.Select(id => SnapshotDictionary[id]).ToList();
        }
        public T GetSnapshotItem(int id)
        {
            return SnapshotDictionary.GetValueOrDefault(id);
        }
    }

    /// <summary>
    /// Dictionary Wrapper and Snapshot helper for IIdentifiable items.
    /// Automatically maps the 'Id' attribute to dictionary key.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    internal class DeletableDictionaryWrapper<T> : DictionaryWrapper<T> where T : IIdentifiable
    {
        public DeletableDictionaryWrapper(IEnumerable<T> items = null) : base(items)
        {
            DefaultFilter = SubscriptionFilters.NotDeleted;
        }

        public override void StoreLatest(List<T> items, Func<T, bool> filter)
        {
            foreach (var item in items)
            {
                if (filter(item))
                {
                    SnapshotDictionary[item.Id] = item;
                }
                else
                {
                    SnapshotDictionary.Remove(item.Id);
                }
            }
        }
    }
}
