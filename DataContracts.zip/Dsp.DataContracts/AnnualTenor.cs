﻿using System;
using System.Collections.Generic;
using System.Globalization;
using TenorTypeEnum = Dsp.DataContracts.TenorType;

// ReSharper disable UnusedParameter.Local

namespace Dsp.DataContracts
{
    public readonly struct AnnualTenor: IComparable<AnnualTenor>, IEquatable<AnnualTenor>, ITenor
    {
        public static readonly IComparer<AnnualTenor> ComparerInstance = new AnnualTenorComparer();
        public static readonly ITenorConverter<AnnualTenor> ConverterInstance = new AnnualTenorConverter();

        public int Year { get; }

        public AnnualTenor(int value)
        {
            Year = value / 10000 % 10000;
            Validate();
        }

        public AnnualTenor(string token)
        {
            Year = Convert.ToInt32(token, CultureInfo.InvariantCulture);
            Validate();
        }

        private void Validate()
        {
            if (Year < 2000 || Year > 3000)
            {
                throw new ArgumentException("Year must be between 2000 and 3000");
            }
        }

        public bool Equals(AnnualTenor other)
        {
            return Year == other.Year;
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }

            return obj is AnnualTenor other && Equals(other);
        }

        public int CompareTo(ITenor other)
        {
            var typeComparison = TenorType().CompareTo(other.TenorType());
            return typeComparison != 0 ? typeComparison : CompareTo((AnnualTenor)other);
        }

        public int CompareTo(AnnualTenor other)
        {
            return Year.CompareTo(other.Year);
        }

        public static bool operator <(AnnualTenor left, AnnualTenor right)
        {
            return left.CompareTo(right) < 0;
        }

        public static bool operator >(AnnualTenor left, AnnualTenor right)
        {
            return left.CompareTo(right) > 0;
        }

        public static bool operator <=(AnnualTenor left, AnnualTenor right)
        {
            return left.CompareTo(right) <= 0;
        }

        public static bool operator >=(AnnualTenor left, AnnualTenor right)
        {
            return left.CompareTo(right) >= 0;
        }

        public static bool operator ==(AnnualTenor left, AnnualTenor right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(AnnualTenor left, AnnualTenor right)
        {
            return !left.Equals(right);
        }

        public string Key => $"{(int)TenorType()}{ConvertToInt()}";

        public int ConvertToInt()
        {
            return Year * 10000;
        }

        public TenorTypeEnum TenorType()
        {
            return TenorTypeEnum.Year;
        }

        public DateTime StartDate()
        {
            return new DateTime(Year, 1, 1);
        }

        public DateTime EndDate()
        {
            return StartDate().AddYears(1).AddDays(-1);
        }
        
        public static AnnualTenor ConvertFromInt(int value)
        {
            return new AnnualTenor(value);
        }

        public override string ToString()
        {
            return Year.ToString();
        }

        public override int GetHashCode()
        {
            return Year.GetHashCode();
        }

        private sealed class AnnualTenorComparer : IComparer<AnnualTenor>
        {
            public int Compare(AnnualTenor x, AnnualTenor y)
            {
                return x.CompareTo(y);
            }
        }

        private sealed class AnnualTenorConverter: ITenorConverter<AnnualTenor>
        {
            public AnnualTenor FromInt(int token)
            {
                return new AnnualTenor(token);
            }

            public int ToInt(AnnualTenor tenor)
            {
                return tenor.ConvertToInt();
            }

            /// <inheritdoc />
            public AnnualTenor FromDate(DateTime date)
            {
                return new AnnualTenor(date.Year);
            }

            /// <inheritdoc />
            public DateTime ToDate(AnnualTenor tenor)
            {
                return tenor.StartDate();
            }
        }
    }
}