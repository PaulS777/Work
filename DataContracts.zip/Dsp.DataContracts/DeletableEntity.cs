﻿using System.ComponentModel.DataAnnotations;
using Dsp.DataContracts.ValidationAttributes;
using Newtonsoft.Json;

namespace Dsp.DataContracts
{
    /// <summary>
    /// Denotes an entity that can be logically deleted.
    /// </summary>
    [JsonObject]
    public abstract record DeletableEntity : IIdentifiable
    {
        private EntityStatus _status;

        [JsonProperty]
        [Required]
        [EqualOrGreaterThan(0)]
        public int Id { get; init; }

        [JsonProperty]
        public EntityStatus Status
        {
            get => _status;
            init => _status = value;
        }

        [JsonConstructor]
        private DeletableEntity() : this(int.MinValue, EntityStatus.Active)
        { }

        /// <summary>
        /// Denotes an entity that can be logically deleted.
        /// </summary>
        protected DeletableEntity(int id, EntityStatus status)
        {
            Id = id;
            _status = status;
        }

        public void MarkDeleted()
        {
            _status = EntityStatus.Deleted;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Status)}: {Status}";
        }
    }
}