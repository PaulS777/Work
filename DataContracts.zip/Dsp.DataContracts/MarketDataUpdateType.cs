﻿namespace Dsp.DataContracts
{
    public enum MarketDataUpdateType
    {
        NotSpecified = 0,
        Future = 1,
        Spread = 2
    }
}