﻿using System;
using System.Collections.Generic;

namespace Dsp.DataContracts
{
    public static class TenorComparer
    {
        public static IComparer<T> GetInstance<T>() where T : ITenor
        {
            if (typeof(T) == typeof(DailyTenor))
            {
                return (IComparer<T>) DailyTenor.ComparerInstance;
            }

            if (typeof(T) == typeof(WeeklyTenor))
            {
                return (IComparer<T>) WeeklyTenor.ComparerInstance;
            }

            if(typeof(T) == typeof(MonthlyTenor))
            {
                return (IComparer<T>)MonthlyTenor.ComparerInstance;
            }

            if(typeof(T) == typeof(QuarterlyTenor))
            {
                return (IComparer<T>)QuarterlyTenor.ComparerInstance;
            }

            if(typeof(T) == typeof(HalfYearTenor))
            {
                return (IComparer<T>)HalfYearTenor.ComparerInstance;
            }

            if(typeof(T) == typeof(AnnualTenor))
            {
                return (IComparer<T>)AnnualTenor.ComparerInstance;
            }

            throw new ArgumentException($"Unsupported tenor type {typeof(T)}");
        }
    }
}