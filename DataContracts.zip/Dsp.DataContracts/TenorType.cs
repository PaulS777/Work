﻿/*====================================================================================
 *
 * WARNING: THIS ENUM FORMS PART OF THE VERSIONED API WITH DSX.
 *
 * Changing it will require a new API version (and potentially filtering new values
 * out of any previous API version to avoid breaking DSX)
 *
 =====================================================================================
*/
using System.ComponentModel;

namespace Dsp.DataContracts
{
    public enum TenorType
    {
        [Description("Day")]
        Day = 1,
        [Description("Week")]
        Week = 2,
        [Description("Month")]
        Month = 3,
        [Description("Quarter")]
        Quarter = 4,
        [Description("HalfYear")]
        HalfYear = 5,
        [Description("Year")]
        Year = 6
    }
}